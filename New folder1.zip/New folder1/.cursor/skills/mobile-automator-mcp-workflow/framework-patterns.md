# Framework adaptation patterns (reference)

Use these when adapting MCP-generated or raw Appium tests to this repo (AutomationBaseFramework / pharmacy-ui). Page Objects, `BasePageApplicationManager`, and `dpTestDataCreationJob.json` live here.

**Test class location:** Put all MCP-generated and new mobile E2E test classes under **`pharmacy-ui/src/test/java/mobile-e2e-tests/`** (e.g. package `mobile.e2e.tests` or `mobile.e2e.tests.<feature>`). Create the folder if needed.

---

## 🔥 CRITICAL: Where to Add New Methods (Decision Tree)

### Rule: Start with Base, Override Only When Needed

**For NEW methods that don't exist anywhere in the framework:**

```
Step 1: Add to BasePageApplicationManager FIRST
├─ Write full implementation in base class
├─ Add all necessary imports (By, WebElement, etc.)
└─ Document clearly with JavaDoc

Step 2: Test on Current Platform (e.g., Android)
├─ Verify method works correctly
└─ No platform-specific code yet

Step 3: Later, When Adding Another Platform (e.g., iOS)
├─ Does the same implementation work?
│  ├─ YES → Keep ONLY base implementation ✅
│  │        Don't create unnecessary overrides
│  │
│  └─ NO → Override in platform manager ✅
│           Add @Override annotation
│           Implement platform-specific logic
```

### Example: selectFamilyMemberForTransfer()

**❌ WRONG Approach (Premature Platform-Specific Code):**

```java
// BasePageApplicationManager.java - Empty implementation
public void selectFamilyMemberForTransfer(String familyMemberName) {
    Reporter.log("Selecting family member: " + familyMemberName);
}

// AndroidPageManager.java - Override created too early!
@Override
public void selectFamilyMemberForTransfer(String familyMemberName) {
    pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
    // ... full Android implementation
}
```

**Problem**: Override created before knowing if iOS differs!

**✅ CORRECT Approach (Start with Base):**

```java
// BasePageApplicationManager.java - Full implementation FIRST
/**
 * Select family member profile for competitive transfer by name
 * Note: Override in platform managers ONLY if implementation differs
 */
public void selectFamilyMemberForTransfer(String familyMemberName) {
    pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
    pharmacyDashboardPage.clickTransferSourceContinueButton();
    WebElement familyMemberElement = remoteWebDriver.findElement(
        By.xpath("//*[@text='" + familyMemberName + "']")
    );
    getTransferStartedPage.click(familyMemberElement);
    getTransferStartedPage.clickContinueButton();
    Reporter.log("Selected family member for transfer: " + familyMemberName);
}

// AndroidPageManager.java - NO override needed!
// Uses base implementation ✅

// IOSPageManager.java - Override ONLY if iOS needs different approach
// If same XPath works → NO override needed ✅
// If iOS needs different locator → THEN override ✅
```

### When to Override in Platform Managers

**Override ONLY when you discover platform differences:**

1. **Different Locator Strategy**

   ```java
   // iOS needs @name instead of @text
   @Override
   public void selectFamilyMemberForTransfer(String familyMemberName) {
       WebElement familyMemberElement = remoteWebDriver.findElement(
           By.xpath("//*[@name='" + familyMemberName + "']")
       );
       // ... rest
   }
   ```

2. **Different Navigation Flow**

   ```java
   @Override
   public void navigateToFeature() {
       clickTab("HealthAndWellness");  // Different tab name in iOS
       scrollToElement("Pharmacy");
   }
   ```

3. **Platform-Specific Behavior**
   ```java
   @Override
   public void proceedToPharmacyDashboard() {
       super.proceedToPharmacyDashboard();
       dismissAndroidPermissionDialog();  // Android-specific
   }
   ```

### Benefits

✅ Avoids premature optimization  
✅ Single source of truth until platforms diverge  
✅ Easier maintenance  
✅ `@Override` signals "this platform differs"  
✅ Follows DRY principle

---

## 🎯 Test Organization: Club Similar Tests Together

### Rule: Related Test Cases → Same Test File

**❌ WRONG: Separate Files for Variants**

```
CompetitiveTransferConnectedUserTest.java              // Primary profile
CompetitiveTransferFamilyMemberConnectedUserTest.java  // Family member
CompetitiveTransferMinorConnectedUserTest.java         // Minor
```

**Problem**: Scattered, hard to maintain, duplicate setup

**✅ CORRECT: Club Related Tests in One File**

```java
// CompetitiveTransferConnectedUserTest.java
public class CompetitiveTransferConnectedUserTest extends DigitalPharmacyTestBase {

    @Test
    public void testCompetitiveTransferPrimaryProfileVerifyTrackerCard() {
        // Test for PRIMARY PROFILE (Self)
    }

    @Test
    public void testCompetitiveTransferFamilyMemberVerifyTrackerCard() {
        // Test for FAMILY MEMBER (Adult)
    }

    @Test
    public void testCompetitiveTransferMinorVerifyTrackerCard() {
        // Test for FAMILY MEMBER (Minor)
    }
}
```

### When to Create New vs Add to Existing

**Create new file when:**

- Completely different feature (`InsuranceManagementTest.java` vs `CompetitiveTransferTest.java`)
- Different test lifecycle/setup
- No logical grouping with existing tests

**Add to existing file when:**

- Same feature, different variant (primary vs family member)
- Same setup/teardown
- Logically related scenarios

---

## 1. Code reusability

- Before adding any new method, search: `BasePageApplicationManager`, `AndroidPageManager`, `IOSPageManager`, and `pageObjects/` for the same or similar behavior.
- **Baseline (always reuse):** `doSignIn(email, password)`, `proceedToPharmacyDashboard()`, `dismissNotifications()`, `clickServicesTab()`.
- **MCP device execution:** To reach Pharmacy Dashboard on device, use **login_pharmacy_connected** (email, password, PIN) or **login_non_pharmacy_connected** (email, password only) instead of manual sign-in + navigate + PIN steps.
- Prefer reusing feature-specific and Page Object methods over duplicating.

---

## 2. Platform-specific overrides (UPDATED RULE)

### For NEW Methods:

- **Add to `BasePageApplicationManager` FIRST** with full implementation
- **Override later** in `AndroidPageManager` or `IOSPageManager` ONLY when platform differences discovered
- **Don't prematurely optimize**: Avoid creating platform-specific code before needed

### For EXISTING Methods:

- **Override** in `AndroidPageManager` or `IOSPageManager` when: different locator strategy (e.g. text vs name), different gestures, or platform-only UI
- Same behavior on both platforms → keep in Base only

Example override pattern for EXISTING method:

```java
// Base - Works for most platforms
public void clickElement(String locator) {
    driver.findElement(By.xpath(locator)).click();
}

// AndroidPageManager - Only override if Android needs different approach
@Override
public void clickElement(String locator) {
    new TouchAction(driver).tap(PointOption.point(x, y)).perform();
}
```

Example for NEW method:

```java
// BasePageApplicationManager - Full implementation FIRST
public void newFeatureMethod() {
    // Complete implementation that works for current platform
    clickButton("FeatureButton");
    verifyElementPresent("FeatureScreen");
}

// AndroidPageManager - NO override yet! Uses base implementation

// IOSPageManager - Override ONLY if iOS testing reveals differences
// If base implementation works → NO override needed ✅
// If iOS needs different approach → THEN override ✅
```

---

## 3. Page Manager method patterns

**Wrapper in BasePageApplicationManager** (tests call these):

```java
public void selectPrescriptionForRefill(String rxNumber) {
    prescriptionRefillPage.selectPrescription(rxNumber);
    log("Selected prescription: " + rxNumber);
}

public void submitRefillOrder() {
    prescriptionRefillPage.clickSubmitButton();
    prescriptionRefillPage.waitForConfirmation();
    log("Refill order submitted");
}
```

**Page Object** (low-level UI):

```java
public void selectPrescription(String rxNumber) {
    String xpath = "//android.widget.TextView[@text='" + rxNumber + "']";
    driver.findElement(By.xpath(xpath)).click();
}
```

Tests use only wrapper methods on `basePageApplicationManager`, not direct Page Object calls.

---

## 4. Naming conventions

- **Test class:** `RefillPrescriptionTest.java`, `SubmitVaccineAppointmentTest.java` (descriptive, not `Test1.java`).
- **Test method:** `testRefillSingleActivePrescription()`, `testSubmitVaccineAppointmentForDependent()` (descriptive, not `test1()`).
- **Page Object class:** `PrescriptionRefillPage.java`, `VaccineSchedulerPage.java`.
- **Methods:** `selectPrescriptionForRefill(String rxNumber)`, `submitRefillOrder()`, `verifyConfirmationMessage()` (clear, camelCase).

---

## 5. Test data JSON

- **File:** `pharmacy-ui/dpTestDataCreationJob.json` in this repo.
- **Key:** exact test method name.
- **Usage:** `commonUtilsForData.getJsonTestData(testDataJsonPath, method.getName())`; then `testData.getString("email")`, etc.

Structure:

```json
{
  "testRefillSingleActivePrescription": {
    "email": "test.user@walmart.com",
    "password": "Password123!",
    "pin": "1111",
    "rxNumber": "RX12345678",
    "storeNumber": "12345"
  }
}
```

Common fields: `email`, `password`, `pin`, `firstName`, `lastName`, `phoneNumber`, `zipCode`, `dateOfBirth`.

---

## 6. When to create Page Object methods (UPDATED)

1. **Already exists?** Search Page Objects → reuse.
2. **Baseline action?** (sign in, navigate to pharmacy, dismiss notifications) → reuse existing baseline methods.
3. **Feature-specific?** → add to the feature Page Object.
4. **Generic (not feature-specific)?** → add wrapper method to `BasePageApplicationManager`.
5. **NEW method needed?** → Add to `BasePageApplicationManager` FIRST with full implementation.
6. **Platform differences discovered?** → THEN override in `AndroidPageManager` / `IOSPageManager`.

**Decision Tree for NEW Manager Methods:**

```
Does method exist in framework?
├─ YES → Reuse it ✅
└─ NO (NEW method needed)
   └─ Add to BasePageApplicationManager with full implementation ✅
      └─ Later, when testing on another platform:
         ├─ Same implementation works? → Keep only base ✅
         └─ Different implementation needed? → Override in platform manager ✅
```

---

## 7. Completion checklist (UPDATED)

**Code structure**

- [ ] Test class file is under **`pharmacy-ui/src/test/java/mobile-e2e-tests/`** (package `mobile.e2e.tests` or subpackage).
- [ ] **Checked for existing related test file** to club similar tests together.
- [ ] **Added test method to existing file** if feature-related, OR created new file only if completely different feature.
- [ ] Test extends project test base (e.g. `DigitalPharmacyTestBase`).
- [ ] New UI → Page Object created; wrapper methods added to `BasePageApplicationManager`.
- [ ] **NEW methods → Added to `BasePageApplicationManager` FIRST** (not platform managers).
- [ ] **Override decision**: Will override in platform managers ONLY when platform differences discovered.

**Test methods**

- [ ] `@BeforeMethod`: platform param, app launch, get page manager.
- [ ] `@Test`: `Method` parameter for test data lookup; uses wrapper methods only.
- [ ] `@AfterMethod`: screenshot on failure, driver quit.

**Test data**

- [ ] Entry in `pharmacy-ui/src/test/java/mobile-e2e-tests/testdata/mobileE2ETestData.json`; key = method name; required fields present.

**Reusability and naming**

- [ ] Searched for existing methods; reused baseline and feature methods.
- [ ] **NEW methods added to base class first**, not platform-specific.
- [ ] **Similar tests clubbed in same file**, not scattered.
- [ ] Descriptive class/method names; no duplicate logic.

**Verification**

- [ ] Assertions with clear failure messages; coverage appropriate for the scenario.
