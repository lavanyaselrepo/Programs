using FlaUI.Core.AutomationElements;
using FlaUI.Core.Capturing;
using FlaUI.UIA3;
using FlaUIgRPC.Server.Core;
using FlaUIgRPC.Server.Protos;
using Google.Protobuf;
using Grpc.Core;
using Serilog;
using System.Runtime.InteropServices;

namespace FlaUIgRPC.Server.Services;

/// <summary>
/// Implements all gRPC RPCs defined in flaui_service.proto.
/// Session, App lifecycle, Element discovery, Element state, Window management, Screenshot.
/// Actions (mouse/keyboard/popup/etc.) live in FlaUIAutomationServiceImpl.Actions.cs.
/// </summary>
public sealed partial class FlaUIAutomationServiceImpl
    : FlaUIAutomationService.FlaUIAutomationServiceBase
{
    // Injected as a Singleton from DI — shared across ALL gRPC calls on this server.
    // DO NOT use `new SessionManager()` here: gRPC services are transient (new instance
    // per call), so each call would get a fresh empty dictionary and sessions created by
    // CreateSession would be invisible to FindElement. (KeyNotFoundException fix)
    private readonly SessionManager _sessions;
    private static readonly DateTime StartTime = DateTime.UtcNow;

    public FlaUIAutomationServiceImpl(SessionManager sessions)
    {
        _sessions = sessions;
    }

    // P/Invoke to get process ID from a native window handle
    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    // P/Invoke: returns true if hWnd is a valid, live top-level window.
    // Used to detect stale MainWindow references after a window transition
    // (e.g. login window destroyed → security popup appears).
    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    // ================================================================
    // Session Management
    // ================================================================

    public override Task<CreateSessionResponse> CreateSession(
        CreateSessionRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Create();

            // If capabilities include "app": "Root" we create a root-level session
            // (used by GrpcConnexusManager to discover existing windows)
            if (request.Capabilities.TryGetValue("app", out var app) &&
                string.Equals(app, "Root", StringComparison.OrdinalIgnoreCase))
            {
                session.MainWindow = session.Auto.GetDesktop();
                Log.Debug("[CreateSession] Root session created: {Id}", session.SessionId);
            }
            else if (request.Capabilities.TryGetValue("appTopLevelWindow", out var hexHandle))
            {
                // Attach to an existing window by native handle
                var hwnd   = (IntPtr)Convert.ToInt64(hexHandle, 16);
                var window = session.Auto.FromHandle(hwnd);
                session.MainWindow = window;
                // Also attach Application by PID for process lifecycle management
                GetWindowThreadProcessId(hwnd, out uint pid);
                if (pid > 0)
                    session.App = FlaUI.Core.Application.Attach((int)pid);
                Log.Information("[CreateSession] Attached to window 0x{Handle}: {Id}", hexHandle, session.SessionId);
            }

            return Task.FromResult(new CreateSessionResponse
            {
                SessionId = session.SessionId,
                Success   = true
            });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[CreateSession] Failed");
            return Task.FromResult(new CreateSessionResponse
            {
                Success      = false,
                ErrorMessage = ex.Message
            });
        }
    }

    public override Task<CloseSessionResponse> CloseSession(
        CloseSessionRequest request, ServerCallContext ctx)
    {
        try
        {
            _sessions.Close(request.SessionId);
            return Task.FromResult(new CloseSessionResponse { Success = true });
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "[CloseSession] {Id}", request.SessionId);
            return Task.FromResult(new CloseSessionResponse { Success = true, ErrorMessage = ex.Message });
        }
    }

    // ================================================================
    // Application Lifecycle
    // ================================================================

    public override Task<LaunchAppResponse> LaunchApplication(
        LaunchAppRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var timeout = request.TimeoutSeconds > 0
                ? TimeSpan.FromSeconds(request.TimeoutSeconds)
                : TimeSpan.FromSeconds(60);

            session.App        = FlaUI.Core.Application.Launch(request.AppPath);
            session.MainWindow = session.App.GetMainWindow(session.Auto, timeout);

            if (session.MainWindow == null)
                throw new InvalidOperationException($"App launched but no main window found within {timeout.TotalSeconds}s");

            var handle = session.MainWindow.Properties.NativeWindowHandle.Value;
            var hexHandle = ((int)handle).ToString("X");

            Log.Information("[LaunchApplication] Launched '{Path}' -> handle 0x{Handle}",
                request.AppPath, hexHandle);

            return Task.FromResult(new LaunchAppResponse
            {
                Success      = true,
                WindowHandle = hexHandle
            });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[LaunchApplication] {Path}", request.AppPath);
            return Task.FromResult(new LaunchAppResponse
            {
                Success      = false,
                ErrorMessage = ex.Message
            });
        }
    }

    public override Task<AttachToWindowResponse> AttachToWindow(
        AttachToWindowRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            AutomationElement? window = null;

            if (!string.IsNullOrEmpty(request.WindowHandle))
            {
                var hwnd = (IntPtr)Convert.ToInt64(request.WindowHandle, 16);
                window = session.Auto.FromHandle(hwnd);
            }
            else if (!string.IsNullOrEmpty(request.WindowTitle))
            {
                var desktop = session.Auto.GetDesktop();
                window = desktop.FindFirstDescendant(
                    session.Auto.ConditionFactory.ByName(request.WindowTitle));
            }

            if (window == null)
                throw new InvalidOperationException(
                    $"Window not found (title='{request.WindowTitle}', handle='{request.WindowHandle}')");

            session.MainWindow = window;
                    var hexHandle = ((int)window.Properties.NativeWindowHandle.Value).ToString("X");

            return Task.FromResult(new AttachToWindowResponse
            {
                Success      = true,
                WindowHandle = hexHandle
            });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[AttachToWindow]");
            return Task.FromResult(new AttachToWindowResponse
            {
                Success      = false,
                ErrorMessage = ex.Message
            });
        }
    }

    public override Task<CloseAppResponse> CloseApplication(
        CloseAppRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            session.App?.Close();
            Log.Information("[CloseApplication] {Id}", request.SessionId);
            return Task.FromResult(new CloseAppResponse { Success = true });
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "[CloseApplication]");
            return Task.FromResult(new CloseAppResponse { Success = true, ErrorMessage = ex.Message });
        }
    }

    // ================================================================
    // Element Discovery
    // ================================================================

    public override Task<FindElementResponse> FindElement(
        FindElementRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var root    = ResolveRoot(session, request.ParentElementId);

            var element = session.Finder.FindElement(
                root, request.Strategy, request.Value, request.TimeoutMs);

            if (element == null)
                return Task.FromResult(new FindElementResponse
                {
                    Found        = false,
                    ErrorMessage = $"Element not found: {request.Strategy}='{request.Value}'"
                });

            var id = session.Cache.Store(element);
            return Task.FromResult(new FindElementResponse { Found = true, ElementId = id });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[FindElement] {Strategy}='{Value}'", request.Strategy, request.Value);
            return Task.FromResult(new FindElementResponse
            {
                Found        = false,
                ErrorMessage = ex.Message
            });
        }
    }

    public override Task<FindElementsResponse> FindElements(
        FindElementRequest request, ServerCallContext ctx)
    {
        try
        {
            var session  = _sessions.Get(request.SessionId);
            var root     = ResolveRoot(session, request.ParentElementId);
            var elements = session.Finder.FindElements(root, request.Strategy, request.Value);

            var response = new FindElementsResponse();
            foreach (var el in elements)
            {
                var id = session.Cache.Store(el);
                response.Elements.Add(new ElementInfo
                {
                    ElementId    = id,
                    Name         = el.Name ?? "",
                    AutomationId = el.AutomationId ?? "",
                    ClassName    = el.ClassName ?? "",
                    IsEnabled    = el.IsEnabled,
                    IsVisible    = !el.IsOffscreen
                });
            }
            return Task.FromResult(response);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[FindElements]");
            return Task.FromResult(new FindElementsResponse { ErrorMessage = ex.Message });
        }
    }

    // ================================================================
    // Element State
    // ================================================================

    public override Task<GetTextResponse> GetText(
        ElementActionRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);

            // 1. Try ValuePattern (TextBox, ComboBox, EditBox)
            string text = "";
            try   { text = element.AsTextBox().Text ?? ""; }
            catch { /* not a TextBox — fall through */ }

            // 2. Fall back to UIA Name property (standard for Label controls)
            if (string.IsNullOrEmpty(text))
                text = element.Name ?? "";

            // 3. WinForms container fallback: lblTitle is sometimes a Panel whose own
            //    Name is empty while a child Label holds the actual page-title text.
            //    Scan immediate children and return the first non-empty text found.
            //    This fixes isPageDisplayed() always returning false in gRPC mode.
            if (string.IsNullOrEmpty(text))
            {
                foreach (var child in element.FindAllChildren())
                {
                    string childText = "";
                    try   { childText = child.AsTextBox().Text ?? ""; }
                    catch { childText = child.Name ?? ""; }
                    if (!string.IsNullOrEmpty(childText))
                    {
                        text = childText;
                        break;
                    }
                }
            }

            return Task.FromResult(new GetTextResponse { Success = true, Text = text });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[GetText] {Id}", request.ElementId);
            return Task.FromResult(new GetTextResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    public override Task<GetAttributeResponse> GetAttribute(
        GetAttributeRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);
            var value   = ResolveAttribute(element, request.AttributeName);

            return Task.FromResult(new GetAttributeResponse { Success = true, Value = value });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[GetAttribute] {Attr}", request.AttributeName);
            return Task.FromResult(new GetAttributeResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    public override Task<BoolResponse> IsDisplayed(
        ElementActionRequest request, ServerCallContext ctx)
        => BoolCheck(request, el =>
        {
            // Primary check via UIA IsOffscreen property
            if (!el.IsOffscreen) return true;

            // WinForms quirk: Label/Panel controls nested inside container panels
            // incorrectly report IsOffscreen=true even when fully visible on screen.
            // This caused pollForElementGrpc() to always time out on page-title labels
            // (e.g. lblTitle), breaking every isPageDisplayed() check in gRPC mode.
            // Fallback: a non-zero bounding rectangle means the element IS on screen.
            var bounds = el.BoundingRectangle;
            return bounds.Width > 0 && bounds.Height > 0;
        });

    public override Task<BoolResponse> IsEnabled(
        ElementActionRequest request, ServerCallContext ctx)
        => BoolCheck(request, el => el.IsEnabled);

    public override Task<BoolResponse> IsSelected(
        ElementActionRequest request, ServerCallContext ctx)
        => BoolCheck(request, el =>
        {
            try { return el.Patterns.SelectionItem.Pattern.IsSelected; }
            catch { return false; }
        });

    // ================================================================
    // Window Management
    // ================================================================

    public override Task<WindowHandleResponse> GetWindowHandle(
        SessionRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);

            if (session.MainWindow == null)
                throw new InvalidOperationException("No valid main window in this session.");

            // Validate the stored window handle is still alive.
            // After login the Connexus login window is destroyed and a security popup
            // takes its place — UIA will throw COMException / AccessViolation when
            // we try to read a destroyed HWND. Detect this early and self-heal.
            IntPtr storedHwnd;
            try
            {
                storedHwnd = (IntPtr)(int)session.MainWindow.Properties.NativeWindowHandle.Value;
            }
            catch (Exception ex)
            {
                Log.Warning("[GetWindowHandle] Could not read stored window handle — trying self-heal. ({Msg})", ex.Message);
                storedHwnd = IntPtr.Zero;
            }

            if (storedHwnd == IntPtr.Zero || !IsWindow(storedHwnd))
            {
                // The stored window is dead. Try to find a live window for the same
                // process so we can update the session and continue cleanly.
                Log.Warning("[GetWindowHandle] Stored window handle 0x{Hwnd:X} is dead. Scanning for a live window...",
                    (long)storedHwnd);

                var recovered = FindLiveWindowForSession(session);
                if (recovered != null)
                {
                    session.MainWindow = recovered;
                    GetWindowThreadProcessId((IntPtr)(int)recovered.Properties.NativeWindowHandle.Value, out uint recoveredPid);
                    storedHwnd = (IntPtr)(int)recovered.Properties.NativeWindowHandle.Value;
                    Log.Information("[GetWindowHandle] Self-healed: now using handle 0x{Hwnd:X}", (long)storedHwnd);
                }
                else
                {
                    throw new InvalidOperationException(
                        "No valid main window in this session. "
                        + "The application window was destroyed (e.g. during login/popup transition) "
                        + "and no replacement window could be found for this process.");
                }
            }

            var hex = ((int)storedHwnd).ToString("X");
            return Task.FromResult(new WindowHandleResponse { Success = true, WindowHandle = hex });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[GetWindowHandle]");
            return Task.FromResult(new WindowHandleResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    public override Task<WindowHandlesResponse> GetWindowHandles(
        SessionRequest request, ServerCallContext ctx)
    {
        try
        {
            var session  = _sessions.Get(request.SessionId);
            var desktop  = session.Auto.GetDesktop();
            var windows  = desktop.FindAllChildren();
            var response = new WindowHandlesResponse { Success = true };

            // Determine the PID of the Connexus process from the session's main window.
            // We ONLY return windows belonging to that same process, so the Java-side
            // switchWindow() retry loop never focuses Explorer / Notepad / IntelliJ etc.
            // This also eliminates E_ACCESSDENIED errors from protected system windows.
            uint targetPid = 0;
            if (session.MainWindow != null)
            {
                try
                {
                    var mainHwnd = (IntPtr)(int)session.MainWindow.Properties.NativeWindowHandle.Value;
                    GetWindowThreadProcessId(mainHwnd, out targetPid);
                }
                catch { /* fall through — targetPid stays 0, include all as safe fallback */ }
            }
            // Fallback: read PID directly from the Application object.
            // This is necessary when session.MainWindow references a window that was just
            // destroyed (e.g. login window closed during the login→popup transition) and
            // reading its HWND throws. We still know the process is alive via App.
            if (targetPid == 0 && session.App != null)
            {
                try { targetPid = (uint)session.App.ProcessId; }
                catch { /* process may be gone; targetPid stays 0 — safe fallback includes all */ }
            }

            foreach (var w in windows)
            {
                try
                {
                    var wHwnd = (IntPtr)(int)w.Properties.NativeWindowHandle.Value;

                    // Skip windows that don't belong to the Connexus process
                    if (targetPid != 0)
                    {
                        GetWindowThreadProcessId(wHwnd, out uint wPid);
                        if (wPid != targetPid)
                            continue;
                    }

                    var hex2 = ((int)wHwnd).ToString("X");
                    response.WindowHandles.Add(hex2);
                    Log.Debug("[GetWindowHandles] Included handle {Handle} (pid={Pid})", hex2, targetPid);
                }
                catch { /* skip windows we can't read */ }
            }

            // Race condition guard: after a window transition (e.g. login → security popup)
            // the old window is destroyed BEFORE the new popup is visible. If we found 0 windows
            // but we have a known live process PID, retry for up to 3 seconds so the caller
            // doesn't have to spin-wait in an empty loop on the Java side.
            if (response.WindowHandles.Count == 0 && targetPid != 0)
            {
                const int maxWaitMs     = 3000;
                const int retryInterval = 300;
                int waited = 0;
                while (response.WindowHandles.Count == 0 && waited < maxWaitMs)
                {
                    Thread.Sleep(retryInterval);
                    waited += retryInterval;
                    foreach (var w2 in desktop.FindAllChildren())
                    {
                        try
                        {
                            var wHwnd2 = (IntPtr)(int)w2.Properties.NativeWindowHandle.Value;
                            GetWindowThreadProcessId(wHwnd2, out uint wPid2);
                            if (wPid2 != targetPid) continue;
                            var hex3 = ((int)wHwnd2).ToString("X");
                            if (!response.WindowHandles.Contains(hex3))
                                response.WindowHandles.Add(hex3);
                        }
                        catch { /* skip unreadable windows */ }
                    }
                    if (response.WindowHandles.Count > 0)
                        Log.Information("[GetWindowHandles] Window appeared after {Ms}ms wait (pid={Pid})", waited, targetPid);
                }
                if (response.WindowHandles.Count == 0)
                    Log.Warning("[GetWindowHandles] Still 0 windows after {Ms}ms wait for pid={Pid}", maxWaitMs, targetPid);
            }

            // -----------------------------------------------------------------------
            // Last-resort: Connexus uses a process-handoff model. The auth launcher
            // (the original PID we tracked) exits after login; the actual shell starts
            // in a BRAND NEW process. If PID-filtered search finds nothing, scan ALL
            // top-level desktop windows for AutomationId=ShellForm, re-attach the
            // session to the new process, and return its handle.
            // -----------------------------------------------------------------------
            if (response.WindowHandles.Count == 0)
            {
                var shellEl = FindShellFormOnDesktop(session);
                if (shellEl != null)
                {
                    var shellHwnd = (IntPtr)(int)shellEl.Properties.NativeWindowHandle.Value;
                    var hexShell  = ((int)shellHwnd).ToString("X");
                    response.WindowHandles.Add(hexShell);
                    Log.Information("[GetWindowHandles] Process handoff: re-attached to ShellForm {Handle}", hexShell);
                }
            }

            Log.Debug("[GetWindowHandles] Returning {Count} Connexus-owned handles (pid={Pid})",
                response.WindowHandles.Count, targetPid);
            return Task.FromResult(response);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[GetWindowHandles]");
            return Task.FromResult(new WindowHandlesResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    public override Task<ActionResponse> SwitchToWindow(
        SwitchWindowRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var hwnd    = (IntPtr)Convert.ToInt64(request.WindowHandle, 16);
            var window  = session.Auto.FromHandle(hwnd);
            window.Focus();
            session.MainWindow = window;
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[SwitchToWindow]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // Screenshot
    // ================================================================

    public override Task<ScreenshotResponse> TakeScreenshot(
        SessionRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var window  = session.MainWindow
                          ?? session.Auto.GetDesktop();

            using var capture = Capture.Element(window);
            using var ms      = new MemoryStream();
            capture.Bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);

            return Task.FromResult(new ScreenshotResponse
            {
                Success        = true,
                ScreenshotData = ByteString.CopyFrom(ms.ToArray())
            });
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[TakeScreenshot]");
            return Task.FromResult(new ScreenshotResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    // ================================================================
    // Internal shared helpers
    // ================================================================

    /// <summary>
    /// Scans desktop top-level windows for any live window belonging to the same
    /// process as the session's current (possibly stale) MainWindow.
    /// Used by <see cref="GetWindowHandle"/> self-heal logic.
    /// Returns the first visible, alive window found, or null.
    /// </summary>
    private AutomationElement? FindLiveWindowForSession(AutomationSession session)
    {
        // Determine the target PID from the session's App reference first,
        // then fall back to attempting to read the (potentially stale) MainWindow.
        uint targetPid = 0;
        if (session.App != null)
        {
            try { targetPid = (uint)session.App.ProcessId; }
            catch { /* App may already be disposed */ }
        }
        if (targetPid == 0 && session.MainWindow != null)
        {
            try
            {
                var hwnd = (IntPtr)(int)session.MainWindow.Properties.NativeWindowHandle.Value;
                GetWindowThreadProcessId(hwnd, out targetPid);
            }
            catch { /* can't read stale handle — PID stays 0 */ }
        }

        if (targetPid == 0)
        {
            Log.Warning("[FindLiveWindowForSession] Cannot determine process PID — cannot self-heal.");
            return null;
        }

        try
        {
            var desktop = session.Auto.GetDesktop();
            foreach (var w in desktop.FindAllChildren())
            {
                try
                {
                    var wHwnd = (IntPtr)(int)w.Properties.NativeWindowHandle.Value;
                    if (!IsWindow(wHwnd)) continue;
                    GetWindowThreadProcessId(wHwnd, out uint wPid);
                    if (wPid == targetPid)
                    {
                        // Update the session's MainWindow to the recovered window
                        // so subsequent calls (SwitchToWindow, etc.) find a live reference.
                        Log.Debug("[FindLiveWindowForSession] Recovered window 0x{Hwnd:X} for pid={Pid}",
                            (long)wHwnd, targetPid);
                        return w;
                    }
                }
                catch { /* skip unreadable system windows */ }
            }
        }
        catch (Exception ex)
        {
            Log.Warning("[FindLiveWindowForSession] Desktop scan failed: {Msg}", ex.Message);
        }

        // PID-based scan found nothing — the auth launcher likely exited and the
        // shell started in a new process (process-handoff pattern). Try ShellForm.
        return FindShellFormOnDesktop(session);
    }

    /// <summary>
    /// Scans ALL top-level desktop windows for AutomationId="ShellForm" (Connexus main shell).
    /// When found, re-attaches the session's App + MainWindow to the new process and returns
    /// the element. Call this as a last resort when the tracked PID has no live windows.
    /// </summary>
    private AutomationElement? FindShellFormOnDesktop(AutomationSession session)
    {
        try
        {
            var desktop = session.Auto.GetDesktop();
            foreach (var w in desktop.FindAllChildren())
            {
                try
                {
                    var autoId = w.Properties.AutomationId.ValueOrDefault ?? "";
                    if (!string.Equals(autoId, "ShellForm", StringComparison.OrdinalIgnoreCase))
                        continue;

                    var shellHwnd = (IntPtr)(int)w.Properties.NativeWindowHandle.Value;
                    if (!IsWindow(shellHwnd)) continue;

                    GetWindowThreadProcessId(shellHwnd, out uint newPid);

                    // Re-attach the session to the new shell process.
                    try { session.App?.Dispose(); } catch { /* best-effort */ }
                    session.App        = FlaUI.Core.Application.Attach((int)newPid);
                    session.MainWindow = w;

                    Log.Information(
                        "[FindShellFormOnDesktop] Process handoff — attached to ShellForm 0x{Hwnd:X} (new pid={Pid})",
                        (long)shellHwnd, newPid);
                    return w;
                }
                catch { /* skip unreadable windows */ }
            }
        }
        catch (Exception ex)
        {
            Log.Warning("[FindShellFormOnDesktop] Desktop scan failed: {Msg}", ex.Message);
        }
        return null;
    }

    private AutomationElement ResolveRoot(AutomationSession session, string parentElementId)
    {
        if (!string.IsNullOrEmpty(parentElementId) && session.Cache.TryGet(parentElementId, out var parent))
            return parent!;
        return session.MainWindow ?? session.Auto.GetDesktop();
    }

    private string ResolveAttribute(AutomationElement element, string name)
        => name.ToLowerInvariant() switch
        {
            "nativewindowhandle" => ((int)element.Properties.NativeWindowHandle.Value).ToString(),
            "automationid"       => element.AutomationId ?? "",
            "name"               => element.Name ?? "",
            "classname"          => element.ClassName ?? "",
            "isenabled"          => element.IsEnabled.ToString(),
            "isoffscreen"        => element.IsOffscreen.ToString(),
            "value"              => GetValueSafe(element),
            _                    => GetValueSafe(element)
        };

    private static string GetValueSafe(AutomationElement el)
    {
        try   { return el.AsTextBox().Text ?? el.Name ?? ""; }
        catch { return el.Name ?? ""; }
    }

    private Task<BoolResponse> BoolCheck(ElementActionRequest request, Func<AutomationElement, bool> check)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);
            return Task.FromResult(new BoolResponse { Success = true, Result = check(element) });
        }
        catch (Exception ex)
        {
            return Task.FromResult(new BoolResponse { Success = false, ErrorMessage = ex.Message });
        }
    }

    private static ActionResponse Ok()          => new() { Success = true };
    private static ActionResponse Fail(Exception ex) => new() { Success = false, ErrorMessage = ex.Message };
}
