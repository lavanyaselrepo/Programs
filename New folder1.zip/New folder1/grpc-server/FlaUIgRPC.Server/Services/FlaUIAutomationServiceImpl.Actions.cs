using FlaUI.Core.AutomationElements;
using FlaUI.Core.Definitions;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;
using static FlaUI.Core.WindowsAPI.VirtualKeyShort;
using FlaUIgRPC.Server.Core;
using FlaUIgRPC.Server.Protos;
using Grpc.Core;
using Serilog;
using FlaUI.Core.Definitions;
using FlaUI.Core.WindowsAPI;

namespace FlaUIgRPC.Server.Services;

/// <summary>
/// Actions partial: Click, SendKeys, Mouse, Keyboard, ComboBox, List,
/// Popup, Drag &amp; Drop, Window Focus, Ping.
/// Companion file to FlaUIAutomationServiceImpl.cs.
/// </summary>
public sealed partial class FlaUIAutomationServiceImpl
{
    // ================================================================
    // Element Interactions
    // ================================================================

    public override Task<ActionResponse> Click(
        ElementActionRequest request, ServerCallContext ctx)
        => ElementAction(request, el =>
        {
            var controlType = el.Properties.ControlType.ValueOrDefault;
            Log.Debug("[Click] ControlType={ControlType} AutomationId={Id} Name={Name}",
                controlType, el.Properties.AutomationId.ValueOrDefault, el.Properties.Name.ValueOrDefault);

            if (controlType == ControlType.CheckBox)
            {
                // WinForms CnxCheckBox: use UIA TogglePattern instead of a physical mouse click.
                // Physical clicks can miss if Connexus loses foreground focus mid-automation,
                // or if the clickable point is offset inside a scrolled panel.
                // TogglePattern.Toggle() goes through the accessibility API directly and is
                // position-independent — it always works regardless of window focus.
                var cb = el.AsCheckBox();
                var state = cb.ToggleState;
                if (state != ToggleState.On)
                {
                    cb.Toggle();
                    Log.Debug("[Click/Toggle] CheckBox '{Name}' toggled (was {State})", el.Name, state);
                }
                else
                {
                    Log.Debug("[Click/Toggle] CheckBox '{Name}' already checked — skipping", el.Name);
                }
            }
            else
            {
                el.Click();
            }

        });

    public override Task<ActionResponse> DoubleClick(
        ElementActionRequest request, ServerCallContext ctx)
        => ElementAction(request, el => el.DoubleClick());

    public override Task<ActionResponse> RightClick(
        ElementActionRequest request, ServerCallContext ctx)
        => ElementAction(request, el => el.RightClick());

    public override Task<ActionResponse> MouseHover(
        ElementActionRequest request, ServerCallContext ctx)
        => ElementAction(request, el => Mouse.MoveTo(el.GetClickablePoint()));

    public override Task<ActionResponse> Clear(
        ElementActionRequest request, ServerCallContext ctx)
        => ElementAction(request, el =>
        {
            try
                        {
                            el.AsTextBox().Text = "";
                        }
                        catch
                        {
                            // ValuePattern.SetValue("") rejected (e.g. numeric/masked WinForms fields).
                            // Fall back to keyboard: focus + Ctrl+A + Delete.
                            el.Click();
                            Thread.Sleep(50);
                            KeyboardSelectAll();
                            KeyboardDelete();
                        }
        });

    public override Task<ActionResponse> SendKeys(
        SendKeysRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);

            // Step 1: Physical click to arm the Win32 focus chain for WinForms TextBox.
            // UIA SetFocus() alone bypasses WM_LBUTTONDOWN so the control's input
            // cursor never activates. This mirrors the proven poc/winapp-gcrpServer approach.
            element.Click();
            Thread.Sleep(100);

            if (request.ClearFirst)
            {
                // Prefer ValuePattern clear — direct, no timing, no keyboard events.
                // Fall back to keyboard clear for controls that don't support
                // ValuePattern (masked textboxes, password fields, custom inputs).
                try
                {
                    element.AsTextBox().Text = string.Empty;
                }
                catch
                {
                    KeyboardSelectAll();
                    KeyboardDelete();
                }
            }

            // Step 2: Try UIA ValuePattern first (most reliable — no focus dependency).
            // Proven approach from poc/winapp-gcrpServer branch PR #6068.
            try
            {
                element.AsTextBox().Enter(request.Text);
            }
            catch
            {
                // Fallback: character-by-character keyboard for controls that
                // don't support ValuePattern (password fields, custom controls).
                Keyboard.Type(request.Text);
            }

            Log.Debug("[SendKeys] Typed {Len} chars into {Id}", request.Text.Length, request.ElementId);
            CheckForCaeDialog(session);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[SendKeys]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // Keyboard
    // ================================================================

    public override Task<ActionResponse> PressKeys(
        PressKeysRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);

            // Optional: focus a specific element first
            if (!string.IsNullOrEmpty(request.ElementId))
            {
                if (session.Cache.TryGet(request.ElementId, out var el))
                    el!.Focus();
            }

            var keys = KeyboardHelper.ToVirtualKeys(request.KeyCodes).ToArray();
            if (keys.Length == 0)
            {
                Log.Warning("[PressKeys] No mappable keys in codes: [{Codes}]",
                    string.Join(", ", request.KeyCodes.Select(k => $"0x{k:X2}")));
                return Task.FromResult(Ok());
            }

            if (keys.Length == 1)
                Keyboard.Press(keys[0]);
            else
                Keyboard.TypeSimultaneously(keys);

            Log.Debug("[PressKeys] Pressed {Keys}", string.Join("+", keys));
            CheckForCaeDialog(session);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[PressKeys]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // ComboBox / List
    // ================================================================

    public override Task<ActionResponse> SelectComboBoxItem(
        SelectItemRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);

            var controlType = element.Properties.ControlType.ValueOrDefault;
            Log.Debug("[SelectComboBoxItem] ControlType={CT} AutomationId={Id} Name={Name}",
                controlType,
                element.Properties.AutomationId.ValueOrDefault,
                element.Properties.Name.ValueOrDefault);

            // ── Path 1: CheckBox / DataGridViewCheckBoxCell ──────────────────
            // DataGridViewCheckBoxCell exposes TogglePattern. Calling AsComboBox().Expand()
            // on a CheckBox throws InvalidOperationException — detect the pattern first.
            // Maps truthy strings ("yes", "true", "checked", "1") → ToggleState.On.
            if (element.Patterns.Toggle.IsSupported)
            {
                var togglePattern = element.Patterns.Toggle.Pattern;
                var wantOn = request.Value.Trim().ToLowerInvariant() is "yes" or "true" or "checked" or "1";
                if (wantOn && togglePattern.ToggleState.ValueOrDefault != FlaUI.Core.Definitions.ToggleState.On)
                    togglePattern.Toggle();
                else if (!wantOn && togglePattern.ToggleState.ValueOrDefault == FlaUI.Core.Definitions.ToggleState.On)
                    togglePattern.Toggle();
                Log.Debug("[SelectComboBoxItem] Toggled checkbox to '{Value}'", request.Value);
                CheckForCaeDialog(session);
                return Task.FromResult(Ok());
            }

            // ── Path 2: ComboBox (ExpandCollapsePattern) ─────────────────────
            if (element.Patterns.ExpandCollapse.IsSupported)
            {
                var combo = element.AsComboBox();

                // cmbPriority is a CnxComboBox (WinForms ComboBox). It is enabled by default but
                // its SelectedIndexChanged resets to -1 if no Rx exists in the order grid.
                // Wait up to 3s for the combo to become enabled before expanding.
                for (int i = 0; i < 6 && !combo.IsEnabled; i++)
                    Thread.Sleep(500);
                if (!combo.IsEnabled)
                    throw new FlaUI.Core.Exceptions.ElementNotEnabledException(
                        $"ComboBox '{element.AutomationId}' is still not enabled after waiting");

                combo.Expand();
                Thread.Sleep(200);

                var item = combo.Items.FirstOrDefault(i =>
                    string.Equals(i.Text, request.Value, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(i.Name, request.Value, StringComparison.OrdinalIgnoreCase));

                if (item == null)
                    throw new InvalidOperationException(
                        $"ComboBox item '{request.Value}' not found. Available: [{string.Join(", ", combo.Items.Select(i => i.Text))}]");

                item.Click();
                Log.Debug("[SelectComboBoxItem] Selected '{Value}'", request.Value);
                CheckForCaeDialog(session);
                return Task.FromResult(Ok());
            }

            // ── Path 3: Unknown control — fall back to plain Click ────────────
            Log.Warning(
                "[SelectComboBoxItem] Element supports neither Toggle nor ExpandCollapse; "
                + "falling back to Click. ControlType={CT}", controlType);
            element.Click();
            CheckForCaeDialog(session);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[SelectComboBoxItem]");
            return Task.FromResult(Fail(ex));
        }
    }

    public override Task<ActionResponse> SelectListItem(
        SelectListItemRequest request, ServerCallContext ctx)
    {
        try
        {
            var session  = _sessions.Get(request.SessionId);
            var element  = session.Cache.Get(request.ElementId);
            var listBox  = element.AsListBox();
            ListBoxItem? item = null;

            if (!string.IsNullOrEmpty(request.Value))
            {
                item = listBox.Items.FirstOrDefault(i =>
                    string.Equals(i.Text, request.Value, StringComparison.OrdinalIgnoreCase));
            }
            else if (request.Index >= 0 && request.Index < listBox.Items.Length)
            {
                item = listBox.Items[request.Index];
            }

            if (item == null)
                throw new InvalidOperationException(
                    $"List item not found (index={request.Index}, value='{request.Value}')");

            item.Select();
            Log.Debug("[SelectListItem] Selected '{Value}' / index {Index}", request.Value, request.Index);
            CheckForCaeDialog(session);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[SelectListItem]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // Popup / Dialog Handling
    // ================================================================

    public override Task<ActionResponse> DismissPopup(
        DismissPopupRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var timeout = request.TimeoutSeconds > 0
                ? TimeSpan.FromSeconds(request.TimeoutSeconds) : TimeSpan.FromSeconds(3);

            var btn = FindPopupButton(
                session, request.ButtonName, request.ButtonAutoId, timeout);

            if (btn == null)
                throw new InvalidOperationException(
                    $"Popup button not found (name='{request.ButtonName}', autoId='{request.ButtonAutoId}')");

            btn.Click();
            Log.Information("[DismissPopup] Clicked '{Btn}'", request.ButtonName);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[DismissPopup]");
            return Task.FromResult(Fail(ex));
        }
    }

        public override Task<HandlePopupResponse> HandlePopup(
            HandlePopupRequest request, ServerCallContext ctx)
        {
            try
            {
                var session = _sessions.Get(request.SessionId);
                var timeout = request.TimeoutSeconds > 0
                    ? TimeSpan.FromSeconds(request.TimeoutSeconds) : TimeSpan.FromSeconds(2);
                var deadline = DateTime.UtcNow.Add(timeout);
                string lastPopupTitle = "";
                string lastMessage = "No matching popup found.";

                do
                {
                    var desktop = session.Auto.GetDesktop();
                    var windows = desktop.FindAllChildren();

                    foreach (var w in windows)
                    {
                        // IsOffscreen / IsEnabled can throw PropertyNotSupportedException
                        // for certain UIA3 elements — skip any that blow up.
                        try
                        {
                            if (w.IsOffscreen || !w.IsEnabled) continue;
                        }
                        catch (FlaUI.Core.Exceptions.PropertyNotSupportedException)
                        {
                            continue;
                        }
                        catch (Exception)
                        {
                            continue;
                        }
                        var title = w.Name ?? "";

                        // If caller specified a title, match it
                        if (!string.IsNullOrEmpty(request.ExpectedTitle) &&
                            !title.Contains(request.ExpectedTitle, StringComparison.OrdinalIgnoreCase))
                            continue;

                        // Look for the action button inside this window
                        var btn = FindButtonInElement(
                            w, request.ActionButton, session.Auto.ConditionFactory);

                        if (btn == null) continue;

                        lastPopupTitle = title;

                        try
                        {
                            btn.Click();
                            Log.Information("[HandlePopup] Dismissed popup '{Title}' via '{Btn}'",
                                title, request.ActionButton);

                            return Task.FromResult(new HandlePopupResponse
                            {
                                PopupFound = true,
                                PopupTitle = title,
                                ActionTaken = true,
                                Message = $"Clicked '{request.ActionButton}' in popup '{title}'"
                            });
                        }
                        catch (FlaUI.Core.Exceptions.NoClickablePointException ex)
                        {
                            lastMessage = $"Popup '{title}' found but button '{request.ActionButton}' was not clickable yet.";
                            Log.Debug(ex, "[HandlePopup] Button '{Btn}' in popup '{Title}' not yet clickable - retrying.",
                                request.ActionButton, title);
                        }
                        catch (Exception ex)
                        {
                            lastMessage = $"Popup '{title}' found but click failed: {ex.Message}";
                            Log.Debug(ex, "[HandlePopup] Click failed for button '{Btn}' in popup '{Title}'.",
                                request.ActionButton, title);
                        }
                    }

                    if (DateTime.UtcNow >= deadline)
                        break;

                    System.Threading.Thread.Sleep(200);
                } while (DateTime.UtcNow <= deadline);

                return Task.FromResult(new HandlePopupResponse
                {
                    PopupFound = !string.IsNullOrEmpty(lastPopupTitle),
                    PopupTitle = lastPopupTitle,
                    ActionTaken = false,
                    Message = lastMessage
                });
            }
            catch (Exception ex)
            {
                Log.Error(ex, "[HandlePopup]");
                return Task.FromResult(new HandlePopupResponse
                {
                    PopupFound = false,
                    Message    = ex.Message
                });
            }
        }

    // ================================================================
    // Drag & Drop
    // ================================================================

    public override Task<ActionResponse> ClickAndDrag(
        ClickAndDragRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var src     = session.Cache.Get(request.SourceElementId);
            var tgt     = session.Cache.Get(request.TargetElementId);

            var srcPt = src.GetClickablePoint();
            var tgtPt = tgt.GetClickablePoint();

            Mouse.MoveTo(srcPt);
            Thread.Sleep(100);
            Mouse.Down(MouseButton.Left);
            Thread.Sleep(200);
            Mouse.MoveTo(tgtPt);
            Thread.Sleep(200);
            Mouse.Up(MouseButton.Left);

            Log.Debug("[ClickAndDrag] {Src} -> {Tgt}", request.SourceElementId, request.TargetElementId);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[ClickAndDrag]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // Window Focus
    // ================================================================

    public override Task<ActionResponse> FocusWindow(
        FocusWindowRequest request, ServerCallContext ctx)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var desktop = session.Auto.GetDesktop();
            var window  = desktop.FindFirstDescendant(
                session.Auto.ConditionFactory.ByName(request.WindowTitle));

            if (window == null)
                throw new InvalidOperationException(
                    $"Window with title containing '{request.WindowTitle}' not found.");

            window.Focus();
            session.MainWindow = window;
            Log.Information("[FocusWindow] Focused '{Title}'", request.WindowTitle);
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[FocusWindow]");
            return Task.FromResult(Fail(ex));
        }
    }

    // ================================================================
    // Health Check
    // ================================================================

    public override Task<PingResponse> Ping(PingRequest request, ServerCallContext ctx)
    {
        var uptime = (long)(DateTime.UtcNow - StartTime).TotalSeconds;
        Log.Debug("[Ping] uptime={Uptime}s, sessions={Count}", uptime, _sessions.ActiveCount);
        return Task.FromResult(new PingResponse
        {
            Alive         = true,
            ServerVersion = "1.0.0",
            UptimeSeconds = uptime
        });
    }

    // ================================================================
    // Private action helpers
    // ================================================================

    private Task<ActionResponse> ElementAction(
        ElementActionRequest request, Action<AutomationElement> action)
    {
        try
        {
            var session = _sessions.Get(request.SessionId);
            var element = session.Cache.Get(request.ElementId);
            action(element);
            CheckForCaeDialog(session);   // fail fast if Connexus Application Error appeared
            return Task.FromResult(Ok());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[ElementAction] {Id}", request.ElementId);
            return Task.FromResult(Fail(ex));
        }
    }

    /// <summary>
    /// Scans desktop-level modal/topmost windows for a Connexus Application Error dialog.
    /// If found: dismisses it (click OK) so it doesn't block the next step, then throws
    /// so the calling action fails immediately at the correct test step.
    /// Non-error popups and scan failures are ignored silently.
    /// </summary>
    private void CheckForCaeDialog(AutomationSession session)
    {
        try
        {
            var cf = session.Auto.ConditionFactory;

            // Modal dialogs appear as desktop-level top-level windows, not as main-window children.
            // Filtering by ControlType.Window avoids scanning toolbar/panel elements inside the app.
            var windows = session.Auto.GetDesktop().FindAllChildren(cf.ByControlType(ControlType.Window));
            foreach (var win in windows)
            {
                try { if (win.IsOffscreen || !win.IsEnabled) continue; }
                catch (Exception propEx) { Log.Debug(propEx, "[CAE] Property read failed, skipping window"); continue; }

                // Only dismiss dialog-like windows — modal or topmost — to avoid corrupting normal UI flows.
                var isLikelyDialog = win.Patterns.Window.IsSupported
                    && (win.Patterns.Window.Pattern.IsModal.ValueOrDefault
                        || win.Patterns.Window.Pattern.IsTopmost.ValueOrDefault);
                if (!isLikelyDialog) continue;

                var title = win.Name ?? "";
                if (!title.Contains("Error", StringComparison.OrdinalIgnoreCase)) continue;

                var btn = win.FindFirstDescendant(cf.ByControlType(ControlType.Button).And(cf.ByName("OK")))
                       ?? win.FindFirstDescendant(cf.ByControlType(ControlType.Button).And(cf.ByName("Close")));
                if (btn == null) continue;

                try { btn.Click(); }
                catch (Exception clickEx) { Log.Debug(clickEx, "[CAE] Dismiss click failed — dialog may have already closed"); }
                Log.Error("[CAE] Connexus Application Error detected: '{Title}' — failing step", title);
                throw new InvalidOperationException($"Connexus Application Error: '{title}'");
            }
        }
        catch (InvalidOperationException) { throw; }
        catch (Exception scanEx) { Log.Debug(scanEx, "[CAE] Modal scan failed — ignored"); }
    }

    private static AutomationElement? FindButtonInElement(
        AutomationElement root,
        string buttonNameOrId,
        FlaUI.Core.Conditions.ConditionFactory cf)
    {
        // Try by Name first
        var btn = root.FindFirstDescendant(cf.ByName(buttonNameOrId))
                  ?? root.FindFirstDescendant(cf.ByAutomationId(buttonNameOrId));
        return btn;
    }

    private AutomationElement? FindPopupButton(
        AutomationSession session, string name, string autoId, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow.Add(timeout);
        while (DateTime.UtcNow < deadline)
        {
            var root = session.MainWindow ?? session.Auto.GetDesktop();

            if (!string.IsNullOrEmpty(name))
            {
                var btn = root.FindFirstDescendant(
                    session.Auto.ConditionFactory.ByName(name));
                if (btn != null) return btn;
            }

            if (!string.IsNullOrEmpty(autoId))
            {
                var btn = root.FindFirstDescendant(
                    session.Auto.ConditionFactory.ByAutomationId(autoId));
                if (btn != null) return btn;
            }

            Thread.Sleep(300);
        }
        return null;
    }

    // ================================================================
    // Private Keyboard Helpers
    // ================================================================

    /// <summary>
    /// Sends Ctrl+A to select all text in the currently focused control.
    /// Encapsulates the Win32 VirtualKeyShort constant noise so call sites
    /// say what they mean instead of spelling out key codes.
    /// </summary>
    private static void KeyboardSelectAll()
    {
        Keyboard.TypeSimultaneously(CONTROL, KEY_A);
        Thread.Sleep(50); // allow WM_KEYDOWN to process before next keystroke
    }

    /// <summary>
    /// Sends Delete and waits for the Win32 message pump to process it.
    /// Used in the keyboard-clear fallback path where ValuePattern is not
    /// supported — no observable field state to poll instead of sleeping.
    /// </summary>
    private static void KeyboardDelete()
    {
        Keyboard.Type(DELETE);
        Thread.Sleep(50); // allow WM_KEYDOWN to process before next keystroke
    }
}
