using System.Collections.Concurrent;
using FlaUI.Core.AutomationElements;

namespace FlaUIgRPC.Server.Core;

/// <summary>
/// Caches found AutomationElements on the server side and returns
/// lightweight string IDs that cross the gRPC wire to the Java client.
/// Java never sees real FlaUI objects — only "elem-1", "elem-2" etc.
/// Thread-safe via ConcurrentDictionary.
/// </summary>
public sealed class ElementCache
{
    private readonly ConcurrentDictionary<string, AutomationElement> _cache = new();
    private int _counter;

    /// <summary>Store an element and return its new ID.</summary>
    public string Store(AutomationElement element)
    {
        var id = $"elem-{Interlocked.Increment(ref _counter)}";
        _cache[id] = element;
        return id;
    }

    /// <summary>Retrieve a cached element by ID. Throws if not found.</summary>
    public AutomationElement Get(string elementId)
    {
        if (_cache.TryGetValue(elementId, out var element))
            return element;
        throw new KeyNotFoundException($"Element '{elementId}' not found in cache. It may have expired.");
    }

    /// <summary>Try to retrieve a cached element without throwing.</summary>
    public bool TryGet(string elementId, out AutomationElement? element)
        => _cache.TryGetValue(elementId, out element);

    /// <summary>Remove an element from the cache.</summary>
    public void Remove(string elementId) => _cache.TryRemove(elementId, out _);

    /// <summary>Clear all cached elements (called on session close).</summary>
    public void Clear() => _cache.Clear();

    public int Count => _cache.Count;
}
