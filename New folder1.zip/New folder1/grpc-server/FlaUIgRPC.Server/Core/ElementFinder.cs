using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Conditions;
using FlaUI.Core.Definitions;
using FlaUIgRPC.Server.Protos;
using Serilog;

namespace FlaUIgRPC.Server.Core;

/// <summary>
/// Converts gRPC LocatorStrategy + value into FlaUI search conditions
/// and executes the search against the element tree.
/// Supports optional parent scope and configurable wait timeout.
/// </summary>
public sealed class ElementFinder
{
    private readonly AutomationBase _automation;

    private const int DefaultTimeoutMs = 10_000;
    private const int RetryIntervalMs  = 250;

    public ElementFinder(AutomationBase automation)
    {
        _automation = automation;
    }

    /// <summary>
    /// Find a single element, retrying until timeout expires.
    /// </summary>
    public AutomationElement? FindElement(
        AutomationElement root,
        LocatorStrategy strategy,
        string value,
        int timeoutMs = 0)
    {
        int effectiveTimeout = timeoutMs > 0 ? timeoutMs : DefaultTimeoutMs;
        var deadline = DateTime.UtcNow.AddMilliseconds(effectiveTimeout);

        AutomationElement? found = null;
        while (DateTime.UtcNow < deadline)
        {
            found = FindSingle(root, strategy, value);
            if (found != null) return found;
            Thread.Sleep(RetryIntervalMs);
        }

        Log.Debug("[ElementFinder] Not found: {Strategy}='{Value}' after {Ms}ms",
            strategy, value, effectiveTimeout);
        return null;
    }

    /// <summary>
    /// Find all elements matching the locator (no retry).
    /// </summary>
    public AutomationElement[] FindElements(
        AutomationElement root,
        LocatorStrategy strategy,
        string value)
    {
        var cf = _automation.ConditionFactory;
        ConditionBase? cond = BuildCondition(cf, strategy, value);
        if (cond == null) return [];
        return root.FindAllDescendants(cond);
    }

    // ----------------------------------------------------------------
    // Private helpers
    // ----------------------------------------------------------------

    private AutomationElement? FindSingle(AutomationElement root, LocatorStrategy strategy, string value)
    {
        try
        {
            if (strategy == LocatorStrategy.Xpath)
            {
                var result = root.FindFirstByXPath(value);

                // Fallback for leaf nodes (e.g. WinForms Labels in Connexus):
                // .//*[predicate] only searches descendants — if the matching text
                // IS the root element's own Name property (leaf node, no children),
                // the XPath finds nothing. Re-try with .[predicate] (self-axis)
                // so the root element itself is also evaluated.
                if (result == null && value.StartsWith(".//*[", StringComparison.Ordinal))
                {
                    string selfXPath = ".[" + value.Substring(5); // ".//*[..." → ".[..."
                    Log.Debug("[ElementFinder] Descendant XPath found nothing, trying self-node: {XPath}", selfXPath);
                    result = root.FindFirstByXPath(selfXPath);
                }

                return result;
            }

            var cf = _automation.ConditionFactory;

            // AccessibilityId mirrors WinAppDriver behaviour:
            // WinAppDriver checks AutomationId first, then falls back to UIA Name
            // (WinForms AccessibleName → UIA Name, not AutomationId).
            // Pure ByAutomationId misses controls whose .AccessibleName = value
            // but whose WinForms .Name property is something else entirely.
            if (strategy == LocatorStrategy.AccessibilityId)
            {
                var byId = root.FindFirstDescendant(cf.ByAutomationId(value));
                if (byId != null) return byId;

                Log.Debug("[ElementFinder] AccessibilityId='{Value}' not found by AutomationId, trying Name", value);
                return root.FindFirstDescendant(cf.ByName(value));
            }

            var cond = BuildCondition(cf, strategy, value);
            return cond == null ? null : root.FindFirstDescendant(cond);
        }
        catch (Exception ex)
        {
            Log.Debug("[ElementFinder] FindSingle error: {Msg}", ex.Message);
            return null;
        }
    }

    private static ConditionBase? BuildCondition(ConditionFactory cf, LocatorStrategy strategy, string value)
        => strategy switch
        {
            LocatorStrategy.AccessibilityId  => cf.ByAutomationId(value),
            LocatorStrategy.AutomationId     => cf.ByAutomationId(value),
            LocatorStrategy.Id               => cf.ByAutomationId(value),
            LocatorStrategy.Name             => cf.ByName(value),
            LocatorStrategy.ClassName        => cf.ByClassName(value),
            LocatorStrategy.TagName          => BuildControlTypeCondition(cf, value),
            _                                => null
        };

    private static ConditionBase BuildControlTypeCondition(ConditionFactory cf, string typeName)
    {
        if (Enum.TryParse<ControlType>(typeName, ignoreCase: true, out var ct))
            return cf.ByControlType(ct);
        // Default to custom / unknown — won't match anything meaningful
        return cf.ByControlType(ControlType.Custom);
    }
}
