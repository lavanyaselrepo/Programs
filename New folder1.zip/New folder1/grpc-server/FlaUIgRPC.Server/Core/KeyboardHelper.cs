using FlaUI.Core.WindowsAPI;
using Serilog;

namespace FlaUIgRPC.Server.Core;

/// <summary>
/// Maps Java KeyEvent VK_ codes to FlaUI VirtualKeyShort enum values.
/// Java uses java.awt.event.KeyEvent constants; Windows uses VK_ codes.
/// Most VK codes match numerically, but a few have naming differences.
/// </summary>
public static class KeyboardHelper
{
    /// <summary>
    /// Convert a Java VK_ key code to the FlaUI VirtualKeyShort enum.
    /// Returns null if no mapping exists.
    /// </summary>
    public static VirtualKeyShort? ToVirtualKey(int javaKeyCode)
    {
        // Explicit remaps where Java != Windows naming
        VirtualKeyShort? mapped = javaKeyCode switch
        {
            0x08 => VirtualKeyShort.BACK,          // VK_BACK_SPACE
            0x09 => VirtualKeyShort.TAB,
            0x0A => VirtualKeyShort.RETURN,        // Java VK_ENTER
            0x0D => VirtualKeyShort.RETURN,        // Windows VK_RETURN
            0x10 => VirtualKeyShort.SHIFT,
            0x11 => VirtualKeyShort.CONTROL,
            0x12 => VirtualKeyShort.ALT,           // Java VK_ALT (Windows MENU=0x12)
            0x13 => VirtualKeyShort.PAUSE,
            0x14 => VirtualKeyShort.CAPITAL,       // CAPS_LOCK
            0x1B => VirtualKeyShort.ESCAPE,
            0x20 => VirtualKeyShort.SPACE,
            0x21 => VirtualKeyShort.PRIOR,         // PAGE_UP
            0x22 => VirtualKeyShort.NEXT,          // PAGE_DOWN
            0x23 => VirtualKeyShort.END,
            0x24 => VirtualKeyShort.HOME,
            0x25 => VirtualKeyShort.LEFT,
            0x26 => VirtualKeyShort.UP,
            0x27 => VirtualKeyShort.RIGHT,
            0x28 => VirtualKeyShort.DOWN,
            0x2C => VirtualKeyShort.SNAPSHOT,      // PRINT_SCREEN
            0x2D => VirtualKeyShort.INSERT,
            0x2E => VirtualKeyShort.DELETE,
            // Function keys
            0x70 => VirtualKeyShort.F1,
            0x71 => VirtualKeyShort.F2,
            0x72 => VirtualKeyShort.F3,
            0x73 => VirtualKeyShort.F4,
            0x74 => VirtualKeyShort.F5,
            0x75 => VirtualKeyShort.F6,
            0x76 => VirtualKeyShort.F7,
            0x77 => VirtualKeyShort.F8,
            0x78 => VirtualKeyShort.F9,
            0x79 => VirtualKeyShort.F10,
            0x7A => VirtualKeyShort.F11,
            0x7B => VirtualKeyShort.F12,
            // Numpad
            0x60 => VirtualKeyShort.NUMPAD0,
            0x61 => VirtualKeyShort.NUMPAD1,
            0x62 => VirtualKeyShort.NUMPAD2,
            0x63 => VirtualKeyShort.NUMPAD3,
            0x64 => VirtualKeyShort.NUMPAD4,
            0x65 => VirtualKeyShort.NUMPAD5,
            0x66 => VirtualKeyShort.NUMPAD6,
            0x67 => VirtualKeyShort.NUMPAD7,
            0x68 => VirtualKeyShort.NUMPAD8,
            0x69 => VirtualKeyShort.NUMPAD9,
            _    => null
        };

        if (mapped.HasValue) return mapped;

        // For ASCII printable keys (A-Z, 0-9), the VK code matches directly
        if (Enum.IsDefined(typeof(VirtualKeyShort), (short)javaKeyCode))
            return (VirtualKeyShort)javaKeyCode;

        Log.Warning("[KeyboardHelper] No VirtualKeyShort mapping for Java VK code 0x{Code:X2}", javaKeyCode);
        return null;
    }

    /// <summary>Convert a list of Java key codes, skipping unmapped ones.</summary>
    public static IEnumerable<VirtualKeyShort> ToVirtualKeys(IEnumerable<int> javaCodes)
        => javaCodes
            .Select(ToVirtualKey)
            .Where(k => k.HasValue)
            .Select(k => k!.Value);
}
