using System.Collections.Concurrent;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.UIA3;
using Serilog;

namespace FlaUIgRPC.Server.Core;

/// <summary>
/// Each gRPC session owns its own UIA3Automation + optional Application reference
/// + a window root + an ElementCache.
/// Thread-safe via ConcurrentDictionary.
/// </summary>
public sealed class AutomationSession : IDisposable
{
    public string SessionId      { get; }
    public UIA3Automation Auto   { get; }
    public Application? App      { get; set; }
    public AutomationElement? MainWindow { get; set; }
    public ElementCache Cache    { get; } = new();
    public ElementFinder Finder  { get; }
    public DateTime CreatedAt    { get; } = DateTime.UtcNow;

    public AutomationSession(string sessionId)
    {
        SessionId = sessionId;
        Auto      = new UIA3Automation();
        Finder    = new ElementFinder(Auto);
    }

    public void Dispose()
    {
        Cache.Clear();
        try { App?.Close(); } catch { /* best effort */ }
        try { App?.Dispose(); } catch { /* best effort */ }
        try { Auto.Dispose(); } catch { /* best effort */ }
    }
}

/// <summary>
/// Manages the lifecycle of all active gRPC sessions.
/// Singleton — shared across all gRPC service calls.
/// </summary>
public sealed class SessionManager
{
    private readonly ConcurrentDictionary<string, AutomationSession> _sessions = new();
    private static int _counter;

    public AutomationSession Create()
    {
        var id      = $"session-{Interlocked.Increment(ref _counter):x4}";
        var session = new AutomationSession(id);
        _sessions[id] = session;
        Log.Information("[SessionManager] Created session {Id}", id);
        return session;
    }

    public AutomationSession Get(string sessionId)
    {
        if (_sessions.TryGetValue(sessionId, out var session))
            return session;
        throw new KeyNotFoundException($"Session '{sessionId}' not found. Was it already closed?");
    }

    public bool TryGet(string sessionId, out AutomationSession? session)
        => _sessions.TryGetValue(sessionId, out session);

    public void Close(string sessionId)
    {
        if (_sessions.TryRemove(sessionId, out var session))
        {
            session.Dispose();
            Log.Information("[SessionManager] Closed session {Id}", sessionId);
        }
        else
        {
            Log.Warning("[SessionManager] Close called for unknown session {Id}", sessionId);
        }
    }

    public void CloseAll()
    {
        foreach (var id in _sessions.Keys.ToList())
            Close(id);
    }

    public int ActiveCount => _sessions.Count;
}
