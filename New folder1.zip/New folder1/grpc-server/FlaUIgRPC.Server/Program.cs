using Serilog;
using Serilog.Events;
using FlaUIgRPC.Server.Services;

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
    .MinimumLevel.Override("Grpc", LogEventLevel.Warning)
    .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
    .WriteTo.File(
        path: "C:\\FlaUIgRPC\\logs\\flaui-grpc-.log",
        rollingInterval: RollingInterval.Day,
        outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}"
    )
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();

// Parse optional port from CLI arg: FlaUIgRPC.Server.exe 50052
int port = 50051;
if (args.Length > 0 && int.TryParse(args[0], out int argPort))
    port = argPort;

builder.WebHost.ConfigureKestrel(opts =>
{
    opts.ListenAnyIP(port, lo => lo.Protocols = Microsoft.AspNetCore.Server.Kestrel.Core.HttpProtocols.Http2);
});

// SessionManager MUST be a singleton — it holds the session dictionary shared
// across all gRPC calls. Without this, each RPC call gets a fresh instance and
// sessions created in CreateSession are invisible to FindElement. (KeyNotFoundException fix)
builder.Services.AddSingleton<FlaUIgRPC.Server.Core.SessionManager>();

builder.Services.AddGrpc(opts =>
{
    opts.MaxReceiveMessageSize = 64 * 1024 * 1024;  // 64 MB — for large screenshots
    opts.MaxSendMessageSize    = 64 * 1024 * 1024;
    opts.EnableDetailedErrors  = true;
});

var app = builder.Build();
app.MapGrpcService<FlaUIAutomationServiceImpl>();

var startTime = DateTime.UtcNow;
Log.Information("");
Log.Information("========================================");
Log.Information("  FlaUI gRPC Server v1.0.0");
Log.Information("  Listening on: http://0.0.0.0:{Port} (all interfaces)", port);
Log.Information("  Protocol: HTTP/2 (gRPC)");
Log.Information("  FlaUI: UIA3 Automation Framework");
Log.Information("  Started: {Time:u}", startTime);
Log.Information("========================================");
Log.Information("");

app.Run();
