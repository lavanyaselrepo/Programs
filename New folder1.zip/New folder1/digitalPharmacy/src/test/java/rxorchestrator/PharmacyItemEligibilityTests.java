package rxorchestrator;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemEligibilityRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class PharmacyItemEligibilityTests {
    private static final Logger logger = LoggerFactory.getLogger(PharmacyItemEligibilityTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    private String cid;
    private List<InputResponse> eodRxs;
    private String ELIGIBILITY_TYPE = "CHECKOUT";
    private String ELIGIBILITY_TYPE_ADD_TO_CART = "ADD_TO_CART";
    private String INVALID_ELIGIBILITY_TYPE = "CHECK";
    HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs;

    private String DOMAIN_ID = "WM-PHARMACY";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;

    AutomationManager am = AutomationManager.getInstance();

    private Integer patientId;

    /**
     * Sequence of API call for Pharmacy Item Eligibility Flow*
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * create eod rxs*
     * create cancelled rxs*
     * delete created patient and rxs*
     * @throws IOException
     */
    @BeforeClass
    void setContext(){
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        Reporter.logJSON("Logs before rxpdUtils object creation: ", "Start Logs");
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        Reporter.logJSON("Logs before createDigitalPharmacyConnectedStorePatientAccount() method call: ", patientEmailId);
        rxpdUtils.testAccountCreation();
        Reporter.logJSON("Logs after createDigitalPharmacyConnectedStorePatientAccount() method call: ", patientEmailId);
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        Reporter.logJSON("Logs after getStorePatientIdFromCPR() method call", patientId);
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        Reporter.logJSON("Logs after rfpgen() method call: ", rfpRxs);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        Reporter.logJSON("Logs after getCidFromEmail() method call: ", cid);
        logger.info("Pharmacy Item Eligibility cid: " + cid);
        Reporter.logJSON("Pharmacy Item Eligibility cid: ", cid);
        am.performSleep(180);
    }

    @Test(enabled = true, priority = 1, description = "Pharmacy Item Eligibility success response")
    void Pharmacy_Item_Eligibility_RFP_Rxs_Success_Response() throws IOException {
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemEligibility Request: " + pharmacyItemEligibilityRequest);
        Reporter.logJSON("PharmacyItemEligibility Request: ", pharmacyItemEligibilityRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest, ELIGIBILITY_TYPE, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(200, itemEligibilityResponse.code());
        Assert.assertNotNull(itemEligibilityResponse.body().getPayload());
        Assert.assertNotNull(itemEligibilityResponse.body().getPayload().getFills().get(0).getPRefId());
    }

    @Test(enabled = true, priority = 2, description = "Pharmacy Item Eligibility success response")
    void Pharmacy_Item_Eligibility_EOD_Rxs_Success_Response() throws IOException {

        eodRxs = rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, 1);
        am.performSleep(90);
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(eodRxs, STORE_NBR);
        logger.info("PharmacyItemEligibility Request: " + pharmacyItemEligibilityRequest);
        Reporter.logJSON("PharmacyItemEligibility Request: ", pharmacyItemEligibilityRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest, ELIGIBILITY_TYPE, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(200, itemEligibilityResponse.code());
        Assert.assertNotNull(itemEligibilityResponse.body().getPayload());
    }

    @Test(enabled = true, priority = 3, description = "Pharmacy Item Eligibility success response")
    void Pharmacy_Item_Eligibility_Cancelled_Rxs_Success_Response() throws IOException {
        cancelledRxs = rxpdUtils.cancelledGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(300);
        List<String> pRefIds = rxpdUtils.getPRefIds(cancelledRxs, STORE_NBR);
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = new PharmacyItemEligibilityRequest();
        pharmacyItemEligibilityRequest.setPRefIds(pRefIds);
        logger.info("PharmacyItemEligibility Request for cancelled state: " + pharmacyItemEligibilityRequest);
        Reporter.logJSON("PharmacyItemEligibility Request for cancelled state: ", pharmacyItemEligibilityRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest, ELIGIBILITY_TYPE, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(200, itemEligibilityResponse.code());
        Assert.assertNotNull(itemEligibilityResponse.body().getPayload());
    }

    @Test(enabled = true, priority = 4, description = "Pharmacy Item Eligibility API eligibilityType as null")
    void Pharmacy_Item_eligibility_Null_Query_Param() throws IOException {
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(rfpRxs, STORE_NBR);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest,
                null, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(400, itemEligibilityResponse.code());
    }

    @Test(enabled = true, priority = 5, description = "Pharmacy Item Eligibility API invalid eligibilityType")
    void Pharmacy_Item_eligibility_Invalid_Query_Param() throws IOException {
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(rfpRxs, STORE_NBR);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest,
                INVALID_ELIGIBILITY_TYPE, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(400, itemEligibilityResponse.code());
    }

    @Test(enabled = true, priority = 6, description = "Pharmacy Item Eligibility failure response")
    void Pharmacy_Item_InEligibility_Downtime() throws IOException {


        System.out.println("the rxFillId is " + rfpRxs.get(0).getRxFillId());
        int returnStatus = rxpdUtils.enableTPDowntime(STORE_NBR,rfpRxs.get(0).getRxFillId());
        Assert.assertEquals(1,returnStatus);
        am.performSleep(90);
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(rfpRxs, STORE_NBR);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> itemEligibilityResponse = rxOrchestratorRetrofit.
                getPharmacyItemEligibilityResponse(cid, pharmacyItemEligibilityRequest,
                        ELIGIBILITY_TYPE_ADD_TO_CART, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertFalse(itemEligibilityResponse.body().getPayload().getFills().get(0).getCheckoutEligibility().isEligible());
        Assert.assertEquals(200, itemEligibilityResponse.code());
        Assert.assertNotNull(itemEligibilityResponse.body().getPayload());
    }

    /**
     * Method to delete patient and rx from informix*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, eodRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, cancelledRxs, patientId);
    }

}
