package rxorchestrator.lookupbyrxv2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.CustomerPrescriptionsV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.LookUpRxRequestV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionV2;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper.*;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.reqTrackingString;


/**
 * Test class for validating insurance coverage scenarios in RxOrchestrator V2.
 *
 * Covered test cases:
 * <ul>
 *   <li>Coverage not modified: Replacement link inactive, replaced insurance active/inactive, primary insurance present/not present, last applied insurance active/inactive.</li>
 *   <li>Coverage modified to default: Replacement link inactive, replaced insurance active/inactive, primary insurance present and active, last applied insurance inactive.</li>
 *   <li>Coverage modified: Replacement link active, replaced insurance active, primary insurance not present, last applied insurance active/inactive.</li>
 *   <li>Coverage modified to cash: All insurances inactive, replacement link inactive/active, last applied insurance inactive.</li>
 *   <li>Coverage modified to default: Replacement link active, replaced insurance inactive, primary insurance present and active, last applied insurance inactive.</li>
 * </ul>
 * Each test simulates different combinations of insurance status, replacement links, and prescription coverage to ensure correct coverage determination.
 *
 * Not Covered
 *
 * 1.  Split bill as currently CNX do not support split bill while placing order
 * 2.  Discount or Coupon card
 */
public class LookupByRxV2SingleInsuranceTests {

    InsuranceWrapper insuranceWrapper;
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    RxOrchestratorRetrofit rxOrchestratorRetrofit;

    ObjectMapper objectMapper = new ObjectMapper();
    List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = new ArrayList<>();
    HashMap<Integer,List<InputResponse>> patientIdAndRxsToBeDeleted = new HashMap<>();
    WrapperUtils wrapperUtils=new WrapperUtils();
    AutomationManager am = AutomationManager.getInstance();
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    LookupByRxV2Helper lookupByRxV2Helper = new LookupByRxV2Helper();

    private List<InputResponse> rfpRxs = new ArrayList<>();
    private String cid;
    private Integer patientId;
    private String patientEmailId;
    private String patientFirstName;
    private String patientLastName;
    private String PHONE_NO;
    private String ZIPCODE;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;

    private int groupId;

    // Insurance related information
    // First Insurance
    public static final String CARDHOLDER_ID_1 = "WBR120";
    public static final Integer CARRIER_ID_1 = 100426;
    public static final Integer PLAN_ID_1 = 171;
    public static final String INS_PLAN_TYPE_CODE_1 = "1003";
    public static final String RELATIONSHIP_CODE_1="3201";
    public static final String BILLING_GROUP_NBR_1 = "1626281726";

    // Second Insurance

    public static final String CARDHOLDER_ID_2 = "248201700";
    public static final Integer CARRIER_ID_2 = 121312;
    public static final Integer PLAN_ID_2 = 120;
    public static final String INS_PLAN_TYPE_CODE_2 = "1002";
    public static final String RELATIONSHIP_CODE_2="3201";
    public static final String BILLING_GROUP_NBR_2 = "1626281726";

    // Third Insurance

    public static final String CARDHOLDER_ID_3 = "WBR125";
    public static final Integer CARRIER_ID_3 = 123495;
    public static final Integer PLAN_ID_3 = 179;
    public static final String INS_PLAN_TYPE_CODE_3 = "1003";
    public static final String RELATIONSHIP_CODE_3="3201";
    public static final String BILLING_GROUP_NBR_3 = "1626281726";

    public static final String CARDHOLDER_ID_B1_SUFFIX = "27823";

    /**
     * Initializes API manager and service wrapper instances required for RxOrchestrator V2 tests.
     * Sets up dependencies for digital pharmacy, insurance, Rx orchestrator, and CPR patient update operations.
     */
    @BeforeClass
    @Parameters({"groupId"})
    void setContext(@org.testng.annotations.Optional("0") int groupId){
        this.groupId = groupId;
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        insuranceWrapper = new InsuranceWrapper();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    }

    // No Replacement Cases
    @Test(priority = 1, description = "Rx with last fill paid with Insurance (Ins 1)  and primary insurance present (Ins 1) and no replacement")
    public void test_RxWithCoverageNotModified_ReplacementNull_PrimaryActive_LastAppliedActive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_1,CARRIER_ID_1,CARDHOLDER_ID_1,Integer.parseInt(INS_PLAN_TYPE_CODE_1), Integer.parseInt(RELATIONSHIP_CODE_1));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 -Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(),patientId.toString(),patientFirstName,patientLastName,DOB,PHONE_NO,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED);
    }


    @Test(priority = 2, description = "Rx with last fill paid with Insurance (Ins 1)  and primary insurance present with is different (Ins 2)  and last insurance (Ins 1) is inactive")
    public void test_RxWithCoverageModifiedToDefault_ReplacementNull_PrimaryDifferentActive_LastAppliedInActive() throws IOException, InterruptedException {
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        // Step - 1 Inactive last insurance used in Rx and add new primary insurance
        try {

            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoRemoved = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"N",BILLING_GROUP_NBR_1,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newPatientPrimaryInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"Y",BILLING_GROUP_NBR_2,"1");
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceInfoRemoved);
            patientInsuranceInfoList.add(newPatientPrimaryInsuranceInfo);
            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);

    }

    @Test(priority = 3, description = "Rx with last fill paid with Insurance (Ins 1) Inactive and primary insurance not present ")
    public void test_RxWithCoverageModifiedToCash_ReplacementNull_PrimaryNotPresent_LastAppliedInactive() throws IOException, InterruptedException {
        // Step - 1 Inactive last insurance used in Rx and add new primary insurance
        try {

            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoRemoved = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"N",BILLING_GROUP_NBR_1,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientPrimaryInsuranceInfoRemoved = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"1");
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceInfoRemoved);
            patientInsuranceInfoList.add(patientPrimaryInsuranceInfoRemoved);
            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 2 -  Call Look up By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 3 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);

    }

    // Replacement link is active but replaced insurance is Inactive cases
    @Test(priority = 4, description = "Rx with last fill paid with Insurance (Ins 2) Active, primary insurance not present, Replacement active (Ins 2 -> Ins 3) but replaced insurance is inactive")
    public void test_RxWithCoverageNotModified_ReplacedInactive_PrimaryNotPresent_LastAppliedActive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Replace Insurance in CPR and make replaced insurance as inactive

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"Y",BILLING_GROUP_NBR_2,"2");
        CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");
        patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
        patientInsuranceInfoList.add(patientInsuranceInfoToReplace);

        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);
    }


    @Test(priority = 5, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance present (Ins 1) Active, Replacement active (Ins 2 -> Ins 3) but replaced insurance is inactive")
    public void test_RxWithCoverageModifiedToDefault_ReplacedInActive_PrimaryIsPresentActive_LastAppliedInactive() throws IOException, InterruptedException {
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        // Step - 1 Inactive last insurance used in Rx and add new primary insurance
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"Y",BILLING_GROUP_NBR_1,"1");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurancePrimary);
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);

    }

    @Test(priority = 6, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance present (Ins 1) Inactive, Replacement active (Ins 2 -> Ins 3) but replaced insurance is inactive")
    public void test_RxWithCoverageModifiedToCash_ReplacedInActive_PrimaryIsPresentInActive_LastAppliedInactive() throws IOException, InterruptedException {
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        // Step - 1 Make primary Insurance Inactive
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"N",BILLING_GROUP_NBR_1,"1");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurancePrimary);
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);

    }

    // Replacement link is active and replaced insurance is active cases

    @Test(priority = 7, description = "Rx with last fill paid with Insurance (Ins 2) Active, primary insurance not present, Replacement active (Ins 2 -> Ins 3) but replaced insurance is active")
    public void test_RxWithCoverageModified_ReplacedActive_PrimaryNotPresent_LastAppliedActive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Replace Insurance in CPR and make replaced insurance as Active

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"Y",BILLING_GROUP_NBR_2,"2");
        CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");
        patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
        patientInsuranceInfoList.add(patientInsuranceInfoToReplace);

        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);
    }


    @Test(priority = 8, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance not present, Replacement active (Ins 2 -> Ins 3) but replaced insurance is active")
    public void test_RxWithCoverageModified_ReplacedActive_PrimaryNotPresentActive_LastAppliedInactive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance 2
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Make last insurance used in Rx inactive and add replacement insurance active
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 4 - Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);

    }

    @Test(priority = 9, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance present (Ins 1) Active, Replacement active (Ins 2 -> Ins 3) but replaced insurance is also active")
    public void test_RxWithCoverageModified_ReplacedActive_PrimaryIsPresentActive_LastAppliedInactive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance 2
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Add primary Insurance active and last fill insurance is Inactive
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"Y",BILLING_GROUP_NBR_1,"1");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurancePrimary);
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"Y",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 4 - Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);

    }

    // Replacement link is inactive cases and replaced insurance is also inactive

    @Test(priority = 10, description = "Rx with last fill paid with Insurance (Ins 2) Active, primary insurance not present, Replacement InActive (Ins 2 -> Ins 3) but replaced insurance is also InActive")
    public void test_RxWithCoverageNotModified_ReplacementLinkInActive_ReplacedInsIsInActive_PrimaryNotPresent_LastAppliedActive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Replace Insurance in CPR and make replaced insurance as InActive and replacement link is also inactive

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"Y",BILLING_GROUP_NBR_2,"2");
        CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");
        patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
        patientInsuranceInfoList.add(patientInsuranceInfoToReplace);

        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED);
    }


    @Test(priority = 11, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance not present, Replacement Inactive (Ins 2 -> Ins 3) and replaced insurance is also Inactive")
    public void test_RxWithCoverageModifiedToCash_ReplacementLinkInActive_ReplacedInsIsInActive_PrimaryNotPresent_LastAppliedInactive() throws IOException, InterruptedException {
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        // Step - 1 Inactive last insurance used in Rx
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);

    }

    @Test(priority = 12, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance present (Ins 1) Active, Replacement Inactive (Ins 2 -> Ins 3) but replaced insurance is also Inactive")
    public void test_RxWithCoverageModifiedToDefault_ReplacementLinkInActive_ReplacedInsIsActive_PrimaryIsPresentActive_LastAppliedInactive() throws IOException, InterruptedException {
        // Step - 1 Add primary Insurance active and last fill insurance is Inactive
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"Y",BILLING_GROUP_NBR_1,"1");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"N",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurancePrimary);
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);

    }

    // Replacement link is inactive cases and replaced insurance is active

    @Test(priority = 13, description = "Rx with last fill paid with Insurance (Ins 2) Active, primary insurance not present, Replacement InActive (Ins 2 -> Ins 3) but replaced insurance is Active")
    public void test_RxWithCoverageNotModified_ReplacementLinkInActive_ReplacedInsIsActive_PrimaryNotPresent_LastAppliedActive() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId,patientFirstName,patientLastName,DOB,STORE_NBR.toString(),PLAN_ID_2,CARRIER_ID_2,CARDHOLDER_ID_2,Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Replace Insurance in CPR and make replaced insurance as InActive and replacement link is also inactive

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"Y",BILLING_GROUP_NBR_2,"2");
        CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");
        patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
        patientInsuranceInfoList.add(patientInsuranceInfoToReplace);

        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED);
    }


    @Test(priority = 14, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance not present, Replacement Inactive (Ins 2 -> Ins 3) and replaced insurance is active")
    public void test_RxWithCoverageModifiedToCash_ReplacementInActive_ReplacedInsIsActive_PrimaryNotPresent_LastAppliedInactive() throws IOException, InterruptedException {
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        // Step - 1 Inactive last insurance used in Rx
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_CASH);

    }

    @Test(priority = 15, description = "Rx with last fill paid with Insurance (Ins 2) InActive, primary insurance present (Ins 1) Active, Replacement Inactive (Ins 2 -> Ins 3) but replaced insurance is active")
    public void test_RxWithCoverageModifiedToDefault_ReplacementLinkInactive_ReplacedInsIsActive_PrimaryIsPresentActive_LastAppliedInactive() throws IOException, InterruptedException {
        // Step - 1 Add primary Insurance active and last fill insurance is Inactive
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"Y",BILLING_GROUP_NBR_1,"1");
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoToReplace = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_2,CARRIER_ID_2.toString(),PLAN_ID_2.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_2,INS_PLAN_TYPE_CODE_2,"N",BILLING_GROUP_NBR_2,"2");
            CPRUpdatePatientRequest.PatientInsuranceInfo newReplacedPatientInsuranceInfo = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_3,CARRIER_ID_3.toString(),PLAN_ID_3.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_3,INS_PLAN_TYPE_CODE_3,"Y",BILLING_GROUP_NBR_3,"3");

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurancePrimary);
            patientInsuranceInfoList.add(patientInsuranceInfoToReplace);
            patientInsuranceInfoList.add(newReplacedPatientInsuranceInfo);
            CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo = LookupByRxV2Helper.buildPatientInsReplacementInfo(CARDHOLDER_ID_2,CARRIER_ID_2,PLAN_ID_2,CARDHOLDER_ID_3,CARRIER_ID_3,PLAN_ID_3,"N",STORE_NBR,patientId);
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList = new ArrayList<>();
            patInsReplacementInfoList.add(patInsReplacementInfo);
            SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,patInsReplacementInfoList,cprPatientUpdateRetrofit);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step - 2 Call Lookup By Rx V2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);

    }


    @Test(priority = 16,description = "Rx with last fill paid with Insurance (Ins 2), but no insurance is present in CPR profile")
    public void test_RxWithCoverageNotModified_NoInsurancePresentInCPR() throws IOException, InterruptedException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, STORE_NBR.toString(), PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, Integer.parseInt(INS_PLAN_TYPE_CODE_2), Integer.parseInt(RELATIONSHIP_CODE_2));
        patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :" + cid);

        // Step 3 - Make CPR profile with no insurance
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurancePrimary = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"N",BILLING_GROUP_NBR_1,"1");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsurancePrimary);
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsuranceAndReplacement(String.valueOf(STORE_NBR), String.valueOf(patientId), patientFirstName, patientLastName, "M", CPR_DOB, PHONE_NO, ZIPCODE, patientInsuranceInfoList, null, cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        // Step 4 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertNull(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getRelation());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_2);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_2.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_2.toString());
        Assert.assertNull(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getRelation());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED_NO_DATA);
    }

    @Test(priority = 17, description = "Refill Rx with Insurance 1, Remove Insurance 1 from CPR, Add Insurance 2, Call LookupByRxV2")
    public void test_RxWithInsurance1_RemoveIns1_AddIns2() throws IOException, InterruptedException {

        // Step 1 - Create new account (CPR) with Insurance 1
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);

        // Create test account with Insurance 1
        rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, STORE_NBR.toString(), PLAN_ID_1, CARRIER_ID_1, CARDHOLDER_ID_1, Integer.parseInt(INS_PLAN_TYPE_CODE_1), Integer.parseInt(RELATIONSHIP_CODE_1));
        patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));

        // Step 2 - Create Refill with Insurance 1
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 3 - Move Order to EOD (Complete the refill with Insurance 1)
        rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :" + cid);

        // Step 4 - CPR - Remove Insurance 1 completely and Add Insurance 2
        try {
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurance2Active = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_2,
                    CARRIER_ID_2.toString(),
                    PLAN_ID_2.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_2,
                    INS_PLAN_TYPE_CODE_2,
                    "Y", // Active
                    BILLING_GROUP_NBR_2,
                    "1"  // Primary
            );

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurance2Active);
            // Note: Insurance 1 is NOT added to the list, so it's completely removed from CPR

            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(
                    String.valueOf(STORE_NBR),
                    String.valueOf(patientId),
                    patientFirstName,
                    patientLastName,
                    "M",
                    CPR_DOB,
                    PHONE_NO,
                    ZIPCODE,
                    patientInsuranceInfoList,
                    cprPatientUpdateRetrofit
            );
            cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
            am.performSleep(60);

        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 5 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingString, true);

        // Step 6 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber()
        );
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber()
        );

        Assert.assertNotNull(response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());

        Assert.assertNotNull(response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());

        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED_NO_DATA);
    }

    @Test(priority = 18, description = "Refill Rx with last fill paid with Insurance B, InActive. Primary Insurance B1 (duplicate of B with additional values) Active")
    public void test_RxWithCoverageModifiedToDefault_InactivePrimary_ActiveDuplicateInsurance() throws IOException, InterruptedException {
        // Step 1 - Create new account (CPR - B) with Insurance B
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);

        // Create test account with insurance B (Insurance 1)
        rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, STORE_NBR.toString(), PLAN_ID_1, CARRIER_ID_1, CARDHOLDER_ID_1, Integer.parseInt(INS_PLAN_TYPE_CODE_1), Integer.parseInt(RELATIONSHIP_CODE_1));
        patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));

        // Step 2 - Create Refill with Insurance B
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 3 - Move Order to EOD (Complete the refill with Insurance B)
        rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :" + cid);

        // Step 4 - CPR - Inactivate Insurance B and Add Insurance B1 (B with additional values)
        // Note: B is inactivated but remains in CPR, B1 is added as active with same core identifiers
        try {

            // Inactivate Insurance B (Insurance 1) - the one used in refill
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceBInactive = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_1,
                    CARRIER_ID_1.toString(),
                    PLAN_ID_1.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_1,
                    INS_PLAN_TYPE_CODE_1,
                    "N", // Inactive
                    BILLING_GROUP_NBR_1,
                    "2"
            );

            // Create Insurance B1 - same carrier/plan as B, but cardholder ID is appended
            // This makes B and B1 DIFFERENT insurances (different cardholder ID)
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceB1Active = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_1 + CARDHOLDER_ID_B1_SUFFIX,  // Cardholder ID appended: "WBR120" + "27823" = "WBR12027823"
                    CARRIER_ID_1.toString(),     // Same as B: "100426"
                    PLAN_ID_1.toString(),        // Same as B: "171"
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_1,
                    INS_PLAN_TYPE_CODE_1,
                    "Y",
                    BILLING_GROUP_NBR_1,  // Same as B
                    "1"
            );

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceB1Active);
            patientInsuranceInfoList.add(patientInsuranceBInactive);
            // Note: B is inactive, B1 is active (same insurance, B1 has additional values)

            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(
                    String.valueOf(STORE_NBR),
                    String.valueOf(patientId),
                    patientFirstName,
                    patientLastName,
                    "M",
                    CPR_DOB,
                    PHONE_NO,
                    ZIPCODE,
                    patientInsuranceInfoList,
                    cprPatientUpdateRetrofit
            );
            cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
            am.performSleep(60);

        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 5 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingString, true);

        // Step 6 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber()
        );
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber()
        );
        Assert.assertNotNull(response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());

        Assert.assertNotNull(response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1 + CARDHOLDER_ID_B1_SUFFIX);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);
    }

    @Test(priority = 19, description = "Refill Rx with last fill paid with Insurance B, Active. Primary Insurance B1 (duplicate of B with additional values) Active")
    public void test_RxWithCoverageModifiedToDefault_ActivePrimary_ActiveDuplicateInsurance() throws IOException, InterruptedException {
        // Step 1 - Create new account (CPR - B) with Insurance B
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);

        // Create test account with insurance B (Insurance 1)
        rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, STORE_NBR.toString(), PLAN_ID_1, CARRIER_ID_1, CARDHOLDER_ID_1, Integer.parseInt(INS_PLAN_TYPE_CODE_1), Integer.parseInt(RELATIONSHIP_CODE_1));
        patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));

        // Step 2 - Create Refill with Insurance B
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 3 - Move Order to EOD (Complete the refill with Insurance B)
        rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :" + cid);

        // Step 4 - CPR - Inactivate Insurance B and Add Insurance B1 (B with additional values)
        // Note: B is inactivated but remains in CPR, B1 is added as active with same core identifiers
        try {

            // Inactivate Insurance B (Insurance 1) - the one used in refill
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceBInactive = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_1,
                    CARRIER_ID_1.toString(),
                    PLAN_ID_1.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_1,
                    INS_PLAN_TYPE_CODE_1,
                    "Y",
                    BILLING_GROUP_NBR_1,
                    "2"
            );
            // Create Insurance B1 - same carrier/plan as B, but cardholder ID is appended
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceB1Active = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_1 + CARDHOLDER_ID_B1_SUFFIX,  // Cardholder ID appended: "WBR120" + "27823" = "WBR12027823"
                    CARRIER_ID_1.toString(),     // Same as B: "100426"
                    PLAN_ID_1.toString(),        // Same as B: "171"
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_1,
                    INS_PLAN_TYPE_CODE_1,
                    "Y",
                    BILLING_GROUP_NBR_1,  // Same as B
                    "3"
            );
            // Create insurance A with billing seq 1
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceAActive = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_2,
                    CARRIER_ID_2.toString(),
                    PLAN_ID_2.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_2,
                    INS_PLAN_TYPE_CODE_2,
                    "Y",
                    BILLING_GROUP_NBR_2,
                    "1"
            );

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsuranceB1Active);
            patientInsuranceInfoList.add(patientInsuranceBInactive);
            // Note: B is inactive, B1 is active (same insurance, B1 has additional values)

            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(
                    String.valueOf(STORE_NBR),
                    String.valueOf(patientId),
                    patientFirstName,
                    patientLastName,
                    "M",
                    CPR_DOB,
                    PHONE_NO,
                    ZIPCODE,
                    patientInsuranceInfoList,
                    cprPatientUpdateRetrofit
            );
            cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
            am.performSleep(60);

        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 5 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingString, true);

        // Step 6 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber()
        );
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber()
        );
        Assert.assertNotNull(response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());

        Assert.assertNotNull(response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED);
    }


    @Test(priority = 20, description = "CPR with two insurances (Ins 1 and Ins 2), Create Refill with Insurance 2")
    public void test_RxWithTwoInsurances_RefillWithInsurance2() throws IOException, InterruptedException {
        // Step 1 - Create new account with Insurance 1
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);

        // Create test account with Insurance 1
        rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, STORE_NBR.toString(), PLAN_ID_1, CARRIER_ID_1, CARDHOLDER_ID_1, Integer.parseInt(INS_PLAN_TYPE_CODE_1), Integer.parseInt(RELATIONSHIP_CODE_1));
        patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));

        // Step 2 - Add Insurance 2 to CPR (so patient has both Insurance 1 and Insurance 2)
        try {
            // Insurance 1 - Primary
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurance1 = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_1,
                    CARRIER_ID_1.toString(),
                    PLAN_ID_1.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_1,
                    INS_PLAN_TYPE_CODE_1,
                    "Y", // Active
                    BILLING_GROUP_NBR_1,
                    "1"  // Primary
            );

            // Insurance 2 - Secondary
            CPRUpdatePatientRequest.PatientInsuranceInfo patientInsurance2 = LookupByRxV2Helper.buildPatientInsuranceInfo(
                    CARDHOLDER_ID_2,
                    CARRIER_ID_2.toString(),
                    PLAN_ID_2.toString(),
                    patientFirstName,
                    patientLastName,
                    RELATIONSHIP_CODE_2,
                    INS_PLAN_TYPE_CODE_2,
                    "Y", // Active
                    BILLING_GROUP_NBR_2,
                    "2"  // Secondary
            );

            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
            patientInsuranceInfoList.add(patientInsurance1);
            patientInsuranceInfoList.add(patientInsurance2);

            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(
                    String.valueOf(STORE_NBR),
                    String.valueOf(patientId),
                    patientFirstName,
                    patientLastName,
                    "M",
                    CPR_DOB,
                    PHONE_NO,
                    ZIPCODE,
                    patientInsuranceInfoList,
                    cprPatientUpdateRetrofit
            );
            cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
            am.performSleep(60);

        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 3 - Create Refill with Insurance 2 (not the primary, but the secondary)
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 4 - Move Order to EOD (Complete the refill with Insurance 2)
        // Note: The refill should be using Insurance 2 based on the test data setup
        rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :" + cid);

        // Step 5 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingString, true);

        // Step 6 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber()
        );
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(),
                lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber()
        );

        // Verify last coverage info (should show Insurance 2 from the refill)
        Assert.assertNotNull(response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getLastCoverageInfo().get(0).getPlanId(), PLAN_ID_1.toString());

        // Verify coverage applicable (should show Insurance 2 - the one used in refill and still active)
        Assert.assertNotNull(response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());

        // Coverage should NOT be modified - Insurance 2 was used and is still active
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_NOT_MODIFIED);
    }

    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.keySet().forEach(patientId->{
            rxpdUtils.deletePatientAndRx(STORE_NBR, patientIdAndRxsToBeDeleted.get(patientId), patientId);
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())) {
                            Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                        }
                    } catch (IOException e) {
                        Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                    }
                });
    }
}
