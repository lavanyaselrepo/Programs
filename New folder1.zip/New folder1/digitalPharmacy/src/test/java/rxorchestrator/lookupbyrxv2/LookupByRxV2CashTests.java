package rxorchestrator.lookupbyrxv2;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.CustomerPrescriptionsV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.LookUpRxRequestV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionV2;
import lombok.extern.slf4j.Slf4j;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper.*;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.reqTrackingString;


/**
 * This class contains tests for the LookUpRxV2 API with scenarios where the last fill was paid with cash
 * 1.  COVERAGE_MODIFIED_TO_DEFAULT - when primary insurance is present
 * 2.  CASH_NOT_MODIFIED - when primary insurance is not present
 *
 * Not Covered
 * 1. CASH_NOT_MODIFIED due to doNotDiscloseInsuranceRestriction - when primary insurance is present/not but doNotDiscloseInsuranceRestriction is set to true and lastFillPaid by CASH
 * 2. COVERAGE_MODIFIED_TO_CASH due to doNotDiscloseInsuranceRestriction -   when primary insurance is present/not but doNotDiscloseInsuranceRestriction is set to true and lastFillPaid by Insurance
 */
@Slf4j
public class LookupByRxV2CashTests {


    InsuranceWrapper insuranceWrapper;
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    RxOrchestratorRetrofit rxOrchestratorRetrofit;

    List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = new ArrayList<>();
    HashMap<Integer,List<InputResponse>> patientIdAndRxsToBeDeleted = new HashMap<>();
    WrapperUtils wrapperUtils=new WrapperUtils();
    AutomationManager am = AutomationManager.getInstance();
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    LookupByRxV2Helper lookupByRxV2Helper = new LookupByRxV2Helper();

    private List<InputResponse> rfpRxs = new ArrayList<>();
    private String cid;
    private Integer patientId;
    private String patientEmailId;
    private String patientFirstName;
    private String patientLastName;
    private String PHONE_NO;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;


    // Insurance related information
    public static final String CARDHOLDER_ID_1 = "248201700";
    public static final Integer CARRIER_ID_1 = 100426;
    public static final Integer PLAN_ID_1 = 171;
    public static final Integer CATEGORY_1=1004;



    /**
     * Sequence of API call to execute Ecom Fill Event Flow *
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * delete created patient and rxs*
     */
    @BeforeClass
    void setContext(){
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        insuranceWrapper = new InsuranceWrapper();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    }


    @Test(priority = 1, description = "Rx with last fill paid with CASH and primary insurance present")
    public void test_RxWithCoverageModifiedToDefault() throws IOException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);


        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        // Step 2 - Update CPR profile to add insurance
        Log.info("CID :"+cid);

        try {

            CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,CommonUtil.generateRandomNumber(6),CARDHOLDER_ID_1,CARRIER_ID_1,PLAN_ID_1,
                   CATEGORY_1,cprPatientUpdateRetrofit);

            cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        } catch (IOException e) {
            Reporter.log("Failed to update CPR profile with insurance information: " + e.getMessage());
        }

        // Step 3 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 4 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);
    }

    @Test(priority = 2, description = "Rx with last fill paid with CASH and primary insurance not present")
    public void test_RxWithCoverageNullAndCashNotModified() throws IOException {
        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 2 -Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(),patientId.toString(),patientFirstName,patientLastName,DOB,PHONE_NO,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        // Step 3 - Call LookUpRxV2 API
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 4 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 1);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.CASH_NOT_MODIFIED);
    }



    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.keySet().forEach(patientId->{
            rxpdUtils.deletePatientAndRx(STORE_NBR, patientIdAndRxsToBeDeleted.get(patientId), patientId);
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())) {
                            Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                        }
                    } catch (IOException e) {
                        Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                    }
                });
    }


}
