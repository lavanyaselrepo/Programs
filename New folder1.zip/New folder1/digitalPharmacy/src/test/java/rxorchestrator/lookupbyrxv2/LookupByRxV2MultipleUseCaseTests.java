package rxorchestrator.lookupbyrxv2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.CustomerPrescriptionsV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.LookUpRxRequestV2;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionV2;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper.*;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.reqTrackingString;


/**
 * Test class for RxOrchestrator V2 multiple use cases.
 * <p>
 * This class contains integration tests for validating various scenarios of the Lookup By Rx V2 API,
 * including unauthorized access, unknown Rx numbers, and multiple Rx coverage modifications.
 * It sets up test data, executes API calls, and asserts expected outcomes for each use case.
 * <p>
 * After all tests, it performs cleanup by deleting created patients, Rxs, and CPR profiles.
 */
public class LookupByRxV2MultipleUseCaseTests {

    InsuranceWrapper insuranceWrapper;
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    RxOrchestratorRetrofit rxOrchestratorRetrofit;

    ObjectMapper objectMapper = new ObjectMapper();
    List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = new ArrayList<>();
    HashMap<Integer,List<InputResponse>> patientIdAndRxsToBeDeleted = new HashMap<>();
    WrapperUtils wrapperUtils=new WrapperUtils();
    AutomationManager am = AutomationManager.getInstance();
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    LookupByRxV2Helper lookupByRxV2Helper = new LookupByRxV2Helper();

    private List<InputResponse> rfpRxs = new ArrayList<>();
    private String cid;
    private Integer patientId;
    private String patientEmailId;
    private String patientFirstName;
    private String patientLastName;
    private String PHONE_NO;
    private String ZIPCODE;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 2;

    // Insurance related information
    // First Insurance
    public static final String CARDHOLDER_ID_1 = "WBR120";
    public static final Integer CARRIER_ID_1 = 100426;
    public static final Integer PLAN_ID_1 = 171;
    public static final String INS_PLAN_TYPE_CODE_1 = "1003";
    public static final String RELATIONSHIP_CODE_1="3201";
    public static final String BILLING_GROUP_NBR_1 = "1626281726";


    /**
     * Initializes API manager and service wrapper instances required for RxOrchestrator V2 tests.
     * Sets up dependencies for digital pharmacy, insurance, Rx orchestrator, and CPR patient update operations.
     */
    @BeforeClass
    void setContext(){
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        insuranceWrapper = new InsuranceWrapper();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    }


    // Unauthorized customer access

    @Test(priority = 1, description = "Getting Rx info of Customer 1 using customer 2 account id")
    public void test_CustomerUnauthorised() throws IOException {

        // Step 1 -  Create new customer (Cust 1) and new Rx in Ready for pickup
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 2 - Get CPR profile for this customer (Cust 1)
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(),patientId.toString(),patientFirstName,patientLastName,DOB,PHONE_NO,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        // Step 3 - Create another customer (Cust 2) account
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation();
        String cid2 = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);

        // Step 4 - Get CPR profile for customer (Cust 2)
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(),patientId.toString(),patientFirstName,patientLastName,DOB,PHONE_NO,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        // Step 5 -  Call Look up by Rx V2 API with Rx from Cust 1 and pass customer Id of Cust 2
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid2, lookUpRxRequestV2, reqTrackingId, true);

        // Step 6 - Validate the response
        Assert.assertEquals(response.code(), 401);

    }


    @Test(priority = 2, description = "Unknown Rx nbr passed as part of request")
    public void test_UnknownRxNbr() throws IOException {

        //Step 1 - Create new customer

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account with insurance
        rxpdUtils.testAccountCreation();
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);

        // Step 2 - Unknown Rx Nbr passed
        InputResponse rx = new InputResponse();
        rx.setRxNbr(60021);
        List<InputResponse> rxs = new ArrayList<>();
        rxs.add(rx);

        // Step 3 -Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(),patientId.toString(),patientFirstName,patientLastName,DOB,PHONE_NO,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        // Step 4 - Call Look up by Rx V2 API with unknown Rx Nbr
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Validate the response
        Assert.assertEquals(response.code(), 500);
    }

    @Test(priority = 3, description = "Multiple Rx's passed in request, both Rx's with coverage modified to default")
    public void test_MultipleRxs_BothRxWithCoverageModifiedToDefault() throws IOException {

        // Step 1 - Create new account and create and RX and move to Ready for Pickup (RFP) state with insurance

        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        PHONE_NO = CommonUtil.generateRandomNumber(10);
        ZIPCODE = CommonUtil.generateRandomNumber(6);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, lookupByRxV2Helper.DOTCOM_PASSWORD);
        // Create test account
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        am.performSleep(180);

        // Step 2 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        Log.info("CID :"+cid);

        // Step 3 - Add insurance to CPR profile of customer
        CPRUpdatePatientRequest.PatientInsuranceInfo newInsuranceToAdd = LookupByRxV2Helper.buildPatientInsuranceInfo(CARDHOLDER_ID_1,CARRIER_ID_1.toString(),PLAN_ID_1.toString(),patientFirstName,patientLastName,RELATIONSHIP_CODE_1,INS_PLAN_TYPE_CODE_1,"Y",BILLING_GROUP_NBR_1,"1");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(newInsuranceToAdd);
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance(String.valueOf(STORE_NBR),String.valueOf(patientId),patientFirstName,patientLastName,"M",CPR_DOB,PHONE_NO,ZIPCODE,patientInsuranceInfoList,cprPatientUpdateRetrofit);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        
        // Step 4 - Call Look up by Rx V2 API with unknown Rx Nbr
        LookUpRxRequestV2 lookUpRxRequestV2 = LookupByRxV2Helper.getLookupByRxV2Request(rfpRxs, STORE_NBR);
        String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
        Response<CustomerPrescriptionsV2> response = rxOrchestratorRetrofit.getCustomerPrescriptionsV2Response(cid, lookUpRxRequestV2, reqTrackingId, true);

        // Step 5 - Asserting response
        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body());
        Assert.assertNotNull(response.body().getPrescriptions());
        Assert.assertEquals(response.body().getPrescriptions().size(), 2);
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getRxNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getRxNumber());
        Assert.assertEquals(
                response.body().getPrescriptions().get(0).getStoreNumber(), lookUpRxRequestV2.getPrescriptions().get(0).getStoreNumber());
        Assert.assertNull(
                response.body().getPrescriptions().get(0).getLastCoverageInfo());
        Assert.assertNull(
                response.body().getPrescriptions().get(1).getLastCoverageInfo());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(0).getCoverageApplicable());
        Assert.assertNotNull(
                response.body().getPrescriptions().get(1).getCoverageApplicable());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(1).getCoverageApplicable().size(), 1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(1).getCoverageApplicable().get(0).getCardHolderId(), CARDHOLDER_ID_1);
        Assert.assertEquals(response.body().getPrescriptions().get(1).getCoverageApplicable().get(0).getCarrierId(), CARRIER_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(1).getCoverageApplicable().get(0).getPlanId(), PLAN_ID_1.toString());
        Assert.assertEquals(response.body().getPrescriptions().get(0).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);
        Assert.assertEquals(response.body().getPrescriptions().get(1).getCoverageApplicableType(), PrescriptionV2.CoverageApplicableTypeEnum.COVERAGE_MODIFIED_TO_DEFAULT);
    }




    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.keySet().forEach(patientId->{
            rxpdUtils.deletePatientAndRx(STORE_NBR, patientIdAndRxsToBeDeleted.get(patientId), patientId);
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())) {
                            Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                        }
                    } catch (IOException e) {
                        Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                    }
                });
    }
}
