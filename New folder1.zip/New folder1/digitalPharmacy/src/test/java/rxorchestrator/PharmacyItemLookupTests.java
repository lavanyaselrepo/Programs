package rxorchestrator;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemLookupRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.BuParm;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.openjdk.tools.sjavac.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class PharmacyItemLookupTests {
    private static final Logger logger = LoggerFactory.getLogger(PharmacyItemLookupTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    AutomationManager am = AutomationManager.getInstance();
    private String cid;
    private Integer patientId;
    private String DOMAIN_ID = "WM-PHARMACY";

    private Integer STORE_NBR = 5548;
    private String DOB = "01011998";
    private String DOTCOMPASSWORD = "Test@1234";

    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;
    private String BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE = "5328";
    private String NDC_NBR = "68382056510";
    private String PET_NDC_NBR = "59415241102";
    private String BU_PARM_PHM_CODE_TRUE = "TRUE";
    private String BU_PARM_PHM_CODE_FALSE = "FALSE";
    private String POS_CAL_IND_N = "N";
    private String POS_CAL_IND_Y = "Y";
    private final String IS_REFRIGERATED = "isRefrigerated";
    private final String IS_RECONSTITUTED = "isReconstituted";

  /**
   * Sequence of API call for Pharmacy Item Lookup Flow*
   * create new patient*
   * get patientId from CPR*
   * get cid from email using ca service API*
   * create rfp rxs*
   * delete created patient and rxs*
   *
   * @throws IOException
   */
  @BeforeClass
  void setContext() throws IOException {

        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOMPASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        logger.info("Pharmacy Item Lookup CID: " + cid);
        Reporter.logJSON("Pharmacy Item Lookup CID: ", cid);
    }

    @Test(enabled = true, priority = 1, description = "Pharmacy Item Lookup API invalid queryParam")
    public void Item_Lookup_Invalid_QueryParam() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request Invalid QueryParam: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Request Invalid QueryParam: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> accountingDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, INVALID_RESPONSE_TYPE);
        Assert.assertEquals(500, accountingDetailsResponse.code());
    }

    @Test(enabled = true, priority = 2, description = "Pharmacy Item Lookup API null queryParam")
    public void Item_Lookup_Null_QueryParam() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request Null QueryParam: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Request Null QueryParam: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> accountingDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, null);
        Assert.assertEquals(400, accountingDetailsResponse.code());
    }

    @Test(enabled = true, priority = 3, description = "Pharmacy Item Accounting Details API successful response")
    public void Accounting_Details_Success_Response() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Accounting Details Request: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Accounting Details Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> accountingDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, ACCOUNTING_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(200, accountingDetailsResponse.code());
        Assert.assertNotNull(accountingDetailsResponse.body());
    }

    @Test(enabled = true, priority = 4, description = "Pharmacy Item Accounting Details API invalid PRefId")
    public void Accounting_Details_Invalid_Request() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.singletonList(INVALID_PREFID));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> accountingDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, ACCOUNTING_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, accountingDetailsResponse.code());
    }

    @Test(enabled = true, priority = 5, description = "Pharmacy Item Accounting Details API null PRefId")
    public void Accounting_Details_Invalid_Request_2() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.emptyList());
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> accountingDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, ACCOUNTING_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, accountingDetailsResponse.code());
    }

    @Test(enabled = true, priority = 6, description = "Pharmacy Item Return Details API successful response")
    public void Return_Details_Success_Response() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Return Details Request: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Return Details Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> returnDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, RETURN_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(200, returnDetailsResponse.code());
        Assert.assertNotNull(returnDetailsResponse.body());
    }

    @Test(enabled = true, priority = 7, description = "Pharmacy Item Return Details API invalid PRefId")
    public void Return_Details_Invalid_Request() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.singletonList(INVALID_PREFID));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> returnDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, RETURN_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, returnDetailsResponse.code());
    }

    @Test(enabled = true, priority = 8, description = "Pharmacy Item Return Details API null PRefId")
    public void Return_Details_Invalid_Request_2() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.emptyList());
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> returnDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, RETURN_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, returnDetailsResponse.code());
    }

    @Test(enabled = true, priority = 9, description = "Pharmacy Item Delivery Update Details API successful response")
    public void Delivery_Update_Details_Success_Response() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Delivery Upddate Details Request: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Delivery Upddate Details Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> deliveryUpdateDetailsResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, DELIVERY_UPDATE_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(200, deliveryUpdateDetailsResponse.code());
        Assert.assertNotNull(deliveryUpdateDetailsResponse.body());
        Assert.assertNotNull(deliveryUpdateDetailsResponse.body().getPayload());
        Assert.assertNotNull(deliveryUpdateDetailsResponse.body().getPayload().getFills());
    }

    @Test(enabled = true, priority = 10, description = "Pharmacy Item Delivery Update Details API invalid PRefId")
    public void Delivery_Update_Details_Invalid_Request() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.singletonList(INVALID_PREFID));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> deliveryUpdateDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, DELIVERY_UPDATE_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, deliveryUpdateDetailsResponse.code());
    }

    @Test(enabled = true, priority = 11, description = "Pharmacy Item Delivery Update Details API null PRefId")
    public void Delivery_Update_Details_Invalid_Request_2() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        pharmacyItemLookupRequest.setPRefIds(Collections.emptyList());
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> deliveryUpdateDetailsResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, DELIVERY_UPDATE_DETAILS_RESPONSE_TYPE);
        Assert.assertEquals(400, deliveryUpdateDetailsResponse.code());
    }

    @Test(enabled = true, priority = 12, description = "Pharmacy Item Cart Item API successful response")
    public void Cart_Item_Success_Response() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Cart Item Request: " + pharmacyItemLookupRequest);
        Reporter.logJSON("PharmacyItemLookup Cart Item Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());

        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertEquals("PHARMACY_TAX_EXEMPT",pharmacyItemResponse.getPayload().getFills().get(0).getOfferInfo().getTaxabilityType());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
           store.getPharmacyOperatingHours().forEach(operatingHours -> {
               Assert.assertNotNull(operatingHours.getLunchHours());
               Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
               Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
           });
           Assert.assertNotNull(store.getAddress());
           Assert.assertNotNull(store.getAddress().getAddressLine1());
           Assert.assertNotNull(store.getAddress().getCity());
           Assert.assertNotNull(store.getAddress().getState());
           Assert.assertNotNull(store.getAddress().getCountry());
           Assert.assertNotNull(store.getAddress().getPostalCode());
        });

    }

    @Test(enabled = true, priority = 13, description = "Pharmacy Item Cart Item API invalid PRefId")
    public void Cart_Item_Invalid_Request() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        pharmacyItemLookupRequest.setPRefIds(Collections.singletonList(INVALID_PREFID));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> cartItemResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        Assert.assertEquals(400, cartItemResponse.code());
    }

    @Test(enabled = true, priority = 14, description = "Pharmacy Item Cart Item API null PRefId")
    public void Cart_Item_Invalid_Request_2() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = new PharmacyItemLookupRequest();
        pharmacyItemLookupRequest.setPRefIds(Collections.emptyList());
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<PharmacyItemResponse> cartItemResponse =  rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        Assert.assertEquals(400, cartItemResponse.code());
    }

    @Test(enabled = true, priority = 15, description = "Pharmacy Item Cart Item API successful response when tax is enabled on store")
    public void Cart_Item_Success_Response_Tax_Enabled_On_Store() throws IOException {

        BuParm startBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);

        rfpRxs = rxpdUtils.generateRFPFillWithTaxApplicable(patientId, STORE_NBR,NDC_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE,BU_PARM_PHM_CODE_TRUE,POS_CAL_IND_N,CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, "CART_ITEM");
        logger.info("cart item lookup request: " + pharmacyItemLookupRequest);
        logger.info("cartItemResponse : " + cartItemResponse.body().getPayload().getFills());

        BuParm currentBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
        if(!Objects.equals(startBuParm.getPhmParmValue(),currentBuParm.getPhmParmValue())){
            rxpdUtils.updateBuParm(startBuParm.getStoreNbr(),startBuParm.getPhmParmValue(),startBuParm.getPhmParmCode());
            BuParm changedBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
            Assert.assertEquals(startBuParm,changedBuParm);
        }
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());
        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertEquals("PHARMACY_TAX_EXEMPT",pharmacyItemResponse.getPayload().getFills().get(0).getOfferInfo().getTaxabilityType());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });


    }

    @Test(enabled = true, priority = 16, description = "Pharmacy Item Cart Item API successful response when tax is not enabled on store")
    public void Cart_Item_Success_Response_Tax_Not_Enabled_On_Store() throws IOException {
        BuParm startBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);

        rfpRxs = rxpdUtils.generateRFPFillWithTaxApplicable(patientId, STORE_NBR,NDC_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE,BU_PARM_PHM_CODE_FALSE,POS_CAL_IND_Y,CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, "CART_ITEM");
        logger.info("cart item lookup request: " + pharmacyItemLookupRequest);
        logger.info("cartItemResponse : " + cartItemResponse.body().getPayload().getFills());

        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        BuParm currentBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
        BuParm endBuParm = new BuParm();
        if(!startBuParm.getPhmParmValue().equals(currentBuParm.getPhmParmValue())){
            rxpdUtils.updateBuParm(startBuParm.getStoreNbr(),startBuParm.getPhmParmValue(),startBuParm.getPhmParmCode());
        }
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertEquals("PHARMACY_TAX_EXEMPT",pharmacyItemResponse.getPayload().getFills().get(0).getOfferInfo().getTaxabilityType());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });

    }

    @Test(enabled = true, priority = 17, description = "Pharmacy Item Cart Item API successful response for No Tax")
    public void Cart_Item_Success_Response_No_Tax() throws IOException {
        BuParm startBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);

        rfpRxs = rxpdUtils.generateRFPFillWithTaxApplicable(patientId, STORE_NBR,NDC_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE,BU_PARM_PHM_CODE_TRUE,POS_CAL_IND_Y,CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, "CART_ITEM");
        logger.info("cart item lookup request: " + pharmacyItemLookupRequest);
        logger.info("cartItemResponse : " + cartItemResponse.body().getPayload().getFills());
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());

        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        BuParm currentBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
        if(!Objects.equals(startBuParm.getPhmParmValue(),currentBuParm.getPhmParmValue())){
            rxpdUtils.updateBuParm(startBuParm.getStoreNbr(),startBuParm.getPhmParmValue(),startBuParm.getPhmParmCode());
        }

        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });


    }

    @Test(enabled = true, priority = 18, description = "Pharmacy Item Cart Item API successful response for Tax Applicable")
    public void Cart_Item_Success_Response_Tax_Applicable() throws IOException {
        BuParm startBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);

        rfpRxs = rxpdUtils.generateRFPFillWithTaxApplicable(patientId, STORE_NBR,NDC_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE,BU_PARM_PHM_CODE_TRUE,POS_CAL_IND_N,CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, "CART_ITEM");
        logger.info("cart item lookup request: " + pharmacyItemLookupRequest);
        logger.info("cartItemResponse : " + cartItemResponse.body().getPayload().getFills());
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());

        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        BuParm currentBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
        if(!Objects.equals(startBuParm.getPhmParmValue(),currentBuParm.getPhmParmValue())){
            rxpdUtils.updateBuParm(startBuParm.getStoreNbr(),startBuParm.getPhmParmValue(),startBuParm.getPhmParmCode());
        }

        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });


    }

    @Test(enabled = true, priority = 17, description = "Pharmacy Item Cart Item API successful response for Pet Only Tax")
    public void Cart_Item_Success_Response_Pet_Only_Tax() throws IOException {
        BuParm startBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);

        rfpRxs = rxpdUtils.generateRFPFillWithTaxApplicable(patientId, STORE_NBR,PET_NDC_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE,BU_PARM_PHM_CODE_TRUE,POS_CAL_IND_N,CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        logger.info("PharmacyItemLookup Request: " + pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, "CART_ITEM");
        logger.info("cart item lookup request: " + pharmacyItemLookupRequest);
        logger.info("cartItemResponse : " + cartItemResponse.body().getPayload().getFills());
        Assert.assertEquals(200, cartItemResponse.code());
        Assert.assertNotNull(cartItemResponse.body());

        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        BuParm currentBuParm = rxpdUtils.getBuParm(STORE_NBR, BU_PARM_PHM_TAX_ENABLEMENT_FLAG_VALUE);
        if(!Objects.equals(startBuParm.getPhmParmValue(),currentBuParm.getPhmParmValue())){
            rxpdUtils.updateBuParm(startBuParm.getStoreNbr(),startBuParm.getPhmParmValue(),startBuParm.getPhmParmCode());
        }

        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });


    }

    @Test(enabled = true, priority = 12, description = "Pharmacy Item Cart Item API successful response for D38 Refrigerated Item")
    public void Cart_Item_Success_Response_For_D38_Refrigerated_Item() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00052027303"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        Log.info(String.format("PharmacyItemLookup Cart Item Request: %s, customerAccountId: %s", pharmacyItemLookupRequest, cid));
        Reporter.logJSON("PharmacyItemLookup Cart Item Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        Assert.assertEquals(HttpStatus.OK.value(), cartItemResponse.code());
        Assert.assertNotNull(pharmacyItemResponse);
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertTrue(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_REFRIGERATED).toString()));
        Assert.assertFalse(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_RECONSTITUTED).toString()));
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });

    }

    @Test(enabled = true, priority = 12, description = "Pharmacy Item Cart Item API successful response for D38 Reconstituted Item")
    public void Cart_Item_Success_Response_For_D38_Reconstituted_Item() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        Log.info(String.format("PharmacyItemLookup Cart Item Request: %s, customerAccountId: %s", pharmacyItemLookupRequest, cid));
        Reporter.logJSON("PharmacyItemLookup Cart Item Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        Assert.assertEquals(HttpStatus.OK.value(), cartItemResponse.code());
        Assert.assertNotNull(pharmacyItemResponse);
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertFalse(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_REFRIGERATED).toString()));
        Assert.assertTrue(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_RECONSTITUTED).toString()));
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });

    }

    @Test(enabled = true, priority = 12, description = "Pharmacy Item Cart Item API successful response for NonD38 Refrigerated Item")
    public void Cart_Item_Success_Response_For_NonD38_Refrigerated_Item() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00006498100"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        Log.info(String.format("PharmacyItemLookup Cart Item Request: %s, customerAccountId: %s", pharmacyItemLookupRequest, cid));
        Reporter.logJSON("PharmacyItemLookup Cart Item Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        Assert.assertEquals(HttpStatus.OK.value(), cartItemResponse.code());
        Assert.assertNotNull(pharmacyItemResponse);
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertTrue(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_REFRIGERATED).toString()));
        Assert.assertFalse(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_RECONSTITUTED).toString()));
        pharmacyItemResponse.getPayload().getStores().forEach(store -> {
            store.getPharmacyOperatingHours().forEach(operatingHours -> {
                Assert.assertNotNull(operatingHours.getLunchHours());
                Assert.assertNotNull(operatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(operatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(store.getAddress());
            Assert.assertNotNull(store.getAddress().getAddressLine1());
            Assert.assertNotNull(store.getAddress().getCity());
            Assert.assertNotNull(store.getAddress().getState());
            Assert.assertNotNull(store.getAddress().getCountry());
            Assert.assertNotNull(store.getAddress().getPostalCode());
        });

    }

    // TODO: Update the NDC for NonD38 Reconstituted item and uncomment the test
//  @Test(enabled = true, priority = 12, description = "Pharmacy Item Cart Item API successful response for NonD38 Reconstituted Item")
    public void Cart_Item_Success_Response_For_NonD38_Reconstituted_Item() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList(""), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);
        PharmacyItemLookupRequest pharmacyItemLookupRequest = rxpdUtils.getPharmacyItemLookupRequest(rfpRxs, STORE_NBR);
        Log.info(String.format("PharmacyItemLookup Cart Item Request: %s, customerAccountId: %s", pharmacyItemLookupRequest, cid));
        Reporter.logJSON("PharmacyItemLookup Cart Item Request: ", pharmacyItemLookupRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(180);
        Response<PharmacyItemResponse> cartItemResponse = rxOrchestratorRetrofit.getPharmacyItemLookupResponse(
                cid, pharmacyItemLookupRequest, reqId, reqTrackingId, CART_ITEM_RESPONSE_TYPE);
        PharmacyItemResponse pharmacyItemResponse = cartItemResponse.body();

        Assert.assertEquals(HttpStatus.OK.value(), cartItemResponse.code());
        Assert.assertNotNull(pharmacyItemResponse);
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills());
        Assert.assertNotNull(pharmacyItemResponse.getPayload().getFills().get(0).getPRefId());
        Assert.assertFalse(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_REFRIGERATED).toString()));
        Assert.assertTrue(Boolean.parseBoolean(pharmacyItemResponse.getPayload().getFills().get(0).getAdditionalInfo().get(IS_RECONSTITUTED).toString()));
    }



    /**
     * Method to delete patient and rx from informix and OCP*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {
        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
    }

}
