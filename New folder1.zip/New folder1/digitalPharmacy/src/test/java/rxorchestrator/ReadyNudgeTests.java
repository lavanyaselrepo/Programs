package rxorchestrator;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.SaveConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.NudgeBottomSheetResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.NudgeSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.request.PharmacyItemsReadyNudgeBottomsheetRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.ReadyNudgeWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;

import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ReadyNudgeTests {
    private static final Logger logger = LoggerFactory.getLogger(ReadyNudgeTests.class);

    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    RxpdUtils rxpdUtils = new RxpdUtils(1);
    ReadyNudgeWrapper readyNudgeWrapper = new ReadyNudgeWrapper();
    GetandSaveEcomWrapper getandSaveEcomWrapper = new GetandSaveEcomWrapper();
    SaveConsentWrapper saveConsentWrapper = new SaveConsentWrapper();
    ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();

    List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = new ArrayList<>();
    HashMap<Integer,List<InputResponse>> patientIdAndRxsToBeDeleted = new HashMap<>();

    WrapperUtils wrapperUtils=new WrapperUtils();
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 1;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private String STORE_NBR = String.valueOf(RxpdUtils.STORE_NBR);
    private final String LOB = "PHARMACY";
    private final String TENANT_ID = "elh9ie";

    @Test(priority = 1, description = "Create a new patient without Ecom Consent. Check the Nudge summary response have Ecom Consent = False")
    public void test_NudgeSummary_NoEcomConsent() throws InterruptedException {
        // Step 1: Generate random patient details
        String patientEmail = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(10);
        String patientLastName = CommonUtil.generateRandomLastName(10);
        String patientDOB = "02021992"; // Example DOB
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);

        // Step 2: Create a new patient account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(patientEmail, patientFirstName, patientLastName, patientDOB, STORE_NBR);
        Integer patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, patientDOB, STORE_NBR);
        String patient_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", patient_cid);
        logger.info("Caregiver Customer Account Id: " + patient_cid);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR,patientId.toString(),patientFirstName,patientLastName,patientDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, new ArrayList<>());

        // Sleet for 5 seconds
        Thread.sleep(5000);

        // Step 3: Query Nudge Summary for CID. It should have No ecom consent
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(patient_cid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), patient_cid);
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeEligibility().getIneligibilityReason().getMessage(), "No Ready For Pickup Fills Present");
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getFills().getAtcEligibleFills().size(), 0);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getAtcEligibleFillsCount(), 0);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getReadyFillsCount(), 0);
        Assert.assertNull(nudgeSummaryResponse.getPayload().getNudgeExpiryDate());
    }

    @Test(priority = 2, description = "Create a new patient and give Ecom Consent. Check the Nudge summary response should have No RFP Fills")
    public void test_NudgeSummary_NoRFPFills() throws InterruptedException {
        // Step 1: Generate random patient details
        String patientEmail = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(10);
        String patientLastName = CommonUtil.generateRandomLastName(10);
        String patientDOB = "02021992"; // Example DOB
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);

        // Step 2: Create a new patient account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(patientEmail, patientFirstName, patientLastName, patientDOB, STORE_NBR);
        String patient_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", patient_cid);
        logger.info("Caregiver Customer Account Id: " + patient_cid);

        Thread.sleep(5000);

        // Step 3: Add Ecom consent
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, patientDOB, STORE_NBR);
        saveConsentWrapper.saveConsentForSelf(patient_cid, "50000-0000-001", "50000", "ACCEPT", LOB, TENANT_ID, STORE_NBR, "US");
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR, String.valueOf(patientId),patientFirstName,patientLastName,patientDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, new ArrayList<>());

        // Sleep for 5 seconds
        Thread.sleep(5000);

        // Step 4: Query Nudge Summary for CID. It should have No RFP Fills
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(patient_cid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), patient_cid);
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeEligibility().getIneligibilityReason().getMessage(), "No Ready For Pickup Fills Present");
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getFills().getAtcEligibleFills().size(), 0);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getAtcEligibleFillsCount(), 0);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getReadyFillsCount(), 0);
        Assert.assertNull(nudgeSummaryResponse.getPayload().getNudgeExpiryDate());
    }

    @Test(priority = 3, description = "Create a new patient and move their RXs to pickup with Ecom consent")
    public void test_NudgeSummary_AtcEligibleFills_WithConsentsSave() throws InterruptedException {
        // Step 1: Generate random patient details
        String patientEmail = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(10);
        String patientLastName = CommonUtil.generateRandomLastName(10);
        String patientDOB = "02021992"; // Example DOB
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);

        // Step 2: Create a new patient account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(patientEmail, patientFirstName, patientLastName, patientDOB, STORE_NBR);
        String patient_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", patient_cid);
        logger.info("Caregiver Customer Account Id: " + patient_cid);

        // Sleet for 20 seconds
        Thread.sleep(20000);

        // Step 3: Drop RXs for the patient
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, patientDOB, STORE_NBR);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR, String.valueOf(patientId),patientFirstName,patientLastName,patientDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, new ArrayList<>());

        // Step 4: Add Ecom and HIPAA Consent
        saveConsentWrapper.saveConsentForSelf(patient_cid, "50000-0000-001", "50000", "ACCEPT", LOB, TENANT_ID, STORE_NBR, "US");
        consentOrchestratorWrapper.saveNPP_SELF("3901","15","1","ACCEPT","101","DOTCOM","",STORE_NBR,patient_cid,patientId);

        rxpdUtils.rfpgen(patientId, Integer.parseInt(STORE_NBR), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Sleep for 5 minutes. Allows for data to sync in TDC
        Thread.sleep(300000);

        // Step 5: Validate RXs are ready for pickup in Nudge Summary
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(patient_cid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), patient_cid);
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeExpiryDate(), LocalDate.now().plusDays(9).format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        // CNX automation wrapper is flaky and can sometimes create fills in progress in first attempt, before creating RFP Fill.
        // This flag with help assert values
        boolean pharmacyDashboardRedirect = nudgeSummaryResponse.getPayload().getRedirectToPharmacyDashboard();
        Reporter.logJSON("Pharmacy Redirection is: ", pharmacyDashboardRedirect);
        logger.info("Pharmacy Redirection is: " + pharmacyDashboardRedirect);

        List<String> nudgePrefIds = nudgeSummaryResponse.getPayload().getFills().getAtcEligibleFills().stream()
                .map(NudgeSummaryResponse.AtcEligibleFills::getPRefId)
                .collect(Collectors.toList());

        // Step 6: Validate RXs are ready for pickup in Nudge Bottom sheet
        Thread.sleep(5000);
        PharmacyItemsReadyNudgeBottomsheetRequest pharmacyItemsReadyNudgeBottomsheetRequest = new PharmacyItemsReadyNudgeBottomsheetRequest();
        pharmacyItemsReadyNudgeBottomsheetRequest.setNudgePRefIds(nudgePrefIds);
        serRes = readyNudgeWrapper.getNudgeBottomSheetDetails(patient_cid, pharmacyItemsReadyNudgeBottomsheetRequest);
        NudgeBottomSheetResponse nudgeBottomSheetResponse = serRes.getDataResponse(NudgeBottomSheetResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        if(pharmacyDashboardRedirect) {
            Assert.assertEquals(nudgeBottomSheetResponse.getPayload().getAdditionalFillsCount(), 1);
        } else {
            // No additional fills for bottom sheet response
            Assert.assertEquals(nudgeBottomSheetResponse.getPayload().getAdditionalFillsCount(), 0);
        }

        List<NudgeBottomSheetResponse.Fills> fills = nudgeBottomSheetResponse.getPayload().getFills();
        Assert.assertEquals(fills.size(), 1);
        Assert.assertEquals(fills.getFirst().getPRefId(), nudgePrefIds.getFirst());

        List<NudgeBottomSheetResponse.Stores> stores = nudgeBottomSheetResponse.getPayload().getStores();
        Assert.assertEquals(stores.size(), 1);
        Assert.assertEquals(stores.getFirst().getStoreId(), Integer.valueOf(STORE_NBR));
        Assert.assertNotNull(stores.getFirst().getPostalCode());
    }

    @Test(description = "Create a new patient and move their RXs to pickup with Ecom consent")
    public void test_NudgeSummary_AtcEligibleFills_WithPhiAuthConsentSave() throws InterruptedException {
        // Step 1: Generate random patient details
        String patientEmail = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(10);
        String patientLastName = CommonUtil.generateRandomLastName(10);
        String patientDOB = "02021992"; // Example DOB
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);

        // Step 2: Create a new patient account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(patientEmail, patientFirstName, patientLastName, patientDOB, STORE_NBR);
        String patient_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", patient_cid);
        logger.info("Caregiver Customer Account Id: " + patient_cid);

        // Sleet for 20 seconds
        Thread.sleep(20000);

        // Step 3: Drop RXs for the patient
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, patientDOB, STORE_NBR);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR, String.valueOf(patientId),patientFirstName,patientLastName,patientDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, new ArrayList<>());

        // Step 4: Add Ecom and HIPAA Consent
        getandSaveEcomWrapper.saveEcommConsentForCaregiver(patient_cid, "50000", "0000", "001", STORE_NBR, patientId + "", "ACCEPT");
        consentOrchestratorWrapper.saveNPP_SELF("3901","15","1","ACCEPT","101","DOTCOM","",STORE_NBR,patient_cid,patientId);

        rxpdUtils.rfpgen(patientId, Integer.parseInt(STORE_NBR), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Sleep for 5 minutes. Allows for data to sync in TDC
        Thread.sleep(300000);

        // Step 5: Validate RXs are ready for pickup in Nudge Summary
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(patient_cid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), patient_cid);
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeExpiryDate(), LocalDate.now().plusDays(9).format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        // CNX automation wrapper is flaky and can sometimes create fills in progress in first attempt, before creating RFP Fill.
        // This flag with help assert values
        boolean pharmacyDashboardRedirect = nudgeSummaryResponse.getPayload().getRedirectToPharmacyDashboard();
        Reporter.logJSON("Pharmacy Redirection is: ", pharmacyDashboardRedirect);
        logger.info("Pharmacy Redirection is: " + pharmacyDashboardRedirect);

        List<String> nudgePrefIds = nudgeSummaryResponse.getPayload().getFills().getAtcEligibleFills().stream()
            .map(NudgeSummaryResponse.AtcEligibleFills::getPRefId)
            .collect(Collectors.toList());

        // Step 6: Validate RXs are ready for pickup in Nudge Bottom sheet
        Thread.sleep(5000);
        PharmacyItemsReadyNudgeBottomsheetRequest pharmacyItemsReadyNudgeBottomsheetRequest = new PharmacyItemsReadyNudgeBottomsheetRequest();
        pharmacyItemsReadyNudgeBottomsheetRequest.setNudgePRefIds(nudgePrefIds);
        serRes = readyNudgeWrapper.getNudgeBottomSheetDetails(patient_cid, pharmacyItemsReadyNudgeBottomsheetRequest);
        NudgeBottomSheetResponse nudgeBottomSheetResponse = serRes.getDataResponse(NudgeBottomSheetResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        if(pharmacyDashboardRedirect) {
          Assert.assertEquals(nudgeBottomSheetResponse.getPayload().getAdditionalFillsCount(), 1);
        } else {
          // No additional fills for bottom sheet response
          Assert.assertEquals(nudgeBottomSheetResponse.getPayload().getAdditionalFillsCount(), 0);
        }

        List<NudgeBottomSheetResponse.Fills> fills = nudgeBottomSheetResponse.getPayload().getFills();
        Assert.assertEquals(fills.size(), 1);
        Assert.assertEquals(fills.getFirst().getPRefId(), nudgePrefIds.getFirst());

        List<NudgeBottomSheetResponse.Stores> stores = nudgeBottomSheetResponse.getPayload().getStores();
        Assert.assertEquals(stores.size(), 1);
        Assert.assertEquals(stores.getFirst().getStoreId(), Integer.valueOf(STORE_NBR));
        Assert.assertNotNull(stores.getFirst().getPostalCode());
    }

    @Test(priority = 4, description = "Add RX for a Dependent(with ecom consent) with a Caregiver(without ecom consent)")
    public void test_NudgeSummary_AdultDependentConsentManagement() throws InterruptedException {

        // Step 1: Create a new Caregiver account
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String patientDOB = "03031993"; // Example DOB

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, patientDOB, STORE_NBR);
        Integer caregiverPatientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, patientDOB, STORE_NBR);
        String caregiverCid = caregiverDetails.getFirst();
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiverCid);
        logger.info("Caregiver Customer Account Id: " + caregiverCid);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequestCaregiver = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR,
                caregiverPatientId.toString(), caregiverFirstName, caregiverLastName, patientDOB, phoneNumber,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequestCaregiver);
        patientIdAndRxsToBeDeleted.put(caregiverPatientId, new ArrayList<>());
        // Sleep for 5 seconds
        Thread.sleep(5000);

        // Step 2: Create a new Dependent account
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5);
        String dependentLastName = CommonUtil.generateRandomLastName(5);

        List<String> dependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(dependentEmail, dependentFirstName, dependentLastName, patientDOB, STORE_NBR);
        Integer dependentPatientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName, dependentLastName, patientDOB, STORE_NBR);
        String dependentCid = dependentDetails.getFirst();
        Reporter.logJSON("Dependent Customer Account Id: ", dependentCid);
        logger.info("Dependent Customer Account Id: " + dependentCid);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequestDependent = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR,
                dependentPatientId.toString(), dependentFirstName, dependentLastName, patientDOB, phoneNumber,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequestDependent);
        patientIdAndRxsToBeDeleted.put(dependentPatientId, new ArrayList<>());

        // Step 3: Add Ecom and HIPAA Consent for Dependent
        saveConsentWrapper.saveConsentForSelf(dependentCid, "50000-0000-001", "50000", "ACCEPT", LOB, TENANT_ID, STORE_NBR, "US");
        consentOrchestratorWrapper.saveNPP_SELF("3901","15","1","ACCEPT","101","DOTCOM","", STORE_NBR, dependentCid, dependentPatientId);

        // Sleep for 5 seconds, and link Dependent to Caregiver
        Thread.sleep(5000);
        digitalPharmacyOperationsUtil.linkDependentToCaregiver_ConsentPreferenceSvc(caregiverCid, caregiverPatientId.toString(), dependentPatientId.toString(),
                STORE_NBR, STORE_NBR, phoneNumber, patientDOB, "ADULT", dependentEmail);

        // Step 4: Drop RXs for the Dependent patient
        List<InputResponse> rxs = rxpdUtils.rfpgen(dependentPatientId, Integer.parseInt(STORE_NBR), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Sleep for 5 minutes. Allows for data to sync in TDC
        Thread.sleep(300000);

        // Step 5: Validate RXs are ready for pickup in Nudge Summary for Caregiver
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(caregiverCid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        // Caregiver would not have Ecom consent but still has ATC Eligible Fill
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), caregiverCid);
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getRedirectToPharmacyDashboard());
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getAtcEligibleFillsCount(), 1);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeExpiryDate(), LocalDate.now().plusDays(9).format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        // Validate RXs are ready for pickup in Nudge Summary for Dependent
        serRes = readyNudgeWrapper.getNudgeSummaryDetails(dependentCid);
        nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        // Dependent would have Ecom consent and still has ATC Eligible Fill
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), dependentCid);
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertFalse(nudgeSummaryResponse.getPayload().getRedirectToPharmacyDashboard());
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getAtcEligibleFillsCount(), 1);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getNudgeExpiryDate(), LocalDate.now().plusDays(9).format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
    }

    @Test(priority = 5, description = "Create a new patient and move their RXs to pickup with Ecom consent but are ineligible because of lily drug")
    public void test_NudgeSummary_Lily_Drug_Present() throws InterruptedException {
        // Step 1: Generate random patient details
        String patientEmail = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(10);
        String patientLastName = CommonUtil.generateRandomLastName(10);
        String patientDOB = "02021992"; // Example DOB
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);

        // Step 2: Create a new patient account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(patientEmail, patientFirstName, patientLastName, patientDOB, STORE_NBR);
        String patient_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", patient_cid);
        logger.info("Caregiver Customer Account Id: " + patient_cid);

        // Sleet for 20 seconds
        Thread.sleep(20000);

        // Step 3: Drop RXs for the patient
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, patientDOB, STORE_NBR);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR, String.valueOf(patientId),patientFirstName,patientLastName,patientDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, new ArrayList<>());

        // Step 4: Add Ecom and HIPAA Consent
        saveConsentWrapper.saveConsentForSelf(patient_cid, "50000-0000-001", "50000", "ACCEPT", LOB, TENANT_ID, STORE_NBR, "US");
        consentOrchestratorWrapper.saveNPP_SELF("3901","15","1","ACCEPT","101","DOTCOM","",STORE_NBR,patient_cid,patientId);

        rxpdUtils.rfpgen(patientId, Integer.parseInt(STORE_NBR), Arrays.asList("00002200204"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Sleep for 5 minutes. Allows for data to sync in TDC
        Thread.sleep(300000);

        // Step 5: Validate RXs are ready for pickup in Nudge Summary
        ServiceResponse serRes = readyNudgeWrapper.getNudgeSummaryDetails(patient_cid);
        NudgeSummaryResponse nudgeSummaryResponse = serRes.getDataResponse(NudgeSummaryResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(nudgeSummaryResponse.getPayload().getCustomerId(), patient_cid);
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getEcommConsentPresentForCustomerId());
        Assert.assertTrue(nudgeSummaryResponse.getPayload().getNudgeEligibility().getEligible());
    }

    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.keySet().forEach(patientId->{
            rxpdUtils.deletePatientAndRx(Integer.parseInt(STORE_NBR), patientIdAndRxsToBeDeleted.get(patientId), patientId);
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())) {
                            Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                        }
                    } catch (IOException e) {
                        Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                    }
                });
    }
}
