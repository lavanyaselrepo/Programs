package rxorchestrator;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.PRefId;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class FillEligibilityTests {
    private static final Logger logger = LoggerFactory.getLogger(FillEligibilityTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    AutomationManager am = AutomationManager.getInstance();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    private Integer patientId;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String CHECKOUT_ELIGIBILITY_TYPE = "CHECKOUT";
    private String ADD_TO_CART_ELIGIBILITY_TYPE = "ADD_TO_CART";
    private String READY_NOTIFICATION_ELIGIBILITY_TYPE = "READY_NOTIFICATION";
    private String INVALID_ELIGIBILITY_TYPE = "CHECK";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;

    private FillEligibilityRequest getFillEligibilityRequestFillInfo(List<InputResponse> rfpRxs, int storeNbr){

        List<FillEligibilityInput> fills = new ArrayList<>();

        for(int i = 0; i<rfpRxs.size(); i++) {

            FillEligibilityInput fillEligibilityInput = new FillEligibilityInput();
            fillEligibilityInput.setInputType(FillEligibilityInput.InputTypeEnum.FILL_INFO);
            fillEligibilityInput.setRxFillId(String.valueOf(rfpRxs.get(i).getRxFillId()));
            fillEligibilityInput.setRxId(String.valueOf(rfpRxs.get(i).getRxId()));
            fillEligibilityInput.setStoreNumber(storeNbr);
            fills.add(fillEligibilityInput);
        }

        FillEligibilityRequest fillEligibilityRequest = new FillEligibilityRequest();
        fillEligibilityRequest.setFills(fills);

        return fillEligibilityRequest;
    }

    private FillEligibilityRequest getFillEligibilityRequestPRedId(List<InputResponse> rfpRxs, int storeNbr){

        List<FillEligibilityInput> fills = new ArrayList<>();

        for(int i = 0; i<rfpRxs.size(); i++) {

            FillEligibilityInput fillEligibilityInput = new FillEligibilityInput();
            fillEligibilityInput.setInputType(FillEligibilityInput.InputTypeEnum.P_REF_ID);
            PRefId pRefId = new PRefId();
            pRefId.setStoreNumber(storeNbr);
            pRefId.setRxId((long) rfpRxs.get(i).getRxId());
            pRefId.setRxFillId((long) rfpRxs.get(i).getRxFillId());
            String encodedPRefId = RxpdUtils.getPRefIdString(pRefId);
            fillEligibilityInput.setPRefId(encodedPRefId);
            fills.add(fillEligibilityInput);
        }

        FillEligibilityRequest fillEligibilityRequest = new FillEligibilityRequest();
        fillEligibilityRequest.setFills(fills);

        return fillEligibilityRequest;
    }

    /**
     * Sequence of API call for Fill Eligibility FLow*
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs* *
     * delete created patient and rxs*
     */
    @BeforeClass
    void setContext() {
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(120);
    }

    @Test(enabled = true, priority = 1, description = "Fill Eligibility PRefId InputType CheckoutEligibility")
    void Fill_Eligibility_PRefId_Request_Checkout_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestPRedId(rfpRxs, STORE_NBR);
        logger.info("Fill Eligibility Request: " + fillEligibilityRequest);
        Reporter.logJSON("Fill Eligibility Request: ", fillEligibilityRequest);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(CHECKOUT_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 2, description = "Fill Eligibility Fill_Info InputType CheckoutEligibility")
    void Fill_Eligibility_Fill_Info_Request_Checkout_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(CHECKOUT_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 3, description = "Fill Eligibility Fill_Info InputType AddToCartEligibility")
    void Fill_Eligibility_Fill_Info_Request_Add_To_Cart_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(ADD_TO_CART_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 4, description = "Fill Eligibility PRefId InputType AddToCartEligibility")
    void Fill_Eligibility_PRefId_Request_Add_To_Cart_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestPRedId(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(ADD_TO_CART_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 5, description = "Fill Eligibility Fill_Info InputType ReadyNotificationEligibility")
    void Fill_Eligibility_Fill_Info_Request_Ready_Notification_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 6, description = "Fill Eligibility PRefId InputType ReadyNotificationEligibility")
    void Fill_Eligibility_PRefId_Request_Ready_Notification_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestPRedId(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
    }

    @Test(enabled = true, priority = 7, description = "Fill Eligibility Invalid queryParam")
    void Fill_Eligibility_Invalid_QueryParam() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestPRedId(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(INVALID_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(500, rxRulesEligibilityResponse.code());
    }

    @Test(enabled = true, priority = 8, description = "Fill Eligibility null queryParam")
    void Fill_Eligibility_Null_QueryParam() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestPRedId(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(null, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(500, rxRulesEligibilityResponse.code());
    }

    @Test(enabled = true, priority = 9, description = "Fill Eligibility AddToCartEligibility With Refrigerated ndcNbr ")
    void Fill_Eligibility_Add_To_Cart_Eligibility_Refrigerated_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00169643910"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(ADD_TO_CART_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
        Assert.assertTrue(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    @Test(enabled = true, priority = 10, description = "Fill Eligibility AddToCartEligibility With Reconstituted ndcNbr ")
    void Fill_Eligibility_Add_To_Cart_Eligibility_Reconstituted_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(ADD_TO_CART_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
        Assert.assertTrue(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    // TODO:: Once ndcNbr is available for IMZ Restriction Code. Uncomment the below test and change the ndcNbr

//    @Test(enabled = true, priority = 10, description = "Fill Eligibility AddToCartEligibility With IMZ Restriction Code ")
//    void Fill_Eligibility_Add_To_Cart_Eligibility_IMZ_Restriction_Code_ATC_Success() throws IOException {
//        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00006498100"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
//        am.performSleep(250);
//        String trackID = CommonUtil.randomUUID();
//        String reqId = reqIdString + trackID;
//        String reqTrackingId = reqTrackingString + trackID;
//        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
//        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(ADD_TO_CART_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
//        Assert.assertFalse(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
//    }


    @Test(enabled = true, priority = 11, description = "Fill Eligibility Ready Notification Eligibility With Refrigerated ndcNbr ")
    void Fill_Eligiility_Ready_Notification_Eligibility_Refrigerated_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00169643910"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
        Assert.assertTrue(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    @Test(enabled = true, priority = 12, description = "Fill Eligibility Ready Notification Eligibility With Reconstituted ndcNbr ")
    void Fill_Eligibility_Ready_Notification_Eligibility_Reconstituted_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
        Assert.assertTrue(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    /**
     * Tests fill eligibility for READY_NOTIFICATION with a lily drug
     */
    @Test(enabled = true, priority = 13, description = "Fill Eligibility Ready Notification Eligibility With Lily Drug ")
    void Fill_Eligibility_Ready_Notification_Eligibility_Lily_Drug_Eligible() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00002200204"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, rxRulesEligibilityResponse.code());
        Assert.assertNotNull(rxRulesEligibilityResponse.body());
        Assert.assertTrue(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }
    // TODO:: Once ndcNbr is available for IMZ Restriction Code. Uncomment the below test and change the ndcNbr

//    @Test(enabled = true, priority = 10, description = "Fill Eligibility Ready Notification Eligibility With IMZ Restriction Code ")
//    void Fill_Eligibility_Ready_Notification_Eligibility_IMZ_Restriction_Code_ATC_Success() throws IOException {
//        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00006498100"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
//        am.performSleep(250);
//        String trackID = CommonUtil.randomUUID();
//        String reqId = reqIdString + trackID;
//        String reqTrackingId = reqTrackingString + trackID;
//        FillEligibilityRequest fillEligibilityRequest = getFillEligibilityRequestFillInfo(rfpRxs, STORE_NBR);
//        Response<RxRulesEligibilityResponse> rxRulesEligibilityResponse = rxOrchestratorRetrofit.getFillEligibilityResponse(READY_NOTIFICATION_ELIGIBILITY_TYPE, fillEligibilityRequest, reqId, reqTrackingId);
//        Assert.assertFalse(rxRulesEligibilityResponse.body().getPayload().getFills().get(0).getEligibility().isEligible());
//    }

    /**
     * Method to delete patient and rx from informix*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
    }
}
