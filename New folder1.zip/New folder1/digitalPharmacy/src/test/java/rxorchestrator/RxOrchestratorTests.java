package rxorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxOrchestratorTests {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private final Gson gson = TestUtils.getConfiguredGson();
  private RxOrchestratorRetrofit rxOrchestratorRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
  }

  /** This test covers PetPrescriptionInfoLookup success case */
  @Test(
      priority = 0,
      description = "PetPrescriptionInfoLookup - Success",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "petPrescriptionInfoLookup")
  public void petPrescriptionInfoLookupSuccess(String petId, String payload, String statusCode)
      throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(petId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionLookupRequest request =
        objectMapper.readValue(payload, PrescriptionLookupRequest.class);

    // Step - 3: Populating request payload with rxNumber and storeNumber
    request.setRxNumber(request.getRxNumber());
    request.setStoreNumber(request.getStoreNumber());

    // Step - 4: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    Response<PetPrescriptionInfoLookupResponse> response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage =
        TestUtils.buildErrorMessageFromPetPrescriptionInfoLookupResponse(gson, response);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(response.body().getPayload().getRxNumber(), request.getRxNumber().toString());
    Assert.assertEquals(response.body().getPayload().getStoreNumber(), request.getStoreNumber());
  }

  /**
   * This test covers PetPrescriptionInfoLookup invalid request cases <br>
   * 1. PetId not UUID <br>
   * 2. Null rxNumber <br>
   * 3. Null storeNumber
   */
  @Test(
      priority = 0,
      description = "PetPrescriptionInfoLookup - Invalid request failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "petPrescriptionInfoLookup")
  public void petPrescriptionInfoLookupInvalidRequestFailure(
      String petId, String payload, String statusCode) throws IOException {

    // ***** CASE 1 - Invalid UUID PetId string *****
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(petId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionLookupRequest request =
        objectMapper.readValue(payload, PrescriptionLookupRequest.class);

    // Step - 3: Populating request payload with rxNumber and storeNumber
    request.setRxNumber(request.getRxNumber());
    request.setStoreNumber(request.getStoreNumber());
    // Step - 4: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    Response<PetPrescriptionInfoLookupResponse> response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 5: Getting error response
    Error errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 7: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-4002 - Invalid request payload received
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-4002");

    // ***** CASE 2 - Null rxNumber *****
    // Step - 1: Set rxNumber null
    request.setRxNumber(null);

    // Step - 2: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-4002 - Invalid request payload received
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-4002");

    // ***** CASE 3 - Null storeNumber *****
    // Step - 1: Set storeNumber null
    request.setRxNumber(request.getRxNumber());
    request.setStoreNumber(null);

    // Step - 2: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-4002 - Invalid request payload received
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-4002");
  }

  /**
   * This test covers PetPrescriptionInfoLookup when received no content from upstream(s) <br>
   * 1. DPAccountOrchestrator provides no content for pet information <br>
   * 2. PatientMart service provides no content for Rx information
   */
  @Test(
      priority = 0,
      description = "PetPrescriptionInfoLookup - No content from upstream failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "petPrescriptionInfoLookup")
  public void petPrescriptionInfoLookupNoContentFromUpstreamFailure(
      String petId, String payload, String statusCode) throws IOException {

    // ***** CASE 1 - Pet patient information doesn't exist in DPAccountOrchestrator *****
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(petId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionLookupRequest request =
        objectMapper.readValue(payload, PrescriptionLookupRequest.class);

    // Step - 3: Populating request payload with rxNumber and storeNumber
    request.setRxNumber(request.getRxNumber());
    request.setStoreNumber(request.getStoreNumber());

    // Step - 4: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    Response<PetPrescriptionInfoLookupResponse> response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 5: Getting error response
    Error errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 7: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-2004 - No pet information exists for given PetId
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-2004");

    // ***** CASE 2 - Prescription information doesn't exist in PatientMart *****
    // Step - 1: Setting non-existent rxNumber
    petId = "7baf5f61-09af-4a1e-ad3d-56d0f4169e91";
    request.setRxNumber(12345L);

    // Step - 2: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-10004 - Rx information missing for given request
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-10004");
  }

  /**
   * This test covers PetPrescriptionInfoLookup when patientLink in prescription from PatientMart is
   * not present in patientLinks of pet information from DPAccountOrchestrator
   */
  @Test(
      priority = 0,
      description =
          "PetPrescriptionInfoLookup - PetId unauthorized for prescription information failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "petPrescriptionInfoLookup")
  public void petPrescriptionInfoLookupPetIdUnauthorizedFailure(
      String petId, String payload, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(petId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionLookupRequest request =
        objectMapper.readValue(payload, PrescriptionLookupRequest.class);

    // Step - 3: Populating request payload with rxNumber and storeNumber
    request.setRxNumber(request.getRxNumber());
    request.setStoreNumber(request.getStoreNumber());

    // Step - 4: Calling the PetPrescriptionInfoLookup API to get pet prescription information
    Response<PetPrescriptionInfoLookupResponse> response =
        rxOrchestratorRetrofit.getPetPrescriptionInfo(petId, request, requestId, requestTrackingId);

    // Step - 5: Getting error response
    Error errorResponse = TestUtils.getPetPrescriptionInfoLookupErrorResponse(gson, response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 7: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1005 - PetId unauthorized for prescription information
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1005");
  }

  /** This test covers MultiplePetsRxLookup success case */
  @Test(
      priority = 0,
      description = "MultiplePetsRxLookup - Success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "multiplePetsRxLookup")
  public void multiplePetsRxLookupSuccess(String payload, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    // Step - 2: Preparing the request payload by mapping the JSON payload
    MultiplePetsRxLookupRequest request =
        objectMapper.readValue(payload, MultiplePetsRxLookupRequest.class);
    CommonUtil.logFlowIdentifiers(request.getPetIds(), requestId, requestTrackingId);

    // Step - 3: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    Response<MultiplePetsRxLookupResponse> response =
        rxOrchestratorRetrofit.getPrescriptionsForMultiplePets(
            request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        TestUtils.buildErrorMessageFromMultiplePetsRxLookupResponse(gson, response);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(response.body().getPayload().get(0).getPetId(), request.getPetIds().get(0));
  }

  /**
   * This test covers MultiplePetsRxLookup invalid request cases <br>
   * 1. Empty petIds list passed <br>
   * 2. More than 10 petIds passed <br>
   * 3. Any one PetId passed is not UUID
   */
  @Test(
      priority = 0,
      description = "MultiplePetsRxLookup - Invalid request failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "multiplePetsRxLookup")
  public void multiplePetsRxLookupInvalidRequestFailure(String payload, String statusCode)
      throws IOException {

    // *****  CASE 1 - Empty petIds list passed in the request *****
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    // Step - 2: Preparing the request payload by mapping the JSON payload
    MultiplePetsRxLookupRequest request =
        objectMapper.readValue(payload, MultiplePetsRxLookupRequest.class);
    CommonUtil.logFlowIdentifiers(request.getPetIds(), requestId, requestTrackingId);

    // Step - 3: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    Response<MultiplePetsRxLookupResponse> response =
        rxOrchestratorRetrofit.getPrescriptionsForMultiplePets(
            request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getMultiplePetsRxLookupErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 2 - More than 10 petIds passed in the request *****
    // Step - 1: Populating request payload with petIds more than 10
    List<String> petIds = new ArrayList<>();
    for (int i = 0; i < 15; i++) {
      petIds.add(CommonUtil.randomUUID());
    }
    request.setPetIds(petIds);

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.getPrescriptionsForMultiplePets(
            request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getMultiplePetsRxLookupErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 3 - If any one petId is not UUID *****
    // Step - 1: Set one invalid UUID
    petIds = new ArrayList<>();
    petIds.add("7baf5f61-09af-4a1e-ad3d-56d0f4169e91");
    petIds.add("zz3f5f61-09af-4a1e-ad3d-56d0f4169e91");
    request.setPetIds(petIds);

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.getPrescriptionsForMultiplePets(
            request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getMultiplePetsRxLookupErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");
  }

  /** This test covers MultiplePetsRxLookup when no content received from AccountOrchestrator */
  @Test(
      priority = 0,
      description = "MultiplePetsRxLookup - No content from AccountOrchestrator",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "multiplePetsRxLookup")
  public void multiplePetsRxLookupNoContentFromAccountOrchestrator(
      String payload, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    // Step - 2: Preparing the request payload by mapping the JSON payload
    MultiplePetsRxLookupRequest request =
        objectMapper.readValue(payload, MultiplePetsRxLookupRequest.class);
    CommonUtil.logFlowIdentifiers(request.getPetIds(), requestId, requestTrackingId);

    // Step - 3: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    Response<MultiplePetsRxLookupResponse> response =
        rxOrchestratorRetrofit.getPrescriptionsForMultiplePets(
            request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getMultiplePetsRxLookupErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(response.body().getPayload().get(0).getPrescriptions().size(), 0);
    Assert.assertEquals(response.body().getPayload().get(1).getPrescriptions().size(), 0);
  }

  /** This test covers RefillEligibility success case */
  @Test(
      priority = 0,
      description = "RefillEligibility - Success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "refillEligibility")
  public void refillEligibilitySuccess(
      String payload, String statusCode, String isEligibleForRefill) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    // Step - 2: Preparing the request payload by mapping the JSON payload
    RefillEligibilityRequest request =
        objectMapper.readValue(payload, RefillEligibilityRequest.class);

    // Step - 3: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    Response<RefillEligibilityServiceResponse> response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        TestUtils.buildErrorMessageFromRefillEligibilityServiceResponse(gson, response);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(
        response.body().getPayload().isIsEligibleForRefill().booleanValue(),
        Boolean.parseBoolean(isEligibleForRefill));
  }

  /**
   * This test covers RefillEligibility invalid request cases <br>
   * 1. RemainingRefills is null <br>
   * 2. OnlineRefillable is null <br>
   * 3. ExpiryDate is either null or empty <br>
   * 4. RxStatus is null or empty <br>
   * 5. ActiveFillPresent is null
   */
  @Test(
      priority = 0,
      description = "RefillEligibility - Invalid request failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "refillEligibility")
  public void refillEligibilityInvalidRequestFailure(String payload, String statusCode)
      throws IOException {

    // *****  CASE 1 - RemainingRefills is null *****
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    // Step - 2: Preparing the request payload by mapping the JSON payload and setting
    // RemainingRefills null
    RefillEligibilityRequest request =
        objectMapper.readValue(payload, RefillEligibilityRequest.class);
    request.setRemainingRefills(null);

    // Step - 3: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    Response<RefillEligibilityServiceResponse> response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getRefillEligibilityErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 2 - OnlineRefillable is null *****
    // Step - 1: Preparing the request payload by mapping the JSON payload and setting
    // OnlineRefillable null
    request = objectMapper.readValue(payload, RefillEligibilityRequest.class);
    request.setOnlineRefillable(null);

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getRefillEligibilityErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 3 - ExpiryDate is either null or empty *****
    // Step - 1: Preparing the request payload by mapping the JSON payload and setting ExpiryDate
    // empty
    request = objectMapper.readValue(payload, RefillEligibilityRequest.class);
    request.setExpiryDate("");

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getRefillEligibilityErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 4 - RxStatus is null or empty *****
    // Step - 1: Preparing the request payload by mapping the JSON payload and setting RxStatus
    // empty
    request = objectMapper.readValue(payload, RefillEligibilityRequest.class);
    request.setRxStatus("");

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getRefillEligibilityErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

    // ***** CASE 5 - ActiveFillPresent is null *****
    // Step - 1: Preparing the request payload by mapping the JSON payload and setting
    // ActiveFillPresent null
    request = objectMapper.readValue(payload, RefillEligibilityRequest.class);
    request.setActiveFillPresent(null);

    // Step - 2: Calling the MultiplePetsRxLookup API to get prescriptions of pets
    response =
        rxOrchestratorRetrofit.checkForRefillEligibility(request, requestId, requestTrackingId);

    // Step - 3: Getting error response
    errorResponse = TestUtils.getRefillEligibilityErrorResponse(gson, response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    // CHPR-DPRXORCH-1003 - Invalid input request. Please correct the request payload and try again
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");
  }
}
