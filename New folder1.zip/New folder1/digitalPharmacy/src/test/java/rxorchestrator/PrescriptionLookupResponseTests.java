package rxorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class PrescriptionLookupResponseTests {
  private final ObjectMapper objectMapper = new ObjectMapper();
  private final Gson gson = TestUtils.getConfiguredGson();
  private RxOrchestratorRetrofit rxOrchestratorRetrofit;

  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  public PrescriptionLookupResponseTests() throws IOException {
  }
  @BeforeClass
  void setContext() {
    rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
  }

  @Test(
          priority = 0,
          description = "Pyxis-RxHistory Mapping - SUCCESS",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void pyxisAndRxHistoryResponseTest(String payload, String statusCode, String customerAccountId, String domainId) throws Exception {

    // Parse the JSON data from files
    JSONParser parser = new JSONParser();
    Object prescriptionObj = parser.parse(new FileReader("src/test/resources/testdata/digitalpharmacy/rxorchestrator/prescriptionResponse.json"));
    Object refillsObj = parser.parse(new FileReader("src/test/resources/testdata/digitalpharmacy/rxorchestrator/refillsResponse.json"));

    // Extract data from the 'prescriptionResponse.json' JSON
    JSONObject prescriptionJsonObject = (JSONObject) prescriptionObj;
    JSONObject prescriptionPayload = (JSONObject) prescriptionJsonObject.get("payload");
    JSONArray customerPrescriptions = (JSONArray) prescriptionPayload.get("customerPrescriptions");
    JSONObject customerPrescriptionsObject = (JSONObject) customerPrescriptions.get(0);
    Boolean isDependent = (Boolean) customerPrescriptionsObject.get("isDependent");
    String onlineCustomerId = (String) customerPrescriptionsObject.get("onlineCustomerId");
    JSONObject customerinfo = (JSONObject) customerPrescriptionsObject.get("customerInfo");
    String firstName = (String) customerinfo.get("firstName");
    String lastName = (String) customerinfo.get("lastName");
    JSONArray prescriptionList = (JSONArray) customerPrescriptionsObject.get("prescriptionList");
    JSONObject prescriptionListObject = (JSONObject) prescriptionList.get(0);
    Long storePatientId = (Long) prescriptionListObject.get("storePatientId");
    Boolean compoundRx = (Boolean) prescriptionListObject.get("compoundRx");
    JSONObject storeNumber = (JSONObject) prescriptionListObject.get("storeNumber");
    String storeId = (String) storeNumber.get("storeId");
    Long remainingRefills = (Long) prescriptionListObject.get("numOfRemainingReFills");

    //Extract data from the 'refillResponse.json' JSON
    JSONObject refillsJsonObject = (JSONObject) refillsObj;
    JSONObject refillsPayload = (JSONObject) refillsJsonObject.get("payload");
    JSONArray customerRefillHistory = (JSONArray) refillsPayload.get("customerRefillHistory");
    JSONObject customerRefillHistoryObject = (JSONObject) customerRefillHistory.get(0);
    JSONArray refillHistory = (JSONArray) customerRefillHistoryObject.get("refillHistory");
    JSONObject refillHistoryObject = (JSONObject) refillHistory.get(0);
    String rxNumber = (String) refillHistoryObject.get("rxNumber");
    String refillId = (String) refillHistoryObject.get("refillId");
    Long ndcNum = (Long) refillHistoryObject.get("ndcNumber");
    Double refillQuantity = (Double) refillHistoryObject.get("refillQuantity");

    //Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    //Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest prescriptionsLookupRequest =
            objectMapper.readValue(payload, PrescriptionsLookupRequest.class);

    //Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, prescriptionsLookupRequest, requestId, requestTrackingId);

    //Building errorMessage in case the Assert for response fails
    String errorMessage =
            TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response);
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);


    List<CustomerPrescriptions> customerPrescription =response.body().getPayload().getCustomerPrescriptions();
    List<CustomerInfo> cInfoList = customerPrescription.stream().map(CustomerPrescriptions::getCustomerInfo).collect(Collectors.toList());

    // Checking if customerId is present same as pyxis response
    boolean customerIdCheck = cInfoList.stream().anyMatch(customerInfo -> {
      String cId = customerInfo.getCustomerId().toString();
      return onlineCustomerId.toString().equals(cId);
    });

    Assert.assertTrue(customerIdCheck, "Customer ID found in both response.");

    // Checking if isDependent is present same as pyxis response
    boolean isIsDependentCheck = cInfoList.stream().anyMatch(customerInfo -> {
      Boolean dependent = customerInfo.isIsDependent().booleanValue();
      return isDependent.equals(dependent);
    });

    Assert.assertTrue(isIsDependentCheck, "Is Dependent found in both response.");

    // Checking if firstName is present
    boolean firstNameCheck = cInfoList.stream().anyMatch(customerInfo -> {
      String fName = customerInfo.getFirstName();
      return firstName.equals(fName);
    });

    Assert.assertTrue(firstNameCheck,"First Name found in both response.");

    // Checking if lastName is present
    boolean lastNameCheck = cInfoList.stream().anyMatch(customerInfo -> {
      String lName = customerInfo.getLastName();
      return lastName.equals(lName);
    });

    Assert.assertTrue(lastNameCheck,"Last Name found in both response.");

    List<List<Prescription>> prescriptionInfoList = customerPrescription.stream().map(CustomerPrescriptions::getPrescriptions).collect(Collectors.toList());

    boolean storePatientCheck =
            prescriptionInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(prescriptions->{
                      Long storePId = prescriptions.getStorePatientId().longValue();
                      return storePatientId.equals(storePId);
                    });

    Assert.assertTrue(storePatientCheck, "Store Patient ID found in the response.");

    boolean storeNumberCheck =
            prescriptionInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(prescriptions->{
                      String storePId = prescriptions.getStoreNumber().toString();
                      return storeId.toString().equals(storePId);
                    });

    Assert.assertTrue(storeNumberCheck, "Store Number found in the response.");

    boolean compoundRxCheck =
            prescriptionInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(prescriptions->{
                      Boolean compoundRX = prescriptions.isCompoundRx().booleanValue();
                      return compoundRx.equals(compoundRX);
                    });

    Assert.assertTrue(compoundRxCheck, "Compound Rx found in the response.");

    boolean RemainingRefillCheck =
            prescriptionInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(prescriptions->{
                      String remainingrefills = prescriptions.getRemainingRefills().toString();
                        System.out.println("remainingrefills" + remainingrefills);
                      return remainingRefills.toString().equals(remainingrefills);
                    });

    Assert.assertTrue(RemainingRefillCheck, "Remaining Refill found in the response.");

    List<List<Fill>> refillInfoList = customerPrescription.stream().map(CustomerPrescriptions::getFills).collect(Collectors.toList());

    boolean rxNumberCheck =
            refillInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(refills->{
                      String RXNumber = refills.getRx().getRxNbr().toString();
                      return rxNumber.toString().equals(RXNumber);
                    });

    Assert.assertTrue(rxNumberCheck, "RX Number found in the response.");

    boolean refillIdCheck =
            refillInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(refills->{
                      String fillID = refills.getFillId().toString();
                      return refillId.toString().equals(fillID);
                    });

    Assert.assertTrue(refillIdCheck, "Refill ID found in the response.");

//    boolean ndcNumberCheck =
//            refillInfoList.stream()
//                    .flatMap(List::stream)
//                    .anyMatch(refills->{
//                      String NDCnum = refills.get.getNdcNumber().toString();
//                      return ndcNum.toString().equals(NDCnum);
//                    });

//    Assert.assertTrue(ndcNumberCheck, "NDC number found in the response.");

    boolean refillQuantityCheck =
            refillInfoList.stream()
                    .flatMap(List::stream)
                    .anyMatch(refills->{
                      String refillquantity = refills.getQuantity().toString();
                      return refillQuantity.toString().equals(refillquantity);
                    });

    Assert.assertTrue(refillQuantityCheck, "Refill Quantity found in the response.");

  }

}