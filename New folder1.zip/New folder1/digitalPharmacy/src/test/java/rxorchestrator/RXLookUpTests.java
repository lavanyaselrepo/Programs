package rxorchestrator;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.RXLookUp.RXLookUpErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.RXLookUp.RXLookUpResponse;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;


public class RXLookUpTests {

    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();




    @Test(description = "lookup Insurance with valid payload", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxValidTest(String payload, String description, String customerId, int statusCode, String rxNo_strNo, String coverageInfo, boolean lastFillPaidByCash, boolean doNotDiscloseInsuranceRestriction) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpResponse rxLookUpResponse = serRes.getDataResponse(RXLookUpResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response body of lookup-by-rx API for new fields of Insurance Handling
        DocumentContext jsonToParse = JsonPath.parse(payload);

        List<Object> noOfRx = jsonToParse.read("$.prescriptions");

        Assert.assertEquals("Requested number of Rx is not equal to returned number of Rx", noOfRx.size(), rxLookUpResponse.getPrescriptions().size());

        for (int i = 0; i < rxLookUpResponse.getPrescriptions().size(); i++) {

            String rxNo = rxLookUpResponse.getPrescriptions().get(i).getRxNumber();
            String storeNo = String.valueOf(rxLookUpResponse.getPrescriptions().get(i).getStoreNumber());
            Assert.assertTrue(rxNo_strNo.contains(rxNo + " - " + storeNo));
            int noOfCoverage = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().size();
            for (int j = 0; j < noOfCoverage; j++) {
                String cardHolderId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCardHolderId();
                String carrierId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCarrierId();
                String planId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getPlanId();
                String processorName = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getProcessorName();
                String category = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCategory();
                String applicationOrder = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getApplicationOrder();

                Assert.assertTrue(cardHolderId + " - " + carrierId + " - " + planId + " - " + processorName + " - " + category + " - " + applicationOrder + " should be there in response", coverageInfo.contains(cardHolderId + " - " + carrierId + " - " + planId + " - " + processorName + " - " + category + " - " + applicationOrder));

                Assert.assertEquals(rxLookUpResponse.getPrescriptions().get(i).getLastFillPaidByCash(),lastFillPaidByCash);
                Assert.assertEquals(rxLookUpResponse.getPrescriptions().get(i).getDoNotDiscloseInsuranceRestriction(),doNotDiscloseInsuranceRestriction);

            }
        }
    }

    @Test(description = "lookup Insurance with valid payload with multiple rx", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxValidTest_multipleRx(String payload, String description, String customerId, int statusCode, String rxNo_strNo, String coverageInfo, boolean lastFillPaidByCash, boolean doNotDiscloseInsuranceRestriction) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective ca  lls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpResponse rxLookUpResponse = serRes.getDataResponse(RXLookUpResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response body of lookup-by-rx API for new fields of Insurance Handling
        DocumentContext jsonToParse = JsonPath.parse(payload);

        List<Object> noOfRx = jsonToParse.read("$.prescriptions");

        Assert.assertEquals("Requested number of Rx is not equal to returned number of Rx", noOfRx.size(), rxLookUpResponse.getPrescriptions().size());

        for (int i = 0; i < rxLookUpResponse.getPrescriptions().size(); i++) {

            String rxNo = rxLookUpResponse.getPrescriptions().get(i).getRxNumber();
            String storeNo = String.valueOf(rxLookUpResponse.getPrescriptions().get(i).getStoreNumber());
            Assert.assertTrue(rxNo_strNo.contains(rxNo + " - " + storeNo));
            int noOfCoverage = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().size();
            for (int j = 0; j < noOfCoverage; j++) {
                String cardHolderId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCardHolderId();
                String carrierId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCarrierId();
                String planId = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getPlanId();
                String processorName = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getProcessorName();
                String category = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getCategory();
                String applicationOrder = rxLookUpResponse.getPrescriptions().get(i).getLastCoverageInfo().get(j).getApplicationOrder();

                Assert.assertTrue(cardHolderId + " - " + carrierId + " - " + planId + " - " + processorName + " - " + category + " - " + applicationOrder + " should be there in response", coverageInfo.contains(cardHolderId + " - " + carrierId + " - " + planId + " - " + processorName + " - " + category + " - " + applicationOrder));

                Assert.assertEquals(rxLookUpResponse.getPrescriptions().get(i).getLastFillPaidByCash(),lastFillPaidByCash);
                Assert.assertEquals(rxLookUpResponse.getPrescriptions().get(i).getDoNotDiscloseInsuranceRestriction(),doNotDiscloseInsuranceRestriction);

            }
        }
    }

    @Test(description = "rx as null", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest400_1(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpErrorResponse rxLookUpErrorResponse = serRes.getDataResponse(RXLookUpErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error response
        Assert.assertTrue(rxLookUpErrorResponse.getError().getCode().equals(errorCode));
        Reporter.logJSON("Error message", rxLookUpErrorResponse.getError().getMessage());

    }

    @Test(description = "store as null", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest400_2(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpErrorResponse rxLookUpErrorResponse = serRes.getDataResponse(RXLookUpErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error response
        Assert.assertTrue(rxLookUpErrorResponse.getError().getCode().equals(errorCode));
        Reporter.logJSON("Error message", rxLookUpErrorResponse.getError().getMessage());

    }


    @Test(description = "both rx and store as null", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest400_3(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpErrorResponse rxLookUpErrorResponse = serRes.getDataResponse(RXLookUpErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error response
        Assert.assertTrue(rxLookUpErrorResponse.getError().getCode().equals(errorCode));
        Reporter.logJSON("Error message", rxLookUpErrorResponse.getError().getMessage());

    }

    @Test(description = "sending text RX number", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest400_4(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpErrorResponse rxLookUpErrorResponse = serRes.getDataResponse(RXLookUpErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error response
        Assert.assertTrue(rxLookUpErrorResponse.getError().getCode().equals(errorCode));
        Reporter.logJSON("Error message", rxLookUpErrorResponse.getError().getMessage());

    }

    @Test(description = "valid Rx number not present in that store", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest_1(String payload, String customerId, int statusCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpResponse rxLookUpResponse = serRes.getDataResponse(RXLookUpResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response
        Assert.assertTrue("Prescription should be null for invalid request", rxLookUpResponse.getPrescriptions().size() == 0);

    }

    @Test(description = "valid Rx number with random store where it is not present", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest_2(String payload, String customerId, int statusCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpResponse rxLookUpResponse = serRes.getDataResponse(RXLookUpResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response
        Assert.assertTrue("Prescription should be null for invalid request", rxLookUpResponse.getPrescriptions().size() == 0);

    }

    @Test(description = "Rx from different store", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx", sheetName = "LookupByRX")
    public void lookUpByRxInvalidTest_3(String payload, String customerId, int statusCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling lookup-by-rx API
        ServiceResponse serRes = insuranceWrapper.RXLookUp(payload, customerId);
        RXLookUpResponse rxLookUpResponse = serRes.getDataResponse(RXLookUpResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response
        Assert.assertTrue("Prescription should be null for invalid request", rxLookUpResponse.getPrescriptions().size() == 0);

    }



}
