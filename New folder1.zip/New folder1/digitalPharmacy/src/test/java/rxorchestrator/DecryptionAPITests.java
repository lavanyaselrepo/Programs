package rxorchestrator;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.DecryptionRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.DecryptionResult;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.reqIdString;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.reqTrackingString;

public class DecryptionAPITests {

    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;

    private DecryptionRequest getDecryptionRequest(){

        List<String> offerIds = new ArrayList<>();

        for(int i = 0; i<5; i++){
            String offerId = RandomStringUtils.randomAlphanumeric(32).toUpperCase();
            offerIds.add(offerId);
        }
        DecryptionRequest decryptionRequest = new DecryptionRequest();
        decryptionRequest.setFieldType(DecryptionRequest.FieldTypeEnum.OFFERID);
        decryptionRequest.setEncryptionValues(offerIds);

        return decryptionRequest;
    }

    @BeforeClass
    void setContext(){
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    }

    @Test(enabled = true, priority = 1, description = "Decryption API success response")
    void Decryption_API_Success_Response() throws IOException {
        DecryptionRequest decryptionRequest = new DecryptionRequest();
        List<String> offerIds = new ArrayList<>();
        offerIds.add("IJ1mo00AId5Fw7N3ImA93BgDvb9k8greBitrMivv3OGJ6v7LKBXA78WTVwV3LoAUk1t7MXqdx4bgrY35X+xRoA==");
        offerIds.add("IJ1mo00AId5Fw7N3ImA93BgDvb9k8greBitrMivv3OGJ6v7LKBXA78WTVwV3LoAUk1t7MXqdx4bgrY35X+xRoA==");
        decryptionRequest.setFieldType(DecryptionRequest.FieldTypeEnum.OFFERID);
        decryptionRequest.setEncryptionValues(offerIds);
        System.out.println("decryptionRequest: " + decryptionRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<List<DecryptionResult>> response = rxOrchestratorRetrofit.getDecryptionAPIResponse(decryptionRequest, reqId, reqTrackingId);
        Assert.assertEquals(200, response.code());
        Assert.assertNotNull(response.body());
    }

    @Test(enabled = true, priority = 2, description = "Decryption API invalid request")
    void Decryption_API_Null_Request() throws IOException {
        DecryptionRequest decryptionRequest = new DecryptionRequest();
        decryptionRequest.setFieldType(DecryptionRequest.FieldTypeEnum.OFFERID);
        decryptionRequest.setEncryptionValues(Collections.singletonList(null));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<List<DecryptionResult>> response = rxOrchestratorRetrofit.getDecryptionAPIResponse(decryptionRequest, reqId, reqTrackingId);
        Assert.assertEquals(400, response.code());
    }

}
