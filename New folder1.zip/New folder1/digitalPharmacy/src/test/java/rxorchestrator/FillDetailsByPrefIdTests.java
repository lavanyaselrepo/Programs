package rxorchestrator;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillDetailsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.StatusDetails;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillDetailsWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;

public class FillDetailsByPrefIdTests {

    WrapperUtils wrapperUtils=new WrapperUtils();
    private FillDetailsWrapper fillDetailsWrapper;
    PropertyReader prop = PropertyReader.getInstance();
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    private List<InputResponse> fillingRxs;
    private int storeNbr;
    private final String patientFirstName = FillDetailsWrapper.PATIENT_FIRST_NAME;
    private final String patientLastName = FillDetailsWrapper.PATIENT_LAST_NAME;
    private final String patientDob = FillDetailsWrapper.PATIENT_DOB;
    private final String patientEmailId = FillDetailsWrapper.PATIENT_EMAILID;
    private final String patientDotComPass = prop.getProperty("PATIENT_DOT_COM_PASS");
    private final String patientCid = FillDetailsWrapper.PATIENT_CID;
    private final Integer patientId = FillDetailsWrapper.PATIENT_PATIENTID;
    private final List<String> ndcList = Arrays.asList("68382056510");
    private String DOMAIN_ID = "WM-PHARMACY";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private String INVALID_ACCOUNT_ID = "331ee47f-42cc-4a24-9869-f130b61bbf4e";
    private Integer NUM_OF_RXS_NEEDED = 1;

    @BeforeClass
    void setContext() {
        fillDetailsWrapper = new FillDetailsWrapper();
        storeNbr = Integer.parseInt(prop.getProperty("store.number"));
        rxpdUtils = new RxpdUtils(storeNbr,  patientFirstName, patientLastName, patientDob, 1, patientEmailId, patientDotComPass);
    }

    @Test(priority = 1,
            description = "Fill Details By PRefId with future promised time, in resolution queue and status=FILLING")
    void Fill_Details_For_Filling_Status_Rxs() throws InterruptedException {
        rfpRxs = rxpdUtils.fillingGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        List<String> pRefIds = rxpdUtils.getPRefIds(rfpRxs, storeNbr);
        List<Integer> orderIds = rfpRxs.stream().map(InputResponse::getOrderId).collect(Collectors.toList());
        List<Integer> rxIds = rfpRxs.stream().map(InputResponse::getRxId).collect(Collectors.toList());
        for (int i = 0; i < pRefIds.size(); i++) {
            String pRefId = pRefIds.get(i);
            System.out.println("pRefId: " + pRefId);
            int orderId = orderIds.get(i);
            System.out.println("orderId: " + orderId);
            int rxId = rxIds.get(i);
            System.out.println("rxId: " + rxId);
            int count = 0;
            // trying every 30 seconds upto 4 minutes - data sync delay with TDC
            int maxAttempt = 8;
            boolean isFilling = false;

            int updateWorkQueueResponse = fillDetailsWrapper.getUpdateWorkQueueToResolutionQuery(storeNbr, orderId);
            Assert.assertEquals(1, updateWorkQueueResponse);
            int insertOrdDtlProblemResponse = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 1, 1008, rxId);
            Assert.assertEquals(1, insertOrdDtlProblemResponse);

            while(!isFilling && count < maxAttempt) {
                ServiceResponse serviceResponse = fillDetailsWrapper.getFillDetails(patientCid, pRefId);
                Assert.assertNotNull(serviceResponse);
                if(serviceResponse.getStatusCode() != 200) {
                    Thread.sleep(30000);
                    count++;
                    continue;
                }
                System.out.println("response: " + serviceResponse.getDataResponse());

                FillDetailsResponse fillDetailsResponse = serviceResponse.getDataResponse(FillDetailsResponse.class);
                Assert.assertNotNull(fillDetailsResponse);
                StatusDetails statusDetails = fillDetailsResponse.getPayload().getFill().getStatusDetails();
                Assert.assertNotNull(statusDetails);

                if("FILLING".equals(statusDetails.getStatus())) {
                    isFilling = true;
                } else {
                    Thread.sleep(30000);
                    count++;
                }
                //Asserting lunch hours
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore());
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
                fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
                });
            }
        }

        rxpdUtils.deleteRxs(rfpRxs);
    }

    @Test(priority = 1,
            description = "Fill Details By PRefId with future promised time, in resolution queue and status=DELAYED, reason=PENDING_PROVIDER_AUTH")
    void Fill_Details_For_Delayed_Pending_Auth_Status_Rxs() throws InterruptedException {
        rfpRxs = rxpdUtils.fillingGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        List<String> pRefIds = rxpdUtils.getPRefIds(rfpRxs, storeNbr);
        List<Integer> orderIds = rfpRxs.stream().map(InputResponse::getOrderId).collect(Collectors.toList());
        List<Integer> rxIds = rfpRxs.stream().map(InputResponse::getRxId).collect(Collectors.toList());
        for (int i = 0; i < pRefIds.size(); i++) {
            String pRefId = pRefIds.get(i);
            System.out.println("pRefId: " + pRefId);
            int orderId = orderIds.get(i);
            System.out.println("orderId: " + orderId);
            int rxId = rxIds.get(i);
            System.out.println("rxId: " + rxId);
            int count = 0;
            // trying every 30 seconds upto 4 minutes - data sync delay with TDC
            int maxAttempt = 8;
            boolean isPendingProviderAuth = false;

            int updateWorkQueueResponse = fillDetailsWrapper.getUpdateWorkQueueToResolutionQuery(storeNbr, orderId);
            Assert.assertEquals(1, updateWorkQueueResponse);

            int insertProblem1008Response = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 1, 1008, rxId);
            Assert.assertEquals(1, insertProblem1008Response);
            int insertProblem1009Response = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 2, 1009, rxId);
            Assert.assertEquals(1, insertProblem1009Response);

            while(!isPendingProviderAuth && count < maxAttempt) {
                ServiceResponse serviceResponse = fillDetailsWrapper.getFillDetails(patientCid, pRefId);
                Assert.assertNotNull(serviceResponse);
                if(serviceResponse.getStatusCode() != 200) {
                    Thread.sleep(30000);
                    count++;
                    continue;
                }
                System.out.println("response: " + serviceResponse.getDataResponse());

                FillDetailsResponse fillDetailsResponse = serviceResponse.getDataResponse(FillDetailsResponse.class);
                Assert.assertNotNull(fillDetailsResponse);
                System.out.println("fillDetailsResponse: " + fillDetailsResponse);
                StatusDetails statusDetails = fillDetailsResponse.getPayload().getFill().getStatusDetails();
                Assert.assertNotNull(statusDetails);
                System.out.println("statusDetails: " + statusDetails.getStatus());

                if("DELAYED".equals(statusDetails.getStatus()) && "PendingProviderAuth".equals(statusDetails.getDelayedDetails().getReason())) {
                    isPendingProviderAuth = true;
                } else {
                    Thread.sleep(30000);
                    count++;
                }
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore());
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
                fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
                });
            }
        }

        rxpdUtils.deleteRxs(rfpRxs);
    }

    @Test(priority = 1,
            description = "Fill Details By PRefId with future promised time, in resolution queue and status=DELAYED, reason=GENERIC_DELAY")
    void Fill_Details_For_Delayed_Generic_Delay_Status_Rxs() throws InterruptedException {
        rfpRxs = rxpdUtils.fillingGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        List<String> pRefIds = rxpdUtils.getPRefIds(rfpRxs, storeNbr);
        List<Integer> orderIds = rfpRxs.stream().map(InputResponse::getOrderId).collect(Collectors.toList());
        List<Integer> rxIds = rfpRxs.stream().map(InputResponse::getRxId).collect(Collectors.toList());
        for (int i = 0; i < pRefIds.size(); i++) {
            String pRefId = pRefIds.get(i);
            System.out.println("pRefId: " + pRefId);
            int orderId = orderIds.get(i);
            System.out.println("orderId: " + orderId);
            int rxId = rxIds.get(i);
            System.out.println("rxId: " + rxId);
            int count = 0;
            // trying every 30 seconds upto 4 minutes - data sync delay with TDC
            int maxAttempt = 8;
            boolean isGenericDelayed = false;

            int updateWorkQueueResponse = fillDetailsWrapper.getUpdateWorkQueueToResolutionQuery(storeNbr, orderId);
            Assert.assertEquals(1, updateWorkQueueResponse);

            int insertProblem1008Response = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 1, 1008, rxId);
            Assert.assertEquals(1, insertProblem1008Response);
            int insertProblem1009Response = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 2, 1009, rxId);
            Assert.assertEquals(1, insertProblem1009Response);
            int insertProblem3012Response = fillDetailsWrapper.getInsertRxOrderDetailProblemQuery(storeNbr, orderId, 3, 3012, rxId);
            Assert.assertEquals(1, insertProblem3012Response);

            while(!isGenericDelayed && count < maxAttempt) {
                ServiceResponse serviceResponse = fillDetailsWrapper.getFillDetails(patientCid, pRefId);
                Assert.assertNotNull(serviceResponse);

                if(serviceResponse.getStatusCode() != 200) {
                    Thread.sleep(300000);
                    count++;
                    continue;
                }
                System.out.println("response: " + serviceResponse.getDataResponse());

                FillDetailsResponse fillDetailsResponse = serviceResponse.getDataResponse(FillDetailsResponse.class);
                Assert.assertNotNull(fillDetailsResponse);
                System.out.println("fillDetailsResponse: " + fillDetailsResponse);
                StatusDetails statusDetails = fillDetailsResponse.getPayload().getFill().getStatusDetails();
                Assert.assertNotNull(statusDetails);
                System.out.println("statusDetails: " + statusDetails.getStatus());

                if("DELAYED".equals(statusDetails.getStatus()) && "DelayedGeneric".equals(statusDetails.getDelayedDetails().getReason())) {
                    isGenericDelayed = true;
                } else {
                    Thread.sleep(300000);
                    count++;
                }
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore());
                Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
                fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                    Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
                });
            }
        }

        rxpdUtils.deleteRxs(rfpRxs);
    }
}
