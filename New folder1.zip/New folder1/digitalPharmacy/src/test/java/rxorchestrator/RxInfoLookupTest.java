package rxorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.RxLookupRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.RxLookupServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import java.io.File;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxInfoLookupTest {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private final Gson gson = TestUtils.getConfiguredGson();
  private RxOrchestratorRetrofit rxOrchestratorRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
  }

  /** This test covers success case scenario for the */
  @Test(priority = 0, description = "RxInfo lookup in patient mart success case")
  public void rxInfoLookupSuccess() throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    RxLookupRequest rxLookupRequest =
        objectMapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/rxorchestrator/rxInfoLookup/rxInfoLookupPayload.json"),
            RxLookupRequest.class);

    // Step-3: Calling rxLookup Api to get the response
    Response<RxLookupServiceResponse> response =
        rxOrchestratorRetrofit.doRxlookup(rxLookupRequest, requestId, requestTrackingId);

    // Step - 4 Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildErrorMessageFromRxLookupServiceResponse(gson, response);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), 200, errorMessage);
    Assert.assertEquals(
        response.body().getPayload().getRxNumber().toString(), rxLookupRequest.getRxNumber());
    Assert.assertEquals(
        response.body().getPayload().getStoreNumber(), rxLookupRequest.getStoreNumber());
  }

  /** This test covers invalid request case 1. RxNumber is not valid in this case */
  @Test(priority = 1, description = "RxInfo lookup in patient mart failure case")
  public void rxInfoLookupFailure() throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    RxLookupRequest rxLookupRequest =
        objectMapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/rxorchestrator/rxInfoLookup/rxInfoLookupPayload.json"),
            RxLookupRequest.class);
    rxLookupRequest.setRxNumber("663805");
    // Step - 3: Calling rxLookup Api to get the response
    Response<RxLookupServiceResponse> response =
        rxOrchestratorRetrofit.doRxlookup(rxLookupRequest, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    Error errorResponse = TestUtils.getRxInfoLookupErrorResponse(gson, response);
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-10004");
  }

  /** This test covers invalid request case 1. RxNumber is empty in this case */
  @Test(priority = 2, description = "RxInfo lookup in patient mart for empty rxNumber case")
  public void rxInfoLookupEmptyRxNumber() throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;

    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    RxLookupRequest rxLookupRequest =
        objectMapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/rxorchestrator/rxInfoLookup/rxInfoLookupPayload.json"),
            RxLookupRequest.class);
    rxLookupRequest.setRxNumber("");
    // Step - 3: Calling rxLookup Api to get the response
    Response<RxLookupServiceResponse> response =
        rxOrchestratorRetrofit.doRxlookup(rxLookupRequest, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    Error errorResponse = TestUtils.getRxInfoLookupErrorResponse(gson, response);
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");
  }
}
