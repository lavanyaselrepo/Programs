package rxorchestrator;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.EcomFillEventRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.PRefId;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class EcomFillEventAPITests {
    private static final Logger logger = LoggerFactory.getLogger(EcomFillEventAPITests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    AutomationManager am = AutomationManager.getInstance();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;

    private List<InputResponse> rfpRxs;
    private String cid;
    private Integer patientId;
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;

    private EcomFillEventRequest getEcomFillEventRequest(List<InputResponse> inputResponses, int storeNbr){

        List<String> pRefIds = new ArrayList<>();

        for(int i = 0; i<inputResponses.size(); i++){
            InputResponse inputResponse = inputResponses.get(i);
            int rxId = inputResponse.getRxId();
            int rxFillId = inputResponse.getRxFillId();
            PRefId pRefId = new PRefId();
            pRefId.setStoreNumber(storeNbr);
            pRefId.setRxId((long) rxId);
            pRefId.setRxFillId((long) rxFillId);
            String encodedPRefId = RxpdUtils.getPRefIdString(pRefId);
            pRefIds.add(encodedPRefId);
        }
        EcomFillEventRequest ecomFillEventRequest = new EcomFillEventRequest();
        ecomFillEventRequest.setPRefIds(pRefIds);

        return ecomFillEventRequest;
    }

    /**
     * Sequence of API call to execute Ecom Fill Event Flow *
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * delete created patient and rxs*
     */
    @BeforeClass
    void setContext(){
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        logger.info("Ecom Fill Event cid: " + cid);
        Reporter.logJSON("Ecom Fill Event cid: ", cid);
        am.performSleep(180);
    }

    @Test(enabled = true, priority = 1, description = "EcomFillEnevt API successful response")
    void Ecom_Fill_Event_Success_Response() throws IOException {
        EcomFillEventRequest ecomFillEventRequest = getEcomFillEventRequest(rfpRxs, STORE_NBR);
        logger.info("Ecom Fill Event Request: " + ecomFillEventRequest);
        Reporter.logJSON("Ecom Fill Event Request: ", ecomFillEventRequest);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<Void> response = rxOrchestratorRetrofit.getEcomFillEventsResponse(cid, ecomFillEventRequest, reqId, reqTrackingId, "CHECKOUT");
        Assert.assertEquals(201, response.code());
    }

    @Test(enabled = true, priority = 3, description = "EcomFillEnevt API null queryParam")
    void Ecom_Fill_Event_Null_QueryParam() throws IOException {
        EcomFillEventRequest ecomFillEventRequest = getEcomFillEventRequest(rfpRxs, STORE_NBR);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<Void> response = rxOrchestratorRetrofit.getEcomFillEventsResponse(cid, ecomFillEventRequest, reqId, reqTrackingId, null);
        Assert.assertEquals(400, response.code());
    }

    @Test(enabled = true, priority = 4, description = "EcomFillEnevt API invalid queryParam")
    void Ecom_Fill_Event_Invalid_QueryParam() throws IOException {
        EcomFillEventRequest ecomFillEventRequest = getEcomFillEventRequest(rfpRxs, STORE_NBR);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<Void> response = rxOrchestratorRetrofit.getEcomFillEventsResponse(cid, ecomFillEventRequest, reqId, reqTrackingId, "CHECK");
        Assert.assertEquals(400, response.code());

    }

    @Test(enabled = true, priority = 5, description = "EcomFillEnevt API null requestBody")
    void Ecom_Fill_Event_Null_RequestBody() throws IOException {
        EcomFillEventRequest ecomFillEventRequest = new EcomFillEventRequest();
        ecomFillEventRequest.setPRefIds(Collections.emptyList());
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<Void> response = rxOrchestratorRetrofit.getEcomFillEventsResponse(cid, ecomFillEventRequest, reqId, reqTrackingId, "CHECK");
        Assert.assertEquals(400, response.code());
    }

    @Test(enabled = true, priority = 6, description = "EcomFillEnevt API invalid queryParam")
    void Ecom_Fill_Event_Invalid_PRefId() throws IOException {
        EcomFillEventRequest ecomFillEventRequest = new EcomFillEventRequest();
        ecomFillEventRequest.setPRefIds(Arrays.asList(INVALID_PREFID));
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Response<Void> response = rxOrchestratorRetrofit.getEcomFillEventsResponse(cid, ecomFillEventRequest, reqId, reqTrackingId, "CHECK");
        Assert.assertEquals(400, response.code());
    }

    /**
     * Method to delete patient and rx from informix*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
    }

}
