package rxorchestrator;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class FillSummaryTests {
    private static final Logger logger = LoggerFactory.getLogger(FillSummaryTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    private FillSummaryWrapper fillSummaryWrapper;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    List<InputResponse> fillingRxs;
    private RxpdUtils rxpdUtils;
    HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs;
    private List<InputResponse> rfpRxs;
    private String cid;
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    AutomationManager am = AutomationManager.getInstance();
    private Integer patientId;
    private String DOMAIN_ID = "WM-PHARMACY";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;
    private final Gson gson = TestUtils.getConfiguredGson();

    /**
     * Sequence of API call for Fill Summary Flow*
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * create filling rxs*
     * create cancelled rxs*
     * delete created patient and rxs*
     * @throws IOException
     */
    @BeforeClass
    void setContext() throws IOException {
        fillSummaryWrapper = new FillSummaryWrapper();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));

        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);

        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        logger.info("Fill Summary CID: " + cid);
        Reporter.logJSON("Fill Summary CID: ", cid);
        am.performSleep(180);
    }

    @Test(enabled = true, priority = 1, description = "Fill Summaries success response")
    void Fill_Summary_RFP_Rxs_Success_Response(){

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());

        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());

        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            apiResponse.getStores().get(i).getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }

    }

    @Test(enabled = true, priority = 1, description = "Fill Summaries success response")
    void Fill_Summary_RFP_Rxs_Success_Response_Refrigerated_ndcNbr(){
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00052027303"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());

        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());

        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            apiResponse.getStores().get(i).getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }

    }

    @Test(enabled = true, priority = 1, description = "Fill Summaries success response")
    void Fill_Summary_RFP_Rxs_Success_Response_Reconstituted_ndcNbr(){
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());

        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());

        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            apiResponse.getStores().get(i).getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }

    }

    @Test(enabled = true, priority = 1, description = "Fill Summaries response with lily drug")
    void Fill_Summary_RFP_Rxs_Success_Response_Lily_Drug_Present(){
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00002200204"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);
        Assert.assertTrue(readyForPickup.getAddToCartEligibility().isEligible());
    }

    @Test(enabled = true, priority = 5, description = "Fill Summaries success response")
    void Fill_Summary_Filling_Rxs_Success_Response(){

        fillingRxs = rxpdUtils.fillingGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        am.performSleep(120);

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        Filling fillingRxs = apiResponse.getCustomer().getFills().getFilling().get(0);

        // For filling rxs
        Assert.assertNotNull(fillingRxs.getPRefId());
        Assert.assertNotNull(fillingRxs.getImageUrl());
        Assert.assertNotNull(fillingRxs.getPatientId());
        Assert.assertNotNull(fillingRxs.getStoreId());

        Assert.assertNotNull(fillingRxs.getDrug().getName());
        Assert.assertNotNull(fillingRxs.getDrug().getNdcNumber());
        Assert.assertNotNull(fillingRxs.getFillId());

        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            apiResponse.getStores().get(i).getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }

    }

    @Test(enabled = true, priority = 1, description = "Fill Summaries success response")
    void Fill_Summary_Cancelled_Rxs_Success_Response(){

        cancelledRxs = rxpdUtils.cancelledGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(300);

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        Cancelled delayedRxs = apiResponse.getCustomer().getFills().getCancelled().get(0);

        //For cancelled rxs
        Assert.assertNotNull(delayedRxs.getPRefId());
        Assert.assertNotNull(delayedRxs.getImageUrl());
        Assert.assertNotNull(delayedRxs.getPatientId());
        Assert.assertNotNull(delayedRxs.getStoreId());

        Assert.assertNotNull(delayedRxs.getDrug().getName());
        Assert.assertNotNull(delayedRxs.getDrug().getNdcNumber());
        Assert.assertNotNull(delayedRxs.getFillId());
        Assert.assertNotNull(delayedRxs.getReason());


        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            apiResponse.getStores().get(i).getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }
    }

    /*
    Commented out tests with static data for future reference
     */

//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Scan to refill - adult", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_1(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop 3 prescriptions and move to EOD for the patient
//        2. do a scan to refill for each
//        3. Move the fill to RFP,Filling and Delayed (past promised time) state respectively
//        4. update the rx details to validate in excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(", ").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult nodotcomaccount, guest scan", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_2(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop a prescription for a patient without dotcomaccount and move to EOD
//        2. Create a refill
//        3. Move the fill to Delayed state- can be any reason
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        for (int i = 0; i < fillSummaryResponse.getStores().size(); i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult without depenedent- RFP,FILLING,DELAYED", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_3(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop 3 prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to RFP,FILLING ,Delayed state- can be any reason
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult Delayed", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_4(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop a prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to Delayed state- can be any reason
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult RFP and Filling", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_5(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to RFP,FILLING
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult RFP and Delayed", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_6(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to RFP,Delayed state- can be any reason
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult Filling and Delayed", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_7(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to FILLING ,Delayed state- can be any reason
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult RFP and Delayed- PastPromisedTime", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_8(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop 2 prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to RFP ,Delayed state- PastPromisedTime
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Adult Delayed- Expired Rx, Call Dr. -PendingProviderAuth", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_9(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to Delayed state- Delay call dr, ExpiredRx
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient based upon filling status- Scan to Refill Adult Delayed- DelayedGeneric, PendingProviderAuth, PastPromisedTime", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithoutDependents_10(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String fillingDetails, String delayedDetails, String readyForPickupDetails ) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and move to EOD
//        2. Create refill
//        3. Move the fill to Delayed state- Delay call dr, ExpiredRx
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue("Status code did not match", serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling,fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" should not be in the response",fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common across all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" should not be in the response",delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//            }
//
//        }
//
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//
//        }
//
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient with dependents based upon filling status- Adult dependent with RFP fill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithDependents_1(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String dependtCustomerId, String dependt_fillingStatus, String dependtPatientId_dependtStoreId, String dependtType, String fillingDetails, String delayedDetails, String readyForPickupDetails, String dependt_fillingDetails, String dependt_delayedDetails, String dependt_readyForPickupDetails) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and dependent and move to EOD
//        2. Place refill
//        3. Move the fill to RFP state- dependent
//        4. move fill for caregiver toRFP and Delayed
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details for customer
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //  Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling, fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response", delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//                }
//        }
//        // Step - 5: Validate fill summary details for dependents
//        int noOfDependents = fillSummaryResponse.getDependents().size();
//        for (int i = 0; i < noOfDependents; i++) {
//            if (dependtType.equalsIgnoreCase(fillSummaryResponse.getDependents().get(i).getDependentType())) {
//
//                Assert.assertEquals(dependtCustomerId, fillSummaryResponse.getDependents().get(i).getCustomerId());
//                Assert.assertEquals(dependtType, fillSummaryResponse.getDependents().get(i).getDependentType());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getFirstName());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getLastName());
//
//                if (dependt_fillingStatus.contains("READY_FOR_PICKUP")) {
//                    int noOfRxForPickup = fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().size();
//                    Assert.assertEquals(noOfRxForPickup,dependt_readyForPickupDetails.split(",").length);
//                    for (int j = 0; j < noOfRxForPickup; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getImageUrl());
//                        String dependtPatientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPatientId());
//                        String dependtStoreId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(dependtPatientId + "-" + dependtStoreId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getFillId());
//                        String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getPatientDueAmt());
//                        String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getEstimatedPrice());
//
//                        Assert.assertTrue(dependt_readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getCurrency());
//
//                    }
//                }
//
//                if (dependt_fillingStatus.contains("FILLING")) {
//                    int noOfRxFilling = fillSummaryResponse.getDependents().get(i).getFills().getFilling().size();
//                    Assert.assertEquals(noOfRxFilling,dependt_fillingDetails.split(",").length);
//                    for (int j = 0; j < noOfRxFilling; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//                        //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                        if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                        {
//                            Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                            Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                        }
//
//                        else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                        {
//                            String drugName= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getName();
//                            String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getNdcNumber();
//                            String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getFillId());
//                            String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getPatientDueAmt());
//                            String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getEstimatedPrice());
//                            String fillStatus= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus();
//
//                            Assert.assertTrue(dependt_fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" - "+fillStatus));
//
//                            Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getCurrency());
//                        }
//                    }
//                }
//                if (dependt_fillingStatus.contains("DELAYED")) {
//                    int noOfRxDelayed = fillSummaryResponse.getDependents().get(i).getFills().getDelayed().size();
//                    Assert.assertEquals(noOfRxDelayed,dependt_delayedDetails.split(",").length);
//                    for (int j = 0; j < noOfRxDelayed; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getFillId());
//                        String delayReason = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getReason());
//
//                        Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response",dependt_delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//                    }
//
//                }
//            }
//        }
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//        }
//
//
//    }
//
//
//    @Test(description = "validate Fill Summary details for a patient with dependents based upon filling status- Delayed fill with Pet dependent", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithDependents_2(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String dependtCustomerId, String dependt_fillingStatus, String dependtPatientId_dependtStoreId, String dependtType, String fillingDetails, String delayedDetails, String readyForPickupDetails, String dependt_fillingDetails, String dependt_delayedDetails, String dependt_readyForPickupDetails) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and pet dependent and move to EOD
//        2. Place refill
//        3. Move the fill to Delayed state- dependent
//        4. move fill for caregiver toRFP and Delayed
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details for customer
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //  Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling, fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response", delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//            }
//        }
//        // Step - 5: Validate fill summary details for dependents
//        int noOfDependents = fillSummaryResponse.getDependents().size();
//        for (int i = 0; i < noOfDependents; i++) {
//            if (dependtType.equalsIgnoreCase(fillSummaryResponse.getDependents().get(i).getDependentType())) {
//
//                Assert.assertEquals(dependtCustomerId, fillSummaryResponse.getDependents().get(i).getCustomerId());
//                Assert.assertEquals(dependtType, fillSummaryResponse.getDependents().get(i).getDependentType());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getFirstName());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getLastName());
//
//                if (dependt_fillingStatus.contains("READY_FOR_PICKUP")) {
//                    int noOfRxForPickup = fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().size();
//                    Assert.assertEquals(noOfRxForPickup,dependt_readyForPickupDetails.split(",").length);
//                    for (int j = 0; j < noOfRxForPickup; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getImageUrl());
//                        String dependtPatientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPatientId());
//                        String dependtStoreId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(dependtPatientId + "-" + dependtStoreId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getFillId());
//                        String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getPatientDueAmt());
//                        String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getEstimatedPrice());
//
//                        Assert.assertTrue(dependt_readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getCurrency());
//
//                    }
//                }
//
//                if (dependt_fillingStatus.contains("FILLING")) {
//                    int noOfRxFilling = fillSummaryResponse.getDependents().get(i).getFills().getFilling().size();
//                    Assert.assertEquals(noOfRxFilling,dependt_fillingDetails.split(",").length);
//                    for (int j = 0; j < noOfRxFilling; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//                        //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                        if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                        {
//                            Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                            Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                        }
//
//                        else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                        {
//                            String drugName= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getName();
//                            String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getNdcNumber();
//                            String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getFillId());
//                            String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getPatientDueAmt());
//                            String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getEstimatedPrice());
//                            String fillStatus= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus();
//
//                            Assert.assertTrue(dependt_fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" - "+fillStatus));
//
//                            Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getCurrency());
//                        }
//                    }
//                }
//                if (dependt_fillingStatus.contains("DELAYED")) {
//                    int noOfRxDelayed = fillSummaryResponse.getDependents().get(i).getFills().getDelayed().size();
//                    Assert.assertEquals(noOfRxDelayed,dependt_delayedDetails.split(",").length);
//                    for (int j = 0; j < noOfRxDelayed; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getFillId());
//                        String delayReason = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getReason());
//
//                        Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response",dependt_delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//                    }
//
//                }
//            }
//        }
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//        }
//
//
//    }
//
//
//    @Test(description = "validate Fill Summary details for a patient with dependents based upon filling status- Delayed fill with minor dependent", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithDependents_3(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String dependtCustomerId, String dependt_fillingStatus, String dependtPatientId_dependtStoreId, String dependtType, String fillingDetails, String delayedDetails, String readyForPickupDetails, String dependt_fillingDetails, String dependt_delayedDetails, String dependt_readyForPickupDetails) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and minor dependent and move to EOD
//        2. Place refill
//        3. Move the fill to RFP state- dependent
//        4. move fill for caregiver toRFP and Delayed
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details for customer
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //  Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling, fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response", delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//            }
//        }
//        // Step - 5: Validate fill summary details for dependents
//        int noOfDependents = fillSummaryResponse.getDependents().size();
//        for (int i = 0; i < noOfDependents; i++) {
//            if (dependtType.equalsIgnoreCase(fillSummaryResponse.getDependents().get(i).getDependentType())) {
//
//                Assert.assertEquals(dependtCustomerId, fillSummaryResponse.getDependents().get(i).getCustomerId());
//                Assert.assertEquals(dependtType, fillSummaryResponse.getDependents().get(i).getDependentType());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getFirstName());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getLastName());
//
//                if (dependt_fillingStatus.contains("READY_FOR_PICKUP")) {
//                    int noOfRxForPickup = fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().size();
//                    Assert.assertEquals(noOfRxForPickup,dependt_readyForPickupDetails.split(",").length);
//                    for (int j = 0; j < noOfRxForPickup; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getImageUrl());
//                        String dependtPatientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPatientId());
//                        String dependtStoreId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(dependtPatientId + "-" + dependtStoreId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getFillId());
//                        String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getPatientDueAmt());
//                        String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getEstimatedPrice());
//
//                        Assert.assertTrue(dependt_readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getCurrency());
//
//                    }
//                }
//
//                if (dependt_fillingStatus.contains("FILLING")) {
//                    int noOfRxFilling = fillSummaryResponse.getDependents().get(i).getFills().getFilling().size();
//                    Assert.assertEquals(noOfRxFilling,dependt_fillingDetails.split(",").length);
//                    for (int j = 0; j < noOfRxFilling; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//                        //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                        if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                        {
//                            Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                            Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                        }
//
//                        else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                        {
//                            String drugName= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getName();
//                            String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getNdcNumber();
//                            String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getFillId());
//                            String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getPatientDueAmt());
//                            String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getEstimatedPrice());
//                            String fillStatus= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus();
//
//                            Assert.assertTrue(dependt_fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" - "+fillStatus));
//
//                            Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getCurrency());
//                        }
//                    }
//                }
//                if (dependt_fillingStatus.contains("DELAYED")) {
//                    int noOfRxDelayed = fillSummaryResponse.getDependents().get(i).getFills().getDelayed().size();
//                    Assert.assertEquals(noOfRxDelayed,dependt_delayedDetails.split(",").length);
//                    for (int j = 0; j < noOfRxDelayed; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getFillId());
//                        String delayReason = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getReason());
//
//                        Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response",dependt_delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//                    }
//
//                }
//            }
//        }
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//        }
//
//
//    }
//
//    @Test(description = "validate Fill Summary details for a patient with dependents based upon filling status- Delayed fill with Minor dependent- DelayedGeneric, PendingProviderAuth, PastPromisedTime", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
//    public void validateFillSummaryForPatientWithDependents_4(String patientId_storeId, String customerAccountId, String fillingStatus1, String fillingStatus2, String fillingStatus3, String dependtCustomerId, String dependt_fillingStatus, String dependtPatientId_dependtStoreId, String dependtType, String fillingDetails, String delayedDetails, String readyForPickupDetails, String dependt_fillingDetails, String dependt_delayedDetails, String dependt_readyForPickupDetails) throws IOException {
//
//        //Steps to recreate the test data once the old data is outdated after 150 days, or fills are past their pickuptime
//        /*
//        1. Drop some prescription for a patient and Minor dependent and move to EOD
//        2. Place refill
//        3. Move the fill to Delayed, RFP state- dependent- PastPromisedTime
//        4. move fill for caregiver Delayed- DelayedGeneric, PendingProviderAuth, PastPromisedTime
//        4. update the rx details to validate in the excel
//         */
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerAccountId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
//        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate fill summary details for customer
//        Assert.assertEquals(customerAccountId, fillSummaryResponse.getCustomer().getCustomerId());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getFirstName());
//        Assert.assertNotNull(fillSummaryResponse.getCustomer().getName().getLastName());
//
//        if (fillingStatus1.equals("READY_FOR_PICKUP")) {
//            int noOfRxForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();
//            Assert.assertEquals(noOfRxForPickup,readyForPickupDetails.split(",").length);
//            for (int i = 0; i < noOfRxForPickup; i++) {
//                //  Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getImageUrl());
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//                String drugName= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getFillId());
//                String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getPatientDueAmt());
//                String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getEstimatedPrice());
//
//                Assert.assertTrue(readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i).getPrice().getCurrency());
//
//            }
//        }
//        if (fillingStatus2.equals("FILLING")) {
//            int noOfRxFilling = fillSummaryResponse.getCustomer().getFills().getFilling().size();
//            Assert.assertEquals(noOfRxFilling, fillingDetails.split(",").length);
//            for (int i = 0; i < noOfRxFilling; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//                //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                {
//                    Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                }
//
//                else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                {
//                    String drugName= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getName();
//                    String ndcNo= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getDrug().getNdcNumber();
//                    String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                    String dueAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getPatientDueAmt());
//                    String estmdAmt= String.valueOf(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getEstimatedPrice());
//
//                    Assert.assertTrue(fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                    Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPrice().getCurrency());
//                }
//            }
//        }
//        if (fillingStatus3.equals("DELAYED")) {
//            int noOfRxDelayed = fillSummaryResponse.getCustomer().getFills().getDelayed().size();
//            Assert.assertEquals(noOfRxDelayed,delayedDetails.split(",").length);
//            for (int i = 0; i < noOfRxDelayed; i++) {
//                //Validate below attributes to be common accross all Rxs
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPRefId());
//                Assert.assertNotNull(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getImageUrl());
//
//                String patientId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getPatientId());
//                String storeId = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getStoreId());
//
//                Assert.assertTrue(patientId_storeId.contains(patientId + "-" + storeId));
//
//
//                String drugName= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getName();
//                String ndcNo= fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getDrug().getNdcNumber();
//                String fillId= String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getFillId());
//                String delayReason = String.valueOf(fillSummaryResponse.getCustomer().getFills().getDelayed().get(i).getReason());
//
//                Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response", delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//            }
//        }
//        // Step - 5: Validate fill summary details for dependents
//        int noOfDependents = fillSummaryResponse.getDependents().size();
//        for (int i = 0; i < noOfDependents; i++) {
//            if (dependtType.equalsIgnoreCase(fillSummaryResponse.getDependents().get(i).getDependentType())) {
//
//                Assert.assertEquals(dependtCustomerId, fillSummaryResponse.getDependents().get(i).getCustomerId());
//                Assert.assertEquals(dependtType, fillSummaryResponse.getDependents().get(i).getDependentType());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getFirstName());
//                Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getName().getLastName());
//
//                if (dependt_fillingStatus.contains("READY_FOR_PICKUP")) {
//                    int noOfRxForPickup = fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().size();
//                    Assert.assertEquals(noOfRxForPickup,dependt_readyForPickupDetails.split(",").length);
//                    for (int j = 0; j < noOfRxForPickup; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getImageUrl());
//                        String dependtPatientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPatientId());
//                        String dependtStoreId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(dependtPatientId + "-" + dependtStoreId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getFillId());
//                        String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getPatientDueAmt());
//                        String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getEstimatedPrice());
//
//                        Assert.assertTrue(dependt_readyForPickupDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt));
//
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getReadyForPickup().get(j).getPrice().getCurrency());
//
//                    }
//                }
//
//                if (dependt_fillingStatus.contains("FILLING")) {
//                    int noOfRxFilling = fillSummaryResponse.getDependents().get(i).getFills().getFilling().size();
//                    Assert.assertEquals(noOfRxFilling,dependt_fillingDetails.split(",").length);
//                    for (int j = 0; j < noOfRxFilling; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//                        //Validate if FillId is null for Rx status Filling then subStatus is in Received state
//                        if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("RECEIVED"))
//                        {
//                            Assert.assertNull(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getFillId());
//                            Assert.assertTrue(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getPRefId().startsWith("2"));
//                        }
//
//                        else if(fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus().equals("INPROCESS"))
//                        {
//                            String drugName= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getName();
//                            String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getDrug().getNdcNumber();
//                            String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getFillId());
//                            String dueAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getPatientDueAmt());
//                            String estmdAmt= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getEstimatedPrice());
//                            String fillStatus= fillSummaryResponse.getCustomer().getFills().getFilling().get(i).getSubStatus();
//
//                            Assert.assertTrue(dependt_fillingDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+dueAmt+" - "+estmdAmt+" - "+fillStatus));
//
//                            Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getFilling().get(j).getPrice().getCurrency());
//                        }
//                    }
//                }
//                if (dependt_fillingStatus.contains("DELAYED")) {
//                    int noOfRxDelayed = fillSummaryResponse.getDependents().get(i).getFills().getDelayed().size();
//                    Assert.assertEquals(noOfRxDelayed,dependt_delayedDetails.split(",").length);
//                    for (int j = 0; j < noOfRxDelayed; j++) {
//                        //Validate below attributes to be common accross all Rxs
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPRefId());
//                        Assert.assertNotNull(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getImageUrl());
//                        String patientId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getPatientId());
//                        String storeId = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getStoreId());
//
//                        Assert.assertTrue(dependtPatientId_dependtStoreId.contains(patientId + "-" + storeId));
//
//
//                        String drugName= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getName();
//                        String ndcNo= fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getDrug().getNdcNumber();
//                        String fillId= String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getFillId());
//                        String delayReason = String.valueOf(fillSummaryResponse.getDependents().get(i).getFills().getDelayed().get(j).getReason());
//
//                        Assert.assertTrue(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason+" is not expected in response",dependt_delayedDetails.contains(drugName+" - "+ndcNo+" - "+fillId+" - "+delayReason));
//
//
//                    }
//
//                }
//            }
//        }
//        // Step - 6: Validate store details in fill summary details api
//        int noOfStores = fillSummaryResponse.getStores().size();
//        Assert.assertTrue(noOfStores==patientId_storeId.split(",").length); //validate no extra store is present in fillsummary response
//        for (int i = 0; i < noOfStores; i++) {
//            Assert.assertTrue(patientId_storeId.contains(String.valueOf(fillSummaryResponse.getStores().get(i).getStoreId())));
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getPharmacyOperatingHours());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getStoreName());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getTimeZone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getContact().getPhone());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCountry());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getCity());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getPostalCode());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getType());
//            Assert.assertNotNull(fillSummaryResponse.getStores().get(i).getAddress().get(0).getState());
//        }
//
//
//    }
//
    @Test(description = "validate Fill Summary details for invalid customerAccountId- null cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_1(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- invalid cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_2(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- adultaccount not linked to pharmacy", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_3(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- petnotaddedasdependent", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_4(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- minornotaddedasdependent - scan to refill", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_5(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- special characters in cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_6(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    @Test(description = "validate Fill Summary details for invalid customerAccountId- self/Adult account not linked to pharmacy - scantorefill", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillSummary")
    public void validateFillSummaryInvalidTest_7(String customerAccountId, int statusCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerAccountId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(customerAccountId);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);


        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

    }

    /**
     * Method to delete patient and rx from informix and OCP*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, fillingRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, cancelledRxs, patientId);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.deleteAccountV1(cid, DOMAIN_ID, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        org.testng.Assert.assertEquals(apiResponse.code(), 200, errorMessage);

        DeleteAccountV1Response deleteAccountV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
                        DeleteAccountV1Response.class);

        Assertions.assertEquals(deleteAccountV1Response.getOnlineAccountId(), cid);
        Assertions.assertEquals(deleteAccountV1Response.getAuthPatientId(), String.valueOf(patientId));
        Assertions.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), String.valueOf(STORE_NBR));
    }
}
