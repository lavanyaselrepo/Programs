package rxorchestrator;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillDetailsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillDetailsWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;


/*
For static data tests check filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails"
 */
public class FillDetailsTests {
    private static final Logger logger = LoggerFactory.getLogger(FillDetailsTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private FillDetailsWrapper fillDetailsWrapper;
    HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs;
    List<InputResponse> fillingRxs;
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    List<InputResponse> eodRxs;
    private String cid;
    private Integer patientId;
    private List<String> pRefIds;
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    AutomationManager am = AutomationManager.getInstance();
    private final Gson gson = new GsonBuilder().create();

    private String DOMAIN_ID = "WM-PHARMACY";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private String INVALID_ACCOUNT_ID = "331ee47f-42cc-4a24-9869-f130b61bbf4e";
    private Integer NUM_OF_RXS_NEEDED = 1;

    /**
     * Sequence of API call for Fill Details By FillId Flow*
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * create filling rxs*
     * create eod rxs*
     * create cancelled rxs*
     * delete created patient and rxs*
     * @throws IOException
     */
    @BeforeClass
    void setContext() throws IOException {
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        fillDetailsWrapper = new FillDetailsWrapper();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        logger.info("CID for Fill Details By FillId: " + cid);
        Reporter.logJSON("CID for Fill Details By FillId: ", cid);

        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(240);
    }

    @Test(enabled = true, priority = 1, description = "Fill Details By FillId RFP rxs success response")
    void Fill_Details_For_RFP_Rxs() throws IOException {
        am.performSleep(180);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        pRefIds = rxpdUtils.getPRefIds(rfpRxs, STORE_NBR);
        logger.info("Fill Details By FillId pRefIds: " + pRefIds);
        Reporter.logJSON("Fill Details By FillId pRefIds: ", pRefIds);
        for (int i = 0; i < pRefIds.size(); i++) {
            Response<com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse> fillsDetailsResponse = rxOrchestratorRetrofit.getFillDetailsLookupByFillIdResponse(cid, pRefIds.get(i), reqId, reqTrackingId);
            Assert.assertEquals(200, fillsDetailsResponse.code());
            Assert.assertNotNull(fillsDetailsResponse.body());
        }

    }

    @Test(enabled = true, priority = 2, description = "Fill Details By FillId Filling rxs success response")
    void Fill_Details_For_Filling_Rxs() throws IOException {
        fillingRxs = rxpdUtils.fillingGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(300);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        List<String> pRefIds = rxpdUtils.getPRefIds(fillingRxs, STORE_NBR);
        Reporter.logJSON("Fill Details By FillId pRefIds for Filling rxs: ", pRefIds);
        logger.info("Fill Details By FillId pRefIds for Filling rxs: " + pRefIds);
        for (int i = 0; i < pRefIds.size(); i++) {
            Response<com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse> fillsDetailsResponse = rxOrchestratorRetrofit.getFillDetailsLookupByFillIdResponse(String.valueOf(patientId), pRefIds.get(i), reqId, reqTrackingId);
            Assert.assertEquals(200, fillsDetailsResponse.code());
            Assert.assertNotNull(fillsDetailsResponse.body());
        }

    }

    @Test(enabled = true, priority = 3, description = "Fill Details By FillId cancelled rxs success response")
    void Fill_Details_For_Cancelled_Rxs() throws IOException {

        cancelledRxs = rxpdUtils.cancelledGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(300);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        List<String> pRefIds = rxpdUtils.getPRefIds(cancelledRxs, STORE_NBR);
        logger.info("Fill Details By FillId pRefIds for Cancelled rxs: " + pRefIds);
        Reporter.logJSON("Fill Details By FillId pRefIds for Cancelled rxs: ", pRefIds);

        for (int i = 0; i < pRefIds.size(); i++) {
            Response<com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse> fillsDetailsResponse = rxOrchestratorRetrofit.getFillDetailsLookupByFillIdResponse(cid, pRefIds.get(i), reqId, reqTrackingId);
            Assert.assertTrue(fillsDetailsResponse.code() == 200 || fillsDetailsResponse.code() == 204);
        }
    }

    @Test(enabled = true, priority = 2, description = "Fill Details By FillId EOD rxs success response")
    void Fill_Details_For_EOD_Rxs() throws IOException {
        eodRxs = rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, 1);
        am.performSleep(120);
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        List<String> pRefIds = rxpdUtils.getPRefIds(eodRxs, STORE_NBR);
        logger.info("Fill Details By FillId pRefIds for EOD rxs: " + pRefIds);
        Reporter.logJSON("Fill Details By FillId pRefIds for EOD rxs: ", pRefIds);
        for (int i = 0; i < pRefIds.size(); i++) {
            Response<com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse> fillsDetailsResponse = rxOrchestratorRetrofit.getFillDetailsLookupByFillIdResponse(cid, pRefIds.get(i), reqId, reqTrackingId);
            Assert.assertTrue(fillsDetailsResponse.code() == 200 || fillsDetailsResponse.code() == 204);
        }
    }

    @Test(enabled = true, priority = 4, description = "Fill Details By FillId invalid cid")
    void Fill_Details_Invalid_CID() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        List<String> pRefIds = rxpdUtils.getPRefIds(rfpRxs, STORE_NBR);
        am.performSleep(180);

        for (int i = 0; i < pRefIds.size(); i++) {
            Response<com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse> fillsDetailsResponse = rxOrchestratorRetrofit.getFillDetailsLookupByFillIdResponse(INVALID_ACCOUNT_ID, pRefIds.get(i), reqId, reqTrackingId);
            Assert.assertEquals(401, fillsDetailsResponse.code());
        }
    }


    /*
    Commented out tests with static data for future reference
     */

    //    @Test(description = "validate Filling Details for Adult without dependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_1(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//    @Test(description = "validate Filling Details for Adult patient without dependent and logged in refill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_2(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//    @Test(description = "validate Filling Details for Adult with minor dependent and delayed fill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_3(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//    @Test(description = "validate Filling Details for Adult with minor dependent and delayed fill PendingProviderAuth", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_4(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//    @Test(description = "validate Filling Details for Adult with minor dependent and delayed fill PastPromisedTime", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_5(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//
//    @Test(description = "validate Filling Details for adult fill with dependent- adult is logged in and placed refill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_6(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//
//    @Test(description = "validate Filling Details for dependent minor- minor is logged in and caregiver placed refill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_7(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//    @Test(description = "validate Filling Details for -adult is logged in without dependent and scan to refill", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTest_8(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay, String isDependent,String dependent_cid) throws IOException, ParseException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with customerId, pRefId  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        if(isDependent.equals("Y"))
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),dependent_cid);
//        }
//        else
//        {
//            Assert.assertEquals(fillDetailsResponse.getPayload().getCustomerId(),customerId);
//        }
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//            if(reasonOfDelay.equals("PastPromisedTime")) {
//
//                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.getDefault());
//
//                Date currentDate = new Date();
//                dateFormat.format(currentDate);
//                //Date EPT  = new Date(fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime().format("yyyy-mm-dd"));
//                String EPT = fillDetailsResponse.getPayload().getFill().getPickupTime().getEstimatedPickupTime();
//                DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
//                Date EPTdate = format.parse(EPT);
//
//                Assert.assertTrue("EPT should be in the past for delay reason PastPromisedTime", EPTdate.before(currentDate));
//            }
//
//        } else if (fillStatus.equals("FILLING") || fillStatus.equals("RECEIVED")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//                Assert.assertEquals(fillId, String.valueOf(fillDetailsResponse.getPayload().getFill().getFillId()));
//
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//
//
//    @Test(description = "validate Filling Details for Pet patient- dependent pet while caregiver placed refill and logged in", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTestForPetRx(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay) throws IOException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//        } else if (fillStatus.equals("FILLING")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//
//                Assert.assertEquals(supply, fillDetailsResponse.getPayload().getFill().getSupply());
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
//
//    @Test(description = "validate Filling Details for Minor patient- minor is logged in", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void fillingDetailsApiTestForMinorRx(String patientId, String customerId, int storeId, String pRefId, int rxNbr, String fillingStatus, String expectedAvailableUntilDate, String patientname, String fillId, String drugDetails, String price, String prescriber, String instruction, String quantity, String supply, String latLong, String reasonOfDelay) throws IOException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("Patient Id", patientId);
//        Reporter.logJSON("Store Id", storeId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == 200);
//
//        // Step - 4: Validate patient details and fill details
//
//        Assert.assertEquals(patientId, fillDetailsResponse.getPayload().getPatient().getPatientId());
//        Assert.assertEquals(Optional.of(rxNbr), Optional.ofNullable(fillDetailsResponse.getPayload().getFill().getRx().getRxNbr()));
//
//        String fillStatus = fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus();
//
//        Assert.assertEquals(fillStatus, fillingStatus);
//
//        if (fillStatus.equals("READY_FOR_PICKUP")) {
//            Assert.assertEquals(expectedAvailableUntilDate, fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails().getAvailableUntilDate());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//            String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//            Assert.assertEquals(price,dueAmt+" - "+estAmt);
//            Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//        } else if (fillStatus.equals("DELAYED")) {
//            Assert.assertEquals(reasonOfDelay, fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails().getReason());
//            String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//            String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//            Assert.assertEquals(patientname,firstName+" "+lastName);
//
//            Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//            Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//            String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//            String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//            Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//            String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//            String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//            String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//            Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//            Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//            Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//            Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//            String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//            String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//            Assert.assertEquals(latLong, lat+"/"+longt);
//
//        } else if (fillStatus.equals("FILLING")) {
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getReadyForPickupDetails());
//            Assert.assertNull(fillDetailsResponse.getPayload().getFill().getStatusDetails().getDelayedDetails());
//
//            //validate Filling substatus based on prefId
//            if (pRefId.startsWith("2")) {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("RECEIVED"));
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//
//
//                Assert.assertEquals(drugDetails,drugName);
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//
//
//                Assert.assertEquals(supply, fillDetailsResponse.getPayload().getFill().getSupply());
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            } else {
//                Assert.assertTrue(fillDetailsResponse.getPayload().getFill().getStatusDetails().getStatus().equals("FILLING"));
//
//
//                String firstName= fillDetailsResponse.getPayload().getPatient().getName().getFirstName();
//                String lastName= fillDetailsResponse.getPayload().getPatient().getName().getLastName();
//                Assert.assertEquals(patientname,firstName+" "+lastName);
//
//                Assert.assertEquals(patientId,fillDetailsResponse.getPayload().getPatient().getPatientId());
//                Assert.assertEquals(fillId,fillDetailsResponse.getPayload().getFill().getFillId());
//                String drugName= fillDetailsResponse.getPayload().getFill().getDrug().getDrugName();
//                String ndcNo= fillDetailsResponse.getPayload().getFill().getDrug().getNdcNbr();
//
//                Assert.assertEquals(drugDetails,drugName+" - "+ndcNo);
//
//                String dueAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getPatientDueAmt());
//                String estAmt= String.valueOf(fillDetailsResponse.getPayload().getFill().getPrice().getEstimatedPrice());
//
//                Assert.assertEquals(price,dueAmt+" - "+estAmt);
//                Assert.assertNotNull(fillDetailsResponse.getPayload().getFill().getPrice().getCurrency());
//
//                String presFirstName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getFirstName();
//                String presMiddleName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getMiddleName();
//                String presLastName= fillDetailsResponse.getPayload().getFill().getRx().getPrescriber().getName().getLastName();
//                Assert.assertEquals(prescriber,presFirstName+" "+presMiddleName+" "+presLastName);
//                Assert.assertEquals(instruction,fillDetailsResponse.getPayload().getFill().getRx().getInstructions());
//                Assert.assertEquals(quantity, String.valueOf(fillDetailsResponse.getPayload().getFill().getQuantity()));
//                Assert.assertEquals(supply, String.valueOf(fillDetailsResponse.getPayload().getFill().getSupply()));
//
//                String lat= String.valueOf(fillDetailsResponse.getPayload().getStore().getLatitude());
//                String longt= String.valueOf(fillDetailsResponse.getPayload().getStore().getLongitude());
//
//                Assert.assertEquals(latLong, lat+"/"+longt);
//            }
//        } else {
//            Assert.assertFalse("No Rxs are in filling status", false);
//        }
//
//        //Validate remaining store details
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getPharmacyOperatingHours());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getStoreName());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getTimeZone());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getContact());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getAddressLine1());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCity());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getCountry());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getState());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getType());
//        Assert.assertNotNull(fillDetailsResponse.getPayload().getStore().getAddress().get(0).getPostalCode());
//
//    }
//
    @Test(description = "validate Filling Details API for invalid values- invalid cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
    public void invalidFillingDetailsApiTest_1(String customerId, String pRefId, int StatusCode, String ErrorCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);
        Reporter.logJSON("request predefined fill Id", pRefId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == StatusCode);

        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), ErrorCode);


    }

    @Test(description = "validate Filling Details API for invalid values- invalid prefid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
    public void invalidFillingDetailsApiTest_2(String customerId, String pRefId, int StatusCode, String ErrorCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);
        Reporter.logJSON("request predefined fill Id", pRefId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == StatusCode);

        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), ErrorCode);


    }

    @Test(description = "validate Filling Details API for invalid values- invalid cid and prefid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
    public void invalidFillingDetailsApiTest_3(String customerId, String pRefId, int StatusCode, String ErrorCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);
        Reporter.logJSON("request predefined fill Id", pRefId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == StatusCode);

        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), ErrorCode);


    }

    @Test(description = "validate Filling Details API for invalid values - special charactaer in cid and prefid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
    public void invalidFillingDetailsApiTest_4(String customerId, String pRefId, int StatusCode, String ErrorCode) throws IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);
        Reporter.logJSON("request predefined fill Id", pRefId);

        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.

        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == StatusCode);

        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), ErrorCode);


    }

    /**
     * Method to delete patient and rx from informix and OCP*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, fillingRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, eodRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, cancelledRxs, patientId);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.deleteAccountV1(cid, DOMAIN_ID, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        org.testng.Assert.assertEquals(apiResponse.code(), 200, errorMessage);

        DeleteAccountV1Response deleteAccountV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
                        DeleteAccountV1Response.class);

        Assertions.assertEquals(deleteAccountV1Response.getOnlineAccountId(), cid);
        Assertions.assertEquals(deleteAccountV1Response.getAuthPatientId(), String.valueOf(patientId));
        Assertions.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), String.valueOf(STORE_NBR));
    }
}
//
//    @Test(description = "validate Filling Details API for fill id not belonging to respective customerId values- unmatched fill id with cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void unmatchedFillIdWithOrderFillingDetailsApiTest_1(String customerId, String pRefId, int statusCode, String errorCode) throws IOException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == statusCode);
//
//        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), errorCode);
//
//    }
//
//    @Test(description = "validate Filling Details API for fill id not belonging to respective customerId values- dependent is not related to logged in person", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/orderToRx/rxOrchestratorData.xlsx", sheetName = "getFillDetails")
//    public void unmatchedFillIdWithOrderFillingDetailsApiTest_2(String customerId, String pRefId, int statusCode, String errorCode) throws IOException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        Reporter.logJSON("Customer Account Id", customerId);
//        Reporter.logJSON("request predefined fill Id", pRefId);
//
//        // Step - 2: Calling fill details API with account Id, predfid  for Fill Details response.
//
//        ServiceResponse serRes = fillDetailsWrapper.getFillDetails(customerId, pRefId);
//        FillDetailsResponse fillDetailsResponse = serRes.getDataResponse(FillDetailsResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertTrue(serRes.getStatusCode() == statusCode);
//
//        // Step - 4: Validate error message
//        FillDetailsErrorResponse errorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);
//        Assert.assertEquals(errorResponse.getError().getCode(), errorCode);
//
//    }

