
package rxorchestrator;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.PRefId;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.*;

import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;

/**
 * Test class for Fill Eligibility V2 API functionality.
 */
public class FillEligibilityV2APITests {
    WrapperUtils wrapperUtils=new WrapperUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    AutomationManager am = AutomationManager.getInstance();
    DBUtils dbUtils = new DBUtils();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    private List<InputResponse> rfpRxsWithMedicaidInsurance;
    private Integer patientId;
    private String cid;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String CHECKOUT_ELIGIBILITY_TYPE = "CHECKOUT";
    private String ADD_TO_CART_ELIGIBILITY_TYPE = "ADD_TO_CART";
    private String READY_NOTIFICATION_ELIGIBILITY_TYPE = "READY_NOTIFICATION";
    private String INVALID_ELIGIBILITY_TYPE = "CHECK";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;
    private String emailId;

    // Medicaid insurance configuration
    private Integer INSURANCE_CARRIER_PLAN_ID = 101;
    private Integer INSURANCE_CARRIER_COMPANY_ID = 122375;
    private String CARD_HOLDER_ID = "WBR120";
    private Integer INS_PLAN_TYPE_CODE = 1000; // Medicaid insurance plan type code
    private Integer RELATIONSHIP_CODE = 3201;
    private String USER_ID = "VN50S29";
    private String MEDICAID_ERROR_CODE = "RULE-IR-003";

    /**
     * Constructs a Fill Eligibility V2 request with FILL_INFO input type.
     */
    private FillEligibilityRequestV2 getFillEligibilityV2RequestFillInfo(List<InputResponse> rfpRxs, int storeNbr){

        List<FillEligibilityInputV2> fills = new ArrayList<>();

        for(int i = 0; i<rfpRxs.size(); i++) {

            FillEligibilityInputV2 fillEligibilityInputV2 = new FillEligibilityInputV2();
            fillEligibilityInputV2.setInputType(FillEligibilityInputV2.InputTypeEnum.FILL_INFO);
            fillEligibilityInputV2.setRxFillId(String.valueOf(rfpRxs.get(i).getRxFillId()));
            fillEligibilityInputV2.setRxId(String.valueOf(rfpRxs.get(i).getRxId()));
            fillEligibilityInputV2.setStoreNumber(storeNbr);
            fills.add(fillEligibilityInputV2);
        }

        FillEligibilityRequestV2 fillEligibilityRequest = new FillEligibilityRequestV2();
        fillEligibilityRequest.setFills(fills);

        return fillEligibilityRequest;
    }

    /**
     * Constructs a Fill Eligibility V2 request with FILL_INFO input type including customer ID.
     */
    private FillEligibilityRequestV2 getFillEligibilityV2RequestFillInfoWithCustomerId(String cid, List<InputResponse> rfpRxs, int storeNbr){

        List<FillEligibilityInputV2> fills = new ArrayList<>();

        for(int i = 0; i<rfpRxs.size(); i++) {

            FillEligibilityInputV2 fillEligibilityInputV2 = new FillEligibilityInputV2();
            fillEligibilityInputV2.setInputType(FillEligibilityInputV2.InputTypeEnum.FILL_INFO);
            fillEligibilityInputV2.setRxFillId(String.valueOf(rfpRxs.get(i).getRxFillId()));
            fillEligibilityInputV2.setRxId(String.valueOf(rfpRxs.get(i).getRxId()));
            fillEligibilityInputV2.setStoreNumber(storeNbr);
            fillEligibilityInputV2.setCustomerIds(List.of(cid));
            fills.add(fillEligibilityInputV2);
        }

        FillEligibilityRequestV2 fillEligibilityRequest = new FillEligibilityRequestV2();
        fillEligibilityRequest.setFills(fills);

        return fillEligibilityRequest;
    }

    /**
     * Constructs a Fill Eligibility V2 request with P_REF_ID input type.
     */
    private FillEligibilityRequestV2 getFillEligibilityV2RequestPRedId(List<InputResponse> rfpRxs, int storeNbr){

        List<FillEligibilityInputV2> fills = new ArrayList<>();

        for(int i = 0; i<rfpRxs.size(); i++) {

            FillEligibilityInputV2 fillEligibilityInputV2 = new FillEligibilityInputV2();
            fillEligibilityInputV2.setInputType(FillEligibilityInputV2.InputTypeEnum.P_REF_ID);
            PRefId pRefId = new PRefId();
            pRefId.setStoreNumber(storeNbr);
            pRefId.setRxId((long) rfpRxs.get(i).getRxId());
            pRefId.setRxFillId((long) rfpRxs.get(i).getRxFillId());
            String encodedPRefId = RxpdUtils.getPRefIdString(pRefId);
            fillEligibilityInputV2.setPRefId(encodedPRefId);
            fills.add(fillEligibilityInputV2);
        }

        FillEligibilityRequestV2 fillEligibilityRequest = new FillEligibilityRequestV2();
        fillEligibilityRequest.setFills(fills);

        return fillEligibilityRequest;
    }

    @BeforeClass
    void setContext() {
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        emailId = patientEmailId;
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

    }

    /**
     * Tests fill eligibility using P_REF_ID input type for CHECKOUT eligibility.
     */
    @Test(enabled = true, priority = 1, description = "Fill Eligibility PRefId InputType CheckoutEligibility")
    void Fill_Eligibility_PRefId_Request_Checkout_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestPRedId(rfpRxs, STORE_NBR);
        Log.info("Fill Eligibility Request: " + fillEligibilityRequestV2);
        Reporter.logJSON("Fill Eligibility Request: ", fillEligibilityRequestV2);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, CHECKOUT_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility using FILL_INFO input type for CHECKOUT eligibility.
     */
    @Test(enabled = true, priority = 2, description = "Fill Eligibility Fill_Info InputType CheckoutEligibility")
    void Fill_Eligibility_Fill_Info_Request_Checkout_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, CHECKOUT_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility using FILL_INFO input type for ADD_TO_CART eligibility.
     * */
    @Test(enabled = true, priority = 3, description = "Fill Eligibility Fill_Info InputType AddToCartEligibility")
    void Fill_Eligibility_Fill_Info_Request_Add_To_Cart_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, ADD_TO_CART_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility using P_REF_ID input type for ADD_TO_CART eligibility.
     */
    @Test(enabled = true, priority = 4, description = "Fill Eligibility PRefId InputType AddToCartEligibility")
    void Fill_Eligibility_PRefId_Request_Add_To_Cart_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestPRedId(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, ADD_TO_CART_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility using FILL_INFO input type for READY_NOTIFICATION eligibility.
     */
    @Test(enabled = true, priority = 5, description = "Fill Eligibility Fill_Info InputType ReadyNotificationEligibility")
    void Fill_Eligibility_Fill_Info_Request_Ready_Notification_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility using P_REF_ID input type for READY_NOTIFICATION eligibility.
     */
    @Test(enabled = true, priority = 6, description = "Fill Eligibility PRefId InputType ReadyNotificationEligibility")
    void Fill_Eligibility_PRefId_Request_Ready_Notification_Eligibility() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestPRedId(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
    }

    /**
     * Tests fill eligibility with an invalid eligibility type query parameter.
     */
    @Test(enabled = true, priority = 7, description = "Fill Eligibility Invalid queryParam")
    void Fill_Eligibility_Invalid_QueryParam() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestPRedId(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, INVALID_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(400, fillEligibilityResponseV2Response.code());
    }

    /**
     * Tests fill eligibility with a null eligibility type query parameter.
     */
    @Test(enabled = true, priority = 8, description = "Fill Eligibility null queryParam")
    void Fill_Eligibility_Null_QueryParam() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestPRedId(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, null, reqTrackingId);
        Assert.assertEquals(400, fillEligibilityResponseV2Response.code());
    }

    /**
     * Tests fill eligibility for ADD_TO_CART with a refrigerated medication NDC.
     */
    @Test(enabled = true, priority = 9, description = "Fill Eligibility AddToCartEligibility With Refrigerated ndcNbr ")
    void Fill_Eligibility_Add_To_Cart_Eligibility_Refrigerated_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00169643910"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        am.performSleep(500);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, ADD_TO_CART_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
        Assert.assertTrue(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    /**
     * Tests fill eligibility for ADD_TO_CART with a reconstituted medication NDC.
     */
    @Test(enabled = true, priority = 10, description = "Fill Eligibility AddToCartEligibility With Reconstituted ndcNbr ")
    void Fill_Eligibility_Add_To_Cart_Eligibility_Reconstituted_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, ADD_TO_CART_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
        Assert.assertTrue(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    /**
     * Tests fill eligibility for READY_NOTIFICATION with a refrigerated medication NDC.
     */
    @Test(enabled = true, priority = 11, description = "Fill Eligibility Ready Notification Eligibility With Refrigerated ndcNbr ")
    void Fill_Eligiility_Ready_Notification_Eligibility_Refrigerated_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00169643910"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
        Assert.assertTrue(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    /**
     * Tests fill eligibility for READY_NOTIFICATION with a reconstituted medication NDC.
     */
    @Test(enabled = true, priority = 12, description = "Fill Eligibility Ready Notification Eligibility With Reconstituted ndcNbr ")
    void Fill_Eligibility_Ready_Notification_Eligibility_Reconstituted_ndcNbr_ATC_Success() throws IOException {
        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("68180065701"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
        Assert.assertTrue(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());
    }

    /**
     * Tests fill eligibility for READY_NOTIFICATION with Medicaid insurance restriction for non-Walmart Plus members.
     */
    @Test(enabled = true, priority = 13, description = "Fill Eligibility Fill_Info InputType ReadyNotificationEligibility - Medicaid Restriction")
    void Fill_Eligibility_Fill_Info_Request_Ready_Notification_Eligibility_Medicaid_Restriction_Non_Walmart_Plus_Member() throws IOException, InterruptedException, ParseException {
        // Create a new patient with Medicaid insurance for this specific test
        // Reuse the same pattern as setContext for generating patient details
        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, 1, patientEmailId, DOTCOM_PASSWORD);
        List<String> caregiverDetails = rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR), INSURANCE_CARRIER_PLAN_ID, INSURANCE_CARRIER_COMPANY_ID, CARD_HOLDER_ID, INS_PLAN_TYPE_CODE, RELATIONSHIP_CODE);
        am.performSleep(5);
        String medicaidPatientId = caregiverDetails.get(1);
        Log.info("Patient with medicaid insurance paitientId: " + patientId);
        cid = caregiverDetails.get(0);
        emailId= patientEmailId;
        Log.info("Patient with medicaid insurance CID: " + cid);

        connexusAPIManager.updatePatientInfoCentralData(Integer.parseInt(medicaidPatientId), STORE_NBR, USER_ID);

        am.performSleep(10);

        List<InputResponse> rfpRxsWithMedicaidInsurance = rxpdUtils.rfpFillsForPatientWithMedicaidInsurance(Integer.parseInt(medicaidPatientId), STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE, 1);

        am.performSleep(500);

        Log.info("Patient cid: " + cid);
        Log.info("Patient emailId: " + emailId);
        com.walmart.hwqe.commons.apicontext.ServiceResponse walmartPlusResponse = rxpdUtils.getWalmartPlusMembership(emailId);
        Assert.assertEquals("Check status of walmart plus membership get ",400, walmartPlusResponse.getStatusCode());

        // Test fill eligibility - should be ineligible due to Medicaid restriction
        // Reuse the same pattern as other tests for generating tracking IDs
        JSONObject jsonObject = new JSONObject(walmartPlusResponse.getDataResponse());
        JSONObject astroDetails = jsonObject.getJSONObject("astroDetails");
        Log.info("walmartPlus status for cid "+cid +"is "+astroDetails.getString("status"));
        Assert.assertEquals("NOT_FOUND", astroDetails.getString("status"));

        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        am.performSleep(500);
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfoWithCustomerId(cid,rfpRxsWithMedicaidInsurance, STORE_NBR);

        am.performSleep(500);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);

        // Verify response
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());


        Assert.assertEquals(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().getIneligibilityReason().get(0).getCode(),
                "RULE-IR-002");
        Assert.assertEquals(
                "Prescription ineligible due state specific medicaid plan restriction", fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().getIneligibilityReason().get(0).getMessage());

        // Clean up the Medicaid test patient and rxs - reusing STORE_NBR from setContext
        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxsWithMedicaidInsurance,  Integer.parseInt(medicaidPatientId));
    }

    /**
     * Tests fill eligibility for READY_NOTIFICATION with Medicaid insurance for Walmart Plus members.
     */
    @Test(enabled = true, priority = 14, description = "Fill Eligibility Fill_Info InputType ReadyNotificationEligibility - Walmart Plus Member Eligible")
    void Fill_Eligibility_Fill_Info_Request_Ready_Notification_Eligibility_Walmart_Plus_Member() throws IOException, InterruptedException, ParseException {


        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, 1, patientEmailId, DOTCOM_PASSWORD);
        List<String> caregiverDetails = rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR), INSURANCE_CARRIER_PLAN_ID, INSURANCE_CARRIER_COMPANY_ID, CARD_HOLDER_ID, INS_PLAN_TYPE_CODE, RELATIONSHIP_CODE);
        am.performSleep(5);
        patientId = Integer.valueOf(caregiverDetails.get(1));
        Log.info("Patient with medicaid insurance paitientId: " + patientId);
        cid = caregiverDetails.get(0);
        emailId= patientEmailId;
        Log.info("Patient with medicaid insurance CID: " + cid);

        connexusAPIManager.updatePatientInfoCentralData(Integer.parseInt(String.valueOf(patientId)), STORE_NBR, USER_ID);

        am.performSleep(5);

        List<InputResponse> rfpRxsWithInsuranceDetails = rxpdUtils.rfpFillsForPatientWithMedicaidInsurance(Integer.parseInt(String.valueOf(patientId)), STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE, 1);

        am.performSleep(300);

        Log.info("Patient cid: " + cid);
        Log.info("Patient emailId: " + emailId);
        Log.info("RX Fill Id: " + rfpRxsWithInsuranceDetails.get(0).getRxFillId());
        // Add walmart plus membership for the patient
        ServiceResponse walmartPlusResponse = rxpdUtils.addWalmartPlusMembership(emailId);
        // Update Rx Sale Detail with TPS Submitted
        dbUtils.insertRxSaleDetailWithTPSSubmitted(STORE_NBR,rfpRxsWithInsuranceDetails.get(0).getRxFillId());
        // Wait for 500 ms to ensure the membership is updated and in dp a/c orch cache time 5mins
        am.performSleep(500);
        Assert.assertEquals("Check status of walmart plus membership update ",200, walmartPlusResponse.getStatusCode());


        // Test fill eligibility - should be eligible for Walmart Plus member
        // Reuse the same pattern as other tests for generating tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfoWithCustomerId(cid,rfpRxsWithInsuranceDetails, STORE_NBR);
        // Reuse rxOrchestratorRetrofit from setContext
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);

        // Verify response
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());

        // Verify the fill is eligible for Walmart Plus member
        Assert.assertTrue("Fill should be eligible for Walmart Plus member",
                fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibilityByCustomer().get(0).getEligibility().isEligible());

        // Verify the fill is eligible for Walmart Plus member
        Assert.assertFalse("Fill should not be eligible for Medicaid restriction",
                fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());

        // Clean up the Walmart Plus test patient and rxs - reusing STORE_NBR from setContext
        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxsWithInsuranceDetails,  patientId);
    }

    //TODO: Once lily drug is enabled change the ccm value and update the test assert for isEligbile to true
    /**
     * Tests fill eligibility for READY_NOTIFICATION with a lily drug
     */
    @Test(enabled = true, priority = 11, description = "Fill Eligibility Ready Notification Eligibility With Lily Drug Eligible ")
    void Fill_Eligiility_Ready_Notification_Eligibility_Lily_Drug_Ineligible() throws IOException {
        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, Arrays.asList("00002200204"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(500);
        String trackID = CommonUtil.randomUUID();
        String reqTrackingId = reqTrackingString + trackID;
        FillEligibilityRequestV2 fillEligibilityRequestV2 = getFillEligibilityV2RequestFillInfo(rfpRxs, STORE_NBR);
        Response<FillEligibilityResponseV2Payload> fillEligibilityResponseV2Response = rxOrchestratorRetrofit.getFillEligibilityV2Response(fillEligibilityRequestV2, READY_NOTIFICATION_ELIGIBILITY_TYPE, reqTrackingId);
        Assert.assertEquals(200, fillEligibilityResponseV2Response.code());
        Assert.assertNotNull(fillEligibilityResponseV2Response.body());
        Assert.assertFalse(fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().isEligible());
        Assert.assertEquals("RULE-DR-018", fillEligibilityResponseV2Response.body().getPayload().getFills().get(0).getEligibility().getIneligibilityReason().get(0).getCode());
    }


    /**
     * Test cleanup method executed after all test methods in the class complete.
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
    }
}