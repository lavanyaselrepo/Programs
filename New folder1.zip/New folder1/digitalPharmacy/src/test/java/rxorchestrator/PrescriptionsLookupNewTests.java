package rxorchestrator;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.PrescriptionsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.PresciptionsWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.CustomerInfo;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.CustomerPrescriptions;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.Prescription;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;


public class PrescriptionsLookupNewTests {
  WrapperUtils wrapperUtils = new WrapperUtils();
  private PresciptionsWrapper presciptionsWrapper;
  private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
  List<InputResponse> fillingRxs;
  private RxpdUtils rxpdUtils;
  private RxpdUtils rxpdUtilsDedup;
  HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs;
  private List<InputResponse> rfpRxs;
  private String cid;
  private String cidForDedup;
  private RxOrchestratorRetrofit rxOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  AutomationManager am = AutomationManager.getInstance();
  private Integer patientId;
  private String DOMAIN_ID = "WM-PHARMACY";
  private String DOB = "01011998";
  private String DOB_DEDUP = "01011998";
  private String DOTCOM_PASSWORD = "Test@1234";
  private List<String> NDC_LIST = Arrays.asList("00093505698", "31722070210", "68382056510", "68645055854", "53746051501");
  private List<String> NDC_LIST_DEDUP = Arrays.asList("00093505698", "31722070210", "68645055854", "68645055854", "53746051501");
//  private List<String> NDC_LIST = Arrays.asList("68382156510");
  private Integer CLINIC_ID = 6105;
  private Integer DISPENSE_TYPE = 1;
  private Integer NUM_REFILLS = 2;
  private List<Integer> NUM_REFILLS_LIST = Arrays.asList(1, 2, 0, 0, 5);
  private Integer PRIORITY_ID = 21100;
  private Integer PRESCRIBER_ID = 1065;
  private Integer REQUEST_TYPE_CODE = 1600;
  private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
  private List<String> INPUT_RX_EXP_DATE_LIST = Arrays.asList(wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate());
  private List<String> INPUT_RX_EXP_DATE_LIST_DEDUP_EXP = Arrays.asList(wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate(), wrapperUtils.getExpiryDate());
  private Integer NUM_OF_RXS_NEEDED = 5;
  private final Gson gson = TestUtils.getConfiguredGson();

  /**
   * Sequence of API call for Fill Summary Flow*
   * create new patient*
   * get patientId from CPR*
   * get cid from email using ca service API*
   * create rfp rxs*
   * create filling rxs*
   * create cancelled rxs*
   * delete created patient and rxs*
   *
   * @throws IOException
   */
  @BeforeClass
  void setContext() throws IOException {
    presciptionsWrapper = new PresciptionsWrapper();
    digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    String patientEmailId = CommonUtil.generateRandomEmailId(10);
    String patientFirstName = CommonUtil.generateRandomFirstName(5);
    String patientLastName = CommonUtil.generateRandomLastName(5);
    rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
    rxpdUtils.testAccountCreationForPrescriptionHistory();
    patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB_DEDUP, String.valueOf(STORE_NBR));

    cid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(patientEmailId);

    rfpRxs = rxpdUtils.rfpgenMultiRx(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS_LIST, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE_LIST);
    Log.info("Prescriptions history CID: " + cid);
    Reporter.logJSON("Prescriptions history CID: ", cid);
    NDC_LIST_DEDUP = Arrays.asList("00093505698", "31722070210", "68645055854", "68645055854", "53746051501");

    String patientEmailIdDedup = CommonUtil.generateRandomEmailId(10);
    String patientFirstNameDedup = CommonUtil.generateRandomFirstName(5);
    String patientLastNameDedup = CommonUtil.generateRandomLastName(5);
    rxpdUtilsDedup = new RxpdUtils(STORE_NBR, patientFirstNameDedup, patientLastNameDedup, DOB, NUM_OF_RXS_NEEDED, patientEmailIdDedup, DOTCOM_PASSWORD);
    rxpdUtilsDedup.testAccountCreationForPrescriptionHistory();
    patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstNameDedup, patientLastNameDedup, DOB, String.valueOf(STORE_NBR));

    cidForDedup = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(patientEmailIdDedup);

    rfpRxs = rxpdUtils.rfpgenMultiRx(patientId, STORE_NBR, NDC_LIST_DEDUP, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS_LIST, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE_LIST);
    Log.info("Prescriptions history CID DEDUP: " + cidForDedup);
    Reporter.logJSON("Prescriptions history CID DEDUP: ", cidForDedup);
    am.performSleep(180);
  }

  @Test(enabled = true, priority = 1, description = "Prescriptions history success response")
  void Prescription_history_Success_Response() {


    // Build the request body as per requirements
    JSONObject filterOptions = new JSONObject();
    filterOptions.put("includeDependents", true);
    filterOptions.put("includeFills", false);
    filterOptions.put("dedupInactiveDuplicateRx", false);
    filterOptions.put("fillDateSpan", "LAST_6_MONTHS");
    filterOptions.put("rxType", new org.json.JSONArray().put("ALL"));

    JSONObject sortOptions = new JSONObject();
    sortOptions.put("rxSortBy", new org.json.JSONArray().put("LAST_FILL_DATE"));
    sortOptions.put("fillSortBy", new org.json.JSONArray().put("FILL_DATE"));

    ServiceResponse prescriptionsResponse = presciptionsWrapper.getPrescriptions(cid, "WM-PHARMACY", filterOptions, sortOptions);
    Assert.assertEquals(200, prescriptionsResponse.getStatusCode());
    Assert.assertNotNull(prescriptionsResponse.getDataResponse());
    PrescriptionsResponse apiResponse = null;
    if(prescriptionsResponse.getDataResponse()!= null) {
      apiResponse =
              prescriptionsResponse.getDataResponse(PrescriptionsResponse.class);
    }
    System.out.println("Prescription history response: " + gson.toJson(apiResponse));

// Assuming apiResponse is an instance of PrescriptionsResponse
      assert apiResponse != null;
      List<CustomerPrescriptions> customerPrescriptions = apiResponse.getPayload().getCustomerPrescriptions();

    boolean hasMoreThanZeroPrescriptions = customerPrescriptions.stream()
            .anyMatch(cp -> cp.getPrescriptions() != null && !cp.getPrescriptions().isEmpty());

    long rxNumberCount = customerPrescriptions.stream()
            .flatMap(cp -> cp.getPrescriptions().stream())
            .map(Prescription::getRxNumber)
            .distinct()
            .count();

    Assertions.assertTrue(hasMoreThanZeroPrescriptions, "No prescriptions found");
    Assertions.assertEquals(5, rxNumberCount, "rxNumber count is not equal to 5");


    // Step - 6: Checking if isDependent is TRUE in response
    List<CustomerPrescriptions> prescriptions=apiResponse.getPayload().getCustomerPrescriptions();
    Stream<CustomerInfo> customerInfoStream=prescriptions.stream().map(CustomerPrescriptions::getCustomerInfo);
    boolean isDependentTrue = customerInfoStream.anyMatch(customerInfo->{
      boolean isDependent = customerInfo.isIsDependent().booleanValue();
      if (isDependent){
        return false;
      }
      return true;
    });

    Assertions.assertTrue(isDependentTrue, "isDependent' is false in the response.");
  }

  @Test(enabled = true, priority = 1, description = "Prescriptions history success response")
  void Prescription_history_DedupInactive_Response() {


    // Build the request body as per requirements
    JSONObject filterOptions = new JSONObject();
    filterOptions.put("includeDependents", true);
    filterOptions.put("includeFills", false);
    filterOptions.put("dedupInactiveDuplicateRx", true);
    filterOptions.put("fillDateSpan", "LAST_6_MONTHS");
    filterOptions.put("rxType", new org.json.JSONArray().put("ALL"));

    JSONObject sortOptions = new JSONObject();
    sortOptions.put("rxSortBy", new org.json.JSONArray().put("LAST_FILL_DATE"));
    sortOptions.put("fillSortBy", new org.json.JSONArray().put("FILL_DATE"));

    ServiceResponse prescriptionsResponse = presciptionsWrapper.getPrescriptions(cidForDedup, "WM-PHARMACY", filterOptions, sortOptions);
    Assert.assertEquals(200, prescriptionsResponse.getStatusCode());
    Assert.assertNotNull(prescriptionsResponse.getDataResponse());
    PrescriptionsResponse apiResponse = null;
    if(prescriptionsResponse.getDataResponse()!= null) {
      apiResponse =
              prescriptionsResponse.getDataResponse(PrescriptionsResponse.class);
    }
    System.out.println("Prescription history response: " + gson.toJson(apiResponse));

// Assuming apiResponse is an instance of PrescriptionsResponse
    assert apiResponse != null;
    List<CustomerPrescriptions> customerPrescriptions = apiResponse.getPayload().getCustomerPrescriptions();

    boolean hasMoreThanZeroPrescriptions = customerPrescriptions.stream()
            .anyMatch(cp -> cp.getPrescriptions() != null && !cp.getPrescriptions().isEmpty());

    long rxNumberCount = customerPrescriptions.stream()
            .flatMap(cp -> cp.getPrescriptions().stream())
            .map(Prescription::getRxNumber)
            .distinct()
            .count();

    Assertions.assertTrue(hasMoreThanZeroPrescriptions, "No prescriptions found");
    Assertions.assertEquals(4, rxNumberCount, "rxNumber count is not equal to 4");


    // Step - 6: Checking if isDependent is TRUE in response
    List<CustomerPrescriptions> prescriptions=apiResponse.getPayload().getCustomerPrescriptions();
    Stream<CustomerInfo> customerInfoStream=prescriptions.stream().map(CustomerPrescriptions::getCustomerInfo);
    boolean isDependentTrue = customerInfoStream.anyMatch(customerInfo->{
      boolean isDependent = customerInfo.isIsDependent().booleanValue();
      if (isDependent){
        return false;
      }
      return true;
    });

    Assertions.assertTrue(isDependentTrue, "isDependent' is false in the response.");
  }
}