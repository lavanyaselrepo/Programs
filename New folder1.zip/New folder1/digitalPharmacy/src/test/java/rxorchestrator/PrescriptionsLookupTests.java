package rxorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;



public class PrescriptionsLookupTests {

  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

  private final Gson gson = TestUtils.getConfiguredGson();
  private RxOrchestratorRetrofit rxOrchestratorRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
  }

  /** Below test covers Prescription Lookup success case */
  @Test(
      priority = 0,
      description = "Include Dependent - False",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
      sheetName = "prescriptionHistory")
  public void includeDependentsRequestFalse(String customerAccountId, String domainId, String payload, String statusCode)
      throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
        gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
        rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
            String.valueOf(TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response));

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(response.body().getPayload().getCustomerPrescriptions().get(0).getCustomerInfo().getCustomerId(),"aa1d085c-43e2-46ce-8a4a-45159e69f78e");
    Assert.assertEquals(response.body().getPayload().getCustomerPrescriptions().get(0).getCustomerInfo().isIsDependent().booleanValue(),false );
    Assert.assertEquals(response.body().getPayload().getCustomerPrescriptions().size(),1);
  }

  @Test(
          priority = 0,
          description = "Include Dependent - True",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void includeDependentsRequestTrue(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
            String.valueOf(TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response));

    // Step - 5: Asserting errorMessade response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);

    // Step - 6: Checking if isDependent is TRUE in response
    List<CustomerPrescriptions> customerPrescriptions=response.body().getPayload().getCustomerPrescriptions();
    Stream<CustomerInfo> customerInfoStream=customerPrescriptions.stream().map(CustomerPrescriptions::getCustomerInfo);
    boolean isDependentTrue = customerInfoStream.anyMatch(customerInfo->{
      boolean isDependent = customerInfo.isIsDependent().booleanValue();
        if (isDependent){
          return true;
        }
        return false;
    });

    // Step - 6: Assert that at least one "isDependent" field is true to check if the response is including dependents or not
    Assert.assertTrue(isDependentTrue, "isDependent' is false in the response.");
  }

  @Test(
          priority = 0,
          description = "Include Fills - False",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void includeFillsFalse(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
            String.valueOf(TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response));

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertNull(response.body().getPayload().getCustomerPrescriptions().get(0).getFills(), null);
  }

  @Test(
          priority = 0,
          description = "Include Fills - True",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void includeFillsTrue(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
            String.valueOf(TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response));

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertNotNull(response.body().getPayload().getCustomerPrescriptions().get(0).getFills());

    // Step - 6 : Iterating over response to check if the Rx is present

    List<CustomerPrescriptions> customerPrescriptions=response.body().getPayload().getCustomerPrescriptions();

    Assert.assertNotNull(customerPrescriptions.get(0).getPrescriptions().get(0).getRxNumber());

    // Step - 7 : Iterating over response to check if the fillId is present

    List<CustomerPrescriptions> customerPrescriptionsList=response.body().getPayload().getCustomerPrescriptions();

    Assert.assertNotNull(customerPrescriptions.get(0).getFills().get(0).getFillId());
  }

  @Test(
          priority = 0,
          description = "rxType - ALL",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void rxTypeSuccess(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
            String.valueOf(TestUtils.buildErrorMessageFromPrescriptionsLookupResponse(gson, response));

    // Step - 5: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertNotNull(response.body().getPayload().getCustomerPrescriptions().get(0).getPrescriptions().get(0).getRxNumber());
    Assert.assertEquals(response.body().getPayload().getCustomerPrescriptions().get(0).getPrescriptions().get(0).getStoreNumber().intValue(),5548);
  }

  /** Below test covers Prescription Lookup failure case */
  @Test(
          priority = 0,
          description = "Invalid Customer Account ID - Failure",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void invalidCustomerIdFailure(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getPrescriptionsLookupErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
//    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-2002"); In every request hit code changes between 2002 and 2004

  }

  @Test(
          priority = 0,
          description = "Invalid Last Refill Date Range - Failure",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void invalidLastRefillDateRange(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getPrescriptionsLookupErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

  }

  @Test(
          priority = 0,
          description = "Multiple Filters - Failure (Providing fillSpan and dateRange together",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/rxorchestrator/rxOrchestratorData.xlsx",
          sheetName = "prescriptionHistory")
  public void multipleFiltersFailure(String customerAccountId, String domainId, String payload, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(customerAccountId, requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    PrescriptionsLookupRequest request =
            gson.fromJson(payload, PrescriptionsLookupRequest.class);

    // Step - 3: Calling the getCustomerPrescriptionsHistory API to get prescription lookup
    Response<PrescriptionsLookupResponse> response =
            rxOrchestratorRetrofit.getCustomerPrescriptionsHistory(customerAccountId, domainId, request, requestId, requestTrackingId);

    // Step - 4: Getting error response
    Error errorResponse = TestUtils.getPrescriptionsLookupErrorResponse(gson, response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = TestUtils.buildCustomErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "CHPR-DPRXORCH-1003");

  }

}
