package rxorchestrator;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.StringUtils;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillDetailsErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.GetReadyRefillsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.walmart.chp.pharmacy.commons.constants.JsonPropertyConstants.STORE_NBR;


public class GetReadyRefills {
    private static final Logger logger = LoggerFactory.getLogger(GetReadyRefills.class);

    private Integer NUM_OF_RXS_NEEDED = 1;
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    RxpdUtils rxpdUtils = new RxpdUtils(NUM_OF_RXS_NEEDED);
    WrapperUtils wrapperUtils=new WrapperUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
    DBUtils dbUtils = new DBUtils();
    AutomationManager am = AutomationManager.getInstance();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
    ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    CommonUtils utility = new CommonUtils();
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = new ArrayList<>();
    HashMap<Integer,List<InputResponse>> patientIdAndRxsToBeDeleted = new HashMap<>();
    public Gson gson;
    private List<InputResponse> rfpRxs;
    private List<InputResponse> rfpRxsNL;
    private List<InputResponse> rfpRxsDependent;
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 1;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    @Test(priority = 1,
            description = "Validate getReadyRefills api forcaregiver with no nonlinked dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test1_getReadyRefills_Self_withNoNonLinkedDependent(String storeNo, String caregiverDOB) throws InterruptedException {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Step - 3: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((180000));

        // Step - 4: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);

        // Step - 5: Validate response of getReadyRefills API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().size(), 0);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().size(), 0);
        Assert.assertEquals(getReadyRefillsResponse.getStores().size(), 0);
    }

    @Test(priority = 2,
            description = "Validate getReadyRefills api forcaregiver with nonlinked ADULT dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test2_getReadyRefills_Self_withNonLinkedADULTDependent(String caregiverDOB, String dependentDOB, String storeNo) throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail_NL = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName_NL = CommonUtil.generateRandomFirstName(10);
        String dependentLastName_NL = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails_NL = digitalPharmacyOperationsUtil.testAccountCreation(dependentEmail_NL, dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo,false,false);
        String dependent_cid = dependentDetails_NL.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        int patientId_NL= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);


        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        rfpRxsNL = rxpdUtils.rfpgen(patientId_NL, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId),caregiverFirstName,caregiverFirstName,caregiverDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_NL),dependentFirstName_NL,dependentLastName_NL,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_NL, rfpRxsNL);

        // Step - 3: Get drugInfo
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNo));
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, NDC_LIST.get(0));
        String drugName = drugInfo.getValue("short_name");
        drugName = drugName.trim();

        // Step - 4: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId_NL));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((240000));

        // Step - 5: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);

        // Step - 6: Validate response of getReadyRefills API

        //caregiverDetails
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiverDetails.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getRxNbr(), rfpRxs.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getFillId(), rfpRxs.get(0).getRxFillId());

        //nonLinkedDependents
        String maskedLastName = dependentLastName_NL.replaceAll("(?!^).", "*");
        String maskedDrugName = drugName.replaceAll("(?<=.{3}).", "*");
        String maskedDrugName_Updated = drugName.replaceAll("(?<=.{3}).", "*").substring(0, 11);

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getCustomerId(),dependent_cid);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getFirstName(), dependentFirstName_NL.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getLastName(), maskedLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPatientId(), Integer.parseInt(dependentDetails_NL.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getName(), maskedDrugName_Updated);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getRxNbr(), rfpRxsNL.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getFillId(), rfpRxsNL.get(0).getRxFillId());

        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getValidationToken());
        Assert.assertFalse(getReadyRefillsResponse.getNonLinkedDependents().get(0).isInCooldown());
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getLinkageStatus());

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthPatientId(), String.valueOf(patientId_NL));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthStoreNbr(), storeNo);
        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getEmailId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getDependentType(), "ADULT");

        Assert.assertNotNull(getReadyRefillsResponse.getStores());
        getReadyRefillsResponse.getStores().forEach(stores -> {
            stores.getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
        });

    }

    @Test(priority = 3,
            description = "Validate getReadyRefills api forcaregiver with nonlinked MINOR dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test3_getReadyRefills_Self_withNonLinkedMINORDependent(String caregiverDOB, String dependentDOB, String storeNo) throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail_NL = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName_NL = CommonUtil.generateRandomFirstName(10);
        String dependentLastName_NL = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: "+ caregiver_cid);
        List<String> dependentDetails_NL = digitalPharmacyOperationsUtil.testAccountCreation_noOnlineAccount_minor(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);
        String dependent_cid = dependentDetails_NL.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        int patientId_NL= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        rfpRxsNL = rxpdUtils.rfpgen(patientId_NL, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId),caregiverFirstName,caregiverFirstName,caregiverDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_NL),dependentFirstName_NL,dependentLastName_NL,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_NL, rfpRxsNL);

        // Step - 3: Get drugInfo
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNo));
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, NDC_LIST.get(0));
        String drugName = drugInfo.getValue("short_name");
        drugName = drugName.trim();

        // Step - 4: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId_NL));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((240000));

        // Step - 5: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);

        // Step - 6: Validate response of getReadyRefills API

        //caregiverDetails
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getRxNbr(), rfpRxs.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getFillId(), rfpRxs.get(0).getRxFillId());

        //nonLinkedDependents
        String maskedLastName = dependentLastName_NL.replaceAll("(?!^).", "*");
        String maskedDrugName = drugName.replaceAll("(?<=.{3}).", "*");
        String maskedDrugName_Updated = drugName.replaceAll("(?<=.{3}).", "*").substring(0, 11);

        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getCustomerId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getFirstName(), dependentFirstName_NL.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getLastName(), maskedLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPatientId(), Integer.parseInt(dependentDetails_NL.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getName(), maskedDrugName_Updated);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getRxNbr(), rfpRxsNL.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getFillId(), rfpRxsNL.get(0).getRxFillId());

        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getValidationToken());
        Assert.assertFalse(getReadyRefillsResponse.getNonLinkedDependents().get(0).isInCooldown());
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getLinkageStatus());

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthPatientId(), dependentDetails_NL.get(1));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthStoreNbr(), storeNo);
        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getEmailId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getDependentType(), "MINOR");

        Assert.assertNotNull(getReadyRefillsResponse.getStores());
        getReadyRefillsResponse.getStores().forEach(stores -> {
            stores.getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
        });

    }

    @Test(priority = 4,
            description = "Validate getReadyRefills api forcaregiver with nonlinked PET dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test4_getReadyRefills_Self_withNonLinkedPETDependent(String caregiverDOB, String dependentDOB, String storeNo) throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail_NL = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName_NL = CommonUtil.generateRandomFirstName(10);
        String dependentLastName_NL = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails_NL = digitalPharmacyOperationsUtil.testAccountCreation_noOnlineAccount_pet(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);
        String dependent_cid = dependentDetails_NL.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " +  dependent_cid);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        int patientId_NL= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        rfpRxsNL = rxpdUtils.rfpgen(patientId_NL, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId),caregiverFirstName,caregiverFirstName,caregiverDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_NL),dependentFirstName_NL,dependentLastName_NL,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_NL, rfpRxsNL);

        // Step - 3: Get drugInfo
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNo));
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, NDC_LIST.get(0));
        String drugName = drugInfo.getValue("short_name");
        drugName = drugName.trim();

        // Step - 4: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId_NL));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((240000));

        // Step - 5: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);


        // Step - 6: Validate response of getReadyRefills API

        //caregiverDetails
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getRxNbr(), rfpRxs.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getFillId(), rfpRxs.get(0).getRxFillId());


        //nonLinkedDependents
        String maskedLastName = dependentLastName_NL.replaceAll("(?!^).", "*");
        String maskedDrugName = drugName.replaceAll("(?<=.{3}).", "*");
        String maskedDrugName_Updated = drugName.replaceAll("(?<=.{3}).", "*").substring(0, 11);

        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getCustomerId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getFirstName(), dependentFirstName_NL.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getLastName(), maskedLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPatientId(), Integer.parseInt(dependentDetails_NL.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getName(), maskedDrugName_Updated);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getRxNbr(), rfpRxsNL.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getFillId(), rfpRxsNL.get(0).getRxFillId());

        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getValidationToken());
        Assert.assertFalse(getReadyRefillsResponse.getNonLinkedDependents().get(0).isInCooldown());
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getLinkageStatus());

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthPatientId(), dependentDetails_NL.get(1));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthStoreNbr(), storeNo);
        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getEmailId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getDependentType(), "PET");

        Assert.assertNotNull(getReadyRefillsResponse.getStores());
        getReadyRefillsResponse.getStores().forEach(stores -> {
            stores.getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
        });

    }


    @Test(priority = 5,
            description = "Validate getReadyRefills api for caregiver with nonlinked and linked dependents",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test5_getReadyRefills_Self_withLinkedAndNonLinkedDependents(String caregiverDOB, String dependentDOB, String storeNo) throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail_NL = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName_NL = CommonUtil.generateRandomFirstName(10);
        String dependentLastName_NL = CommonUtil.generateRandomLastName(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(10);
        String dependentLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails_NL = digitalPharmacyOperationsUtil.testAccountCreation_noOnlineAccount(dependentEmail_NL, dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);
        String dependent_cid_NL = dependentDetails_NL.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid_NL);
        logger.info("Dependent Customer Account Id: " + dependent_cid_NL);
        List<String> dependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(dependentEmail, dependentFirstName, dependentLastName, dependentDOB, storeNo);
        String dependent_cid = dependentDetails.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, dependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        int patientId_dependent= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName, dependentLastName, dependentDOB, storeNo);
        int patientId_NL_Dependent= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        rfpRxsNL = rxpdUtils.rfpgen(patientId_NL_Dependent, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        rfpRxsDependent = rxpdUtils.rfpgen(patientId_dependent, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId),caregiverFirstName,caregiverFirstName,caregiverDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_dependent),dependentFirstName,dependentLastName,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_dependent),dependentFirstName_NL,dependentLastName_NL,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_dependent, rfpRxsNL);
        patientIdAndRxsToBeDeleted.put(patientId_NL_Dependent, rfpRxsDependent);

        // Step - 3: Get drugInfo
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNo));
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, NDC_LIST.get(0));
        String drugName = drugInfo.getValue("short_name");
        drugName = drugName.trim();

        // Step - 4: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId_NL_Dependent));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((360000));

        // Step - 5: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);


        // Step - 6: Validate response of getReadyRefills API

        //caregiverDetails
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getRxNbr(), rfpRxs.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getFillId(), rfpRxs.get(0).getRxFillId());


        //nonLinkedDependents
        String maskedLastName = dependentLastName_NL.replaceAll("(?!^).", "*");
        String maskedDrugName = drugName.replaceAll("(?<=.{3}).", "*");
        String maskedDrugName_Updated = drugName.replaceAll("(?<=.{3}).", "*").substring(0, 11);

        // Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getCustomerId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getFirstName(), dependentFirstName_NL.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getLastName(), maskedLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getPatientId(), Integer.parseInt(dependentDetails_NL.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getName(), maskedDrugName_Updated);
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getRxNbr(), rfpRxsNL.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().get(0).getFillId(), rfpRxsNL.get(0).getRxFillId());

        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getValidationToken());
        Assert.assertFalse(getReadyRefillsResponse.getNonLinkedDependents().get(0).isInCooldown());
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getLinkageStatus());

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthPatientId(), dependentDetails_NL.get(1));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthStoreNbr(), storeNo);
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getEmailId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getDependentType(), "ADULT");

        Assert.assertNotNull(getReadyRefillsResponse.getStores());

        //Linked Dependent Details
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getCustomerId(), dependent_cid);
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getName().getFirstName(), dependentFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getName().getLastName(), dependentLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getPatientId(), Integer.parseInt(dependentDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getRxNbr(), rfpRxsDependent.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getDependents().get(0).getFills().get(0).getFillId(), rfpRxsDependent.get(0).getRxFillId());
        getReadyRefillsResponse.getStores().forEach(stores -> {
            stores.getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
        });

    }

    @Test(priority = 6,
            description = "Validate getReadyRefills api forcaregiver with nonlinked dependents without any RFP fills",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test6_getReadyRefills_Self_withNonLinkedDependentsWithoutRFPFills(String caregiverDOB, String dependentDOB, String storeNo) throws InterruptedException {


        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail_NL = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName_NL = CommonUtil.generateRandomFirstName(10);
        String dependentLastName_NL = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails_NL = digitalPharmacyOperationsUtil.testAccountCreation_noOnlineAccount(dependentEmail_NL, dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);
        String dependent_cid = dependentDetails_NL.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        // Step - 2: Dropping RXs for caregiver and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        int patientId_NL= digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentFirstName_NL, dependentLastName_NL, dependentDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId),caregiverFirstName,caregiverFirstName,caregiverDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(storeNo, String.valueOf(patientId_NL),dependentFirstName_NL,dependentLastName_NL,dependentDOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);

        // Step - 3: Get drugInfo
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNo));
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, NDC_LIST.get(0));
        String drugName = drugInfo.getValue("short_name");
        drugName = drugName.trim();

        // Step - 4: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId_NL));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((240000));

        // Step - 5: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);


        // Step - 6: Validate response of getReadyRefills API

        //caregiverDetails
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPRefId());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getStoreId(), Integer.parseInt(storeNo));
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getPrice());
        Assert.assertNotNull(getReadyRefillsResponse.getCustomer().getFills().get(0).getImageUrl());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getCoverageApplied(), "NO");
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getName(), drugName);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getDrug().getNdcNumber().trim(), NDC_LIST.get(0));
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getRxNbr(), rfpRxs.get(0).getRxNbr());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().get(0).getFillId(), rfpRxs.get(0).getRxFillId());


        //nonLinkedDependents
        String maskedLastName = dependentLastName_NL.replaceAll("(?!^).", "*");

        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getCustomerId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getFirstName(), dependentFirstName_NL.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getName().getLastName(), maskedLastName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getFills().size(), 0);

        Assert.assertNotNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getValidationToken());
        Assert.assertFalse(getReadyRefillsResponse.getNonLinkedDependents().get(0).isInCooldown());
        Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getLinkageStatus());

        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthPatientId(), dependentDetails_NL.get(1));
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getAuthStoreNbr(), storeNo);
        //Assert.assertNull(getReadyRefillsResponse.getNonLinkedDependents().get(0).getEmailId());
        Assert.assertEquals(getReadyRefillsResponse.getNonLinkedDependents().get(0).getDependentType(), "ADULT");

        Assert.assertNotNull(getReadyRefillsResponse.getStores());
        getReadyRefillsResponse.getStores().forEach(stores -> {
            stores.getPharmacyOperatingHours().forEach(pharmacyOperatingHours -> {
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getStartTime());
                Assert.assertNotNull(pharmacyOperatingHours.getLunchHours().getEndTime());
            });
        });

    }

    @Test(priority = 7,
            description = "Validate getReadyRefills api for invalid phoneNo",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test7_getReadyRefills_InvalidPhoneNo(String errorCode) {


        // Step - 1: Call getReadyRefills api with invalid PhoneNo
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills("42a4cb05-c054-49ad-ba39-5408dc23883a", "331333898");
        FillDetailsErrorResponse getReadyRefillsErrorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);


        // Step - 2: Validate response of getReadyRefills API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getReadyRefillsErrorResponse.getError().getCode(), errorCode);

    }

    @Test(priority = 8,
            description = "Validate getReadyRefills api for invalid cid",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test8_getReadyRefills_InvalidCID(String errorCode) {


        // Step - 1: Call getReadyRefills api with invalid PhoneNo
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills("abcd", "3313338988");
        FillDetailsErrorResponse getReadyRefillsErrorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);


        // Step - 2: Validate response of getReadyRefills API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);


    }

    @Test(priority = 9,
            description = "Validate getReadyRefills api for invalid cid and phoneNo",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test9_getReadyRefills_InvalidCIDAndPhoneNo(String errorCode) {


        // Step - 1: Call getReadyRefills api with invalid PhoneNo
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills("abcd", "33133389");
        FillDetailsErrorResponse getReadyRefillsErrorResponse = serRes.getDataResponse(FillDetailsErrorResponse.class);


        // Step - 2: Validate response of getReadyRefills API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getReadyRefillsErrorResponse.getError().getCode(), errorCode);

    }

    @Test(priority = 10,
            description = "Validate getReadyRefills api forcaregiver with no nonlinked dependent with lily drug present",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getReadyRefills")
    public void Test10_getReadyRefills_Self_withNoNonLinkedDependent_Lily_Present(String storeNo, String caregiverDOB) throws InterruptedException {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : storeNo;

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till pickup

        int patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);

        rfpRxs = rxpdUtils.rfpgen(patientId, Integer.parseInt(storeNo), List.of("00002200204"), CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);

        // Step - 3: Enrolling patients with RX Messaging PhoneNo
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(phoneNo, storeNo, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        Thread.sleep((180000));

        // Step - 4: Call getReadyRefills api
        ServiceResponse serRes = fillSummaryWrapper.getReadyRefills(caregiver_cid, phoneNo);
        GetReadyRefillsResponse getReadyRefillsResponse = serRes.getDataResponse(GetReadyRefillsResponse.class);

        // Step - 5: Validate response of getReadyRefills API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(getReadyRefillsResponse.getCustomer().getFills().size(), 0);
    }

    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        String storeNo = StringUtils.isNotNullOrEmpty(System.getProperty("storeNbr")) ? System.getProperty("storeNbr") : "5548";
        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.keySet().forEach(patientId->{
            rxpdUtils.deletePatientAndRx(Integer.parseInt(storeNo), patientIdAndRxsToBeDeleted.get(patientId), patientId);
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())) {
                            Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                        }
                    } catch (IOException e) {
                        Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                    }
                });
    }

}
