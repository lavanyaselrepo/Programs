package rxorchestrator;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.helper.LookupByRxV2Helper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxservice.RxServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.RefillsDueResponse;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RxStatusUpdateRequestV2;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RxStatusUpdateResponse;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;

public class RefillsDueTests {

    private static final Logger logger = LoggerFactory.getLogger(RefillsDueTests.class);

    private static final int MAX_RETRIES = 5;
    private static final int RETRY_DELAY_SECONDS = 10;
    private static final int CPR_PROPAGATION_DELAY_SECONDS = 30; // Wait for account to propagate to CPR
    private static final int CPR_RETRY_DELAY_SECONDS = 15;       // Longer delay between CPR lookup retries
    private static final Random random = new Random();

    private final Integer NUM_OF_RXS_NEEDED = 1;
    private final RxOrchestratorRetrofit rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
    private final RxServiceRetrofit rxServiceRetrofit = new RxServiceRetrofit();
    private final DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    private final ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    private final RxpdUtils rxpdUtils = new RxpdUtils(NUM_OF_RXS_NEEDED);
    private final WrapperUtils wrapperUtils = new WrapperUtils();
    private final AutomationManager am = AutomationManager.getInstance();
    private final DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    private final CprPatientUpdateRetrofit cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    // Thread-safe collections for parallel execution
    private final List<CPRUpdatePatientRequest> cprUpdatePatientRequestToBeDeleted = Collections.synchronizedList(new ArrayList<>());
    private final ConcurrentHashMap<Integer, List<InputResponse>> patientIdAndRxsToBeDeleted = new ConcurrentHashMap<>();

    public Gson gson;
    private final List<String> NDC_LIST = Arrays.asList("68382056510");
    private final Integer CLINIC_ID = 6105;
    private final Integer DISPENSE_TYPE = 1;
    private final Integer NUM_REFILLS = 1;
    private final Integer PRIORITY_ID = 21100;
    private final Integer PRESCRIBER_ID = 1065;
    private final Integer REQUEST_TYPE_CODE = 1600;
    private final String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private final String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private final String DOB = "01011998";
    private final String reqTrackingString = "req-tracking-";


    // ==================== Retry Helper Methods ====================

    /**
     * Adds a random initial delay (1-5 seconds) to stagger parallel API calls
     */
    private void randomInitialDelay() {
        int delaySeconds = 1 + random.nextInt(5);
        am.performSleep(delaySeconds);
    }

    /**
     * Creates account with retry logic to handle intermittent failures during parallel execution
     */
    private List<String> createAccountWithRetry(String email, String firstName, String lastName, String dob,
                                                String storeNbr, boolean isRxpd, boolean isPos) throws Exception {
        randomInitialDelay(); // Stagger parallel calls
        Exception lastException = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                List<String> details = digitalPharmacyOperationsUtil.testAccountCreation(email, firstName, lastName, dob, storeNbr, isRxpd, isPos);
                if (details != null && !details.isEmpty()) {
                    return details;
                }
                lastException = new IllegalStateException("Empty account details returned");
            } catch (Exception e) {
                lastException = e;
                logger.warn("Account creation failed on attempt {} for email {}: {}", attempt, email, e.getMessage());
            }
            if (attempt < MAX_RETRIES) {
                am.performSleep(RETRY_DELAY_SECONDS);
            }
        }
        throw new RuntimeException("Account creation failed after " + MAX_RETRIES + " attempts", lastException);
    }

    /**
     * Creates consent orchestrator account with retry logic
     */
    private List<String> createConsentAccountWithRetry(String email, String firstName, String lastName, String dob,
                                                       String storeNbr) throws Exception {
        randomInitialDelay(); // Stagger parallel calls
        Exception lastException = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(email, firstName, lastName, dob, storeNbr);
                if (details != null && !details.isEmpty()) {
                    return details;
                }
                lastException = new IllegalStateException("Empty account details returned");
            } catch (Exception e) {
                lastException = e;
                logger.warn("Consent account creation failed on attempt {} for email {}: {}", attempt, email, e.getMessage());
            }
            if (attempt < MAX_RETRIES) {
                am.performSleep(RETRY_DELAY_SECONDS);
            }
        }
        throw new RuntimeException("Consent account creation failed after " + MAX_RETRIES + " attempts", lastException);
    }

    /**
     * Gets store patient ID from CPR with retry logic to handle intermittent failures.
     * Includes initial propagation delay since account creation takes time to sync to CPR.
     */
    private int getPatientIdWithRetry(String firstName, String lastName, String dob, String storeNbr) throws Exception {
        // Wait for account to propagate to CPR before first lookup attempt
        logger.info("Waiting {}s for account propagation to CPR for {} {}", CPR_PROPAGATION_DELAY_SECONDS, firstName, lastName);
        am.performSleep(CPR_PROPAGATION_DELAY_SECONDS);
        
        Exception lastException = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                logger.info("CPR lookup attempt {} for {} {}", attempt, firstName, lastName);
                int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(firstName, lastName, dob, storeNbr);
                if (patientId > 0) {
                    logger.info("Found patient ID {} for {} {}", patientId, firstName, lastName);
                    return patientId;
                }
                lastException = new IllegalStateException("Invalid patient ID returned: " + patientId);
                logger.warn("CPR returned invalid patient ID {} on attempt {} for {} {}", patientId, attempt, firstName, lastName);
            } catch (Exception e) {
                lastException = e;
                logger.warn("Get patient ID failed on attempt {} for {} {}: {}", attempt, firstName, lastName, e.getMessage());
            }
            if (attempt < MAX_RETRIES) {
                am.performSleep(CPR_RETRY_DELAY_SECONDS);
            }
        }
        throw new RuntimeException("Get patient ID failed after " + MAX_RETRIES + " attempts for " + firstName + " " + lastName, lastException);
    }

    /**
     * Makes Rxs ready for refill with retry logic to handle intermittent failures
     */
    private void makeRxsReadyForRefillWithRetry(Integer storeNbr, String cid, List<String> rxNbrs) throws Exception {
        randomInitialDelay(); // Stagger parallel calls
        Exception lastException = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                rxpdUtils.makeRxsReadyForRefill(storeNbr, cid, rxNbrs);
                return; // Success
            } catch (Exception e) {
                lastException = e;
                logger.warn("makeRxsReadyForRefill failed on attempt {} for cid {}: {}", attempt, cid, e.getMessage());
            }
            if (attempt < MAX_RETRIES) {
                am.performSleep(RETRY_DELAY_SECONDS);
            }
        }
        throw new RuntimeException("makeRxsReadyForRefill failed after " + MAX_RETRIES + " attempts for cid " + cid, lastException);
    }


    @Test(priority = 1, description = "Validate refills due for caregiver with no dependent when sourceActivityTs is greater than tdcSts and not within X hour")
    public void Test_refillsDue_For_Caregiver_With_No_Dependent_when_sourceActivityTs_greater_then_tdcSts_not_within_X_hour() throws Exception {
        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR), false, false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);

        // Step - 2: Dropping RXs for caregiver and moving till eod

        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));

        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId,STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        // Step 3 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(), String.valueOf(patientId),caregiverFirstName,caregiverLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Trigger Refill Due Notification
        List<String> rxNbrs = rfpRxs.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,caregiver_cid,rxNbrs);

        // Step 5 - Update Rx SourceActivityTs to after tdcSts to simulate Refill Due scenario
        Long sourceActivityTs = System.currentTimeMillis();
        RxStatusUpdateRequestV2 requestV2 = buildRxStatusUpdateRequestV2(rxNbrs.getFirst(), String.valueOf(patientId), String.valueOf(STORE_NBR), sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
        // Step 5.1 - Call Rx Service to update Rx Status to partial
        Response response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);
        // Step 5.2 - Call Rx Service to update Rx Status to pending
        requestV2.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PENDING);
        sourceActivityTs+=36000000L;  // adding 600 mins to sourceActivityTs
        logger.info("Source Activity Ts: " + sourceActivityTs);
        requestV2.setSourceActivityTs(sourceActivityTs);
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);


        // Step 6 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 7 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 1);
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().get(0).getRxNumber(), rxNbrs.get(0));
        Assert.assertEquals(serRes.body().getDependents().size(), 0);


    }

    @Test(priority = 2, description = "Validate refills due for caregiver with no dependent when sourceActivityTs is greater then tdcSts and within X hour ")
    public void Test_refillsDue_For_Caregiver_With_No_Dependent_sourceActivityTs_greater_then_tdcSts_within_X_hour() throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR), false, false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);

        // Step - 2: Dropping RXs for caregiver and moving till eod

        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));

        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId,STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        // Step 3 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(), String.valueOf(patientId),caregiverFirstName,caregiverLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Trigger Refill Due Notification
        List<String> rxNbrs = rfpRxs.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,caregiver_cid,rxNbrs);


        // Step 5 - Update Rx SourceActivityTs to after tdcSts with X hour
        Long sourceActivityTs = System.currentTimeMillis();
        RxStatusUpdateRequestV2 requestV2 = buildRxStatusUpdateRequestV2(rxNbrs.getFirst(), String.valueOf(patientId), String.valueOf(STORE_NBR), sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
        // Step 5.1 - Call Rx Service to update Rx Status to partial
        Response response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);
        // Step 5.2 - Call Rx Service to update Rx Status to pending
        requestV2.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PENDING);
        sourceActivityTs+=60000L; // adding 1 min to sourceActivityTs
        logger.info("Source Activity Ts: " + sourceActivityTs);
        requestV2.setSourceActivityTs(sourceActivityTs);
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);


        // Step 6 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 7 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 0);
        Assert.assertEquals(serRes.body().getDependents().size(), 0);


    }

    @Test(priority = 3, description = "Validate refills due for caregiver with no dependent when tdcSts is greater than sourceActivityTs")
    public void Test_refillsDue_For_Caregiver_With_No_Dependent_tdcSts_is_greater_then_sourceActivityTs() throws Exception {

        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR), false, false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);

        // Step - 2: Dropping RXs for caregiver and moving till eod

        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));

        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId,STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        // Step 3 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(300);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(STORE_NBR.toString(), String.valueOf(patientId),caregiverFirstName,caregiverLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);


        // Step 4 - Trigger Refill Due Notification
        List<String> rxNbrs = rfpRxs.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,caregiver_cid,rxNbrs);


        // Step 5 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 6 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 0);
        Assert.assertEquals(serRes.body().getDependents().size(), 0);


    }

    @Test(priority = 4,description = "Validate refills due for caregiver with linked dependent and sourceActivityTs is greater than tdcSts and not within X hour for caregiver and dependent")
    public void Test_refillsDue_For_Caregiver_With_linked__Dependent() throws Exception {
        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(10);
        String dependentLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR),false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails = createConsentAccountWithRetry(dependentEmail, dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));
        String dependent_cid = dependentDetails.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, dependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till eod

        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));
        int patientId_dependent= getPatientIdWithRetry(dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));

        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        List<InputResponse> rfpRxsDependent = rxpdUtils.rfpgen(patientId_dependent, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        // Step 3 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(100);
        rxpdUtils.eodGen(patientId_dependent,STORE_NBR,rfpRxsDependent,NDC_LIST,NUM_REFILLS);
        am.performSleep(180);

        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId),caregiverFirstName,caregiverFirstName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId_dependent),dependentFirstName,dependentLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_dependent, rfpRxsDependent);

        // Step 4 - Trigger Refill Due Notification
        List<String> rxNbrs = rfpRxs.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,caregiver_cid,rxNbrs);
        List<String> rxNbrs_dependent = rfpRxsDependent.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,dependent_cid,rxNbrs_dependent);

        //Step 5 - For Caregiver Update Rx SourceActivityTs to after tdcSts to simulate Refill Due scenario
        Long sourceActivityTs = System.currentTimeMillis();
        RxStatusUpdateRequestV2 requestV2 = buildRxStatusUpdateRequestV2(rxNbrs.get(0), String.valueOf(patientId), String.valueOf(STORE_NBR), sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
        // Step 5.1 - Call Rx Service to update Rx Status to partial
        Response response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);
        // Step 5.2 - Call Rx Service to update Rx Status to pending
        requestV2.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PENDING);
        sourceActivityTs+=36000000L; // adding 100 mins to sourceActivityTs
        logger.info("For caregiver Source Activity Ts: " + sourceActivityTs);
        requestV2.setSourceActivityTs(sourceActivityTs);
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);

        //Step 6 - For Dependent Update Rx SourceActivityTs to after tdcSts to simulate Refill Due scenario
        Long sourceActivityTsDependent = System.currentTimeMillis();
        requestV2 = buildRxStatusUpdateRequestV2(rxNbrs_dependent.get(0), String.valueOf(patientId_dependent), String.valueOf(STORE_NBR), sourceActivityTsDependent, RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
        // Step 6.1 - Call Rx Service to update Rx Status to partial
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);
        // Step 6.2 - Call Rx Service to update Rx Status to pending
        requestV2.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PENDING);
        sourceActivityTsDependent+=36000000L; // adding 100 mins to sourceActivityTs
        logger.info("For dependent Source Activity Ts: " + sourceActivityTsDependent);
        requestV2.setSourceActivityTs(sourceActivityTsDependent);
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);

        // Step 7 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 8 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 1);
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().getFirst().getRxNumber(), rxNbrs.getFirst());
        Assert.assertEquals(serRes.body().getDependents().size(), 1);
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getFirstName(), dependentFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getLastName(), dependentLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getRefillDuePrescriptions().size(), 1);
        Assert.assertEquals(serRes.body().getDependents().getFirst().getRefillDuePrescriptions().getFirst().getRxNumber(), rxNbrs_dependent.getFirst());


    }

    @Test(priority = 5,description = "Validate refills due for caregiver with linked dependent and sourceActivityTs is greater than tdcSts and not within X hour for dependent only")
    public void Test_refillsDue_For_Caregiver_With_linked_Dependent_refill_due_for_dependent() throws Exception {
        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(10);
        String dependentLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR),false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails = createConsentAccountWithRetry(dependentEmail, dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));
        String dependent_cid = dependentDetails.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, dependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Dropping RXs for caregiver and dependents and moving till eod

        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));
        int patientId_dependent= getPatientIdWithRetry(dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));

        List<InputResponse> rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        List<InputResponse> rfpRxsDependent = rxpdUtils.rfpgen(patientId_dependent, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

        // Step 3 - Move Order to EOD
        rxpdUtils.eodGen(patientId,STORE_NBR,rfpRxs,NDC_LIST,NUM_REFILLS);
        am.performSleep(100);
        rxpdUtils.eodGen(patientId_dependent,STORE_NBR,rfpRxsDependent,NDC_LIST,NUM_REFILLS);
        am.performSleep(180);

        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId),caregiverFirstName,caregiverFirstName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId_dependent),dependentFirstName,dependentLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        patientIdAndRxsToBeDeleted.put(patientId, rfpRxs);
        patientIdAndRxsToBeDeleted.put(patientId_dependent, rfpRxsDependent);

        // Step 4 - Trigger Refill Due Notification for dependent only
        List<String> rxNbrs_dependent = rfpRxsDependent.stream().map(InputResponse::getRxNbr)
                .map(Object::toString)
                .toList();
        makeRxsReadyForRefillWithRetry(STORE_NBR,dependent_cid,rxNbrs_dependent);


        //Step 5 - For Dependent Update Rx SourceActivityTs to after tdcSts to simulate Refill Due scenario
        Long sourceActivityTsDependent = System.currentTimeMillis();
        RxStatusUpdateRequestV2 requestV2 = buildRxStatusUpdateRequestV2(rxNbrs_dependent.get(0), String.valueOf(patientId_dependent), String.valueOf(STORE_NBR), sourceActivityTsDependent, RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
        // Step 5.1 - Call Rx Service to update Rx Status to partial
        Response<RxStatusUpdateResponse> response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);
        // Step 5.2 - Call Rx Service to update Rx Status to pending
        requestV2.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PENDING);
        sourceActivityTsDependent+=36000000L; // adding 100 mins to sourceActivityTs
        logger.info("For dependent Source Activity Ts: " + sourceActivityTsDependent);
        requestV2.setSourceActivityTs(sourceActivityTsDependent);
        response = rxServiceRetrofit.updateRxStatus(requestV2);
        Assert.assertEquals(response.code(), HttpStatus.OK_200);

        // Step 7 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 8 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 0);
        Assert.assertEquals(serRes.body().getDependents().size(), 1);
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getFirstName(), dependentFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getLastName(), dependentLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getRefillDuePrescriptions().size(), 1);
        Assert.assertEquals(serRes.body().getDependents().getFirst().getRefillDuePrescriptions().getFirst().getRxNumber(), rxNbrs_dependent.getFirst());


    }


    @Test(priority = 6,description = "Validate refills due for caregiver with linked Adult dependent and no refills due for both")
    public void Test_refillsDue_For_Caregiver_With_linked_Adult_Dependent_with_no_refills_due_for_both() throws Exception {
        // Step - 1: Setting and logging customer ID and adding dependent to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(10);
        String dependentLastName = CommonUtil.generateRandomLastName(10);
        String phoneNo = CommonUtil.generateRandomPhoneNo(10);
        String trackID = CommonUtil.randomUUID();
        List<String> caregiverDetails = createAccountWithRetry(caregiverEmail, caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR),false,false);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id: ", caregiver_cid);
        logger.info("Caregiver Customer Account Id: " + caregiver_cid);
        List<String> dependentDetails = createConsentAccountWithRetry(dependentEmail, dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));
        String dependent_cid = dependentDetails.get(0);
        Reporter.logJSON("Dependent Customer Account Id: ", dependent_cid);
        logger.info("Dependent Customer Account Id: " + dependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, dependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);


        int patientId= getPatientIdWithRetry(caregiverFirstName, caregiverLastName, DOB, String.valueOf(STORE_NBR));
        int patientId_dependent= getPatientIdWithRetry(dependentFirstName, dependentLastName, DOB, String.valueOf(STORE_NBR));


        // Create CPRUpdatePatientRequest
        CPRUpdatePatientRequest cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId),caregiverFirstName,caregiverFirstName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);
        cprUpdatePatientRequest = LookupByRxV2Helper.getCPRCreateOrUpdatePatientRequest(String.valueOf(STORE_NBR), String.valueOf(patientId_dependent),dependentFirstName,dependentLastName,DOB,phoneNo,null);
        cprUpdatePatientRequestToBeDeleted.add(cprUpdatePatientRequest);

        am.performSleep(100);

        // Step 2 - Call DP Rx Orchestrator for Refills Due
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(caregiver_cid,reqTrackingString+trackID,true,true,true );

        // Step 3 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.OK_200);
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body());
        Assert.assertNotNull(serRes.body().getCustomer());
        Assert.assertEquals(serRes.body().getCustomer().getCustomerId(), caregiver_cid);
        Assert.assertEquals(serRes.body().getCustomer().getName().getFirstName(), caregiverFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getName().getLastName(), caregiverLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getCustomer().getRefillDuePrescriptions().size(), 0);
        Assert.assertEquals(serRes.body().getDependents().size(), 1);
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getFirstName(), dependentFirstName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getName().getLastName(), dependentLastName.toUpperCase());
        Assert.assertEquals(serRes.body().getDependents().getFirst().getRefillDuePrescriptions().size(), 0);

    }

    @Test(priority = 7,description = "Test refills due for unknown user")
    public void Test_refillsDue_For_UnknownUser() throws IOException {
        // Step 1 - Call DP Rx Orchestrator for Refills Due
        String trackID = CommonUtil.randomUUID();
        String unknownCID = CommonUtil.randomUUID();
        Response<RefillsDueResponse> serRes = rxOrchestratorRetrofit.getRefillsDueResponse(unknownCID,reqTrackingString+trackID,true,true,true );

        // Step 2 - Validate Response
        Assert.assertEquals(serRes.code(), HttpStatus.BAD_REQUEST_400);

    }


    public RxStatusUpdateRequestV2 buildRxStatusUpdateRequestV2(String rxNbr, String patientId, String storeId, Long sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum refillStatusEnum) {
        RxStatusUpdateRequestV2 requestV2 =  new RxStatusUpdateRequestV2();
        requestV2.setRxNumber(rxNbr);
        requestV2.setPatientId(patientId);
        requestV2.setStoreId(storeId);
        requestV2.setSourceActivityTs(sourceActivityTs);
        requestV2.setRefillStatus(refillStatusEnum);

        return requestV2;
    }


    /**
     * Method to delete patient and rx from informix* and deleting CPR account
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        // Delete RFP rxs
        patientIdAndRxsToBeDeleted.forEach((patientId, rxList) -> {
            if (rxList != null) {
                rxpdUtils.deletePatientAndRx(STORE_NBR, rxList, patientId);
            }
        });

        // Delete CPR profiles
        cprUpdatePatientRequestToBeDeleted.forEach(
                request -> {
                    if (request != null && request.getPatientInfo() != null) {
                        request.getPatientInfo().setPatientStatusCode(20708);
                        try {
                            Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                            if (!(response.code() == 202
                                    && response.body() != null
                                    && response.body().getErrors().isEmpty())) {
                                Reporter.logJSON("Exception while deleting CPR profile", response.errorBody().toString());
                            }
                        } catch (IOException e) {
                            Reporter.log("Failed to delete CPR profile : " + e.getMessage());
                        }
                    }
                });
    }
}
