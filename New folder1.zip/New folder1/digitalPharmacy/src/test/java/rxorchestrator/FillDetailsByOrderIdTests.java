package rxorchestrator;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.dior.ecom.EcomEntityServiceRetrofit;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.github.sardine.model.Report;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.*;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.AddressDetails;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.CommunicationDetails;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.CustomerInfo;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.MedicineQuantityDetails;
import com.walmart.pharmacy.dior.ecom.order.entity.service.restclient.model.NameDetails;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillDetailsResponse;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.FillLookupByOrderIdRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class FillDetailsByOrderIdTests {
    private static final Logger logger = LoggerFactory.getLogger(FillDetailsByOrderIdTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    private RxOrchestratorRetrofit rxOrchestratorRetrofit;
    private EcomEntityServiceRetrofit ecomEntityServiceRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    private RxpdUtils rxpdUtils;
    private List<InputResponse> rfpRxs;
    private List<InputResponse> eodRxs;
    private HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs;
    private List<InputResponse> fillGen;
    private List<String> pRefIds;
    private String patientEmailId;
    private String patientFirstName;
    private String patientLastName;
    private String cid;
    private Integer patientId;
    private String DOMAIN_ID = "WM-PHARMACY";
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer CLINIC_ID = 6105;
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer PRESCRIBER_ID = 1065;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private Integer NUM_OF_RXS_NEEDED = 1;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private final Gson gson = new GsonBuilder().create();

    private FillLookupByOrderIdRequest getFillLookupByOrderIdRequest(EcomOrderRequest ecomOrderRequest, String pRefId){

            FillLookupByOrderIdRequest fillLookupByOrderIdRequest = new FillLookupByOrderIdRequest();

            String omsOrderId = ecomOrderRequest.getOmsOrderId();
            String omsOrderLineId = String.valueOf(ecomOrderRequest.getOrderLines().get(0).getOrderLineNo());
            String purchaseOrderId = ecomOrderRequest.getPurchaseOrderId();
            String purchaseOrderLineId = String.valueOf(ecomOrderRequest.getOrderLines().get(0).getPurchaseOrderLineNo());

            fillLookupByOrderIdRequest.setPRefId(pRefId);
            fillLookupByOrderIdRequest.setOmsOrderId(omsOrderId);
            fillLookupByOrderIdRequest.setOmsOrderLineId(omsOrderLineId);
            fillLookupByOrderIdRequest.setPurchaseOrderId(purchaseOrderId);
            fillLookupByOrderIdRequest.setPurchaseOrderLineId(purchaseOrderLineId);

        return fillLookupByOrderIdRequest;
    }

    private EcomOrderRequest getEcomOrderRequest(String patientEmailId, String patientFirstName, String patientLastName, int storeNbr, String cid){

        String omsOrderId = "dynamicAutoTests-" + CommonUtil.generateRandomNumber(4);
        String poCreate = CommonUtil.generateRandomNumber(10);

        Map<String, Long> orderLineEventTimeStamp = new HashMap<>();
        orderLineEventTimeStamp.put("fulfillment-po-create", Long.valueOf(poCreate));

        FillInfo fillInfo = new FillInfo();
        fillInfo.setItemDescription("Fisher Boy 60 oz Fish Sticks");

        AddressDetails addressDetails = new AddressDetails();
        addressDetails.setCity("New Palestine");
        addressDetails.setAddressLineOne("3382 S. DENDLE DR.");
        addressDetails.setPostalCode("111011");
        addressDetails.setCountryCode("USA");
        addressDetails.setAddressType("RESIDENTIAL");
        addressDetails.setStateOrProvinceCode("IN");

        CommunicationDetails communicationDetails = new CommunicationDetails();
        communicationDetails.setEmail(patientEmailId);
        communicationDetails.setPhone("7777788888");

        MedicineQuantityDetails medicineQuantityDetails = new MedicineQuantityDetails();
        medicineQuantityDetails.setUnitOfMeasure("EACH");
        medicineQuantityDetails.setMeasurementValue(1);

        List<EcomOrderLineInfo> ecomOrderLineInfoList = new ArrayList<>();

        EcomOrderLineInfo ecomOrderLineInfo = new EcomOrderLineInfo();
        ecomOrderLineInfo.setOrderLineNo(Integer.valueOf(CommonUtil.generateRandomNumber(1)));
        ecomOrderLineInfo.setPurchaseOrderLineNo(Integer.valueOf(CommonUtil.generateRandomNumber(1)));
        ecomOrderLineInfo.setFillInfo(fillInfo);
        ecomOrderLineInfo.setOmsOrderId(omsOrderId);
        ecomOrderLineInfo.setOfferId("8CDDE0642AA342CB9DF95368678EED3F");
        ecomOrderLineInfo.setEventTimestamp(orderLineEventTimeStamp);
        ecomOrderLineInfo.setQuantity(medicineQuantityDetails);

        ecomOrderLineInfoList.add(ecomOrderLineInfo);

        NameDetails nameDetails = new NameDetails();
        nameDetails.setFirstName(patientFirstName);
        nameDetails.setLastName(patientLastName);

        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setName(nameDetails);
        customerInfo.setAddressDetails(addressDetails);
        customerInfo.setCommunication(communicationDetails);

        Map<String, Long> eventTimestamp = new HashMap<>();
        eventTimestamp.put("po-create", Long.valueOf(poCreate));

        DeliverySlot deliverySlot = new DeliverySlot();
        deliverySlot.setStartTime("14:00");
        deliverySlot.setEndTime("15:00");
        deliverySlot.setEndDateTime("2022-06-02T18:00:00.000+0000");
        deliverySlot.setStartDateTime("2022-06-02T17:00:00.000+0000");
        deliverySlot.setFulfillmentDate("2024-12-18T18:00:00.000+0000");
        deliverySlot.setReservationId("eb9f3d3c-9092-4b8c-8973-e198b89e384d");


        DeliveryInfo deliveryInfo = new DeliveryInfo();
        deliveryInfo.setName(nameDetails);
        deliveryInfo.setAddress(addressDetails);
        deliveryInfo.setCommunication(communicationDetails);
        deliveryInfo.setSlot(deliverySlot);

        FulfillmentAmendInfo fulfillmentAmendInfo = new FulfillmentAmendInfo();
        fulfillmentAmendInfo.setAmendCutoffTime("2024-08-28T05:08:00.000+0000");
        fulfillmentAmendInfo.setOrderAmendVersion("0");
        fulfillmentAmendInfo.setFoAttributeAmendVersion("0");
        fulfillmentAmendInfo.setFoItemAmendVersion("0");

        EcomOrderRequest ecomOrderRequest = new EcomOrderRequest();
        ecomOrderRequest.setOmsOrderId(omsOrderId);
        ecomOrderRequest.setPurchaseOrderId("dynamicAutoTests-Purchase-" + CommonUtil.generateRandomNumber(4));
        ecomOrderRequest.setOrderLines(ecomOrderLineInfoList);
        ecomOrderRequest.setCustomerInfo(customerInfo);
        ecomOrderRequest.setStoreNumber(String.valueOf(storeNbr));
        ecomOrderRequest.setMartId("0");
        ecomOrderRequest.setBuid("0");
        ecomOrderRequest.setCustomerAccountId(cid);
        ecomOrderRequest.setEventTimestamp(eventTimestamp);
        ecomOrderRequest.setDeliveryInfo(deliveryInfo);
        ecomOrderRequest.setFulfillmentAmendInfo(fulfillmentAmendInfo);

        logger.info("EcomOrderRequest: " + ecomOrderRequest);
        Reporter.logJSON("EcomOrderRequest: ", ecomOrderRequest);

        return ecomOrderRequest;
    }

    /**
     * Sequence of API call to execute Fill Details By OrderId Flow*
     * 1. PO Create API*
     * 2. Fill Details Lookup By OrderId API*
     * create new patient*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * create rfp rxs*
     * create eod rxs*
     * create cancelled rxs*
     * delete created patient and rxs*
     * @throws IOException
     */
    @BeforeClass
    void setContext() throws IOException {
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        patientEmailId = CommonUtil.generateRandomEmailId(10);
        patientFirstName = CommonUtil.generateRandomFirstName(5);
        patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR,patientFirstName, patientLastName, DOB, NUM_OF_RXS_NEEDED, patientEmailId, DOTCOM_PASSWORD);
        rxpdUtils.testAccountCreation();
        patientId= digitalPharmacyAPIManager.getStorePatientIdFromCPR(patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR));
        cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmailId);
        logger.info("Fill Details By OrderId cid: " + cid);
        Reporter.logJSON("Fill Details By OrderId cid: ", cid);

        rfpRxs = rxpdUtils.rfpgen(patientId, STORE_NBR, NDC_LIST, CLINIC_ID, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, PRESCRIBER_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(180);

    }


    @Test(enabled = true, priority = 1, description = "Fill Details By Order Id success response")
    void Fill_Details_By_Order_Id_RFP_Rxs_Success_Response() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ecomEntityServiceRetrofit = new EcomEntityServiceRetrofit();

        pRefIds = rxpdUtils.getPRefIds(rfpRxs, STORE_NBR);
        logger.info("Fill Details By OrderId RFP Rxs pRefIds: " + pRefIds);
        Reporter.logJSON("Fill Details By OrderId RFP Rxs pRefIds: ", pRefIds);

        for(int i = 0; i<pRefIds.size(); i++){
            String pRefId = pRefIds.get(i);
            EcomOrderRequest ecomOrderRequest = getEcomOrderRequest(patientEmailId, patientFirstName, patientLastName, STORE_NBR, cid);
            ecomOrderRequest.getOrderLines().get(0).getFillInfo().setPRefId(pRefId);
            Response<BaseResponse> createOrderResponse= ecomEntityServiceRetrofit.createOrder(ecomOrderRequest, reqTrackingId, reqId);
            Assert.assertEquals(200, createOrderResponse.code());
            am.performSleep(150);

            FillLookupByOrderIdRequest fillLookupByOrderIdRequest = getFillLookupByOrderIdRequest(ecomOrderRequest, pRefId);
            Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
            Assert.assertEquals(200, response.code());
            Assert.assertNotNull(response.body());
        }

    }

    @Test(enabled = true, priority = 2, description = "Fill Details By Order Id success response")
    void Fill_Details_By_Order_Id_EOD_Rxs_Success_Response() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        eodRxs = rxpdUtils.eodGen(patientId, STORE_NBR, rfpRxs, NDC_LIST, 1);
        am.performSleep(180);

        List<String> pRefIds = rxpdUtils.getPRefIds(eodRxs, STORE_NBR);
        logger.info("Fill Details By OrderId EOD Rxs pRefIds: " + pRefIds);
        Reporter.logJSON("Fill Details By OrderId EOD Rxs pRefIds: ", pRefIds);

        ecomEntityServiceRetrofit = new EcomEntityServiceRetrofit();

        for(int i = 0; i<pRefIds.size(); i++){
            String pRefId = pRefIds.get(i);
            EcomOrderRequest ecomOrderRequest = getEcomOrderRequest(patientEmailId, patientFirstName, patientLastName, STORE_NBR, cid);
            ecomOrderRequest.getOrderLines().get(0).getFillInfo().setPRefId(pRefId);
            Response<BaseResponse> createOrderResponse= ecomEntityServiceRetrofit.createOrder(ecomOrderRequest, reqTrackingId, reqId);
            Assert.assertEquals(200, createOrderResponse.code());
            am.performSleep(150);

            FillLookupByOrderIdRequest fillLookupByOrderIdRequest = getFillLookupByOrderIdRequest(ecomOrderRequest, pRefId);
            Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
            Assert.assertEquals(200, response.code());
            Assert.assertNotNull(response.body());
        }
    }

    @Test(enabled = true, priority = 3, description = "Fill Details By Order Id success response")
    void Fill_Details_By_Order_Id_Cancelled_Rxs_Success_Response() throws IOException {

        cancelledRxs = rxpdUtils.cancelledGen(patientId, STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE);
        am.performSleep(300);

        List<String> pRefIds = rxpdUtils.getPRefIds(cancelledRxs, STORE_NBR);
        logger.info("Fill Details By OrderId Cancelled Rxs pRefIds: " + pRefIds);
        Reporter.logJSON("Fill Details By OrderId Cancelled Rxs pRefIds: ", pRefIds);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ecomEntityServiceRetrofit = new EcomEntityServiceRetrofit();

        for(int i = 0; i<pRefIds.size(); i++){
            String pRefId = pRefIds.get(i);
            EcomOrderRequest ecomOrderRequest = getEcomOrderRequest(patientEmailId, patientFirstName, patientLastName, STORE_NBR, cid);
            ecomOrderRequest.getOrderLines().get(0).getFillInfo().setPRefId(pRefId);
            Response<BaseResponse> createOrderResponse= ecomEntityServiceRetrofit.createOrder(ecomOrderRequest, reqTrackingId, reqId);
            Assert.assertEquals(200, createOrderResponse.code());
            am.performSleep(150);

            FillLookupByOrderIdRequest fillLookupByOrderIdRequest = getFillLookupByOrderIdRequest(ecomOrderRequest, pRefId);
            Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
            Assert.assertEquals(200, response.code());
            Assert.assertNotNull(response.body());
        }
    }

    @Test(enabled = true, priority = 4, description = "Fill Details By Order Id null requestBody")
    void Fill_Details_By_Order_Id_Null_Request() throws IOException {
        FillLookupByOrderIdRequest fillLookupByOrderIdRequest = new FillLookupByOrderIdRequest();
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

            Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
            Assert.assertEquals(400, response.code());
    }

    @Test(enabled = true, priority = 5, description = "Fill Details By Order Id invalid PRefId")
    void Fill_Details_By_Order_Id_Invalid_PRefId() throws IOException {

        FillLookupByOrderIdRequest fillLookupByOrderIdRequest = new FillLookupByOrderIdRequest();
        fillLookupByOrderIdRequest.setPRefId("1-NTU0OC0xNz");
        fillLookupByOrderIdRequest.setPurchaseOrderLineId("1");
        fillLookupByOrderIdRequest.setOmsOrderId("test-1234");
        fillLookupByOrderIdRequest.setOmsOrderLineId("1");

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
        Assert.assertEquals(500, response.code());
    }

    @Test(enabled = true, priority = 6, description = "Fill Details By Order Id null PRefId")
    void Fill_Details_By_Order_Id_Null_PRefId() throws IOException {

        FillLookupByOrderIdRequest fillLookupByOrderIdRequest = new FillLookupByOrderIdRequest();
        fillLookupByOrderIdRequest.setPRefId(null);
        fillLookupByOrderIdRequest.setPurchaseOrderLineId("1");
        fillLookupByOrderIdRequest.setOmsOrderId("test-1234");
        fillLookupByOrderIdRequest.setOmsOrderLineId("1");

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<FillDetailsResponse> response = rxOrchestratorRetrofit.getFillDetailsLookupByOrderAPIResponse(cid, fillLookupByOrderIdRequest, reqId, reqTrackingId);
        Assert.assertEquals(400, response.code());
    }

    /**
     * Method to delete patient and rx from informix and OCP*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown() throws IOException {

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, eodRxs, patientId);
        rxpdUtils.deletePatientAndRx(STORE_NBR, cancelledRxs, patientId);


        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.deleteAccountV1(cid, DOMAIN_ID, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        org.testng.Assert.assertEquals(apiResponse.code(), 200, errorMessage);

        DeleteAccountV1Response deleteAccountV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
                        DeleteAccountV1Response.class);

        Assertions.assertEquals(deleteAccountV1Response.getOnlineAccountId(), cid);
        Assertions.assertEquals(deleteAccountV1Response.getAuthPatientId(), String.valueOf(patientId));
        Assertions.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), String.valueOf(STORE_NBR));
    }

}
