package rxorchestrator;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.ReadyForPickup;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.STORE_NBR;


@Slf4j
public class MedicaidRestrictionTests {

    WrapperUtils wrapperUtils=new WrapperUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    private FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();;
    private List<InputResponse> rfpRxsWithInsuranceDetails;
    private RxpdUtils rxpdUtils;
    AutomationManager am = AutomationManager.getInstance();
    DBUtils dbUtils = new DBUtils();
    private String patientId;
    private String cid;
    private String emailId;
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private Integer INSURANCE_CARRIER_PLAN_ID = 101;
    private Integer INSURANCE_CARRIER_COMPANY_ID = 122375;
    private String CARD_HOLDER_ID = "WBR120";
    private Integer INS_PLAN_TYPE_CODE = 1000;
    private Integer RELATIONSHIP_CODE = 3201;
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private String USER_ID = "VN50S29";


    /**
     * 1. Create a patient with insurance
     * 2. Create RFP Rx for the patient with insurance
     * 3. Verify the walmart plus membership status for the patient
     * 4. Get the fill summary details for the patient
     * 5. Verify the fill summary details for the patient
     * 6. Verify the ineligibility reason for the RFP Rx
     * @throws IOException
     */
    @BeforeClass
    void setContext() throws InterruptedException, IOException, ParseException {

        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, 1, patientEmailId, DOTCOM_PASSWORD);
        List<String> caregiverDetails = rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR), INSURANCE_CARRIER_PLAN_ID, INSURANCE_CARRIER_COMPANY_ID, CARD_HOLDER_ID, INS_PLAN_TYPE_CODE, RELATIONSHIP_CODE);
        am.performSleep(5);
        patientId = caregiverDetails.get(1);
        Log.info("Patient with medicaid insurance paitientId: " + patientId);
        cid = caregiverDetails.get(0);
        emailId= patientEmailId;
        Log.info("Patient with medicaid insurance CID: " + cid);

        connexusAPIManager.updatePatientInfoCentralData(Integer.parseInt(patientId), STORE_NBR, USER_ID);

        am.performSleep(5);

        rfpRxsWithInsuranceDetails = rxpdUtils.rfpFillsForPatientWithMedicaidInsurance(Integer.parseInt(patientId), STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE, 1);

        am.performSleep(300);

    }

    /**
      * 1. Verify the walmart plus membership status for the patient
      * 2. Get the fill summary details for the patient
      * 3. Verify the fill summary details for the patient
      * 4. Verify the ineligibility reason for the RFP Rx
     * @throws InterruptedException
     */
    @Test(enabled = true, priority = 1, description = "ATC is ineligible for medicaid restricted state for non walmart plus member in fillSummary flow")
    public void Pharmacy_Item_Eligibility_Response_For_Non_walmart_plus_member() throws InterruptedException {
        Log.info("Patient cid: " + cid);
        Log.info("Patient emailId: " + emailId);
        ServiceResponse walmartPlusResponse = rxpdUtils.getWalmartPlusMembership(emailId);
        Assert.assertEquals("Check status of walmart plus membership get ",400, walmartPlusResponse.getStatusCode());

        JSONObject jsonObject = new JSONObject(walmartPlusResponse.getDataResponse());
        JSONObject astroDetails = jsonObject.getJSONObject("astroDetails");
        Log.info("walmartPlus status for cid "+cid +"is "+astroDetails.getString("status"));
        Assert.assertEquals("NOT_FOUND", astroDetails.getString("status"));

        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        Log.info("Ineligibility reason message: " + readyForPickup.getAddToCartEligibility().getIneligibilityReason().get(0).getMessage());
        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());
        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());
        Assert.assertEquals(readyForPickup.getAddToCartEligibility().getIneligibilityReason().get(0).getMessage(),
                "Prescription ineligible due state specific medicaid plan restriction");
        Assert.assertEquals(readyForPickup.getAddToCartEligibility().getIneligibilityReason().get(0).getCode(),
                "RULE-IR-002");
    }

    /**
     * 1. update the patient with walmart plus membership
     * 2. update Rx Sale Detail with TPS Submitted
     * 2. Get the fill summary details for the patient
     * 3. Verify the fill summary details for the patient
     * 4. Verify the ineligibility reason for the RFP Rx
     * @throws InterruptedException
     */
    @Test(enabled = true, priority = 2, description = "ATC is eligible for medicaid restricted state for walmart plus member in fillSummary flow")
    public void Pharmacy_Item_Eligibility_Response_For_walmart_plus_member() throws InterruptedException {
        Log.info("Patient cid: " + cid);
        Log.info("Patient emailId: " + emailId);
        Log.info("RX Fill Id: " + rfpRxsWithInsuranceDetails.get(0).getRxFillId());
        // Add walmart plus membership for the patient
        ServiceResponse walmartPlusResponse = rxpdUtils.addWalmartPlusMembership(emailId);
        // Update Rx Sale Detail with TPS Submitted
        dbUtils.insertRxSaleDetailWithTPSSubmitted(STORE_NBR,rfpRxsWithInsuranceDetails.get(0).getRxFillId());
        // Wait for 500 ms to ensure the membership is updated and in dp a/c orch cache time 5mins
        am.performSleep(500);
        Assert.assertEquals("Check status of walmart plus membership update ",200, walmartPlusResponse.getStatusCode());
        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        Log.info("Ineligibility reason message: " + readyForPickup.getAddToCartEligibility().getIneligibilityReason());
        Log.info("Fill eligibility "+ readyForPickup.getAddToCartEligibility().isEligible());
        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());

        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());
        Assert.assertTrue(readyForPickup.getAddToCartEligibility().getIneligibilityReason().isEmpty());

    }

    /**
     * Method to delete patient and rx from informix*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){
        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxsWithInsuranceDetails, Integer.parseInt(patientId));
    }
}