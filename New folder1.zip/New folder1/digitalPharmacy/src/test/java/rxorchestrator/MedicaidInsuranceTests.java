package rxorchestrator;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Input.InputResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.ReadyForPickup;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.RxOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemEligibilityRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PharmacyItemResponse;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.RxpdUtils.*;

public class MedicaidInsuranceTests {
    private static final Logger logger = LoggerFactory.getLogger(MedicaidInsuranceTests.class);

    WrapperUtils wrapperUtils=new WrapperUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    private FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();;
    private List<InputResponse> rfpRxsWithInsuranceDetails;
    private RxOrchestratorRetrofit rxOrchestratorRetrofit = new RxOrchestratorRetrofit();
    private RxpdUtils rxpdUtils;
    AutomationManager am = AutomationManager.getInstance();
    private String patientId;
    private String cid;
    private String DOB = "01011998";
    private String DOTCOM_PASSWORD = "Test@1234";
    private Integer INSURANCE_CARRIER_PLAN_ID = 128;
    private Integer INSURANCE_CARRIER_COMPANY_ID = 100167;
    private String CARD_HOLDER_ID = "WBR120";

    // insPlanTypeCode for medicaid insurance
    private Integer INS_PLAN_TYPE_CODE = 1000;
    private Integer RELATIONSHIP_CODE = 3201;
    private List<String> NDC_LIST = Arrays.asList("68382056510");
    private Integer DISPENSE_TYPE = 1;
    private Integer NUM_REFILLS = 2;
    private Integer PRIORITY_ID = 21100;
    private Integer REQUEST_TYPE_CODE = 1600;
    private String INPUT_PICKUP_DATE = wrapperUtils.getPickUpDate();
    private String INPUT_RX_EXP_DATE = wrapperUtils.getExpiryDate();
    private String ELIGIBILITY_TYPE = "ADD_TO_CART";
    private String USER_ID = "VN50S29";
    private String ERROR_CODE = "RULE-IR-003";


    /**
     * Medicaid switch to cash flow is active only on store 5597*
     * Sequence of API call to test medicaid switch to non-medicaid *
     * create new patient with TP*
     * Insurance plan type code should be 1000 only*
     * get patientId from CPR*
     * get cid from email using ca service API*
     * update central data with newly created patient details*
     * Added store state in ccm QA override*
     * create rfp rxs*
     * delete created patient and rxs*
     * @throws IOException
     */@BeforeClass
    void setContext() throws InterruptedException, IOException, ParseException {

        String patientEmailId = CommonUtil.generateRandomEmailId(10);
        String patientFirstName = CommonUtil.generateRandomFirstName(5);
        String patientLastName = CommonUtil.generateRandomLastName(5);
        rxpdUtils = new RxpdUtils(STORE_NBR, patientFirstName, patientLastName, DOB, 1, patientEmailId, DOTCOM_PASSWORD);

//         List.of(cid, patientId, storeId)
        List<String> caregiverDetails = rxpdUtils.testAccountCreation_WithTP(patientEmailId, patientFirstName, patientLastName, DOB, String.valueOf(STORE_NBR), INSURANCE_CARRIER_PLAN_ID, INSURANCE_CARRIER_COMPANY_ID, CARD_HOLDER_ID, INS_PLAN_TYPE_CODE, RELATIONSHIP_CODE);

        am.performSleep(5);

        patientId = caregiverDetails.get(1);
        logger.info("Patient with medicaid insurance paitientId: " + patientId);

        cid = caregiverDetails.get(0);
        logger.info("Patient with medicaid insurance cid: " + cid);

        connexusAPIManager.updatePatientInfoCentralData(Integer.parseInt(patientId), STORE_NBR, USER_ID);

        am.performSleep(5);

        rfpRxsWithInsuranceDetails = rxpdUtils.rfpFillsForPatientWithMedicaidInsurance(Integer.parseInt(patientId), STORE_NBR, NDC_LIST, DISPENSE_TYPE, NUM_REFILLS, PRIORITY_ID, REQUEST_TYPE_CODE, INPUT_PICKUP_DATE, INPUT_RX_EXP_DATE, 1);
        am.performSleep(300);

    }

    @Test(enabled = true, priority = 1, description = "Pharmacy Item Eligibility ineligible addToCart eligibility response for medicaid switch to cash")
    public void Pharmacy_Item_Eligibility_Response_For_Medicaid_SwitchToCash() throws IOException, ParseException, InterruptedException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        PharmacyItemEligibilityRequest pharmacyItemEligibilityRequest = rxpdUtils.getPharmacyItemEligibilityRequest(rfpRxsWithInsuranceDetails, STORE_NBR);
        logger.info("Pharmacy Item Eligibility request: " + pharmacyItemEligibilityRequest);
        Reporter.logJSON("Pharmacy Item Eligibility request: ", pharmacyItemEligibilityRequest);
        am.performSleep(180);
        Response<PharmacyItemResponse> pharmacyItemEligibilityResponse = rxOrchestratorRetrofit.getPharmacyItemEligibilityResponse(
                cid, pharmacyItemEligibilityRequest, ELIGIBILITY_TYPE, String.valueOf(STORE_NBR), reqId, reqTrackingId);
        Assert.assertEquals(200, pharmacyItemEligibilityResponse.code());
        Assert.assertNotNull(pharmacyItemEligibilityResponse.body());
        Assert.assertNotNull(pharmacyItemEligibilityResponse.body().getPayload().getFills().get(0).getPRefId());
        Assert.assertNotNull(pharmacyItemEligibilityResponse.body().getPayload().getFills().get(0).getCheckoutEligibility());
        Assert.assertFalse(pharmacyItemEligibilityResponse.body().getPayload().getFills().get(0).getCheckoutEligibility().isEligible());
        Assert.assertEquals(pharmacyItemEligibilityResponse.body().getPayload().getFills().get(0).getCheckoutEligibility().getIneligibilityReason().get(0).getMessage(),
                "Prescription ineligible due to WA/MT/OR state medicaid restriction");
        Assert.assertEquals(pharmacyItemEligibilityResponse.body().getPayload().getFills().get(0).getCheckoutEligibility().getIneligibilityReason().get(0).getCode(),
                ERROR_CODE);
    }

    @Test(enabled = true, priority = 2, description = "Fill Summaries success response with medicaid insurance")
    public void Fill_Summary_Response_For_Medicaid_SwitchToCash(){

        am.performSleep(300);
        ServiceResponse fillsSummaryResponse = fillSummaryWrapper.getFillSummaryDetails(cid);
        Assert.assertEquals(200, fillsSummaryResponse.getStatusCode());
        Assert.assertNotNull(fillsSummaryResponse.getDataResponse());
        FillSummaryResponse apiResponse = fillsSummaryResponse.getDataResponse(FillSummaryResponse.class);

        Assert.assertEquals(cid, apiResponse.getCustomer().getCustomerId());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getFirstName());
        Assert.assertNotNull(apiResponse.getCustomer().getName().getLastName());

        ReadyForPickup readyForPickup = apiResponse.getCustomer().getFills().getReadyForPickup().get(0);

        // For ready for pickup rxs
        Assert.assertNotNull(readyForPickup.getPRefId());
        Assert.assertNotNull(readyForPickup.getImageUrl());
        Assert.assertNotNull(readyForPickup.getPatientId());
        Assert.assertNotNull(readyForPickup.getStoreId());

        Assert.assertNotNull(readyForPickup.getDrug().getName());
        Assert.assertNotNull(readyForPickup.getDrug().getNdcNumber());
        Assert.assertNotNull(readyForPickup.getFillId());

        Assert.assertFalse(readyForPickup.getAddToCartEligibility().isEligible());
        Assert.assertEquals(readyForPickup.getAddToCartEligibility().getIneligibilityReason().get(0).getMessage(),
                "Prescription ineligible due to WA/MT/OR state medicaid restriction");
        Assert.assertEquals(readyForPickup.getAddToCartEligibility().getIneligibilityReason().get(0).getCode(),
                ERROR_CODE);


        int noOfStores = apiResponse.getStores().size();
        for (int i = 0; i < noOfStores; i++){
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreId());
            Assert.assertNotNull(apiResponse.getStores().get(i).getPharmacyOperatingHours());
            Assert.assertNotNull(apiResponse.getStores().get(i).getStoreName());
            Assert.assertNotNull(apiResponse.getStores().get(i).getTimeZone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getContact().getPhone());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getAddressLine1());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCountry());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getCity());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getPostalCode());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getType());
            Assert.assertNotNull(apiResponse.getStores().get(i).getAddress().get(0).getState());
        }
    }

    /**
     * Method to delete patient and rx from informix*
     * after executing all the tests because of patient creation on every run*
     * @throws IOException
     */
    @AfterClass(alwaysRun = true)
    void tearDown(){

        rxpdUtils.deletePatientAndRx(STORE_NBR, rfpRxsWithInsuranceDetails, Integer.parseInt(patientId));
    }

}
