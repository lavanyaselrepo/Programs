package accountorchestrator.validateDob;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.ApprovalStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.junit.jupiter.api.AfterEach;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class ValidateDependentDobServiceTests {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetroFit;
    private ObjectMapper mapper = new ObjectMapper();
    private Gson gson = new GsonBuilder().create();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String commonDobCPRFormat = null;
    private String commonDobDPFormat = null;
    private String customerAccountId = null;
    private String commonStoreNbr = null;
    private String commonPatientId = null;
    private String caregiver1 = null;
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private String accountCreationSource = "smsOtpVerification";
    private String dependentStoreNbr = null;
    private String dependentPatientId = null;
    private String dependentFirstName = null;
    private String dependentLastName = null;
    private String dependentCustomerAccountId = null;
    private String dependentCustomerEmailId = null;
    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent1CustomerAccountId = null;
    private String dependent1CustomerEmailId = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForLessThan18 = null;
    private String commonDobDPFormatForLessThan18 = null;
    private String HUMAN = "HUMAN";
    private String PET = "PET";

    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        wcpRetroFit = new WCPRetroFit();

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);
        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
        commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);
        
    }
    @BeforeMethod
    void setUpTest() throws Exception {
        Date date = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
        commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

        commonStoreNbr = CommonUtil.generateRandomNumber(6);
        commonPatientId = CommonUtil.generateRandomNumber(9);

        String caregiver1EmailId = CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = RandomStringUtils.randomAlphabetic(5);
        String caregiver1LastName = RandomStringUtils.randomAlphabetic(5);

        customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                caregiver1EmailId,
                commonPassword,
                commonPhoneNo,
                caregiver1FirstName,
                caregiver1LastName,
                null);

        createCPRAccount(commonStoreNbr, commonPatientId, commonDobCPRFormatForOlderThan18 , HUMAN , caregiver1FirstName, caregiver1LastName);
        createPharmacyAccount(customerAccountId, commonStoreNbr, commonPatientId);

        // dependent - ADULT, ACTIVE
        dependentCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependentStoreNbr = CommonUtil.generateRandomNumber(6);
        dependentPatientId = CommonUtil.generateRandomNumber(9);
        dependentFirstName = RandomStringUtils.randomAlphabetic(5);
        dependentLastName = RandomStringUtils.randomAlphabetic(5);
        dependentCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                dependentCustomerEmailId,
                commonPassword,
                commonPhoneNo,
                dependentFirstName,
                dependentLastName,
                null);
        createCPRAccount(
                dependentStoreNbr,
                dependentPatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                dependentFirstName,
                dependentLastName);
        createPharmacyAccount(
                dependentCustomerAccountId,
                dependentStoreNbr,
                dependentPatientId);
        WCPAddDependentRequest.Dependent wcpDependent2 = WCPAddDependentRequest.Dependent.builder()
                .ownerId(WCPAddDependentRequest.Identifier.builder().id(customerAccountId).build())
                .groupType(GroupType.FAM.name())
                .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentCustomerAccountId).build())
                .memberType(Type.ADULT.name())
                .notificationEmail(dependentCustomerEmailId)
                .membershipStatus(ApprovalStatus.ACTIVE.name())
                .build();
        WCPAddDependentRequest wcpAddDependentRequest2 = WCPAddDependentRequest.builder()
                .payload(WCPAddDependentRequest.Payload.builder()
                        .dependent(wcpDependent2)
                        .build())
                .build();
        wcpRetroFit.addDependent(wcpAddDependentRequest2, dependentCustomerAccountId);

        // Allow WCP dependent linkage to propagate before the test starts
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterEach
    void cleanUp() throws IOException {

        // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
        // delete CPR account

        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    public void createCPRAccount(
            String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
                break; // success — exit retry loop
            }
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(
            priority = 0,
            description = "Validate DOB success case")
    public void validateDependentDobSuccess() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Build request
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob(commonDobDPFormat); // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(
                        customerAccountId, validateDependentDobV1Request,domainId, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Parsing the response

        ValidateDobV1Response validateDobV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>)
                                validateDobResponse.body().getPayload()),
                        ValidateDobV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(validateDobResponse.code(), 200, errorMessage);
        Assert.assertNotNull(validateDobResponse.body().getPayload(), "Payload is null");
        Assert.assertEquals(validateDobV1Response.isIsValidDob(), true, errorMessage);
    }

    @Test(priority = 1, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt01() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Pre-check — verify correct DOB returns 200 before testing incorrect attempts
        ValidateDependentDobV1RequestDependentInfo correctDependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob(commonDobDPFormat); // correct DOB in MMDDYYYY format

        ValidateDependentDobV1Request correctDobRequest = new ValidateDependentDobV1Request()
                .dependentInfo(correctDependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> correctDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, correctDobRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(correctDobResponse.code(), 200,
                "Pre-check: Expected 200 for correct DOB but got " + correctDobResponse.code());

        // Step 3: Build request with incorrect DOB
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("01012001");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 4: Call validateDependentDob with incorrect DOB
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);

        // Step 5: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 6: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 7: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 8: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 9: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1017");

        // Step 10: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 11: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 1);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 5);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 2, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt03() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Pre-check — verify correct DOB returns 200 before testing incorrect attempts
        ValidateDependentDobV1RequestDependentInfo correctDependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob(commonDobDPFormat); // correct DOB in MMDDYYYY format

        ValidateDependentDobV1Request correctDobRequest = new ValidateDependentDobV1Request()
                .dependentInfo(correctDependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> correctDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, correctDobRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(correctDobResponse.code(), 200,
                "Pre-check: Expected 200 for correct DOB but got " + correctDobResponse.code());

        // Step 3: Build request with incorrect DOB
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("01012001");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 4: Call validateDependentDob with incorrect DOB (3 times)
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);

        // Step 5: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 6: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 7: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 8: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 9: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1017");

        // Step 10: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 11: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 3);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 3);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 3, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt04() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Pre-check — verify correct DOB returns 200 before testing incorrect attempts
        ValidateDependentDobV1RequestDependentInfo correctDependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob(commonDobDPFormat); // correct DOB in MMDDYYYY format

        ValidateDependentDobV1Request correctDobRequest = new ValidateDependentDobV1Request()
                .dependentInfo(correctDependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> correctDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, correctDobRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(correctDobResponse.code(), 200,
                "Pre-check: Expected 200 for correct DOB but got " + correctDobResponse.code());

        // Step 3: Build request with incorrect DOB
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("01012001");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 4: Call validateDependentDob with incorrect DOB (4 times)
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse3 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);

        // Step 5: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 6: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 7: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 8: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 9: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1020");

        // Step 10: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 11: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 4);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 2);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 4, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt05() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Pre-check — verify correct DOB returns 200 before testing incorrect attempts
        ValidateDependentDobV1RequestDependentInfo correctDependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob(commonDobDPFormat); // correct DOB in MMDDYYYY format

        ValidateDependentDobV1Request correctDobRequest = new ValidateDependentDobV1Request()
                .dependentInfo(correctDependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> correctDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, correctDobRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(correctDobResponse.code(), 200,
                "Pre-check: Expected 200 for correct DOB but got " + correctDobResponse.code());

        // Step 3: Build request with incorrect DOB
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("01012001");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 4: Call validateDependentDob with incorrect DOB (5 times)
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse3 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse4 =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);

        // Step 5: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 6: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 7: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 8: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 9: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1021");

        // Step 10: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 11: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 5);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 1);
    }

    @Test(
            priority = 5,
            description = "Validate DOB invalid domainId")
    public void validateDobInvalidDomainId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        // Build request
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("01012001");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 3: Call validateDependentDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, "INVALID", reqId, reqTrackingId);


        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1001"), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 6,
            description = "Validate DOB with incorrect date format in input")
    public void validateDobIncorrectDateFormat() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        // Build request
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependentCustomerAccountId)
                .dob("19900101");  // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step 3: Call validateDependentDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(customerAccountId, validateDependentDobV1Request, domainId, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1019"), "DPR-DPACCOR-1019");
    }
    @Test(
            priority = 7,
            description = "Validate DOB error scenario where dependent linkageStatus is invalid ")
    public void validateDependentDobWithInvalidDependentLinkageStatus() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // dependent - ADULT, PENDING
        dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent1LastName = RandomStringUtils.randomAlphabetic(5);
        dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                dependent1CustomerEmailId,
                commonPassword,
                commonPhoneNo,
                dependent1FirstName,
                dependent1LastName,
                null);
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                dependent1FirstName,
                dependent1LastName);
        createPharmacyAccount(
                dependent1CustomerAccountId,
                dependent1StoreNbr,
                dependent1PatientId);
        WCPAddDependentRequest.Dependent wcpDependent4 = WCPAddDependentRequest.Dependent.builder()
                .ownerId(WCPAddDependentRequest.Identifier.builder().id(customerAccountId).build())
                .groupType(GroupType.FAM.name())
                .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent1CustomerAccountId).build())
                .memberType(Type.ADULT.name())
                .notificationEmail(dependent1CustomerEmailId)
                .membershipStatus(ApprovalStatus.PENDING.name())
                .build();
        WCPAddDependentRequest wcpAddDependentRequest4 = WCPAddDependentRequest.builder()
                .payload(WCPAddDependentRequest.Payload.builder()
                        .dependent(wcpDependent4)
                        .build())
                .build();
        wcpRetroFit.addDependent(wcpAddDependentRequest4, dependent1CustomerAccountId);

        // Build request
        ValidateDependentDobV1RequestDependentInfo dependentInfo = new ValidateDependentDobV1RequestDependentInfo()
                .customerAccountId(dependent1CustomerAccountId)
                .dob(commonDobDPFormat); // MMDDYYYY

        ValidateDependentDobV1Request validateDependentDobV1Request = new ValidateDependentDobV1Request()
                .dependentInfo(dependentInfo)
                .flowName("ADULT_DEPENDENT_PHI_AUTH");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDependentDob(
                        customerAccountId, validateDependentDobV1Request,domainId, reqId, reqTrackingId);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 5: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 6: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 7: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 8: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1015");

    }



    private static void logFlowIdentifiers(
            String customerAccountId,
            String domainId,
            String reqId,
            String reqTrackingId) {
        Reporter.logJSON("customerAccountId", customerAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    public void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId) throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId);
        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(commonDobDPFormat)
                                .build())
                .build();
    }



}
