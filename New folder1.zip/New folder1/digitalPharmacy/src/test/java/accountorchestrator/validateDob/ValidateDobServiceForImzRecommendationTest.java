package accountorchestrator.validateDob;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.junit.jupiter.api.AfterEach;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ValidateDobServiceForImzRecommendationTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private ObjectMapper mapper = new ObjectMapper();
    private Gson gson = new GsonBuilder().create();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String commonDobCPRFormat = null;
    private String commonDobDPFormat = null;
    private String customerAccountId = null;
    private String commonStoreNbr = null;
    private String commonPatientId = null;

    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    }
    @BeforeMethod
    void setUpTest() throws Exception {
        Date date = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
        commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

        String customerFirstName = RandomStringUtils.randomAlphabetic(5);
        String customerLastName = RandomStringUtils.randomAlphabetic(5);

        commonStoreNbr = CommonUtil.generateRandomNumber(6);
        commonPatientId = CommonUtil.generateRandomNumber(9);
        customerAccountId = CommonUtil.generateRandomEmailId(10);

        createCPRAccount(commonStoreNbr, commonPatientId, customerFirstName, customerLastName);
    }

    @AfterEach
    void cleanUp() throws IOException {

        // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
        // delete CPR account

        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
    }
    /**
     * Create CPR Account
     *
     * @throws IOException
     */
    public void createCPRAccount(String storeNbr, String patientId, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
        cprPatientRequest.getPatientInfo().setFirstName(firstName);
        cprPatientRequest.getPatientInfo().setLastName(lastName);

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
                break;
            }
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(
            priority = 0,
            description = "Validate DOB success case")
    public void validateDobSuccess() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Build request
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob(commonDobDPFormat); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDob(
                        customerAccountId, validateDobV1Request,domainId, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Parsing the response to the GetFamLinksResponse class so that we can assert
        // GetFamLinks
        ValidateDobV1Response validateDobV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>)
                                validateDobResponse.body().getPayload()),
                        ValidateDobV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(validateDobResponse.code(), 200, errorMessage);
        Assert.assertNotNull(validateDobResponse.body().getPayload(), "Payload is null");
        Assert.assertEquals(validateDobV1Response.isIsValidDob(), true, errorMessage);
    }

    @Test(priority = 1, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt01() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob("01012001"); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step 3: Call validateDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 5: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 6: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 7: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 8: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1017");

        // Step 9: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 10: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 1);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 5);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 2, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt03() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob("01012001"); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step 3: Call validateDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 5: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 6: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 7: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 8: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1017");

        // Step 9: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 10: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 3);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 3);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 3, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt04() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob("01012001"); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step 3: Call validateDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse3 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 5: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 6: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 7: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 8: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1020");

        // Step 9: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 10: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 4);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 2);
        Assert.assertEquals(cooldown.getRemainingTime(), 0L);
    }

    @Test(priority = 4, description = "Validate DOB incorrect scenario with cooldown")
    public void validateDobIncorrectAttempt05() throws IOException {
        // Step 1: Generate tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with incorrect DOB
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob("01012001"); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step 3: Call validateDob
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse1 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse2 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse3 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse4 =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> validateDobResponse =
                accountOrchestratorRetrofit.validateDob(customerAccountId, validateDobV1Request, domainId, reqId, reqTrackingId);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        // Step 5: Get error body as string
        String errorJson =  validateDobResponse.errorBody().string() ;
        // Step 6: Log the raw JSON for debugging
        Reporter.logJSON("ValidateDOB errorBody", errorJson);

        // Step 7: Deserialize manually
        ServiceResponseValidateDobV1 serviceResponse = null;
        try {
            serviceResponse = gson.fromJson(errorJson, ServiceResponseValidateDobV1.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody JSON into ServiceResponseValidateDobV1: " + e.getMessage());
        }

        Assert.assertNotNull(serviceResponse, "ServiceResponse should not be null");

        // Step 8: Assert error object
        Error errorResponse = serviceResponse.getError();
        Assert.assertNotNull(errorResponse, "Error object is null");
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1021");

        // Step 9: Assert payload
        ValidateDobV1Response payload = serviceResponse.getPayload();
        Assert.assertNotNull(payload, "Payload should not be null");
        Assert.assertFalse(payload.isIsValidDob(), "DOB should be incorrect");

        // Step 10: Assert cooldown
        CoolDownStatus cooldown = payload.getCoolDownStatus();
        Assert.assertNotNull(cooldown, "Cooldown should not be null");
        Assert.assertEquals(cooldown.getFailedAttemptsCount(), 5);
        Assert.assertEquals(cooldown.getAttemptsRemaining(), 1);
    }

    @Test(
            priority = 5,
            description = "Validate DOB invalid domainId")
    public void validateDobInvalidDomainId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Build request
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob(commonDobDPFormat); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDob(
                        customerAccountId, validateDobV1Request,"INVALID", reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1001"), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 6,
            description = "Validate DOB with incorrect date format in input")
    public void validateDobIncorrectDateFormat() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Build request
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId(commonPatientId)
                .storeNbr(commonStoreNbr)
                .dob("19990101"); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDob(
                        customerAccountId, validateDobV1Request,domainId, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 400,
                "Expected 400 response  " + validateDobResponse.code());

        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1019"), "DPR-DPACCOR-1019");
    }

    @Test(
            priority = 7,
            description = "Validate DOB storeNbr patientId does not exist in CPR")
    public void validateDobIncorrectStoreNbrPatientId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // Build request
        ValidateDobV1RequestCustomerInfo customerInfo = new ValidateDobV1RequestCustomerInfo()
                .patientId("111111")
                .storeNbr("111111")
                .dob(commonDobDPFormat); // MMDDYYYY

        ValidateDobV1Request validateDobV1Request = new ValidateDobV1Request()
                .customerInfo(customerInfo)
                .flowName("IMZ_RECOMMENDATION");

        // Step - 2: Calling validateDOB with a valid customerAccountId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                validateDobResponse =
                accountOrchestratorRetrofit.validateDob(
                        customerAccountId, validateDobV1Request,domainId, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, validateDobResponse);

        // Step 4: Assert HTTP status
        Assert.assertEquals(validateDobResponse.code(), 404,
                "Expected 404 response  " + validateDobResponse.code());

        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-6001"), "DPR-DPACCOR-6001");
    }



    private static void logFlowIdentifiers(
            String customerAccountId,
            String domainId,
            String reqId,
            String reqTrackingId) {
        Reporter.logJSON("customerAccountId", customerAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }


}
