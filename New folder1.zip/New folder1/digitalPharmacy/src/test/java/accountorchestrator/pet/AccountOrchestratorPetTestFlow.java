package accountorchestrator.pet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class AccountOrchestratorPetTestFlow {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonPatientId = null;
  private String commonPetId = null;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonStoreNbr = null;

  @BeforeClass
  void setContext() {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
  }

  @Test(
      priority = 0,
      description = "Create pet account success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting unique commonPatientId, commonPetId and commonStoreNbr
    commonPatientId = CommonUtil.generateRandomNumber(7);
    commonPetId = CommonUtil.randomUUID();
    commonStoreNbr = CommonUtil.generateRandomNumber(4);

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - 3: Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 4: Setting Customer Info where commonPatientId will be created in this test and will
    // be also used in subsequent tests
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    createPetAccountV1Request.getCustomerInfo().setPatientId(commonPatientId);

    // Step - 5: calling the createPetAccountV1 orchestrator API to create an account with the above
    // made request and the commonPetId will also be created which will be also used in subsequent
    // tests
    Response<ServiceResponse> createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            commonPetId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, createPetAccountV1Response);

    // Step - 7: Asserting response
    Assert.assertEquals(createPetAccountV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to PetAccountActionResponse class so that we can assert petId
    PetAccountActionResponse petAccountActionResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) createPetAccountV1Response.body().getPayload()),
            PetAccountActionResponse.class);

    Assert.assertEquals(petAccountActionResponse.getPetId(), commonPetId);
  }

  @Test(
      priority = 1,
      description = "Create pet account 400 error due to invalid request",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1InvalidPayload(String payload) throws IOException {

    // Step - I: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - II: Preparing the request payload by mapping the JSON payload to
    // the CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // CASE 1: storeNbr null
    // Step - 1: Setting storeNbr as null
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(null);

    // Step - 2: Calling createPetAccountV1 API for CASE - 2
    Response<ServiceResponse> createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            commonPetId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createPetAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");

    // CASE 2: patientId null
    // Step - 1: Resetting the storeNbr as we are using the previous payload and setting patientId
    // as null
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    createPetAccountV1Request.getCustomerInfo().setPatientId(null);

    // Step - 2: Calling createPetAccountV1 API for CASE - 3
    createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            commonPetId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, createPetAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 2,
      description =
          "Create pet account Invalid response from entity due to already existing online account id",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestExistingOnlineAccountId(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 3: Setting patientId as unique random number string in the request payload
    createPetAccountV1Request.getCustomerInfo().setPatientId(CommonUtil.generateRandomNumber(7));

    // Step - 4: Calling createPetAccountV1 with already existing commonPetId and unique patientId
    Response<ServiceResponse> createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            commonPetId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createPetAccountV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2004");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 4,
      description =
          "Create pet account Invalid response because patient type in CPR does not match",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestInvalidPatientType(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 3: Setting patientId to a record which does not correspond to a PET patient type in
    // the request payload
    createPetAccountV1Request.getCustomerInfo().setStoreNbr("5572");
    createPetAccountV1Request.getCustomerInfo().setPatientId("123198");

    // Step - 4: Calling createPetAccountV1 with a unique PetId
    Response<ServiceResponse> createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            petId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createPetAccountV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(priority = 5, description = "Get pet patient info success case")
  public void getPetPatientInfoV1RequestSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = "e3523b47-ca49-4aac-aca3-c3e08c239";
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2: Calling getPetPatientInfoV1 with a PetId record which is present in CPR
    Response<ServiceResponse> getPetPatientInfoV1Response =
        accountOrchestratorRetrofit.getPetPatientInfoV1(petId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getPetPatientInfoV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getPetPatientInfoV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the PetPatientInfoV1Response class so that we can assert
    // patientInfo and patientLinks
    PetPatientInfoV1Response petPatientInfoV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getPetPatientInfoV1Response.body().getPayload()),
            PetPatientInfoV1Response.class);

    Assert.assertNotNull(petPatientInfoV1Response.getPatientInfo(), "patientInfo found null");
    Assert.assertNotNull(petPatientInfoV1Response.getPatientLinks(), "patientLinks found null");
  }

  @Test(
      priority = 6,
      description =
          "get pet patient info API call 404 found case where 404 is returned from CPR for storeId and patientId")
  public void getPetPatientInfoV1Request404FromCPR() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - 2: Calling getPetPatientInfoV1 with the commonPetId which is not present in CPR
    Response<ServiceResponse> getPetPatientInfoV1Response =
        accountOrchestratorRetrofit.getPetPatientInfoV1(commonPetId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getPetPatientInfoV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getPetPatientInfoV1Response.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 7,
      description =
          "get pet patient info API call 204 No Content case where 204 is returned from entity service for not existing petId")
  public void getPetPatientInfoV1Request204FromEntity() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2: Calling getPetPatientInfoV1 with a random PetId which is not created in entity
    Response<ServiceResponse> getPetPatientInfoV1Response =
        accountOrchestratorRetrofit.getPetPatientInfoV1(petId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getPetPatientInfoV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getPetPatientInfoV1Response.code(), 204, errorMessage);
  }

  @Test(
      priority = 8,
      description = "Update pet account success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - 2: We will update PatientId for the account created with commonPetId
    String patientId = CommonUtil.generateRandomNumber(7);

    // Step - 3: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 4: Setting Customer Info in the updatePetAccountV1Request
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    updatePetAccountV1Request.getCustomerInfo().setPatientId(patientId);

    // Step - 5: calling the updatePetAccountV1 orchestrator API to update the account with the
    // above
    // made request and using commonPetId
    Response<ServiceResponse> updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            commonPetId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updatePetAccountV1Response);

    // Step - 7: Asserting response
    Assert.assertEquals(updatePetAccountV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to PetAccountActionResponse class so that we can assert petId
    PetAccountActionResponse petAccountActionResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updatePetAccountV1Response.body().getPayload()),
            PetAccountActionResponse.class);

    Assert.assertEquals(petAccountActionResponse.getPetId(), commonPetId);

    // Step - 9 Setting commonPatientId to the new updated PatientId
    commonPatientId = patientId;
  }

  @Test(
      priority = 9,
      description = "Update pet account 400 error due to invalid request",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1InvalidPayload(String payload) throws IOException {

    // Step - I: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonPetId, reqId, reqTrackingId);

    // Step - II: Preparing the request payload by mapping the JSON payload to
    // the UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // CASE 1: storeNbr null
    // Step - 1: Setting storeNbr as null
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(null);

    // Step - 2: Calling updatePetAccountV1 API for CASE - 2
    Response<ServiceResponse> updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            commonPetId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updatePetAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");

    // CASE 2: patientId null
    // Step - 1: Resetting the storeNbr as we are using the previous payload and setting patientId
    // as null
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    updatePetAccountV1Request.getCustomerInfo().setPatientId(null);

    // Step - 2: Calling updatePetAccountV1 API for CASE - 3
    updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            commonPetId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, updatePetAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 10,
      description =
          "Update pet account Invalid response from entity due to not existing online account id",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestNotExistingOnlineAccountId(String payload)
      throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 3: Calling updatePetAccountV1 with the unique PetId
    Response<ServiceResponse> updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            petId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updatePetAccountV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 11,
      description =
          "Update pet account Invalid response from entity due to already associated storeNbr and patientId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestExistingStoreNbrAndPatientId(String payload)
      throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2:
    // *********************Creating a new account for this test***************************
    // Step - a: Creating a new account with online account id as random petId
    // the payload of update and create account are same so mapping it with the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - b: Setting a random PatientId
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    createPetAccountV1Request.getCustomerInfo().setPatientId(CommonUtil.generateRandomNumber(7));

    // Step - c: Calling the createPetAccountV1 API with the createPetAccountV1Request and random
    // petId
    Response<ServiceResponse> createPetAccountV1Response =
        accountOrchestratorRetrofit.createPetAccountV1(
            petId, createPetAccountV1Request, reqId, reqTrackingId);

    // Step - d: Building errorMessage in case the Assert for create account response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, createPetAccountV1Response);

    // Step - e: Asserting create account response
    Assert.assertEquals(createPetAccountV1Response.code(), 200, errorMessage);

    // ***************************************END*******************************************

    // Step - 3: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 4: Setting already existing commonPatientId as the patientId in the request payload
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    updatePetAccountV1Request.getCustomerInfo().setPatientId(commonPatientId);

    // Step - 5: Calling updatePetAccountV1 with the newly formed account associated with PetId
    // trying to update the PatientId with the already existing commonPatientId
    Response<ServiceResponse> updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            petId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 6: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updatePetAccountV1Response);

    // Step - 7: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 8: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2004");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 12,
      description =
          "Update pet account Invalid response because patient type in CPR does not match",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorPetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestInvalidPatientType(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String petId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(petId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 3: Setting patientId to a record which does not correspond to a PET patient type in
    // the request payload
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr("5572");
    updatePetAccountV1Request.getCustomerInfo().setPatientId("123198");

    // Step - 4: Calling updatePetAccountV1 with a unique PetId
    Response<ServiceResponse> updatePetAccountV1Response =
        accountOrchestratorRetrofit.updatePetAccountV1(
            petId, updatePetAccountV1Request, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updatePetAccountV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }
}
