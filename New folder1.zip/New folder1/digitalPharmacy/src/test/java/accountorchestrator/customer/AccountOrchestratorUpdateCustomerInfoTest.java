package accountorchestrator.customer;

import accountorchestrator.utils.AccountOrchestratorCommonUtils;
import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerAccountInfoV2Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.UpdateCustomerInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequestByCustomerType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AccountOrchestratorUpdateCustomerInfoTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String accountCreationSource = "idVerification";
    private String accountType = "INDIVIDUAL";
    private String customerType = "INDIVIDUAL";
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private final ObjectMapper mapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();
    private String caregiverCustomerEmailId = null;
    private String dependent1CustomerEmailId = null;
    private String dependent2CustomerEmailId = null;
    private String caregiverCustomerAccountId = null;
    private String dependent1CustomerAccountId = null;
    private String dependent2CustomerAccountId = null;
    private String caregiverStoreNbr = null;
    private String caregiverPatientId = null;
    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent2StoreNbr = null;
    private String dependent2PatientId = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForLessThan18 = null;
    private String commonDobDPFormatForLessThan18 = null;
    private String caregiverFirstName = null;
    private String caregiverLastName = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent2FirstName = null;
    private String dependent2LastName = null;
    private String HUMAN = "HUMAN";
    private String PET = "PET";
    private String trackID = CommonUtil.randomUUID();
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetrofit = new WCPRetroFit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

        caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
        commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

        // making test accounts
        caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
        caregiverPatientId = CommonUtil.generateRandomNumber(9);
        caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(caregiverCustomerEmailId,commonPassword,commonPhoneNo,caregiverFirstName,caregiverLastName,trackID);
        createCPRAccount(
                caregiverStoreNbr,
                caregiverPatientId,
                caregiverFirstName,
                caregiverLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);

        createPharmacyAccount(
                caregiverCustomerAccountId,
                caregiverStoreNbr,
                caregiverPatientId,
                commonDobDPFormatForOlderThan18);
        dependent1StoreNbr = "9928";
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(dependent1CustomerEmailId,commonPassword,commonPhoneNo,dependent1FirstName,dependent1LastName,trackID);
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                dependent1FirstName,
                dependent1LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                dependent1CustomerAccountId,
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobDPFormatForOlderThan18);
    }
    /**
     * Clean up for all created cpr accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                    } catch (IOException e) {
                    }
                });

        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                        // Handle the IOException
                    }
                });
    }

    private void wcpAddDependent(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId)
            throws Exception {
        Response<WCPAddDependentResponse> response = null;

        WCPAddDependentRequest wcpAddDependentRequest = AccountOrchestratorCommonUtils.getWCPAddDependentRequest(type, status, dependentAccountId, caregiverAccountId);

        // This will try to create a person account in CA, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetrofit.addDependent(wcpAddDependentRequest, caregiverAccountId);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP add dependent failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }
    private void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
            }
            break;
        }
    }

    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test(
            priority = 0,
            description =
                    "Update the communication for the customer who has 9928 profile")
    public void updateCustomerInfoSuccess() throws IOException, InterruptedException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("1291 PALACE")
                                .state("TN")
                                .city("BB TOWN")
                                .zipCode("786523503")
                                .build())
                        .communication(UpdateCustomerInfoV1Request.Communication.builder()
                                .phoneNumber("(737) 344-8713")
                                .type("home")
                                .build())
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateCustomerInfoV1Request);

        UpdateCustomerInfoV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>)
                                updateCustomerInfoResponse.body().getPayload()),
                        UpdateCustomerInfoV1Response.class);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 200);
        Assert.assertEquals(response.getCustomerAccountId(), dependent1CustomerAccountId);
        Thread.sleep(60000);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        dependent1CustomerAccountId, domainId, false, true, null, false,false, false, false, false);
        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);
        String expectedPhoneNumber = updateCustomerInfoV1Request.getCommunication().getPhoneNumber().replaceAll("\\D", "");
        String actualPhoneNumber = getCustomerAccountInfoV2Response.getCustomerInfo().getCommunicationInfo().get(0).getCommunicationId();
        String expectedAddressLine1 = updateCustomerInfoV1Request.getAddress().getAddressLine1();
        String actualAddressLine1 = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getAddressLine1();
        String expectedState = updateCustomerInfoV1Request.getAddress().getState();
        String actualState = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getState();
        Assert.assertEquals(actualPhoneNumber, expectedPhoneNumber);
        Assert.assertEquals(actualAddressLine1, expectedAddressLine1);
        Assert.assertEquals(actualState, expectedState);
    }
    @Test(
            priority = 1,
            description =
                    "Invalid phone number in request payload to UpdateCustomerInfo")
    public void updateCustomerInfoFailureWhenInvalidPhoneNumberInRequestPayload() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request = UpdateCustomerInfoV1Request.builder().communication(UpdateCustomerInfoV1Request.Communication.builder().phoneNumber("3423").build()).build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(UUID.randomUUID().toString(), domainId, updateCustomerInfoV1Request);
        Error errorResponse = CommonUtil.getErrorResponse(gson,updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400,errorMessage);
    }
    @Test(
            priority = 2,
            description =
                    "CustomerId not found in OCP table")
    public void updateCustomerInfoFailureWhenCustomerIdNotFound() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("1291 PALACE")
                                .state("TN")
                                .city("BB TOWN")
                                .zipCode("786523503")
                                .build())
                .communication(UpdateCustomerInfoV1Request.Communication.builder()
                        .phoneNumber("(737) 344-8713")
                        .type("home")
                        .build())
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(UUID.randomUUID().toString(), domainId, updateCustomerInfoV1Request);

        Assert.assertEquals(updateCustomerInfoResponse.code(), 204);
    }
    @Test(
            priority = 3,
            description =
                    "Invalid communication type in request payload to UpdateCustomerInfo")
    public void updateCustomerInfoFailureWhenRequestPayloadIsInvalid() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("1291 PALACE")
                                .state("TN")
                                .city("BB TOWN")
                                .zipCode("786523503")
                                .build())
                        .communication(UpdateCustomerInfoV1Request.Communication.builder()
                                .phoneNumber("(737) 344-8713")
                                .type("invalid")
                                .build())
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(UUID.randomUUID().toString(), domainId, updateCustomerInfoV1Request);
        Error errorResponse = CommonUtil.getErrorResponse(gson,updateCustomerInfoResponse);

        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400, errorMessage);
    }
    @Test(
            priority = 4,
            description =
                    "Invalid address line 1 in request payload to UpdateCustomerInfo")
    public void updateCustomerInfoFailureWhenInvalidAddressInRequestPayload() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("")
                                .state("TN")
                                .city("BB TOWN")
                                .zipCode("786523503")
                                .build())
                        .communication(UpdateCustomerInfoV1Request.Communication.builder()
                                .phoneNumber("(737) 344-8713")
                                .type("home")
                                .build())
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(UUID.randomUUID().toString(), domainId, updateCustomerInfoV1Request);
        Error errorResponse = CommonUtil.getErrorResponse(gson,updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400,errorMessage);
    }
    @Test(
            priority = 5,
            description =
                    "Update the communication for the customer who dont have 9928 profile")
    public void updateCustomerInfoSuccessWhenNo9928CPRProfile() throws IOException, InterruptedException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("1291 PALACE")
                                .state("TN")
                                .city("BB TOWN")
                                .zipCode("786523503")
                                .build())
                        .communication(UpdateCustomerInfoV1Request.Communication.builder()
                                .phoneNumber("(737) 344-8713")
                                .type("home")
                                .build())
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        UpdateCustomerInfoV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>)
                                updateCustomerInfoResponse.body().getPayload()),
                        UpdateCustomerInfoV1Response.class);
        Assert.assertEquals(response.getCustomerAccountId(), caregiverCustomerAccountId);
        Thread.sleep(60000);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        caregiverCustomerAccountId, domainId, false, true, null, false,false, false, false, false);
        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);
        String expectedPhoneNumber = updateCustomerInfoV1Request.getCommunication().getPhoneNumber().replaceAll("\\D", "");
        String actualPhoneNumber = getCustomerAccountInfoV2Response.getCustomerInfo().getCommunicationInfo().get(0).getCommunicationId();
        String expectedAddressLine1 = updateCustomerInfoV1Request.getAddress().getAddressLine1();
        String actualAddressLine1 = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getAddressLine1();
        String expectedState = updateCustomerInfoV1Request.getAddress().getState();
        String actualState = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getState();
        Assert.assertEquals(actualPhoneNumber, expectedPhoneNumber);
        Assert.assertEquals(actualAddressLine1, expectedAddressLine1);
        Assert.assertEquals(actualState, expectedState);
    }
    @Test(
            priority = 6,
            description =
                    "UpdateCustomerInfo request payload is empty/null")
    public void updateCustomerInfoFailureWhenEmptyRequestPayload() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);
        Error errorResponse = CommonUtil.getErrorResponse(gson,updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400,errorMessage);
    }
    @Test(
            priority = 7,
            description =
                    "UpdateCustomerInfo request payload is empty/null")
    public void updateCustomerInfoFailureWhenInvalidDomainId() throws IOException {
        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .build();
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, "invalid", updateCustomerInfoV1Request);
        Error errorResponse = CommonUtil.getErrorResponse(gson,updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400,errorMessage);
    }
    @Test(
            priority = 8,
            description = "Update customer info with emergency contact information - success")
    public void updateCustomerInfoWithEmergencyContactSuccess() throws IOException, InterruptedException {
        // Step 1: Create update request with emergency contact info
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("John")
                        .middleName("M")
                        .lastName("Doe")
                        .gender("M")
                        .dob("01011990")
                        .phoneNbr("5551234567")
                        .relationshipType("SPOUSE")
                        .build();
        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        // Step 2: Execute update
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        UpdateCustomerInfoV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>)
                                updateCustomerInfoResponse.body().getPayload()),
                        UpdateCustomerInfoV1Response.class);

        // Step 3: Verify update response
        Assert.assertEquals(updateCustomerInfoResponse.code(), 200); // UPDATE returns 202
        Assert.assertEquals(response.getCustomerAccountId(), caregiverCustomerAccountId);

        // Step 4: Wait for async processing
        Thread.sleep(60000);

        // Step 5: Verify emergency contact was saved by calling GET with includeEC=true
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        caregiverCustomerAccountId, domainId, false, true, null, false, true, true, false, false);

        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);

        // Step 6: Verify emergency contact data
        Assert.assertNotNull(getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo(),
                "Emergency contact info should be present after update");
        Assert.assertFalse(getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo().isEmpty(),
                "Emergency contact list should not be empty");

        var savedEmergencyContact = getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo().get(0);
        Assert.assertEquals(savedEmergencyContact.getFirstName(), "John");
        Assert.assertEquals(savedEmergencyContact.getMiddleName(), "M");
        Assert.assertEquals(savedEmergencyContact.getLastName(), "Doe");
        Assert.assertEquals(savedEmergencyContact.getGender(), "M");
        Assert.assertEquals(savedEmergencyContact.getPhoneNbr(), "5551234567");
        Assert.assertEquals(savedEmergencyContact.getRelationshipCode().getDescr(), "Spouse");
    }

    @Test(
            priority = 10,
            description = "Update customer info with all fields (address, communication, emergency contact) - success")
    public void updateCustomerInfoWithAllFieldsSuccess() throws IOException, InterruptedException {
        // Step 1: Create comprehensive update request
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("Mary")
                        .lastName("Williams")
                        .gender("F")
                        .dob("08201992") // MMDDYYYY format
                        .phoneNbr("5554567890")
                        .relationshipType("Parent")
                        .build();
        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("456 Main Street")
                                .addressLine2("Apt 2B")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75201")
                                .build())
                        .communication(UpdateCustomerInfoV1Request.Communication.builder()
                                .phoneNumber("(214) 555-0123")
                                .type("home")
                                .build())
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        // Step 2: Execute update
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        // Step 3: Verify update response
        Assert.assertEquals(updateCustomerInfoResponse.code(), 200);

        // Step 4: Wait for async processing
        Thread.sleep(60000);

        // Step 5: Verify all fields were updated
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        caregiverCustomerAccountId, domainId, false, true, null, false, true, true, false, false);

        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);

        // Step 6: Verify all updated fields
        // Verify phone number
        String expectedPhoneNumber = updateCustomerInfoV1Request.getCommunication().getPhoneNumber().replaceAll("\\D", "");
        String actualPhoneNumber = getCustomerAccountInfoV2Response.getCustomerInfo().getCommunicationInfo().get(0).getCommunicationId();
        Assert.assertEquals(actualPhoneNumber, expectedPhoneNumber);

        // Verify address
        String expectedAddressLine1 = updateCustomerInfoV1Request.getAddress().getAddressLine1();
        String actualAddressLine1 = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getAddressLine1();
        Assert.assertEquals(actualAddressLine1, expectedAddressLine1);

        String expectedCity = updateCustomerInfoV1Request.getAddress().getCity();
        String actualCity = getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().get(0).getCity();
        Assert.assertEquals(actualCity, expectedCity);

        // Verify emergency contact
        Assert.assertNotNull(getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo());
        var savedEmergencyContact = getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo().get(0);
        Assert.assertEquals(savedEmergencyContact.getFirstName(), "Mary");
        Assert.assertEquals(savedEmergencyContact.getLastName(), "Williams");
        Assert.assertEquals(savedEmergencyContact.getRelationshipCode().getDescr(), "Parent");
    }

    @Test(
            priority = 11,
            description = "Update customer info with invalid emergency contact - missing firstName")
    public void updateCustomerInfoFailureWhenEmergencyContactMissingFirstName() throws IOException {
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .lastName("Doe")
                        .gender("M")
                        .dob("01011990")
                        .phoneNbr("5551234567")
                        .relationshipType("SPOUSE")
                        .build(); // Missing firstName

        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("firstName"), "Error should mention missing firstName");
    }

    @Test(
            priority = 12,
            description = "Update customer info with invalid emergency contact - missing lastName")
    public void updateCustomerInfoFailureWhenEmergencyContactMissingLastName() throws IOException {
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("John")
                        .gender("M")
                        .dob("01011990")
                        .phoneNbr("5551234567")
                        .relationshipType("SPOUSE")
                        .build(); // Missing lastName

        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("lastName"), "Error should mention missing lastName");
    }

    @Test(
            priority = 13,
            description = "Update customer info with invalid emergency contact - missing relationshipType")
    public void updateCustomerInfoFailureWhenEmergencyContactMissingRelationshipType() throws IOException {
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("John")
                        .lastName("Doe")
                        .gender("M")
                        .dob("01011990")
                        .phoneNbr("5551234567")
                        .build();

        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("relationshipType"), "Error should mention missing relationshipType");
    }

    @Test(
            priority = 14,
            description = "Update customer info with invalid emergency contact DOB format")
    public void updateCustomerInfoFailureWhenEmergencyContactInvalidDOBFormat() throws IOException {
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> emergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo emergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("John")
                        .lastName("Doe")
                        .gender("M")
                        .dob("1990-01-01") // Wrong format, should be MMDDYYYY
                        .phoneNbr("5551234567")
                        .relationshipType("SPOUSE")
                        .build();

        emergencyContacts.add(emergencyContact);

        UpdateCustomerInfoV1Request updateCustomerInfoV1Request =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(emergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateCustomerInfoResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(caregiverCustomerAccountId, domainId, updateCustomerInfoV1Request);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateCustomerInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateCustomerInfoResponse.code(), 500, errorMessage);
    }

    @Test(
            priority = 15,
            description = "Add secondary address - success")
    public void addSecondaryAddressSuccess() throws IOException, InterruptedException {

        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .addressLine2("Apt 2B")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);
        Assert.assertEquals(updateResponse.code(), 200);
        Thread.sleep(60000);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        dependent1CustomerAccountId, domainId, false, true, null, false, false, false, false, false);
        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);

        Assert.assertNotNull(getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo(),
                "Address info should be present");
        Assert.assertTrue(getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo().size() >= 1,
                "At least one address should be present");

        boolean secondaryAddressFound = false;
        for (GetCustomerAccountInfoV2Response.CustomerInfo.AddressInfo addressInfo :
                getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo()) {
            if (addressInfo.getType() != null && addressInfo.getType().getCode() == 4) { // Secondary address code
                Assert.assertEquals(addressInfo.getAddressLine1(), "789 Secondary St");
                Assert.assertEquals(addressInfo.getCity(), "Dallas");
                Assert.assertEquals(addressInfo.getState(), "TX");
                Assert.assertEquals(addressInfo.getZipCode(), "75204");
                secondaryAddressFound = true;
                break;
            }
        }
        Assert.assertTrue(secondaryAddressFound, "Secondary address should be found in response");
    }

    @Test(
            priority = 16,
            description = "Edit secondary address - success")
    public void editSecondaryAddressSuccess() throws IOException, InterruptedException {
        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);
        UpdateCustomerInfoV1Request editRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("222 Updated St")
                                .addressLine2("Suite 100")
                                .city("Plano")
                                .state("TX")
                                .zipCode("75023")
                                .type("secondary")
                                .operation("update")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> editResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, editRequest);
        Assert.assertEquals(editResponse.code(), 200);
        Thread.sleep(60000);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        dependent1CustomerAccountId, domainId, false, true, null, false, false, false, false, false);
        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);
        boolean updatedSecondaryAddressFound = false;
        for (GetCustomerAccountInfoV2Response.CustomerInfo.AddressInfo addressInfo :
                getCustomerAccountInfoV2Response.getCustomerInfo().getAddressInfo()) {
            if (addressInfo.getType() != null && addressInfo.getType().getCode() == 4) {
                Assert.assertEquals(addressInfo.getAddressLine1(), "222 Updated St");
                Assert.assertEquals(addressInfo.getCity(), "Plano");
                Assert.assertEquals(addressInfo.getState(), "TX");
                Assert.assertEquals(addressInfo.getZipCode(), "75023");
                updatedSecondaryAddressFound = true;
                break;
            }
        }
        Assert.assertTrue(updatedSecondaryAddressFound, "Updated secondary address should be found in response");
    }

    @Test(
            priority = 17,
            description = "Edit existing emergency contact - success")
    public void editEmergencyContactSuccess() throws IOException, InterruptedException {
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> addEmergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo addEmergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("Original")
                        .lastName("Contact")
                        .gender("M")
                        .dob("01011990")
                        .phoneNbr("5551111111")
                        .relationshipType("FRIEND")
                        .build();
        addEmergencyContacts.add(addEmergencyContact);

        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(addEmergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);
        List<UpdateCustomerInfoV1Request.EmergencyContactInfo> editEmergencyContacts = new ArrayList<>();
        UpdateCustomerInfoV1Request.EmergencyContactInfo editEmergencyContact =
                UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                        .firstName("Updated")
                        .lastName("Contact")
                        .middleName("M")
                        .gender("F")
                        .dob("02021991")
                        .phoneNbr("5552222222")
                        .relationshipType("SPOUSE")
                        .build();
        editEmergencyContacts.add(editEmergencyContact);

        UpdateCustomerInfoV1Request editRequest =
                UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(editEmergencyContacts)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> editResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, editRequest);
        Assert.assertEquals(editResponse.code(), 200);
        Thread.sleep(60000);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        dependent1CustomerAccountId, domainId, false, true, null, false, true, true, false, false);
        GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                        GetCustomerAccountInfoV2Response.class);

        Assert.assertNotNull(getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo(),
                "Emergency contact info should be present after update");
        Assert.assertFalse(getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo().isEmpty(),
                "Emergency contact list should not be empty");

        var updatedEmergencyContact = getCustomerAccountInfoV2Response.getCustomerInfo().getEmergencyContactInfo().get(0);
        Assert.assertEquals(updatedEmergencyContact.getFirstName(), "Updated");
        Assert.assertEquals(updatedEmergencyContact.getLastName(), "Contact");
        Assert.assertEquals(updatedEmergencyContact.getPhoneNbr(), "5552222222");
        Assert.assertEquals(updatedEmergencyContact.getRelationshipCode().getDescr(), "Spouse");
    }

    @Test(
            priority = 18,
            description = "Add secondary address with invalid type - should fail")
    public void addSecondaryAddressFailureWhenInvalidType() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75204")
                                .type("invalid")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("Address Type should be primary or secondary") ||
                        errorMessage.contains("address type must be either 'primary' or 'secondary'"),
                "Error message should indicate invalid address type");
    }

    @Test(
            priority = 19,
            description = "Add secondary address without addressLine1 - should fail")
    public void addSecondaryAddressFailureWhenAddressLine1Missing() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("address line 1 is null/empty"),
                "Error message should indicate that addressLine1 is required");
    }

    @Test(
            priority = 20,
            description = "Add secondary address without city - should fail")
    public void addSecondaryAddressFailureWhenCityMissing() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .state("TX")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("city is null/empty/exceeds max length"),
                "Error message should indicate that city is required");
    }

    @Test(
            priority = 21,
            description = "Add secondary address without state - should fail")
    public void addSecondaryAddressFailureWhenStateMissing() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("Dallas")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("state name is null/empty/exceeds max length"),
                "Error message should indicate that state is required");
    }

    @Test(
            priority = 22,
            description = "Add secondary address without zipCode - should fail")
    public void addSecondaryAddressFailureWhenZipCodeMissing() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("Dallas")
                                .state("TX")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("zipcode is null/empty"),
                "Error message should indicate that zipCode is required");
    }

    @Test(
            priority = 23,
            description = "Add secondary address with invalid zipCode format - should fail")
    public void addSecondaryAddressFailureWhenInvalidZipCodeFormat() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("123") // Invalid format - too short
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("zipcode is invalid"),
                "Error message should indicate that zipCode format is invalid");
    }

    @Test(
            priority = 24,
            description = "Add secondary address with city exceeding max length - should fail")
    public void addSecondaryAddressFailureWhenCityExceedsMaxLength() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("ThisCityNameExceedsTwentyFiveCharacters") // Max length is 25
                                .state("TX")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("city is null/empty/exceeds max length"),
                "Error message should indicate that city exceeds max length");
    }

    @Test(
            priority = 25,
            description = "Add secondary address with state exceeding max length - should fail")
    public void addSecondaryAddressFailureWhenStateExceedsMaxLength() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("789 Secondary St")
                                .city("Dallas")
                                .state("TEX") // Max length is 2
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("state name is null/empty/exceeds max length"),
                "Error message should indicate that state exceeds max length");
    }

    @Test(
            priority = 26,
            description = "Add secondary address with empty addressLine1 - should fail")
    public void addSecondaryAddressFailureWhenAddressLine1Empty() throws IOException {
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("") // Empty string
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75204")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("address line 1 is null/empty"),
                "Error message should indicate that addressLine1 cannot be empty");
    }

    @Test(
            priority = 27,
            description = "Update secondary address without addressLine1 - should fail")
    public void updateSecondaryAddressFailureWhenAddressLine1Missing() throws IOException, InterruptedException {

        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);

        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .city("Plano")
                                .state("TX")
                                .zipCode("75023")
                                .type("secondary")
                                .operation("update")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("address line 1 is null/empty"),
                "Error message should indicate that addressLine1 is required");
    }

    @Test(
            priority = 28,
            description = "Update secondary address without city - should fail")
    public void updateSecondaryAddressFailureWhenCityMissing() throws IOException, InterruptedException {

        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);

        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("222 Updated St")
                                .state("TX")
                                .zipCode("75023")
                                .type("secondary")
                                .operation("update")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("city is null/empty/exceeds max length"),
                "Error message should indicate that city is required");
    }

    @Test(
            priority = 29,
            description = "Update secondary address without state - should fail")
    public void updateSecondaryAddressFailureWhenStateMissing() throws IOException, InterruptedException {

        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);

        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("222 Updated St")
                                .city("Plano")
                                .zipCode("75023")
                                .type("secondary")
                                .operation("update")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("state name is null/empty/exceeds max length"),
                "Error message should indicate that state is required");
    }

    @Test(
            priority = 30,
            description = "Update secondary address without zipCode - should fail")
    public void updateSecondaryAddressFailureWhenZipCodeMissing() throws IOException, InterruptedException {

        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("222 Updated St")
                                .city("Plano")
                                .state("TX")
                                .type("secondary")
                                .operation("update")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("zipcode is null/empty"),
                "Error message should indicate that zipCode is required");
    }

    @Test(
            priority = 31,
            description = "Update secondary address with invalid operation - should fail")
    public void updateSecondaryAddressFailureWhenInvalidOperation() throws IOException, InterruptedException {
        UpdateCustomerInfoV1Request addRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("111 Original St")
                                .city("Dallas")
                                .state("TX")
                                .zipCode("75205")
                                .type("secondary")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> addResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, addRequest);
        Assert.assertEquals(addResponse.code(), 200);
        Thread.sleep(60000);
        UpdateCustomerInfoV1Request updateRequest =
                UpdateCustomerInfoV1Request.builder()
                        .address(UpdateCustomerInfoV1Request.Address.builder()
                                .addressLine1("222 Updated St")
                                .city("Plano")
                                .state("TX")
                                .zipCode("75023")
                                .type("secondary")
                                .operation("invalid_operation")
                                .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(dependent1CustomerAccountId, domainId, updateRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, updateResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(updateResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("Address Operation should be update/bottomsheet_update/bottomsheet_confirm"),
                "Error message should indicate that operation is invalid");
    }
}
