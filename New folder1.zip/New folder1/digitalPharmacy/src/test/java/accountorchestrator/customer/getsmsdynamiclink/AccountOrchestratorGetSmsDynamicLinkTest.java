package accountorchestrator.customer.getsmsdynamiclink;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetSmsDynamicLinkV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetSmsDynamicLinkV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.restapi.DMStageIDRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountOrchestratorGetSmsDynamicLinkTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private static DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
    private static DMStageIDRetrofit dmStageIDRetrofit;
    private WCPRetroFit wcpRetroFit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private final ObjectMapper mapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();
    private String caregiverCustomerEmailId = null;
    private String dependent2EmailId = null;
    private String dependent3EmailId = null;
    private String dependent4EmailId = null;
    private String caregiverCustomerAccountId = null;
    private String dependent1CustomerAccountId = null;
    private String dependent2CustomerAccountId = null;
    private String dependent3CustomerAccountId = null;
    private String dependent4CustomerAccountId = null;
    private String caregiverStageId = null;
    private String dependent1StageId = null;
    private String dependent2StageId = null;
    private String dependent3StageId = null;
    private String dependent4StageId = null;
    private String caregiverStoreNbr = null;
    private String caregiverPatientId = null;
    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent2StoreNbr = null;
    private String dependent2PatientId = null;
    private String dependent3StoreNbr = null;
    private String dependent3PatientId = null;
    private String dependent4StoreNbr = null;
    private String dependent4PatientId = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForLessThan18 = null;
    private String commonDobDPFormatForLessThan18 = null;
    private String caregiverFirstName = null;
    private String caregiverLastName = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent2FirstName = null;
    private String dependent2LastName = null;
    private String dependent3FirstName = null;
    private String dependent3LastName = null;
    private String dependent4FirstName = null;
    private String dependent4LastName = null;
    private String HUMAN = "HUMAN";
    private String PET = "PET";
    private String minorDob = "2019-01-01";
    private String CONNECTED = "CONNECTED";
    private String NOT_CONNECTED = "NOT_CONNECTED";
    private String SELF = "SELF";
    private String DEPENDENT = "DEPENDENT";
    private String NON_DEPENDENT = "NON_DEPENDENT";
    private String phoneNbr = null;
    private String phoneNbr1 = null;
    private String stageIdPhoneNbr = null;
    private String enrollmentStatusCode = "26805";
    private String accountCreationSource = "smsOtpVerification";
    private static String refillConfirmationRefType = "refill-confirmation-sms";
    private String latestTs = String.valueOf(Instant.now().getEpochSecond());
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
    static List<DMPostPreferencesRequest> dmProfilesToBeDeleted = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetroFit = new WCPRetroFit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
        dmStageIDRetrofit = new DMStageIDRetrofit();

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
        commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

        // making test accounts
        createTestAccounts();
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {

        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                        // Handle the IOException
                    }
                });

        dmProfilesToBeDeleted.forEach(
                request -> {
                    request.getPreferences().getFirst().setEnrollment_status_code("26805");
                    try {
                        Response<DMPostPreferencesResponse> response =
                                dmPostPreferencesRetrofit.callDMPostPreferencesAPI(request);
                        if (!(response.code() == 200
                                && response.body() != null
                                && response.body().getResponseStatus() != null
                                && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
                            throw new RuntimeException(
                                    "DM Account failed to update with Enrollment status code 26803 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
    }

    void createTestAccounts() throws Exception {

        // customer account
        caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        phoneNbr = CommonUtil.generateRandomNumber(10);
        caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
        caregiverPatientId = CommonUtil.generateRandomNumber(9);
        caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiverCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        caregiverCustomerEmailId);
        createCPRAccount(
                caregiverStoreNbr,
                caregiverPatientId,
                caregiverFirstName,
                caregiverLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbr);
        createPharmacyAccount(
                caregiverCustomerAccountId,
                caregiverStoreNbr,
                caregiverPatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(caregiverStoreNbr, caregiverPatientId, phoneNbr, enrollmentStatusCode);
        caregiverStageId =
                createStageId(
                        caregiverStoreNbr, caregiverPatientId, phoneNbr, refillConfirmationRefType, latestTs);

        // dependent
        dependent1CustomerAccountId =
                CommonAccountHelper.createGuestAccountWithWCPWithRandomName(minorDob);
        dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                dependent1FirstName,
                dependent1LastName,
                commonDobCPRFormatForLessThan18,
                HUMAN,
                phoneNbr);
        createPharmacyAccount(
                dependent1CustomerAccountId,
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobDPFormatForLessThan18);
        WCPAddDependentRequest wcpAddDependentRequest =
                CommonAccountHelper.getWCPAddDependentRequest(
                        DependentInfo.TypeEnum.MINOR,
                        DependentInfo.LinkageStatusEnum.ACTIVE,
                        dependent1CustomerAccountId,
                        caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCustomerAccountId);
        createSMSEnrollment(dependent1StoreNbr, dependent1PatientId, phoneNbr, enrollmentStatusCode);
        dependent1StageId =
                createStageId(
                        dependent1StoreNbr, dependent1PatientId, phoneNbr, refillConfirmationRefType, latestTs);

        // non-dependent
        dependent2EmailId = CommonUtil.generateRandomEmailId(10);
        dependent2CustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependent2EmailId);
        dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent2PatientId = CommonUtil.generateRandomNumber(9);
        dependent2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        createCPRAccount(
                dependent2StoreNbr,
                dependent2PatientId,
                dependent2FirstName,
                dependent2LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbr);
        createPharmacyAccount(
                dependent2CustomerAccountId,
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(dependent2StoreNbr, dependent2PatientId, phoneNbr, enrollmentStatusCode);
        dependent2StageId =
                createStageId(
                        dependent2StoreNbr, dependent2PatientId, phoneNbr, refillConfirmationRefType, latestTs);

        // non-dependent for a different phoneNbr
        stageIdPhoneNbr = CommonUtil.generateRandomNumber(10);
        dependent3EmailId = CommonUtil.generateRandomEmailId(10);
        dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent3PatientId = CommonUtil.generateRandomNumber(9);
        dependent3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent3CustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependent3EmailId);
        createCPRAccount(
                dependent3StoreNbr,
                dependent3PatientId,
                dependent3FirstName,
                dependent3LastName,
                commonDobCPRFormatForLessThan18,
                HUMAN,
                stageIdPhoneNbr);
        createPharmacyAccount(
                dependent3CustomerAccountId,
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobDPFormatForLessThan18);
        createSMSEnrollment(
                dependent3StoreNbr, dependent3PatientId, stageIdPhoneNbr, enrollmentStatusCode);
        dependent3StageId =
                createStageId(
                        dependent3StoreNbr,
                        dependent3PatientId,
                        stageIdPhoneNbr,
                        refillConfirmationRefType,
                        latestTs);

        // non-dependent for a non-connected
        phoneNbr1 = CommonUtil.generateRandomNumber(10);
        dependent4EmailId = CommonUtil.generateRandomEmailId(10);
        dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent4PatientId = CommonUtil.generateRandomNumber(9);
        dependent4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent4CustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependent4EmailId);
        createCPRAccount(
                dependent4StoreNbr,
                dependent4PatientId,
                dependent4FirstName,
                dependent4LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbr1);
        createSMSEnrollment(dependent4StoreNbr, dependent4PatientId, phoneNbr1, enrollmentStatusCode);
        dependent4StageId =
                createStageId(
                        dependent4StoreNbr,
                        dependent4PatientId,
                        phoneNbr1,
                        refillConfirmationRefType,
                        latestTs);

        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
                break;
            }
        }
    }

    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    private void createCPRAccount(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String dob,
            String type,
            String phoneNbr)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
                break;
            }
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void createSMSEnrollment(
            String storeNbr, String patientId, String notifyValue, String enrollStatusCode)
            throws IOException {

        DMPostPreferencesRequest dmPostPreferencesRequest =
                getDmPostPreferencesRequest(storeNbr, patientId, notifyValue, enrollStatusCode);
        Response<DMPostPreferencesResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getResponseStatus() != null
                    && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "DM Post Preference call failure. HttpStatusCode : " + response.code());
                }
            } else {
                dmProfilesToBeDeleted.add(dmPostPreferencesRequest);
                break;
            }
        }
    }

    /**
     * Create DM post preference request (notifyType 1 for phone nbr, 3 for email)
     *
     * @param storeNbr store Nbr
     * @param patientId patientId
     * @param notifyValue phone Number or email Id
     * @param enrollStatusCode 26802 for enrollment, 26803 for unenrollment
     * @return
     */
    private static DMPostPreferencesRequest getDmPostPreferencesRequest(
            String storeNbr, String patientId, String notifyValue, String enrollStatusCode) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
        String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

        String requestId = String.format("%s-%s", storeNbr, patientId);
        return DMPostPreferencesRequest.builder()
                .storeNbr(storeNbr)
                .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
                .preferences(
                        org.openjdk.tools.javac.util.List.of(
                                DMPostPreferencesRequest.Preference.builder()
                                        .notification_type("1")
                                        .notification_val(notifyValue)
                                        .short_code_type_id("1")
                                        .enrollment_status_code(enrollStatusCode)
                                        .build()))
                .build();
    }

    private static String createStageId(
            String storeNbr, String patientId, String phoneNumber, String refType, String createTs)
            throws IOException, GeneralSecurityException {

        DMCreateStageIdRequest dmCreateStageIdRequest =
                getDMCreateStageIdRequest(storeNbr, patientId, phoneNumber, refType, createTs);
        Response<DMCreateStageIdResponse> response = null;

        // This will try to create a stage id, 3 times if creation fails
        for (int i = 0; i < 3; i++) {
            response = dmStageIDRetrofit.callDMStageIdAPI(dmCreateStageIdRequest);
            if (!(response.code() == 201 && response.body() != null)) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "DM Create Stage Id call failure. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
        return response.body().getId();
    }

    private static DMCreateStageIdRequest getDMCreateStageIdRequest(
            String storeNbr, String patientId, String phoneNumber, String refType, String createTs) {
        DMCreateStageIdRequest.Comms comms =
                DMCreateStageIdRequest.Comms.builder()
                        .patientId(patientId)
                        .phoneNumber(phoneNumber)
                        .storeId(storeNbr)
                        .createTs(createTs)
                        .rxNumber(Collections.emptyList())
                        .build();

        DMCreateStageIdRequest.Payload payload =
                DMCreateStageIdRequest.Payload.builder().comms(comms).build();

        return DMCreateStageIdRequest.builder().refType(refType).payload(payload).build();
    }

    private GetSmsDynamicLinkV1Request createGetSmsDynamicLinkV1Request(String stageId) {
        return GetSmsDynamicLinkV1Request.builder().stageId(stageId).build();
    }

    private void logAccountDetails(
            String domainId,
            String storeNbr,
            String patientId,
            String customerAccountId,
            String stageId,
            String reqId,
            String reqTrackingId) {
        Reporter.logJSON("domain Id", domainId);
        Reporter.logJSON("Store nbr", storeNbr);
        Reporter.logJSON("Patient Id", patientId);
        Reporter.logJSON("Customer Account Id", customerAccountId);
        Reporter.logJSON("Stage Id", stageId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    @Test(
            priority = 0,
            description = "Get SmsDynamicLink when status is connected and relationWithCustomer is SELF")
    public void getSmsDynamicLinkWhenStatusIsConnectedAndRelationWithCustomerIsSelf()
            throws IOException, GeneralSecurityException {

        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(
                domainId,
                caregiverStoreNbr,
                caregiverPatientId,
                caregiverCustomerAccountId,
                caregiverStageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with a valid caregiverCustomerAccountId ,valid
        // caregiverStageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);

        // Step - 4: Parsing the response to the GetSmsDynamicLinkV1Response class so that we can assert
        // GetSmsDynamicLinkV1
        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getSmsDynamicLinkResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getCustomerInfo());

        // stageIdInfo
        Assert.assertEquals(response.getStageIdInfo().getStageId(), caregiverStageId);
        Assert.assertEquals(response.getStageIdInfo().getType(), refillConfirmationRefType);
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), SELF);
        Assert.assertEquals(response.getStageIdInfo().getPhoneNbr(), Long.parseLong(phoneNbr));

        // ownerInfo
        Assert.assertNull(response.getStageIdInfo().getOwnerDetails());

        // customerInfo
        Assert.assertEquals(
                response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
        Assert.assertEquals(response.getCustomerInfo().getStatus(), CONNECTED);
    }

    @Test(
            priority = 1,
            description =
                    "Get SmsDynamicLink when status is connected and relationWithCustomer is DEPENDENT")
    public void getSmsDynamicLinkWhenStatusIsConnectedAndRelationWithCustomerIsDependent()
            throws IOException, GeneralSecurityException {

        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(
                domainId,
                caregiverStoreNbr,
                caregiverPatientId,
                caregiverCustomerAccountId,
                dependent1StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with a valid caregiverCustomerAccountId ,valid
        // dependent1StageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent1StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);

        // Step - 4: Parsing the response to the GetSmsDynamicLinkV1Response class so that we can assert
        // GetSmsDynamicLinkV1
        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getSmsDynamicLinkResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getCustomerInfo());

        // stageIdInfo
        Assert.assertEquals(response.getStageIdInfo().getStageId(), dependent1StageId);
        Assert.assertEquals(response.getStageIdInfo().getType(), refillConfirmationRefType);
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), DEPENDENT);
        Assert.assertEquals(response.getStageIdInfo().getPhoneNbr(), Long.parseLong(phoneNbr));

        // ownerInfo
        Assert.assertNull(response.getStageIdInfo().getOwnerDetails());

        // customerInfo
        Assert.assertEquals(
                response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
        Assert.assertEquals(response.getCustomerInfo().getStatus(), CONNECTED);
    }

    @Test(
            priority = 2,
            description =
                    "Get SmsDynamicLink when status is connected and relationWithCustomer is NON_DEPENDENT")
    public void getSmsDynamicLinkWhenStatusIsConnectedAndRelationWithCustomerIsNonDependent()
            throws IOException, GeneralSecurityException {

        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(
                domainId,
                caregiverStoreNbr,
                caregiverPatientId,
                caregiverCustomerAccountId,
                dependent2StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with a valid caregiverCustomerAccountId ,valid
        // dependent2StageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent2StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);

        // Step - 4: Parsing the response to the GetSmsDynamicLinkV1Response class so that we can assert
        // GetSmsDynamicLinkV1
        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getSmsDynamicLinkResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getCustomerInfo());

        // stageIdInfo
        Assert.assertEquals(response.getStageIdInfo().getStageId(), dependent2StageId);
        Assert.assertEquals(response.getStageIdInfo().getType(), refillConfirmationRefType);
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);
        Assert.assertEquals(response.getStageIdInfo().getPhoneNbr(), Long.parseLong(phoneNbr));

        // owner details
        Assert.assertEquals(
                response.getStageIdInfo().getOwnerDetails().getFirstName(), dependent2FirstName);
        Assert.assertNotNull(response.getStageIdInfo().getOwnerDetails().getMiddleName());
        Assert.assertEquals(
                response.getStageIdInfo().getOwnerDetails().getLastName(), dependent2LastName);
        Assert.assertEquals(response.getStageIdInfo().getOwnerDetails().getType(), Type.ADULT);
        Assert.assertEquals(
                response.getStageIdInfo().getOwnerDetails().getEmailId(), dependent2EmailId);
        Assert.assertNotNull(response.getStageIdInfo().getOwnerDetails().getValidationToken());
        Assert.assertEquals(response.getStageIdInfo().getOwnerDetails().getIsInCooldown(), false);
        Assert.assertNull(response.getStageIdInfo().getOwnerDetails().getCoolDownStatus());

        // customerInfo
        Assert.assertEquals(
                response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
        Assert.assertEquals(response.getCustomerInfo().getStatus(), CONNECTED);
    }

    @Test(
            priority = 3,
            description =
                    "Get SmsDynamicLink when status is not connected and relationWithCustomer is NON_DEPENDENT/SELF/DEPENDENT")
    public void
    getSmsDynamicLinkWhenStatusIsNotConnectedAndRelationWithCustomerIsDependentOrNonDependentOrSelf()
            throws IOException, GeneralSecurityException {

        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(
                domainId,
                caregiverStoreNbr,
                caregiverPatientId,
                dependent4CustomerAccountId,
                dependent4StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with a valid dependent4CustomerAccountId ,valid
        // dependent4StageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent4StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent4CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);

        // Step - 4: Parsing the response to the GetSmsDynamicLinkV1Response class so that we can assert
        // GetSmsDynamicLinkV1
        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getSmsDynamicLinkResponse.body().getPayload(), "Payload is null");

        Assert.assertNotNull(response.getCustomerInfo());

        // stageIdInfo
        Assert.assertEquals(response.getStageIdInfo().getStageId(), dependent4StageId);
        Assert.assertEquals(response.getStageIdInfo().getType(), refillConfirmationRefType);
        Assert.assertEquals(response.getStageIdInfo().getPhoneNbr(), Long.parseLong(phoneNbr1));

        // ownerInfo
        Assert.assertNull(response.getStageIdInfo().getOwnerDetails());

        // customerInfo
        Assert.assertEquals(
                response.getCustomerInfo().getCustomerAccountId(), dependent4CustomerAccountId);
        Assert.assertEquals(response.getCustomerInfo().getStatus(), NOT_CONNECTED);
    }

    @Test(priority = 4, description = "Get SmsDynamicLink with null stageId should return 400 error")
    public void getSmsDynamicLinkWithNullStageId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with null stageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request = createGetSmsDynamicLinkV1Request(null);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(priority = 5, description = "Get SmsDynamicLink with empty stageId should return 400 error")
    public void getSmsDynamicLinkWithEmptyStageId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with empty stageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request = createGetSmsDynamicLinkV1Request("");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 6,
            description = "Get SmsDynamicLink with blank/whitespace stageId should return 400 error")
    public void getSmsDynamicLinkWithBlankStageId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with blank/whitespace stageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request = createGetSmsDynamicLinkV1Request("   ");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 7,
            description = "Get SmsDynamicLink with invalid domainId should return 400 error")
    public void getSmsDynamicLinkWithInvalidDomainId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with invalid domainId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        "INVALID_DOMAIN",
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(priority = 8, description = "Get SmsDynamicLink with stage id not present in DM")
    public void getSmsDynamicLinkWithStageIdNotPresentInDM404Case() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with a non-existent stageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(
                        "bm1XN1l3YTltbEt2OTA0ejVzR0piall3S0Z4eWZOUE9qd0JjWlJBcmVHbUtaK3VaWjlzRmt6SnUvUUZHUWxmUCxFRmUzNkhmYm1HVUZDbi9IcUVIcmJ3PT0=");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 404, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-24004");
    }

    @Test(
            priority = 9,
            description =
                    "Get SmsDynamicLink with random invalid stageId format should return error (Error decrypting given request from DM)")
    public void getSmsDynamicLinkWithRandomInvalidStageId() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with a random invalid stageId
        String randomStageId = RandomStringUtils.randomAlphanumeric(20);
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(randomStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-24002");
    }

    @Test(priority = 10, description = "Get SmsDynamicLink with WM-PHARMACY domainId should succeed")
    public void getSmsDynamicLinkWithWmPharmacyDomainId()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with WM-PHARMACY domainId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        "WM-PHARMACY",
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Assert success
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
    }

    @Test(priority = 11, description = "Verify ownerDetails is null for SELF relation")
    public void getSmsDynamicLinkVerifyOwnerDetailsNullForSelfRelation()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for SELF relation
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), SELF);
        Assert.assertNull(
                response.getStageIdInfo().getOwnerDetails(),
                "ownerDetails should be null for SELF relation");
    }

    @Test(priority = 12, description = "Verify ownerDetails is null for DEPENDENT relation")
    public void getSmsDynamicLinkVerifyOwnerDetailsNullForDependentRelation()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for DEPENDENT relation
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent1StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), DEPENDENT);
        Assert.assertNull(
                response.getStageIdInfo().getOwnerDetails(),
                "ownerDetails should be null for DEPENDENT relation");
    }

    @Test(
            priority = 13,
            description = "Verify ownerDetails is populated with all fields for NON_DEPENDENT ADULT")
    public void getSmsDynamicLinkVerifyOwnerDetailsPopulatedForNonDependentAdult()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for NON_DEPENDENT (ADULT)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent2StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails(),
                "ownerDetails should not be null for NON_DEPENDENT relation");

        // Verify all expected fields
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getFirstName(), "firstName should be present");
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getLastName(), "lastName should be present");
        Assert.assertEquals(
                response.getStageIdInfo().getOwnerDetails().getType(), Type.ADULT, "Type should be ADULT");
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getValidationToken(),
                "validationToken should be present");
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getIsInCooldown(),
                "isInCooldown should be present");

        // For ADULT type, emailId should be included
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getEmailId(),
                "emailId should be present for ADULT type");
    }

    @Test(priority = 14, description = "Verify isInCooldown field value for NON_DEPENDENT")
    public void getSmsDynamicLinkVerifyIsInCooldownFieldForNonDependent()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for NON_DEPENDENT
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent2StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);

        // isInCooldown should be a boolean value
        Boolean isInCooldown = response.getStageIdInfo().getOwnerDetails().getIsInCooldown();
        Assert.assertNotNull(isInCooldown, "isInCooldown should not be null");
        Assert.assertTrue(
                isInCooldown.equals(true) || isInCooldown.equals(false),
                "isInCooldown should be either true or false");
    }

    @Test(
            priority = 15,
            description = "Verify stageId with leading/trailing whitespace is handled correctly")
    public void getSmsDynamicLinkVerifyStageIdWithWhitespaceHandledCorrectly()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with stageId having leading/trailing spaces
        // Note: The service should either trim and process correctly, or reject
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(" " + caregiverStageId + " ");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Document actual behavior - either success (trimmed) or error
        Reporter.logJSON(
                "Whitespace test response code", String.valueOf(getSmsDynamicLinkResponse.code()));

        // The service should either trim and succeed or return validation error
        Assert.assertTrue(
                getSmsDynamicLinkResponse.code() == 200 || getSmsDynamicLinkResponse.code() == 400,
                "Expected either 200 (trimmed) or 400 (validation error), but got: "
                        + getSmsDynamicLinkResponse.code());
    }

    @Test(
            priority = 16,
            description =
                    "Get SmsDynamicLink with a different phone number (dependent3StageId enrolled to stageIdPhoneNbr")
    public void getSmsDynamicLinkWithDifferentPhoneNumberUsedDuringStageIdCreation()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(
                domainId,
                dependent3StoreNbr,
                dependent3PatientId,
                dependent3CustomerAccountId,
                dependent3StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with dependent3StageId (different phone number)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent3StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent3CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);

        // Step - 4: Parsing the response
        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
        Assert.assertNotNull(response.getStageIdInfo().getPhoneNbr());

        // Verify the phoneNbr matches the stageIdPhoneNbr used for dependent3
        Assert.assertEquals(
                response.getStageIdInfo().getPhoneNbr(),
                Long.parseLong(stageIdPhoneNbr),
                "phoneNbr should match the phone number used when creating the stageId");
    }

    @Test(priority = 18, description = "Get SmsDynamicLink when refType is not refillConfirmation")
    public void getSmsDynamicLinkWithInvalidFlowType() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Creating test accounts
        String phoneNbrB = CommonUtil.generateRandomNumber(10);
        String dependentBEmailId = CommonUtil.generateRandomEmailId(10);
        String dependentBStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentBPatientId = CommonUtil.generateRandomNumber(9);
        String dependentBFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentBLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentBCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependentBEmailId);
        String invalidType = "imz-reco";
        createCPRAccount(
                dependentBStoreNbr,
                dependentBPatientId,
                dependentBFirstName,
                dependentBLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbrB);
        createPharmacyAccount(
                dependentBCustomerAccountId,
                dependentBStoreNbr,
                dependentBPatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(dependentBStoreNbr, dependentBPatientId, phoneNbrB, enrollmentStatusCode);
        String dependentBStageId =
                createStageId(dependentBStoreNbr, dependentBPatientId, phoneNbrB, invalidType, latestTs);
        logAccountDetails(
                domainId,
                dependent3StoreNbr,
                dependent3PatientId,
                dependent3CustomerAccountId,
                dependent3StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with dependentBStageId (invalid flow type)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependentBStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent3CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400);
    }

    @Test(priority = 18, description = "Get SmsDynamicLink when create Ts is greater than 10 days")
    public void getSmsDynamicLinkWithGreaterThan10daysCreateTs() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Creating test accounts
        String phoneNbrB = CommonUtil.generateRandomNumber(10);
        String dependentBEmailId = CommonUtil.generateRandomEmailId(10);
        String dependentBStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentBPatientId = CommonUtil.generateRandomNumber(9);
        String dependentBFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentBLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentBCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependentBEmailId);
        String olderThan10DaysTs =
                String.valueOf(
                        Instant.now().minus(11, java.time.temporal.ChronoUnit.DAYS).getEpochSecond());
        createCPRAccount(
                dependentBStoreNbr,
                dependentBPatientId,
                dependentBFirstName,
                dependentBLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbrB);
        createPharmacyAccount(
                dependentBCustomerAccountId,
                dependentBStoreNbr,
                dependentBPatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(dependentBStoreNbr, dependentBPatientId, phoneNbrB, enrollmentStatusCode);
        String dependentBStageId =
                createStageId(
                        dependentBStoreNbr,
                        dependentBPatientId,
                        phoneNbrB,
                        refillConfirmationRefType,
                        olderThan10DaysTs);
        logAccountDetails(
                domainId,
                dependent3StoreNbr,
                dependent3PatientId,
                dependent3CustomerAccountId,
                dependent3StageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with dependentBStageId (olderThan10DaysTs)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependentBStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent3CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);

        // Step - 4: Asserting response
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400);
    }

    @Test(
            priority = 19,
            description = "Get SmsDynamicLink with future createTs should return 400 error")
    public void getSmsDynamicLinkWithFutureCreateTs() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Creating test accounts with future createTs
        String phoneNbrC = CommonUtil.generateRandomNumber(10);
        String dependentCEmailId = CommonUtil.generateRandomEmailId(10);
        String dependentCStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentCPatientId = CommonUtil.generateRandomNumber(9);
        String dependentCFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentCLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentCCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependentCEmailId);
        // Future timestamp - 5 days from now
        String futureTs =
                String.valueOf(Instant.now().plus(5, java.time.temporal.ChronoUnit.DAYS).getEpochSecond());
        createCPRAccount(
                dependentCStoreNbr,
                dependentCPatientId,
                dependentCFirstName,
                dependentCLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbrC);
        createPharmacyAccount(
                dependentCCustomerAccountId,
                dependentCStoreNbr,
                dependentCPatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(dependentCStoreNbr, dependentCPatientId, phoneNbrC, enrollmentStatusCode);
        String dependentCStageId =
                createStageId(
                        dependentCStoreNbr,
                        dependentCPatientId,
                        phoneNbrC,
                        refillConfirmationRefType,
                        futureTs);

        // Step - 2: Calling getSmsDynamicLink with dependentCStageId (future createTs)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependentCStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependentCCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response - future timestamp should be rejected
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 20,
            description =
                    "Get SmsDynamicLink when storeNbr and patientId from stageId is not present in customer/dependents/non-dependents should return 400 error")
    public void getSmsDynamicLinkWhenStoreNbrAndPatientIdNotPresentInResponse() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Create a stageId with storeNbr/patientId that doesn't exist in caregiver's account
        // (not in customer info, not in dependents, not in non-dependents)
        String phoneNbrG = CommonUtil.generateRandomNumber(10);
        String nonExistentStoreNbr = CommonUtil.generateRandomNumber(6);
        String nonExistentPatientId = CommonUtil.generateRandomNumber(9);

        // Create stageId with storeNbr/patientId that is not linked to any user in caregiver's account
        String stageIdWithNonExistentPatientLink =
                createStageId(
                        nonExistentStoreNbr,
                        nonExistentPatientId,
                        phoneNbrG,
                        refillConfirmationRefType,
                        latestTs);

        logAccountDetails(
                domainId,
                nonExistentStoreNbr,
                nonExistentPatientId,
                caregiverCustomerAccountId,
                stageIdWithNonExistentPatientLink,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink with caregiverCustomerAccountId but stageId contains
        // storeNbr/patientId that is not found in customer's patientLinks, dependents' patientLinks,
        // or non-dependents' patientLinks
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(stageIdWithNonExistentPatientLink);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Get error response and assert
        Error errorResponse = CommonUtil.getErrorResponse(gson, getSmsDynamicLinkResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step - 4: Asserting response - should return 400 error as storeNbr/patientId not found
        // in customer info, dependents, or non-dependents (STORE_NBR_PATIENT_ID_NOT_FOUND_IN_ANY_USER)
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 400, errorMessage);
        Assert.assertEquals(
                errorResponse.getCode(),
                "DPR-DPACCOR-1001",
                "Error code should indicate invalid request when storeNbr/patientId not found in any user");
    }

    @Test(
            priority = 21,
            description =
                    "Get SmsDynamicLink for NON_DEPENDENT MINOR type should not include emailId in ownerDetails")
    public void getSmsDynamicLinkVerifyNoEmailIdForNonDependentMinorType() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Creating a MINOR non-dependent account (less than 18 years old)
        String phoneNbrE = CommonUtil.generateRandomNumber(10);
        String dependentEEmailId = CommonUtil.generateRandomEmailId(10);
        String dependentEStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentEPatientId = CommonUtil.generateRandomNumber(9);
        String dependentEFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentELastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentECustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependentEEmailId);

        // Create CPR account with minor DOB (less than 18)
        createCPRAccount(
                dependentEStoreNbr,
                dependentEPatientId,
                dependentEFirstName,
                dependentELastName,
                commonDobCPRFormatForLessThan18,
                HUMAN,
                phoneNbrE);
        createPharmacyAccount(
                dependentECustomerAccountId,
                dependentEStoreNbr,
                dependentEPatientId,
                commonDobDPFormatForLessThan18);
        createSMSEnrollment(dependentEStoreNbr, dependentEPatientId, phoneNbrE, enrollmentStatusCode);
        String dependentEStageId =
                createStageId(
                        dependentEStoreNbr,
                        dependentEPatientId,
                        phoneNbrE,
                        refillConfirmationRefType,
                        latestTs);

        logAccountDetails(
                domainId,
                dependentEStoreNbr,
                dependentEPatientId,
                caregiverCustomerAccountId,
                dependentEStageId,
                reqId,
                reqTrackingId);

        // Step - 2: Calling getSmsDynamicLink - this should return as NON_DEPENDENT with MINOR type
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependentEStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Asserting NON_DEPENDENT with MINOR type should NOT have emailId
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);
        Assert.assertNotNull(response.getStageIdInfo().getOwnerDetails());
        Assert.assertEquals(
                response.getStageIdInfo().getOwnerDetails().getType(),
                Type.MINOR,
                "Type should be MINOR for users under 18");
        // emailId should NOT be present for MINOR type
        Assert.assertNull(
                response.getStageIdInfo().getOwnerDetails().getEmailId(),
                "emailId should be null for MINOR type NON_DEPENDENT");
    }

    @Test(
            priority = 22,
            description =
                    "Get SmsDynamicLink verify response contains correct stageId type as refill-confirmation-sms")
    public void getSmsDynamicLinkVerifyStageIdTypeInResponse()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with valid caregiverStageId
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify stageIdInfo type is refill-confirmation-sms
        Assert.assertNotNull(response.getStageIdInfo().getType());
        Assert.assertEquals(
                response.getStageIdInfo().getType(),
                refillConfirmationRefType,
                "stageIdInfo type should be refill-confirmation-sms");
    }

    @Test(
            priority = 23,
            description = "Get SmsDynamicLink verify phoneNbr is correctly parsed as Long in response")
    public void getSmsDynamicLinkVerifyPhoneNbrParsedAsLong()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify phoneNbr is a valid Long value
        Long responsePhoneNbr = response.getStageIdInfo().getPhoneNbr();
        Assert.assertNotNull(responsePhoneNbr, "phoneNbr should not be null");
        Assert.assertEquals(
                responsePhoneNbr,
                Long.parseLong(phoneNbr),
                "phoneNbr should match the original phone number");
        Assert.assertEquals(
                String.valueOf(responsePhoneNbr).length(), 10, "phoneNbr should be 10 digits");
    }

    @Test(
            priority = 24,
            description = "Get SmsDynamicLink verify validationToken is present for NON_DEPENDENT")
    public void getSmsDynamicLinkVerifyValidationTokenForNonDependent()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for NON_DEPENDENT
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent2StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify validationToken is present and not empty
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getValidationToken(),
                "validationToken should be present for NON_DEPENDENT");
        Assert.assertFalse(
                response.getStageIdInfo().getOwnerDetails().getValidationToken().isEmpty(),
                "validationToken should not be empty");
    }

    @Test(
            priority = 25,
            description = "Get SmsDynamicLink with createTs at exactly 10 days should succeed")
    public void getSmsDynamicLinkWithCreateTsAtExactly10Days() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 1b: Creating test accounts with createTs exactly 10 days ago
        String phoneNbrF = CommonUtil.generateRandomNumber(10);
        String dependentFEmailId = CommonUtil.generateRandomEmailId(10);
        String dependentFStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentFPatientId = CommonUtil.generateRandomNumber(9);
        String dependentFFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentFLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentFCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                        dependentFEmailId);
        // Exactly 10 days ago (should be at the boundary)
        String exactly10DaysTs =
                String.valueOf(
                        Instant.now().minus(10, java.time.temporal.ChronoUnit.DAYS).getEpochSecond());
        createCPRAccount(
                dependentFStoreNbr,
                dependentFPatientId,
                dependentFFirstName,
                dependentFLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                phoneNbrF);
        createPharmacyAccount(
                dependentFCustomerAccountId,
                dependentFStoreNbr,
                dependentFPatientId,
                commonDobDPFormatForOlderThan18);
        createSMSEnrollment(dependentFStoreNbr, dependentFPatientId, phoneNbrF, enrollmentStatusCode);
        String dependentFStageId =
                createStageId(
                        dependentFStoreNbr,
                        dependentFPatientId,
                        phoneNbrF,
                        refillConfirmationRefType,
                        exactly10DaysTs);

        // Step - 2: Calling getSmsDynamicLink with dependentFStageId (exactly 10 days createTs)
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependentFStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependentFCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Assert - exactly 10 days should still be valid (boundary case)
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);
    }

    @Test(
            priority = 26,
            description =
                    "Get SmsDynamicLink verify middleName can be null in ownerDetails for NON_DEPENDENT")
    public void getSmsDynamicLinkVerifyMiddleNameCanBeNull()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink for NON_DEPENDENT
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent2StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify ownerDetails fields - middleName can be null or present
        Assert.assertEquals(response.getStageIdInfo().getRelationWithCustomer(), NON_DEPENDENT);
        Assert.assertNotNull(response.getStageIdInfo().getOwnerDetails());
        // firstName and lastName should always be present
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getFirstName(), "firstName should be present");
        Assert.assertNotNull(
                response.getStageIdInfo().getOwnerDetails().getLastName(), "lastName should be present");
        // middleName is optional - just verify the response structure is valid
        Reporter.logJSON(
                "middleName value",
                String.valueOf(response.getStageIdInfo().getOwnerDetails().getMiddleName()));
    }

    @Test(
            priority = 27,
            description = "Get SmsDynamicLink verify search order: customer checked before dependents")
    public void getSmsDynamicLinkVerifySearchOrderCustomerFirst() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Using caregiverStageId which matches caregiver's own patient link
        // This should return SELF, not DEPENDENT or NON_DEPENDENT
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(caregiverStageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        caregiverCustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 2: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 3: Verify SELF is returned (customer info is checked first)
        Assert.assertEquals(
                response.getStageIdInfo().getRelationWithCustomer(),
                SELF,
                "Should return SELF when stageId matches customer's own patient link");
    }

    @Test(
            priority = 28,
            description = "Get SmsDynamicLink verify NOT_CONNECTED response has no relationWithCustomer")
    public void getSmsDynamicLinkVerifyNotConnectedHasNoRelation()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with dependent4 which should return NOT_CONNECTED
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent4StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent4CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify NOT_CONNECTED status has no relationWithCustomer
        Assert.assertEquals(
                response.getCustomerInfo().getStatus(), NOT_CONNECTED, "Status should be NOT_CONNECTED");
        Assert.assertNull(
                response.getStageIdInfo().getRelationWithCustomer(),
                "relationWithCustomer should be null for NOT_CONNECTED status");
        Assert.assertNull(
                response.getStageIdInfo().getOwnerDetails(),
                "ownerDetails should be null for NOT_CONNECTED status");
    }

    @Test(
            priority = 29,
            description = "Get SmsDynamicLink verify NOT_CONNECTED response still contains phoneNbr")
    public void getSmsDynamicLinkVerifyNotConnectedContainsPhoneNbr()
            throws IOException, GeneralSecurityException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Calling getSmsDynamicLink with dependent4 which should return NOT_CONNECTED
        GetSmsDynamicLinkV1Request getSmsDynamicLinkV1Request =
                createGetSmsDynamicLinkV1Request(dependent4StageId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getSmsDynamicLinkResponse =
                accountOrchestratorRetrofit.getSmsDynamicLink(
                        dependent4CustomerAccountId,
                        domainId,
                        getSmsDynamicLinkV1Request,
                        reqId,
                        reqTrackingId);

        // Step - 3: Parse and assert
        String errorMessage = CommonUtil.buildErrorMessage(gson, getSmsDynamicLinkResponse);
        Assert.assertEquals(getSmsDynamicLinkResponse.code(), 200, errorMessage);

        GetSmsDynamicLinkV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getSmsDynamicLinkResponse.body().getPayload()),
                        GetSmsDynamicLinkV1Response.class);

        // Step - 4: Verify NOT_CONNECTED response still contains phoneNbr from stageId
        Assert.assertEquals(
                response.getCustomerInfo().getStatus(), NOT_CONNECTED, "Status should be NOT_CONNECTED");
        Assert.assertNotNull(
                response.getStageIdInfo().getPhoneNbr(),
                "phoneNbr should be present even for NOT_CONNECTED status");
        Assert.assertEquals(
                response.getStageIdInfo().getPhoneNbr(),
                Long.parseLong(phoneNbr1),
                "phoneNbr should match the phone number from stageId");
    }
}
