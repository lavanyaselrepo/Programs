package accountorchestrator.customer.getcustomerdependentandsmsenrolledinfo;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerDependentsAndSmsEnrolledInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.request.PharmaAuthPatientIdStoreNbrRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.response.IsCustomerInCoolDownResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountOrchestratorGetCustomerDependentsAndSMSEnrolledInfoCoolDownTests {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private static DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private WCPRetroFit wcpRetroFit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String accountCreationSource = "smsOtpVerification";
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder()
          .registerTypeAdapter(LocalDateTime.class, new TypeAdapter<LocalDateTime>() {
            @Override
            public void write(JsonWriter out, LocalDateTime value) throws IOException {
              if (value == null) {
                out.nullValue();
              } else {
                out.beginArray();
                out.value(value.getYear());
                out.value(value.getMonthValue());
                out.value(value.getDayOfMonth());
                out.value(value.getHour());
                out.value(value.getMinute());
                out.value(value.getSecond());
                out.endArray();
              }
            }

            @Override
            public LocalDateTime read(JsonReader in) throws IOException {
              if (in.peek() == JsonToken.NULL) {
                in.nextNull();
                return null;
              } else if (in.peek() == JsonToken.BEGIN_ARRAY) {
                in.beginArray();
                int year = in.nextInt();
                int month = in.nextInt();
                int day = in.nextInt();
                int hour = in.hasNext() ? in.nextInt() : 0;
                int minute = in.hasNext() ? in.nextInt() : 0;
                int second = in.hasNext() ? in.nextInt() : 0;
                in.endArray();
                return LocalDateTime.of(year, month, day, hour, minute, second);
              } else if (in.peek() == JsonToken.STRING) {
                String dateStr = in.nextString();
                return LocalDateTime.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
              }
              return null;
            }
          })
          .create();
  private String caregiverCustomerEmailId = null;
  private String caregiverCustomerAccountId = null;
  private String dependent1CustomerAccountId = null;
  private String dependent2CustomerAccountId = null;
  private String caregiverStoreNbr = null;
  private String caregiverPatientId = null;
  private String dependent1StoreNbr = null;
  private String dependent1PatientId = null;
  private String dependent2StoreNbr = null;
  private String dependent2PatientId = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;
  private String commonDobCPRFormatForLessThan18 = null;
  private String commonDobDPFormatForLessThan18 = null;
  private String smsEnrolledDependentCustomerEmailId = null;
  private String caregiverFirstName = null;
  private String caregiverLastName = null;
  private String dependent1FirstName = null;
  private String dependent1LastName = null;
  private String dependent2FirstName = null;
  private String dependent2LastName = null;
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  private String phoneNbr = null;
  private String enrollmentStatusCode = "26805";
  private String flowType = "FAM";
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
  static List<DMPostPreferencesRequest> dmProfilesToBeDeleted = new ArrayList<>();
  List<PharmaAuthPatientIdStoreNbrRequest> pharmaAuthPatientLinkProfilesToBeDeleted =
          new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    pharmacyAuthServiceRetrofit = new PharmacyAuthServiceRetrofit();

    caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    smsEnrolledDependentCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    phoneNbr = CommonUtil.generateRandomNumber(10);

    Date dateForOlderThan18 =
            new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
            new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
    commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

    // making test accounts
    caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
    caregiverPatientId = CommonUtil.generateRandomNumber(9);
    caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    caregiverCustomerEmailId);
    createCPRAccount(
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverFirstName,
            caregiverLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            caregiverCustomerAccountId,
            caregiverStoreNbr,
            caregiverPatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(caregiverStoreNbr, caregiverPatientId, phoneNbr, enrollmentStatusCode);

    dependent1CustomerAccountId =
            CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2019-01-02");
    dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent1PatientId = CommonUtil.generateRandomNumber(9);
    dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent1StoreNbr,
            dependent1PatientId,
            dependent1FirstName,
            dependent1LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependent1CustomerAccountId,
            dependent1StoreNbr,
            dependent1PatientId,
            commonDobDPFormatForOlderThan18);
    WCPAddDependentRequest wcpAddDependentRequest =
            CommonAccountHelper.getWCPAddDependentRequest(
                    DependentInfo.TypeEnum.PET,
                    DependentInfo.LinkageStatusEnum.ACTIVE,
                    dependent1CustomerAccountId,
                    caregiverCustomerAccountId);
    wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCustomerAccountId);
    createSMSEnrollment(dependent1StoreNbr, dependent1PatientId, phoneNbr, enrollmentStatusCode);

    dependent2CustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    smsEnrolledDependentCustomerEmailId);
    dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent2PatientId = CommonUtil.generateRandomNumber(9);
    dependent2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent2StoreNbr,
            dependent2PatientId,
            dependent2FirstName,
            dependent2LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependent2CustomerAccountId,
            dependent2StoreNbr,
            dependent2PatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependent2StoreNbr, dependent2PatientId, phoneNbr, enrollmentStatusCode);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Clean up for all created accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() throws IOException {

    cprProfilesToBeDeletedList.forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                Response<ValidationServiceResponse> response =
                        cprPatientUpdateRetrofit.validateProfile(request);
                if (!(response.code() == 202
                        && response.body() != null
                        && response.body().getErrors().isEmpty())
                        && response.code() != 406) {
                  throw new RuntimeException(
                          "CPR Account failed to update with status code 20708 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });

    pharmacyProfilesToBeDeleted.forEach(
            request -> {
              try {
                Response<ServiceResponse> getOnlineIdentityResp =
                        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                request, domainId, reqIdString, reqTrackingString);

                if (getOnlineIdentityResp.code() == 204) {
                  // If the response is 204, skip the deletion
                  return;
                }

                accountEntityServiceRetrofit.deleteAccountV1(
                        request, domainId, reqIdString, reqTrackingString);

              } catch (IOException e) {
                // Handle the IOException
              }
            });

    dmProfilesToBeDeleted.forEach(
            request -> {
              request.getPreferences().getFirst().setEnrollment_status_code("26805");
              try {
                Response<DMPostPreferencesResponse> response =
                        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(request);
                if (!(response.code() == 200
                        && response.body() != null
                        && response.body().getResponseStatus() != null
                        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
                  throw new RuntimeException(
                          "DM Account failed to update with Enrollment status code 26803 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  private void createPharmacyAccount(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      domainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
        break;
      }
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(dob)
                            .build())
            .build();
  }

  /**
   * Increments failed authentication count for a given storeNbr and patientId
   *
   * @param storeNbr
   * @param patientId
   * @param flowType
   * @throws IOException
   */
  private void createPharmaAuthIncrementFailedAuthenticationForPatientLinks(
          String storeNbr, String patientId, String flowType) throws IOException {
    PharmaAuthPatientIdStoreNbrRequest pharmaAuthPatientIdStoreNbrRequest =
            getCreatePharmaAuthCoolDownStatusRequest(storeNbr, patientId, flowType);
    Response<IsCustomerInCoolDownResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              pharmacyAuthServiceRetrofit.incrementFailedAuthenticationForPatientLinks(
                      pharmaAuthPatientIdStoreNbrRequest);

      if (!(response.code() == 200
              && response.body() != null
              && response.body().getCoolDownStatus() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Pharma Auth increment failed authentication for patient Links failed. HttpStatusCode : "
                          + response.code());
        }
      } else {
        pharmaAuthPatientLinkProfilesToBeDeleted.add(pharmaAuthPatientIdStoreNbrRequest);
        break;
      }
    }
  }

  /**
   * Builds Create Pharma Auth Cool Down Status
   *
   * @param storeNbr
   * @param patientId
   * @param flowType
   * @return
   */
  private PharmaAuthPatientIdStoreNbrRequest getCreatePharmaAuthCoolDownStatusRequest(
          String storeNbr, String patientId, String flowType) {
    return PharmaAuthPatientIdStoreNbrRequest.builder()
            .storeNbr(Integer.parseInt(storeNbr))
            .patientId(Integer.parseInt(patientId))
            .flowName(flowType)
            .build();
  }

  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  private void createCPRAccount(
          String storeNbr,
          String patientId,
          String firstName,
          String lastName,
          String dob,
          String type,
          String phoneNbr)
          throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
        break;
      }
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Creates SMS Enrollement for a storeNbr and patientId
   *
   * @param storeNbr
   * @param patientId
   * @param notifyValue
   * @param enrollStatusCode
   * @throws IOException
   */
  private static void createSMSEnrollment(
          String storeNbr, String patientId, String notifyValue, String enrollStatusCode)
          throws IOException {

    DMPostPreferencesRequest dmPostPreferencesRequest =
            getDmPostPreferencesRequest(storeNbr, patientId, notifyValue, enrollStatusCode);
    Response<DMPostPreferencesResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getResponseStatus() != null
              && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "DM Post Preference call failure. HttpStatusCode : " + response.code());
        }
      } else {
        dmProfilesToBeDeleted.add(dmPostPreferencesRequest);
        break;
      }
    }
  }

  /**
   * Create DM post preference request (notifyType 1 for phone nbr, 3 for email)
   *
   * @param storeNbr store Nbr
   * @param patientId patientId
   * @param notifyValue phone Number or email Id
   * @param enrollStatusCode 26802 for enrollment, 26803 for unenrollment
   * @return
   */
  private static DMPostPreferencesRequest getDmPostPreferencesRequest(
          String storeNbr, String patientId, String notifyValue, String enrollStatusCode) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    String requestId = String.format("%s-%s", storeNbr, patientId);
    return DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
            .zipCode("96898")
            .userId("SIGPAD")
            .storePhone("8009666546")
            .timeStamp(timestamp)
            .language("101")
            .preferences(
                    org.openjdk.tools.javac.util.List.of(
                            DMPostPreferencesRequest.Preference.builder()
                                    .notification_type("1")
                                    .notification_val(notifyValue)
                                    .short_code_type_id("1")
                                    .enrollment_status_code(enrollStatusCode)
                                    .build()))
            .build();
  }

  @Test(
          priority = 0,
          description =
                  "Get customer , dependents and sms enrolled info when coolDown status is not there")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCoolDownStatusIsNull()
          throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null,false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
  }

  @Test(
          priority = 1,
          description =
                  "Get customer , dependents and sms enrolled info when coolDown status is present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCoolDownStatusIsPresent()
          throws IOException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // creating coolDown Status for the patientId and storeNbr by hitting the api for 5 times
    for (int i = 0; i < 5; i++) {
      createPharmaAuthIncrementFailedAuthenticationForPatientLinks(
              dependent2StoreNbr, dependent2PatientId, flowType);
    }

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null,false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNotNull(
            response
                    .getSmsEnrolledNonDependentsInfo()
                    .getFirst()
                    .getCoolDownStatus()
                    .getAttemptsRemaining());
    Assert.assertNotNull(
            response
                    .getSmsEnrolledNonDependentsInfo()
                    .getFirst()
                    .getCoolDownStatus()
                    .getRemainingTime());
    Assert.assertNotNull(
            response
                    .getSmsEnrolledNonDependentsInfo()
                    .getFirst()
                    .getCoolDownStatus()
                    .getFailedAttemptsCount());
  }
}
