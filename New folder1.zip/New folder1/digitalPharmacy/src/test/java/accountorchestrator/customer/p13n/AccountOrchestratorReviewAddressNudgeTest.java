package test.java.accountorchestrator.customer.p13n;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nAuditDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerP13NRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerP13NRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerP13NResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;
import test.java.accountorchestrator.utils.P13nTestUtil;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.walmart.chp.metrics.commons.constants.LogConstants.HUMAN;

/**
 * Test class for Review and Update Address Nudge functionality in Account Orchestrator
 * This test verifies the get nudge in getp13n flow
 */
public class AccountOrchestratorReviewAddressNudgeTest {

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final Gson gson = new Gson();
    private P13nDao p13nDao;
    private P13nAuditDao p13nAuditDao;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private final ObjectMapper mapper = new ObjectMapper();
    private String accountCreationSource = "idVerification";
    private ValidationServiceRequest cprPatientRequest = null;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private String trackID = CommonUtil.randomUUID();


    // Shared account ID for all tests
    private String onlineAccountId = null;

    @BeforeClass
    void setContext() throws Exception {
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        p13nDao = new P13nDao();
        p13nAuditDao = new P13nAuditDao();

        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);

        onlineAccountId = accountorchestrator.utils.CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                email,
                commonPassword,
                commonPhoneNo,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);

        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        cleanupReviewAddressNudgeRecords();
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(dob);
        cprPatientRequest.getPatientInfo().setFirstName(firstName);
        cprPatientRequest.getPatientInfo().setLastName(lastName);

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Clean up method to delete all REVIEW_AND_UPDATE_ADDRESS_NUDGE records
     * from both main container and audit after each test
     */
    @AfterMethod
    void cleanupAfterTest() {
        cleanupReviewAddressNudgeRecords();
    }

    @AfterClass
    void cleanup(){
        if (cprPatientRequest != null) {
            cprPatientRequest.getPatientInfo().setPatientTypeCode(20708);
            try {
                deleteAccount();
            } catch (IOException e) {
            }
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    private void createPharmacyAccount(
            String customerAccountId, String commonPatientId, String dob)
            throws IOException {

        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request("9928", commonPatientId, dob);

        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {

            String reqId = reqIdString + CommonUtil.randomUUID();
            String reqTracking = reqTrackingString + CommonUtil.randomUUID();

            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqId,
                            reqTracking);

            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody() != null ? response.errorBody().toString() : "No error body");
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    private void deleteAccount() throws IOException {
        if (cprPatientRequest == null) {
            return;
        }

        try {
            Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> getOnlineIdentityResp =
                    accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                            onlineAccountId, domainId, reqIdString, reqTrackingString);

            if (getOnlineIdentityResp.code() == 204) {
                // If the response is 204, skip the deletion
                return;
            }

            accountEntityServiceRetrofit.deleteAccountV1(
                    onlineAccountId, domainId, reqIdString, reqTrackingString);

            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);

        } catch (IOException e) {
            // Handle the IOException
        }
    }


    /**
     * Helper method to clean up all REVIEW_AND_UPDATE_ADDRESS_NUDGE records
     * from both main P13N container and audit container
     */
    private void cleanupReviewAddressNudgeRecords() {
        P13nTestUtil.cleanupP13nRecords(
                onlineAccountId,
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE,
                p13nDao,
                p13nAuditDao);
    }

    /**
     * Test to verify Review and Update Address Nudge is returned in getP13N flow
     * when no existing records are found.
     *
     * Test Scenario:
     * - No card dismissal record exists
     * - No confirm/update audit record exists
     * - Account Entity should return nothing
     * - Account Orchestrator should return the nudge
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 0, description = "Get Review and Update Address Nudge in getP13N flow when no existing records exist")
    public void getReviewAddressNudgeInGetP13NFlowAndGetCustomerAccountInfoV2_NoExistingRecords() throws IOException {

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Call Account Orchestrator getCustomerInfoV2 API with p13n=true
        Response<ServiceResponse> customerInfoV2Response =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        onlineAccountId,
                        domainId,
                        false,  // dependentsInfo
                        false,  // walmartPlusStatus
                        null,   // lookupCID
                        true,   // includeP13n
                        false,  // storeFilter
                        false,
                        false, false); // includeEC

        // Step 2: Assert successful response (200 status code)
        Assert.assertEquals(customerInfoV2Response.code(), 200, "getCustomerInfoV2 should return 200");

        // Step 3: Verify the response contains the Review and Update Address nudge
        ServiceResponse response = customerInfoV2Response.body();
        Assert.assertNotNull(response, "Response should not be null");
        Assert.assertNotNull(response.getPayload(), "Payload should not be null");

        // Step 4: Parse payload - p13ns is nested in customerInfo for getCustomerInfoV2
        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) response.getPayload();

        Object customerInfoObj = payload.get("customerInfo");
        Assert.assertNotNull(customerInfoObj, "customerInfo field should be present");

        @SuppressWarnings("unchecked")
        Map<String, Object> customerInfo = (Map<String, Object>) customerInfoObj;

        Object p13nsObj = customerInfo.get("p13ns");
        Assert.assertNotNull(p13nsObj, "p13ns field should be present in customerInfo");

        @SuppressWarnings("unchecked")
        List<Map<String, String>> p13nsList = (List<Map<String, String>>) p13nsObj;
        Assert.assertFalse(p13nsList.isEmpty(), "p13ns list should not be empty");

        // Step 5: Verify the entity matches REVIEW_AND_UPDATE_ADDRESS_NUDGE
        Map<String, String> p13n = p13nsList.get(0);
        Assert.assertEquals(p13n.get("entity"), P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name(),
                "Entity should be REVIEW_AND_UPDATE_ADDRESS_NUDGE");
        Assert.assertEquals(p13n.get("type"), P13NType.SHOW.name(),
                "Type should be SHOW");

        // Step 2: Build GetCustomerP13NRequest for REVIEW_AND_UPDATE_ADDRESS_NUDGE entity
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.SHOW);

        // Step 3: Call Account Orchestrator getP13Ns API
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        // Step 4: Assert successful response (200 status code)
        Assert.assertEquals(getApiResponse.code(), 200, "Expected 200 OK but got " + getApiResponse.code());

        // Step 6: Verify the response contains the Review and Update Address nudge
        GetCustomerP13NResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertNotNull(getCustomerP13nResponse, "Response payload should not be null");
        Assert.assertNotNull(getCustomerP13nResponse.getP13ns(), "p13ns list should not be null");
        Assert.assertFalse(getCustomerP13nResponse.getP13ns().isEmpty(), "p13ns list should not be empty");

        // Step 7: Verify the entity matches REVIEW_AND_UPDATE_ADDRESS_NUDGE
        GetCustomerP13NResponse.P13n getP13n = getCustomerP13nResponse.getP13ns().get(0);
        Assert.assertEquals(getP13n.getEntity(), P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name(),
                "Entity should be REVIEW_AND_UPDATE_ADDRESS_NUDGE");
        Assert.assertEquals(getP13n.getType(), P13NType.SHOW.name(),
                "Type should be SHOW");
    }

    /**
     * Test to verify card dismissal logic for Review and Update Address Nudge
     *
     * Test Scenario:
     * - Create a card dismissal record
     * - Verify Account Orchestrator does NOT return the nudge
     * - Delete the dismissal record
     * - Verify the nudge IS shown after deletion
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 1, description = "Verify Review and Update Address Nudge is not shown when card dismissal exists")
    public void getReviewAddressNudgeWithCardDismissal_NudgeNotShownThenShownAfterExpiration() throws IOException {

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Create card dismissal record
        List<Map<String, Object>> identifiers = new ArrayList<>();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("action", "dismiss");

        Map<String, Object> identifier = new HashMap<>();
        identifier.put("metadata", metadata);
        identifiers.add(identifier);

        UpdateCustomerP13NRequest dismissalRequest =
                buildUpdateP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.CARD_DISMISSAL, identifiers);

        Response<Void> createDismissalResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, dismissalRequest, domainId, reqId, reqTrackingId);

        // Step 3: Verify dismissal was created successfully
        Assert.assertEquals(createDismissalResponse.code(), 200, "Expected 200 OK from updateP13Ns");

        // Step 4: Call getP13Ns and verify nudge is NOT returned
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.SHOW);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getAfterDismissalResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        // Step 5: Assert that nudge is not returned (204 No Content or empty list)
        if (getAfterDismissalResponse.code() == 200) {
            GetCustomerP13NResponse responseAfterDismissal = getAfterDismissalResponse.body().getPayload();
            if (responseAfterDismissal != null && responseAfterDismissal.getP13ns() != null) {
                // Verify the SHOW nudge is filtered out
                boolean hasShowNudge = responseAfterDismissal.getP13ns().stream()
                        .anyMatch(p13n -> P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name().equals(p13n.getEntity())
                                && P13NType.SHOW.name().equals(p13n.getType()));
                Assert.assertFalse(hasShowNudge, "Nudge should not be shown when card dismissal exists");
            }
        } else {
            Assert.assertEquals(getAfterDismissalResponse.code(), 204,
                    "Expected 204 No Content when nudge is suppressed by dismissal");
        }
    }

    /**
     * Test to verify that bottomsheet_update operation creates dismissal that suppresses the nudge
     *
     * Test Scenario:
     * - Call updateCustomerInfo with operation="bottomsheet_update"
     * - Verify getP13Ns returns 204 (nudge is suppressed by dismissal)
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 2, description = "Verify bottomsheet_update creates dismissal that suppresses nudge")
    public void testBottomsheetUpdateSuppressesNudge() throws IOException, InterruptedException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Call updateCustomerInfo with bottomsheet_update
        UpdateCustomerInfoV1Request.Address address = UpdateCustomerInfoV1Request.Address.builder()
                .addressLine1("123 Test Street")
                .city("Bentonville")
                .state("AR")
                .zipCode("72712")
                .operation("bottomsheet_update")
                .build();

        UpdateCustomerInfoV1Request updateRequest = UpdateCustomerInfoV1Request.builder()
                .address(address)
                .build();

        Response<ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(onlineAccountId, domainId, updateRequest);

        Assert.assertEquals(updateResponse.code(), 200, "Expected 200 OK from updateCustomerInfo with bottomsheet_update");

        // Wait for async P13N creation and cache invalidation to complete
        System.out.println("\nWaiting for async P13N creation and cache invalidation...");
        Thread.sleep(3000);

        // Check if dismissal was created in database
        java.util.List<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument> dismissals =
                p13nDao.getP13nDocuments(onlineAccountId);

        // Step 2: Verify nudge is NOT shown (expect 204)
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.SHOW);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(getApiResponse.code(), 204, "Expected 204 No Content - nudge should be suppressed by dismissal");
    }

    /**
     * Test to verify that bottomsheet_confirm operation creates dismissal that suppresses the nudge
     *
     * Test Scenario:
     * - Call updateCustomerInfo with operation="bottomsheet_confirm"
     * - Verify getP13Ns returns 204 (nudge is suppressed by dismissal)
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 3, description = "Verify bottomsheet_confirm creates dismissal that suppresses nudge")
    public void testBottomsheetConfirmSuppressesNudge() throws IOException, InterruptedException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Call updateCustomerInfo with bottomsheet_confirm
        UpdateCustomerInfoV1Request.Address address = UpdateCustomerInfoV1Request.Address.builder()
                .addressLine1("123 Test Street")
                .city("Bentonville")
                .state("AR")
                .zipCode("72712")
                .operation("bottomsheet_confirm")
                .build();

        UpdateCustomerInfoV1Request updateRequest = UpdateCustomerInfoV1Request.builder()
                .address(address)
                .build();

        Response<ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(onlineAccountId, domainId, updateRequest);

        Assert.assertEquals(updateResponse.code(), 200, "Expected 200 OK from updateCustomerInfo with bottomsheet_confirm");

        // Wait for async P13N creation and cache invalidation to complete
        System.out.println("\nWaiting for async P13N creation and cache invalidation...");
        Thread.sleep(3000);

        // Check if dismissal was created in database
        java.util.List<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument> dismissals =
                p13nDao.getP13nDocuments(onlineAccountId);

        // Step 2: Verify nudge is NOT shown (expect 204)
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.SHOW);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(getApiResponse.code(), 204, "Expected 204 No Content - nudge should be suppressed by dismissal");
    }

    /**
     * Test to verify that update operation creates dismissal that suppresses the nudge
     *
     * Test Scenario:
     * - Call updateCustomerInfo with operation="update"
     * - Verify getP13Ns returns 204 (nudge is suppressed by dismissal)
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 4, description = "Verify update operation creates dismissal that suppresses nudge")
    public void testUpdateOperationSuppressesNudge() throws IOException, InterruptedException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Call updateCustomerInfo with update operation
        UpdateCustomerInfoV1Request.Address address = UpdateCustomerInfoV1Request.Address.builder()
                .addressLine1("123 Test Street")
                .city("Bentonville")
                .state("AR")
                .zipCode("72712")
                .operation("update")
                .build();

        UpdateCustomerInfoV1Request updateRequest = UpdateCustomerInfoV1Request.builder()
                .address(address)
                .build();

        Response<ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(onlineAccountId, domainId, updateRequest);

        Assert.assertEquals(updateResponse.code(), 200, "Expected 200 OK from updateCustomerInfo with update operation");

        // Wait for async P13N creation and cache invalidation to complete
        System.out.println("\nWaiting for async P13N creation and cache invalidation...");
        Thread.sleep(3000);

        // Check if dismissal was created in database
        java.util.List<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument> dismissals =
                p13nDao.getP13nDocuments(onlineAccountId);

        // Step 2: Verify nudge is NOT shown (expect 204)
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE, P13NType.SHOW);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(getApiResponse.code(), 204, "Expected 204 No Content - nudge should be suppressed by dismissal");
    }

    /**
     * Test to verify that bottomsheet_update operation creates dismissal that suppresses the nudge in getCustomerInfoV2
     *
     * Test Scenario:
     * - Call updateCustomerInfo with operation="bottomsheet_update"
     * - Verify getCustomerInfoV2 returns empty p13ns array (nudge is suppressed by dismissal)
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 5, description = "Verify bottomsheet_update creates dismissal that suppresses nudge in getCustomerInfoV2")
    public void testBottomsheetUpdateSuppressesNudgeInGetCustomerInfoV2() throws IOException, InterruptedException {

        // Step 1: Call updateCustomerInfo with bottomsheet_update
        UpdateCustomerInfoV1Request.Address address = UpdateCustomerInfoV1Request.Address.builder()
                .addressLine1("123 Test Street")
                .city("Bentonville")
                .state("AR")
                .zipCode("72712")
                .operation("bottomsheet_update")
                .build();

        UpdateCustomerInfoV1Request updateRequest = UpdateCustomerInfoV1Request.builder()
                .address(address)
                .build();

        Response<ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(onlineAccountId, domainId, updateRequest);

        Assert.assertEquals(updateResponse.code(), 200, "Updated customer info with bottomsheet_update");

        // Wait for async P13N creation and cache invalidation to complete
        System.out.println("\nWaiting for async P13N creation and cache invalidation...");
        Thread.sleep(3000);

        // Check if dismissal was created in database
        java.util.List<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument> dismissals =
                p13nDao.getP13nDocuments(onlineAccountId);

        // Step 2: Verify nudge is NOT shown in getCustomerInfoV2
        Response<ServiceResponse> getApiResponse =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        onlineAccountId,
                        domainId,
                        false,  // dependentsInfo
                        false,  // walmartPlusStatus
                        null,   // lookupCID
                        true,   // includeP13n
                        false,  // storeFilter
                        false,
                        false, false); // includeEC

        Assert.assertEquals(getApiResponse.code(), 200, "getCustomerInfoV2 should return 200");

        ServiceResponse response = getApiResponse.body();
        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) response.getPayload();
        @SuppressWarnings("unchecked")
        Map<String, Object> customerInfo = (Map<String, Object>) payload.get("customerInfo");
        @SuppressWarnings("unchecked")
        List<Map<String, String>> p13nsList = (List<Map<String, String>>) customerInfo.get("p13ns");

        Assert.assertTrue(p13nsList.isEmpty(), "p13ns should be empty - nudge should be suppressed by dismissal");
    }

    /**
     * Test to verify that bottomsheet_confirm operation creates dismissal that suppresses the nudge in getCustomerInfoV2
     *
     * Test Scenario:
     * - Call updateCustomerInfo with operation="bottomsheet_confirm"
     * - Verify getCustomerInfoV2 returns empty p13ns array (nudge is suppressed by dismissal)
     *
     * @throws IOException if API call fails
     */
    @Test(priority = 6, description = "Verify bottomsheet_confirm creates dismissal that suppresses nudge in getCustomerInfoV2")
    public void testBottomsheetConfirmSuppressesNudgeInGetCustomerInfoV2() throws IOException, InterruptedException {

        // Step 1: Call updateCustomerInfo with bottomsheet_confirm
        UpdateCustomerInfoV1Request.Address address = UpdateCustomerInfoV1Request.Address.builder()
                .addressLine1("123 Test Street")
                .city("Bentonville")
                .state("AR")
                .zipCode("72712")
                .operation("bottomsheet_confirm")
                .build();

        UpdateCustomerInfoV1Request updateRequest = UpdateCustomerInfoV1Request.builder()
                .address(address)
                .build();

        Response<ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(onlineAccountId, domainId, updateRequest);

        Assert.assertEquals(updateResponse.code(), 200, "Updated customer info with bottomsheet_confirm");

        // Wait for async P13N creation and cache invalidation to complete
        System.out.println("\nWaiting for async P13N creation and cache invalidation...");
        Thread.sleep(3000);

        // Check if dismissal was created in database
        java.util.List<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument> dismissals =
                p13nDao.getP13nDocuments(onlineAccountId);

        // Step 2: Verify nudge is NOT shown in getCustomerInfoV2
        Response<ServiceResponse> getApiResponse =
                accountOrchestratorRetrofit.getCustomerInfoV2(
                        onlineAccountId,
                        domainId,
                        false,  // dependentsInfo
                        false,  // walmartPlusStatus
                        null,   // lookupCID
                        true,   // includeP13n
                        false,  // storeFilter
                        false,
                        false, false); // includeEC

        Assert.assertEquals(getApiResponse.code(), 200, "getCustomerInfoV2 should return 200");

        ServiceResponse response = getApiResponse.body();
        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) response.getPayload();
        @SuppressWarnings("unchecked")
        Map<String, Object> customerInfo = (Map<String, Object>) payload.get("customerInfo");
        @SuppressWarnings("unchecked")
        List<Map<String, String>> p13nsList = (List<Map<String, String>>) customerInfo.get("p13ns");

        Assert.assertTrue(p13nsList.isEmpty(), "p13ns should be empty - nudge should be suppressed by dismissal");
    }

    /**
     * Helper method to build UpdateCustomerP13NRequest with specified entity, type, and identifiers
     *
     * @param p13nEntity The P13N entity type
     * @param p13nType The P13N type
     * @param identifiersData The identifiers data
     * @return UpdateCustomerP13NRequest object
     */
    private UpdateCustomerP13NRequest buildUpdateP13nRequest(
            P13NEntity p13nEntity,
            P13NType p13nType,
            List<Map<String, Object>> identifiersData) {

        return UpdateCustomerP13NRequest.builder()
                .entity(p13nEntity)
                .type(p13nType)
                .identifiers(identifiersData)
                .build();
    }

    /**
     * Helper method to build GetCustomerP13NRequest with specified entity and type
     *
     * @param p13nEntity The P13N entity type
     * @param p13nType The P13N type
     * @return GetCustomerP13NRequest object
     */
    private GetCustomerP13NRequest buildGetP13nRequest(P13NEntity p13nEntity, P13NType p13nType) {
        GetCustomerP13NRequest.P13NEntities entityType = GetCustomerP13NRequest.P13NEntities.builder()
                .entity(p13nEntity)
                .type(p13nType)
                .build();
        return GetCustomerP13NRequest.builder()
                .p13NEntities(Collections.singletonList(entityType))
                .build();
    }
}
