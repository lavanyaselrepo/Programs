package accountorchestrator.customer.p13n;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerP13NRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerP13NRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerP13NResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.testng.Assert;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;
import org.testng.annotations.AfterClass;
import java.text.SimpleDateFormat;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;

import java.io.IOException;
import java.io.File;
import java.util.*;
import static com.walmart.chp.metrics.commons.constants.LogConstants.HUMAN;

public class AccountOrchestratorP13NTests {

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    private final Gson gson = new Gson();
    private P13nDao p13nDao;

    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private static final String ALL = "ALL";
    private WCPRetroFit wcpRetroFit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String accountType = "INDIVIDUAL";
    private String customerType = "INDIVIDUAL";
    private String accountCreationSource = "idVerification";
    private ValidationServiceRequest cprPatientRequest = null;
    private final ObjectMapper mapper = new ObjectMapper();
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();

    @BeforeClass
    void setContext() throws IOException {
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        wcpRetroFit = new WCPRetroFit();
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        p13nDao = new P13nDao();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    }

    @AfterClass
    void cleanUp() {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                    } catch (IOException e) {
                    }
                });
        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                        // Handle the IOException
                    }
                });
    }

    @Test(description = "Create p13n api success")
    public void createP13nsV1APISuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> ecommAdultConsentApproved = new HashMap<>();
        ecommAdultConsentApproved.put("dependentCustomerAccountId", String.valueOf("8384938"));
        rxIdentifiers.add(ecommAdultConsentApproved);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED, P13NType.SET, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(apiResponse.code(), 200);

    }

    @Test(description = "Create p13n api failure, mandatory fields absent")
    public void createP13nsV1APIError1() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<UpdateCustomerP13NRequest> p13nList = new ArrayList<UpdateCustomerP13NRequest>();
        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> ecommAdultConsentApproved = new HashMap<>();
        ecommAdultConsentApproved.put("dependentCustomerAccountId", String.valueOf("8384938"));
        rxIdentifiers.add(ecommAdultConsentApproved);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);


        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 400);
        Assert.assertEquals(error.getCode(), "DPR-DPACCOR-1100");
        Assert.assertTrue(error.getMessage().contains("Invalid identifiers. Missing identifier : rxNumber"));
    }

    @Test(description = "Create p13n api success")
    public void createP13nsV1APISuccess_02() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> rx1 = new HashMap<>();
        rx1.put("storeNbr", String.valueOf("8384938"));
        rx1.put("rxNumber", String.valueOf("8384938"));
        rxIdentifiers.add(rx1);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(apiResponse.code(), 200);

    }


    @Test(description = "Create p13n api failure, mandatory fields absent")
    public void createP13nsV1APIError3_InvalidDomainId() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<UpdateCustomerP13NRequest> p13nList = new ArrayList<UpdateCustomerP13NRequest>();
        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> ecommAdultConsentRejected = new HashMap<>();
        ecommAdultConsentRejected.put("dependentCustomerAccountId", String.valueOf("8384938"));
        rxIdentifiers.add(ecommAdultConsentRejected);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, "invalidDomainId", reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 400);

        Assert.assertTrue(error.getMessage().contains("Invalid input request. domainId invalidDomainId in input is invalid"));
    }



    @Test(description = "Create p13n api failure, mandatory fields absent")
    public void createP13nsV1APIError3_customerAccountIdEmpty() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<UpdateCustomerP13NRequest> p13nList = new ArrayList<UpdateCustomerP13NRequest>();
        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> ecommAdultConsentRejected = new HashMap<>();
        ecommAdultConsentRejected.put("dependentCustomerAccountId", String.valueOf("8384938"));
        rxIdentifiers.add(ecommAdultConsentRejected);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        "", updateCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 500);
    }

    @Test(description = "Get P13Ns success, without any query params, default to ALL")
    public void getP13NsSuccess_01() throws Exception {

        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        final String onlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(email);
        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);
        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first

        List<UpdateCustomerP13NRequest> p13nList = new ArrayList<UpdateCustomerP13NRequest>();
        List<Map<String, Object>> rxIdentifiers = new ArrayList<>();

        Map<String, Object> rx1 = new HashMap<>();
        rx1.put("storeNbr", String.valueOf("8384938"));
        rx1.put("rxNumber", String.valueOf("12345"));
        rxIdentifiers.add(rx1);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, rxIdentifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Error updateApiError = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 200);

        //Get P13ns API Call
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.RX, P13NType.ARCHIVE);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 200, errorMessage);



        //verify response
        GetCustomerP13NResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertNotNull(getCustomerP13nResponse, "Response payload should not be null");
        Assert.assertNotNull(getCustomerP13nResponse.getP13ns(), "p13ns list should not be null");
        Assert.assertFalse(getCustomerP13nResponse.getP13ns().isEmpty(), "p13ns list should not be empty");
        GetCustomerP13NResponse.P13n p13n = getCustomerP13nResponse.getP13ns().get(0);
        Assert.assertEquals(p13n.getEntity(), P13NEntity.RX.name());
        Assert.assertEquals(p13n.getType(), P13NType.ARCHIVE.name());
        Assert.assertNotNull(p13n.getIdentifiers(), "identifiers should not be null");
        Assert.assertFalse(p13n.getIdentifiers().isEmpty(), "identifiers should not be empty");
        Map<String, Object> identifier = p13n.getIdentifiers().get(0);
        Assert.assertEquals(identifier.get("storeNbr"), "8384938");
        Assert.assertEquals(identifier.get("rxNumber"), "12345");

    }

    @Test(description = "Get P13Ns success for ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED entity with SET type and dependentCustomerAccountId identifier")
    public void getP13NsSuccess_02() throws Exception {

        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        final String onlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(email);
        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);
        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Create P13ns first
        List<Map<String, Object>> identifiers = new ArrayList<>();
        Map<String, Object> identifier = new HashMap<>();
        identifier.put("dependentCustomerAccountId", String.valueOf("8384938"));
        identifiers.add(identifier);

        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET, identifiers);

        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);


        Error updateApiError = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        Assert.assertEquals(apiResponse.code(), 200);

        // Get P13ns API Call
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET);

        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit
                        .getP13Ns(onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 200, errorMessage);

        // verify response
        GetCustomerP13NResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertNotNull(getCustomerP13nResponse, "Response payload should not be null");
        Assert.assertNotNull(getCustomerP13nResponse.getP13ns(), "p13ns list should not be null");
        Assert.assertFalse(getCustomerP13nResponse.getP13ns().isEmpty(), "p13ns list should not be empty");
        GetCustomerP13NResponse.P13n p13n = getCustomerP13nResponse.getP13ns().get(0);
        Assert.assertEquals(p13n.getEntity(), P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.name());
        Assert.assertEquals(p13n.getType(), P13NType.SET.name());
        Assert.assertNotNull(p13n.getIdentifiers(), "identifiers should not be null");
        Assert.assertFalse(p13n.getIdentifiers().isEmpty(), "identifiers should not be empty");
        Map<String, Object> respIdentifier = p13n.getIdentifiers().get(0);
        Assert.assertEquals(respIdentifier.get("dependentCustomerAccountId"), "8384938");
    }

    @Test(description = "Get P13Ns success with multiple P13N entities in request")
    public void getP13NsSuccess_WithMultipleP13NEntries() throws Exception {
        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        final String onlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(email);
        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);
        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Create first P13N
        List<Map<String, Object>> identifiers1 = new ArrayList<>();
        Map<String, Object> identifier1 = new HashMap<>();
        identifier1.put("dependentCustomerAccountId", "1111111");
        identifiers1.add(identifier1);
        UpdateCustomerP13NRequest updateCustomerP13NRequest1 =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED, P13NType.SET, identifiers1);
        Response<Void> apiResponse1 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest1, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse1.code(), 200);

        // Create second P13N
        List<Map<String, Object>> identifiers2 = new ArrayList<>();
        Map<String, Object> identifier2 = new HashMap<>();
        identifier2.put("dependentCustomerAccountId", "2222222");
        identifiers2.add(identifier2);
        UpdateCustomerP13NRequest updateCustomerP13NRequest2 =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET, identifiers2);
        Response<Void> apiResponse2 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest2, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse2.code(), 200);

        // Create third P13N (RX, ARCHIVE)
        List<Map<String, Object>> identifiers3 = new ArrayList<>();
        Map<String, Object> identifier3 = new HashMap<>();
        identifier3.put("storeNbr", "8384938");
        identifier3.put("rxNumber", "12345");
        identifiers3.add(identifier3);
        UpdateCustomerP13NRequest updateCustomerP13NRequest3 =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, identifiers3);
        Response<Void> apiResponse3 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest3, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse3.code(), 200);

        // Test with only APPROVED entity
        GetCustomerP13NRequest.P13NEntities entityApproved = GetCustomerP13NRequest.P13NEntities.builder()
                .entity(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED)
                .type(P13NType.SET)
                .build();
        GetCustomerP13NRequest getApprovedRequest = GetCustomerP13NRequest.builder()
                .p13NEntities(Collections.singletonList(entityApproved))
                .build();
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> approvedResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getApprovedRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(approvedResponse.code(), 200);
        GetCustomerP13NResponse approvedPayload = approvedResponse.body().getPayload();
        Assert.assertNotNull(approvedPayload);
        Assert.assertNotNull(approvedPayload.getP13ns());
        boolean foundApproved = false;
        for (GetCustomerP13NResponse.P13n p13n : approvedPayload.getP13ns()) {
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.name().equals(p13n.getEntity())) {
                foundApproved = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "1111111");
            }
        }
        Assert.assertTrue(foundApproved, "ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED entity not found in response");

        // Test with only REJECTED entity
        GetCustomerP13NRequest.P13NEntities entityRejected = GetCustomerP13NRequest.P13NEntities.builder()
                .entity(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED)
                .type(P13NType.SET)
                .build();
        GetCustomerP13NRequest getRejectedRequest = GetCustomerP13NRequest.builder()
                .p13NEntities(Collections.singletonList(entityRejected))
                .build();
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> rejectedResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getRejectedRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(rejectedResponse.code(), 200);
        GetCustomerP13NResponse rejectedPayload = rejectedResponse.body().getPayload();
        Assert.assertNotNull(rejectedPayload);
        Assert.assertNotNull(rejectedPayload.getP13ns());
        boolean foundRejected = false;
        for (GetCustomerP13NResponse.P13n p13n : rejectedPayload.getP13ns()) {
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.name().equals(p13n.getEntity())) {
                foundRejected = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "2222222");
            }
        }
        Assert.assertTrue(foundRejected, "ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED entity not found in response");

        // Test with only RX ARCHIVE entity
        GetCustomerP13NRequest.P13NEntities entityRxArchive = GetCustomerP13NRequest.P13NEntities.builder()
                .entity(P13NEntity.RX)
                .type(P13NType.ARCHIVE)
                .build();
        GetCustomerP13NRequest getRxArchiveRequest = GetCustomerP13NRequest.builder()
                .p13NEntities(Collections.singletonList(entityRxArchive))
                .build();
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> rxArchiveResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getRxArchiveRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(rxArchiveResponse.code(), 200);
        GetCustomerP13NResponse rxArchivePayload = rxArchiveResponse.body().getPayload();
        Assert.assertNotNull(rxArchivePayload);
        Assert.assertNotNull(rxArchivePayload.getP13ns());
        boolean foundRxArchive = false;
        for (GetCustomerP13NResponse.P13n p13n : rxArchivePayload.getP13ns()) {
            if (P13NEntity.RX.name().equals(p13n.getEntity()) && P13NType.ARCHIVE.name().equals(p13n.getType())) {
                foundRxArchive = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("storeNbr"), "8384938");
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("rxNumber"), "12345");
            }
        }
        Assert.assertTrue(foundRxArchive, "RX ARCHIVE entity not found in response");

        // Test with all three entities
        GetCustomerP13NRequest getAllRequest = GetCustomerP13NRequest.builder()
                .p13NEntities(Arrays.asList(entityApproved, entityRejected, entityRxArchive))
                .build();
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> allResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getAllRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(allResponse.code(), 200);
        GetCustomerP13NResponse allPayload = allResponse.body().getPayload();
        Assert.assertNotNull(allPayload);
        Assert.assertNotNull(allPayload.getP13ns());
        boolean foundAllApproved = false;
        boolean foundAllRejected = false;
        boolean foundAllRxArchive = false;
        for (GetCustomerP13NResponse.P13n p13n : allPayload.getP13ns()) {
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.name().equals(p13n.getEntity())) {
                foundAllApproved = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "1111111");
            }
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.name().equals(p13n.getEntity())) {
                foundAllRejected = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "2222222");
            }
            if (P13NEntity.RX.name().equals(p13n.getEntity()) && P13NType.ARCHIVE.name().equals(p13n.getType())) {
                foundAllRxArchive = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("storeNbr"), "8384938");
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("rxNumber"), "12345");
            }
        }
        Assert.assertTrue(foundAllApproved, "ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED entity not found in response");
        Assert.assertTrue(foundAllRejected, "ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED entity not found in response");
        Assert.assertTrue(foundAllRxArchive, "RX ARCHIVE entity not found in response");
    }

    @Test(description = "Update and then dismiss P13N, assert get returns empty after dismissal")
    public void getP13NsSuccess_DismissalFlow() throws Exception {

        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        final String onlineAccountId =CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(email);
        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);
        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // 1. Create P13N (SET)
        List<Map<String, Object>> identifiers = new ArrayList<>();
        Map<String, Object> identifier = new HashMap<>();
        identifier.put("storeNbr", "8384938");
        identifier.put("rxNumber", "12345");
        identifiers.add(identifier);
        UpdateCustomerP13NRequest updateCustomerP13NRequest =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, identifiers);
        Response<Void> apiResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse.code(), 200);

        // 2. Assert via get (should return the entry)
        GetCustomerP13NRequest getCustomerP13NRequest =
                buildGetP13nRequest(P13NEntity.RX, P13NType.ARCHIVE);
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getApiResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(getApiResponse.code(), 200);
        GetCustomerP13NResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertNotNull(getCustomerP13nResponse);
        Assert.assertNotNull(getCustomerP13nResponse.getP13ns());
        Assert.assertFalse(getCustomerP13nResponse.getP13ns().isEmpty());
        GetCustomerP13NResponse.P13n p13n = getCustomerP13nResponse.getP13ns().get(0);
        Assert.assertEquals(p13n.getEntity(), P13NEntity.RX.name());
        Assert.assertEquals(p13n.getType(), P13NType.ARCHIVE.name());
        Assert.assertEquals(p13n.getIdentifiers().get(0).get("storeNbr"), "8384938");
        Assert.assertEquals(p13n.getIdentifiers().get(0).get("rxNumber"), "12345");

        // 3. Dismiss (CARD_DISMISSAL)
        UpdateCustomerP13NRequest dismissRequest =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.UNARCHIVE, identifiers);
        Response<Void> dismissResponse =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, dismissRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(dismissResponse.code(), 200);

        // 4. Assert via get (should now be empty)
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getAfterDismissal =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getCustomerP13NRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(getAfterDismissal.code(), 200);
    }

    @Test(description = "Get P13Ns with empty p13NEntities returns all P13Ns")
    public void getP13NsSuccess_GetAllWithEmptyEntities() throws Exception {
        String email = CommonUtil.generateRandomEmailId(10);
        String patientIdGenerated = CommonUtil.generateRandomNumber(9);

        Date dobDate = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(dobDate);
        String dobDPFormat = new SimpleDateFormat("MMddyyyy").format(dobDate);

        final String onlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(email);
        createCPRAccount(
                "9928",
                patientIdGenerated,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                dobCPRFormat,
                HUMAN);
        createPharmacyAccount(
                onlineAccountId,
                patientIdGenerated,
                dobDPFormat);

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Create first P13N
        List<Map<String, Object>> identifiers1 = new ArrayList<>();
        Map<String, Object> identifier1 = new HashMap<>();
        identifier1.put("dependentCustomerAccountId", "1111111");
        identifiers1.add(identifier1);
        UpdateCustomerP13NRequest updateCustomerP13NRequest1 =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED, P13NType.SET, identifiers1);
        Response<Void> apiResponse1 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest1, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse1.code(), 200);

        // Create second P13N
        List<Map<String, Object>> identifiers2 = new ArrayList<>();
        Map<String, Object> identifier2 = new HashMap<>();
        identifier2.put("dependentCustomerAccountId", "2222222");
        identifiers2.add(identifier2);
        UpdateCustomerP13NRequest updateCustomerP13NRequest2 =
                buildUpdateP13nRequest(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED, P13NType.SET, identifiers2);
        Response<Void> apiResponse2 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest2, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse2.code(), 200);

        // Create third P13N (RX, ARCHIVE)
        List<Map<String, Object>> identifiers3 = new ArrayList<>();
        Map<String, Object> identifier3 = new HashMap<>();
        identifier3.put("storeNbr", "8384938");
        identifier3.put("rxNumber", "12345");
        identifiers3.add(identifier3);
        UpdateCustomerP13NRequest updateCustomerP13NRequest3 =
                buildUpdateP13nRequest(P13NEntity.RX, P13NType.ARCHIVE, identifiers3);
        Response<Void> apiResponse3 =
                accountOrchestratorRetrofit.updateP13Ns(
                        onlineAccountId, updateCustomerP13NRequest3, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse3.code(), 200);

        // Get with empty p13NEntities (should return all P13Ns for the account)
        GetCustomerP13NRequest getAllRequest = GetCustomerP13NRequest.builder()
                .p13NEntities(new ArrayList<>())
                .build();
        Response<ServiceResponseHolder<GetCustomerP13NResponse>> getAllResponse =
                accountOrchestratorRetrofit.getP13Ns(
                        onlineAccountId, getAllRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(getAllResponse.code(), 200);
        GetCustomerP13NResponse allPayload = getAllResponse.body().getPayload();
        Assert.assertNotNull(allPayload);
        Assert.assertNotNull(allPayload.getP13ns());
        // Should contain at least the three we just added
        boolean foundApproved = false;
        boolean foundRejected = false;
        boolean foundRxArchive = false;
        for (GetCustomerP13NResponse.P13n p13n : allPayload.getP13ns()) {
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.name().equals(p13n.getEntity())) {
                foundApproved = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "1111111");
            }
            if (P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.name().equals(p13n.getEntity())) {
                foundRejected = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("dependentCustomerAccountId"), "2222222");
            }
            if (P13NEntity.RX.name().equals(p13n.getEntity()) && P13NType.ARCHIVE.name().equals(p13n.getType())) {
                foundRxArchive = true;
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("storeNbr"), "8384938");
                Assert.assertEquals(p13n.getIdentifiers().get(0).get("rxNumber"), "12345");
            }
        }
        Assert.assertTrue(foundApproved, "ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED entity not found in response");
        Assert.assertTrue(foundRejected, "ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED entity not found in response");
        Assert.assertTrue(foundRxArchive, "RX ARCHIVE entity not found in response");
    }

    private UpdateCustomerP13NRequest buildUpdateP13nRequest(
            P13NEntity p13nEntity,
            P13NType p13nType,
            List<Map<String, Object>> identifiersData) {

        return UpdateCustomerP13NRequest.builder()
                .entity(p13nEntity)
                .type(p13nType)
                .identifiers(identifiersData)
                .build();
    }

    private GetCustomerP13NRequest buildGetP13nRequest(P13NEntity p13nEntity, P13NType p13nType) {
        GetCustomerP13NRequest.P13NEntities entityType = GetCustomerP13NRequest.P13NEntities.builder()
                .entity(p13nEntity)
                .type(p13nType)
                .build();
        return GetCustomerP13NRequest.builder()
                .p13NEntities(Collections.singletonList(entityType))
                .build();
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        ValidationServiceRequest cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(dob);
        cprPatientRequest.getPatientInfo().setFirstName(firstName);
        cprPatientRequest.getPatientInfo().setLastName(lastName);

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            }
            else{
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    private void createPharmacyAccount(
            String customerAccountId, String commonPatientId, String dob)
            throws IOException {

        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request("9928", commonPatientId, dob);

        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {

            String reqId = reqIdString + CommonUtil.randomUUID();
            String reqTracking = reqTrackingString + CommonUtil.randomUUID();

            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqId,
                            reqTracking);

            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody() != null ? response.errorBody().toString() : "No error body");
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else{
                pharmacyProfilesToBeDeleted.add(customerAccountId);
            }
            break;
        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }






}
