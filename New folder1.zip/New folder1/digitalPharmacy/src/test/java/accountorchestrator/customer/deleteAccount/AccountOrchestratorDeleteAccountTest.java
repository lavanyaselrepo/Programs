package accountorchestrator.customer.deleteAccount;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.GetPHIAuthConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetCareGiverResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetProfileResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CASignUpV2Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMGetPrefDataResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class AccountOrchestratorDeleteAccountTest {

  private AccountOrchestratorRetrofit accountOrchestratorStgRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CARetrofit caRetrofit;
  private WCPRetroFit wcpRetroFit;
  private ConsentOrchestratorRetrofit consentOrchestratorRetrofit;
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String samsDomainId = "SAMS-PHARMACY";
  private String accountType = "INDIVIDUAL";
  private String customerType = "INDIVIDUAL";
  private String caregiver1CustomerId = null;
  private String caregiver1CustomerEmailId = null;
  private String caregiver1StoreNbr = null;
  private String caregiver1PatientId = null;
  private String caregiver1FirstName = null;
  private String caregiver1LastName = null;
  private String caregiver2CustomerEmailId = null;
  private String caregiver2CustomerId = null;
  private String caregiver2StoreNbr = null;
  private String caregiver2PatientId = null;
  private String caregiver2FirstName = null;
  private String caregiver2LastName = null;
  private String caregiver3CustomerId = null;
  private String caregiver3CustomerEmailId = null;
  private String caregiver3StoreNbr = null;
  private String caregiver3PatientId = null;
  private String caregiver3FirstName = null;
  private String caregiver3LastName = null;
    private String customerAccountId = null;
  private String storeNbr = null;
  private String patientId = null;
  private String caregiver1PhoneNbr = null;
  private String caregiver2PhoneNbr = null;
  private String caregiver3PhoneNbr = null;
  private String firstName = null;
  private String lastName = null;
  private String phoneNbr = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonPhoneNo = "1234567829";
  private String commonPassword = "Test@12345";

  @BeforeClass
  void setContext() throws Exception {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    accountOrchestratorStgRetrofit = new AccountOrchestratorRetrofit();
    caRetrofit = new CARetrofit();
    wcpRetroFit = new WCPRetroFit();
    consentOrchestratorRetrofit = new ConsentOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

    Date dateForOlderThan18 =
        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    // making test accounts
      String customerAccountEmailId = CommonUtil.generateRandomEmailId(10);
    storeNbr = CommonUtil.generateRandomNumber(6);
    patientId = CommonUtil.generateRandomNumber(9);
    firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    phoneNbr = CommonUtil.generateRandomNumber(10);

    caregiver1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    caregiver1StoreNbr = CommonUtil.generateRandomNumber(6);
    caregiver1PatientId = CommonUtil.generateRandomNumber(9);
    caregiver1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver1PhoneNbr = CommonUtil.generateRandomNumber(10);

    caregiver2CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    caregiver2StoreNbr = CommonUtil.generateRandomNumber(6);
    caregiver2PatientId = CommonUtil.generateRandomNumber(9);
    caregiver2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver2PhoneNbr = CommonUtil.generateRandomNumber(10);

    // LoggedIn User
    String trackID = CommonUtil.randomUUID();
    customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(customerAccountEmailId,
            commonPassword,
            commonPhoneNo,
            firstName,
            lastName,
            trackID);
    createCPRAccount(
        storeNbr,
        patientId,
        firstName,
        lastName,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        phoneNbr);
    createSMSEnrollment(storeNbr, patientId, "1", phoneNbr);
    createSMSEnrollment(storeNbr, patientId, "3", customerAccountEmailId);
    createPharmacyAccount(
        storeNbr, patientId, phoneNbr, commonDobDPFormatForOlderThan18, customerAccountId);

    dateForOlderThan18 = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    commonDobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    // Caregiver 1 User
    caregiver1CustomerId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver1CustomerEmailId);
    createCPRAccount(
        caregiver1StoreNbr,
        caregiver1PatientId,
        caregiver1FirstName,
        caregiver1LastName,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        caregiver1PhoneNbr);
    createSMSEnrollment(caregiver1StoreNbr, caregiver1PatientId, "1", caregiver1PhoneNbr);
    createSMSEnrollment(caregiver1StoreNbr, caregiver1PatientId, "3", caregiver1CustomerEmailId);
    createPharmacyAccount(
        caregiver1StoreNbr,
        caregiver1PatientId,
        caregiver1PhoneNbr,
        commonDobDPFormatForOlderThan18,
        caregiver1CustomerId);

    dateForOlderThan18 = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    commonDobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    // Caregiver 2 User
    caregiver2CustomerId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver2CustomerEmailId);
    createCPRAccount(
        caregiver2StoreNbr,
        caregiver2PatientId,
        caregiver2FirstName,
        caregiver2LastName,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        caregiver2PhoneNbr);
    createSMSEnrollment(caregiver2StoreNbr, caregiver2PatientId, "1", caregiver2PhoneNbr);
    createSMSEnrollment(caregiver2StoreNbr, caregiver2PatientId, "3", caregiver2CustomerEmailId);
    createPharmacyAccount(
        caregiver2StoreNbr,
        caregiver2PatientId,
        caregiver2PhoneNbr,
        commonDobDPFormatForOlderThan18,
        caregiver2CustomerId);

    // adding caregivers for LoggedIn User
      wcpAddDependent(
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE,
        customerAccountId,
        caregiver1CustomerId);
      wcpAddDependent(
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.APPROVED,
        customerAccountId,
        caregiver2CustomerId);

    // Caregiver 3 User - SAMS

    caregiver3CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    caregiver3CustomerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver3CustomerEmailId);
    caregiver3StoreNbr = "5596"; // Sams club store number
    caregiver3PatientId = CommonUtil.generateRandomNumber(9);
    caregiver3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver3PhoneNbr = CommonUtil.generateRandomNumber(10);

    createCPRAccount(
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3FirstName,
            caregiver3LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            caregiver3PhoneNbr);
    createPharmacyAccountForSamsDomainId(
            caregiver3CustomerId,
            caregiver3StoreNbr,
            caregiver3PatientId,
            commonDobDPFormatForOlderThan18);

    dateForOlderThan18 = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    commonDobCPRFormatForOlderThan18 =
            new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);
  }
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource("idVerification")
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(dob)
                            .build())
            .build();
  }

  private void createPharmacyAccountForSamsDomainId(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      String setupReqId = reqIdString + CommonUtil.randomUUID();
      String setupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      samsDomainId,
                      createPharmacyAccountV1Request,
                      setupReqId,
                      setupReqTrackingId);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
      }
      break;
    }
  }

  /**
   * Clean up for CPR accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() {
    cprProfilesToBeDeletedList.forEach(
        request -> {
          request.getPatientInfo().setPatientStatusCode(20708);
          try {
            Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(request);
          } catch (IOException e) {
          }
        });
    pharmacyProfilesToBeDeleted.forEach(
            request -> {
              try {
                String cleanupReqId = reqIdString + CommonUtil.randomUUID();
                String cleanupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
                Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> getOnlineIdentityResp =
                        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                request, domainId, cleanupReqId, cleanupReqTrackingId);

                if (getOnlineIdentityResp.code() == 204) {
                  // If the response is 204, skip the deletion
                  return;
                }

                String deleteReqId = reqIdString + CommonUtil.randomUUID();
                String deleteReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
                accountEntityServiceRetrofit.deleteAccountV1(
                        request, domainId, deleteReqId, deleteReqTrackingId);

              } catch (IOException e) {
                // Handle the IOException
              }
            });
  }

  /**
   * Gets Ecomm consent for the user
   *
   * @throws IOException
   */
  private Response<GetPHIAuthConsentResponse> getEcommConsent(String customerAccountId)
      throws IOException, GeneralSecurityException {
    String reqId = reqIdString + CommonUtil.randomUUID();
    String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    return consentOrchestratorRetrofit.getEcommConsent(
        customerAccountId, domainId, reqId, reqTrackingId);
  }

  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  private void createCPRAccount(
      String storeNbr,
      String patientId,
      String firstName,
      String lastName,
      String dob,
      String type,
      String phoneNbr)
      throws IOException {
    cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(phoneNbr);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(phoneNbr);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
      }
      break;
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Call CA add dependent api
   *
   * @param type'
   * @throws IOException
   */
  private void wcpAddDependent(
      DependentInfo.TypeEnum type,
      DependentInfo.LinkageStatusEnum status,
      String dependentAccountId,
      String caregiverAccountId)
          throws Exception {
    WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(type, status, dependentAccountId, caregiverAccountId);
    Response<WCPAddDependentResponse> response = null;

    // This will try to create a person account in CA, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
        response = wcpRetroFit.addDependent(wcpAddDependentRequest,caregiverAccountId);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CA add dependent failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Call DM Post Preferences API to link store number and patient Id with phoneNbr
   *
   * @throws IOException
   */
  private void createSMSEnrollment(
      String storeNbr, String patientId, String notification_type, String notification_val)
      throws IOException {
    Response<DMPostPreferencesResponse> response = null;

    // This will try to create post pref in DM for 3 times if creation fails
    for (int i = 0; i < 3; i++) {
      response =
          dmPostPreferencesRetrofit.callDMPostPreferencesAPI(
              createDMPostPreferenceRequest(
                  storeNbr, patientId, notification_type, notification_val));

      if (!(response.code() == 200
          && response.body() != null
          && response.body().getResponseStatus() != null
          && "100".equals(response.body().getResponseStatus().getStatus_code()))) {

        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "DM Post Preference call failure. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Builds DM Post Preference Request
   *
   * @param storeNbr
   * @param patientId
   * @param notification_type
   * @param notification_val
   * @return
   */
  private DMPostPreferencesRequest createDMPostPreferenceRequest(
      String storeNbr, String patientId, String notification_type, String notification_val) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    return DMPostPreferencesRequest.builder()
        .storeNbr(storeNbr)
        .patientId(patientId)
            .zipCode("96898")
            .userId("SIGPAD")
            .storePhone("8009666546")
            .timeStamp(timestamp)
            .language("101")
        .preferences(
            org.openjdk.tools.javac.util.List.of(
                DMPostPreferencesRequest.Preference.builder()
                    .notification_type(notification_type)
                    .notification_val(notification_val)
                    .short_code_type_id("1")
                    .enrollment_status_code("26805")
                    .build()))
        .build();
  }

  /**
   * Builds ca create person request
   *
   * @return
   */
  private CASignUpV2Request getCASignUpV2Request(
      String firstName, String lastName, String customerEmailId) {
    List<CASignUpV2Request.PersonName> personNames = new ArrayList<>();
    personNames.add(
        CASignUpV2Request.PersonName.builder().firstName(firstName).lastName(lastName).build());

    List<CASignUpV2Request.Account> accounts = new ArrayList<>();
    accounts.add(
        CASignUpV2Request.Account.builder()
            .accountType(accountType)
            .emailAddress(customerEmailId)
            .build());

    CASignUpV2Request.Person person =
        CASignUpV2Request.Person.builder()
            .customerType(customerType)
            .names(personNames)
            .accounts(accounts)
            .build();

    return CASignUpV2Request.builder()
        .payload(
            CASignUpV2Request.Payload.builder()
                .tenantId("WALMART.COM")
                .realmId("WALMART.COM")
                .person(person)
                .password("Walmart@123")
                .build())
        .build();
  }

  /**
   * Builds create pharmacy account request
   *
   * @param storeNbr
   * @param patientId
   * @param phoneNbr
   * @param dob
   * @return
   */
  private CreateAccountByPatientIdV1Request getCreatePharmacyAccountByPatientIdV1Request(
      String storeNbr, String patientId, String phoneNbr, String dob) {
    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(storeNbr);
    customerInfo.setPatientId(patientId);
    customerInfo.setPhoneNumber(phoneNbr);
    customerInfo.setDob(dob);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        new CreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

    return createAccountByPatientIdV1Request;
  }

  /**
   * Creates Pharmacy account for a user
   *
   * @param storeNbr
   * @param patientId
   * @param phoneNbr
   * @param dob
   * @param customerAccountId
   * @throws IOException
   * @throws GeneralSecurityException
   */
  private void createPharmacyAccount(
      String storeNbr, String patientId, String phoneNbr, String dob, String customerAccountId)
      throws IOException, GeneralSecurityException {

    Response<ServiceResponse>
        createAccountByPatientIdV1Response = null;

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request1 =
        getCreatePharmacyAccountByPatientIdV1Request(storeNbr, patientId, phoneNbr, dob);

    for (int i = 0; i < 3; i++) {
      createAccountByPatientIdV1Response =
          accountOrchestratorStgRetrofit.createAccountByPatientIdV1(
              customerAccountId,
              domainId,
              createAccountByPatientIdV1Request1);
      if (!(createAccountByPatientIdV1Response.code() == 200
              && createAccountByPatientIdV1Response.body() != null
              && createAccountByPatientIdV1Response.body().getPayload() != null)
          && !createAccountByPatientIdV1Response.isSuccessful()) {
        Reporter.logJSON("Exception", createAccountByPatientIdV1Response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "Create patient account failed for customerId: "
                  + customerAccountId
                  + " with HttpStatusCode : "
                  + createAccountByPatientIdV1Response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
      }
      break;
    }
  }


  /**
   * Calls CA get caregivers to get the caregivers for the customer
   *
   * @param customerAccountId
   * @return
   * @throws IOException
   */
  private Response<WCPGetCareGiverResponse> getCaregivers(String customerAccountId)
          throws Exception {
      return wcpRetroFit.getCareGivers(customerAccountId);
  }

  /**
   * Call CA get Person to get the customer details
   *
   * @return
   * @throws IOException
   */
  private Response<WCPGetProfileResponse> getPersonByCustomerAccountId(String customerAccountId)
          throws Exception {
      return wcpRetroFit.getProfile(customerAccountId);
  }


  /**
   * Calling DMServiceHelper getPrefData for a given storeNbr and patientId
   *
   * @param patientId
   * @param storeNbr
   * @param buType
   * @param isEmailRequired
   * @return
   * @throws IOException
   */
  private String getEnrollementStatusCode(
      String patientId, String storeNbr, String buType, String isEmailRequired) throws IOException {
    List<String> shortCodeTypes = new ArrayList<>();
    shortCodeTypes.add("RX");
    shortCodeTypes.add("CS");
    Response<DMGetPrefDataResponse> dmResponse =
        DMServiceHelper.getPrefData(
            dmPostPreferencesRetrofit,
            DMServiceHelper.buildDMGetPrefDataRequest(
                patientId, storeNbr, buType, isEmailRequired, shortCodeTypes));

    // Retrieve the patient preferences
    if (dmResponse.body() != null) {
      List<DMGetPrefDataResponse.PatientPreference> patientPreferences =
          dmResponse.body().getPatientPreferences();

      // Find the enrollmentStatusCode when the notificationType is 3
      for (DMGetPrefDataResponse.PatientPreference preference : patientPreferences) {
        if (preference.getNotificationType().equals("3")) {
          return preference.getEnrollmentStatusCode();
        }
      }
    }
    // If the enrollmentStatusCode is not found for notificationType 3, return null or handle it as
    // needed
    return null;
  }

  @Test(priority = 0, description = "delete account v1 success response")
  public void deleteAccountV1SuccessCase()
      throws IOException, GeneralSecurityException, InterruptedException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(domainId, customerAccountId, reqId, reqTrackingId);

    // Step - 2a: Calling deleteAccountV1 with a valid customerAccountId ,valid domainId
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId, domainId, reqId, reqTrackingId);

    // To check for async flows
    Thread.sleep(200000);

    // Step - 2b: Calling getEnrollementStatusCode to get the enrollmentStatusCode for email
    // preference
    String enrollmentStatusCode = getEnrollementStatusCode(patientId, storeNbr, "1", "true");

    // Step - 2c: Calling getEcommConsent to get the consent for the customer
    Response<GetPHIAuthConsentResponse> getPHIAuthConsentResponse =
        getEcommConsent(customerAccountId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, deleteAccountV1Response);

    // Step - 4: Parsing the response to the deleteAccountV1Response class so that we can assert
    // GetCustomerInfoV2
    DeleteAccountV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountV1Response.body().getPayload()),
            DeleteAccountV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(deleteAccountV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(response.getCustomerAccountId(), customerAccountId);

    // since the email is un-enrolled, the enrollment status code is 26803
    Assert.assertEquals(enrollmentStatusCode, "26803");

    // since the account is deleted consent gives 500
    Assert.assertEquals(getPHIAuthConsentResponse.code(), 400);

  }

  @Test(priority = 1, description = "delete account v1 pharmacy account already deleted case")
  public void deleteAccountV1WhenPharmacyAccountAlreadyDeletedCase()
      throws IOException, GeneralSecurityException, InterruptedException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(domainId, customerAccountId, reqId, reqTrackingId);

    // Step - 2: Calling deleteAccountV1 with a valid customerAccountId ,valid domainId
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, deleteAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 410, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1061");
  }

  @Test(priority = 2, description = "delete account v1 invalid domainId case")
  public void deleteAccountV1WhenInvalidDomainId()
      throws IOException, GeneralSecurityException, InterruptedException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    logAccountDetails(invalidDomainId, customerAccountId, reqId, reqTrackingId);

    // Step - 2: Calling deleteAccountV1 with a valid customerAccountId ,invalidDomainId domainId
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, deleteAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
  }

  @Test(
      priority = 3,
      description = "delete account v1 success response when CA get caregivers gives 404")
  public void deleteAccountV1SuccessCaseWhenCAGetCaregiversGives404()
          throws Exception {

    // Step - 1a : making test accounts
    String customerAccountEmailId1 = CommonUtil.generateRandomEmailId(10);
    String storeNbr1 = CommonUtil.generateRandomNumber(6);
    String patientId1 = CommonUtil.generateRandomNumber(9);
    String firstName1 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName1 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String phoneNbr1 = CommonUtil.generateRandomNumber(10);
    Date dateForOlderThan18 =
        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    String dobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    String dobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);
    String customerAccountId1 = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(customerAccountEmailId1);

    createCPRAccount(
        storeNbr1, patientId1, firstName1, lastName1, dobCPRFormatForOlderThan18, HUMAN, phoneNbr1);

    createSMSEnrollment(storeNbr1, patientId1, "1", phoneNbr1);
    createSMSEnrollment(storeNbr1, patientId1, "3", customerAccountEmailId1);

    createPharmacyAccount(
        storeNbr1, patientId1, phoneNbr1, dobDPFormatForOlderThan18, customerAccountId1);

    // Step - 1b: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(domainId, customerAccountId, reqId, reqTrackingId);

    // Step - 2a: Calling deleteAccountV1 with a valid customerAccountId which doesn't have any
    // caregivers ,valid domainId
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId1, domainId, reqId, reqTrackingId);

    // To check for async flows
     Thread.sleep(200000);

    // Step - 2b: Calling getEcommConsent to get the consent for the customer
    Response<GetPHIAuthConsentResponse> getPHIAuthConsentResponse =
        getEcommConsent(customerAccountId1);

    // Step - 2c: Calling getCaregivers to get the caregivers for the customer
    Response<WCPGetCareGiverResponse> wcpGetCaregiversResponse = getCaregivers(customerAccountId1);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, deleteAccountV1Response);

    // Step - 4: Parsing the response to the deleteAccountV1Response class so that we can assert
    // GetCustomerInfoV2
    DeleteAccountV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountV1Response.body().getPayload()),
            DeleteAccountV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(deleteAccountV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(response.getCustomerAccountId(), customerAccountId1);

    // since there are no caregivers, ca gives 404
    Assert.assertEquals(wcpGetCaregiversResponse.code(), 404);

    // since the account is deleted, consent gives 500
    Assert.assertEquals(getPHIAuthConsentResponse.code(), 400);
  }

  @Test(
      priority = 4,
      description = "delete account v1 success response when CA get person gives 404")
  public void deleteAccountV1SuccessCaseWhenCAGetPersonGives404()
          throws Exception {

    // Step - 1a : making test accounts
    // customerAccountId2 is a random UUID — no dotcom account exists for this CID.
    // The pharmacy account is created via AES directly (not the orchestrator) because the
    // orchestrator's createAccountByPatientIdV1 requires a valid dotcom CID in CA.
    String storeNbr2 = CommonUtil.generateRandomNumber(6);
    String patientId2 = CommonUtil.generateRandomNumber(9);
    String firstName2 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName2 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String phoneNbr2 = CommonUtil.generateRandomNumber(10);
    Date dateForOlderThan18 =
        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    String dobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    String dobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);
    String customerAccountId2 = CommonUtil.randomUUID();

    createCPRAccount(
        storeNbr2, patientId2, firstName2, lastName2, dobCPRFormatForOlderThan18, HUMAN, phoneNbr2);

    // Step - 1b: Create pharmacy account in AES directly using the random UUID CID
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request(storeNbr2, patientId2, dobDPFormatForOlderThan18);
    String setupReqId = reqIdString + CommonUtil.randomUUID();
    String setupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> createAesResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            customerAccountId2,
            domainId,
            createPharmacyAccountV1Request,
            setupReqId,
            setupReqTrackingId);
    if (createAesResponse.code() == 200) {
      pharmacyProfilesToBeDeleted.add(customerAccountId2);
    }

    // Step - 1c: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(domainId, customerAccountId2, reqId, reqTrackingId);

    // Step - 2a: Calling deleteAccountV1 — orchestrator handles CA 404 gracefully and still
    // returns 200 since the pharmacy account exists in AES
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId2, domainId, reqId, reqTrackingId);

    // To check for async flows
    Thread.sleep(200000);

    // Step - 2b: Calling getCaregivers — expects 404 (no WCP relationship for random UUID CID)
    Response<WCPGetCareGiverResponse> wcpGetCaregiversResponse = getCaregivers(customerAccountId2);

    // Step - 2c: Calling getPersonByCustomerAccountId — expects 404 (no CA account for random UUID CID)
    Response<WCPGetProfileResponse> caGetPersonResponse =
        getPersonByCustomerAccountId(customerAccountId2);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, deleteAccountV1Response);

    // Step - 4: Assert status code first to get a clear failure message before accessing body
    Assert.assertEquals(deleteAccountV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(deleteAccountV1Response.body().getPayload(), "Payload is null");

    // Step - 5: Parsing the response to the deleteAccountV1Response class
    DeleteAccountV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountV1Response.body().getPayload()),
            DeleteAccountV1Response.class);

    // Step - 6: Asserting payload and secondary calls
    Assert.assertEquals(response.getCustomerAccountId(), customerAccountId2);

    // since there are no caregivers, ca gives 404
    Assert.assertEquals(wcpGetCaregiversResponse.code(), 404);

    // since there is no dotcom account for this CID, CA person gives 404
    Assert.assertEquals(caGetPersonResponse.code(), 404);
  }

  @Test(priority = 5, description = "delete account v1 success response when there is no TnC")
  public void deleteAccountV1SuccessCaseWhenThereIsNoTnC()
          throws Exception {

    // Step - 1a : making test accounts
    String customerAccountEmailId3 = CommonUtil.generateRandomEmailId(10);
    String storeNbr3 = CommonUtil.generateRandomNumber(6);
    String patientId3 = CommonUtil.generateRandomNumber(9);
    String firstName3 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName3 = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String phoneNbr3 = CommonUtil.generateRandomNumber(10);
    Date dateForOlderThan18 =
        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    String dobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    String dobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);
    String customerAccountId3 = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(customerAccountEmailId3);

    createCPRAccount(
        storeNbr3, patientId3, firstName3, lastName3, dobCPRFormatForOlderThan18, HUMAN, phoneNbr3);

    createSMSEnrollment(storeNbr3, patientId3, "1", phoneNbr3);
    createSMSEnrollment(storeNbr3, patientId3, "3", customerAccountEmailId3);

    createPharmacyAccount(
        storeNbr3, patientId3, phoneNbr3, dobDPFormatForOlderThan18, customerAccountId3);

    // Step - 1b: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(domainId, customerAccountId3, reqId, reqTrackingId);

    // Step - 2a: Calling deleteAccountV1 with a valid customerAccountId which doesn't have any
    // caregivers ,valid domainId
    Response<ServiceResponse>
        deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                customerAccountId3, domainId, reqId, reqTrackingId);

    // Step - 2b: Calling getCaregivers to get the caregivers for the customer
    Response<WCPGetCareGiverResponse> wcpGetCaregiversResponse = getCaregivers(customerAccountId3);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, deleteAccountV1Response);

    // Step - 4: Parsing the response to the deleteAccountV1Response class so that we can assert
    // GetCustomerInfoV2
    DeleteAccountV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountV1Response.body().getPayload()),
            DeleteAccountV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(deleteAccountV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(response.getCustomerAccountId(), customerAccountId3);

    // since there are no caregivers, ca gives 404
    Assert.assertEquals(wcpGetCaregiversResponse.code(), 404);
  }

  @Test(priority = 6, description = "delete account v1 success response")
  public void deleteAccountV1SuccessCaseForSamsDomain()
          throws IOException, GeneralSecurityException, InterruptedException {

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

      // Step - 2a: Calling deleteAccountV1 with a valid customerAccountId ,valid domainId
      Response<ServiceResponse>
              deleteAccountV1Response =
              accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                      caregiver3CustomerId, samsDomainId, reqId, reqTrackingId);

      // To check for async flows
      Thread.sleep(20000);


      // Step - 3: Building errorMessage in case the Assert for response fails
      String deleteErrorMessage = CommonUtil.buildErrorMessage(gson, deleteAccountV1Response);

      // Step - 4: Parsing the response to the deleteAccountV1Response class so that we can assert
      // GetCustomerInfoV2
      DeleteAccountV1Response response =
              ResponseUtil.parseResponse(
                      gson,
                      ((LinkedTreeMap<String, Object>) deleteAccountV1Response.body().getPayload()),
                      DeleteAccountV1Response.class);

      // Step - 5: Asserting response
      Assert.assertEquals(deleteAccountV1Response.code(), 200, deleteErrorMessage);
      Assert.assertNotNull(deleteAccountV1Response.body().getPayload(), "Payload is null");
      Assert.assertEquals(response.getCustomerAccountId(), caregiver3CustomerId);


  }

  @Test(priority = 7, description = "delete account v1 pharmacy account already deleted case")
  public void deleteAccountV1WhenPharmacyAccountAlreadyDeletedCaseForSamsDomain()
          throws IOException, GeneralSecurityException, InterruptedException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(samsDomainId, caregiver3CustomerId, reqId, reqTrackingId);

    // Step - 2: Calling deleteAccountV1 with a valid customerAccountId ,valid domainId
    Response<ServiceResponse>
            deleteAccountV1Response =
            accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
                    caregiver3CustomerId, samsDomainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, deleteAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 410, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1061");
  }

  @Test(priority = 8, description = "delete account v1 when customerAccountId is blank — service treats it as already-deleted")
  public void deleteAccountV1WhenCustomerAccountIdIsInvalid()
      throws IOException, GeneralSecurityException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidCustomerAccountId = " ";
    logAccountDetails(domainId, invalidCustomerAccountId, reqId, reqTrackingId);

    // Step - 2: Calling deleteAccountV1 with a blank/whitespace customerAccountId and valid domainId.
    // The service does not validate customerAccountId format — it looks it up and finds a tombstone,
    // returning 410 DPR-DPACCOR-1061 (same as already-deleted).
    Response<ServiceResponse> deleteAccountV1Response =
        accountOrchestratorStgRetrofit.deletePharmacyAccountV1(
            invalidCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, deleteAccountV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(deleteAccountV1Response.code(), 410, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1061");
  }

  private void logAccountDetails(
      String domainId, String loggedInCustomerAccountId, String reqId, String reqTrackingId) {
    Reporter.logJSON("domain Id", domainId);
    Reporter.logJSON("Logged In Customer Account Id", loggedInCustomerAccountId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
