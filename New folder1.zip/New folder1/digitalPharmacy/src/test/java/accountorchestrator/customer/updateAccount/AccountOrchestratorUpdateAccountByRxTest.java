package accountorchestrator.customer.updateAccount;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DPExtendedOpsUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerInfoByPidV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateAccountByRxV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerInfoByPidV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.UpdateAccountByRxV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ImportRxUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccountOrchestratorUpdateAccountByRxTest {

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private ImportRxUtil importRxUtil;
    private WCPRetroFit wcpRetrofit;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    private final Gson gson = new GsonBuilder().create();
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    String domainId = "WM-PHARMACY";
    String connectedPatientStore = "5537";
    String underLinkedPatientStore = "5548";

    List<DPExtendedOpsUtils.PatientData> cleanUpData;

    @BeforeClass
    void setContext() throws IOException {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        wcpRetrofit= new WCPRetroFit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        cleanUpData = new ArrayList<>();
        importRxUtil = new ImportRxUtil();
    }

    @Test(
            priority = 1,
            description = "UpdateAccountByRx Invalid Rx")
    void updateAccountByRxV1InvalidRx() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String cid = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().storeNbr("123456").build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(cid, domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid input request. Rx number is null/empty");
    }

    @Test(
            priority = 1,
            description = "UpdateAccountByRx Invalid isDependent Flag")
    void updateAccountByRxV1InvalidFlag() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String cid = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr("98765433").storeNbr("12345").isDependent(false).customerId(CommonUtil.randomUUID()).build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(cid, domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid input request. Request Body customerId should be same as logged-in customerAccountId if isDependent is false");
    }

    @Test(
            priority = 1,
            description = "UpdateAccountByRx Invalid Store")
    void updateAccountByRxV1InvalidStore() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String cid = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr("98765433").storeNbr("123456").isDependent(true).customerId(CommonUtil.randomUUID()).build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(cid, domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1036");
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid storeNbr in request. Store number length should not be more than 5");
    }

    @Test(
            priority = 1,
            description = "UpdateAccountByRx Self Under Linking Success scenario")
    void updateAccountByRxV1SelfUnderLinkingSuccess() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ImportRxUtil.ImportRxPatientData importRxPatientData = importRxUtil.generateUnderLinkingPatient(connectedPatientStore, underLinkedPatientStore, accountOrchestratorRetrofit, gson);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr(importRxPatientData.getUnderLinkedPatientData().getRx()).storeNbr(importRxPatientData.getUnderLinkedPatientData().getStoreNbr()).build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(importRxPatientData.getLinkedPatientData().getCid(), domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 200, errorMessage);
        UpdateAccountByRxV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) updateAccountByRxV1Response.body().getPayload()),
                        UpdateAccountByRxV1Response.class);

        // Asserting desired responses
        Assert.assertEquals(response.getCustomerAccountId(),importRxPatientData.getLinkedPatientData().getCid());

        //clean up
        cleanUpData.add(importRxPatientData.getLinkedPatientData());
        cleanUpData.add(importRxPatientData.getUnderLinkedPatientData());
    }

    @Test(
            priority = 1,
            description = "UpdateAccountByRx Self Under Linking Conflict scenario")
    void updateAccountByRxV1SelfUnderLinkingConflict() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ImportRxUtil.ImportRxPatientData importRxPatientData = importRxUtil.generateUnderLinkingPatientConflict(connectedPatientStore, underLinkedPatientStore, accountOrchestratorRetrofit, gson);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr(importRxPatientData.getUnderLinkedPatientData().getRx()).storeNbr(importRxPatientData.getUnderLinkedPatientData().getStoreNbr()).build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(importRxPatientData.getLinkedPatientData().getCid(), domainId, request, reqId, reqTrackingId);

        // Parsing response
        ServiceResponse serviceResponse = CommonUtil.getServiceResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(serviceResponse.getError());

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 409, errorMessage);
        UpdateAccountByRxV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) serviceResponse.getPayload()),
                        UpdateAccountByRxV1Response.class);

        // Asserting desired responses
        Assert.assertEquals(response.getExistingAccountInfo().getCustomerAccountId(),importRxPatientData.getUnderLinkedPatientData().getCid());

        //clean up
        cleanUpData.add(importRxPatientData.getUnderLinkedPatientData());
        cleanUpData.add(importRxPatientData.getLinkedPatientData());
    }


    @Test(
            priority = 1,
            description = "UpdateAccountByRx Dependent Under Linking Success scenario")
    void updateAccountByRxV1DependentUnderLinkingSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ImportRxUtil.PatientUnderLinkingData importRxPatientData = importRxUtil.generateUnderLinkingAdultDependentPatient(connectedPatientStore, underLinkedPatientStore, wcpRetrofit, accountOrchestratorRetrofit, gson);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder()
                .rxNbr(importRxPatientData.getDependent().getUnderLinkedPatientData().getRx())
                .storeNbr(importRxPatientData.getDependent().getUnderLinkedPatientData().getStoreNbr())
                .isDependent(true)
                .customerId(importRxPatientData.getDependent().getLinkedPatientData().getCid())
                .build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(importRxPatientData.getCaregiver().getCid(), domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 200, errorMessage);
        UpdateAccountByRxV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) updateAccountByRxV1Response.body().getPayload()),
                        UpdateAccountByRxV1Response.class);

        // Asserting desired responses
        Assert.assertEquals(response.getCustomerAccountId(),importRxPatientData.getDependent().getLinkedPatientData().getCid());

        //clean up
        cleanUpData.add(importRxPatientData.getCaregiver());
        cleanUpData.add(importRxPatientData.getDependent().getLinkedPatientData());
        cleanUpData.add(importRxPatientData.getDependent().getUnderLinkedPatientData());
    }


    @Test(
            priority = 1,
            description = "UpdateAccountByRx Dependent Under Linking Conflict scenario")
    void updateAccountByRxV1DependentUnderLinkingConflict() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ImportRxUtil.PatientUnderLinkingData patientUnderLinkingData = importRxUtil.generateUnderLinkingAdultDependentPatientConflict(connectedPatientStore, underLinkedPatientStore, wcpRetrofit, accountOrchestratorRetrofit, gson);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getRx()).storeNbr(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getStoreNbr())
                .isDependent(true)
                .customerId(patientUnderLinkingData.getDependent().getLinkedPatientData().getCid())
                .build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(patientUnderLinkingData.getCaregiver().getCid(), domainId, request, reqId, reqTrackingId);

        // Parsing response
        ServiceResponse serviceResponse = CommonUtil.getServiceResponse(gson, updateAccountByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(serviceResponse.getError());

        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 409, errorMessage);
        UpdateAccountByRxV1Response response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) serviceResponse.getPayload()),
                        UpdateAccountByRxV1Response.class);

        // Asserting desired responses
        Assert.assertEquals(response.getExistingAccountInfo().getCustomerAccountId(),patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getCid());

        //clean up
        cleanUpData.add(patientUnderLinkingData.getDependent().getLinkedPatientData());
        cleanUpData.add(patientUnderLinkingData.getCaregiver());
        cleanUpData.add(patientUnderLinkingData.getDependent().getUnderLinkedPatientData());
    }


    @Test(
            priority = 1,
            description = "UpdateAccountByRx Minor Dependent Under Linking Success scenario")
    void updateAccountByRxV1MinorDependentUnderLinkingSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ImportRxUtil.PatientUnderLinkingData patientUnderLinkingData = importRxUtil.generateUnderLinkingMinorDependentPatient(connectedPatientStore, underLinkedPatientStore,wcpRetrofit, accountOrchestratorRetrofit, gson);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        UpdateAccountByRxV1Request request = UpdateAccountByRxV1Request.builder().rxNbr(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getRx()).storeNbr(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getStoreNbr())
                .isDependent(true)
                .customerId(patientUnderLinkingData.getDependent().getLinkedPatientData().getCid())
                .build();

        Response<ServiceResponse> updateAccountByRxV1Response =
                accountOrchestratorRetrofit.updateAccountByRxV1(patientUnderLinkingData.getCaregiver().getCid(), domainId, request, reqId, reqTrackingId);


        // Asserting desired responses
        Assert.assertEquals(updateAccountByRxV1Response.code(), 200);

        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                GetCustomerInfoByPidV1Request.builder()
                        .patientId(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getPatientId())
                        .storeNbr(patientUnderLinkingData.getDependent().getUnderLinkedPatientData().getStoreNbr())
                        .build();

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        domainId,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        false,
                        true,
                        true);

        if(getCustomerInfoByPidResponse.code() == 200) {
            GetCustomerInfoByPidV1Response responsepid =
                    ResponseUtil.parseResponse(
                            gson,
                            ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                            GetCustomerInfoByPidV1Response.class);

            Assert.assertEquals(responsepid.getCustomerInfo().getCustomerAccountId(),responsepid.getCustomerInfo().getCustomerAccountId());
        }



        //clean up
        cleanUpData.add(patientUnderLinkingData.getDependent().getLinkedPatientData());
        cleanUpData.add(patientUnderLinkingData.getCaregiver());
        cleanUpData.add(patientUnderLinkingData.getDependent().getUnderLinkedPatientData());
    }


    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterTest
    void cleanUp() throws IOException {
        cleanUpData.stream()
                .filter(patientData -> patientData.getRx() != null)
                .forEach(patientData -> {
                    patientData.getDPExtendedOpsUtils().cleanUpRx(Integer.parseInt(patientData.getRx()));
                });

        cleanUpData.stream()
                .filter(patientData -> patientData.getCid() != null)
                .forEach(
                        request -> {
                            try {
                                Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> getOnlineIdentityResp =
                                        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                                request.getCid(), domainId, reqIdString, reqTrackingString);

                                if (getOnlineIdentityResp.code() == 204) {
                                    // If the response is 204, skip the deletion
                                    return;
                                }

                                accountEntityServiceRetrofit.deleteAccountV1(
                                        request.getCid(), domainId, reqIdString, reqTrackingString);

                            } catch (IOException e) {
                                // Handle the IOException
                            }
                        });
    }

}
