package accountorchestrator.customer.getcustomerdependentandsmsenrolledinfo;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.WalmartPlusStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerDependentsAndSmsEnrolledInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.restapi.DMStageIDRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.request.PharmaAuthPatientIdStoreNbrRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.response.IsCustomerInCoolDownResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPCreateGuestAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPCreateGuestAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountOrchestratorGetCustomerDependentsAndSMSEnrolledInfoTests {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private static DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private static DMStageIDRetrofit dmStageIDRetrofit;
  private WCPRetroFit wcpRetroFit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String accountCreationSource = "smsOtpVerification";
  private String accountType = "INDIVIDUAL";
  private String customerType = "INDIVIDUAL";
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder()
      .registerTypeAdapter(LocalDateTime.class, new TypeAdapter<LocalDateTime>() {
        @Override
        public void write(JsonWriter out, LocalDateTime value) throws IOException {
          if (value == null) {
            out.nullValue();
          } else {
            out.beginArray();
            out.value(value.getYear());
            out.value(value.getMonthValue());
            out.value(value.getDayOfMonth());
            out.value(value.getHour());
            out.value(value.getMinute());
            out.value(value.getSecond());
            out.endArray();
          }
        }

        @Override
        public LocalDateTime read(JsonReader in) throws IOException {
          if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
          } else if (in.peek() == JsonToken.BEGIN_ARRAY) {
            in.beginArray();
            int year = in.nextInt();
            int month = in.nextInt();
            int day = in.nextInt();
            int hour = in.hasNext() ? in.nextInt() : 0;
            int minute = in.hasNext() ? in.nextInt() : 0;
            int second = in.hasNext() ? in.nextInt() : 0;
            in.endArray();
            return LocalDateTime.of(year, month, day, hour, minute, second);
          } else if (in.peek() == JsonToken.STRING) {
            String dateStr = in.nextString();
            return LocalDateTime.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
          }
          return null;
        }
      })
      .create();
  private String caregiverCustomerEmailId = null;
  private String dependentAEmailId = null;
  private String dependentBEmailId = null;
  private String caregiverCustomerAccountId = null;
  private String dependent1CustomerAccountId = null;
  private String dependent2CustomerAccountId = null;
  private String dependentACustomerAccountId = null;
  private String dependentBCustomerAccountId = null;
  private String caregiverStoreNbr = null;
  private String caregiverPatientId = null;
  private String dependent1StoreNbr = null;
  private String dependent1PatientId = null;
  private String dependent2StoreNbr = null;
  private String dependent2PatientId = null;
  private String dependentAStoreNbr = null;
  private String dependentAPatientId = null;
  private String dependentBStoreNbr = null;
  private String dependentBPatientId = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;
  private String commonDobCPRFormatForLessThan18 = null;
  private String commonDobDPFormatForLessThan18 = null;
  private String smsEnrolledDependentCustomerEmailId = null;
  private String caregiverFirstName = null;
  private String caregiverLastName = null;
  private String dependent1FirstName = null;
  private String dependent1LastName = null;
  private String dependent2FirstName = null;
  private String dependent2LastName = null;
  private String dependentAFirstName = null;
  private String dependentALastName = null;
  private String dependentBFirstName = null;
  private String dependentBLastName = null;
  private String caregiverStageId = null;
  private String dependent1StageId = null;
  private String dependent2StageId = null;
  private String dependentAStageId = null;
  private String dependentBStageId = null;
  private String phoneNbrA = null;
  private String phoneNbrB = null;
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  private static String refillConfirmationRefType = "refill-confirmation-sms";
  private static String ciImzReco = "ci-imz-reco";
  private String phoneNbr = null;
  private String enrollmentStatusCode = "26805";
  private String flowType = "FAM";
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
  static List<DMPostPreferencesRequest> dmProfilesToBeDeleted = new ArrayList<>();
  List<PharmaAuthPatientIdStoreNbrRequest> pharmaAuthPatientLinkProfilesToBeDeleted =
          new ArrayList<>();
  private String wmPharmacyStore = "9928";
  private IDatabaseContext accountDbContext;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    pharmacyAuthServiceRetrofit = new PharmacyAuthServiceRetrofit();
    dmStageIDRetrofit = new DMStageIDRetrofit();
    accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();

    caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    smsEnrolledDependentCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    phoneNbr = CommonUtil.generateRandomNumber(10);

    Date dateForOlderThan18 =
            new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
            new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
    commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

    // making test accounts
    createTestData();
  }

  private void createTestData() throws Exception {

    // create customer data
    caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
    caregiverPatientId = CommonUtil.generateRandomNumber(9);
    caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    caregiverCustomerEmailId);
    createCPRAccount(
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverFirstName,
            caregiverLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            caregiverCustomerAccountId,
            caregiverStoreNbr,
            caregiverPatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(caregiverStoreNbr, caregiverPatientId, phoneNbr, enrollmentStatusCode);
    CommonAccountHelper.addWalmartPlusMembershipViaAstro(caregiverCustomerEmailId);
    caregiverStageId =
            createStageId(caregiverStoreNbr, caregiverPatientId, phoneNbr, refillConfirmationRefType);

    // create dependent data
    dependent1CustomerAccountId =
            CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2019-01-01");
    dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent1PatientId = CommonUtil.generateRandomNumber(9);
    dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent1StoreNbr,
            dependent1PatientId,
            dependent1FirstName,
            dependent1LastName,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependent1CustomerAccountId,
            dependent1StoreNbr,
            dependent1PatientId,
            commonDobDPFormatForLessThan18);
    WCPAddDependentRequest wcpAddDependentRequest =
            CommonAccountHelper.getWCPAddDependentRequest(
                    DependentInfo.TypeEnum.MINOR,
                    DependentInfo.LinkageStatusEnum.ACTIVE,
                    dependent1CustomerAccountId,
                    caregiverCustomerAccountId);
    wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCustomerAccountId);
    createSMSEnrollment(dependent1StoreNbr, dependent1PatientId, phoneNbr, enrollmentStatusCode);
    dependent1StageId =
            createStageId(dependent1StoreNbr, dependent1PatientId, phoneNbr, refillConfirmationRefType);

    // create non-dependent data
    dependent2CustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    smsEnrolledDependentCustomerEmailId);
    dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent2PatientId = CommonUtil.generateRandomNumber(9);
    dependent2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent2StoreNbr,
            dependent2PatientId,
            dependent2FirstName,
            dependent2LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependent2CustomerAccountId,
            dependent2StoreNbr,
            dependent2PatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependent2StoreNbr, dependent2PatientId, phoneNbr, enrollmentStatusCode);
    dependent2StageId =
            createStageId(dependent2StoreNbr, dependent2PatientId, phoneNbr, refillConfirmationRefType);

    // non-dependent for a different phoneNbr
    phoneNbrA = CommonUtil.generateRandomNumber(10);
    dependentAEmailId = CommonUtil.generateRandomEmailId(10);
    dependentAStoreNbr = CommonUtil.generateRandomNumber(6);
    dependentAPatientId = CommonUtil.generateRandomNumber(9);
    dependentAFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependentALastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependentACustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    dependentAEmailId);
    createCPRAccount(
            dependentAStoreNbr,
            dependentAPatientId,
            dependentAFirstName,
            dependentALastName,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            phoneNbrA);
    createPharmacyAccount(
            dependentACustomerAccountId,
            dependentAStoreNbr,
            dependentAPatientId,
            commonDobDPFormatForLessThan18);
    createSMSEnrollment(dependentAStoreNbr, dependentAPatientId, phoneNbrA, enrollmentStatusCode);
    dependentAStageId =
            createStageId(
                    dependentAStoreNbr, dependentAPatientId, phoneNbrA, refillConfirmationRefType);

    // non-dependent for a different phoneNbr
    phoneNbrB = CommonUtil.generateRandomNumber(10);
    dependentBEmailId = CommonUtil.generateRandomEmailId(10);
    dependentBStoreNbr = CommonUtil.generateRandomNumber(6);
    dependentBPatientId = CommonUtil.generateRandomNumber(9);
    dependentBFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependentBLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependentBCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    dependentBEmailId);
    createCPRAccount(
            dependentBStoreNbr,
            dependentBPatientId,
            dependentBFirstName,
            dependentBLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbrB);
    createPharmacyAccount(
            dependentBCustomerAccountId,
            dependentBStoreNbr,
            dependentBPatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependentBStoreNbr, dependentBPatientId, phoneNbrB, enrollmentStatusCode);
    dependentBStageId =
            createStageId(dependentBStoreNbr, dependentBPatientId, phoneNbrB, ciImzReco);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Clean up for all created accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() throws IOException {

    cprProfilesToBeDeletedList.forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                Response<ValidationServiceResponse> response =
                        cprPatientUpdateRetrofit.validateProfile(request);
                if (!(response.code() == 202
                        && response.body() != null
                        && response.body().getErrors().isEmpty())
                        && response.code() != 406) {
                  throw new RuntimeException(
                          "CPR Account failed to update with status code 20708 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });

    pharmacyProfilesToBeDeleted.forEach(
            request -> {
              try {
                Response<ServiceResponse> getOnlineIdentityResp =
                        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                request, domainId, reqIdString, reqTrackingString);

                if (getOnlineIdentityResp.code() == 204) {
                  // If the response is 204, skip the deletion
                  return;
                }

                accountEntityServiceRetrofit.deleteAccountV1(
                        request, domainId, reqIdString, reqTrackingString);

              } catch (IOException e) {
                // Handle the IOException
              }
            });

    dmProfilesToBeDeleted.forEach(
            request -> {
              request.getPreferences().getFirst().setEnrollment_status_code("26805");
              try {
                Response<DMPostPreferencesResponse> response =
                        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(request);
                if (!(response.code() == 200
                        && response.body() != null
                        && response.body().getResponseStatus() != null
                        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
                  throw new RuntimeException(
                          "DM Account failed to update with Enrollment status code 26803 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  private void createPharmacyAccount(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      domainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
        break;
      }
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(dob)
                            .build())
            .build();
  }

  /**
   * Increments failed authentication count for a given storeNbr and patientId
   *
   * @param storeNbr
   * @param patientId
   * @param flowType
   * @throws IOException
   */
  private void createPharmaAuthIncrementFailedAuthenticationForPatientLinks(
          String storeNbr, String patientId, String flowType) throws IOException {
    PharmaAuthPatientIdStoreNbrRequest pharmaAuthPatientIdStoreNbrRequest =
            getCreatePharmaAuthCoolDownStatusRequest(storeNbr, patientId, flowType);
    Response<IsCustomerInCoolDownResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              pharmacyAuthServiceRetrofit.incrementFailedAuthenticationForPatientLinks(
                      pharmaAuthPatientIdStoreNbrRequest);

      if (!(response.code() == 200
              && response.body() != null
              && response.body().getCoolDownStatus() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Pharma Auth increment failed authentication for patient Links failed. HttpStatusCode : "
                          + response.code());
        }
      } else {
        pharmaAuthPatientLinkProfilesToBeDeleted.add(pharmaAuthPatientIdStoreNbrRequest);
        break;
      }
    }
  }

  /**
   * Builds Create Pharma Auth Cool Down Status
   *
   * @param storeNbr
   * @param patientId
   * @param flowType
   * @return
   */
  private PharmaAuthPatientIdStoreNbrRequest getCreatePharmaAuthCoolDownStatusRequest(
          String storeNbr, String patientId, String flowType) {
    return PharmaAuthPatientIdStoreNbrRequest.builder()
            .storeNbr(Integer.parseInt(storeNbr))
            .patientId(Integer.parseInt(patientId))
            .flowName(flowType)
            .build();
  }

  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  private void createCPRAccount(
          String storeNbr,
          String patientId,
          String firstName,
          String lastName,
          String dob,
          String type,
          String phoneNbr)
          throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
        break;
      }
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Deletes cpr account by setting the PatientStatusCode as 20708
   *
   * @param storeNbr
   * @param patientId
   * @param firstName
   * @param lastName
   * @throws IOException
   */
  private void deleteCPRAccount(
          String storeNbr, String patientId, String firstName, String lastName, String dob)
          throws IOException {
    ValidationServiceRequest cprRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprRequest.setPatientId(Integer.parseInt(patientId));
    cprRequest.getPatientInfo().setBirthDate(dob);
    cprRequest.getPatientInfo().setFirstName(firstName);
    cprRequest.getPatientInfo().setLastName(lastName);
    cprRequest.getPatientInfo().setPatientStatusCode(20708);

    // This will try to delete an account in CPR 3 times if account deletion fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account deletion failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // This is needed because CPR account deletion is async, and it usually takes a couple of
    // seconds to reflect account deletion
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Creates SMS Enrollement for a storeNbr and patientId
   *
   * @param storeNbr
   * @param patientId
   * @param notifyValue
   * @param enrollStatusCode
   * @throws IOException
   */
  private static void createSMSEnrollment(
          String storeNbr, String patientId, String notifyValue, String enrollStatusCode)
          throws IOException {

    DMPostPreferencesRequest dmPostPreferencesRequest =
            getDmPostPreferencesRequest(storeNbr, patientId, notifyValue, enrollStatusCode);
    Response<DMPostPreferencesResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getResponseStatus() != null
              && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "DM Post Preference call failure. HttpStatusCode : " + response.code());
        }
      } else {
        dmProfilesToBeDeleted.add(dmPostPreferencesRequest);
        break;
      }
    }
  }

  /**
   * Create DM post preference request (notifyType 1 for phone nbr, 3 for email)
   *
   * @param storeNbr store Nbr
   * @param patientId patientId
   * @param notifyValue phone Number or email Id
   * @param enrollStatusCode 26802 for enrollment, 26803 for unenrollment
   * @return
   */
  private static DMPostPreferencesRequest getDmPostPreferencesRequest(
          String storeNbr, String patientId, String notifyValue, String enrollStatusCode) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    String requestId = String.format("%s-%s", storeNbr, patientId);
    return DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
            .zipCode("96898")
            .userId("SIGPAD")
            .storePhone("8009666546")
            .timeStamp(timestamp)
            .language("101")
            .preferences(
                    org.openjdk.tools.javac.util.List.of(
                            DMPostPreferencesRequest.Preference.builder()
                                    .notification_type("1")
                                    .notification_val(notifyValue)
                                    .short_code_type_id("1")
                                    .enrollment_status_code(enrollStatusCode)
                                    .build()))
            .build();
  }

  private String createWcpGuestAccount(
          String firstName, String lastName, String customerType, String dob) throws Exception {
    WCPCreateGuestAccountRequest wcpCreateGuestAccountRequest =
            getWcpCreateGuestAccountRequest(firstName, lastName, customerType, dob);
    Response<WCPCreateGuestAccountResponse> response = null;

    // Retry up to 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = wcpRetroFit.createGuestAccount(wcpCreateGuestAccountRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && response.body().getStatus() != "OK") {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "WCP Guest account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        break;
      }
    }
    return response.body().getPayload().getCustomerAccountId();
  }

  private static WCPCreateGuestAccountRequest getWcpCreateGuestAccountRequest(
          String firstName, String lastName, String customerType, String dob) {
    return WCPCreateGuestAccountRequest.builder()
            .payload(
                    WCPCreateGuestAccountRequest.Payload.builder()
                            .account(
                                    WCPCreateGuestAccountRequest.Account.builder()
                                            .accountType("GUEST")
                                            .customerType(customerType)
                                            .firstName(firstName)
                                            .lastName(lastName)
                                            .dateOfBirth(dob)
                                            .build())
                            .build())
            .build();
  }

  private static String getInsertFAMQuery(
          String caregiverId,
          String dependentId,
          String onlineStoreNbr,
          String storeNbr,
          String patientId,
          String type) {
    return String.format(
            "INSERT INTO pharmacydb.FAM_REQUEST(CAREGIVER_ID, DEPENDENT_ID, REQUEST_TYPE, ONLINE_STORE_NBR, ADDITIONAL_INFORMATION, CREATE_TS, UPDATE_TS) VALUES ('%s', '%s', '%s', '%s', '{\n"
                    + "    \"storeNbr\": %s,\n"
                    + "    \"patientId\": %s\n"
                    + "}', '2024-01-01', '2024-01-01')",
            caregiverId, dependentId, type, onlineStoreNbr, storeNbr, patientId);
  }

  private static String createStageId(
          String storeNbr, String patientId, String phoneNumber, String refType)
          throws IOException, GeneralSecurityException {

    DMCreateStageIdRequest dmCreateStageIdRequest =
            getDMCreateStageIdRequest(storeNbr, patientId, phoneNumber, refType);
    Response<DMCreateStageIdResponse> response = null;

    // This will try to create a stage id, 3 times if creation fails
    for (int i = 0; i < 3; i++) {
      response = dmStageIDRetrofit.callDMStageIdAPI(dmCreateStageIdRequest);
      if (!(response.code() == 201 && response.body() != null)) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "DM Create Stage Id call failure. HttpStatusCode : " + response.code());
        }
      } else {
        break;
      }
    }
    return response.body().getId();
  }

  private static DMCreateStageIdRequest getDMCreateStageIdRequest(
          String storeNbr, String patientId, String phoneNumber, String refType) {
    DMCreateStageIdRequest.Comms comms =
            DMCreateStageIdRequest.Comms.builder()
                    .patientId(patientId)
                    .phoneNumber(phoneNumber)
                    .storeId(storeNbr)
                    .createTs(String.valueOf(Instant.now().getEpochSecond()))
                    .rxNumber(Collections.emptyList())
                    .build();

    DMCreateStageIdRequest.Payload payload =
            DMCreateStageIdRequest.Payload.builder().comms(comms).build();

    return DMCreateStageIdRequest.builder().refType(refType).payload(payload).build();
  }

  @Test(
          priority = 0,
          description =
                  "Get customer , dependents and sms enrolled info when stage Id PhoneNbr is null, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenStageIdPhoneNbrIsNull()
          throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, true, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE);

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false);
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLinkageStatus());
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getEmailId(),
            smsEnrolledDependentCustomerEmailId);
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertFalse(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks().isEmpty(),
            "PatientLinks should not be empty");
    // Verify PatientLink fields
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks().getFirst().getStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks().getFirst().getPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 1,
          description =
                  "Get customer , dependents and sms enrolled info when stage Id PhoneNbr is equal to customer Enrolled phoneNbr, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenStageIdPhoneNbrIsEqualToCustomerPhoneNbr()
          throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            phoneNbr,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and stage Id PhoneNbr equal to customer Enrolled
    // phoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, phoneNbr, null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false);
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLinkageStatus());
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getEmailId(),
            smsEnrolledDependentCustomerEmailId);
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertFalse(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks().isEmpty(),
            "PatientLinks should not be empty");
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 2,
          description =
                  "Get customer , dependents and sms enrolled info when stage Id PhoneNbr is not equal to customer Enrolled phoneNbr, stage id = null/not present")
  public void
  getCustomerDependentAndSMSEnrolledInfoWhenStageIdPhoneNbrIsNotEqualToCustomerPhoneNbr()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String stageIdPhoneNbr = CommonUtil.generateRandomNumber(10);
    String MINOR = "MINOR";
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            stageIdPhoneNbr,
            reqId,
            reqTrackingId);

    // Step - 1b: Creating test accounts
    String dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent3PatientId = CommonUtil.generateRandomNumber(9);
    String dependent3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent3CustomerAccountId =
            createWcpGuestAccount(
                    dependent3FirstName, dependent3LastName, MINOR, commonDobCPRFormatForLessThan18);
    createCPRAccount(
            dependent3StoreNbr,
            dependent3PatientId,
            dependent3FirstName,
            dependent3LastName,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            stageIdPhoneNbr);
    createPharmacyAccount(
            dependent3CustomerAccountId,
            dependent3StoreNbr,
            dependent3PatientId,
            commonDobDPFormatForLessThan18);
    createSMSEnrollment(
            dependent3StoreNbr, dependent3PatientId, stageIdPhoneNbr, enrollmentStatusCode);

    // Step - 2a: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and stage Id PhoneNbr is not equal to customer
    // Enrolled phoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    stageIdPhoneNbr,
                    null,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 2b: Calling getCustomerInfoV2, getSmsEnrolledProfileListByPhoneNbr,
    // getEnrollmentPreferences, getFamLinks api's for assertion
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    true,
                    false,
                    null,
                    false,
                    false,
                    false,
                    false,
                    false);

    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId, domainId, "DEPENDENT", reqId, reqTrackingId, "ALL");

    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            smsEnrolledProfileListsResponseForCustomerEnrolledPhoneNbr =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    caregiverCustomerAccountId,
                    domainId,
                    phoneNbr,
                    reqId,
                    reqTrackingId,
                    "MINOR,PET,ADULT");

    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            smsEnrolledProfileListsResponseForStageIdPhoneNbr =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    dependent3CustomerAccountId,
                    domainId,
                    stageIdPhoneNbr,
                    reqId,
                    reqTrackingId,
                    "MINOR,PET,ADULT");

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 200, errorMessage);
    Assert.assertEquals(
            smsEnrolledProfileListsResponseForCustomerEnrolledPhoneNbr.code(), 200, errorMessage);
    Assert.assertEquals(
            smsEnrolledProfileListsResponseForStageIdPhoneNbr.code(), 200, errorMessage);

    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 2,
            "Should have 2 SMS enrolled non-dependents: one from stageIdPhoneNbr and one from customer enrolled phone number");
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false);
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLinkageStatus());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertFalse(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks().isEmpty(),
            "PatientLinks should not be empty");
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 3,
          description =
                  "Get customer , dependents and sms enrolled info when coolDown status is not there, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCoolDownStatusIsNull()
          throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false,
            "Customer should not be in cooldown when cooldown status is not present");
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 4,
          description =
                  "Get customer , dependents and sms enrolled info when coolDown status is present, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCoolDownStatusIsPresent()
          throws IOException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating coolDown Status for the patientId and storeNbr by hitting the api for 5
    // times
    for (int i = 0; i < 5; i++) {
      createPharmaAuthIncrementFailedAuthenticationForPatientLinks(
              dependent2StoreNbr, dependent2PatientId, flowType);
    }

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
    
    // CoolDownStatus field assertions (primitive types cannot be null, so assert values instead)
    GetCustomerDependentsAndSmsEnrolledInfoV1Response.CoolDownStatus coolDownStatus =
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus();
    Assert.assertTrue(coolDownStatus.getFailedAttemptsCount() >= 0,
            "Failed attempts count should be non-negative");
    Assert.assertTrue(coolDownStatus.getAttemptsRemaining() >= 0,
            "Attempts remaining should be non-negative");
    Assert.assertTrue(coolDownStatus.getRemainingTime() >= 0,
            "Remaining time should be non-negative");
    
    // Verify isInCooldown is set to true after 5 failed attempts
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), true,
            "Customer should be in cooldown after 5 failed attempts");
  }

  @Test(
          priority = 5,
          description =
                  "Get customer , dependents and sms enrolled info with pending acc creation linkage status, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenPendingAccCreationLinkageStatus()
          throws IOException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating test data
    String dependentCid = CommonUtil.generateRandomEmailId(10);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String type = "PENDING_ACCOUNT_CREATION";

    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createSMSEnrollment(dependentStoreNbr, dependentPatientId, phoneNbr, enrollmentStatusCode);
    accountDbContext.executeInsertQuery(
            getInsertFAMQuery(
                    caregiverCustomerAccountId,
                    dependentCid,
                    wmPharmacyStore,
                    dependentStoreNbr,
                    dependentPatientId,
                    type));

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // smsEnrolledNonDependentsInfo - Verify profile with PENDING_ACCOUNT_CREATION linkage status exists
    Assert.assertTrue(
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .map(GetCustomerDependentsAndSmsEnrolledInfoV1Response.NonDependentInfo::getAuthStoreNbr)
                    .collect(Collectors.toList())
                    .contains(dependentStoreNbr),
            "SMS enrolled non-dependents should contain the dependent store number");
    Assert.assertTrue(
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .map(GetCustomerDependentsAndSmsEnrolledInfoV1Response.NonDependentInfo::getAuthPatientId)
                    .collect(Collectors.toList())
                    .contains(dependentPatientId),
            "SMS enrolled non-dependents should contain the dependent patient ID");

    // Verify the non-dependent with PENDING_ACCOUNT_CREATION has proper linkage status mapping
    Optional<GetCustomerDependentsAndSmsEnrolledInfoV1Response.NonDependentInfo> pendingAccCreationNonDep =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .filter(nd -> dependentStoreNbr.equals(nd.getAuthStoreNbr())
                            && dependentPatientId.equals(nd.getAuthPatientId()))
                    .findFirst();
    Assert.assertTrue(pendingAccCreationNonDep.isPresent(),
            "Non-dependent with PENDING_ACCOUNT_CREATION should be found");
    // Verify fields for the pending account creation non-dependent
    Assert.assertNotNull(pendingAccCreationNonDep.get().getFirstName());
    Assert.assertNotNull(pendingAccCreationNonDep.get().getLastName());
    Assert.assertNotNull(pendingAccCreationNonDep.get().getPatientLinks());
    Assert.assertFalse(pendingAccCreationNonDep.get().getPatientLinks().isEmpty(),
            "Patient links should not be empty");
  }

  @Test(
          priority = 6,
          description =
                  "Get customer , dependents and sms enrolled info with pending linkage status, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenPendingLinkageStatus() throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating test data
    String emailId = CommonUtil.generateRandomEmailId(10);
    String dependentCid =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String type = "PENDING";

    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createSMSEnrollment(dependentStoreNbr, dependentPatientId, phoneNbr, enrollmentStatusCode);
    createPharmacyAccount(
            dependentCid, dependentStoreNbr, dependentPatientId, commonDobDPFormatForOlderThan18);
    accountDbContext.executeInsertQuery(
            getInsertFAMQuery(
                    caregiverCustomerAccountId,
                    dependentCid,
                    wmPharmacyStore,
                    dependentStoreNbr,
                    dependentPatientId,
                    type));

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // smsEnrolledNonDependentsInfo - Verify profile with PENDING linkage status exists
    Assert.assertTrue(
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .map(GetCustomerDependentsAndSmsEnrolledInfoV1Response.NonDependentInfo::getCustomerAccountId)
                    .collect(Collectors.toList())
                    .contains(dependentCid),
            "SMS enrolled non-dependents should contain the dependent customer account ID");

    // Find the non-dependent with PENDING linkage status and verify its properties
    Optional<GetCustomerDependentsAndSmsEnrolledInfoV1Response.NonDependentInfo> pendingNonDep =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .filter(nd -> dependentCid.equals(nd.getCustomerAccountId()))
                    .findFirst();
    Assert.assertTrue(pendingNonDep.isPresent(),
            "Non-dependent with PENDING linkage status should be found");
    Assert.assertNotNull(pendingNonDep.get().getFirstName());
    Assert.assertNotNull(pendingNonDep.get().getLastName());
    Assert.assertNotNull(pendingNonDep.get().getAuthStoreNbr());
    Assert.assertNotNull(pendingNonDep.get().getAuthPatientId());
    Assert.assertNotNull(pendingNonDep.get().getPatientLinks());
    Assert.assertFalse(pendingNonDep.get().getPatientLinks().isEmpty(),
            "Patient links should not be empty");
  }

  @Test(
          priority = 7,
          description =
                  "Get customer , dependents and sms enrolled info with rejected linkage status, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenRejectedLinkageStatus() throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating test data
    String emailId = CommonUtil.generateRandomEmailId(10);
    String dependentCid =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependentCid, dependentStoreNbr, dependentPatientId, commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependentStoreNbr, dependentPatientId, phoneNbr, enrollmentStatusCode);

    WCPAddDependentRequest wcpAddDependentRequest =
            CommonAccountHelper.getWCPAddDependentRequest(
                    DependentInfo.TypeEnum.ADULT,
                    DependentInfo.LinkageStatusEnum.REJECTED,
                    dependentCid,
                    caregiverCustomerAccountId);
    wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCustomerAccountId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // smsEnrolledNonDependentsInfo
    response.getDependentsInfo().stream()
            .map(GetCustomerDependentsAndSmsEnrolledInfoV1Response.DependentInfo::getCustomerAccountId)
            .collect(Collectors.toList())
            .contains(dependentCid);
    response.getDependentsInfo().stream()
            .map(GetCustomerDependentsAndSmsEnrolledInfoV1Response.DependentInfo::getType)
            .collect(Collectors.toList())
            .contains(DependentInfo.LinkageStatusEnum.REJECTED.getValue());
  }

  @Test(
          priority = 8,
          description =
                  "Get customer , dependents and sms enrolled info when invalid stageIdPhoneNbr or invalid domainId, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoForInvalidCases() throws IOException {

    // ***** CASE 1 - DomainId is invalid *****

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    logAccountDetails(
            invalidDomainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,invalid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, invalidDomainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");

    // ***** CASE 2 - stageIdPhoneNbr is of invalid length *****

    // Step - 1b: Creating invalid StageIdPhoneNbr
    String invalidStageIdPhoneNbr = CommonUtil.generateRandomNumber(9);
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            invalidStageIdPhoneNbr,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,and invalid stageIdPhoneNbr
    getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    invalidStageIdPhoneNbr,
                    null,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
  }

  @Test(
          priority = 9,
          description =
                  "Get customer , dependents and sms enrolled info when customer is not sms enrolled, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCustomerIsNotSmsEnrolled()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    String phoneNbr = CommonUtil.generateRandomNumber(10);
    String emailId = CommonUtil.generateRandomEmailId(10);
    String caregiverCustomerAccountId1 =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);
    String caregiver2StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver2PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver2StoreNbr,
            caregiver2PatientId,
            caregiver2FirstName,
            caregiver2LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            caregiverCustomerAccountId1,
            caregiver2StoreNbr,
            caregiver2PatientId,
            commonDobDPFormatForOlderThan18);
    logAccountDetails(
            domainId,
            caregiver2StoreNbr,
            caregiver2PatientId,
            caregiverCustomerAccountId1,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId1 ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId1, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver2FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver2LastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId1);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 0);

    // smsEnrolledNonDependentsInfo
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 0);
  }

  @Test(
          priority = 10,
          description =
                  "Get customer , dependents and sms enrolled info when customer profile is not in ocp, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCustomerProfileIsNotInOCP()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    String emailId = CommonUtil.generateRandomEmailId(10);
    String caregiverCustomerAccountId2 =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);
    logAccountDetails(
            domainId, null, null, caregiverCustomerAccountId2, null, null, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId2, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 204, errorMessage);
  }

  @Test(
          priority = 11,
          description =
                  "Get customer , dependents and sms enrolled info when loggedIn user account not in CPR, stage id = null/not present")
  public void getCustomerDependentAndSMSEnrolledInfoWhenCustomerProfileNotInCPR() throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data
    String caregiver3emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver3CustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    caregiver3emailId);
    String caregiver3StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver3PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3FirstName,
            caregiver3LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            caregiver3CustomerAccountId,
            caregiver3StoreNbr,
            caregiver3PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: delete the caregiver account from cpr
    deleteCPRAccount(
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3FirstName,
            caregiver3LastName,
            commonDobCPRFormatForOlderThan18);

    logAccountDetails(
            domainId,
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3CustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiver3CustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 404, errorMessage);
  }

  @Test(
          priority = 12,
          description =
                  "Get customer , dependents and sms enrolled info when stage id = present, flowType = valid(refill-confirmation-sms), stageIdPhoneNbr= null or not present")
  public void
  getCustomerDependentAndSMSEnrolledInfoWhenStageIdIsPresentAndValidRefillConfirmationAndStageIdPhoneNbrIsNullOrNotPresent()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbrA,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr and dependentAStageId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    null,
                    dependentAStageId,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo - Should only contain profiles from stageId phone (stageId flow skips customer enrolled phone comparison)
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 1,
            "Should have 1 SMS enrolled non-dependent from stageId phone when stageId is provided");
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false,
            "Customer should not be in cooldown");
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 13,
          description =
                  "Get customer , dependents and sms enrolled info when stage id = present, flowType = invalid, stageIdPhoneNbr= null or not present")
  public void
  getCustomerDependentAndSMSEnrolledInfoWhenStageIdIsPresentAndInValidAndStageIdPhoneNbrIsNullOrNotPresent()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    String phoneNbrB = CommonUtil.generateRandomNumber(10);
    String dependentBEmailId = CommonUtil.generateRandomEmailId(10);
    String dependentBStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentBPatientId = CommonUtil.generateRandomNumber(9);
    String dependentBFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentBLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentBCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    dependentBEmailId);
    String invalidType = "imz-reco";
    createCPRAccount(
            dependentBStoreNbr,
            dependentBPatientId,
            dependentBFirstName,
            dependentBLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbrB);
    createPharmacyAccount(
            dependentBCustomerAccountId,
            dependentBStoreNbr,
            dependentBPatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependentBStoreNbr, dependentBPatientId, phoneNbrB, enrollmentStatusCode);
    String dependentBStageId =
            createStageId(dependentBStoreNbr, dependentBPatientId, phoneNbrB, invalidType);

    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbrA,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr and dependentBStageId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    null,
                    dependentBStageId,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 400, errorMessage);
  }

  @Test(
          priority = 14,
          description =
                  "Get customer , dependents and sms enrolled info when stage id = present, flowType = valid(ci-imz-reco), stageIdPhoneNbr= null or not present")
  public void
  getCustomerDependentAndSMSEnrolledInfoWhenStageIdIsPresentAndInValidCiImzRecoAndStageIdPhoneNbrIsNullOrNotPresent()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbrB,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and null stageIdPhoneNbr and dependentBStageId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    null,
                    dependentBStageId,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response to the GetCustomerDependentsAndSmsEnrolledInfoV1Response class
    // so that we can assert
    // GetCustomerDependentsAndSmsEnrolledInfoV1
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());

    // customerInfo
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());

    // dependentsInfo
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getDependentsInfo().getFirst().getAddressInfo());

    // smsEnrolledNonDependentsInfo - Should contain profiles from ci-imz-reco stageId phone
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 1,
            "Should have 1 SMS enrolled non-dependent from ci-imz-reco stageId phone");
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getFirstName());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getLastName());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthStoreNbr());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAuthPatientId());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getPatientLinks());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getType());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getGender());
    Assert.assertNotNull(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getValidationToken(),
            "Validation token should be present for non-dependent SMS enrolled profiles");
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getIsInCooldown(), false,
            "Customer should not be in cooldown");
    Assert.assertNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getCoolDownStatus());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getDob());
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo().getFirst().getAddressInfo());
  }

  @Test(
          priority = 15,
          description =
                  "Get customer , dependents and sms enrolled info when stage id = present but not present in DM(404)")
  public void getCustomerDependentAndSMSEnrolledInfoWhenStageIdIsPresentAndDM404()
          throws Exception {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidStageId =
            "bm1XN1l3YTltbEt2OTA0ejVzR0piall3S0Z4eWZOUE9qd0JjWlJBcmVHbUtaK3VaWjlzRmt6SnUvUUZHUWxmUCxFRmUzNkhmYm1HVUZDbi9IcUVIcmJ3PT0=";
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and invalidStageId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    "",
                    invalidStageId,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 404);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-24004");
  }

  @Test(
          priority = 16,
          description =
                  "Get customer , dependents and sms enrolled info when stage id = present but invalid DM(404)")
  public void getCustomerDependentAndSMSEnrolledInfoWhenStageIdIsPresentAndDM400()
          throws Exception {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String randomStageId = RandomStringUtils.randomAlphanumeric(20);
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with a valid
    // caregiverCustomerAccountId ,valid domainId and randomStageId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    "",
                    randomStageId,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 400);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-24002");
  }

  @Test(
          priority = 17,
          description = "Get customer, dependents and sms enrolled info with APPROVED linkage status")
  public void getCustomerDependentAndSMSEnrolledInfoWhenApprovedLinkageStatus() throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating test data with APPROVED linkage status
    String emailId = CommonUtil.generateRandomEmailId(10);
    String dependentCid =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();

    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createPharmacyAccount(
            dependentCid, dependentStoreNbr, dependentPatientId, commonDobDPFormatForOlderThan18);
    createSMSEnrollment(dependentStoreNbr, dependentPatientId, phoneNbr, enrollmentStatusCode);

    // Adding dependent with APPROVED linkage status
    WCPAddDependentRequest wcpAddDependentRequest =
            CommonAccountHelper.getWCPAddDependentRequest(
                    DependentInfo.TypeEnum.ADULT,
                    DependentInfo.LinkageStatusEnum.ACTIVE,
                    dependentCid,
                    caregiverCustomerAccountId);
    wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCustomerAccountId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNotNull(response.getDependentsInfo());

    // Verify dependent with APPROVED status is in dependentsInfo, not in
    // smsEnrolledNonDependentsInfo
    boolean foundInDependents =
            response.getDependentsInfo().stream()
                    .anyMatch(d -> dependentCid.equals(d.getCustomerAccountId()));
    Assert.assertTrue(
            foundInDependents, "Dependent with APPROVED status should be in dependentsInfo");

    boolean foundInNonDependents =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .anyMatch(nd -> dependentCid.equals(nd.getCustomerAccountId()));
    Assert.assertFalse(
            foundInNonDependents, "APPROVED dependent should NOT be in smsEnrolledNonDependentsInfo");
  }

  @Test(
          priority = 18,
          description =
                  "Get customer, dependents and sms enrolled info when both stageId and stageIdPhoneNbr are provided (stageId takes precedence)")
  public void getCustomerDependentAndSMSEnrolledInfoWhenBothStageIdAndStageIdPhoneNbrProvided()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String differentPhoneNbr = CommonUtil.generateRandomNumber(10);
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbrA,
            differentPhoneNbr,
            reqId,
            reqTrackingId);

    // Step - 2: Calling API with BOTH stageId AND stageIdPhoneNbr - stageId should take precedence
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    differentPhoneNbr, // This should be ignored
                    dependentAStageId, // This should take precedence
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response - should return profiles based on stageId phone, not
    // stageIdPhoneNbr
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(response.getSmsEnrolledNonDependentsInfo());
    // Should have profiles for phoneNbrA (from stageId), not differentPhoneNbr
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 1);
  }

  @Test(
          priority = 19,
          description =
                  "Get customer, dependents and sms enrolled info verifying correct customer filtering from SMS enrolled profiles")
  public void getCustomerDependentAndSMSEnrolledInfoVerifyCorrectFiltering()
          throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            phoneNbr,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse
    // The caregiver and dependent1 are SMS enrolled on the same phoneNbr
    // They should NOT appear in smsEnrolledNonDependentsInfo
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, phoneNbr, null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);

    // Verify caregiver is NOT in smsEnrolledNonDependentsInfo (should be filtered as logged-in
    // customer)
    boolean caregiverInNonDependents =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .anyMatch(nd -> caregiverCustomerAccountId.equals(nd.getCustomerAccountId()));
    Assert.assertFalse(
            caregiverInNonDependents,
            "Logged-in customer should NOT be in smsEnrolledNonDependentsInfo");

    // Verify dependent1 is NOT in smsEnrolledNonDependentsInfo (should be filtered as dependent)
    boolean dependent1InNonDependents =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .anyMatch(nd -> dependent1CustomerAccountId.equals(nd.getCustomerAccountId()));
    Assert.assertFalse(
            dependent1InNonDependents, "Dependent should NOT be in smsEnrolledNonDependentsInfo");

    // Verify dependent2 (non-dependent) IS in smsEnrolledNonDependentsInfo
    boolean dependent2InNonDependents =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .anyMatch(nd -> dependent2CustomerAccountId.equals(nd.getCustomerAccountId()));
    Assert.assertTrue(
            dependent2InNonDependents,
            "Non-dependent SMS enrolled user should be in smsEnrolledNonDependentsInfo");
  }

  @Test(
          priority = 20,
          description =
                  "Get customer, dependents and sms enrolled info with stageIdPhoneNbr having longer invalid length")
  public void getCustomerDependentAndSMSEnrolledInfoWhenStageIdPhoneNbrHasLongerInvalidLength()
          throws IOException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating invalid StageIdPhoneNbr with length > 10
    String invalidStageIdPhoneNbr = CommonUtil.generateRandomNumber(15);
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            invalidStageIdPhoneNbr,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse with invalid
    // stageIdPhoneNbr
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId,
                    domainId,
                    invalidStageIdPhoneNbr,
                    null,
                    false,
                    reqId,
                    reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
            CommonUtil.getErrorResponse(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
  }

  @Test(
          priority = 21,
          description =
                  "Get customer, dependents and sms enrolled info when customer has no dependents but has SMS enrolled non-dependents")
  public void getCustomerDependentAndSMSEnrolledInfoWhenNoDependentsButHasSmsEnrolledNonDependents()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts - a caregiver with no dependents
    String noDepsPhoneNbr = CommonUtil.generateRandomNumber(10);
    String noDepsEmailId = CommonUtil.generateRandomEmailId(10);
    String noDepsCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    noDepsEmailId);
    String noDepsStoreNbr = CommonUtil.generateRandomNumber(6);
    String noDepsPatientId = CommonUtil.generateRandomNumber(9);
    String noDepsFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String noDepsLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            noDepsStoreNbr,
            noDepsPatientId,
            noDepsFirstName,
            noDepsLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            noDepsPhoneNbr);
    createPharmacyAccount(
            noDepsCustomerAccountId, noDepsStoreNbr, noDepsPatientId, commonDobDPFormatForOlderThan18);
    createSMSEnrollment(noDepsStoreNbr, noDepsPatientId, noDepsPhoneNbr, enrollmentStatusCode);

    // Create another profile enrolled on same phone (non-dependent)
    String nonDepEmailId = CommonUtil.generateRandomEmailId(10);
    String nonDepCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    nonDepEmailId);
    String nonDepStoreNbr = CommonUtil.generateRandomNumber(6);
    String nonDepPatientId = CommonUtil.generateRandomNumber(9);
    String nonDepFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String nonDepLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            nonDepStoreNbr,
            nonDepPatientId,
            nonDepFirstName,
            nonDepLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            noDepsPhoneNbr);
    createPharmacyAccount(
            nonDepCustomerAccountId, nonDepStoreNbr, nonDepPatientId, commonDobDPFormatForOlderThan18);
    createSMSEnrollment(nonDepStoreNbr, nonDepPatientId, noDepsPhoneNbr, enrollmentStatusCode);

    logAccountDetails(
            domainId,
            noDepsStoreNbr,
            noDepsPatientId,
            noDepsCustomerAccountId,
            noDepsPhoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    noDepsCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertEquals(response.getCustomerInfo().getCustomerAccountId(), noDepsCustomerAccountId);

    // Should have empty dependentsInfo
    Assert.assertTrue(response.getDependentsInfo().isEmpty(), "DependentsInfo should be empty");

    // Should have SMS enrolled non-dependents
    Assert.assertFalse(
            response.getSmsEnrolledNonDependentsInfo().isEmpty(),
            "SmsEnrolledNonDependentsInfo should NOT be empty");
    Assert.assertEquals(response.getSmsEnrolledNonDependentsInfo().size(), 1);
    Assert.assertEquals(
            response.getSmsEnrolledNonDependentsInfo().getFirst().getCustomerAccountId(),
            nonDepCustomerAccountId);
  }

  @Test(
          priority = 22,
          description =
                  "Get customer, dependents and sms enrolled info when customer has dependents but no SMS enrolled non-dependents")
  public void getCustomerDependentAndSMSEnrolledInfoWhenHasDependentsButNoSmsEnrolledNonDependents()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts - a caregiver with dependent but different phone
    String isolatedPhoneNbr = CommonUtil.generateRandomNumber(10);
    String isolatedEmailId = CommonUtil.generateRandomEmailId(10);
    String isolatedCustomerAccountId =
            CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    isolatedEmailId);
    String isolatedStoreNbr = CommonUtil.generateRandomNumber(6);
    String isolatedPatientId = CommonUtil.generateRandomNumber(9);
    String isolatedFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String isolatedLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            isolatedStoreNbr,
            isolatedPatientId,
            isolatedFirstName,
            isolatedLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            isolatedPhoneNbr);
    createPharmacyAccount(
            isolatedCustomerAccountId,
            isolatedStoreNbr,
            isolatedPatientId,
            commonDobDPFormatForOlderThan18);
    createSMSEnrollment(
            isolatedStoreNbr, isolatedPatientId, isolatedPhoneNbr, enrollmentStatusCode);

    // Create a dependent enrolled on the same phone
    String isolatedDepCustomerAccountId =
            CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2019-01-01");
    String isolatedDepStoreNbr = CommonUtil.generateRandomNumber(6);
    String isolatedDepPatientId = CommonUtil.generateRandomNumber(9);
    String isolatedDepFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String isolatedDepLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            isolatedDepStoreNbr,
            isolatedDepPatientId,
            isolatedDepFirstName,
            isolatedDepLastName,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            isolatedPhoneNbr);
    createPharmacyAccount(
            isolatedDepCustomerAccountId,
            isolatedDepStoreNbr,
            isolatedDepPatientId,
            commonDobDPFormatForLessThan18);
    createSMSEnrollment(
            isolatedDepStoreNbr, isolatedDepPatientId, isolatedPhoneNbr, enrollmentStatusCode);

    // Add as dependent
    WCPAddDependentRequest wcpAddDependentRequest =
            CommonAccountHelper.getWCPAddDependentRequest(
                    DependentInfo.TypeEnum.MINOR,
                    DependentInfo.LinkageStatusEnum.ACTIVE,
                    isolatedDepCustomerAccountId,
                    isolatedCustomerAccountId);
    wcpRetroFit.addDependent(wcpAddDependentRequest, isolatedCustomerAccountId);

    logAccountDetails(
            domainId,
            isolatedStoreNbr,
            isolatedPatientId,
            isolatedCustomerAccountId,
            isolatedPhoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    isolatedCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), isolatedCustomerAccountId);

    // Should have dependentsInfo
    Assert.assertFalse(
            response.getDependentsInfo().isEmpty(), "DependentsInfo should NOT be empty");
    Assert.assertEquals(response.getDependentsInfo().size(), 1);

    // Should have empty SMS enrolled non-dependents (dependent filtered out)
    Assert.assertTrue(
            response.getSmsEnrolledNonDependentsInfo().isEmpty(),
            "SmsEnrolledNonDependentsInfo should be empty since only the dependent is enrolled on same phone");
  }

  @Test(
          priority = 23,
          description =
                  "Get customer, dependents and sms enrolled info verifying uniqueId based linkage status mapping for non-dependents without customerAccountId")
  public void getCustomerDependentAndSMSEnrolledInfoVerifyUniqueIdBasedLinkageStatusMapping()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            phoneNbr,
            null,
            reqId,
            reqTrackingId);

    // Step - 1b: creating test data with PENDING_ACCOUNT_CREATION (no customerAccountId)
    String dependentCid = CommonUtil.generateRandomEmailId(10);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String type = "PENDING_ACCOUNT_CREATION";

    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            phoneNbr);
    createSMSEnrollment(dependentStoreNbr, dependentPatientId, phoneNbr, enrollmentStatusCode);
    accountDbContext.executeInsertQuery(
            getInsertFAMQuery(
                    caregiverCustomerAccountId,
                    dependentCid,
                    wmPharmacyStore,
                    dependentStoreNbr,
                    dependentPatientId,
                    type));

    // Step - 2: Calling getCustomerDependentsAndSmsEnrolledInfoResponse
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerDependentsAndSmsEnrolledInfoResponse =
            accountOrchestratorRetrofit.getCustomerDependentsAndSmsEnrolledInfoV1(
                    caregiverCustomerAccountId, domainId, "", null, false, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
            CommonUtil.buildErrorMessage(gson, getCustomerDependentsAndSmsEnrolledInfoResponse);

    // Step - 4: Parsing the response
    GetCustomerDependentsAndSmsEnrolledInfoV1Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getCustomerDependentsAndSmsEnrolledInfoResponse.body().getPayload()),
                    GetCustomerDependentsAndSmsEnrolledInfoV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerDependentsAndSmsEnrolledInfoResponse.code(), 200, errorMessage);

    // Find the non-dependent by storeNbr and patientId
    boolean found =
            response.getSmsEnrolledNonDependentsInfo().stream()
                    .anyMatch(
                            nd ->
                                    dependentStoreNbr.equals(nd.getAuthStoreNbr())
                                            && dependentPatientId.equals(nd.getAuthPatientId()));
    Assert.assertTrue(found, "Non-dependent with PENDING_ACCOUNT_CREATION should be found");

    // Verify linkage status is mapped via uniqueId
    response.getSmsEnrolledNonDependentsInfo().stream()
            .filter(
                    nd ->
                            dependentStoreNbr.equals(nd.getAuthStoreNbr())
                                    && dependentPatientId.equals(nd.getAuthPatientId()))
            .findFirst()
            .ifPresent(
                    nd ->
                            Assert.assertNotNull(
                                    nd.getLinkageStatus(),
                                    "Linkage status should be mapped via uniqueId for non-dependents without customerAccountId"));
  }

  private void logAccountDetails(
          String domainId,
          String storeNumber,
          String patientId,
          String caregiverCustomerAccountId,
          String customerPhoneNbr,
          String stagePhoneNbr,
          String reqId,
          String reqTrackingId) {
    Reporter.logJSON("domain Id", domainId);
    Reporter.logJSON("Store nbr", storeNumber);
    Reporter.logJSON("Patient Id", patientId);
    Reporter.logJSON("Caregiver Customer Account Id", caregiverCustomerAccountId);
    Reporter.logJSON("Customer Enrolled Phone Nbr", customerPhoneNbr);
    Reporter.logJSON("Stage Id Phone Nbr", stagePhoneNbr);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
