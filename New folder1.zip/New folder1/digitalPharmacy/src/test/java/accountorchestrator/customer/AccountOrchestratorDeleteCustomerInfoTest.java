package accountorchestrator.customer;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.DeleteCustomerInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;


public class AccountOrchestratorDeleteCustomerInfoTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String accountCreationSource = "idVerification";
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private final ObjectMapper mapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();
    private String customerEmailId = null;
    private String customerAccountId = null;
    private String storeNbr = null;
    private String patientId = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String firstName = null;
    private String lastName = null;
    private String HUMAN = "HUMAN";
    private String trackID = CommonUtil.randomUUID();
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

        customerEmailId = CommonUtil.generateRandomEmailId(10);

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        // Create test account
        storeNbr = "9928";
        patientId = CommonUtil.generateRandomNumber(9);
        firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                customerEmailId, commonPassword, commonPhoneNo, firstName, lastName, trackID);
        createCPRAccount(
                storeNbr,
                patientId,
                firstName,
                lastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                customerAccountId,
                storeNbr,
                patientId,
                commonDobDPFormatForOlderThan18);
    }

    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                    } catch (IOException e) {
                    }
                });

        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                    }
                });
    }

    private void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                CreatePharmacyAccountV1Request.builder()
                        .accountCreationSource(accountCreationSource)
                        .customerInfo(
                                CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                        .storeNbr(commonStoreNbr)
                                        .patientId(commonPatientId)
                                        .dob(dob)
                                        .build())
                        .build();
        Response<ServiceResponse> response = null;

        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
            }
            break;
        }
    }

    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(
            priority = 1,
            description = "Delete primary address - should fail (not permitted)")
    public void deletePrimaryAddressFailure() throws IOException {

        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request updateRequest =
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.builder()
                        .address(
                                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.Address.builder()
                                        .addressLine1("123 Main St")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75201")
                                        .type("primary")
                                        .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(customerAccountId, domainId, updateRequest);
        Assert.assertEquals(updateResponse.code(), 200);

        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("123 Main St")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75201")
                                        .type("primary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("Primary address cannot be deleted")
                        || errorMessage.contains("primary address cannot be deleted"),
                "Error message should indicate that primary address cannot be deleted");
    }

    @Test(
            priority = 2,
            description = "Delete secondary address - success (when flag enabled)")
    public void deleteSecondaryAddressSuccess() throws IOException, InterruptedException {

        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request updateRequest =
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.builder()
                        .address(
                                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.Address.builder()
                                        .addressLine1("456 Secondary St")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75202")
                                        .type("secondary")
                                        .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(customerAccountId, domainId, updateRequest);
        Assert.assertEquals(updateResponse.code(), 200);
        Thread.sleep(60000);

        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("456 Secondary St")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75202")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Assert.assertEquals(deleteResponse.code(), 200);
    }

    @Test(
            priority = 3,
            description = "Delete both emergency contact and address - success")
    public void deleteBothEmergencyContactAndAddressSuccess() throws IOException, InterruptedException {
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request updateRequest =
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("Jane")
                                        .lastName("Smith")
                                        .gender("F")
                                        .dob("02021991")
                                        .phoneNbr("5559876543")
                                        .relationshipType("PARENT")
                                        .build()))
                        .address(
                                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.Address.builder()
                                        .addressLine1("789 Test Ave")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75203")
                                        .type("secondary")
                                        .build())
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(customerAccountId, domainId, updateRequest);
        Assert.assertEquals(updateResponse.code(), 200);
        Thread.sleep(60000);

        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("Jane")
                                        .lastName("Smith")
                                        .phoneNbr("5559876543")
                                        .relationshipType("PARENT")
                                        .build()))
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("789 Test Ave")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75203")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Assert.assertEquals(deleteResponse.code(), 200);
    }

    @Test(
            priority = 4,
            description = "Delete customer info with empty request - should fail")
    public void deleteCustomerInfoFailureWhenEmptyRequest() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
    }

    @Test(
            priority = 5,
            description = "Delete customer info with invalid customerAccountId - should fail")
    public void deleteCustomerInfoFailureWhenInvalidCustomerAccountId() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("John")
                                        .lastName("Doe")
                                        .phoneNbr("5551234567")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(UUID.randomUUID().toString(), domainId, deleteRequest);

        Assert.assertEquals(deleteResponse.code(), 204);
    }

    @Test(
            priority = 6,
            description = "Delete customer info with invalid domainId - should fail")
    public void deleteCustomerInfoFailureWhenInvalidDomainId() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("John")
                                        .lastName("Doe")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, "INVALID", deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
    }

    @Test(
            priority = 7,
            description = "Delete emergency contact that doesn't exist - should fail")
    public void deleteEmergencyContactFailureWhenNotExists() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("NonExistent")
                                        .lastName("Person")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
    }

    @Test(
            priority = 8,
            description = "Delete address that doesn't exist - should fail")
    public void deleteAddressFailureWhenNotExists() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("NonExistent Address")
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75201")
                                        .type("primary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
    }
    @Test(
            priority = 9,
            description = "Delete emergency contact separately - success")
    public void deleteEmergencyContactSuccess() throws IOException, InterruptedException {

        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request updateRequest =
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("Emergency")
                                        .lastName("Contact")
                                        .gender("M")
                                        .dob("01011990")
                                        .phoneNbr("5551112222")
                                        .relationshipType("FRIEND")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> updateResponse =
                accountOrchestratorRetrofit.updateCustomerInfo(customerAccountId, domainId, updateRequest);
        Assert.assertEquals(updateResponse.code(), 200);
        Thread.sleep(60000);

        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("Emergency")
                                        .lastName("Contact")
                                        .phoneNbr("5551112222")
                                        .relationshipType("FRIEND")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Assert.assertEquals(deleteResponse.code(), 200);
    }

    @Test(
            priority = 10,
            description = "Delete emergency contact without firstName - should fail")
    public void deleteEmergencyContactFailureWhenFirstNameMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .lastName("Doe")
                                        .phoneNbr("5551234567")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("firstName is required for emergency contact deletion"),
                "Error message should indicate that firstName is required");
    }

    @Test(
            priority = 11,
            description = "Delete emergency contact without lastName - should fail")
    public void deleteEmergencyContactFailureWhenLastNameMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("John")
                                        .phoneNbr("5551234567")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("lastName is required for emergency contact deletion"),
                "Error message should indicate that lastName is required");
    }

    @Test(
            priority = 12,
            description = "Delete emergency contact without relationshipType - should fail")
    public void deleteEmergencyContactFailureWhenRelationshipTypeMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("John")
                                        .lastName("Doe")
                                        .phoneNbr("5551234567")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("relationshipType is required for emergency contact deletion"),
                "Error message should indicate that relationshipType is required");
    }

    @Test(
            priority = 13,
            description = "Delete emergency contact without phoneNbr - should fail")
    public void deleteEmergencyContactFailureWhenPhoneNbrMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .emergencyContactInfo(Arrays.asList(
                                DeleteCustomerInfoV1Request.EmergencyContactInfo.builder()
                                        .firstName("John")
                                        .lastName("Doe")
                                        .relationshipType("SPOUSE")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("phoneNbr is required for emergency contact deletion"),
                "Error message should indicate that phoneNbr is required");
    }

    @Test(
            priority = 14,
            description = "Delete address without addressLine1 - should fail")
    public void deleteAddressFailureWhenAddressLine1Missing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .city("Dallas")
                                        .state("TX")
                                        .zipCode("75201")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("addressLine1 is required for address deletion"),
                "Error message should indicate that addressLine1 is required");
    }

    @Test(
            priority = 15,
            description = "Delete address without city - should fail")
    public void deleteAddressFailureWhenCityMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("123 Main St")
                                        .state("TX")
                                        .zipCode("75201")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("city is required for address deletion"),
                "Error message should indicate that city is required");
    }

    @Test(
            priority = 16,
            description = "Delete address without state - should fail")
    public void deleteAddressFailureWhenStateMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("123 Main St")
                                        .city("Dallas")
                                        .zipCode("75201")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("state is required for address deletion"),
                "Error message should indicate that state is required");
    }

    @Test(
            priority = 17,
            description = "Delete address without zipCode - should fail")
    public void deleteAddressFailureWhenZipCodeMissing() throws IOException {
        DeleteCustomerInfoV1Request deleteRequest =
                DeleteCustomerInfoV1Request.builder()
                        .address(Arrays.asList(
                                DeleteCustomerInfoV1Request.Address.builder()
                                        .addressLine1("123 Main St")
                                        .city("Dallas")
                                        .state("TX")
                                        .type("secondary")
                                        .build()))
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> deleteResponse =
                accountOrchestratorRetrofit.deleteCustomerInfo(customerAccountId, domainId, deleteRequest);

        Error errorResponse = CommonUtil.getErrorResponse(gson, deleteResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
        Assert.assertEquals(deleteResponse.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("zipCode is required for address deletion"),
                "Error message should indicate that zipCode is required");
    }
}