package accountorchestrator.customer.createAccount;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CreateAccountByRxV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.CreateAccountByRxV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.iap.restapi.IAPRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.iap.restapi.models.IAPUserIdentityVerificationsRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class AccountOrchestratorCreateAccountByRxTest {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private WCPRetroFit wcpRetroFit;
  private IAPRetrofit iapRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private  String reqIdString = "req-id-";
  private  String reqTrackingString = "req-tracking-";
  private  String domainId = "WM-PHARMACY";

  private  String customerAccountId = "e7434ff8-95fb-4b82-b897-a54c5db05c25";

  String trackID, reqId, reqTrackingId = null;

  String customerAccountIdWithIdNotVerified;
  private final ObjectMapper mapper = new ObjectMapper();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    iapRetrofit = new IAPRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    pharmacyAuthServiceRetrofit = new PharmacyAuthServiceRetrofit();

    customerAccountIdWithIdNotVerified = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName("raone.kamal421@wmt.com");

    //  Setting and logging tracking IDs to make the respective calls
     trackID = CommonUtil.randomUUID();
     reqId = reqIdString + trackID;
     reqTrackingId = reqTrackingString + trackID;

    accountEntityServiceRetrofit.deleteAccountV1(customerAccountId,domainId,reqId,reqTrackingId);
    pharmacyAuthServiceRetrofit.resetFailedAuthentication(customerAccountId);
  }

  @Test(priority = 0,
          description = "ID Not verified case")
  public void createAccountByRxIdNotVerified() throws IOException {

    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
            reqId,reqTrackingId, storeNbr, rxNbr, customerAccountIdWithIdNotVerified);

    // Call createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
            domainId,
            createAccountByRxV1Request
            ,customerAccountIdWithIdNotVerified
            ,reqId
            ,reqTrackingId);

    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(createAccountByRxResponse.code(),400,errorMessage);
    Assert.assertEquals(errorResponse.getCode(),"DPR-DPACCOR-1034");
    Assert.assertTrue(errorResponse.getMessage().contains("ID not verified for given customerAccountId. " + customerAccountIdWithIdNotVerified));
  }

  @Test(priority = 1,
      description = "Success scenario for createAccountByRx")
  public void createAccountByRxSuccess() throws IOException, GeneralSecurityException {

    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
        reqId, reqTrackingId, storeNbr, rxNbr, customerAccountId);

    // Writing in IAP to make it ID verified
    IAPUserIdentityVerificationsRequest iapWriteRequest = mapper.readValue(new File("src/test/resources/testdata/digitalpharmacy/iap/IAPWriteRequest.json"),IAPUserIdentityVerificationsRequest.class);
    iapWriteRequest.setCustomerId(customerAccountId);
    iapRetrofit.callIAPUserIdentityVerificationsAPI(iapWriteRequest);

    // Calling createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
        domainId,
        createAccountByRxV1Request
        ,customerAccountId
        ,reqId
        ,reqTrackingId);


    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);
    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
    Assert.assertEquals(createAccountByRxResponse.code(),200,errorMessage);

    CreateAccountByRxV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) createAccountByRxResponse.body().getPayload()),
            CreateAccountByRxV1Response.class);

    // Asserting desired responses
    Assert.assertEquals(response.getCustomerAccountId(),customerAccountId);
  }

  @Test(priority = 2,
          description = "Account already linked to other customer account id case")
  public void createAccountByRxAccountAlreadyExists() throws IOException {
    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
            reqId,reqTrackingId, storeNbr, rxNbr, customerAccountId);

    // call createAccountByRx API first time so that next time we call it will give error
    accountOrchestratorRetrofit.createAccountByRx(
            domainId,
            createAccountByRxV1Request
            ,customerAccountId
            ,reqId
            ,reqTrackingId);

    // call createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
            domainId,
            createAccountByRxV1Request
            ,customerAccountId
            ,reqId
            ,reqTrackingId);

    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(createAccountByRxResponse.code(),409,errorMessage);
    Assert.assertEquals(errorResponse.getCode(),"DPR-DPACCOR-2011");
    Assert.assertTrue(errorResponse.getMessage().contains("Online account id already exists."));
  }

 @Test(priority = 3,
      description = "Invalid request scenario for createAccountForRx")
  public void createAccountByRxInvalidRequest() throws IOException {

    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
        reqId,reqTrackingId, storeNbr, rxNbr, customerAccountId);

    // Creating request and setting t&c lang as null so that exception is thrown
    createAccountByRxV1Request.getCustomerInfo().setTAndCPolicyLanguage(null);

    // call createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
        domainId
        ,createAccountByRxV1Request
        ,customerAccountId
        ,reqId
        ,reqTrackingId);

    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(createAccountByRxResponse.code(),400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(),"DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(),"Invalid input request. tAndCPolicyLanguage is null/empty");
  }

  @Test(priority = 4,
      description = "Invalid store number case where rx orchestrator svc will throw exception")
  public void createAccountByRxInvalidDataRxOrchestrator() throws IOException, GeneralSecurityException {

    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    createAccountByRxV1Request.getCustomerInfo().setStoreNbr("30275");
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
        reqId,reqTrackingId, storeNbr, rxNbr, customerAccountId);

    // Writing in IAP to make it ID verified
    IAPUserIdentityVerificationsRequest iapWriteRequest = mapper.readValue(new File("src/test/resources/testdata/digitalpharmacy/iap/IAPWriteRequest.json"),IAPUserIdentityVerificationsRequest.class);
    iapWriteRequest.setCustomerId(customerAccountId);
    iapRetrofit.callIAPUserIdentityVerificationsAPI(iapWriteRequest);

    // call createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
        domainId
        ,createAccountByRxV1Request
        ,customerAccountId
        ,reqId
        ,reqTrackingId);

    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(createAccountByRxResponse.code(),400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(),"DPR-DPACCOR-4002");
    Assert.assertEquals(errorResponse.getMessage(),"Invalid input request sent to RX-Orchestrator service. Rx information missing for given request");
  }

  @Test(priority = 5,
          description = "Customer is in coolDown case")
  public void createAccountByRxAccountCustomerInCoolDownError() throws IOException, GeneralSecurityException {

    CreateAccountByRxV1Request createAccountByRxV1Request = getCreateAccountByRxV1Request();
    String rxNbr = createAccountByRxV1Request.getCustomerInfo().getRxNbr();
    String storeNbr = createAccountByRxV1Request.getCustomerInfo().getStoreNbr();

    logFlowIdentifiers(
            reqId,reqTrackingId, storeNbr, rxNbr, customerAccountId);

    //Authentication failed for more than 5 times-> customer in cooldown
    for(int i = 0 ;i<6 ;i++){
      pharmacyAuthServiceRetrofit.incrementFailedAuthentication(customerAccountId);
    }

    //Writing cid to IAP to make it ID verified
    IAPUserIdentityVerificationsRequest iapWriteRequest = mapper.readValue(new File("src/test/resources/testdata/digitalpharmacy/iap/IAPWriteRequest.json"),IAPUserIdentityVerificationsRequest.class);
    iapWriteRequest.setCustomerId(customerAccountId);
    iapRetrofit.callIAPUserIdentityVerificationsAPI(iapWriteRequest);

    // call createAccountByRx API
    Response<ServiceResponse> createAccountByRxResponse = accountOrchestratorRetrofit.createAccountByRx(
            domainId,
            createAccountByRxV1Request
            ,customerAccountId
            ,reqId
            ,reqTrackingId);


    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByRxResponse);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(createAccountByRxResponse.code(),400,errorMessage);
    Assert.assertEquals(errorResponse.getCode(),"DPR-DPACCOR-3001");
    Assert.assertEquals(errorResponse.getMessage(),"Customer is in Cooldown Period");
  }

  private CreateAccountByRxV1Request getCreateAccountByRxV1Request() {

    CreateAccountByRxV1Request.CustomerInfo customerInfo = CreateAccountByRxV1Request.CustomerInfo.builder()
            .rxNbr("8022092")
            .storeNbr("5548")
            .dob("09051992")
            .tAndCPolicyLanguage("EN")
            .lastName("KINGSTON")
            .build();

    return CreateAccountByRxV1Request.builder().customerInfo(customerInfo).build();
  }

  public static void logFlowIdentifiers(
      String reqId, String reqTrackingId, String storeNbr, String rxNbr, String customerAccountId) {

    Reporter.logJSON("customerAccountId", customerAccountId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
    Reporter.logJSON("store number", storeNbr);
    Reporter.logJSON("rx number", rxNbr);
  }
}
