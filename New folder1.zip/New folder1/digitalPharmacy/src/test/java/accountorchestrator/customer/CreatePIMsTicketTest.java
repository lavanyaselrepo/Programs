package accountorchestrator.customer;

import accountorchestrator.constants.AccountOrchestratorConstants;
import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPCreateGuestAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPCreateGuestAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Arrays;

import static accountorchestrator.constants.AccountOrchestratorConstants.*;

public class CreatePIMsTicketTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetroFit;
    private ObjectMapper mapper = new ObjectMapper();
    private Gson gson = new GsonBuilder().create();
    private String caregiverCustomerEmailId = null;
    private String dependent3CustomerEmailId = null;
    private String dependent4CustomerEmailId = null;
    private String caregiverCustomerAccountId = null;
    private String dependent3CustomerAccountId = null;
    private String caregiverStoreNbr = null;
    private String caregiverPatientId = null;
    private String dependent3StoreNbr = null;
    private String dependent3PatientId = null;
    private String caregiverFirstName = null;
    private String caregiverLastName = null;
    private String dependent3FirstName = null;
    private String dependent3LastName = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatYoungerThan18 = null;
    private String commonDobDPFormatYoungerThan18 = null;
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetroFit = new WCPRetroFit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

        caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent3CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent4CustomerEmailId = CommonUtil.generateRandomEmailId(10);

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

        Date dateForYoungerThan18 = new Date(System.currentTimeMillis() - 24L * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatYoungerThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForYoungerThan18);
        commonDobDPFormatYoungerThan18 = new SimpleDateFormat("MMddyyyy").format(dateForYoungerThan18);


        // caregiver
        caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
        caregiverPatientId = CommonUtil.generateRandomNumber(9);
        caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverCustomerEmailId);
        caregiverFirstName = RandomStringUtils.randomAlphabetic(5);
        caregiverLastName = RandomStringUtils.randomAlphabetic(5);
        createCPRAccount(
                caregiverStoreNbr,
                caregiverPatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                caregiverFirstName,
                caregiverLastName);
        createPharmacyAccount(
                caregiverCustomerAccountId,
                caregiverStoreNbr,
                caregiverPatientId,
                commonDobDPFormatForOlderThan18);

        dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent3PatientId = CommonUtil.generateRandomNumber(9);
        dependent3FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent3LastName = RandomStringUtils.randomAlphabetic(5);
        dependent3CustomerAccountId = createWcpGuestAccount(dependent3FirstName,dependent3LastName,MINOR, commonDobCPRFormatYoungerThan18);
        createCPRAccount(
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobCPRFormatYoungerThan18,
                HUMAN,
                dependent3FirstName,
                dependent3LastName);
        createPharmacyAccount(
                dependent3CustomerAccountId,
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobDPFormatYoungerThan18);
        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent3CustomerAccountId,caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest,caregiverCustomerAccountId);
    }

    /**
     * Clean up for all created cpr accounts
     *
     */
    @AfterClass
    void cleanUp() {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
    }

    private String createWcpGuestAccount(
            String firstName, String lastName, String customerType, String dob) throws Exception {
        WCPCreateGuestAccountRequest wcpCreateGuestAccountRequest =
                getWcpCreateGuestAccountRequest(firstName, lastName, customerType, dob);
        Response<WCPCreateGuestAccountResponse> response = null;

        // Retry up to 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetroFit.createGuestAccount(wcpCreateGuestAccountRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && response.body().getStatus() != "OK") {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP Guest account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
        return response
                .body()
                .getPayload()
                .getCustomerAccountId();
    }

    private static WCPCreateGuestAccountRequest getWcpCreateGuestAccountRequest(
            String firstName, String lastName, String customerType, String dob) {
        return WCPCreateGuestAccountRequest.builder()
                .payload(
                        WCPCreateGuestAccountRequest.Payload.builder()
                                .account(
                                        WCPCreateGuestAccountRequest.Account.builder()
                                                .accountType(ACCOUNT_TYPE_GUEST)
                                                .customerType(CUSTOMER_TYPE_INDIVIDUAL)
                                                .firstName(firstName)
                                                .lastName(lastName)
                                                .dateOfBirth(dob)
                                                .build())
                                .build())
                .build();
    }

    @Test(
            priority = 0,
            description =
                    "Create PIMs Ticket for self successful")
    public void createPIMsTicketForSelfSuccessFul()
            throws IOException, GeneralSecurityException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = AccountOrchestratorConstants.reqIdString + trackID;
        String reqTrackingId = AccountOrchestratorConstants.reqTrackingString + trackID;

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.additionalInfo(TICKET_ADDITIONAL_INFO);

        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId,PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
        // GetCustomerInfoV2
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 1,
            description =
                    "Create PIMs ticket for dependent successful")
    public void createPIMsTicketForDependentSuccess()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.additionalInfo(TICKET_ADDITIONAL_INFO);

        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(dependent3CustomerAccountId)
                .isDependent(true)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
        // GetCustomerInfoV2
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), dependent3CustomerAccountId);
    }

    @Test(
            priority = 2,
            description =
                    "Create PIMs ticket for self with only required fields")
    public void createPIMsTicketForSelfWithOnlyRequiredFields()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId,PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
        // GetCustomerInfoV2
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 4,
            description =
                    "Create PIMs ticket for self customerAccountId null")
    public void createPIMsTicketForSelfWithCIDNull()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(null)
                .isDependent(false)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Customer Account ID is null"));
    }

    @Test(
            priority = 5,
            description =
                    "Create PIMs ticket for self isDependent null")
    public void createPIMsTicketForSelfWithIsDependentNull()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(null)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Please mark if you are creating the ticket for yourself or dependent"));
    }

    @Test(
            priority = 6,
            description =
                    "Create PIMs ticket for self type null")
    public void createPIMsTicketForSelfWithTypeNull()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(null);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Type is null"));
    }

    @Test(
            priority = 7,
            description =
                    "Create PIMs ticket for dependent with null")
    public void createPIMsTicketForSelfWithCidInURISameAsRequestNull()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(true)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Please enter the dependent customer account ID"));
    }

    @Test(
            priority = 8,
            description =
                    "Create PIMs ticket for self with cid different as uri with isDependent false")
    public void createPIMsTicketForSelfWithCidDifferntFromRequestIsDependentFalseAsRequestNull()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(dependent3CustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Please enter a valid customer account ID"));
    }

    @Test(
            priority = 9,
            description =
                    "Create PIMs ticket with not a valid CID")
    public void createPIMsTicketNotAValidCid()
            throws IOException {
        // Step - 1a: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId("dependent3CustomerAccountId")
                .isDependent(true)
                .ticketInfo(ticketInfo);
        // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1014"));
    }

    @Test(
            priority = 10,
            description =
                    "Create PIMs ticket with all CorrectedInfo fields present")
    public void createPIMsTicketWithAllCorrectedInfoFields()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create request with all corrected info fields
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        CustomerInfoValidationCorrectedInfo correctedInfo = createBasicCorrectedInfo();
        correctedInfo.address(createValidAddress());
        customerInfoValidation.correctedInfo(correctedInfo);

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.customerInfoValidation(customerInfoValidation);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 11,
            description =
                    "Create PIMs ticket with some CorrectedInfo fields and one empty field")
    public void createPIMsTicketWithPartialCorrectedInfoFields()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create customer info validation with some corrected info fields
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(true);

        // Create proper CustomerInfoValidationCorrectedInfo object with one empty field
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.dob(commonDobDPFormatForOlderThan18);
        correctedInfo.gender(""); // Empty field

        customerInfoValidation.correctedInfo(correctedInfo);

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.customerInfoValidation(customerInfoValidation);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 12,
            description =
                    "Create PIMs ticket with one CorrectedInfo field present and two empty fields")
    public void createPIMsTicketWithOneCorrectedInfoField()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create customer info validation with one corrected info field and two empty fields
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(true);

        // Create proper CustomerInfoValidationCorrectedInfo object with two empty fields
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName()); // Only one field with value
        correctedInfo.dob(""); // Empty field
        correctedInfo.gender(""); // Empty field

        customerInfoValidation.correctedInfo(correctedInfo);

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.customerInfoValidation(customerInfoValidation);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 14,
            description =
                    "Create PIMs ticket with PreviousInfo not present (null)")
    public void createPIMsTicketWithNoPreviousInfo()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create and configure the request with null previousInfo
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.previousInfo(null); // Explicitly set to null

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 15,
            description =
                    "Create PIMs ticket with valid PreviousInfo (addresses, names, and phone numbers)")
    public void createPIMsTicketWithValidPreviousInfo()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create PreviousInfo with addresses, names, and phone numbers
        PreviousInfo previousInfo = createValidPreviousInfo();

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.previousInfo(previousInfo);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 24,
            description =
                    "Create PIMs ticket with valid phone number in CorrectedInfo")
    public void createPIMsTicketWithValidPhoneNumber()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create customer info validation with valid phone number
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(true);

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());

        customerInfoValidation.correctedInfo(correctedInfo);

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.customerInfoValidation(customerInfoValidation);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 26,
            description =
                    "Create PIMs ticket with valid address in CorrectedInfo")
    public void createPIMsTicketWithValidCorrectedAddress()
            throws IOException {

        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        // Create customer info validation with valid address
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(true);
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.address(createValidAddress());

        // Create and configure the request
        CreatePIMSTicketV1Request createPIMSTicketV1Request = createBaseRequest(false);
        createPIMSTicketV1Request.customerInfoValidation(customerInfoValidation);

        // Step - 2: Calling createPIMsTicketV1 with the request
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(description = "customerId null should fail")
    public void testCustomerIdNull() throws Exception {
        CreatePIMSTicketV1Request req = createBaseRequest(false).customerId(null);
        String[] ids = getTrackingIds();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> createPIMSTicketResponse = accountOrchestratorRetrofit.createPIMsTicketV1(
                caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);
        String errMsg = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errMsg);
        Assert.assertTrue(errMsg.contains("Customer Account ID is null"));
    }

    @Test(description = "PreviousInfo.phoneNumbers invalid should fail")
    public void testPreviousInfoInvalidPhoneNumber() throws Exception {

        PreviousInfo previousInfo = new PreviousInfo();
        List<String> phoneNumbers = new ArrayList<>();
        phoneNumbers.add("123456789"); // Invalid (too short, or not matching backend rule)
        previousInfo.phoneNumbers(phoneNumbers);

        CreatePIMSTicketV1Request req = createBaseRequest(false).previousInfo(previousInfo);
        String[] ids = getTrackingIds();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);
        String errMsg = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        Assert.assertEquals(createPIMSTicketResponse.code(), 400, errMsg);
        Assert.assertTrue(errMsg.contains("Invalid Previous Phone Number"));
    }

    @Test(
            priority = 13,
            description = "Create PIMs ticket with reasonForRequest 'Recently prescribed Rx' for self")
    public void createPIMsTicketWithReasonForRequestRecentlyPrescribedRx()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest("Recently prescribed Rx"); // New field

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);

        // Step - 2: Calling createPIMsTicketV1
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        // Step - 3: Building errorMessage
        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);

        // Step - 4: Parsing the response
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Step - 5: Asserting response
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 14,
            description = "Create PIMs ticket with reasonForRequest 'Recently transferred Rx' for self")
    public void createPIMsTicketWithReasonForRequestRecentlyTransferredRx()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest("Recently transferred Rx"); // New field

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
    }

    @Test(
            priority = 15,
            description = "Create PIMs ticket with reasonForRequest null (backward compatibility)")
    public void createPIMsTicketWithReasonForRequestNull()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest(null); // Null for backward compatibility

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        // Should succeed even with null reasonForRequest (backward compatibility)
        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
    }

    @Test(
            priority = 16,
            description = "Create PIMs ticket with reasonForRequest empty string")
    public void createPIMsTicketWithReasonForRequestEmptyString()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest(""); // Empty string

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
    }

    @Test(
            priority = 17,
            description = "Create PIMs ticket for dependent with reasonForRequest")
    public void createPIMsTicketForDependentWithReasonForRequest()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest("Recently prescribed Rx");

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(dependent3CustomerAccountId)
                .isDependent(true)
                .ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
        Assert.assertEquals(response.getCustomerId(), dependent3CustomerAccountId);
    }

    @Test(
            priority = 18,
            description = "Create PIMs ticket with reasonForRequest and all other ticket fields")
    public void createPIMsTicketWithReasonForRequestAndAllFields()
            throws IOException {
        // Get tracking IDs
        String[] ids = getTrackingIds();
        String reqId = ids[0];
        String reqTrackingId = ids[1];

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("missing prescription");
        ticketInfo.reasonForRequest("Recently prescribed Rx");
        ticketInfo.additionalInfo(TICKET_ADDITIONAL_INFO);
        ticketInfo.description(new ArrayList<>());

        CreatePIMSTicketV1Request createPIMSTicketV1Request = new CreatePIMSTicketV1Request();
        createPIMSTicketV1Request.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                createPIMSTicketResponse =
                accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, createPIMSTicketV1Request, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, createPIMSTicketResponse);
        CreatePIMSTicketV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) createPIMSTicketResponse.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertEquals(createPIMSTicketResponse.code(), 200, errorMessage);
        Assert.assertNotNull(createPIMSTicketResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getTicketRefNo());
    }

    @Test(
            priority = 27,
            description = "Create PIMs ticket with type as whitespace-only string should fail with 'Type is null'")
    public void createPIMsTicketWithTypeWhitespace() throws IOException {
        String[] ids = getTrackingIds();
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type("   "); // whitespace only
        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId).isDependent(false).ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Type is null"), errorMessage);
    }

    @Test(
            priority = 28,
            description = "Create PIMs ticket with type as empty string should fail with 'Type is null'")
    public void createPIMsTicketWithTypeEmptyString() throws IOException {
        String[] ids = getTrackingIds();
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(""); // empty string
        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId).isDependent(false).ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Type is null"), errorMessage);
    }

    @Test(
            priority = 29,
            description = "Create PIMs ticket with ticketInfo null should fail with HTTP 500 — " +
                    "service has no null guard on ticketInfo before calling getType(), causing NullPointerException")
    public void createPIMsTicketWithTicketInfoNull() throws IOException {
        String[] ids = getTrackingIds();
        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId).isDependent(false).ticketInfo(null);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        Assert.assertEquals(response.code(), 500,
                "Expected HTTP 500 because ticketInfo=null causes NPE inside service validation");
    }

    @Test(
            priority = 30,
            description = "Create PIMs ticket with correctedInfo present but all fields null should fail with 'At least one corrected info field must be present'")
    public void createPIMsTicketWithCorrectedInfoAllFieldsEmpty() throws IOException {
        String[] ids = getTrackingIds();

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("At least one corrected info field must be present"), errorMessage);
    }


    @Test(
            priority = 31,
            description = "Create PIMs ticket with correctedInfo name having firstName set but lastName blank should fail")
    public void createPIMsTicketWithCorrectedNameFirstNameOnlyNoLastName() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoName name = new CustomerInfoValidationCorrectedInfoName();
        name.firstName(RandomStringUtils.randomAlphabetic(5));
        name.lastName(""); // blank lastName

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(name);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected Last name is required"), errorMessage);
    }

    @Test(
            priority = 32,
            description = "Create PIMs ticket with correctedInfo name having lastName set but firstName blank should fail")
    public void createPIMsTicketWithCorrectedNameLastNameOnlyNoFirstName() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoName name = new CustomerInfoValidationCorrectedInfoName();
        name.firstName(""); // blank firstName
        name.lastName(RandomStringUtils.randomAlphabetic(5));

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(name);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected First name is required"), errorMessage);
    }


    @Test(
            priority = 33,
            description = "Create PIMs ticket with DOB in wrong format (yyyy-MM-dd instead of MMddyyyy) should fail")
    public void createPIMsTicketWithInvalidDobWrongFormat() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.dob("2000-01-15"); // wrong format — service expects MMddyyyy

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("DOB must be a valid date in MMddyyyy format"), errorMessage);
    }

    @Test(
            priority = 34,
            description = "Create PIMs ticket with DOB having invalid month (13) should fail")
    public void createPIMsTicketWithInvalidDobInvalidMonth() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.dob("13012000"); // month = 13, invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("DOB must be a valid date in MMddyyyy format"), errorMessage);
    }

    @Test(
            priority = 35,
            description = "Create PIMs ticket with DOB having invalid day (00) should fail")
    public void createPIMsTicketWithInvalidDobInvalidDay() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.dob("00012000"); // day = 00, invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("DOB must be a valid date in MMddyyyy format"), errorMessage);
    }

    @Test(
            priority = 36,
            description = "Create PIMs ticket with DOB as non-numeric string should fail")
    public void createPIMsTicketWithInvalidDobNonNumeric() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.dob("abcdefgh"); // non-numeric

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("DOB must be a valid date in MMddyyyy format"), errorMessage);
    }

    @Test(
            priority = 37,
            description = "Create PIMs ticket with DOB as empty string should succeed (treated as not provided)")
    public void createPIMsTicketWithDobEmptyString() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName()); // at least one field to avoid 'at least one' error
        correctedInfo.dob(""); // empty — service treats as not provided, skips validation

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 38,
            description = "Create PIMs ticket with correctedInfo phoneNbr having 9 digits should fail with 'Invalid Corrected Phone Number'")
    public void createPIMsTicketWithCorrectedPhoneNineDigits() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.phoneNbr("123456789"); // 9 digits — invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Corrected Phone Number"), errorMessage);
    }

    @Test(
            priority = 39,
            description = "Create PIMs ticket with correctedInfo phoneNbr having 11 digits should fail with 'Invalid Corrected Phone Number'")
    public void createPIMsTicketWithCorrectedPhoneElevenDigits() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.phoneNbr("12345678901"); // 11 digits — invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Corrected Phone Number"), errorMessage);
    }

    @Test(
            priority = 40,
            description = "Create PIMs ticket with correctedInfo phoneNbr formatted with dashes should fail with 'Invalid Corrected Phone Number'")
    public void createPIMsTicketWithCorrectedPhoneFormattedWithDashes() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.phoneNbr("123-456-7890"); // formatted with dashes — invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Corrected Phone Number"), errorMessage);
    }

    @Test(
            priority = 41,
            description = "Create PIMs ticket with correctedInfo phoneNbr containing alpha characters should fail with 'Invalid Corrected Phone Number'")
    public void createPIMsTicketWithCorrectedPhoneAlphaChars() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.phoneNbr("abcdefghij"); // alpha chars — invalid

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Corrected Phone Number"), errorMessage);
    }

    @Test(
            priority = 42,
            description = "Create PIMs ticket with correctedInfo phoneNbr as empty string should succeed — " +
                    "service uses StringUtils.isBlank() guard: blank phone is treated as 'not provided' and validation is skipped")
    public void createPIMsTicketWithCorrectedPhoneEmptyString() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.phoneNbr(""); // empty string — service guard: if (!isBlank(phoneNbr)) → skips validation entirely

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        // Service uses if (!isBlank(phoneNbr)) as a guard — empty string is blank,
        // so phone validation is SKIPPED and the request succeeds with 200.
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo(),
                "ticketRefNo must not be null — empty phoneNbr is treated as not provided");
    }


    @Test(
            priority = 43,
            description = "Create PIMs ticket with correctedInfo address missing addressLine1 should fail with 'Corrected Address is required'")
    public void createPIMsTicketWithCorrectedAddressMissingAddressLine1() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoAddress address = new CustomerInfoValidationCorrectedInfoAddress();
        // addressLine1 intentionally omitted
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.address(address);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected Address is required"), errorMessage);
    }

    @Test(
            priority = 44,
            description = "Create PIMs ticket with correctedInfo address missing city should fail with 'Corrected City is required'")
    public void createPIMsTicketWithCorrectedAddressMissingCity() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoAddress address = new CustomerInfoValidationCorrectedInfoAddress();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        // city intentionally omitted
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.address(address);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected City is required"), errorMessage);
    }

    @Test(
            priority = 45,
            description = "Create PIMs ticket with correctedInfo address missing state should fail with 'Corrected State is required'")
    public void createPIMsTicketWithCorrectedAddressMissingState() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoAddress address = new CustomerInfoValidationCorrectedInfoAddress();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.city(RandomStringUtils.randomAlphabetic(8));
        // state intentionally omitted
        address.zipCode(CommonUtil.generateRandomNumber(5));

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.address(address);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected State is required"), errorMessage);
    }

    @Test(
            priority = 46,
            description = "Create PIMs ticket with correctedInfo address missing zipCode should fail with 'Corrected ZipCode is required'")
    public void createPIMsTicketWithCorrectedAddressMissingZipCode() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidationCorrectedInfoAddress address = new CustomerInfoValidationCorrectedInfoAddress();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        // zipCode intentionally omitted

        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        correctedInfo.name(createValidName());
        correctedInfo.address(address);

        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Corrected ZipCode is required"), errorMessage);
    }

    @Test(
            priority = 47,
            description = "Create PIMs ticket with previousInfo address missing addressLine1 should fail with 'Prior Address is required'")
    public void createPIMsTicketWithPreviousAddressMissingAddressLine1() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoAddresses address = new PreviousInfoAddresses();
        // addressLine1 intentionally omitted
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.addresses(List.of(address));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Prior Address is required"), errorMessage);
    }

    @Test(
            priority = 48,
            description = "Create PIMs ticket with previousInfo address missing city should fail with 'Prior City is required'")
    public void createPIMsTicketWithPreviousAddressMissingCity() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoAddresses address = new PreviousInfoAddresses();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        // city intentionally omitted
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.addresses(List.of(address));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Prior City is required"), errorMessage);
    }

    @Test(
            priority = 49,
            description = "Create PIMs ticket with previousInfo address missing state should fail with 'Prior State is required'")
    public void createPIMsTicketWithPreviousAddressMissingState() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoAddresses address = new PreviousInfoAddresses();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.city(RandomStringUtils.randomAlphabetic(8));
        // state intentionally omitted
        address.zipCode(CommonUtil.generateRandomNumber(5));

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.addresses(List.of(address));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Prior State is required"), errorMessage);
    }

    @Test(
            priority = 50,
            description = "Create PIMs ticket with previousInfo address missing zipCode should fail with 'Prior ZipCode is required'")
    public void createPIMsTicketWithPreviousAddressMissingZipCode() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoAddresses address = new PreviousInfoAddresses();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        // zipCode intentionally omitted

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.addresses(List.of(address));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Prior ZipCode is required"), errorMessage);
    }

    @Test(
            priority = 51,
            description = "Create PIMs ticket with previousInfo name having firstName blank should fail with 'Previous First name is required'")
    public void createPIMsTicketWithPreviousNameMissingFirstName() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoNames name = new PreviousInfoNames();
        name.firstName(""); // blank
        name.lastName(RandomStringUtils.randomAlphabetic(5));

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.names(List.of(name));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Previous First name is required"), errorMessage);
    }

    @Test(
            priority = 52,
            description = "Create PIMs ticket with previousInfo name having lastName blank should fail with 'Previous Last name is required'")
    public void createPIMsTicketWithPreviousNameMissingLastName() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfoNames name = new PreviousInfoNames();
        name.firstName(RandomStringUtils.randomAlphabetic(5));
        name.lastName(""); // blank

        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.names(List.of(name));

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Previous Last name is required"), errorMessage);
    }


    @Test(
            priority = 53,
            description = "Create PIMs ticket with previousInfo phone formatted with dashes should fail with 'Invalid Previous Phone Number'")
    public void createPIMsTicketWithPreviousPhoneFormattedWithDashes() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.phoneNumbers(List.of("123-456-7890")); // formatted with dashes

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Previous Phone Number"), errorMessage);
    }

    @Test(
            priority = 54,
            description = "Create PIMs ticket with previousInfo phone as empty string should fail with 'Previous Phone number is required'")
    public void createPIMsTicketWithPreviousPhoneEmptyString() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.phoneNumbers(List.of("")); // empty string phone — blank when provided

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Previous Phone number is required"), errorMessage);
    }

    @Test(
            priority = 55,
            description = "Create PIMs ticket with previousInfo multiple phones where one is invalid should fail on first invalid")
    public void createPIMsTicketWithPreviousMultiplePhonesOneInvalid() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.phoneNumbers(List.of("1234567890", "badphone")); // first valid, second invalid

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertTrue(errorMessage.contains("Invalid Previous Phone Number"), errorMessage);
    }

    @Test(
            priority = 56,
            description = "Create PIMs ticket with isInfoCorrect=true and no correctedInfo should succeed")
    public void createPIMsTicketWithIsInfoCorrectTrueNoCorrectedInfo() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidation customerInfoValidation = new CustomerInfoValidation();
        customerInfoValidation.isInfoCorrect(true); // info is correct — no corrections needed

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
        Assert.assertEquals(parsedResponse.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 57,
            description = "Create PIMs ticket with isInfoCorrect=false and no correctedInfo should succeed")
    public void createPIMsTicketWithIsInfoCorrectFalseNoCorrectedInfo() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidation customerInfoValidation = new CustomerInfoValidation();
        customerInfoValidation.isInfoCorrect(false); // false but correctedInfo omitted

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 58,
            description = "Create PIMs ticket with isInfoCorrect=null (optional field omitted) should succeed")
    public void createPIMsTicketWithIsInfoCorrectNull() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidation customerInfoValidation = new CustomerInfoValidation();
        customerInfoValidation.isInfoCorrect(null); // null — field is optional

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 59,
            description = "Create PIMs ticket with previousInfo addresses as empty list should succeed")
    public void createPIMsTicketWithPreviousInfoEmptyAddressList() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.addresses(new ArrayList<>()); // empty list

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 60,
            description = "Create PIMs ticket with previousInfo phoneNumbers as empty list should succeed")
    public void createPIMsTicketWithPreviousInfoEmptyPhoneNumbersList() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.phoneNumbers(new ArrayList<>()); // empty list

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 61,
            description = "Create PIMs ticket with previousInfo names as empty list should succeed")
    public void createPIMsTicketWithPreviousInfoEmptyNamesList() throws IOException {
        String[] ids = getTrackingIds();
        PreviousInfo previousInfo = new PreviousInfo();
        previousInfo.names(new ArrayList<>()); // empty list

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }

    @Test(
            priority = 62,
            description = "Create PIMs ticket for self — response customerId must match the request customerId")
    public void createPIMsTicketResponseCustomerIdMatchesRequest() throws IOException {
        String[] ids = getTrackingIds();
        CreatePIMSTicketV1Request req = createBaseRequest(false);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);

        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertNotNull(parsedResponse.getTicketRefNo(), "ticketRefNo must not be null");
        Assert.assertFalse(parsedResponse.getTicketRefNo().isEmpty(), "ticketRefNo must not be empty");
        Assert.assertEquals(parsedResponse.getCustomerId(), caregiverCustomerAccountId,
                "Response customerId must match the request customerId");
    }

    @Test(
            priority = 63,
            description = "Two sequential CreatePIMsTicket calls must return two unique ticketRefNo values (idempotency)")
    public void createPIMsTicketIdempotencyTwoUniqueTicketRefNos() throws IOException {
        // First call
        String[] ids1 = getTrackingIds();
        CreatePIMSTicketV1Request req1 = createBaseRequest(false);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response1 = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req1, ids1[0], ids1[1]);

        // Second call — new tracking IDs
        String[] ids2 = getTrackingIds();
        CreatePIMSTicketV1Request req2 = createBaseRequest(false);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response2 = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req2, ids2[0], ids2[1]);

        Assert.assertEquals(response1.code(), 200, "First call must return 200");
        Assert.assertEquals(response2.code(), 200, "Second call must return 200");

        CreatePIMSTicketV1Response parsedResponse1 = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response1.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        CreatePIMSTicketV1Response parsedResponse2 = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response2.body().getPayload()),
                CreatePIMSTicketV1Response.class);

        Assert.assertNotNull(parsedResponse1.getTicketRefNo(), "First ticketRefNo must not be null");
        Assert.assertNotNull(parsedResponse2.getTicketRefNo(), "Second ticketRefNo must not be null");
        Assert.assertNotEquals(parsedResponse1.getTicketRefNo(), parsedResponse2.getTicketRefNo(),
                "Each call must generate a unique ticketRefNo");
    }


    @Test(
            priority = 64,
            description = "Create PIMs ticket with description list containing items should succeed")
    public void createPIMsTicketWithDescriptionListItems() throws IOException {
        String[] ids = getTrackingIds();
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        ticketInfo.description(List.of("Item 1 description", "Item 2 description"));

        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId).isDependent(false).ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
        Assert.assertEquals(parsedResponse.getCustomerId(), caregiverCustomerAccountId);
    }

    @Test(
            priority = 65,
            description = "Create PIMs ticket with description as empty list should succeed")
    public void createPIMsTicketWithDescriptionEmptyList() throws IOException {
        String[] ids = getTrackingIds();
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        ticketInfo.description(new ArrayList<>()); // empty list — valid

        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId).isDependent(false).ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }


    @Test(
            priority = 66,
            description = "Create PIMs ticket with customerInfoValidation present but correctedInfo null should succeed")
    public void createPIMsTicketWithCustomerInfoValidationNullCorrectedInfo() throws IOException {
        String[] ids = getTrackingIds();
        CustomerInfoValidation customerInfoValidation = new CustomerInfoValidation();
        customerInfoValidation.isInfoCorrect(false);
        customerInfoValidation.correctedInfo(null); // correctedInfo explicitly null

        CreatePIMSTicketV1Request req = createBaseRequest(false);
        req.customerInfoValidation(customerInfoValidation);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
    }


    @Test(
            priority = 67,
            description = "Create PIMs ticket for dependent — response customerId must match dependent's customerId")
    public void createPIMsTicketForDependentResponseCustomerIdMatchesDependent() throws IOException {
        String[] ids = getTrackingIds();
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);

        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(dependent3CustomerAccountId).isDependent(true).ticketInfo(ticketInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);

        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo(), "ticketRefNo must not be null");
        Assert.assertFalse(parsedResponse.getTicketRefNo().isEmpty(), "ticketRefNo must not be empty");
        Assert.assertEquals(parsedResponse.getCustomerId(), dependent3CustomerAccountId,
                "Response customerId must match the dependent's customerId");
    }


    @Test(
            priority = 68,
            description = "Create PIMs ticket for self with correctedInfo, previousInfo, and reasonForRequest all set should succeed")
    public void createPIMsTicketWithAllOptionalFieldsCombined() throws IOException {
        String[] ids = getTrackingIds();

        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);
        ticketInfo.reasonForRequest("Recently prescribed Rx");
        ticketInfo.additionalInfo("Additional test info");
        ticketInfo.description(List.of("Description line 1"));

        CustomerInfoValidationCorrectedInfo correctedInfo = createBasicCorrectedInfo();
        correctedInfo.address(createValidAddress());
        CustomerInfoValidation customerInfoValidation = createCustomerInfoValidation(false);
        customerInfoValidation.correctedInfo(correctedInfo);

        PreviousInfo previousInfo = createValidPreviousInfo();

        CreatePIMSTicketV1Request req = new CreatePIMSTicketV1Request();
        req.customerId(caregiverCustomerAccountId)
                .isDependent(false)
                .ticketInfo(ticketInfo)
                .customerInfoValidation(customerInfoValidation)
                .previousInfo(previousInfo);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                response = accountOrchestratorRetrofit.createPIMsTicketV1(
                        caregiverCustomerAccountId, PHARMACY_DOMAIN_ID, req, ids[0], ids[1]);

        String errorMessage = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertEquals(response.code(), 200, errorMessage);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");
        CreatePIMSTicketV1Response parsedResponse = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                CreatePIMSTicketV1Response.class);
        Assert.assertNotNull(parsedResponse.getTicketRefNo());
        Assert.assertEquals(parsedResponse.getCustomerId(), caregiverCustomerAccountId);
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    public void createCPRAccount(
            String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    public void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            PHARMACY_DOMAIN_ID,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(ACCOUNT_CREATION_SOURCE_ID_VERIFICATION)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    /**
     * Build ca create person request for dependent
     *
     * @return
     */
    private CACreatePersonRequest getCACreatePersonRequestForDependent(
            String dependentCustomerEmailId) {
        List<CACreatePersonRequest.Accounts> accountsList = new ArrayList<>();
        accountsList.add(
                CACreatePersonRequest.Accounts.builder()
                        .accountType(ACCOUNT_TYPE_INDIVIDUAL)
                        .emailAddress(dependentCustomerEmailId)
                        .build());
        return CACreatePersonRequest.builder()
                .payload(
                        CACreatePersonRequest.CreatePersonRequestPayload.builder()
                                .person(CACreatePersonRequest.Person.builder().accounts(accountsList).build())
                                .build())
                .build();
    }

    // Helper methods for creating test objects
    private CustomerInfoValidation createCustomerInfoValidation(boolean isInfoCorrect) {
        CustomerInfoValidation customerInfoValidation = new CustomerInfoValidation();
        customerInfoValidation.isInfoCorrect(isInfoCorrect);
        return customerInfoValidation;
    }

    private CustomerInfoValidationCorrectedInfo createBasicCorrectedInfo() {
        CustomerInfoValidationCorrectedInfo correctedInfo = new CustomerInfoValidationCorrectedInfo();
        CustomerInfoValidationCorrectedInfoName name = new CustomerInfoValidationCorrectedInfoName();
        name.firstName(RandomStringUtils.randomAlphabetic(5));
        name.lastName(RandomStringUtils.randomAlphabetic(5));
        correctedInfo.name(name);
        correctedInfo.dob(commonDobDPFormatForOlderThan18);
        correctedInfo.gender("M");
        correctedInfo.phoneNbr(CommonUtil.generateRandomNumber(10));
        return correctedInfo;
    }

    private CustomerInfoValidationCorrectedInfoName createValidName() {
        CustomerInfoValidationCorrectedInfoName name = new CustomerInfoValidationCorrectedInfoName();
        name.firstName(RandomStringUtils.randomAlphabetic(5));
        name.lastName(RandomStringUtils.randomAlphabetic(5));
        return name;
    }

    private CustomerInfoValidationCorrectedInfoAddress createValidAddress() {
        CustomerInfoValidationCorrectedInfoAddress address = new CustomerInfoValidationCorrectedInfoAddress();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.addressLine2("Apt " + RandomStringUtils.randomNumeric(2));
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));
        address.country(ADDRESS_COUNTRY_USA);
        return address;
    }

    private PreviousInfo createBasicPreviousInfo() {
        PreviousInfo previousInfo = new PreviousInfo();
        return previousInfo;
    }

    private PreviousInfoAddresses createValidPreviousAddress() {
        PreviousInfoAddresses address = new PreviousInfoAddresses();
        address.addressLine1(RandomStringUtils.randomNumeric(3) + " " + RandomStringUtils.randomAlphabetic(8) + " St");
        address.city(RandomStringUtils.randomAlphabetic(8));
        address.state(RandomStringUtils.randomAlphabetic(2).toUpperCase());
        address.zipCode(CommonUtil.generateRandomNumber(5));
        return address;
    }

    private PreviousInfoNames createValidPreviousName() {
        PreviousInfoNames name = new PreviousInfoNames();
        name.firstName(RandomStringUtils.randomAlphabetic(5));
        name.lastName(RandomStringUtils.randomAlphabetic(5));
        return name;
    }

    private PreviousInfo createValidPreviousInfo() {
        PreviousInfo previousInfo = new PreviousInfo();

        // Add address
        List<PreviousInfoAddresses> addresses = new ArrayList<>();
        addresses.add(createValidPreviousAddress()); // assumes you have this helper already
        previousInfo.addresses(addresses);

        // Add name
        List<PreviousInfoNames> names = new ArrayList<>();
        names.add(createValidPreviousName()); // assumes you have this helper already
        previousInfo.names(names);

        // Add phone numbers
        List<String> phoneNumbers = new ArrayList<>();
        phoneNumbers.add(CommonUtil.generateRandomNumber(10));
        previousInfo.phoneNumbers(phoneNumbers);

        return previousInfo;
    }

    private CreatePIMSTicketV1Request createBaseRequest(boolean isDependent) {
        TicketInfo ticketInfo = new TicketInfo();
        ticketInfo.type(TICKET_TYPE_MISSING_PRESCRIPTION);

        CreatePIMSTicketV1Request request = new CreatePIMSTicketV1Request();
        request.customerId(caregiverCustomerAccountId)
                .isDependent(isDependent)
                .ticketInfo(ticketInfo);
        return request;
    }

    private String[] getTrackingIds() {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        return new String[]{reqId, reqTrackingId};
    }
}
