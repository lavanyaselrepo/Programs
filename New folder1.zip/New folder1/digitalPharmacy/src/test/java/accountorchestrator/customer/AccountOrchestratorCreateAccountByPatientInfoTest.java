package accountorchestrator.customer;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpsertAccountVerificationV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountVerificationHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.CreateAccountByPatientInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.CreateAccountByPatientInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.DrRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.models.updateIdVerification.UpdateIdVerificationRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.models.updateIdVerification.UpdateIdVerificationResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class AccountOrchestratorCreateAccountByPatientInfoTest {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private AccountVerificationHelper accountVerificationHelper;
  private DrRetrofit drRetrofit;
  private WCPRetroFit wcpRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonOnlineAccountId = null;
  private String commonEmailId = null;
  private String commonStoreNbr = null;
  private String commonDobCPRFormat = null;
  private String commonFirstName = null;
  private String commonLastName = null;
  private String commonPhoneNbr = null;
  private String commonDobDPFormat = null;
  private String commonAddressPostalCode = null;
  private String adult1OnlineAccountId = null;
  private String adult1EmailId = null;
  private String adult1StoreNbr = null;
  private String adult1DobCPRFormat = null;
  private String adult1FirstName = null;
  private String adult1LastName = null;
  private String adult1PhoneNbr = null;
  private String adult1DobDPFormat = null;
  private String adult1AddressPostalCode = null;
  private String adult2OnlineAccountId = null;
  private String adult2EmailId = null;
  private String adult2StoreNbr = null;
  private String adult2DobCPRFormat = null;
  private String adult2FirstName = null;
  private String adult2LastName = null;
  private String adult2PhoneNbr = null;
  private String adult2DobDPFormat = null;
  private String adult2AddressPostalCode = null;
  private String adult3OnlineAccountId = null;
  private String adult3EmailId = null;
  private String adult3StoreNbr = null;
  private String adult3DobCPRFormat = null;
  private String adult3FirstName = null;
  private String adult3LastName = null;
  private String adult3PhoneNbr = null;
  private String adult3DobDPFormat = null;
  private String adult3AddressPostalCode = null;
  private String adult4OnlineAccountId = null;
  private String adult4EmailId = null;
  private String adult4StoreNbr = null;
  private String adult4DobCPRFormat = null;
  private String adult4FirstName = null;
  private String adult4LastName = null;
  private String adult4PhoneNbr = null;
  private String adult4DobDPFormat = null;
  private String adult4AddressPostalCode = null;
  private String adult5OnlineAccountId = null;
  private String adult5EmailId = null;
  private String adult5StoreNbr = null;
  private String adult5DobCPRFormat = null;
  private String adult5FirstName = null;
  private String adult5LastName = null;
  private String adult5PhoneNbr = null;
  private String adult5DobDPFormat = null;
  private String adult5AddressPostalCode = null;
  private String adult6OnlineAccountId = null;
  private String adult6EmailId = null;
  private String adult6StoreNbr = null;
  private String adult6DobCPRFormat = null;
  private String adult6FirstName = null;
  private String adult6LastName = null;
  private String adult6PhoneNbr = null;
  private String adult6DobDPFormat = null;
  private String adult6AddressPostalCode = null;
  private String adult7OnlineAccountId = null;
  private String adult7EmailId = null;
  private String adult7StoreNbr = null;
  private String adult7DobCPRFormat = null;
  private String adult7FirstName = null;
  private String adult7LastName = null;
  private String adult7PhoneNbr = null;
  private String adult7DobDPFormat = null;
  private String adult7AddressPostalCode = null;
  private String adult8OnlineAccountId = null;
  private String adult8EmailId = null;
  private String adult8StoreNbr = null;
  private String adult8DobCPRFormat = null;
  private String adult8FirstName = null;
  private String adult8LastName = null;
  private String adult8PhoneNbr = null;
  private String adult8DobDPFormat = null;
  private String adult8AddressPostalCode = null;
  private String adult9OnlineAccountId = null;
  private String adult9EmailId = null;
  private String adult9StoreNbr = null;
  private String adult9DobCPRFormat = null;
  private String adult9FirstName = null;
  private String adult9LastName = null;
  private String adult9PhoneNbr = null;
  private String adult9DobDPFormat = null;
  private String adult9AddressPostalCode = null;
  private String adult10OnlineAccountId = null;
  private String adult10EmailId = null;
  private String adult10StoreNbr = null;
  private String adult10DobCPRFormat = null;
  private String adult10FirstName = null;
  private String adult10LastName = null;
  private String adult10PhoneNbr = null;
  private String adult10DobDPFormat = null;
  private String adult10AddressPostalCode = null;
  private String adult11OnlineAccountId = null;
  private String adult11EmailId = null;
  private String adult11StoreNbr = null;
  private String adult11DobCPRFormat = null;
  private String adult11FirstName = null;
  private String adult11LastName = null;
  private String adult11PhoneNbr = null;
  private String adult11DobDPFormat = null;
  private String adult11AddressPostalCode = null;
  private String adult12OnlineAccountId = null;
  private String adult12EmailId = null;
  private String adult12StoreNbr = null;
  private String adult12DobCPRFormat = null;
  private String adult12FirstName = null;
  private String adult12LastName = null;
  private String adult12PhoneNbr = null;
  private String adult12DobDPFormat = null;
  private String adult12AddressPostalCode = null;
  private String domainId = "WM-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String accountCreationSource = "idVerification";
  private String virtualStoreNbr = "9928";
  private String insertOperationType = "INSERT";

  private Integer cprCommonHumanPatientId,
          cprAdult1HumanPatientId,
          cprAdult2HumanPatientId,
          cprAdult3HumanPatientId,
          cprAdult5HumanPatientId,
          cprAdult6HumanPatientId,
          cprAdult8HumanPatientId,
          cprAdult9HumanPatientId,
          cprAdult10HumanPatientId,
          cprAdult11HumanPatientId,
          cprAdult12HumanPatientId;


  ValidationServiceRequest commonHumanCprPatientRequest = null,
          adult1HumanCprPatientRequest,
          adult2HumanCprPatientRequest,
          adult3HumanCprPatientRequest,
          adult5HumanCprPatientRequest,
          adult6HumanCprPatientRequest,
          adult8HumanCprPatientRequest,
          adult9HumanCprPatientRequest,
          adult10HumanCprPatientRequest,
          adult11HumanCprPatientRequest,
          adult12HumanCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    accountVerificationHelper = new AccountVerificationHelper();
      wcpRetrofit = new WCPRetroFit();
    drRetrofit = new DrRetrofit();

    commonEmailId = CommonUtil.generateRandomEmailId(10);
    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonFirstName = RandomStringUtils.randomAlphabetic(8);
    commonLastName = RandomStringUtils.randomAlphabetic(8);
    commonPhoneNbr = CommonUtil.generateRandomNumber(10);
    Date date = new Date((System.currentTimeMillis()/1000 - 18 * 366 * 24 * 60 * 60) * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    commonAddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult1EmailId = CommonUtil.generateRandomEmailId(10);
    adult1StoreNbr = virtualStoreNbr;
    adult1FirstName = RandomStringUtils.randomAlphabetic(8);
    adult1LastName = RandomStringUtils.randomAlphabetic(8);
    adult1PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult1DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult1DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult1AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult2EmailId = CommonUtil.generateRandomEmailId(10);
    adult2StoreNbr = virtualStoreNbr;
    adult2FirstName = RandomStringUtils.randomAlphabetic(8);
    adult2LastName = RandomStringUtils.randomAlphabetic(8);
    adult2PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult2DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult2DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult2AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult3EmailId = CommonUtil.generateRandomEmailId(10);
    adult3StoreNbr = virtualStoreNbr;
    adult3FirstName = RandomStringUtils.randomAlphabetic(8);
    adult3LastName = RandomStringUtils.randomAlphabetic(8);
    adult3PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult3DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult3DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult3AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult4EmailId = CommonUtil.generateRandomEmailId(10);
    adult4StoreNbr = virtualStoreNbr;
    adult4FirstName = RandomStringUtils.randomAlphabetic(8);
    adult4LastName = RandomStringUtils.randomAlphabetic(8);
    adult4PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult4DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult4DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult4AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult5EmailId = CommonUtil.generateRandomEmailId(10);
    adult5StoreNbr = virtualStoreNbr;
    adult5FirstName = RandomStringUtils.randomAlphabetic(8);
    adult5LastName = RandomStringUtils.randomAlphabetic(8);
    adult5PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult5DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult5DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult5AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult6EmailId = CommonUtil.generateRandomEmailId(10);
    adult6StoreNbr = virtualStoreNbr;
    adult6FirstName = RandomStringUtils.randomAlphabetic(8);
    adult6LastName = RandomStringUtils.randomAlphabetic(8);
    adult6PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult6DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult6DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult6AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult7EmailId = CommonUtil.generateRandomEmailId(10);
    adult7StoreNbr = virtualStoreNbr;
    adult7FirstName = RandomStringUtils.randomAlphabetic(8);
    adult7LastName = RandomStringUtils.randomAlphabetic(8);
    adult7PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult7DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult7DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult7AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult8EmailId = CommonUtil.generateRandomEmailId(10);
    adult8StoreNbr = virtualStoreNbr;
    adult8FirstName = RandomStringUtils.randomAlphabetic(8);
    adult8LastName = RandomStringUtils.randomAlphabetic(8);
    adult8PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult8DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult8DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult8AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult9EmailId = CommonUtil.generateRandomEmailId(10);
    adult9StoreNbr = virtualStoreNbr;
    adult9FirstName = RandomStringUtils.randomAlphabetic(8);
    adult9LastName = RandomStringUtils.randomAlphabetic(8);
    adult9PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult9DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult9DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult9AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult10EmailId = CommonUtil.generateRandomEmailId(10);
    adult10StoreNbr = virtualStoreNbr;
    adult10FirstName = RandomStringUtils.randomAlphabetic(8);
    adult10LastName = RandomStringUtils.randomAlphabetic(8);
    adult10PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult10DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult10DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult10AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult11EmailId = CommonUtil.generateRandomEmailId(10);
    adult11StoreNbr = virtualStoreNbr;
    adult11FirstName = RandomStringUtils.randomAlphabetic(8);
    adult11LastName = RandomStringUtils.randomAlphabetic(8);
    adult11PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult11DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult11DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult11AddressPostalCode = CommonUtil.generateRandomNumber(5);

    adult12EmailId = CommonUtil.generateRandomEmailId(10);
    adult12StoreNbr = virtualStoreNbr;
    adult12FirstName = RandomStringUtils.randomAlphabetic(8);
    adult12LastName = RandomStringUtils.randomAlphabetic(8);
    adult12PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult12DobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    adult12DobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    adult12AddressPostalCode = CommonUtil.generateRandomNumber(5);

    commonOnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(commonEmailId);
    adult1OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult1EmailId);
    adult2OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult2EmailId);
    adult3OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult3EmailId);
    adult4OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult4EmailId);
    adult5OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult5EmailId);
    adult6OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult6EmailId);
    adult7OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult7EmailId);
    adult8OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult8EmailId);
    adult9OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult9EmailId);
    adult10OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult10EmailId);
    adult11OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult11EmailId);
    adult12OnlineAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult12EmailId);

    // Creating CPR account for all
    createAllCprAccounts();
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    commonHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    commonHumanCprPatientRequest.getPatientInfo().setFirstName(commonFirstName);
    commonHumanCprPatientRequest.getPatientInfo().setLastName(commonLastName);
    commonHumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    commonHumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(commonPhoneNbr);
    commonHumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(commonAddressPostalCode);
    commonHumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(commonDobCPRFormat);

    adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult2HumanCprPatientRequest.getPatientInfo().setFirstName(adult2FirstName);
    adult2HumanCprPatientRequest.getPatientInfo().setLastName(adult2LastName);
    adult2HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult2HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult2PhoneNbr);
    adult2HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult2AddressPostalCode);
    adult2HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult2DobCPRFormat);

    adult3HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult3HumanCprPatientRequest.getPatientInfo().setFirstName(adult3FirstName);
    adult3HumanCprPatientRequest.getPatientInfo().setLastName(adult3LastName);
    adult3HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult3HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult3PhoneNbr);
    adult3HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult3AddressPostalCode);
    adult3HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult3DobCPRFormat);

    adult5HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult5HumanCprPatientRequest.getPatientInfo().setFirstName(adult5FirstName);
    adult5HumanCprPatientRequest.getPatientInfo().setLastName(adult5LastName);
    adult5HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult5HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult5PhoneNbr);
    adult5HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult5AddressPostalCode);
    adult5HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult5DobCPRFormat);

    adult6HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult6HumanCprPatientRequest.getPatientInfo().setFirstName(adult6FirstName);
    adult6HumanCprPatientRequest.getPatientInfo().setLastName(adult6LastName);
    adult6HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult6HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult6PhoneNbr);
    adult6HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult6AddressPostalCode);
    adult6HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult6DobCPRFormat);

    adult8HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult8HumanCprPatientRequest.getPatientInfo().setFirstName(adult8FirstName);
    adult8HumanCprPatientRequest.getPatientInfo().setLastName(adult8LastName);
    adult8HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult8HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult8PhoneNbr);
    adult8HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult8AddressPostalCode);
    adult8HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult8DobCPRFormat);

    adult9HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult9HumanCprPatientRequest.getPatientInfo().setFirstName(adult9FirstName);
    adult9HumanCprPatientRequest.getPatientInfo().setLastName(adult9LastName);
    adult9HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult9HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult9PhoneNbr);
    adult9HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult9AddressPostalCode);
    adult9HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult9DobCPRFormat);

    adult10HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult10HumanCprPatientRequest.getPatientInfo().setFirstName(adult10FirstName);
    adult10HumanCprPatientRequest.getPatientInfo().setLastName(adult10LastName);
    adult10HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult10HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult10PhoneNbr);
    adult10HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult10AddressPostalCode);
    adult10HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult10DobCPRFormat);

    adult11HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult11HumanCprPatientRequest.getPatientInfo().setFirstName(adult11FirstName);
    adult11HumanCprPatientRequest.getPatientInfo().setLastName(adult11LastName);
    adult11HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult11HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult11PhoneNbr);
    adult11HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult11AddressPostalCode);
    adult11HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult11DobCPRFormat);

    adult12HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult12HumanCprPatientRequest.getPatientInfo().setFirstName(adult12FirstName);
    adult12HumanCprPatientRequest.getPatientInfo().setLastName(adult12LastName);
    adult12HumanCprPatientRequest.setStoreNbr(Integer.parseInt(virtualStoreNbr));
    adult12HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult12PhoneNbr);
    adult12HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(adult12AddressPostalCode);
    adult12HumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate(adult12DobCPRFormat);

    cprCommonHumanPatientId =
            SharedUtils.createCprAccount(commonHumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult2HumanPatientId =
            SharedUtils.createCprAccount(adult2HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult3HumanPatientId =
            SharedUtils.createCprAccount(adult3HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult5HumanPatientId =
            SharedUtils.createCprAccount(adult5HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult6HumanPatientId =
            SharedUtils.createCprAccount(adult6HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult8HumanPatientId =
            SharedUtils.createCprAccount(adult8HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult9HumanPatientId =
            SharedUtils.createCprAccount(adult9HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult10HumanPatientId =
            SharedUtils.createCprAccount(adult10HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult11HumanPatientId =
            SharedUtils.createCprAccount(adult11HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprAdult12HumanPatientId =
            SharedUtils.createCprAccount(adult12HumanCprPatientRequest, cprPatientUpdateRetrofit);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Updated the idVerificationSource through DR Service
   *
   * @param customerId
   * @return
   * @throws IOException
   */
  private UpdateIdVerificationResponse createIdVerificationInDrService(String customerId, String firstName, String lastName, String postalCode)
          throws IOException {
    UpdateIdVerificationRequest updateIdVerificationRequest =
            UpdateIdVerificationRequest.builder()
                    .payload(
                            UpdateIdVerificationRequest.UpdateIdVerificationRequestPayload.builder()
                                    .customerId(customerId)
                                    .idVerificationSource("EXPERIAN")
                                    .idValidated(Boolean.TRUE.toString())
                                    .personName(UpdateIdVerificationRequest.PersonName.builder()
                                            .firstName(firstName)
                                            .lastName(lastName)
                                            .build())
                                    .postalAddress(UpdateIdVerificationRequest.PostalAddress.builder()
                                            .addressLineOne("927 E 15th St")
                                            .city("FAIRBANKS")
                                            .stateOrProvinceCode("AK")
                                            .countryCode("USA")
                                            .postalCode(postalCode)
                                            .build())
                                    .photoId(UpdateIdVerificationRequest.PhotoId.builder()
                                            .photoIdType("DRV")
                                            .photoIdNumber("90808567456567")
                                            .photoIdState("AR")
                                            .photoIdCountry("US")
                                            .photoIdExpirationDate("06-22-2021")
                                            .build())
                                    .build())
                    .build();
    Response<UpdateIdVerificationResponse> response = null;

    for (int i = 0; i < 3; i++) {
      response = drRetrofit.updateIdVerification(updateIdVerificationRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && response.body().getStatus() != "OK") {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "dr UpdateIdVerification failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }

    return response.body();
  }

  @Test(
      priority = 0,
      description = "Call Create Account By Patient Profile V1 API With Invalid Input Request")
  public void createAccountByPatientProfileInvalidRequest() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
        getCreateAccountByPatientProfileV1Request(commonFirstName, commonLastName, commonDobDPFormat, commonPhoneNbr, commonAddressPostalCode);
    createAccountByPatientInfoV1Request.getCustomerInfo().setTAndCPolicyLanguage(null);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
        accountOrchestratorRetrofit.createAccountByPatientInfoV1(
            commonOnlineAccountId,
            domainId,
            createAccountByPatientInfoV1Request,
            reqId,
            reqTrackingId,
            type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("tAndCPolicyLanguage is null/empty"));
  }

  @Test(
          priority = 1,
          description = "Call Create Account By Patient Profile V1 API With CustomerAccountId is not verified")
  public void createAccountByPatientProfileWithCustomerAccountIdNotVerified() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(commonFirstName, commonLastName, commonDobDPFormat, commonPhoneNbr, commonAddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    commonOnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1034");
    Assert.assertTrue(errorResponse.getMessage().contains(String.format("ID not verified for given customerAccountId. %s", commonOnlineAccountId)));
  }

  @Test(
          priority = 2,
          description = "Call Create Account By Patient Profile V1 API With patient not found in cpr")
  public void createAccountByPatientProfileWithPatientNotFoundInCPR() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult1OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult1OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult1FirstName, adult1LastName, adult1DobDPFormat, adult1PhoneNbr, adult1AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult1OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6005");
    Assert.assertTrue(errorResponse.getMessage().contains("No Profile Found by CPR MPI Search. {}"));
  }

  @Test(
          priority = 3,
          description = "Call Create Account By Patient Profile V1 API With pharmacy account already exists")
  public void createAccountByPatientProfileWithPharmacyAccountAlreadyExists() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult2OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult2OnlineAccountId);
    //creating pharmacy account in account entity
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request = getCreatePharmacyAccountV1Request(adult2StoreNbr, cprAdult2HumanPatientId.toString(), adult2DobDPFormat);
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.createPharmacyAccountV1(adult2OnlineAccountId, domainId,
            createPharmacyAccountV1Request,
            reqId,
            reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult2FirstName, adult2LastName, adult2DobDPFormat, adult2PhoneNbr, adult2AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult2OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2011");
  }

  @Test(
          priority = 4,
          description = "Call Create Account By Patient Profile V1 API Success")
  public void createAccountByPatientProfileSuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult3OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult3OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult3FirstName, adult3LastName, adult3DobDPFormat, adult3PhoneNbr, adult3AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult3OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult3OnlineAccountId);
  }


  @Test(
      priority = 5,
      description = "Call Create Account Without Rx V1 API With Invalid Input Request")
  public void createAccountWithoutRxInvalidRequest() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = true;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
        getCreateAccountWithoutRxV1Request(commonFirstName, commonLastName, commonDobDPFormat, commonPhoneNbr, commonAddressPostalCode);
    createAccountByPatientInfoV1Request.getCustomerInfo().setGender(null);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
        accountOrchestratorRetrofit.createAccountByPatientInfoV1(
            commonOnlineAccountId,
            domainId,
            createAccountByPatientInfoV1Request,
            reqId,
            reqTrackingId,
            type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Gender is null/empty"));
  }

  @Test(
          priority = 6,
          description = "Call Create Account Without Rx V1 API With CustomerAccountId is not verified")
  public void createAccountWithoutRxWithCustomerAccountIdNotVerified() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = true;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountWithoutRxV1Request(commonFirstName, commonLastName, commonDobDPFormat, commonPhoneNbr, commonAddressPostalCode);
    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    commonOnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1034");
    Assert.assertTrue(errorResponse.getMessage().contains(String.format("ID not verified for given customerAccountId. %s", commonOnlineAccountId)));
  }

  @Test(
          priority = 7,
          description = "Call Create Account Without Rx V1 API With patient not found in cpr")
  public void createAccountWithoutRxWithPatientNotFoundInCpr() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = true;
    CommonUtil.logFlowIdentifiers(adult4OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult4OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountWithoutRxV1Request(adult4FirstName, adult4LastName, adult4DobDPFormat, adult4PhoneNbr, adult4AddressPostalCode);
    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult4OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult4OnlineAccountId);
  }

  @Test(
          priority = 8,
          description = "Call Create Account Without Rx V1 API with pharmacy account already exists")
  public void createAccountWithoutRxWithAccountAlreadyExists() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = true;
    CommonUtil.logFlowIdentifiers(adult6OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult6OnlineAccountId);
    //creating pharmacy account in account entity
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request = getCreatePharmacyAccountV1Request(adult6StoreNbr, cprAdult6HumanPatientId.toString(), adult6DobDPFormat);
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.createPharmacyAccountV1(adult6OnlineAccountId, domainId,
            createPharmacyAccountV1Request,
            reqId,
            reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountWithoutRxV1Request(adult6FirstName, adult6LastName, adult6DobDPFormat, adult6PhoneNbr, adult6AddressPostalCode);
    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult6OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2011");
  }

  @Test(
          priority = 9,
          description = "Call Create Account Without Rx V1 API with one cpr profile found success")
  public void createAccountWithoutRxWithOneProfileFoundInCprSuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = true;
    CommonUtil.logFlowIdentifiers(adult5OnlineAccountId, domainId, reqId, reqTrackingId);

    // creating Id Verification in drService
    insertAccountVerificationSuccess(adult5OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountWithoutRxV1Request(adult5FirstName, adult5LastName, adult5DobDPFormat, adult5PhoneNbr, adult5AddressPostalCode);
    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult5OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult5OnlineAccountId);
  }

  @Test(
          priority = 10,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as SQL")
  public void createAccountByPatientProfileWithVerificationFlowAsNewPatientNotFoundInCPR() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult7OnlineAccountId, domainId, reqId, reqTrackingId);

    insertAccountVerificationSuccess(adult7OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult7FirstName, adult7LastName, adult7DobDPFormat, adult7PhoneNbr, adult7AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult7OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6005");
    Assert.assertTrue(errorResponse.getMessage().contains("No Profile Found by CPR MPI Search. {}"));
  }

  @Test(
          priority = 11,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as SQL")
  public void createAccountByPatientProfileWithVerificationFlowAsNewAndPharmacyAccountAlreadyExists() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult8OnlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request = getCreatePharmacyAccountV1Request(adult8StoreNbr, cprAdult8HumanPatientId.toString(), adult8DobDPFormat);
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> apiResponse = accountEntityServiceRetrofit.createPharmacyAccountV1(adult8OnlineAccountId, domainId,
            createPharmacyAccountV1Request,
            reqId,
            reqTrackingId);

    insertAccountVerificationSuccess(adult8OnlineAccountId);
    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult8FirstName, adult8LastName, adult8DobDPFormat, adult8PhoneNbr, adult8AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult8OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2011");
  }

  @Test(
          priority = 12,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as SQL")
  public void createAccountByPatientProfileWithVerificationFlowAsNewSuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult9OnlineAccountId, domainId, reqId, reqTrackingId);
    insertAccountVerificationSuccess(adult9OnlineAccountId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult9FirstName, adult9LastName, adult9DobDPFormat, adult9PhoneNbr, adult9AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult9OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult9OnlineAccountId);
  }

  @Test(
          priority = 13,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as CAANDSQL")
  public void createAccountByPatientProfileSuccessWithDataPresentInSQL() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult10OnlineAccountId, domainId, reqId, reqTrackingId);
    insertAccountVerificationSuccess(adult10OnlineAccountId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult10FirstName, adult10LastName, adult10DobDPFormat, adult10PhoneNbr, adult10AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult10OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult10OnlineAccountId);
  }

  @Test(
          priority = 14,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as CAANDSQL")
  public void createAccountByPatientProfileSuccessWithDataPresentInBoth() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult11OnlineAccountId, domainId, reqId, reqTrackingId);
    insertAccountVerificationSuccess(adult11OnlineAccountId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult11FirstName, adult11LastName, adult11DobDPFormat, adult11PhoneNbr, adult11AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult11OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
    Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
    CreateAccountByPatientInfoV1Response createAccountByPatientInfoV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            createAccountByPatientInfoResponse.body().getPayload()),
                    CreateAccountByPatientInfoV1Response.class);
    Assert.assertEquals(
            createAccountByPatientInfoV1Response.getCustomerAccountId(), adult11OnlineAccountId);
  }

  @Test(
          priority = 15,
          description = "Call Create Account By Patient Profile V1 API With verification.flow as NEW and get.extended.attributes.datasource as CAANDSQL")
  public void createAccountByPatientProfileSuccessWithDataPresentInNone() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Boolean type = false;
    CommonUtil.logFlowIdentifiers(adult12OnlineAccountId, domainId, reqId, reqTrackingId);

    CreateAccountByPatientInfoV1Request createAccountByPatientInfoV1Request =
            getCreateAccountByPatientProfileV1Request(adult12FirstName, adult12LastName, adult12DobDPFormat, adult12PhoneNbr, adult12AddressPostalCode);

    Response<ServiceResponse> createAccountByPatientInfoResponse =
            accountOrchestratorRetrofit.createAccountByPatientInfoV1(
                    adult12OnlineAccountId,
                    domainId,
                    createAccountByPatientInfoV1Request,
                    reqId,
                    reqTrackingId,
                    type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1034");
    Assert.assertTrue(errorResponse.getMessage().contains(String.format("ID not verified for given customerAccountId. %s", adult12OnlineAccountId)));
  }

  public CreateAccountByPatientInfoV1Request getCreateAccountByPatientProfileV1Request(String firstName,
    String lastName, String dob, String phoneNbr, String postalCode){
    return CreateAccountByPatientInfoV1Request.builder()
        .customerInfo(
            CreateAccountByPatientInfoV1Request.CustomerInfo.builder()
                    .firstName(firstName)
                    .lastName(lastName)
                    .dob(dob)
                    .phoneNumber(phoneNbr)
                    .tAndCPolicyLanguage("EN")
                    .gender("F")
                    .address(CreateAccountByPatientInfoV1Request.Address.builder()
                            .addressLine1("927 E 15th St")
                            .city("FAIRBANKS")
                            .state("AK")
                            .country("USA")
                            .zipCode(postalCode)
                            .build())
                .build())
        .build();
  }

  public CreateAccountByPatientInfoV1Request getCreateAccountWithoutRxV1Request(String firstName,
                                                                                String lastName, String dob, String phoneNbr, String postalCode) {
    return CreateAccountByPatientInfoV1Request.builder()
        .customerInfo(CreateAccountByPatientInfoV1Request.CustomerInfo.builder()
                .firstName(firstName)
                .lastName(lastName)
                .dob(dob)
                .phoneNumber(phoneNbr)
                .tAndCPolicyLanguage("EN")
                .gender("F")
                .address(CreateAccountByPatientInfoV1Request.Address.builder()
                        .addressLine1("927 E 15th St")
                        .city("FAIRBANKS")
                        .state("AK")
                        .country("USA")
                        .zipCode(postalCode)
                        .build())
                .build())
        .build();
  }

  @AfterClass
  void cleanUp() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    List<ValidationServiceRequest> requests = Arrays.asList(
            commonHumanCprPatientRequest,
            adult2HumanCprPatientRequest,
            adult3HumanCprPatientRequest);

    for (ValidationServiceRequest request : requests) {
      request.getPatientInfo().setPatientTypeCode(20708);
      try {
        deleteCprAccount(request);
      } catch (IOException e) {
      }
    }

    accountEntityServiceRetrofit.deleteAccountV1(
            commonOnlineAccountId, domainId, reqId, reqTrackingId);
    accountEntityServiceRetrofit.deleteAccountV1(
            adult1OnlineAccountId, domainId, reqId, reqTrackingId);
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
            cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
            && response.body() != null
            && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON(
              "errorMessage",
              String.format(
                      "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                      cprRequest.getPatientId(), response.code()));
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String storeNbr, String patientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(storeNbr)
                            .patientId(patientId)
                            .dob(dob)
                            .build())
            .build();
  }

  public  Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> insertAccountVerificationSuccess(String customerAccountId) throws IOException {

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
            buildInsertAccountVerificationV1Request();


    return
            accountEntityServiceRetrofit.upsertAccountVerificationV1(
                    customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, "INSERT");
  }

  private UpsertAccountVerificationV1Request buildInsertAccountVerificationV1Request() {

    UpsertAccountVerificationV1Request.Address address =
            UpsertAccountVerificationV1Request.Address.builder()
                    .addressLine1("859 Innovation Lab")
                    .city("Bentonville")
                    .state("AR")
                    .country("US")
                    .zipCode("72712")
                    .build();

    UpsertAccountVerificationV1Request.CustomerInfo customerInfo =
            UpsertAccountVerificationV1Request.CustomerInfo.builder()
                    .firstName("Will")
                    .lastName("Smith")
                    .dob("01011990")
                    .phoneNumber("1234567890")
                    .address(address)
                    .build();

    UpsertAccountVerificationV1Request.PhotoId photoId =
            UpsertAccountVerificationV1Request.PhotoId.builder()
                    .type("License")
                    .number("123456")
                    .state("AR")
                    .country("US")
                    .expirationDate("06-22-2030")
                    .build();

    UpsertAccountVerificationV1Request.AccountVerificationData accountVerificationData =
            UpsertAccountVerificationV1Request.AccountVerificationData.builder()
                    .customerInfo(customerInfo)
                    .photoId(photoId)
                    .build();

    UpsertAccountVerificationV1Request.IdVerified idVerified =
            UpsertAccountVerificationV1Request.IdVerified.builder()
                    .status(Boolean.TRUE)
                    .verificationSource("EXPERIAN")
                    .data(accountVerificationData)
                    .build();

    UpsertAccountVerificationV1Request.TwoFASetUp twoFASetUp =
            UpsertAccountVerificationV1Request.TwoFASetUp.builder()
                    .status("ACTIVE")
                    .data(accountVerificationData)
                    .build();

    return UpsertAccountVerificationV1Request.builder().idVerified(idVerified).twoFASetUp(twoFASetUp).build();
  }
}
