package accountorchestrator.customer.delink.link;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.DelinkAndLinkAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.DelinkAndLinkAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerAccountInfoV2Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CAServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.EntityServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.AESUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetAcceptedTermsNConditionPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetCareGiverResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetDependentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetProfileResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMGetPrefDataResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AccountOrchestratorUnderLinkingDelinkLinkAccountTest {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private WCPRetroFit wcpRetrofit;
  private AESUtil aesUtil;
  private final Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private String existingCustomerAccountId;
  private String newCustomerAccountId;
  private List<String> dependentList;
  private List<String> caregiverList;
  private String storeNbr;
  private String patientId;
  private String newStoreNbr;
  private String newPatientId;
  private String dobCPRFormat;
  private String dobDPFormat;
  private String token;
  private String firstName;
  private String lastName;

  private static final String DOMAIN = "WM-PHARMACY";
  private static final String ACCOUNT_TYPE = "INDIVIDUAL";

  @BeforeClass
  void setContext() throws Exception {

    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    wcpRetrofit = new WCPRetroFit();
    aesUtil = new AESUtil();

    dependentList = new ArrayList<>();
    caregiverList = new ArrayList<>();

    storeNbr = CommonUtil.generateRandomNumber(6);
    patientId = CommonUtil.generateRandomNumber(9);

    newStoreNbr = CommonUtil.generateRandomNumber(5);
    newPatientId = CommonUtil.generateRandomNumber(9);

    List<String> mdmdob =Arrays.asList("01011900","01011901","01011801","01012005","01012000","01012001");
    List<String> mdmNames = Arrays.asList("BB", "BG", "DC", "DO", "ER", "FR", "IN", "MY", "NB", "NN", "OK", "RN", "TO", "ACC", "AKA", "BB1", "BB2", "BB3", "BB4", "BB5", "BB6", "BB7", "BB8", "BB9", "BG1", "BG2", "BG3", "BG4", "BG5", "BG6", "BG7", "BG8", "BG9", "BOY", "FLS", "FOR", "MCI", "MRN", "NMI", "NOT", "NSC", "PAY", "PER", "REF", "REG", "SEE", "USE", "ZZZ", "GIRL1", "GIRL2", "GIRL3", "00000", "PROBLEM", "11111", "REGISTERED", "UNIQUE", "22222", "ACCT", "BABY", "BB10", "BBOY", "BG10", "BOY1", "BOY2", "BOY3", "CALL", "EACH", "EDIT", "GIRL", "INFO", "33333", "LINE", "LOAN", "NEED", "NFLS", "ONLY", "DUPLICATE", "TEST", "TIME", "UNKNOWN", "ZZZZ", "DECEASED", "45454", "RETURNS", "BABYBOY", "BABYGIRL", "TRAUMA", "ALERT", "66666", "PATIENT", "BGIRL", "77777", "PHARMACY", "88888", "CONFIDENTIAL", "99999", "PURGED", "REFER", "ERROR", "NOFIRSTNAME", "NOLASTNAME", "FRAUD");


    Random random = new Random();
    firstName = mdmNames.get(random.nextInt(mdmNames.size()));
    lastName = mdmNames.get(random.nextInt(mdmNames.size()));
    dobDPFormat = mdmdob.get(random.nextInt(mdmdob.size()));
    SimpleDateFormat dpFormat = new SimpleDateFormat("MMddyyyy");
    dobCPRFormat = (new SimpleDateFormat("yyyy-MM-dd")).format(dpFormat.parse(dobDPFormat));

    Reporter.logJSON("dobCPRFormat", dobCPRFormat);
    Reporter.logJSON("dobDPFormat", dobDPFormat);

    createDataInCA();
    createDependentLinkageInCA();
    createCaregiverLinkageInCA();
    CAServiceHelper.callCACreateTAndCAPI(
        wcpRetrofit,
        existingCustomerAccountId,
        CAServiceHelper.buildCACreateAcceptedTermsNConditionPreferencesRequest(
            "Reviewed in English"));

    CAServiceHelper.callCACreateTAndCAPI(
            wcpRetrofit,
            newCustomerAccountId,
            CAServiceHelper.buildCACreateAcceptedTermsNConditionPreferencesRequest(
                    "Reviewed in English"));

    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit,
        storeNbr,
        patientId,
        dobCPRFormat,
        firstName,
        lastName);

    Thread.sleep(10000);

    EntityServiceHelper.createPharmacyAccount(
        accountEntityServiceRetrofit,
        existingCustomerAccountId,
        DOMAIN,
        EntityServiceHelper.buildCreatePharmacyAccountV1Request(
            storeNbr, patientId, dobDPFormat, "smsOtpVerification"));

    CPRServiceHelper.createAccountInCPR(
            cprPatientUpdateRetrofit,
            newStoreNbr,
            newPatientId,
            dobCPRFormat,
            firstName,
            lastName);

    Thread.sleep(10000);

    EntityServiceHelper.createPharmacyAccount(
            accountEntityServiceRetrofit,
            newCustomerAccountId,
            DOMAIN,
            EntityServiceHelper.buildCreatePharmacyAccountV1Request(
                    newStoreNbr, newPatientId, dobDPFormat, "smsOtpVerification"));


    token = aesUtil.encrypt(existingCustomerAccountId);

    Reporter.logJSON("storeNbr", storeNbr);
    Reporter.logJSON("patientId", patientId);
    Reporter.logJSON("newStoreNbr", newStoreNbr);
    Reporter.logJSON("newPatientId", newPatientId);
    Reporter.logJSON("token", token);
  }

  private void createDataInCA() throws Exception {
    existingCustomerAccountId =
            CAServiceHelper.callCACreatePersonAPI(
                    wcpRetrofit,
                    getCAIndividualAccount());
    newCustomerAccountId =
            CAServiceHelper.callCACreatePersonAPI(
                    wcpRetrofit,
                    getCAIndividualAccount());

    for (int i = 0; i < 3; i++) {
      dependentList.add(
              CAServiceHelper.callCACreatePersonAPI(
                      wcpRetrofit,
                      getCAIndividualAccount()));
      caregiverList.add(
              CAServiceHelper.callCACreatePersonAPI(
                      wcpRetrofit,
                      getCAIndividualAccount()));
    }

    Reporter.logJSON("existingCustomerAccountId", existingCustomerAccountId);
    Reporter.logJSON("newCustomerAccountId", newCustomerAccountId);
    dependentList.forEach(dependentId -> Reporter.logJSON("dependentId", dependentId));
    caregiverList.forEach(caregiverId -> Reporter.logJSON("caregiverId", caregiverId));
  }

  private CACreatePersonRequest getCAIndividualAccount(){
    CACreatePersonRequest  caCreatePersonRequest = CAServiceHelper.buildCACreatePersonRequest(
            ACCOUNT_TYPE, CommonUtil.generateRandomEmailId(10));
    caCreatePersonRequest.getPayload().getPerson().setCustomerType("INDIVIDUAL");
    return caCreatePersonRequest;
  }

  private void createDependentLinkageInCA() {
    dependentList.forEach(
        dependentCid -> {
          try {
            CAServiceHelper.callCAAddDependentAPI(
                wcpRetrofit,
                CAServiceHelper.buildCAAddDependentRequest(
                    existingCustomerAccountId,
                    dependentCid,
                    DependentInfo.TypeEnum.ADULT,
                    DependentInfo.LinkageStatusEnum.ACTIVE));
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
  }

  private void createCaregiverLinkageInCA() {
    caregiverList.forEach(
        caregiverCid -> {
          try {
            CAServiceHelper.callCAAddDependentAPI(
                wcpRetrofit,
                CAServiceHelper.buildCAAddDependentRequest(
                    caregiverCid,
                    existingCustomerAccountId,
                    DependentInfo.TypeEnum.ADULT,
                    DependentInfo.LinkageStatusEnum.ACTIVE));
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
  }

  @Test(priority = 1, description = "Delink link account invalid domain")
  public void delinkAndLinkAccountV1InvalidDomain() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId,
            "dummy",
            buildDelinkAndLinkAccountV1Request(),
            reqId,
            reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("domainId"));
    Assert.assertTrue(errorResponse.getMessage().contains("is invalid"));
  }

  @Test(priority = 2, description = "Delink link account invalid token")
  public void delinkAndLinkAccountV1InvalidToken() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setToken(UUID.randomUUID().toString());

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 500, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1007");
    Assert.assertTrue(errorResponse.getMessage().contains("Error decrypting token"));
  }

  @Test(priority = 3, description = "Delink link account 400 from CA while get dependents")
  public void delinkAndLinkAccountV1400FromCA() throws IOException, GeneralSecurityException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();
    String cid = UUID.randomUUID().toString();
    cid = cid.substring(0, cid.length() - 2);
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(cid));

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7002");
    Assert.assertTrue(errorResponse.getMessage().contains("Invalid customerAccountId"));
  }

  @Test(priority = 4, description = "Delink link account 404 from CA while get dependents")
  public void delinkAndLinkAccountV1404FromCA() throws IOException, GeneralSecurityException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();
    String cid = UUID.randomUUID().toString();
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(cid));

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertTrue(
        errorResponse
            .getMessage()
            .contains("No information found for given customerAccountId in CA"));
  }

  @Test(priority = 5, description = "Delink link account, account not found error")
  public void delinkAndLinkAccountNotFoundError() throws Exception {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    String cid1 =
        CAServiceHelper.callCACreatePersonAPI(
            wcpRetrofit,
            CAServiceHelper.buildCACreatePersonRequest(
                ACCOUNT_TYPE, CommonUtil.generateRandomEmailId(10)));

    String cid2 =
        CAServiceHelper.callCACreatePersonAPI(
            wcpRetrofit,
            CAServiceHelper.buildCACreatePersonRequest(
                ACCOUNT_TYPE, CommonUtil.generateRandomEmailId(10)));

    CAServiceHelper.callCAAddDependentAPI(
        wcpRetrofit,
        CAServiceHelper.buildCAAddDependentRequest(
            cid1, cid2, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE));

    CAServiceHelper.callCACreateTAndCAPI(
        wcpRetrofit,
        cid2,
        CAServiceHelper.buildCACreateAcceptedTermsNConditionPreferencesRequest(
            "Reviewed in English"));

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(cid2));

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 204, errorMessage);
   // Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
   // Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }


  @Test(priority = 6, description = "Delink link account, account already exists error")
  public void delinkAndLinkAccountAlreadyExistsError() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            existingCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6001");
  }

  @Test(
      priority = 7,
      description =
          "Delink link account, verify new cid does not have any TAndC present after API error due to account already exists")
  public void delinkAndLinkAccountNewCIDNoTAndCPresentAsyncOperationVerification2()
          throws Exception {

    Thread.sleep(2000);

    Response<WCPGetAcceptedTermsNConditionPreferencesResponse> caResponse =
        CAServiceHelper.getAcceptedTermsNConditionPreference(wcpRetrofit, existingCustomerAccountId);

    Assert.assertEquals(
        caResponse.body().getPayload().getAcceptedTermsAndConditions().size(),
        1,
        "Async operation to delete TAndC for new cid on API error failed");
  }

  @Test(priority = 8, description = "Delink link account success")
  public void delinkAndLinkAccountSuccess() throws IOException, InterruptedException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        buildDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId,true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 200, errorMessage);

    DelinkAndLinkAccountV1Response delinkAndLinkAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) response.body().getPayload()),
            DelinkAndLinkAccountV1Response.class);

    Assert.assertEquals(
        delinkAndLinkAccountV1Response.getCustomerAccountId(), newCustomerAccountId);

    // let all the async operations complete for further verification
    Thread.sleep(10000);
  }

  @Test(
      priority = 9,
      description = "Delink link account, verify new cid has TAndC present after API success")
  public void delinkAndLinkAccountNewCIDTAndCPresent() throws Exception {

    Response<WCPGetAcceptedTermsNConditionPreferencesResponse> caResponse =
        CAServiceHelper.getAcceptedTermsNConditionPreference(wcpRetrofit, newCustomerAccountId);

    Assert.assertEquals(
        caResponse.body().getPayload().getAcceptedTermsAndConditions().size(),
        1,
        "New CID does not have TAndC present");

    Assert.assertEquals(
        caResponse.body().getPayload().getAcceptedTermsAndConditions().get(0).getDescription(),
        "Reviewed in English",
        "New CID has different TAndC than what is expected");
  }

  @Test(
      priority = 10,
      description =
          "Delink link account, verify existing cid has no TAndC present after API success")
  public void delinkAndLinkAccountExistingCIDNoTAndCPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetAcceptedTermsNConditionPreferencesResponse> caResponse =
        CAServiceHelper.getAcceptedTermsNConditionPreference(wcpRetrofit, existingCustomerAccountId);

    Assert.assertEquals(
        caResponse.body().getPayload().getAcceptedTermsAndConditions().size(),
        0,
        "Existing CID still has TAndC present");
  }

  @Test(
      priority = 11,
      description =
          "Delink link account, verify new cid has extra links present after API success")
  public void delinkAndLinkAccountNewCIDHasStoreProfilePresentAsyncOperationVerification()
      throws IOException {

    Response<ServiceResponse> response = accountOrchestratorRetrofit.getCustomerInfoV2(newCustomerAccountId,DOMAIN,false,false,null,false,false,false, false, false);
    GetCustomerAccountInfoV2Response getCustomerAccountInfoV2Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);
    Assert.assertEquals(newStoreNbr, getCustomerAccountInfoV2Response.getCustomerInfo().getAuthStoreNbr());
    Assert.assertEquals(newPatientId, getCustomerAccountInfoV2Response.getCustomerInfo().getAuthPatientId());

    Assert.assertEquals(2, getCustomerAccountInfoV2Response.getCustomerInfo().getPatientLinks().size());

  }

  @Test(
      priority = 12,
      description =
          "Delink link account, verify existing cid has no auth store nbr and auth patient id present after API success")
  public void delinkAndLinkAccountExistingCIDHasNoStoreProfilePresentAsyncOperationVerification()
      throws IOException {

    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
        serviceResponse =
            EntityServiceHelper.getPharmacyOnlineIdentityV1(
                accountEntityServiceRetrofit, existingCustomerAccountId, DOMAIN);

    Assert.assertEquals(204, serviceResponse.code());
  }

  @Test(
      priority = 13,
      description = "Delink link account, verify enrollment in DM for new cid after API success")
  public void delinkAndLinkAccountNewCidHasDMEnrollmentPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetProfileResponse> wcpProfileResponse =
        CAServiceHelper.getPersonByCustomerAccountId(wcpRetrofit, newCustomerAccountId);
    String expectedEmail =
        wcpProfileResponse.body().getPayload().getAccount().getEmailAddress();

    List<String> shortCodeTypes = new ArrayList<>();
    shortCodeTypes.add("RX");
    shortCodeTypes.add("CS");

    Response<DMGetPrefDataResponse> dmResponse =
        DMServiceHelper.getPrefData(
            dmPostPreferencesRetrofit,
            DMServiceHelper.buildDMGetPrefDataRequest(
                patientId, storeNbr, "1", "true", shortCodeTypes));
    String actualEmail = dmResponse.body().getPatientPreferences().get(0).getNotificationVal();

    Assert.assertEquals(expectedEmail, actualEmail);
    Assert.assertEquals(
        "26802", dmResponse.body().getPatientPreferences().get(0).getEnrollmentStatusCode());
  }

  @Test(
      priority = 14,
      description = "Delink link account, existing cid to not have any caregiver after API success")
  public void delinkAndLinkAccountExistingCidHasNoCaregiverPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetCareGiverResponse> response =
        CAServiceHelper.getCaregivers(wcpRetrofit, existingCustomerAccountId);

    Assert.assertEquals(response.body().getPayload().getOwners().size(), 0);
  }

  @Test(
      priority = 15,
      description =
          "Delink link account, existing cid to not have any dependents after API success")
  public void delinkAndLinkAccountExistingCidHasNoDependentPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetDependentsResponse> response =
        CAServiceHelper.getDependents(wcpRetrofit, existingCustomerAccountId);

    Assert.assertEquals(response.body().getPayload().getDependents().size(), 0);
  }

  @Test(
      priority = 16,
      description =
          "Delink link account, new cid to have all caregivers of existing cid after API success")
  public void delinkAndLinkAccountNewCidHasAllCaregiversPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetCareGiverResponse> response =
        CAServiceHelper.getCaregivers(wcpRetrofit, newCustomerAccountId);

    Assert.assertEquals(response.body().getPayload().getOwners().size(), 3);
    Assert.assertTrue(
        caregiverList.contains(
            response
                .body()
                .getPayload()
                .getOwners()
                .get(0)
                .getPerson()
                .getCustomerAccountId()
                .toString()));
    Assert.assertTrue(
        caregiverList.contains(
            response
                .body()
                .getPayload()
                .getOwners()
                .get(1)
                .getPerson()
                .getCustomerAccountId()
                .toString()));
    Assert.assertTrue(
        caregiverList.contains(
            response
                .body()
                .getPayload()
                .getOwners()
                .get(2)
                .getPerson()
                .getCustomerAccountId()
                .toString()));
  }

  @Test(
      priority = 17,
      description =
          "Delink link account, new cid to have all dependents of existing cid after API success")
  public void delinkAndLinkAccountNewCidHasAllDependentsPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetDependentsResponse> response =
        CAServiceHelper.getDependents(wcpRetrofit, newCustomerAccountId);

    Assert.assertEquals(response.body().getPayload().getDependents().size(), 3);
    Assert.assertTrue(
        dependentList.contains(
            response
                .body()
                .getPayload()
                .getDependents()
                .get(0)
                .getDependent()
                .getMemberId()
                .getId()
                .toString()));
    Assert.assertTrue(
        dependentList.contains(
            response
                .body()
                .getPayload()
                .getDependents()
                .get(1)
                .getDependent()
                .getMemberId()
                .getId()
                .toString()));
    Assert.assertTrue(
        dependentList.contains(
            response
                .body()
                .getPayload()
                .getDependents()
                .get(2)
                .getDependent()
                .getMemberId()
                .getId()
                .toString()));
  }

  @Test(
          priority = 18,
          description =
                  "Delink link account, Existing CID doesnt exist success")
  public void delinkAndLinkAccountExistingCIdDoesntExist()
          throws IOException {


    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response  = EntityServiceHelper.getPharmacyOnlineIdentityV1(accountEntityServiceRetrofit,existingCustomerAccountId,DOMAIN);

    Assert.assertEquals(response.code(), 204);
  }

  private DelinkAndLinkAccountV1Request buildDelinkAndLinkAccountV1Request() {
    return DelinkAndLinkAccountV1Request.builder().token(token).build();
  }
}
