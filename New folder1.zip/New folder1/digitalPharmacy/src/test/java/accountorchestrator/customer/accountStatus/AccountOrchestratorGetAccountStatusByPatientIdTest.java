package accountorchestrator.customer.accountStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.GetAccountStatusByPatientIdV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.WalmartPlusStatus;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateStageISACRecordV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.AttributeFilters;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CustomerInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.FilterOptions;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.GetAccountStatusByPatientIdV1Request;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static accountorchestrator.utils.CommonAccountHelper.addWalmartPlusMembershipViaAstro;
import static accountorchestrator.utils.CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName;
import static accountorchestrator.utils.CommonAccountHelper.createGuestAccountWithWCPWithRandomName;

public class AccountOrchestratorGetAccountStatusByPatientIdTest {

  // ─────────────────────────────────────────────────────────────────────────
  // Infrastructure retrofits
  // ─────────────────────────────────────────────────────────────────────────
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;

  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();

  // ─────────────────────────────────────────────────────────────────────────
  // Shared DOB fields – initialised dynamically in setContext()
  // ─────────────────────────────────────────────────────────────────────────
  /**
   * Entity DOB format: MMddyyyy (used by AccountEntityService).
   * Set to ~30 years before the current date so the simulated patient is
   * always a valid adult regardless of when the test suite runs.
   */
  private String entityDob;
  /**
   * CPR DOB format: yyyy-MM-dd (used by CprPatientUpdateRetrofit).
   * Derived from the same base date as {@link #entityDob} to keep both in sync.
   */
  private String cprDob;

  private final String domainId          = "WM-PHARMACY";
  private final String reqIdString       = "req-id-";
  private final String reqTrackingString = "req-tracking-";
  private final String accountCreationSource = "smsOtpVerification";

  // ─────────────────────────────────────────────────────────────────────────
  // CPR requests (needed for @AfterClass cleanup)
  // ─────────────────────────────────────────────────────────────────────────
  private final List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 1  – CPR only (P3: entity 204, ISAC 204 → NOT_CREATED)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult1CprRequest;
  private Integer cprAdult1PatientId;
  private String adult1StoreNbr;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 2  – CPR + ISAC(idVerified=true)  (P4: ISAC_PENDING + ID_VERIFIED)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult2CprRequest;
  private Integer cprAdult2PatientId;
  private String adult2StoreNbr;
  private String adult2EmailId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 3  – CPR + ISAC(idVerified=false) (P5: ISAC_PENDING + NOT_ID_VERIFIED)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult3CprRequest;
  private Integer cprAdult3PatientId;
  private String adult3StoreNbr;
  private String adult3EmailId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 4  – CPR + CA(non-GUEST) + entity  (P6: ACTIVE, onlyCustomerInfo=false)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult4CprRequest;
  private Integer cprAdult4PatientId;
  private String adult4StoreNbr;
  private String adult4EmailId;
  private String adult4CustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 5  – CPR + CA(non-GUEST) + entity  (P7: customerInfo only, onlyCustomerInfo=true)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult5CprRequest;
  private Integer cprAdult5PatientId;
  private String adult5StoreNbr;
  private String adult5EmailId;
  private String adult5CustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 6  – CPR + CA(GUEST) + entity      (P8: NOT_ELIGIBLE)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult6CprRequest;
  private Integer cprAdult6PatientId;
  private String adult6StoreNbr;
  private String adult6GuestCustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 7  – CPR + entity(randomCID)       (P9: CA 404 → NOT_CREATED, onlyCustomerInfo=false)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult7CprRequest;
  private Integer cprAdult7PatientId;
  private String adult7StoreNbr;
  private String adult7RandomCustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 8  – CPR + entity(randomCID)       (P10: CA 404, onlyCustomerInfo=true → 204)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult8CprRequest;
  private Integer cprAdult8PatientId;
  private String adult8StoreNbr;
  private String adult8RandomCustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // Adult 9  – CPR + CA(non-GUEST + WalmartPlus) + entity  (P11: ACTIVE + walmartPlusStatus)
  // ─────────────────────────────────────────────────────────────────────────
  private ValidationServiceRequest adult9CprRequest;
  private Integer cprAdult9PatientId;
  private String adult9StoreNbr;
  private String adult9EmailId;
  private String adult9CustomerAccountId;

  // ─────────────────────────────────────────────────────────────────────────
  // @BeforeClass – pre-create ALL accounts so tests are independent
  // ─────────────────────────────────────────────────────────────────────────
  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit  = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit     = new CprPatientUpdateRetrofit();

    // Generate DOBs dynamically: ~30 years in the past to represent a valid adult patient.
    // Both formats are derived from the same base date so they always stay in sync.
    Date dob  = new Date(System.currentTimeMillis() - 30L * 365 * 24 * 60 * 60 * 1000);
    cprDob    = new SimpleDateFormat("yyyy-MM-dd").format(dob);  // e.g. "1996-03-24"
    entityDob = new SimpleDateFormat("MMddyyyy").format(dob);    // e.g. "03241996"

    initAdultFields();
    createAllCprAccounts();          // batch CPR creation + 50s wait
    createAllSetupAccounts();        // CA, entity, ISAC (depend on CPR patientIds)
  }

  /**
   * Initialise per-adult identifiers (storeNbr, emailId, names, phone).
   * All names are UPPER-CASE alpha strings to match CPR template requirements.
   */
  private void initAdultFields() {
    adult1StoreNbr = CommonUtil.generateRandomNumber(6);

    adult2StoreNbr = CommonUtil.generateRandomNumber(6);
    adult2EmailId  = CommonUtil.generateRandomEmailId(10);

    adult3StoreNbr = CommonUtil.generateRandomNumber(6);
    adult3EmailId  = CommonUtil.generateRandomEmailId(10);

    adult4StoreNbr = CommonUtil.generateRandomNumber(6);
    adult4EmailId  = CommonUtil.generateRandomEmailId(10);

    adult5StoreNbr = CommonUtil.generateRandomNumber(6);
    adult5EmailId  = CommonUtil.generateRandomEmailId(10);

    adult6StoreNbr = CommonUtil.generateRandomNumber(6);

    adult7StoreNbr = CommonUtil.generateRandomNumber(6);
    adult7RandomCustomerAccountId = CommonUtil.randomUUID();

    adult8StoreNbr = CommonUtil.generateRandomNumber(6);
    adult8RandomCustomerAccountId = CommonUtil.randomUUID();

    adult9StoreNbr = CommonUtil.generateRandomNumber(6);
    adult9EmailId  = CommonUtil.generateRandomEmailId(10);
  }

  /**
   * Build CPR requests for all 9 adults, call {@link SharedUtils#createCprAccount} for each,
   * collect them in the cleanup list, then wait 50 seconds for async CPR propagation.
   */
  private void createAllCprAccounts() throws IOException {
    adult1CprRequest = buildCprRequest(adult1StoreNbr);
    adult2CprRequest = buildCprRequest(adult2StoreNbr);
    adult3CprRequest = buildCprRequest(adult3StoreNbr);
    adult4CprRequest = buildCprRequest(adult4StoreNbr);
    adult5CprRequest = buildCprRequest(adult5StoreNbr);
    adult6CprRequest = buildCprRequest(adult6StoreNbr);
    adult7CprRequest = buildCprRequest(adult7StoreNbr);
    adult8CprRequest = buildCprRequest(adult8StoreNbr);
    adult9CprRequest = buildCprRequest(adult9StoreNbr);

    cprAdult1PatientId = SharedUtils.createCprAccount(adult1CprRequest, cprPatientUpdateRetrofit);
    cprAdult2PatientId = SharedUtils.createCprAccount(adult2CprRequest, cprPatientUpdateRetrofit);
    cprAdult3PatientId = SharedUtils.createCprAccount(adult3CprRequest, cprPatientUpdateRetrofit);
    cprAdult4PatientId = SharedUtils.createCprAccount(adult4CprRequest, cprPatientUpdateRetrofit);
    cprAdult5PatientId = SharedUtils.createCprAccount(adult5CprRequest, cprPatientUpdateRetrofit);
    cprAdult6PatientId = SharedUtils.createCprAccount(adult6CprRequest, cprPatientUpdateRetrofit);
    cprAdult7PatientId = SharedUtils.createCprAccount(adult7CprRequest, cprPatientUpdateRetrofit);
    cprAdult8PatientId = SharedUtils.createCprAccount(adult8CprRequest, cprPatientUpdateRetrofit);
    cprAdult9PatientId = SharedUtils.createCprAccount(adult9CprRequest, cprPatientUpdateRetrofit);

    cprProfilesToBeDeletedList.add(adult1CprRequest);
    cprProfilesToBeDeletedList.add(adult2CprRequest);
    cprProfilesToBeDeletedList.add(adult3CprRequest);
    cprProfilesToBeDeletedList.add(adult4CprRequest);
    cprProfilesToBeDeletedList.add(adult5CprRequest);
    cprProfilesToBeDeletedList.add(adult6CprRequest);
    cprProfilesToBeDeletedList.add(adult7CprRequest);
    cprProfilesToBeDeletedList.add(adult8CprRequest);
    cprProfilesToBeDeletedList.add(adult9CprRequest);

    // CPR account creation is async; wait for propagation before creating entity/ISAC records
    try {
      Thread.sleep(50000);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }

  /**
   * Creates CA accounts, entity pharmacy accounts, and ISAC records after CPR accounts
   * have propagated. Each adult's setup is self-contained for its target test scenario.
   */
  private void createAllSetupAccounts() throws Exception {
    String setupTrackId      = CommonUtil.randomUUID();
    String setupReqId        = reqIdString + setupTrackId;
    String setupReqTrackId   = reqTrackingString + setupTrackId;

    // ── Adult 2: ISAC stage record with isIdVerified=true (P4) ──────────────
    createStageIsacRecord(
        adult2StoreNbr, cprAdult2PatientId, adult2EmailId, entityDob,
        setupReqId, setupReqTrackId, Boolean.TRUE);
    addWalmartPlusMembershipViaAstro(adult2EmailId);

    // ── Adult 3: ISAC stage record with isIdVerified=false (P5) ─────────────
    createStageIsacRecord(
        adult3StoreNbr, cprAdult3PatientId, adult3EmailId, entityDob,
        setupReqId, setupReqTrackId, Boolean.FALSE);
    addWalmartPlusMembershipViaAstro(adult3EmailId);

    // ── Adult 4: CA non-GUEST + entity pharmacy account (P6) ─────────────────
    adult4CustomerAccountId =
        createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult4EmailId);
    addWalmartPlusMembershipViaAstro(adult4EmailId);
    createPharmacyAccount(
        adult4CustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult4StoreNbr, cprAdult4PatientId.toString()),
        setupReqId, setupReqTrackId);

    // ── Adult 5: CA non-GUEST + entity pharmacy account (P7) ─────────────────
    adult5CustomerAccountId =
        createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult5EmailId);
    addWalmartPlusMembershipViaAstro(adult5EmailId);
    createPharmacyAccount(
        adult5CustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult5StoreNbr, cprAdult5PatientId.toString()),
        setupReqId, setupReqTrackId);

    // ── Adult 6: CA GUEST account + entity pharmacy account (P8) ─────────────
    // createGuestAccountWithWCPWithRandomName takes DOB in yyyy-MM-dd format
    adult6GuestCustomerAccountId = createGuestAccountWithWCPWithRandomName(cprDob);
    createPharmacyAccount(
        adult6GuestCustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult6StoreNbr, cprAdult6PatientId.toString()),
        setupReqId, setupReqTrackId);

    // ── Adult 7: entity pharmacy account linked to random CID (P9) ───────────
    // CA will return 404 for this randomUUID CID → NOT_CREATED, onlyCustomerInfo=false
    createPharmacyAccount(
        adult7RandomCustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult7StoreNbr, cprAdult7PatientId.toString()),
        setupReqId, setupReqTrackId);

    // ── Adult 8: entity pharmacy account linked to random CID (P10) ──────────
    // CA will return 404 for this randomUUID CID → 204, onlyCustomerInfo=true
    createPharmacyAccount(
        adult8RandomCustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult8StoreNbr, cprAdult8PatientId.toString()),
        setupReqId, setupReqTrackId);

    // ── Adult 9: CA non-GUEST + WalmartPlus + entity pharmacy account (P11) ──
    adult9CustomerAccountId =
        createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult9EmailId);
    addWalmartPlusMembershipViaAstro(adult9EmailId);
    createPharmacyAccount(
        adult9CustomerAccountId, domainId,
        buildCreatePharmacyAccountV1Request(adult9StoreNbr, cprAdult9PatientId.toString()),
        setupReqId, setupReqTrackId);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // @AfterClass – mark all CPR accounts as deleted (patientStatusCode=20708)
  // ─────────────────────────────────────────────────────────────────────────
  @AfterClass
  void cleanUp() throws IOException {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    cprProfilesToBeDeletedList.forEach(
        request -> {
          request.getPatientInfo().setPatientStatusCode(20708);
          try {
            Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(request);
            if (!(response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty())) {
              throw new RuntimeException(
                  "CPR Account cleanup failed (patientStatusCode=20708). HTTP: " + response.code());
            }
          } catch (IOException e) {
            // log but do not fail cleanup
            Reporter.logJSON("CPR cleanup error", e.getMessage());
          }
        });
  }

  // =========================================================================
  //  Test methods
  // =========================================================================

  // ── P0: Validation – null patientId → 400 ─────────────────────────────────
  @Test(priority = 0, description = "Null patientId in request → 400 DPR-DPACCOR-1001")
  public void getAccountStatusByPatientIdV1_NullPatientId_Returns400() throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    CommonUtil.logFlowIdentifiers(reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(CommonUtil.generateRandomNumber(5), null),
            "false",
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001", errorMessage);
  }

  // ── P1: Validation – null storeNbr → 400 ──────────────────────────────────
  @Test(priority = 1, description = "Null storeNbr in request → 400 DPR-DPACCOR-1001")
  public void getAccountStatusByPatientIdV1_NullStoreNbr_Returns400() throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    CommonUtil.logFlowIdentifiers(reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(null, CommonUtil.generateRandomNumber(9)),
            "false",
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001", errorMessage);
  }

  // ── P2: Entity 204 + onlyCustomerInfo=true → 204 ─────────────────────────
  /**
   * When the entity service returns 204 (no account for this storeNbr/patientId) AND
   * {@code onlyCustomerInfo=true}, the service throws ACCOUNT_ENTITY_SERVICE_NO_CONTENT_EXCEPTION
   * which maps to HTTP 204 for the caller.
   * Uses fully random storeNbr/patientId so entity always returns 204.
   */
  @Test(priority = 2, description =
      "Flag=true: entity 204 + onlyCustomerInfo=true → API 204 (no-content)")
  public void getAccountStatusByPatientIdV1_Entity204OnlyCustomerInfoTrue_Returns204()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    String storeNbr      = CommonUtil.generateRandomNumber(6);
    String patientId     = CommonUtil.generateRandomNumber(9);
    logFlowIdentifiers(storeNbr, patientId, domainId, reqId, reqTrackingId);

    // No entity pharmacy account for these random credentials → entity returns 204
    // onlyCustomerInfo=true → service returns 204 immediately without checking ISAC
    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(storeNbr, patientId),
            "true",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 204, errorMessage);
  }

  // ── P3: Entity 204 + ISAC 204 (no record) → NOT_CREATED ──────────────────
  /**
   * Adult1 has a CPR account but NO entity pharmacy account and NO ISAC record.
   * Entity service returns 204 → ISAC check triggered (onlyCustomerInfo=false).
   * ISAC service returns 204 (no record) → account.status = NOT_CREATED.
   */
  @Test(priority = 3, description =
      "Flag=true: entity 204 + ISAC 204 (no ISAC record) → account.status=NOT_CREATED")
  public void getAccountStatusByPatientIdV1_Entity204IsacNotFound_ReturnsNotCreated()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult1StoreNbr, cprAdult1PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult1StoreNbr, cprAdult1PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "NOT_CREATED",
        "Expected NOT_CREATED when no ISAC record exists");
    Assert.assertNull(body.getCustomerInfo(),
        "customerInfo must be null for NOT_CREATED status");
  }

  // ── P4: Entity 204 + ISAC 200 (idVerified=true) → ISAC_PENDING + ID_VERIFIED ──
  /**
   * Adult2 has a CPR account and an ISAC record with {@code isIdVerified=true}
   * created via {@link #createStageIsacRecord} with {@code idVerified=true}.
   * Entity service returns 204 → ISAC check triggered.
   * ISAC returns 200 with {@code idVerified=true} and {@code linkExpired=false}
   * → account.status=ISAC_PENDING, account.code=ID_VERIFIED.
   */
  @Test(priority = 4, description =
      "Flag=true: entity 204 + ISAC 200 (idVerified=true, linkNotExpired) "
          + "→ ISAC_PENDING + code=ID_VERIFIED")
  public void getAccountStatusByPatientIdV1_Entity204IsacIdVerifiedTrue_IsacPendingIdVerified()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult2StoreNbr, cprAdult2PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult2StoreNbr, cprAdult2PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "ISAC_PENDING");

    Assert.assertNotNull(body.getAccount().getCode(), "account.code must not be null");
    Assert.assertEquals(body.getAccount().getCode(), "ID_VERIFIED",
        "Expected account.code=ID_VERIFIED but got: " + body.getAccount().getCode());

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must be present");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult2EmailId,
        "customerInfo.emailId must match the ISAC record email");
  }

  // ── P5: Entity 204 + ISAC 200 (idVerified=false) → ISAC_PENDING + NOT_ID_VERIFIED ──
  /**
   * Adult3 has a CPR account and an ISAC record with {@code isIdVerified=false}
   * created via {@link #createStageIsacRecord} with {@code idVerified=false}.
   * ISAC returns 200 with {@code idVerified=false} and {@code linkExpired=false}
   * → account.status=ISAC_PENDING, account.code=NOT_ID_VERIFIED.
   */
  @Test(priority = 5, description =
      "Flag=true: entity 204 + ISAC 200 (idVerified=false, linkNotExpired) "
          + "→ ISAC_PENDING + code=NOT_ID_VERIFIED")
  public void getAccountStatusByPatientIdV1_Entity204IsacIdVerifiedFalse_IsacPendingNotIdVerified()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult3StoreNbr, cprAdult3PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult3StoreNbr, cprAdult3PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "ISAC_PENDING");

    Assert.assertNotNull(body.getAccount().getCode(), "account.code must not be null");
    Assert.assertEquals(body.getAccount().getCode(), "NOT_ID_VERIFIED",
        "Expected account.code=NOT_ID_VERIFIED but got: " + body.getAccount().getCode());

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must be present");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult3EmailId,
        "customerInfo.emailId must match the ISAC record email");
  }

  // ── P6: Entity 200 + CA non-GUEST + onlyCustomerInfo=false → ACTIVE ──────
  /**
   * Adult4 has a CPR account, a CA non-GUEST account, and an entity pharmacy account
   * linking the CPR patientId to the CA CID.
   * Entity returns 200 → CA GetPersonByCustomerAccountId returns 200 (non-GUEST)
   * → setAccountStatusEmailIdAndWPlusStatus → status=ACTIVE + customerInfo populated.
   */
  @Test(priority = 6, description =
      "Flag=true: entity 200 + CA non-GUEST + onlyCustomerInfo=false "
          + "→ ACTIVE + customerInfo(emailId, customerAccountId)")
  public void getAccountStatusByPatientIdV1_Entity200NonGuest_ActiveWithCustomerInfo()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult4StoreNbr, cprAdult4PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult4StoreNbr, cprAdult4PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "ACTIVE",
        "Expected ACTIVE for non-GUEST CA account");

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must not be null");
    Assert.assertNotNull(body.getCustomerInfo().getEmailId(),
        "customerInfo.emailId must not be null");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult4EmailId,
        "customerInfo.emailId must match the CA account email");
    Assert.assertNotNull(body.getCustomerInfo().getCustomerAccountId(),
        "customerInfo.customerAccountId must not be null");
    Assert.assertEquals(body.getCustomerInfo().getCustomerAccountId(), adult4CustomerAccountId,
        "customerInfo.customerAccountId must match the CA CID");
  }

  // ── P7: Entity 200 + CA non-GUEST + onlyCustomerInfo=true → customerInfo only ──
  /**
   * Adult5 is equivalent to adult4 but queried with {@code onlyCustomerInfo=true}.
   * When onlyCustomerInfo=true and the account is ACTIVE, the response must contain
   * only the customerInfo block (no account field).
   */
  @Test(priority = 7, description =
      "Flag=true: entity 200 + CA non-GUEST + onlyCustomerInfo=true "
          + "→ customerInfo only (no account field)")
  public void getAccountStatusByPatientIdV1_Entity200NonGuestOnlyCustomerInfoTrue_CustomerInfoOnly()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult5StoreNbr, cprAdult5PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult5StoreNbr, cprAdult5PatientId.toString()),
            "true",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNull(body.getAccount(),
        "account must be null when onlyCustomerInfo=true");

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must not be null");
    Assert.assertNotNull(body.getCustomerInfo().getEmailId(),
        "customerInfo.emailId must not be null");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult5EmailId,
        "customerInfo.emailId must match the CA account email");
    Assert.assertNotNull(body.getCustomerInfo().getCustomerAccountId(),
        "customerInfo.customerAccountId must not be null");
    Assert.assertEquals(body.getCustomerInfo().getCustomerAccountId(), adult5CustomerAccountId,
        "customerInfo.customerAccountId must match the CA CID");
  }

  // ── P8: Entity 200 + CA GUEST account → NOT_ELIGIBLE ─────────────────────
  /**
   * Adult6 has an entity pharmacy account linked to a CA GUEST account (accountType=GUEST).
   * Entity returns 200 → CA returns 200 with GUEST type
   * → setAccountStatusEmailIdAndWPlusStatus detects GUEST → status=NOT_ELIGIBLE, no customerInfo.
   */
  @Test(priority = 8, description =
      "Flag=true: entity 200 + CA GUEST account → NOT_ELIGIBLE, no customerInfo")
  public void getAccountStatusByPatientIdV1_Entity200GuestAccount_NotEligible()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult6StoreNbr, cprAdult6PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult6StoreNbr, cprAdult6PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "NOT_ELIGIBLE",
        "Expected NOT_ELIGIBLE when CA account type is GUEST");
    Assert.assertNull(body.getCustomerInfo(),
        "customerInfo must be null for GUEST/NOT_ELIGIBLE accounts");
  }

  // ── P9: Entity 200 + CA 404 + onlyCustomerInfo=false → NOT_CREATED ────────
  /**
   * Adult7 has an entity pharmacy account linked to a random UUID (not a real CA account).
   * Entity returns 200 → CA GetPersonByCustomerAccountId returns 404
   * → handleCA404Error (5-param) with onlyCustomerInfo=false → NOT_CREATED.
   */
  @Test(priority = 9, description =
      "Flag=true: entity 200 + CA 404 + onlyCustomerInfo=false → NOT_CREATED")
  public void getAccountStatusByPatientIdV1_Entity200Ca404OnlyCustomerInfoFalse_NotCreated()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult7StoreNbr, cprAdult7PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult7StoreNbr, cprAdult7PatientId.toString()),
            "false",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "NOT_CREATED",
        "Expected NOT_CREATED when CA returns 404 and onlyCustomerInfo=false");
    Assert.assertNull(body.getCustomerInfo(),
        "customerInfo must be null for NOT_CREATED status");
  }

  // ── P10: Entity 200 + CA 404 + onlyCustomerInfo=true → 204 ───────────────
  /**
   * Adult8 mirrors adult7 but is queried with {@code onlyCustomerInfo=true}.
   * Entity returns 200 → CA returns 404
   * → handleCA404Error (5-param) with onlyCustomerInfo=true → throws exception → API 204.
   */
  @Test(priority = 10, description =
      "Flag=true: entity 200 + CA 404 + onlyCustomerInfo=true → API 204")
  public void getAccountStatusByPatientIdV1_Entity200Ca404OnlyCustomerInfoTrue_Returns204()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult8StoreNbr, cprAdult8PatientId.toString(), domainId, reqId, reqTrackingId);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId,
            buildRequest(adult8StoreNbr, cprAdult8PatientId.toString()),
            "true",
            reqId,
            reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 204, errorMessage);
  }

  // ── P12: Entity 200 + filterOptions.walmartPlusStatus=true → NxtGn 4xx → 400 DPR-DPACCOR-13003 ──
  /**
   * Adult9 has a CPR account, a CA non-GUEST account, and an entity pharmacy account.
   * The request includes {@code filterOptions.attributeFilters.walmartPlusStatus=true},
   * which triggers the NxtGn Membership Core Service lookup inside
   * {@code callAndValidateCaGetPersonByCustomerAccountId} (5-param, flag=true path).
   *
   * <p>WIAP-generated CIDs are unknown to NxtGn. NxtGn returns an HTTP 4xx response
   * (not 404), and {@code NxtGnMembershipUtil} maps any non-404 4xx to
   * {@code NXTGN_MEMBERSHIP_CORE_SERVICE_INVALID_REQUEST_EXCEPTION}
   * (error code {@code DPR-DPACCOR-13003}, HTTP 400).
   *
   * <p>Note: {@code AttributeFilters} and {@code FilterOptions} are standalone top-level
   * classes in {@code com.walmart.pharmacy.dp.account.orchestrator.restclient.model}
   * (auto-generated from Swagger) — NOT inner classes of
   * {@code GetAccountStatusByPatientIdV1Request}.
   */
  @Test(priority = 12, description =
      "Flag=true: entity 200 + filterOptions.walmartPlusStatus=true + emailId=true "
          + "+ onlyCustomerInfo=false → 200 NxtGn Membership Active")
  public void getAccountStatusByPatientIdV1_Entity200WalmartPlusFilterNxtGnActive_Returns200()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult9StoreNbr, cprAdult9PatientId.toString(), domainId, reqId, reqTrackingId);

    AttributeFilters attributeFilters = new AttributeFilters();
    attributeFilters.setWalmartPlusStatus(Boolean.TRUE);
    attributeFilters.setEmailId(Boolean.TRUE);

    FilterOptions filterOptions = new FilterOptions();
    filterOptions.setAttributeFilters(attributeFilters);

    GetAccountStatusByPatientIdV1Request request =
        buildRequest(adult9StoreNbr, cprAdult9PatientId.toString());
    request.setFilterOptions(filterOptions);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId, request, "false", reqId, reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNotNull(body.getAccount(), "account must not be null");
    Assert.assertEquals(body.getAccount().getStatus(), "ACTIVE",
        "Expected ACTIVE for non-GUEST CA account with WalmartPlus membership");

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must not be null");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult9EmailId,
        "customerInfo.emailId must match adult9 email (emailId filter=true)");
    Assert.assertEquals(body.getCustomerInfo().getCustomerAccountId(), adult9CustomerAccountId,
        "customerInfo.customerAccountId must match adult9 CA CID");
    Assert.assertNotNull(body.getCustomerInfo().getWalmartPlusStatus(),
        "walmartPlusStatus must not be null when walmartPlusStatus filter=true");
    Assert.assertEquals(body.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE,
        "Expected walmartPlusStatus=ACTIVE for adult9 WalmartPlus member");
  }

  // ── P13: Entity 200 + WalmartPlus + emailId filter + onlyCustomerInfo=true → 400 ────
  @Test(priority = 13, description =
      "Flag=true: entity 200 + filterOptions.walmartPlusStatus=true + emailId=true "
          + "+ onlyCustomerInfo=true → 200 NxtGn Membership Active)")
  public void getAccountStatusByPatientIdV1_WalmartPlusEmailIdFilterOnlyCustomerInfoTrue_Returns200()
      throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;
    logFlowIdentifiers(
        adult9StoreNbr, cprAdult9PatientId.toString(), domainId, reqId, reqTrackingId);

    AttributeFilters attributeFilters = new AttributeFilters();
    attributeFilters.setWalmartPlusStatus(Boolean.TRUE);

    FilterOptions filterOptions = new FilterOptions();
    filterOptions.setAttributeFilters(attributeFilters);

    GetAccountStatusByPatientIdV1Request request =
        buildRequest(adult9StoreNbr, cprAdult9PatientId.toString());
    request.setFilterOptions(filterOptions);

    Response<ServiceResponse> apiResponse =
        accountOrchestratorRetrofit.getAccountStatusByPatientIdV1(
            domainId, request, "true", reqId, reqTrackingId);

    String errorMessage = CommonUtil.buildErrorMessage(gson, apiResponse);
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetAccountStatusByPatientIdV1Response body = parsePayload(apiResponse);
    Assert.assertNull(body.getAccount(),
        "account must be null when onlyCustomerInfo=true");

    Assert.assertNotNull(body.getCustomerInfo(), "customerInfo must not be null");
    Assert.assertEquals(body.getCustomerInfo().getEmailId(), adult9EmailId,
        "customerInfo.emailId must match adult9 email");
    Assert.assertEquals(body.getCustomerInfo().getCustomerAccountId(), adult9CustomerAccountId,
        "customerInfo.customerAccountId must match adult9 CA CID");
    Assert.assertNotNull(body.getCustomerInfo().getWalmartPlusStatus(),
        "walmartPlusStatus must not be null when walmartPlusStatus filter=true");
    Assert.assertEquals(body.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE,
        "Expected walmartPlusStatus=ACTIVE for adult9 WalmartPlus member");
  }

  // =========================================================================
  //  Helper / builder methods
  // =========================================================================

  /**
   * Builds a {@link ValidationServiceRequest} using the SharedUtils CPR template,
   * sets a random firstName, lastName, phone, and the dynamically generated {@link #cprDob}.
   *
   * @param storeNbr the pharmacy store number (as a numeric String)
   * @return fully populated ValidationServiceRequest ready for SharedUtils.createCprAccount
   */
  private ValidationServiceRequest buildCprRequest(String storeNbr) throws IOException {
    ValidationServiceRequest req = SharedUtils.getTemplateCprRequest(mapper);
    req.setStoreNbr(Integer.parseInt(storeNbr));
    req.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5).toUpperCase());
    req.getPatientInfo().setLastName(RandomStringUtils.randomAlphabetic(5).toUpperCase());
    req.getPatientInfo().setBirthDate(cprDob);
    req.getPatientCommunicationInfo().get(0)
        .setCommunicationId(CommonUtil.generateRandomNumber(10));
    return req;
  }

  /**
   * Builds the {@link GetAccountStatusByPatientIdV1Request} for the given storeNbr/patientId.
   *
   * @param storeNbr  store number (may be null to trigger validation error)
   * @param patientId patient ID (may be null to trigger validation error)
   */
  private GetAccountStatusByPatientIdV1Request buildRequest(String storeNbr, String patientId) {
    CustomerInfo customerInfo = new CustomerInfo();
    customerInfo.setStoreNbr(storeNbr);
    customerInfo.setPatientId(patientId);
    GetAccountStatusByPatientIdV1Request request = new GetAccountStatusByPatientIdV1Request();
    request.setCustomerInfo(customerInfo);
    return request;
  }

  /**
   * Builds a {@link CreatePharmacyAccountV1Request} using the smsOtpVerification source
   * and the dynamically generated {@link #entityDob} (MMddyyyy format).
   *
   * @param storeNbr  store number
   * @param patientId CPR patient ID (Integer → String)
   */
  private CreatePharmacyAccountV1Request buildCreatePharmacyAccountV1Request(
      String storeNbr, String patientId) {
    return CreatePharmacyAccountV1Request.builder()
        .accountCreationSource(accountCreationSource)
        .customerInfo(
            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                .storeNbr(storeNbr)
                .patientId(patientId)
                .dob(entityDob)
                .build())
        .build();
  }

  /**
   * Wraps {@code accountEntityServiceRetrofit.createPharmacyAccountV1} with up to 3 retries.
   *
   * @param customerAccountId the CA CID to link the pharmacy account to
   * @param domainId          domain identifier
   * @param request           create request
   * @param reqId             request ID header
   * @param reqTrackingId     request tracking ID header
   */
  private void createPharmacyAccount(
      String customerAccountId,
      String domainId,
      CreatePharmacyAccountV1Request request,
      String reqId,
      String reqTrackingId) throws IOException {
    for (int i = 0; i < 3; i++) {
      Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
          response = accountEntityServiceRetrofit.createPharmacyAccountV1(
              customerAccountId, domainId, request, reqId, reqTrackingId);
      if (response.code() == 200
          && response.body() != null
          && response.body().getPayload() != null) {
        return;
      }
      if (i == 2) {
        throw new RuntimeException(
            "createPharmacyAccountV1 failed. HTTP: " + response.code()
                + " cid: " + customerAccountId);
      }
    }
  }

  /**
   * Convenience: parse the API response payload into {@link GetAccountStatusByPatientIdV1Response}.
   */
  @SuppressWarnings("unchecked")
  private GetAccountStatusByPatientIdV1Response parsePayload(
      Response<ServiceResponse> apiResponse) {
    return ResponseUtil.parseResponse(
        gson,
        (LinkedTreeMap<String, Object>) apiResponse.body().getPayload(),
        GetAccountStatusByPatientIdV1Response.class);
  }

  /**
   * Logs the storeNbr, patientId, domainId, reqId, and reqTrackingId for test traceability.
   */
  private void logFlowIdentifiers(
      String storeNbr,
      String patientId,
      String domainId,
      String reqId,
      String reqTrackingId) {
    Reporter.logJSON("Store nbr", storeNbr);
    Reporter.logJSON("Patient Id", patientId);
    Reporter.logJSON("domainId", domainId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }


  private String createStageIsacRecord(
      String storeNbr,
      Integer cprPatientId,
      String emailId,
      String dob,
      String reqId,
      String reqTrackingId,
      Boolean idVerified) throws IOException {

    AccountOrchestratorRetrofit accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();

    CreateStageISACRecordV1Request request = CreateStageISACRecordV1Request.builder()
        .storeNbr(storeNbr)
        .patientId(String.valueOf(cprPatientId))
        .emailId(emailId)
        .dob(dob)
        .idVerified(idVerified)
        .build();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createStageIsacRecordV1(
            domainId,
            request,
            reqId,
            reqTrackingId);

    if (response.body() == null || response.body().getPayload() == null) {
      throw new RuntimeException(
          "createStageIsacRecord failed — null payload. HTTP " + response.code()
              + (response.errorBody() != null ? " body=" + response.errorBody().string() : ""));
    }

    @SuppressWarnings("unchecked")
    LinkedTreeMap<String, Object> payload =
        (LinkedTreeMap<String, Object>) response.body().getPayload();

    String stageId = (String) payload.get("stageId");
    if (stageId == null || stageId.isBlank()) {
      throw new RuntimeException(
          "createStageIsacRecord succeeded (HTTP " + response.code()
              + ") but stageId is absent in response payload: " + payload);
    }
    return stageId;
  }
}
