package accountorchestrator.customer.getCustomerInfoByPid;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static accountorchestrator.constants.AccountOrchestratorConstants.*;
import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerInfoByPidV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerInfoByPidV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPCreateGuestAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPCreateGuestAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountOrchestratorGetCustomerInfoByPidTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();

    /**
     * Generates a valid 10-digit US phone number with area code 405 (Oklahoma)
     * and random remaining 7 digits. Uses a valid area code to generates a unique number per call to avoid
     * Astro's 16-minute phone reuse cooldown.
     */
    private static String generateValidPhoneNumber() {
        return "405" + RandomStringUtils.randomNumeric(7);
    }

    private String commonPassword = generatePassword();
    private String trackID = CommonUtil.randomUUID();

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetroFit;

    private ValidationServiceRequest cprPatientRequest = null;
    private List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    private List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();

    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForLessThan18 = null;
    private String commonDobDPFormatForLessThan18 = null;

    private String customerEmailId = null;
    private String customerStoreNbr = null;
    private String customerPatientId = null;
    private String customerFirstName = null;
    private String customerLastName = null;
    private String customerAccountId = null;

    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent1AccountId = null;

    private String dependent2StoreNbr = null;
    private String dependent2PatientId = null;
    private String dependent2FirstName = null;
    private String dependent2LastName = null;
    private String dependent2AccountId = null;

    private String dependent3EmailId = null;
    private String dependent3StoreNbr = null;
    private String dependent3PatientId = null;
    private String dependent3FirstName = null;
    private String dependent3LastName = null;
    private String dependent3AccountId = null;

    private String caregiver1EmailId = null;
    private String caregiver1StoreNbr = null;
    private String caregiver1PatientId = null;
    private String caregiver1FirstName = null;
    private String caregiver1LastName = null;
    private String caregiver1AccountId = null;

    private String caregiver2EmailId = null;
    private String caregiver2StoreNbr = null;
    private String caregiver2PatientId = null;
    private String caregiver2FirstName = null;
    private String caregiver2LastName = null;
    private String caregiver2AccountId = null;

    // Solo customer - no dependents or caregivers linked (used for empty-relationship tests)
    private String soloCustomerEmailId = null;
    private String soloCustomerStoreNbr = null;
    private String soloCustomerPatientId = null;
    private String soloCustomerFirstName = null;
    private String soloCustomerLastName = null;
    private String soloCustomerAccountId = null;

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        wcpRetroFit = new WCPRetroFit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
        commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

        createTestData();
    }

    private void createTestData() throws Exception {

        // Create customer account
        customerEmailId = CommonUtil.generateRandomEmailId(10);
        customerStoreNbr = CommonUtil.generateRandomNumber(6);
        customerPatientId = CommonUtil.generateRandomNumber(9);
        customerFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        customerLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        customerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        customerEmailId,
                        commonPassword,
                        generateValidPhoneNumber(),
                        customerFirstName,
                        customerLastName,
                        trackID);
        createCPRAccount(
                customerStoreNbr,
                customerPatientId,
                customerFirstName,
                customerLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                customerAccountId,
                customerStoreNbr,
                customerPatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
        CommonAccountHelper.addWalmartPlusMembershipViaAstro(customerEmailId);

        // Create dependent1 (PET)
        dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent1AccountId =
                createWcpGuestAccount(
                        dependent1FirstName, dependent1LastName, PET, commonDobCPRFormatForLessThan18);
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                dependent1FirstName,
                dependent1LastName,
                commonDobCPRFormatForLessThan18,
                PET);
        createPharmacyAccount(
                dependent1AccountId,
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobDPFormatForLessThan18,
                PHARMACY_DOMAIN_ID);
        wcpAddDependent(
                DependentInfo.TypeEnum.PET,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent1AccountId,
                customerAccountId,
                null);

        // Create dependent2 (MINOR)
        dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent2PatientId = CommonUtil.generateRandomNumber(9);
        dependent2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent2AccountId =
                createWcpGuestAccount(
                        dependent2FirstName, dependent2LastName, MINOR, commonDobCPRFormatForLessThan18);
        createCPRAccount(
                dependent2StoreNbr,
                dependent2PatientId,
                dependent2FirstName,
                dependent2LastName,
                commonDobCPRFormatForLessThan18,
                HUMAN);
        createPharmacyAccount(
                dependent2AccountId,
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobDPFormatForLessThan18,
                PHARMACY_DOMAIN_ID);
        wcpAddDependent(
                DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent2AccountId,
                customerAccountId,
                null);

        // Create dependent3 (ADULT)
        dependent3EmailId = CommonUtil.generateRandomEmailId(10);
        dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent3PatientId = CommonUtil.generateRandomNumber(9);
        dependent3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dependent3AccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        dependent3EmailId,
                        commonPassword,
                        generateValidPhoneNumber(),
                        dependent3FirstName,
                        dependent3LastName,
                        trackID);
        createCPRAccount(
                dependent3StoreNbr,
                dependent3PatientId,
                dependent3FirstName,
                dependent3LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                dependent3AccountId,
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent3AccountId,
                customerAccountId,
                dependent3EmailId);
        CommonAccountHelper.addWalmartPlusMembershipViaAstro(dependent3EmailId);

        // Create caregiver1
        caregiver1EmailId = CommonUtil.generateRandomEmailId(10);
        caregiver1StoreNbr = CommonUtil.generateRandomNumber(6);
        caregiver1PatientId = CommonUtil.generateRandomNumber(9);
        caregiver1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiver1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiver1AccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        caregiver1EmailId,
                        commonPassword,
                        generateValidPhoneNumber(),
                        caregiver1FirstName,
                        caregiver1LastName,
                        trackID);
        createCPRAccount(
                caregiver1StoreNbr,
                caregiver1PatientId,
                caregiver1FirstName,
                caregiver1LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                caregiver1AccountId,
                caregiver1StoreNbr,
                caregiver1PatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                customerAccountId,
                caregiver1AccountId,
                customerEmailId);
        CommonAccountHelper.addWalmartPlusMembershipViaAstro(caregiver1EmailId);

        // Create caregiver2
        caregiver2EmailId = CommonUtil.generateRandomEmailId(10);
        caregiver2StoreNbr = CommonUtil.generateRandomNumber(6);
        caregiver2PatientId = CommonUtil.generateRandomNumber(9);
        caregiver2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiver2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        caregiver2AccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        caregiver2EmailId,
                        commonPassword,
                        generateValidPhoneNumber(),
                        caregiver2FirstName,
                        caregiver2LastName,
                        trackID);
        createCPRAccount(
                caregiver2StoreNbr,
                caregiver2PatientId,
                caregiver2FirstName,
                caregiver2LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                caregiver2AccountId,
                caregiver2StoreNbr,
                caregiver2PatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                customerAccountId,
                caregiver2AccountId,
                customerEmailId);
        CommonAccountHelper.addWalmartPlusMembershipViaAstro(caregiver2EmailId);
        

        // Create solo customer - has a valid CA + CPR + pharmacy account but NO dependents or
        // caregivers linked. Used to verify empty relationship list responses.
        soloCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        soloCustomerStoreNbr = CommonUtil.generateRandomNumber(6);
        soloCustomerPatientId = CommonUtil.generateRandomNumber(9);
        soloCustomerFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        soloCustomerLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        soloCustomerAccountId =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        soloCustomerEmailId,
                        commonPassword,
                        generateValidPhoneNumber(),
                        soloCustomerFirstName,
                        soloCustomerLastName,
                        trackID);
        createCPRAccount(
                soloCustomerStoreNbr,
                soloCustomerPatientId,
                soloCustomerFirstName,
                soloCustomerLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                soloCustomerAccountId,
                soloCustomerStoreNbr,
                soloCustomerPatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
        // Intentionally no wcpAddDependent or createWPlusMembership calls — solo customer
       

    }

    @AfterClass
    void cleanUp() throws IOException {
        // Delete CPR profiles
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        cprPatientUpdateRetrofit.validateProfile(request);
                    } catch (IOException e) {
                        Reporter.logJSON("Exception during CPR profile deletion", e.getMessage());
                    }
                });

        // Delete pharmacy profiles
        pharmacyProfilesToBeDeleted.forEach(
                accountId -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        accountId, PHARMACY_DOMAIN_ID, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                accountId, PHARMACY_DOMAIN_ID, reqIdString, reqTrackingString);
                    } catch (IOException e) {
                        Reporter.logJSON("Exception during pharmacy profile deletion", e.getMessage());
                    }
                });
    }

    /**
     * // Note : If we switch back to CA flag we have to use these methods for creating accounts in CA
     * public String createDotComAccountUsingCA(String emailAddress) throws IOException {
     * CACreatePersonRequestByCustomerType caCreatePersonRequest =
     * getCACreatePersonRequest(emailAddress); Response<CACreatePersonByCustomerTypeResponse> response
     * = null;
     *
     * <p>// This will try to create a person account in CA, 3 times if account creation fails for
     * (int i = 0; i < 3; i++) { response =
     * caRetrofit.createPersonByCustomerType(caCreatePersonRequest); if (!(response.code() == 200 &&
     * response.body() != null && response.body().getPayload() != null) && response.body().getStatus()
     * != "OK") { Reporter.logJSON("Exception", response.errorBody().toString()); if (i == 2) { throw
     * new RuntimeException( "CA person account creation failed. HttpStatusCode : " +
     * response.code()); } } else break; } return
     * response.body().getPayload().getPerson().getCustomerAccountId(); }
     *
     * <p>private CACreatePersonRequestByCustomerType getCACreatePersonRequest( String
     * dependentCustomerEmailId) { List<CACreatePersonRequestByCustomerType.Accounts> accountsList =
     * new ArrayList<>(); accountsList.add( CACreatePersonRequestByCustomerType.Accounts.builder()
     * .accountType("INDIVIDUAL") .emailAddress(dependentCustomerEmailId) .build()); return
     * CACreatePersonRequestByCustomerType.builder() .payload(
     * CACreatePersonRequestByCustomerType.CreatePersonRequestPayload.builder() .person(
     * CACreatePersonRequestByCustomerType.Person.builder() .accounts(accountsList)
     * .customerType("INDIVIDUAL") .build()) .build()) .build(); }
     */
    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : "
                                    + response.code()
                                    + response.errorBody().string());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(50000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void createPharmacyAccount(
            String customerAccountId,
            String commonStoreNbr,
            String commonPatientId,
            String dob,
            String domainId)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // Retry up to 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);

            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : "
                                    + response.code()
                                    + response.errorBody().string());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
                break;
            }
        }
    }

    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(ACCOUNT_CREATION_SOURCE)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    /**
     * // Note : If we switch back to CA flag we have to use these methods for adding dependents or
     * caregivers private void caAddDependent( DependentInfo.TypeEnum type,
     * DependentInfo.LinkageStatusEnum status, String dependentAccountId, String caregiverAccountId)
     * throws IOException { CAAddDependentRequest caAddDependentRequest =
     * getCAAddDependentRequest(type, status, dependentAccountId, caregiverAccountId);
     * Response<CAAddDependentResponse> response = null;
     *
     * <p>// Retry up to 3 times if adding dependent fails for (int i = 0; i < 3; i++) { response =
     * caRetrofit.addDependent(caAddDependentRequest); if (!(response.code() == 200 && response.body()
     * != null && response.body().getPayload() != null) && !response.isSuccessful()) {
     * Reporter.logJSON("Exception", response.errorBody().toString()); if (i == 2) { throw new
     * RuntimeException( "CA add dependent failed. HttpStatusCode : " + response.code()); } } else {
     * break; } } }
     *
     * <p>private CAAddDependentRequest getCAAddDependentRequest( DependentInfo.TypeEnum type,
     * DependentInfo.LinkageStatusEnum status, String dependentAccountId, String caregiverAccountId) {
     * return CAAddDependentRequest.builder() .payload( CAAddDependentRequest.Payload.builder()
     * .dependent( CAAddDependentRequest.Dependent.builder() .groupType(GroupType.FAM) .memberId(
     * CAAddDependentRequest.Identifier.builder() .id(dependentAccountId) .build())
     * .membershipStatus(status) .memberType(type) .ownerId(
     * CAAddDependentRequest.Identifier.builder() .id(caregiverAccountId) .build()) .build())
     * .build()) .build(); }
     */
    private void wcpAddDependent(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId,
            String dependentCustomerEmailId)
            throws Exception {
        WCPAddDependentRequest wcpAddDependentRequest =
                getWcpAddDependentRequest(
                        type, status, dependentAccountId, caregiverAccountId, dependentCustomerEmailId);
        Response<WCPAddDependentResponse> response = null;

        // Retry up to 3 times if adding dependent fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetroFit.addDependent(wcpAddDependentRequest, dependentAccountId);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP add dependent failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
    }

    private WCPAddDependentRequest getWcpAddDependentRequest(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId,
            String dependentCustomerEmailId) {

        WCPAddDependentRequest.Dependent wcpDependent =
                WCPAddDependentRequest.Dependent.builder()
                        .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverAccountId).build())
                        .groupType(GroupType.FAM.name())
                        .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentAccountId).build())
                        .memberType(String.valueOf(type))
                        .notificationEmail(dependentCustomerEmailId)
                        .membershipStatus(String.valueOf(status))
                        .build();

        return WCPAddDependentRequest.builder()
                .payload(WCPAddDependentRequest.Payload.builder().dependent(wcpDependent).build())
                .build();
    }

    private String createWcpGuestAccount(
            String firstName, String lastName, String customerType, String dob) throws Exception {
        WCPCreateGuestAccountRequest wcpCreateGuestAccountRequest =
                getWcpCreateGuestAccountRequest(firstName, lastName, customerType, dob);
        Response<WCPCreateGuestAccountResponse> response = null;

        // Retry up to 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetroFit.createGuestAccount(wcpCreateGuestAccountRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && response.body().getStatus() != "OK") {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP Guest account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
        return response
                .body()
                .getPayload()
                .getCustomerAccountId();
    }

    private static WCPCreateGuestAccountRequest getWcpCreateGuestAccountRequest(
            String firstName, String lastName, String customerType, String dob) {
        return WCPCreateGuestAccountRequest.builder()
                .payload(
                        WCPCreateGuestAccountRequest.Payload.builder()
                                .account(
                                        WCPCreateGuestAccountRequest.Account.builder()
                                                .accountType(ACCOUNT_TYPE_GUEST)
                                                .customerType(customerType)
                                                .firstName(firstName)
                                                .lastName(lastName)
                                                .dateOfBirth(dob)
                                                .build())
                                .build())
                .build();
    }

    /**
     * // Note : If we switch back to CA flag we have to use these methods for creating guest accounts
     * in CA private String createCaPetAccount() throws IOException { CACreatePetAccountRequest
     * caCreatePetAccountRequest = getCACreatePetRequest(); Response<CACreatePetAccountResponse>
     * response = null;
     *
     * <p>// Retry up to 3 times if account creation fails for (int i = 0; i < 3; i++) { response =
     * caRetrofit.createPetAccount(caCreatePetAccountRequest); if (!(response.code() == 200 &&
     * response.body() != null && response.body().getPayload() != null) && response.body().getStatus()
     * != "OK") { Reporter.logJSON("Exception", response.errorBody().toString()); if (i == 2) { throw
     * new RuntimeException( "CA pet account creation failed. HttpStatusCode : " + response.code()); }
     * } else { break; } } return response.body().getPayload().getPet().getCustomerAccountId(); }
     *
     * <p>private static CACreatePetAccountRequest getCACreatePetRequest() {
     * List<CACreatePetAccountRequest.Accounts> accountsList = new ArrayList<>(); String dob =
     * "2024-01-02"; String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase(); String
     * lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
     *
     * <p>accountsList.add(CACreatePetAccountRequest.Accounts.builder().accountType("GUEST").build());
     *
     * <p>CACreatePetAccountRequest.Pet pet = CACreatePetAccountRequest.Pet.builder()
     * .firstName(firstName) .lastName(lastName) .accounts(accountsList) .customerType("PET")
     * .birthDay(dob) .build();
     *
     * <p>return CACreatePetAccountRequest.builder()
     * .payload(CACreatePetAccountRequest.CACreatePetAccountPayload.builder().pet(pet).build())
     * .build(); }
     *
     * <p>private String createCaMinorAccount() throws IOException { CACreateGuestAccountRequest
     * caCreateGuestAccountRequest = getCACreateMinorRequest(); Response<CACreateGuestAccountResponse>
     * response = null;
     *
     * <p>// Retry up to 3 times if account creation fails for (int i = 0; i < 3; i++) { response =
     * caRetrofit.createGuestAccount(caCreateGuestAccountRequest); if (!(response.code() == 200 &&
     * response.body() != null && response.body().getPayload() != null) && response.body().getStatus()
     * != "OK") { Reporter.logJSON("Exception", response.errorBody().toString()); if (i == 2) { throw
     * new RuntimeException( "CA Guest account creation failed. HttpStatusCode : " + response.code());
     * } } else { break; } } return response.body().getPayload().getPerson().getCustomerAccountId(); }
     *
     * <p>private static CACreateGuestAccountRequest getCACreateMinorRequest() {
     * List<CACreateGuestAccountRequest.Accounts> accountsList = new ArrayList<>();
     * List<CACreateGuestAccountRequest.Name> nameList = new ArrayList<>(); String dob = "2024-01-02";
     * String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase(); String lastName =
     * RandomStringUtils.randomAlphabetic(5).toUpperCase();
     *
     * <p>accountsList.add(CACreateGuestAccountRequest.Accounts.builder().accountType("GUEST").build());
     *
     * <p>nameList.add( CACreateGuestAccountRequest.Name.builder() .personName(
     * CACreateGuestAccountRequest.PersonName.builder() .firstName(firstName) .lastName(lastName)
     * .build()) .build());
     *
     * <p>CACreateGuestAccountRequest.Person person = CACreateGuestAccountRequest.Person.builder()
     * .names(nameList) .accounts(accountsList) .customerType("INDIVIDUAL") .birthDay(dob) .build();
     *
     * <p>return CACreateGuestAccountRequest.builder() .payload(
     * CACreateGuestAccountRequest.CACreateGuestAccountPayload.builder() .person(person) .build())
     * .build(); }
     */
    public GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request(
            String storeNbr,
            String patientId,
            GetCustomerInfoByPidV1Request.FilterOptions filterOptions) {
        return GetCustomerInfoByPidV1Request.builder()
                .patientId(patientId)
                .storeNbr(storeNbr)
                .filterOptions(filterOptions)
                .build();
    }

    // Attribute Filter Combinations
    @Test(
            priority = 0,
            description =
                    "When wPlus = false, storePatientInfo = false, email = false, payMethods = false, Result =customerAccountId only ")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsFalseEmailIsFalsePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 1,
            description =
                    "When wPlus = true, storePatientInfo = false, email = false, payMethods = false, Result = customerAccountId + walmartPlusStatus")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsFalseEmailIsFalsePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 2,
            description =
                    "When wPlus = false, storePatientInfo = true, email = false, payMethods = false, Result = customerAccountId + personalNameFields + patientLinks + type")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsTrueEmailIsFalsePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(true)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
    }

    @Test(
            priority = 3,
            description =
                    "When wPlus = false, storePatientInfo = false, email = true, payMethods = false, Result = customerAccountId + emailId")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsFalseEmailIsTruePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(true)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 4,
            description =
                    "When wPlus = false, storePatientInfo = false, email = false, payMethods = true, Result = customerAccountId + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsFalseEmailIsFalsePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 5,
            description =
                    "When wPlus = true, storePatientInfo = true, email = false, payMethods = false, Result = customerAccountId + walmartPlusStatus + personalNameFields + patientLinks + type")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsTrueEmailIsFalsePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
    }

    @Test(
            priority = 6,
            description =
                    "When wPlus = true, storePatientInfo = false, email = true, payMethods = false, Result = customerAccountId + walmartPlusStatus + emailId")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsFalseEmailIsTruePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(false)
                                        .emailId(true)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 7,
            description =
                    "When wPlus = true, storePatientInfo = false, email = false, payMethods = true, Result = customerAccountId + walmartPlusStatus + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsFalseEmailIsFalsePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 8,
            description =
                    "When wPlus = false, storePatientInfo = true, email = true, payMethods = false, Result = customerAccountId + personalNameFields + patientLinks + type + emailId")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsTrueEmailIsTruePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
    }

    @Test(
            priority = 9,
            description =
                    "When wPlus = false, storePatientInfo = true, email = false, payMethods = true, Result = customerAccountId + personalNameFields + patientLinks + type + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsTrueEmailIsFalsePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(true)
                                        .emailId(false)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
    }

    @Test(
            priority = 10,
            description =
                    "When wPlus = false, storePatientInfo = false, email = true, payMethods = true, Result = customerAccountId + emailId + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsFalseEmailIsTruePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 11,
            description =
                    "When wPlus = true, storePatientInfo = true, email = true, payMethods = false, Result = customerAccountId + walmartPlusStatus + personalNameFields + patientLinks + type + emailId")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsTrueEmailIsTruePayMethodsIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
    }

    @Test(
            priority = 12,
            description =
                    "When wPlus = true, storePatientInfo = true, email = false, payMethods = true, Result = customerAccountId + walmartPlusStatus + personalNameFields + patientLinks + type + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsTrueEmailIsFalsePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(false)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getEmailId());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
    }

    @Test(
            priority = 13,
            description =
                    "When wPlus = true, storePatientInfo = false, email = true, payMethods = true, Result = customerAccountId + walmartPlusStatus + emailId + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsFalseEmailIsTruePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(false)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
    }

    @Test(
            priority = 14,
            description =
                    "When wPlus = false, storePatientInfo = true, email = true, payMethods = true, Result = customerAccountId + personalNameFields + patientLinks + type + emailId + paymentMethods")
    public void
    getCustomerInfoByPidWhenWplusIsFalseStorePatientInfoIsTrueEmailIsTruePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getWalmartPlusStatus());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
        assertNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
    }

    @Test(
            priority = 15,
            description =
                    "When wPlus = true, storePatientInfo = true, email = true, payMethods = true, Result = all fields")
    public void getCustomerInfoByPidWhenWplusIsTrueStorePatientInfoIsTrueEmailIsTruePayMethodsIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(
                                custId ->
                                        dependent1AccountId.equals(custId.getCustomerAccountId())
                                                || dependent2AccountId.equals(custId.getCustomerAccountId())
                                                || dependent3AccountId.equals(custId.getCustomerAccountId())));
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getWalmartPlusStatus())));
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPatientLinks());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(customerInfo -> Objects.nonNull(customerInfo.getEmailId())));
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo().getFirst().getPaymentMethods());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(
                                custId ->
                                        caregiver1AccountId.equals(custId.getCustomerAccountId())
                                                || caregiver2AccountId.equals(custId.getCustomerAccountId())));
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getEmailId());
        assertNotNull(
                getCustomerInfoByPidV1Response.getCaregiversInfo().getFirst().getPaymentMethods());
    }

    // RelationshipFilters Combinations

    @Test(
            priority = 16,
            description =
                    "When for relationshipFilters primary=true, dependents=true, caregivers=true and attributeFilters are false - All three")
    public void getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsTrueAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 17,
            description =
                    "When for relationshipFilters primary=false, dependents=true, caregivers=true and attributeFilters are false - dependentsInfo + caregiversInfo")
    public void getCustomerInfoByPidWhenPrimaryIsFalseAndDependentsIsTrueAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 18,
            description =
                    "When for relationshipFilters primary=null or not present, dependents=true, caregivers=true and attributeFilters are false, by default primary is true")
    public void
    getCustomerInfoByPidWhenPrimaryIsNullOrNotPresentAndDependentsIsTrueAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(null)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 19,
            description =
                    "When for relationshipFilters primary=true, dependents=false, caregivers=true and attributeFilters are false - customerInfo + caregiversInfo")
    public void getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsFalseAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 20,
            description =
                    "When for relationshipFilters primary=true, dependents=null or not present, caregivers=true and attributeFilters are false, by default primary is true")
    public void
    getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsNullOrNotPresentAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(null)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 21,
            description =
                    "When for relationshipFilters primary=true, dependents=true, caregivers=false and attributeFilters are false - customerInfo + dependentsInfo")
    public void getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsTrueAndCaregiversIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 22,
            description =
                    "When for relationshipFilters primary=true, dependents=true, caregivers=null or not present and attributeFilters are false, by default primary is true")
    public void
    getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsTrueAndCaregiversIsNullOrNotPresent()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(null)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());

        // caregiverInfo
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 23,
            description =
                    "When for relationshipFilters primary=false, dependents=false, caregivers=false and attributeFilters are false - empty payload")
    public void getCustomerInfoByPidWhenPrimaryIsFalseAndDependentsIsFalseAndCaregiversIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCustomerInfo() == null
                        || getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId() == null);

        // dependentInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo() == null
                        || getCustomerInfoByPidV1Response.getDependentsInfo().isEmpty());

        // caregiverInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo() == null
                        || getCustomerInfoByPidV1Response.getCaregiversInfo().isEmpty());
    }

    @Test(
            priority = 24,
            description =
                    "When for relationshipFilters primary=true, dependents=false, caregivers=false and attributeFilters are false - customerInfo only")
    public void getCustomerInfoByPidWhenPrimaryIsTrueAndDependentsIsFalseAndCaregiversIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - should be present
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // dependentInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo() == null
                        || getCustomerInfoByPidV1Response.getDependentsInfo().isEmpty());

        // caregiverInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo() == null
                        || getCustomerInfoByPidV1Response.getCaregiversInfo().isEmpty());
    }

    @Test(
            priority = 25,
            description =
                    "When for relationshipFilters primary=false, dependents=true, caregivers=false and attributeFilters are false - dependentsInfo only")
    public void getCustomerInfoByPidWhenPrimaryIsFalseAndDependentsIsTrueAndCaregiversIsFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(true)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCustomerInfo() == null
                        || getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId() == null);

        // dependentInfo - should be present
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertFalse(getCustomerInfoByPidV1Response.getDependentsInfo().isEmpty());

        // caregiverInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo() == null
                        || getCustomerInfoByPidV1Response.getCaregiversInfo().isEmpty());
    }

    @Test(
            priority = 26,
            description =
                    "When for relationshipFilters primary=false, dependents=false, caregivers=true and attributeFilters are false - caregiversInfo only")
    public void getCustomerInfoByPidWhenPrimaryIsFalseAndDependentsIsFalseAndCaregiversIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(false)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getCustomerInfo() == null
                        || getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId() == null);

        // dependentInfo - should be null or empty
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo() == null
                        || getCustomerInfoByPidV1Response.getDependentsInfo().isEmpty());

        // caregiverInfo - should be present
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertFalse(getCustomerInfoByPidV1Response.getCaregiversInfo().isEmpty());
    }

    // AttributeFilter Priority Mapping Tests
    // AttributeFilter values from request body are given first priority, if not present check URL
    // parameters,
    // if not present in URL parameters, default value is chosen

    @Test(
            priority = 27,
            description =
                    "When attributeFilter values are false in URL but true in request - Request values should take priority (true)")
    public void getCustomerInfoByPidWhenAttributeFilterValuesAreTrueInRequestButFalseInUrl()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters (these are present but should NOT take priority)
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body with TRUE values (these should take priority over URL)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Request values (true) should take priority over URL values (false)
        // So all fields should be present as per true values
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // These should be present because request params were TRUE (taking priority over URL FALSE)
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 28,
            description =
                    "When attributeFilter values are present in request but not in URL - Request values should be used (highest priority)")
    public void getCustomerInfoByPidWhenAttributeFilterValuesPresentInRequestButNotInUrl()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters are NULL (not present, so request body takes priority)
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body with TRUE values (these have highest priority)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(true)
                                        .emailId(true)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Request values (true) should be used as URL params are null
        // So all fields should be present as per true values
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // These should be present because request params were TRUE (URL was null, so request has
        // highest priority)
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 29,
            description =
                    "When attributeFilter values are true in URL but false in request - Request values should take priority (false)")
    public void getCustomerInfoByPidWhenAttributeFilterValuesAreFalseInRequestButTrueInUrl()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters (these are present but should NOT take priority)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body with FALSE values (these should take priority over URL)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Request values (false) should take priority over URL values (true)
        // So fields should be NULL as per false values
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // These should be NULL because request params were FALSE (taking priority over URL TRUE)
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
    }

    @Test(
            priority = 30,
            description = "When attributeFilter values are not present in URL and also not in request")
    public void getCustomerInfoByPidWhenAttributeFilterValuesAreNotPresentInUrlAndAlsoInRequest()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Default values should be used (false)
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // These should be NULL
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
    }

    // Query Parameter Only Tests (No AttributeFilters)
    // These tests verify behavior when only query parameters are used (AttributeFilters not set)
    // TODO: This behavior applies to query parameter path only (not request body path) The email ID
    // is being populated when isWPlusStatusRequired query param is true. This needs to be removed
    // in the next release, and the email ID should only be populated based on the isEmailRequired
    // flag. NOTE: Need to confirm with client before making this change.

    @Test(
            priority = 31,
            description =
                    "Query Param Only: When walmartPlusStatus=true, emailId=false in URL - Email should be populated (special logic)")
    public void getCustomerInfoByPidWhenQueryParamWplusIsTrueAndEmailIsFalse() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - Special logic: walmartPlusStatus=true in query param, so email is always
        // populated
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        // Email should be populated even though emailId=false, because walmartPlusStatus=true in query
        // param
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 32,
            description =
                    "Query Param Only: When walmartPlusStatus=true, emailId=true in URL - Email should be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsTrueAndEmailIsTrue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = false;
        Boolean emailId = true;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 33,
            description =
                    "Query Param Only: When walmartPlusStatus=false, emailId=false in URL - Email should NOT be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsFalseAndEmailIsFalse() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - walmartPlusStatus=false, emailId=false, so email should be NULL
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 34,
            description =
                    "Query Param Only: When walmartPlusStatus=false, emailId=true in URL - Email should be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsFalseAndEmailIsTrue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = true;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - emailId=true, so email should be populated
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 35,
            description =
                    "Query Param Only: When walmartPlusStatus=null, emailId=null in URL - Both default to false, Email and WalmartPlusStatus should NOT be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsNullAndEmailIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Both URL parameters are NULL (defaults apply → both treated as false)
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - walmartPlusStatus=null (defaults to false), emailId=null (defaults to false)
        // So both walmartPlusStatus and emailId should be NULL in the response
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 36,
            description =
                    "Query Param Only: When walmartPlusStatus=true, all other params=true - All fields should be populated")
    public void getCustomerInfoByPidWhenQueryParamAllValuesAreTrue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - All params true, all fields should be populated
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 37,
            description =
                    "Query Param Only: When walmartPlusStatus=null, emailId=false in URL - Email should NOT be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsNullAndEmailIsFalse() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - walmartPlusStatus=null (defaults to false), emailId=false, so email should be
        // NULL
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 38,
            description =
                    "Query Param Only: When walmartPlusStatus=false, emailId=null in URL - Email should NOT be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsFalseAndEmailIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - walmartPlusStatus=false, emailId=null (defaults to false), so email should be
        // NULL
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 39,
            description =
                    "Query Param Only: When walmartPlusStatus=true, emailId=null in URL - Email should be populated (special logic)")
    public void getCustomerInfoByPidWhenQueryParamWplusIsTrueAndEmailIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = false;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - Special logic: walmartPlusStatus=true in query param, so email is always
        // populated
        // even though emailId=null (which defaults to false)
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        // Email should be populated even though emailId=null, because walmartPlusStatus=true in query
        // param
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 40,
            description =
                    "Query Param Only: When walmartPlusStatus=null, emailId=true in URL - Email should be populated")
    public void getCustomerInfoByPidWhenQueryParamWplusIsNullAndEmailIsTrue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Query parameters only (no AttributeFilters)
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = false;
        Boolean emailId = true;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters set - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // customerInfo - emailId=true, so email should be populated
        assertEquals(
                customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 41,
            description =
                    "When filterOptions is null in the request body and all URL params are null"
                            + " - defaults: primary=true, dependents=false, caregivers=false, all attributes=false"
                            + " - Result: customerInfo with customerAccountId only, no dependentsInfo, no caregiversInfo")
    public void getCustomerInfoByPidWhenFilterOptionsIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // filterOptions explicitly set to null - service defaults apply
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                GetCustomerInfoByPidV1Request.builder()
                        .patientId(customerPatientId)
                        .storeNbr(customerStoreNbr)
                        .filterOptions(null)
                        .build();

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Default: primary=true → customerInfo present
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo(), "customerInfo should be present when primary defaults to true");
        assertEquals(customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // Default: all attribute flags=false → no attribute fields populated
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());

        // Default: dependents=false, caregivers=false → neither list present
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo(), "dependentsInfo should be null when dependents defaults to false");
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo(), "caregiversInfo should be null when caregivers defaults to false");
    }

    @Test(
            priority = 42,
            description =
                    "Query Param Only: When includeStorePatientInfo=true in URL and no AttributeFilters in request body"
                            + " - firstName, lastName, type, patientLinks should be populated")
    public void getCustomerInfoByPidWhenQueryParamStorePatientInfoIsTrueAndNoBodyFilter()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = true;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters in body - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // includeStorePatientInfo=true → PII name fields + type + patientLinks populated
        assertEquals(customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName(), "firstName should be populated when includeStorePatientInfo=true");
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName(), "lastName should be populated when includeStorePatientInfo=true");
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType(), "type should be populated when includeStorePatientInfo=true");
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks(), "patientLinks should be populated when includeStorePatientInfo=true");

        // Other attributes not requested
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 43,
            description =
                    "Query Param Only: When includeStorePatientInfo=false in URL and no AttributeFilters in request body"
                            + " - firstName, lastName, type, patientLinks should NOT be populated")
    public void getCustomerInfoByPidWhenQueryParamStorePatientInfoIsFalseAndNoBodyFilter()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // No AttributeFilters in body - only relationshipFilters
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // includeStorePatientInfo=false → PII name fields should NOT be populated
        assertEquals(customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName(), "firstName should be null when includeStorePatientInfo=false");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName(), "lastName should be null when includeStorePatientInfo=false");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType(), "type should be null when includeStorePatientInfo=false");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks(), "patientLinks should be null when includeStorePatientInfo=false");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 44,
            description =
                    "Request body storePatientInfo=false takes priority over URL includeStorePatientInfo=true"
                            + " - firstName, lastName, type, patientLinks should NOT be populated (body wins)")
    public void getCustomerInfoByPidWhenQueryParamStorePatientInfoTrueButBodyFilterFalse()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = true;  // URL param = true
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body AttributeFilters storePatientInfo=false (takes HIGHEST PRIORITY over URL)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)  // body = false overrides URL true
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Request body false takes priority over URL true → PII fields should NOT be populated
        assertEquals(customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName(),
                "Request body storePatientInfo=false must override URL param storePatientInfo=true");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getLastName(),
                "Request body storePatientInfo=false must override URL param storePatientInfo=true");
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getMiddleName());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getType());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId());
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods());
    }

    @Test(
            priority = 45,
            description =
                    "When caregivers=true for a customer with no caregiver relationships"
                            + " - caregiversInfo should be an empty list [], not null and not an error")
    public void getCustomerInfoByPidWhenCustomerHasNoCaregiversAndCaregiverFilterIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                soloCustomerPatientId,
                soloCustomerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(false)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(soloCustomerStoreNbr, soloCustomerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // caregiversInfo should be an empty list (not null, not an error) when no caregivers exist
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo(),
                "caregiversInfo should be an empty list, not null");
        assertTrue(getCustomerInfoByPidV1Response.getCaregiversInfo().isEmpty(),
                "caregiversInfo should be empty for a customer with no caregivers");

        // Other relationship lists not requested
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertNull(getCustomerInfoByPidV1Response.getDependentsInfo());
    }

    @Test(
            priority = 46,
            description =
                    "When dependents=true for a customer with no dependent relationships"
                            + " - dependentsInfo should be an empty list [], not null and not an error")
    public void getCustomerInfoByPidWhenCustomerHasNoDependentsAndDependentsFilterIsTrue()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                soloCustomerPatientId,
                soloCustomerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(false)
                                        .dependents(true)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(soloCustomerStoreNbr, soloCustomerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // dependentsInfo should be an empty list (not null, not an error) when no dependents exist
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo(),
                "dependentsInfo should be an empty list, not null");
        assertTrue(getCustomerInfoByPidV1Response.getDependentsInfo().isEmpty(),
                "dependentsInfo should be empty for a customer with no dependents");

        // Other relationship lists not requested
        assertNull(getCustomerInfoByPidV1Response.getCustomerInfo());
        assertNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
    }

    @Test(
            priority = 47,
            description =
                    "When paymentMethods=true - validate field-level data: each payment method must have id, type and isEligible populated")
    public void getCustomerInfoByPidVerifyPaymentMethodsFieldLevelData() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(true)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        assertEquals(customerAccountId, getCustomerInfoByPidV1Response.getCustomerInfo().getCustomerAccountId());

        // Field-level validation: if payment methods are present, each entry must have all fields
        if (getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods() != null
                && !getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods().isEmpty()) {
            getCustomerInfoByPidV1Response.getCustomerInfo().getPaymentMethods().forEach(
                    paymentMethod -> {
                        assertNotNull(paymentMethod.getId(),
                                "paymentMethod.id must not be null");
                        assertNotNull(paymentMethod.getType(),
                                "paymentMethod.type must not be null");
                        assertNotNull(paymentMethod.getIsEligible(),
                                "paymentMethod.isEligible must not be null");
                    });
        }
    }

    @Test(
            priority = 48,
            description =
                    "When storePatientInfo=true - validate patientLinks field-level data: each link must have storeNbr and patientId"
                            + " matching the values used during account creation")
    public void getCustomerInfoByPidVerifyPatientLinksFieldLevelData() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(true)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Customer patientLinks - must contain the storeNbr + patientId used during setup
        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks(),
                "patientLinks must be non-null when storePatientInfo=true");
        assertFalse(getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks().isEmpty(),
                "patientLinks must not be empty");

        // Each patientLink entry must have storeNbr and patientId populated
        getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks().forEach(
                link -> {
                    assertNotNull(link.getStoreNbr(), "patientLink.storeNbr must not be null");
                    assertNotNull(link.getPatientId(), "patientLink.patientId must not be null");
                });

        // At least one patientLink should match the storeNbr and patientId used to create the account
        assertTrue(
                getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks().stream()
                        .anyMatch(link ->
                                customerStoreNbr.equals(link.getStoreNbr())
                                        && customerPatientId.equals(link.getPatientId())),
                "patientLinks must contain the storeNbr=" + customerStoreNbr
                        + " and patientId=" + customerPatientId + " used during account creation");

        // Dependents patientLinks - each dependent should also have valid patientLinks
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        getCustomerInfoByPidV1Response.getDependentsInfo().forEach(
                dependent -> {
                    assertNotNull(dependent.getPatientLinks(),
                            "dependent patientLinks must be non-null when storePatientInfo=true");
                    dependent.getPatientLinks().forEach(
                            link -> {
                                assertNotNull(link.getStoreNbr(), "dependent patientLink.storeNbr must not be null");
                                assertNotNull(link.getPatientId(), "dependent patientLink.patientId must not be null");
                            });
                });
    }

    @Test(
            priority = 49,
            description =
                    "When walmartPlusStatus=true - validate actual W+ status value: accounts with W+ membership should"
                            + " have a non-null non-empty status; accounts without W+ should have a different status or null")
    public void getCustomerInfoByPidVerifyWalmartPlusStatusActualValue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(true)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        assertNotNull(getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus(),
                "customer walmartPlusStatus must be non-null since W+ was created in setup");
        String customerStatusStr =
                getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus().name();
        assertFalse(customerStatusStr.trim().isEmpty(),
                "customer walmartPlusStatus must not be an empty string");

        // caregiver1 and caregiver2 both have W+ → at least one caregiver should have non-null status
        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(cg -> cg.getWalmartPlusStatus() != null
                                && !cg.getWalmartPlusStatus().name().trim().isEmpty()),
                "At least one caregiver should have a non-null/non-empty walmartPlusStatus (caregivers have W+ in setup)");

        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(dep -> dep.getWalmartPlusStatus() != null
                                && !dep.getWalmartPlusStatus().name().trim().isEmpty()),
                "At least one dependent (dependent3 ADULT) should have a non-null/non-empty walmartPlusStatus");

        assertTrue(
                List.of("ACTIVE", "INACTIVE", "PAUSED", "CANCELLED", "TRIAL", "W_PLUS")
                        .contains(customerStatusStr),
                "customer walmartPlusStatus '" + customerStatusStr + "' must be a valid known membership status");
    }

    @Test(
            priority = 50,
            description =
                    "When emailId=true - validate that the exact email address value matches the email"
                            + " used during account creation for customer and ADULT dependent")
    public void getCustomerInfoByPidVerifyEmailIdExactValue() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = null;
        Boolean storePatientInfo = null;
        Boolean emailId = null;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(true)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        // Exact email match for the primary customer (not just assertNotNull)
        assertEquals(
                customerEmailId.toLowerCase(),
                getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId().toLowerCase(),
                "Customer emailId must exactly match the email used during account creation");

        // dependent3 is an ADULT with email = dependent3EmailId → exact match in dependentsInfo
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(dep ->
                                dependent3AccountId.equals(dep.getCustomerAccountId())
                                        && dependent3EmailId.toLowerCase()
                                        .equals(dep.getEmailId() != null
                                                ? dep.getEmailId().toLowerCase()
                                                : null)),
                "ADULT dependent3 emailId must exactly match dependent3EmailId=" + dependent3EmailId);

        // dependent1 (PET) and dependent2 (MINOR) are guest accounts with no email → emailId null
        assertNotNull(getCustomerInfoByPidV1Response.getDependentsInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getDependentsInfo().stream()
                        .anyMatch(dep ->
                                (dependent1AccountId.equals(dep.getCustomerAccountId())
                                        || dependent2AccountId.equals(dep.getCustomerAccountId()))
                                        && dep.getEmailId() == null),
                "PET/MINOR dependents (guest accounts) should have null emailId");

        assertNotNull(getCustomerInfoByPidV1Response.getCaregiversInfo());
        assertTrue(
                getCustomerInfoByPidV1Response.getCaregiversInfo().stream()
                        .anyMatch(cg ->
                                caregiver1AccountId.equals(cg.getCustomerAccountId())
                                        && caregiver1EmailId.toLowerCase()
                                        .equals(cg.getEmailId() != null
                                                ? cg.getEmailId().toLowerCase()
                                                : null)),
                "caregiver1 emailId must exactly match caregiver1EmailId=" + caregiver1EmailId);
    }

    @Test(
            priority = 51,
            description =
                    "Query Param Only: When includeWalmartPlusStatus=true in URL and no AttributeFilters in request body"
                            + " - emailId MUST also be populated in the response even though emailId URL param is false/not set."
                            + " This verifies the side-effect documented in the service TODO: when isWPlusStatusRequired=true,"
                            + " the service forces includeEmailId=true (lines 174-176 of GetCustomerInfoByPidService).")
    public void getCustomerInfoByPidVerifyWalmartPlusStatusUrlParamForcesEmailId()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 200, errorMessage);
        Assert.assertNotNull(getCustomerInfoByPidResponse.body());
        Assert.assertNotNull(getCustomerInfoByPidResponse.body().getPayload(), "Payload is null");

        GetCustomerInfoByPidV1Response getCustomerInfoByPidV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getCustomerInfoByPidResponse.body().getPayload()),
                        GetCustomerInfoByPidV1Response.class);

        assertNotNull(
                getCustomerInfoByPidV1Response.getCustomerInfo().getWalmartPlusStatus(),
                "walmartPlusStatus must be non-null when includeWalmartPlusStatus URL param=true");

        assertNotNull(
                getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId(),
                "emailId MUST be populated even though emailId URL param=false — "
                        + "includeWalmartPlusStatus=true forces includeEmailId=true in the service");
        assertEquals(
                customerEmailId.toLowerCase(),
                getCustomerInfoByPidV1Response.getCustomerInfo().getEmailId().toLowerCase(),
                "emailId value must match the email used during account creation (forced by walmartPlusStatus=true)");

        assertNull(
                getCustomerInfoByPidV1Response.getCustomerInfo().getFirstName(),
                "firstName must be null — storePatientInfo URL param=false");
        assertNull(
                getCustomerInfoByPidV1Response.getCustomerInfo().getLastName(),
                "lastName must be null — storePatientInfo URL param=false");
        assertNull(
                getCustomerInfoByPidV1Response.getCustomerInfo().getPatientLinks(),
                "patientLinks must be null — storePatientInfo URL param=false");
    }

    public void logFlowIdentifiers(
            String domainId,
            String patientId,
            String storeNbr,
            String reqId,
            String reqTrackingId,
            Boolean walmartPlusStatus,
            Boolean storePatientInfo,
            Boolean emailId) {
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("patientId", patientId);
        Reporter.logJSON("storeNbr", storeNbr);
        Reporter.logJSON("walmartPlusStatusFlag", walmartPlusStatus);
        Reporter.logJSON("storePatientInfoFlag", storePatientInfo);
        Reporter.logJSON("emailId", emailId);
    }
}
