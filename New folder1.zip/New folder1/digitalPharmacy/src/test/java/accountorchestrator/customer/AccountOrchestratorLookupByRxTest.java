package accountorchestrator.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.DropOff.Drug;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.DropOff.FetchDrug;
import com.walmart.hwqe.commons.datacontext.DataTable;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.LookupByRxV1RequestObject;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import static accountorchestrator.constants.AccountOrchestratorConstants.generatePassword;
import org.apache.commons.lang3.RandomStringUtils;
import org.jetbrains.annotations.NotNull;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class AccountOrchestratorLookupByRxTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();

    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";


    private String dynamicStoreNbr;
    private String dynamicRxNbr1;      // For single-item tests (P4, P7, P8)
    private String dynamicRxNbr2;      // For multi-item tests (P5, P9 - item 1)
    private String dynamicRxNbr3;      // For multi-item tests (P5, P9 - item 2)
    private String dynamicDob;
    private int dynamicPatientId;

    // Connexus wrapper managers
    private ConnexusAPIManager connexusAPIManager;
    private WrapperAPIManager wrapperAPIManager;
    private AutomationManager automationManager;
    private DBUtils dbUtils;
    private WrapperUtils wrapperUtils;

    private String domainId = WM_PHARMACY_DOMAIN;  // Default domain for most tests

    // ── Path C (HTTP 200 full success) — patient with dotcom account linked (OCID set in Account Entity) ──
    // createDigitalPharmacyConnectedStorePatientAccount creates: PMART + CPR + walmart.com account + Account Entity OCID.
    // Without OCID, ACCEN returns onlineAccountId=null → always DPR-DPACCOR-2007 → HTTP 206 (never HTTP 200).
    private String linkedCid;         // OCP customerAccountId (= onlineAccountId from Account Entity)
    private String linkedRxNbr;       // Rx created for the linked patient — used in P27 (WM) and P28 (SAMS)
    private String linkedFirstName;   // patientFirstName as set in @BeforeClass (CPR uppercases names)
    private int linkedPatientId;      // CPR-verified patientId for linked patient — used in P27/P28 OCID write
    private String linkedDob;         // DOB for linked patient (MMddyyyy) — used in P27/P28 OCID write body

    // ── Path C second patient (p200) — dedicated to P27/P29 WM-PHARMACY full-success tests ───────
    // Created FIRST in setContext so createDigitalPharmacyConnectedStorePatientAccount's internal
    // AE write (WM-PHARMACY) and RXOR dot-com sync (~9 min) complete before P27 runs (~10 min later).
    // p200RxNbr1/2 are created immediately after the dot-com account is set up, maximising
    // the RXOR indexing window. No AE write needed inside P27/P29 — already set up here.
    private String p200Cid;           // OCP customerAccountId for p200 patient
    private int    p200PatientId;     // CPR-verified patientId for p200 patient
    private String p200Dob;           // DOB for p200 patient (MMddyyyy)
    private String p200RxNbr1;        // For P27 (WM-PHARMACY single-item) and P29 item1
    private String p200RxNbr2;        // For P29 (WM-PHARMACY multi-item item2)

    // ── Path C MINOR patient (p300) — dedicated to P30 WM-PHARMACY MINOR patientType guard ──────
    // patientTypeCode=HUMAN + DOB=10 years ago → getPatientType returns Type.MINOR.
    // callGetPersonByCustomerAccountId guard: ADULT check → false → GetPerson NOT called → emailId=null.
    // Distinct from P28 (SAMS-PHARMACY domain guard) — tests the patientType branch specifically.
    private String p300Cid;           // standalone dotcom CID (no pharmacy patient linkage, no RXOR sync)
    private int    p300PatientId;     // MINOR Connexus patient patientId (DOB = 10 years ago)
    private String p300Dob;           // DOB for p300 MINOR patient (MMddyyyy format)
    private String p300RxNbr1;        // Rx for P30 (WM-PHARMACY MINOR single-item)

    // Static constants - QA2 infrastructure requirements
    private static final String CONTROL_CODE = "2304";       // Non-controlled drugs
    private static final int REQUEST_TYPE_CODE = 1600;

    // Domain ID constants
    private static final String WM_PHARMACY_DOMAIN = "WM-PHARMACY";
    private static final String SAMS_PHARMACY_DOMAIN = "SAMS-PHARMACY";
    private static final int PRIORITY_ID = 21101;
    private static final int DISPENSE_TYPE = 1;
    private static final int NUM_REFILLS = 30;
    private static final Random random = new Random();

    @BeforeClass
    void setContext() throws Exception {
        // Initialize components
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        connexusAPIManager = new ConnexusAPIManager();
        wrapperAPIManager = new WrapperAPIManager();
        automationManager = AutomationManager.getInstance();
        dbUtils = new DBUtils();
        wrapperUtils = new WrapperUtils();

        // ── Step 1: Set store number (Connexus-enabled store in QA2) ───────────
        dynamicStoreNbr = "5548";
        int storeId = Integer.parseInt(dynamicStoreNbr);

        // ── Step 2: Generate dynamic DOB (18–59 years old) ─────────────────────
        LocalDate dob = LocalDate.now().minusYears(18 + random.nextInt(42));
        dynamicDob = dob.format(DateTimeFormatter.ofPattern("MMddyyyy"));
        String dobDotNet = "/Date(" + dob.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() + ")/";

        // ── Step 3: Create p200 patient FIRST — maximises RXOR indexing time before P27 ──
        // createDigitalPharmacyConnectedStorePatientAccount: patient → CPR (12s sleep) →
        // walmart.com account → AE write (WM-PHARMACY OCID) → enableTestAccountInQa (internal).
        // The walmart.com account creation triggers RXOR dot-com sync (~9 min) for p200PatientId.
        // Starting this FIRST gives ~10+ min of RXOR sync time before P27 runs.
        DigitalPharmacyAPIManager dpApiManager = new DigitalPharmacyAPIManager();
        p200Dob = "0101" + LocalDate.now().minusYears(25).getYear();
        String p200Password = generatePassword();
        String p200Email    = CommonUtil.generateRandomEmailId(10);
        String p200FirstName = CommonUtil.generateRandomFirstName(5);
        String p200LastName  = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil p200DpUtil = new DigitalPharmacyOperationsUtil(
                storeId,
                p200FirstName,
                p200LastName,
                p200Dob,
                0,
                p200Email,
                p200Password);
        // Internally: Connexus patient → 12s CPR sleep → walmart.com account →
        //             AE write (WM-PHARMACY p200PatientId→p200Cid) → enableTestAccountInQa.
        p200DpUtil.createDigitalPharmacyConnectedStorePatientAccount(false, false);

        p200Cid = dpApiManager.getCidFromEmailUsingAstro(p200Email);
        p200PatientId = dpApiManager.getStorePatientIdFromCPR(
                p200DpUtil.getPatientFirstName(),
                p200DpUtil.getPatientLastName(),
                p200DpUtil.getDates().get(1),
                storeId + "");
        Assert.assertNotNull(p200Cid,
                "p200Cid must not be null — getCidFromEmailUsingAstro must return a valid CID");
        Assert.assertTrue(p200PatientId > 0,
                "p200PatientId from CPR must be positive — getStorePatientIdFromCPR returned 0 or negative");

        // Create p200 Rx immediately — RXOR dot-com sync is in progress; Rx will be indexed
        // when sync completes (~9 min). P27 runs ~10+ min after this point.
        p200RxNbr1 = createDynamicRx(storeId, p200PatientId, "Rx #1 for p200 WM-PHARMACY path (P27/P29 item1)");
        p200RxNbr2 = createDynamicRx(storeId, p200PatientId, "Rx #2 for p200 WM-PHARMACY path (P29 item2)");

        // ── Step 3b: Create p300 MINOR patient — for P30 WM-PHARMACY MINOR patientType guard ──
        // Uses same createDigitalPharmacyConnectedStorePatientAccount pattern as p200:
        //   Connexus patient (MINOR DOB) → 12s CPR sleep → walmart.com account →
        //   AE write (WM-PHARMACY OCID: p300PatientId→p300Cid) → enableTestAccountInQa.
        // patientTypeCode=HUMAN + DOB=10 years ago < AGE_OF_MAJORITY(18)
        //   → CommonUtil.getPatientType returns Type.MINOR → ADULT guard fails → emailId=null.
        // AE WM-PHARMACY OCID written internally here — P30 does NOT write AE manually (avoids 409).
        // 12s CPR sleep ensures getCidFromEmailUsingAstro succeeds (account indexed before lookup).
        p300Dob = "0101" + LocalDate.now().minusYears(10).getYear();
        String p300Password  = generatePassword();
        String p300Email     = CommonUtil.generateRandomEmailId(10);
        String p300FirstName = CommonUtil.generateRandomFirstName(5);
        String p300LastName  = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil p300DpUtil = new DigitalPharmacyOperationsUtil(
                storeId,
                p300FirstName,
                p300LastName,
                p300Dob,
                0,
                p300Email,
                p300Password);
        p300DpUtil.createDigitalPharmacyConnectedStorePatientAccount(false, false);

        p300Cid = dpApiManager.getCidFromEmailUsingAstro(p300Email);
        p300PatientId = dpApiManager.getStorePatientIdFromCPR(
                p300DpUtil.getPatientFirstName(),
                p300DpUtil.getPatientLastName(),
                p300DpUtil.getDates().get(1),
                storeId + "");
        Assert.assertNotNull(p300Cid,
                "p300Cid must not be null — getCidFromEmailUsingAstro must return a valid CID for p300Email");
        Assert.assertTrue(p300PatientId > 0,
                "p300PatientId from CPR must be positive — getStorePatientIdFromCPR returned 0 or negative");

        p300RxNbr1 = createDynamicRx(storeId, p300PatientId, "Rx for p300 MINOR WM-PHARMACY path (P30)");

        // ── Step 4: Create Connexus patient → patientId ────────────────────────
        AddPatient addPatient = buildAddPatient(storeId, dobDotNet);
        dynamicPatientId = connexusAPIManager.addPatientWithGenericAllParam(addPatient);
        Assert.assertTrue(dynamicPatientId > 0, "Connexus addPatient failed — patientId is 0 or negative");

        // ── Step 5: Create 3 dynamic Rx prescriptions ──────────────────────────
        dynamicRxNbr1 = createDynamicRx(storeId, dynamicPatientId, "Rx #1 for single-item tests");
        dynamicRxNbr2 = createDynamicRx(storeId, dynamicPatientId, "Rx #2 for multi-item tests");
        dynamicRxNbr3 = createDynamicRx(storeId, dynamicPatientId, "Rx #3 for multi-item tests");

        // ── Step 6: Create patient with linked dotcom account (OCID) for HTTP 200 full success path ──
        // This patient has: PMART record (Connexus) + CPR record + walmart.com dotcom account +
        // Account Entity record (onlineAccountId = OCID).
        // Service Path C: RXOR found → CPR patientInfo non-null → accEnResponse.getOnlineAccountId() non-null
        //                 → customerAccountId set → applyExecutionState COMPLETE → HTTP 200.
        // Without this OCID, all Connexus-only patients always hit Path D (2007) → HTTP 206 (never HTTP 200).
        String linkedPassword = generatePassword();
        String linkedEmail    = CommonUtil.generateRandomEmailId(10);
        String linkedFirstNameLocal = CommonUtil.generateRandomFirstName(5);
        String linkedLastNameLocal  = CommonUtil.generateRandomLastName(5);
        // DOB in MMddyyyy format — 25-year-old adult (ADULT patientType in CPR)
        linkedDob = "0101" + LocalDate.now().minusYears(25).getYear();

        DigitalPharmacyOperationsUtil linkedDpUtil = new DigitalPharmacyOperationsUtil(
                storeId,
                linkedFirstNameLocal,
                linkedLastNameLocal,
                linkedDob,
                0,
                linkedEmail,
                linkedPassword);

        // Creates: patient via Connexus wrapper API → CPR propagation (sleep 12 s) →
        //          dotcom account (Astro) → Account Entity pharmacy account (OCID via .stg URL) → enableTestAccountInQa.
        linkedDpUtil.createDigitalPharmacyConnectedStorePatientAccount(false, false);

        // Retrieve the OCP customerAccountId (= OCID stored in Account Entity)
        linkedCid       = dpApiManager.getCidFromEmailUsingAstro(linkedEmail);
        linkedFirstName = linkedDpUtil.getPatientFirstName();

        // Fetch CPR-verified patientId — ensures Account Entity key matches CPR patientLinks.
        linkedPatientId = dpApiManager.getStorePatientIdFromCPR(
                linkedDpUtil.getPatientFirstName(),
                linkedDpUtil.getPatientLastName(),
                linkedDpUtil.getDates().get(1),
                storeId + "");
        Assert.assertTrue(linkedPatientId > 0,
                "linkedPatientId from CPR must be positive — getStorePatientIdFromCPR returned 0 or negative");
        Assert.assertNotNull(linkedCid,
                "linkedCid must not be null — getCidFromEmailUsingAstro must return a valid CID");

        // Create Rx for the linked patient BEFORE enableTestAccountInQa so RXOR has the maximum
        // possible time to async-index the Rx before P27/P28/P29 run.
        // RXOR indexes Rx numbers asynchronously; creating early maximises the indexing window.
        linkedRxNbr = createDynamicRx(storeId, linkedPatientId, "Rx for HTTP 200 full-success path (P27/P28/P29)");

        // Write WM-PHARMACY OCID to Account Entity (QA2) with CPR-verified patientId.
        linkedDpUtil.enableTestAccountInQa(
                linkedCid,
                storeId + "",
                linkedPatientId + "",
                linkedDpUtil.getPatientDob());
    }

    @Test(
            priority = 1,
            description = "Lookup by rx Invalid domainId",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1InvalidDomainId(String payload, String domainId) throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");

        // — no hardcoded domain value in the test code.
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid input request. domainId " + domainId + " in input is invalid");
    }

    @Test(
            priority = 2,
            description = "Lookup by rx Rx_Nbr is Null",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1RxNbrIsNull(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        // Error message must reference the null rxNbr — assert case-insensitive substring.
        Assert.assertTrue(
                errorResponse.getMessage() != null
                        && errorResponse.getMessage().toLowerCase().contains("rx nbr"),
                "Expected error message referencing 'Rx nbr' (null/empty) but got: "
                        + errorResponse.getMessage());
    }

    @Test(
            priority = 3,
            description = "Lookup by rx Store_Nbr is Null",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1StoreNbrIsNull(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        // Error message must reference the null storeNbr — assert case-insensitive substring.
        Assert.assertTrue(
                errorResponse.getMessage() != null
                        && errorResponse.getMessage().toLowerCase().contains("store nbr"),
                "Expected error message referencing 'Store nbr' (null/empty) but got: "
                        + errorResponse.getMessage());
    }

    @Test(
            priority = 4,
            description = "Lookup by rx 206 partial success — Rx found in RXOR, CPR returns patientInfo "
                    + "(Connexus patient is synced to CPR in QA2), but OCID lookup returns no onlineAccountId "
                    + "→ getOcidNotFoundError() → DPR-DPACCOR-2007. customerInfo IS built (firstName + dob "
                    + "from CPR patientInfo) but customerAccountId is null. HTTP 206.")
    void getLookupByRxV1Success() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data from @BeforeClass
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        // Track requested rxNbr for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses

        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(1, responseList.size());

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        // customerInfo IS built: CPR returns patientInfo (Connexus patient is synced to CPR).
        // OCID not found → customerAccountId is null; firstName and dob come from CPR patientInfo.
        Set<String> customerAccountIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getCustomerAccountId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> patientIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getPatientId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> firstNameSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getFirstName).orElse(null))
                .collect(Collectors.toSet());
        Set<String> dobSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getDob).orElse(null))
                .collect(Collectors.toSet());

        // rxNbr — RXOR echoes it back from upstream when Rx is found
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);

        // patientId — non-null and non-empty: RXOR returns storePatientId for this Rx
        Assert.assertTrue(patientIdSet.stream().allMatch(id -> id != null && !id.isEmpty()),
                "patientId must be non-null and non-empty — RXOR sets storePatientId when Rx is found in upstream");

        // customerAccountId — null: OCID lookup returns no onlineAccountId → getOcidNotFoundError()
        Assert.assertTrue(customerAccountIdSet.contains(null),
                "customerAccountId must be null — OCID not found, service calls getOcidNotFoundError()");

        // firstName — non-null and non-empty: CPR patientInfo is present, firstName set from patientInfo.getFirstName()
        Assert.assertTrue(firstNameSet.stream().allMatch(fn -> fn != null && !fn.isEmpty()),
                "firstName must be non-null and non-empty — CPR patientInfo is present and provides firstName");

        // dob — non-null and non-empty: CPR patientInfo is present, dob formatted from patientInfo.getBirthDate()
        Assert.assertTrue(dobSet.stream().allMatch(d -> d != null && !d.isEmpty()),
                "dob must be non-null and non-empty — CPR patientInfo is present and provides birthDate");
    }

    @Test(
            priority = 5,
            description = "Lookup by rx 206 partial success — two Rx items with mixed per-item errors. "
                    + "Item 1: dynamicRxNbr2 (real Connexus Rx) → RXOR found → CPR patientInfo non-null → "
                    + "OCID not found → DPR-DPACCOR-2007 (Customer Profile Not Found In OCP). "
                    + "Item 2: nonExistentRxNbr ('999999999') → RXOR returns rxNumber=null → "
                    + "DPR-DPACCOR-4003 (Rx Not Found in Upstream). "
                    + "Both items have null customerAccountId. HTTP 206.")
    void getLookupByRxV1SuccessMultipleItems() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Item 1: real Connexus Rx → RXOR found → OCID not found → DPR-DPACCOR-2007
        // Item 2: non-existent Rx → RXOR returns null rxNumber → DPR-DPACCOR-4003
        String nonExistentRxNbr = "999999999";
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}]",
                dynamicRxNbr2, dynamicStoreNbr, nonExistentRxNbr, dynamicStoreNbr);

        // Track requested rxNbrs for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr2);
        requestedRxNbrs.add(nonExistentRxNbr);

        // Parse JSON payload to request object
        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        // HTTP 206 = partial success: multiple Rx items returned but at least one per-item
        // downstream lookup (e.g. OCID/customer profile) has an error.
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(2, responseList.size());

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        // customerAccountId: null for both items.
        // DPR-DPACCOR-2007 item: customerInfo IS built (OCID not found) → customerAccountId null via Optional.
        // DPR-DPACCOR-4003 item: customerInfo is null (RXOR not found, service exits early) → customerAccountId null via orElse(null).
        Set<String> customerAccountIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getCustomerAccountId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // rxNbrs — both echoed back (RXOR found → rxNumber; RXOR not found → lookupRequest.getRxNbr())
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);

        // customerAccountId — null for both items regardless of which path each item takes
        Assert.assertTrue(customerAccountIdSet.contains(null),
                "customerAccountId must be null — either OCID not found (2007) or RXOR not found (4003)");

        // Error code: one item hit OCID-not-found path → DPR-DPACCOR-2007 (ACCOUNT_ENTITY_SERVICE_CUSTOMER_PROFILE_NOT_FOUND_IN_OCP_EXCEPTION)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) but got: "
                        + errorCodeResponseSet);

        // Error code: one item hit RXOR-not-found path → DPR-DPACCOR-4003 (RX_ORCHESTRATOR_SERVICE_RX_NOT_FOUND_IN_UPSTREAM_EXCEPTION)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found In Upstream) but got: "
                        + errorCodeResponseSet);

        // Error message: OCID-not-found item → CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: "
                        + errorResponseSet);

        // Error message: RXOR-not-found item → RX_NOT_FOUND_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 6,
            description = "Lookup by rx 206 partial success response for SAMS-PHARMACY — "
                    + "Uses WM store Rx with SAMS domain to test domain parameter handling. "
                    + "Uses dynamically created Rx from @BeforeClass.")
    void getLookupByRxV1SuccessSams() throws IOException {
        String domainId = SAMS_PHARMACY_DOMAIN;
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data (using WM store Rx with SAMS domain)
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        // Track requested rxNbr for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);


        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(1, responseList.size());

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        // customerInfo IS built: CPR returns patientInfo (Connexus patient synced to CPR).
        // OCID not found → customerAccountId null; firstName and dob come from CPR patientInfo.
        // SAMS-PHARMACY domain: Domain.WM_PHARMACY check in callGetPersonByCustomerAccountId
        // skips the GetPerson call, but OCID lookup via ACCEN is still performed.
        Set<String> customerAccountIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getCustomerAccountId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> patientIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getPatientId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> firstNameSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getFirstName).orElse(null))
                .collect(Collectors.toSet());
        Set<String> dobSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getDob).orElse(null))
                .collect(Collectors.toSet());

        // rxNbr — RXOR echoes it back from upstream when Rx is found
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);

        // patientId — non-null and non-empty: RXOR returns storePatientId for dynamicRxNbr1
        Assert.assertTrue(patientIdSet.stream().allMatch(id -> id != null && !id.isEmpty()),
                "patientId must be non-null and non-empty — RXOR sets storePatientId when Rx is found in upstream");

        // customerAccountId — null: OCID lookup returns no onlineAccountId → getOcidNotFoundError()
        Assert.assertTrue(customerAccountIdSet.contains(null),
                "customerAccountId must be null — OCID not found, service calls getOcidNotFoundError()");

        // firstName — non-null and non-empty: CPR patientInfo is present, firstName from patientInfo.getFirstName()
        Assert.assertTrue(firstNameSet.stream().allMatch(fn -> fn != null && !fn.isEmpty()),
                "firstName must be non-null and non-empty — CPR patientInfo is present and provides firstName");

        // dob — non-null and non-empty: CPR patientInfo is present, dob formatted from patientInfo.getBirthDate()
        Assert.assertTrue(dobSet.stream().allMatch(d -> d != null && !d.isEmpty()),
                "dob must be non-null and non-empty — CPR patientInfo is present and provides birthDate");
    }

    @Test(
            priority = 7,
            description = "Lookup by rx partial success with dynamic Connexus Rx data. Expects HTTP 206 "
                    + "with per-item error DPR-DPACCOR-2007 (Customer Profile Not Found In OCP). "
                    + "RXOR finds the Rx (dynamically created), CPR returns patientInfo (Connexus patient "
                    + "is synced to CPR in QA2), but OCID lookup returns no onlineAccountId "
                    + "→ getOcidNotFoundError(). Uses dynamically created Rx from @BeforeClass.")
    void getLookupByRxV1PartialSuccessRxNotFoundInUpstream() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        // Track requested rxNbr for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(1, responseList.size());

        Set<String> rxNbrsSet = responseList.stream().map(
                        apiResponse -> apiResponse.getRxInfo().getRxNbr())
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream().filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream().filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // rxNbr is derived dynamically from the request payload — response must echo it back.
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);

        // Error code — always DPR-DPACCOR-2007: RXOR finds the Rx, CPR returns patientInfo (non-null),
        // but OCID lookup returns no onlineAccountId → getOcidNotFoundError() → ACCOUNT_ENTITY_SERVICE_CUSTOMER_PROFILE_NOT_FOUND_IN_OCP_EXCEPTION
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) but got: "
                        + errorCodeResponseSet);

        // Error message — always "Customer Profile Not Found In OCP": set by CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: "
                        + errorResponseSet);

    }

    @Test(
            priority = 8,
            description =
                    "Lookup by rx partial success with dynamic Connexus Rx data. Expects HTTP 206 with "
                            + "per-item error DPR-DPACCOR-2007 (Customer Profile Not Found In OCP). "
                            + "RXOR finds the Rx (dynamically created), CPR returns patientInfo (Connexus patient "
                            + "is synced to CPR in QA2), but OCID lookup returns no onlineAccountId "
                            + "→ getOcidNotFoundError(). Uses dynamically created Rx from @BeforeClass.")
    void getLookupByRxV1PartialSuccessCustomerProfileNotFoundInOCP() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        // Track requested rxNbr for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(1, responseList.size());

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        // Service: when OCID not found, customerInfo IS built (sans customerAccountId) — use null-safe access
        Set<String> customerAccountIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getCustomerAccountId).orElse(null))
                .collect(Collectors.toSet());
        Set<String> patientIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getPatientId).orElse(null))
                .collect(Collectors.toSet());
        // Null-safe: filter items that have a per-item error before extracting message/code
        Set<String> errorResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // rxNbr is derived dynamically from the request payload — response must echo it back.
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);
        // customerAccountId — null: customerInfo IS built (CPR patientInfo non-null), but OCID not found
        Assert.assertTrue(customerAccountIdSet.contains(null),
                "customerAccountId must be null — OCID not found, service calls getOcidNotFoundError()");

        // patientId — non-null and non-empty: RXOR returns storePatientId for dynamicRxNbr1
        Assert.assertTrue(patientIdSet.stream().allMatch(id -> id != null && !id.isEmpty()),
                "patientId must be non-null and non-empty — RXOR sets storePatientId when Rx is found in upstream");

        // Error code — always DPR-DPACCOR-2007: RXOR finds the Rx, CPR returns patientInfo (non-null),
        // but OCID lookup returns no onlineAccountId → getOcidNotFoundError() → ACCOUNT_ENTITY_SERVICE_CUSTOMER_PROFILE_NOT_FOUND_IN_OCP_EXCEPTION
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) but got: "
                        + errorCodeResponseSet);

        // Error message — always "Customer Profile Not Found In OCP": set by CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 9,
            description =
                    "Lookup by rx partial success — multi-item request with mixed data. "
                            + "Item 1: dynamicRxNbr2 (real Connexus Rx) → RXOR found → CPR patientInfo non-null → "
                            + "OCID not found → DPR-DPACCOR-2007 (Customer Profile Not Found In OCP). "
                            + "Item 2: nonExistentRxNbr ('888888888') → RXOR returns rxNumber=null → "
                            + "DPR-DPACCOR-4003 (Rx Not Found in Upstream). "
                            + "HTTP 206 — applyExecutionState → PARTIAL_COMPLETE (at least one item has error).")
    void getLookupByRxV1PartialSuccessMultipleItems() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Item 1: real Connexus Rx → RXOR found → OCID not found → DPR-DPACCOR-2007
        // Item 2: non-existent Rx → RXOR returns null rxNumber → DPR-DPACCOR-4003
        String nonExistentRxNbr = "888888888";
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}]",
                dynamicRxNbr2, dynamicStoreNbr, nonExistentRxNbr, dynamicStoreNbr);

        // Parse JSON payload to request object
        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Asserting desired responses
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(2, responseList.size());


        // Use Optional for null-safe extraction — service always sets rxInfo from request data
        // (even for RXOR-not-found items), but guard with Optional for safety
        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        Set<String> customerAccountIdSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getCustomerInfo())
                        .map(LookupByRxCustomerInfo::getCustomerAccountId)
                        .orElse(null))
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // Both requested rxNbrs must be echoed back in response
        Assert.assertTrue(rxNbrsSet.contains(dynamicRxNbr2),
                "Response must echo back dynamicRxNbr2: " + dynamicRxNbr2 + " but got: " + rxNbrsSet);
        Assert.assertTrue(rxNbrsSet.contains(nonExistentRxNbr),
                "Response must echo back nonExistentRxNbr: " + nonExistentRxNbr + " but got: " + rxNbrsSet);
        // Error code: one item found by RXOR (CPR found, OCID not found) → DPR-DPACCOR-2007 (ACCOUNT_ENTITY_SERVICE_CUSTOMER_PROFILE_NOT_FOUND_IN_OCP_EXCEPTION)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) but got: "
                        + errorCodeResponseSet);

        // Error code: one item NOT found by RXOR → DPR-DPACCOR-4003 (RX_ORCHESTRATOR_SERVICE_RX_NOT_FOUND_IN_UPSTREAM_EXCEPTION)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found In Upstream) but got: "
                        + errorCodeResponseSet);

        // Error message: OCID-not-found item → CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: "
                        + errorResponseSet);

        // Error message: RXOR-not-found item → RX_NOT_FOUND_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 10,
            description = "Lookup by rx validation — empty string rxNbr should be rejected with HTTP 400. "
                    + "Complements P2 (null rxNbr) by verifying the service also rejects an explicit empty "
                    + "string value for rxNbr with error code DPR-DPACCOR-1001.",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1RxNbrIsEmpty(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        // Error message must reference the empty rxNbr — assert case-insensitive substring.
        Assert.assertTrue(
                errorResponse.getMessage() != null
                        && errorResponse.getMessage().toLowerCase().contains("rx nbr"),
                "Expected error message referencing 'Rx nbr' (null/empty) but got: "
                        + errorResponse.getMessage());
    }

    @Test(
            priority = 11,
            description = "Lookup by rx validation — empty string storeNbr should be rejected with HTTP 400. "
                    + "Complements P3 (null storeNbr) by verifying the service also rejects an explicit empty "
                    + "string value for storeNbr with error code DPR-DPACCOR-1001.",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1StoreNbrIsEmpty(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        // Error message must reference the empty storeNbr — assert case-insensitive substring.
        Assert.assertTrue(
                errorResponse.getMessage() != null
                        && errorResponse.getMessage().toLowerCase().contains("store nbr"),
                "Expected error message referencing 'Store nbr' (null/empty) but got: "
                        + errorResponse.getMessage());
    }

    @Test(
            priority = 12,
            description = "Lookup by rx with empty items array [] — the service accepts the request "
                    + "and returns HTTP 200 with an empty result list. No validation error is raised "
                    + "because an empty array is a structurally valid request; the service simply "
                    + "has no items to look up and returns an empty payload.",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1EmptyItemsList(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // The service returns HTTP 200 with an empty payload for an empty items list.
        // It treats [] as a valid no-op request rather than a validation error.
        Assert.assertEquals(getLookupByRxV1Response.code(), 200,
                "Expected HTTP 200 for empty items list but got: "
                        + getLookupByRxV1Response.code());
        Assert.assertNotNull(getLookupByRxV1Response.body(),
                "Expected a non-null response body for empty items list");

        // Payload must be present but empty — no items were requested so none are returned.
        ArrayList<Object> responsePayload =
                (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        Assert.assertNotNull(responsePayload,
                "Expected a non-null payload list in response body");
        Assert.assertTrue(responsePayload.isEmpty(),
                "Expected an empty payload list for empty items request but got: "
                        + responsePayload);
    }

    @Test(
            priority = 13,
            description = "Lookup by rx partial success — Rx number does not exist in the upstream "
                    + "pharmacy system. The service returns HTTP 206 with per-item error "
                    + "DPR-DPACCOR-4003 (Rx Not Found In Upstream). The rxNbr is read dynamically "
                    + "from the Excel payload and must reference an rxNbr that truly does not exist "
                    + "in the QA2 upstream pharmacy system.",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataByEnv")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/accountorchestrator/rxData.xlsx",
            sheetName = "lookupByRxV1")
    void getLookupByRxV1RxNotFoundInUpstream(String payload, String domainId) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Extract rxNbr from the request payload JSON — fully dynamic, no hardcoded values.
        // Payload structure: [{"rxNbr": "...", "storeNbr": "..."}, ...]
        Set<String> requestedRxNbrs = new HashSet<>();
        objectMapper.readTree(payload).forEach(item -> requestedRxNbrs.add(item.path("rxNbr").asText()));

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList =
                extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(1, responseList.size());

        Set<String> rxNbrsSet = responseList.stream().map(
                        apiResponse -> apiResponse.getRxInfo().getRxNbr())
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // rxNbr is derived dynamically from the request payload — response must echo it back.
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: "
                        + requestedRxNbrs + ", got: " + rxNbrsSet);
        // DPR-DPACCOR-4003 = Rx Not Found In Upstream — stable business rule, assert strictly.
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 for Rx Not Found In Upstream but got: "
                        + errorCodeResponseSet);
        // Error message must match ErrorMessageConstants.RX_NOT_FOUND_MESSAGE exactly.
        // Service sets this constant: getRxOrchNotFoundError() → LookupByRxServiceErrorMessages.RX_NOT_FOUND_MESSAGE
        Assert.assertTrue(errorResponseSet.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' (exact match from RX_NOT_FOUND_MESSAGE constant) but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 14,
            description = "Lookup by rx with invalid rxNbr format — non-numeric rxNbr causes downstream " +
                    "RxOrchestrator service error. Service does not validate rxNbr format at API gateway, " +
                    "resulting in HTTP 500 from downstream service. Tests actual service behavior.")
    void getLookupByRxV1InvalidRxNbrFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with invalid (non-numeric) rxNbr
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("ABC123XYZ");  // Invalid: contains letters
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Assert HTTP 500 - service passes invalid rxNbr to RxOrchestrator which causes downstream error
        // Note: Ideally should be 400, but service doesn't validate format before calling downstream
        Assert.assertEquals(getLookupByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 (RxOrchestrator service error) but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 15,
            description = "Lookup by rx with invalid storeNbr format — non-numeric storeNbr is validated " +
                    "by the service and rejected with HTTP 400. Tests input validation for storeNbr field. " +
                    "Uses dynamic Rx from Connexus.")
    void getLookupByRxV1InvalidStoreNbrFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with invalid (non-numeric) storeNbr but valid dynamic rxNbr from Connexus
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);  // Valid dynamic Rx from @BeforeClass
        requestObject.setStoreNbr("STORE123");  // Invalid: contains letters

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Assert HTTP 400 - service validates storeNbr format and rejects invalid values
        Assert.assertEquals(getLookupByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
                "Expected error code DPR-DPACCOR-1001 (Invalid input request) but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 16,
            description = "Lookup by rx with special characters in rxNbr — Tests handling of special " +
                    "characters. Service passes invalid rxNbr to downstream causing HTTP 500. Uses " +
                    "dynamic storeNbr from Connexus setup.")
    void getLookupByRxV1SpecialCharactersInRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with special characters in rxNbr
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("12345@#$%");  // Invalid: special characters
        requestObject.setStoreNbr(dynamicStoreNbr);  // Valid dynamic storeNbr from @BeforeClass

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Assert HTTP 500 - service doesn't validate rxNbr format before calling downstream
        Assert.assertEquals(getLookupByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 (RxOrchestrator service error) but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 17,
            description = "Lookup by rx with very long rxNbr value — Tests boundary condition for field " +
                    "length. Service passes extremely long value to downstream causing HTTP 500. Uses " +
                    "dynamic storeNbr from Connexus setup.")
    void getLookupByRxV1VeryLongRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with extremely long rxNbr (1000 characters)
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("1".repeat(1000));  // Invalid: too long
        requestObject.setStoreNbr(dynamicStoreNbr);  // Valid dynamic storeNbr from @BeforeClass

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Assert HTTP 500 - service doesn't validate rxNbr length before calling downstream
        Assert.assertEquals(getLookupByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 (RxOrchestrator service error) but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 18,
            description = "Lookup by rx with negative rxNbr — Negative rxNbr ('-12345') passes " +
                    "String-level validation but is not found in RXOR (rxNumber == null). " +
                    "→ getRxOrchNotFoundError() → DPR-DPACCOR-4003 + 'Rx Not Found in Upstream' → HTTP 206.")
    void getLookupByRxV1NegativeRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with negative rxNbr — not found in RXOR → Path A → DPR-DPACCOR-4003
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("-12345");  // Negative: passes @NotEmpty but not found in RXOR
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Negative rxNbr → RXOR returns rxNumber=null → applyExecutionState → PARTIAL_COMPLETE → HTTP 206
        Assert.assertEquals(getLookupByRxV1Response.code(), 206,
                "Expected HTTP 206 — negative rxNbr not found in RXOR (Path A) but got: "
                        + getLookupByRxV1Response.code());

        ArrayList<Object> response18 = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList18 = extractLookupByRxV1ResponsePayload(response18);

        Set<String> errorCodeSet18 = responseList18.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> errorMsgSet18 = responseList18.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getMessage())
                .collect(Collectors.toSet());

        // RXOR lookup returns null rxNumber → getRxOrchNotFoundError() → DPR-DPACCOR-4003
        Assert.assertTrue(errorCodeSet18.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found in Upstream) for negative rxNbr but got: "
                        + errorCodeSet18);
        Assert.assertTrue(errorMsgSet18.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' (RX_NOT_FOUND_MESSAGE constant) for negative rxNbr but got: "
                        + errorMsgSet18);
    }

    @Test(
            priority = 19,
            description = "Lookup by rx with zero values — rxNbr='0' and storeNbr='0' pass " +
                    "String-level validation but Rx '0' at store '0' is never found in RXOR " +
                    "(rxNumber == null). → getRxOrchNotFoundError() → DPR-DPACCOR-4003 + " +
                    "'Rx Not Found in Upstream' → HTTP 206.")
    void getLookupByRxV1ZeroValues() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with zero values — rxNbr="0" & storeNbr="0" → not found in RXOR → Path A
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("0");   // Zero: passes @NotEmpty but no Rx with ID "0" exists in RXOR
        requestObject.setStoreNbr("0"); // Zero: passes @NotEmpty but no store "0" exists in RXOR

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Zero rxNbr/storeNbr → RXOR returns rxNumber=null → applyExecutionState → PARTIAL_COMPLETE → HTTP 206
        Assert.assertEquals(getLookupByRxV1Response.code(), 206,
                "Expected HTTP 206 — zero rxNbr/storeNbr not found in RXOR (Path A) but got: "
                        + getLookupByRxV1Response.code());

        ArrayList<Object> response19 = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList19 = extractLookupByRxV1ResponsePayload(response19);

        Set<String> errorCodeSet19 = responseList19.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> errorMsgSet19 = responseList19.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getMessage())
                .collect(Collectors.toSet());

        // RXOR lookup returns null rxNumber → getRxOrchNotFoundError() → DPR-DPACCOR-4003
        Assert.assertTrue(errorCodeSet19.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found in Upstream) for zero rxNbr/storeNbr but got: "
                        + errorCodeSet19);
        Assert.assertTrue(errorMsgSet19.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' (RX_NOT_FOUND_MESSAGE constant) for zero rxNbr/storeNbr but got: "
                        + errorMsgSet19);
    }

    @Test(
            priority = 20,
            description = "Lookup by rx with whitespace-only rxNbr — Tests handling of whitespace. " +
                    "Service passes whitespace to downstream causing HTTP 500. Uses dynamic storeNbr " +
                    "from Connexus setup.")
    void getLookupByRxV1WhitespaceRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with whitespace-only rxNbr
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr("   ");  // Invalid: whitespace only
        requestObject.setStoreNbr(dynamicStoreNbr);  // Valid dynamic storeNbr from @BeforeClass

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Assert HTTP 500 - service doesn't validate/trim rxNbr before calling downstream
        Assert.assertEquals(getLookupByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 (RxOrchestrator service error) but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 21,
            description = "Lookup by rx with multi-item request — One dynamic Rx from Connexus, one " +
                    "non-existent Rx. Tests partial success (HTTP 206) handling with multiple items. " +
                    "With dynamic Connexus data, both items may return errors (Rx Not Found or Customer " +
                    "Profile Not Found), but service should echo back both rxNbrs in response.")
    void getLookupByRxV1MixedSuccessFailureMultiItem() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build multi-item request: one dynamic Rx from Connexus, one non-existent Rx
        String nonExistentRxNbr = "999999999";  // Extremely unlikely to exist

        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}]",
                dynamicRxNbr1, dynamicStoreNbr, nonExistentRxNbr, dynamicStoreNbr);

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Should return 206 (partial success) for multi-item request with errors
        Assert.assertEquals(getLookupByRxV1Response.code(), 206,
                "Expected HTTP 206 for multi-item partial success but got: " + getLookupByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        // Should return 2 items in response
        Assert.assertEquals(responseList.size(), 2,
                "Expected 2 items in response but got: " + responseList.size());

        // Collect rxNbrs from response
        Set<String> rxNbrsSet = responseList.stream()
                .map(item -> Optional.ofNullable(item.getRxInfo())
                        .map(LookupByRxRxInfo::getRxNbr)
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        // Service must echo back both requested rxNbrs
        Assert.assertTrue(rxNbrsSet.contains(dynamicRxNbr1),
                "Response must contain dynamic rxNbr: " + dynamicRxNbr1 + " but got: " + rxNbrsSet);
        Assert.assertTrue(rxNbrsSet.contains(nonExistentRxNbr),
                "Response must contain non-existent rxNbr: " + nonExistentRxNbr + " but got: " + rxNbrsSet);

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getMessage())
                .collect(Collectors.toSet());

        // dynamicRxNbr1: RXOR found → CPR patientInfo non-null (Connexus patient synced to CPR) →
        //                OCID not found → getOcidNotFoundError() → DPR-DPACCOR-2007
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) for dynamicRxNbr1 but got: "
                        + errorCodeResponseSet);
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' (CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant) but got: "
                        + errorResponseSet);

        // nonExistentRxNbr: RXOR returns rxNumber=null → getRxOrchNotFoundError() → DPR-DPACCOR-4003
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found In Upstream) for nonExistentRxNbr but got: "
                        + errorCodeResponseSet);
        Assert.assertTrue(errorResponseSet.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' (RX_NOT_FOUND_MESSAGE constant) but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 22,
            description = "Lookup by rx with lowercase domain — Tests that domainId is case-sensitive. " +
                    "'wm-pharmacy' (lowercase) returns HTTP 500, indicating service requires exact-case " +
                    "domain 'WM-PHARMACY'. Uses dynamic Rx from Connexus.")
    void getLookupByRxV1CaseInsensitiveDomain() throws IOException {
        String domainId = "wm-pharmacy";  // lowercase - not supported
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Service is case-sensitive for domainId - lowercase domain returns HTTP 500
        int responseCode = getLookupByRxV1Response.code();
        Assert.assertEquals(responseCode, 500,
                "Expected HTTP 500 for invalid lowercase domain but got: " + responseCode);
    }

    @Test(
            priority = 23,
            description = "Lookup by rx with mixed-case domain — Tests that domainId is case-sensitive. " +
                    "'Wm-PhArMaCy' (mixed case) returns HTTP 500, indicating service requires exact-case " +
                    "domain 'WM-PHARMACY'. Uses dynamic Rx from Connexus.")
    void getLookupByRxV1MixedCaseDomain() throws IOException {
        String domainId = "Wm-PhArMaCy";  // mixed case - not supported
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx data
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Service is case-sensitive for domainId - mixed-case domain returns HTTP 500
        int responseCode = getLookupByRxV1Response.code();
        Assert.assertEquals(responseCode, 500,
                "Expected HTTP 500 for invalid mixed-case domain but got: " + responseCode);
    }

    @Test(
            priority = 24,
            description = "Lookup by rx with very large multi-item request — Tests handling of " +
                    "multiple items (10 items) to validate batch processing. Uses dynamic Rx data " +
                    "and fills remaining slots with non-existent Rx numbers.")
    void getLookupByRxV1LargeMultiItemRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with 10 items (3 dynamic Rx + 7 non-existent) — using String.join for clean comma separation
        List<String> items24 = new ArrayList<>();

        // Add 3 dynamic Rx from Connexus @BeforeClass setup
        items24.add(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}", dynamicRxNbr1, dynamicStoreNbr));
        items24.add(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}", dynamicRxNbr2, dynamicStoreNbr));
        items24.add(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}", dynamicRxNbr3, dynamicStoreNbr));

        // Add 7 non-existent Rx numbers (999999991 … 999999997)
        for (int i = 1; i <= 7; i++) {
            items24.add(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}", "99999999" + i, dynamicStoreNbr));
        }
        String payload24 = "[" + String.join(",", items24) + "]";

        LookupByRxV1Request request = objectMapper.readValue(payload24, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Should return 206 (partial success) for mixed valid/invalid items
        Assert.assertEquals(getLookupByRxV1Response.code(), 206,
                "Expected HTTP 206 for large multi-item request but got: " + getLookupByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        // Should return 10 items in response
        Assert.assertEquals(responseList.size(), 10,
                "Expected 10 items in response but got: " + responseList.size());
    }

    @Test(
            priority = 25,
            description = "Lookup by rx with duplicate rxNbr in multi-item request — Tests handling " +
                    "of duplicate Rx numbers in the same request. LookupByRxV1Request has no " +
                    "@EqualsAndHashCode so each item is a distinct object reference; getRequestOrderMap " +
                    "maps them to indices 0 and 1 without collision. Service processes both items " +
                    "independently. Both hit RXOR found → CPR patientInfo non-null → OCID not found " +
                    "→ HTTP 206, 2 items, each with error DPR-DPACCOR-2007 (Customer Profile Not Found In OCP).")
    void getLookupByRxV1DuplicateRxInMultiItem() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with duplicate rxNbr (same dynamic Rx twice)
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}]",
                dynamicRxNbr1, dynamicStoreNbr, dynamicRxNbr1, dynamicStoreNbr);  // Same Rx twice

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        // Parsing errorResponse from the errorBody of received response
        Error errorResponse = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);

        // Building errorMessage in case the Assert fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // HTTP 206 — both items have a per-item error (OCID not found) → PARTIAL_COMPLETE
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        // Service processes each request item independently (no deduplication) — always 2 items
        Assert.assertEquals(responseList.size(), 2,
                "Expected 2 items in response — service processes each request object independently, got: "
                        + responseList.size());

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getMessage())
                .collect(Collectors.toSet());

        // Error code — always DPR-DPACCOR-2007 for both items: RXOR finds each Rx, CPR returns patientInfo
        // (Connexus patient synced to CPR in QA2), but OCID not found → getOcidNotFoundError() → ACCOUNT_ENTITY_SERVICE_CUSTOMER_PROFILE_NOT_FOUND_IN_OCP_EXCEPTION
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) but got: "
                        + errorCodeResponseSet);

        // Error message — always "Customer Profile Not Found In OCP" for both items: set by CUSTOMER_NOT_FOUND_IN_OCP_MESSAGE constant
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: "
                        + errorResponseSet);
    }

    @Test(
            priority = 26,
            description = "Lookup by rx with same rxNbr but different stores in multi-item request. "
                    + "Item 1: dynamicRxNbr1 at dynamicStoreNbr (5548) → RXOR found, CPR patientInfo non-null, "
                    + "OCID not found → DPR-DPACCOR-2007. "
                    + "Item 2: dynamicRxNbr1 at store 5549 → RXOR returns null (Rx belongs to store 5548 only) "
                    + "→ DPR-DPACCOR-4003. Both items have per-item errors → applyExecutionState PARTIAL_COMPLETE "
                    + "→ HTTP 206. LookupByRxV1Request has no @EqualsAndHashCode so the two objects are distinct "
                    + "and both are processed independently by getRequestOrderMap.")
    void getLookupByRxV1SameRxDifferentStores() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request: item 1 uses dynamicStoreNbr (Rx exists here),
        //                item 2 uses a different store where this Rx does NOT exist
        String differentStore = "5549";
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\"}]",
                dynamicRxNbr1, dynamicStoreNbr, dynamicRxNbr1, differentStore);

        LookupByRxV1Request request = objectMapper.readValue(payload, LookupByRxV1Request.class);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // Both items have per-item errors → applyExecutionState() → PARTIAL_COMPLETE → HTTP 206
        Assert.assertEquals(getLookupByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        // Service processes each request item independently — always 2 items
        Assert.assertEquals(responseList.size(), 2,
                "Expected 2 items in response but got: " + responseList.size());

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> errorResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getMessage())
                .collect(Collectors.toSet());

        // Item 1 (dynamicStoreNbr): RXOR found → CPR patientInfo non-null → OCID not found → DPR-DPACCOR-2007
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP) for item at dynamicStoreNbr but got: "
                        + errorCodeResponseSet);
        Assert.assertTrue(errorResponseSet.contains("Customer Profile Not Found In OCP"),
                "Expected error message 'Customer Profile Not Found In OCP' but got: " + errorResponseSet);

        // Item 2 (differentStore 5549): RXOR returns rxNumber=null → DPR-DPACCOR-4003 (Rx belongs to store 5548 only)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found In Upstream) for item at store 5549 but got: "
                        + errorCodeResponseSet);
        Assert.assertTrue(errorResponseSet.contains("Rx Not Found in Upstream"),
                "Expected error message 'Rx Not Found in Upstream' but got: " + errorResponseSet);
    }

    @Test(
            priority = 27,
            description = "Lookup by rx full success — WM-PHARMACY, single item, p200 patient (OCID pre-set). "
                    + "Service Path C: RXOR found → CPR patientInfo non-null → accEnResponse.getOnlineAccountId() "
                    + "non-null → customerAccountId = p200Cid → applyExecutionState COMPLETE → HTTP 200. "
                    + "callGetPersonByCustomerAccountId is called (WM-PHARMACY + ADULT) → emailId populated "
                    + "from the GetPerson API response. No per-item error. "
                    + "AE WM-PHARMACY mapping (p200Cid → p200PatientId) written internally by "
                    + "createDigitalPharmacyConnectedStorePatientAccount in @BeforeClass — no AE write needed here.")
    void getLookupByRxV1FullSuccessWmPharmacy() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // AE WM-PHARMACY mapping (p200Cid → p200PatientId) already written by
        // p200DpUtil.createDigitalPharmacyConnectedStorePatientAccount in @BeforeClass.
        // No explicit AE write needed here.
        // Service chain: RXOR(p200RxNbr1)→p200PatientId → CPR→patientInfo → AE→p200Cid → HTTP 200.
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(p200RxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // All items succeed → applyExecutionState returns COMPLETE → HTTP 200
        Assert.assertEquals(getLookupByRxV1Response.code(), 200, errorMessage);

        // No top-level error in response body
        Assert.assertNull(getLookupByRxV1Response.body().getError(),
                "Top-level error must be null for a full success HTTP 200 response");

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1,
                "Expected 1 item in response but got: " + responseList.size());

        LookupByRxV1Response item = responseList.get(0);
        LookupByRxCustomerInfo customerInfo = item.getCustomerInfo();

        // No per-item error — OCID was found, no error path was triggered
        Assert.assertNull(item.getError(),
                "Per-item error must be null — service Path C: all lookups succeeded (RXOR + CPR + OCID)");

        // customerAccountId = onlineAccountId from Account Entity → matches p200Cid
        Assert.assertEquals(customerInfo.getCustomerAccountId(), p200Cid,
                "customerAccountId must equal p200Cid (= OCP onlineAccountId from Account Entity) "
                        + "— OCID found by accEnResponse.getOnlineAccountId()");

        // firstName populated from CPR patientInfo.getFirstName() — always non-null/non-empty
        Assert.assertTrue(customerInfo.getFirstName() != null && !customerInfo.getFirstName().isEmpty(),
                "firstName must be non-null and non-empty — set from CPR patientInfo.getFirstName()");

        // dob populated from CPR patientInfo.getBirthDate() → CommonUtil.changeDateFormat(...)
        Assert.assertTrue(customerInfo.getDob() != null && !customerInfo.getDob().isEmpty(),
                "dob must be non-null and non-empty — set from CPR patientInfo.getBirthDate()");

        // emailId populated from GetPerson API — callGetPersonByCustomerAccountId is called when
        // domainId == WM_PHARMACY AND patientType == ADULT AND customerAccountId non-empty.
        // NOTE: Generated LookupByRxCustomerInfo model is missing emailId (Swagger codegen ran before field was added).
        //       Extract directly from raw LinkedTreeMap to avoid compile error.
        LinkedTreeMap<String, Object> rawItem27 = (LinkedTreeMap<String, Object>) response.get(0);
        LinkedTreeMap<String, Object> rawCustomerInfo27 =
                (LinkedTreeMap<String, Object>) rawItem27.get("customerInfo");
        String emailId27 = rawCustomerInfo27 != null ? (String) rawCustomerInfo27.get("emailId") : null;

        Assert.assertTrue(emailId27 != null && !emailId27.isEmpty(),
                "emailId must be non-null and non-empty — WM-PHARMACY + ADULT: "
                        + "callGetPersonByCustomerAccountId is called → GetPerson returns emailId. "
                        + "Actual value: " + emailId27);
    }

    @Test(
            priority = 28,
            description = "Lookup by rx full success — SAMS-PHARMACY, single item, linked patient (OCID set). "
                    + "Service Path C: RXOR found → CPR patientInfo non-null → accEnResponse.getOnlineAccountId() "
                    + "non-null → customerAccountId = linkedCid → applyExecutionState COMPLETE → HTTP 200. "
                    + "callGetPersonByCustomerAccountId is NOT called for SAMS-PHARMACY "
                    + "(condition: Domain.WM_PHARMACY.getDomainId().equals(domainId) fails) → emailId = null. "
                    + "customerAccountId IS set (OCID found) but GetPerson sub-path is skipped. "
                    + "Patient created via createDigitalPharmacyConnectedStorePatientAccount in @BeforeClass.")
    void getLookupByRxV1FullSuccessSamsPharmacy() throws IOException {
        String domainId = SAMS_PHARMACY_DOMAIN;
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Write SAMS-PHARMACY OCID for dynamicPatientId → linkedCid in Account Entity.
        // dynamicRxNbr2 belongs to dynamicPatientId (indexed quickly — confirmed by P1–P26).
        // SAMS-PHARMACY is never written by enableTestAccountInQa → always a fresh 200.
        AccountEntityServiceRetrofit accountEntityRetrofitP28 = new AccountEntityServiceRetrofit();
        var ocidWriteRespP28 = accountEntityRetrofitP28.createPharmacyAccountV1(
                linkedCid,
                "SAMS-PHARMACY",
                CreatePharmacyAccountV1Request.builder()
                        .customerInfo(CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(dynamicStoreNbr)
                                .patientId(String.valueOf(dynamicPatientId))
                                .dob(dynamicDob)
                                .build())
                        .accountCreationSource("smsOtpVerification")
                        .build(),
                reqId,
                reqTrackingId);
        Assert.assertEquals(ocidWriteRespP28.code(), 200,
                "Account Entity SAMS-PHARMACY write must return HTTP 200 — got: " + ocidWriteRespP28.code());

        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr2);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // All items succeed (OCID found) → applyExecutionState returns COMPLETE → HTTP 200
        Assert.assertEquals(getLookupByRxV1Response.code(), 200, errorMessage);

        // No top-level error in response body
        Assert.assertNull(getLookupByRxV1Response.body().getError(),
                "Top-level error must be null for a full success HTTP 200 response");

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1,
                "Expected 1 item in response but got: " + responseList.size());

        LookupByRxV1Response item = responseList.get(0);
        LookupByRxCustomerInfo customerInfo = item.getCustomerInfo();

        // No per-item error — OCID was found, no error path was triggered
        Assert.assertNull(item.getError(),
                "Per-item error must be null — service Path C: all lookups succeeded (RXOR + CPR + OCID)");

        // customerAccountId = onlineAccountId from Account Entity → matches linkedCid
        Assert.assertEquals(customerInfo.getCustomerAccountId(), linkedCid,
                "customerAccountId must equal linkedCid — OCID found even for SAMS-PHARMACY");

        // firstName populated from CPR patientInfo.getFirstName()
        Assert.assertTrue(customerInfo.getFirstName() != null && !customerInfo.getFirstName().isEmpty(),
                "firstName must be non-null and non-empty — set from CPR patientInfo.getFirstName()");

        // dob populated from CPR patientInfo.getBirthDate()
        Assert.assertTrue(customerInfo.getDob() != null && !customerInfo.getDob().isEmpty(),
                "dob must be non-null and non-empty — set from CPR patientInfo.getBirthDate()");

        // emailId MUST be null for SAMS-PHARMACY — callGetPersonByCustomerAccountId guard condition:
        // Domain.WM_PHARMACY.getDomainId().equals(domainId) → false for SAMS-PHARMACY → emailId stays null.
        // NOTE: Generated LookupByRxCustomerInfo model is missing emailId (Swagger codegen ran before field was added).
        //       Extract directly from raw LinkedTreeMap to avoid compile error.
        LinkedTreeMap<String, Object> rawItem28 = (LinkedTreeMap<String, Object>) response.get(0);
        LinkedTreeMap<String, Object> rawCustomerInfo28 =
                (LinkedTreeMap<String, Object>) rawItem28.get("customerInfo");
        String emailId28 = rawCustomerInfo28 != null ? (String) rawCustomerInfo28.get("emailId") : null;

        Assert.assertNull(emailId28,
                "emailId must be null for SAMS-PHARMACY — callGetPersonByCustomerAccountId is "
                        + "skipped when domainId != WM_PHARMACY; emailId stays null in customerInfoBuilder. "
                        + "Actual value: " + emailId28);
    }

    @Test(
            priority = 29,
            description = "Lookup by rx full success — WM-PHARMACY, multi-item (2 Rx for same p200 patient, OCID pre-set). "
                    + "Service Path C for ALL items: RXOR found → CPR patientInfo non-null → "
                    + "accEnResponse.getOnlineAccountId() non-null → customerAccountId = p200Cid → "
                    + "applyExecutionState COMPLETE → HTTP 200. "
                    + "callGetPersonByCustomerAccountId is called for every item (WM-PHARMACY + ADULT) → "
                    + "emailId populated in each item. No per-item error on any item. "
                    + "Uses p200RxNbr1 + p200RxNbr2 (both belong to p200PatientId). "
                    + "AE WM-PHARMACY mapping (p200Cid → p200PatientId) written internally by "
                    + "createDigitalPharmacyConnectedStorePatientAccount in @BeforeClass — no AE write needed here.")
    void getLookupByRxV1FullSuccessWmPharmacyMultiItem() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // AE WM-PHARMACY mapping (p200Cid → p200PatientId) already written by
        // p200DpUtil.createDigitalPharmacyConnectedStorePatientAccount in @BeforeClass.
        // No explicit AE write needed here.
        // Service chain: RXOR(p200RxNbr1/2)→p200PatientId → CPR→patientInfo → AE→p200Cid → HTTP 200.
        LookupByRxV1RequestObject requestObject1 = new LookupByRxV1RequestObject();
        requestObject1.setRxNbr(p200RxNbr1);
        requestObject1.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1RequestObject requestObject2 = new LookupByRxV1RequestObject();
        requestObject2.setRxNbr(p200RxNbr2);
        requestObject2.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject1);
        request.add(requestObject2);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // All items complete → applyExecutionState returns COMPLETE → HTTP 200
        Assert.assertEquals(getLookupByRxV1Response.code(), 200, errorMessage);

        // No top-level error in response body
        Assert.assertNull(getLookupByRxV1Response.body().getError(),
                "Top-level error must be null for a multi-item full success HTTP 200 response");

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2,
                "Expected 2 items in response but got: " + responseList.size());

        // Validate each item — both belong to the same p200 patient (same OCID, same CPR record)
        for (int i = 0; i < responseList.size(); i++) {
            LookupByRxV1Response item = responseList.get(i);
            LookupByRxCustomerInfo customerInfo = item.getCustomerInfo();

            // No per-item error — OCID found for all items → no error path triggered
            Assert.assertNull(item.getError(),
                    "Per-item error must be null for item[" + i + "] — service Path C: "
                            + "all lookups succeeded (RXOR + CPR + OCID)");

            // customerAccountId = onlineAccountId from Account Entity → matches p200Cid for every item
            Assert.assertEquals(customerInfo.getCustomerAccountId(), p200Cid,
                    "customerAccountId must equal p200Cid for item[" + i + "] "
                            + "(= OCP onlineAccountId from Account Entity)");

            // firstName populated from CPR patientInfo.getFirstName() — always non-null/non-empty
            Assert.assertTrue(customerInfo.getFirstName() != null && !customerInfo.getFirstName().isEmpty(),
                    "firstName must be non-null and non-empty for item[" + i + "] "
                            + "— set from CPR patientInfo.getFirstName()");

            // dob populated from CPR patientInfo.getBirthDate() → CommonUtil.changeDateFormat(...)
            Assert.assertTrue(customerInfo.getDob() != null && !customerInfo.getDob().isEmpty(),
                    "dob must be non-null and non-empty for item[" + i + "] "
                            + "— set from CPR patientInfo.getBirthDate()");

            // emailId populated from GetPerson API — callGetPersonByCustomerAccountId is called when
            // domainId == WM_PHARMACY AND patientType == ADULT AND customerAccountId non-empty.
            // NOTE: Generated LookupByRxCustomerInfo model is missing emailId (Swagger codegen ran before field was added).
            //       Extract directly from raw LinkedTreeMap to avoid compile error.
            LinkedTreeMap<String, Object> rawItem = (LinkedTreeMap<String, Object>) response.get(i);
            LinkedTreeMap<String, Object> rawCustomerInfo =
                    (LinkedTreeMap<String, Object>) rawItem.get("customerInfo");
            String emailId = rawCustomerInfo != null ? (String) rawCustomerInfo.get("emailId") : null;

            Assert.assertTrue(emailId != null && !emailId.isEmpty(),
                    "emailId must be non-null and non-empty for item[" + i + "] — WM-PHARMACY + ADULT: "
                            + "callGetPersonByCustomerAccountId is called → GetPerson returns emailId. "
                            + "Actual value: " + emailId);
        }
    }

    @Test(
            priority = 30,
            description = "Lookup by rx full success — WM-PHARMACY, single item, MINOR patient (OCID written in setContext). "
                    + "Service Path C: RXOR found → CPR patientInfo non-null → "
                    + "accEnResponse.getOnlineAccountId() non-null → customerAccountId = p300Cid → "
                    + "applyExecutionState COMPLETE → HTTP 200. "
                    + "callGetPersonByCustomerAccountId guard: customerAccountId non-empty ✓, "
                    + "patientType non-null ✓, WM-PHARMACY ✓, "
                    + "BUT Type.ADULT.name().equalsIgnoreCase(patientType.name()) = false for MINOR "
                    + "→ GetPerson NOT called → emailId = null. "
                    + "Distinct from P28 (SAMS-PHARMACY domain guard) — tests the patientType=MINOR branch. "
                    + "AE WM-PHARMACY OCID (p300PatientId→p300Cid) written by createDigitalPharmacyConnectedStorePatientAccount in setContext.")
    void getLookupByRxV1FullSuccessWmPharmacyMinorPatient() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // AE WM-PHARMACY OCID (p300PatientId→p300Cid) was written in setContext by
        // createDigitalPharmacyConnectedStorePatientAccount → enableTestAccountInQa.
        // No manual AE write needed here — re-writing would return 409 conflict.
        // Service chain: RXOR(p300RxNbr1)→p300PatientId → CPR→patientInfo(patientType=MINOR)
        //               → AE→p300Cid → ADULT guard fails → emailId=null → HTTP 200.
        LookupByRxV1RequestObject requestObject = new LookupByRxV1RequestObject();
        requestObject.setRxNbr(p300RxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);

        LookupByRxV1Request request = new LookupByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> getLookupByRxV1Response =
                accountOrchestratorRetrofit.lookupByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, getLookupByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // OCID found → all items succeed → applyExecutionState COMPLETE → HTTP 200
        Assert.assertEquals(getLookupByRxV1Response.code(), 200, errorMessage);

        // No top-level error in response body
        Assert.assertNull(getLookupByRxV1Response.body().getError(),
                "Top-level error must be null for a full success HTTP 200 response");

        ArrayList<Object> response = (ArrayList<Object>) getLookupByRxV1Response.body().getPayload();
        List<LookupByRxV1Response> responseList = extractLookupByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1,
                "Expected 1 item in response but got: " + responseList.size());

        LookupByRxV1Response item = responseList.get(0);
        LookupByRxCustomerInfo customerInfo = item.getCustomerInfo();

        // No per-item error — OCID found, no error path triggered
        Assert.assertNull(item.getError(),
                "Per-item error must be null — OCID found for MINOR patient, no error path triggered");

        // customerAccountId = onlineAccountId from Account Entity → p300Cid
        Assert.assertEquals(customerInfo.getCustomerAccountId(), p300Cid,
                "customerAccountId must equal p300Cid — OCID found via accEnResponse.getOnlineAccountId()");

        // firstName populated from CPR patientInfo.getFirstName()
        Assert.assertTrue(customerInfo.getFirstName() != null && !customerInfo.getFirstName().isEmpty(),
                "firstName must be non-null and non-empty — set from CPR patientInfo.getFirstName()");

        // dob populated from CPR patientInfo.getBirthDate()
        Assert.assertTrue(customerInfo.getDob() != null && !customerInfo.getDob().isEmpty(),
                "dob must be non-null and non-empty — set from CPR patientInfo.getBirthDate()");

        // patientType = MINOR — CPR patientTypeCode=HUMAN + DOB=10 years ago → getPatientType → MINOR.
        // LookupByRxCustomerInfo.getPatientType() is available in the generated model.
        Assert.assertEquals(customerInfo.getPatientType(), "MINOR",
                "patientType must be MINOR — patient DOB is 10 years ago < AGE_OF_MAJORITY(18) "
                        + "→ CommonUtil.getPatientType returns Type.MINOR. "
                        + "Actual: " + customerInfo.getPatientType());

        // emailId MUST be null — callGetPersonByCustomerAccountId guard in LookupByRxService:
        //   StringUtils.isNotEmpty(customerAccountId) = true  ✓
        //   patientType != null                        = true  ✓
        //   Domain.WM_PHARMACY.getDomainId().equals()  = true  ✓
        //   Type.ADULT.name().equalsIgnoreCase(MINOR)  = false ✗  → condition short-circuits → GetPerson NOT called
        // emailId stays null in customerInfoBuilder.
        // NOTE: Generated LookupByRxCustomerInfo model is missing emailId (Swagger codegen ran before field was added).
        //       Extract directly from raw LinkedTreeMap to avoid compile error.
        LinkedTreeMap<String, Object> rawItem30 = (LinkedTreeMap<String, Object>) response.get(0);
        LinkedTreeMap<String, Object> rawCustomerInfo30 =
                (LinkedTreeMap<String, Object>) rawItem30.get("customerInfo");
        String emailId30 = rawCustomerInfo30 != null ? (String) rawCustomerInfo30.get("emailId") : null;

        Assert.assertNull(emailId30,
                "emailId must be null for MINOR patient on WM-PHARMACY — "
                        + "callGetPersonByCustomerAccountId ADULT guard fails: "
                        + "Type.ADULT.name().equalsIgnoreCase(\"MINOR\") = false → GetPerson NOT called. "
                        + "Actual value: " + emailId30);
    }

    @NotNull
    private List<LookupByRxV1Response> extractLookupByRxV1ResponsePayload(
            ArrayList<Object> payload) {
        return payload.stream()
                .map(
                        profile ->
                                ResponseUtil.parseResponse(
                                        gson,
                                        ((LinkedTreeMap<String, Object>) profile),
                                        LookupByRxV1Response.class))
                .collect(Collectors.toList());
    }


    /**
     * Creates a dynamic Rx prescription using Connexus wrapper API.
     * Steps:
     * 1. Query database for available drug by control code (with inventory > 0)
     * 2. Fetch drug details using fetchDrugInfo API
     * 3. Get full drug info from Connexus DB for newOrderToEOD
     * 4. Create Rx order via newOrderToEOD
     * 5. Parse and return rxNumber
     *
     * @param storeId Store number as integer
     * @param patientId Patient ID from Connexus
     * @param description Log description for this Rx
     * @return Generated rxNumber as String
     */
    private String createDynamicRx(int storeId, int patientId, String description) throws Exception {
        // Step 1: Query database for available drug by control code with inventory
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);

        // Query for a drug with the specified control code and available inventory (on_hand_qty > 0)
        // Note: Informix syntax uses "FIRST n" not "TOP n"
        String queryDrug = "SELECT FIRST 1 pi.ndc_nbr, pi.on_hand_qty " +
                "FROM pharmacy_offering:pharmacy_product AS pp, " +
                "     pharmacy_offering:pharmacy_item AS pi " +
                "WHERE pp.product_mds_fam_id = pi.product_mds_fam_id " +
                "  AND pp.drug_control_code = '" + CONTROL_CODE + "' " +
                "  AND pi.on_hand_qty > 0 " +
                "ORDER BY pi.ndc_nbr";

        DataTable drugTable = cnx.getDataTable(queryDrug);
        Assert.assertTrue(drugTable.getRowCount() > 0,
                "No drugs found in DB for store " + storeId + " with controlCode " + CONTROL_CODE + " and inventory > 0");

        DataRow drugRow = drugTable.getDataRows().get(0);
        String ndc = drugRow.getValue("ndc_nbr").toString().trim();
        int onHandQty = Integer.parseInt(drugRow.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", ""));

        // Step 2: Fetch drug details using Connexus wrapper API
        FetchDrug fetchDrugPayload = new FetchDrug();
        fetchDrugPayload.setSiteId(String.valueOf(storeId));
        fetchDrugPayload.setNdc(ndc);

        Drug drug = wrapperAPIManager.fetchDrugInfo(fetchDrugPayload);
        Assert.assertNotNull(drug, "fetchDrugInfo returned null for NDC: " + ndc);

        // Step 3: Get full drug info from Connexus DB for newOrderToEOD
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, ndc);
        Assert.assertNotNull(drugInfo, "Drug info not found in Connexus DB for NDC: " + ndc);

        // Step 4: Create Rx order via newOrderToEOD
        String pickupDate = wrapperUtils.getPickUpDate();
        String rxExpDate = wrapperUtils.getExpiryDate();

        // Note: Using fully qualified name to avoid conflict with Account Orchestrator's ServiceResponse
        com.walmart.hwqe.commons.apicontext.ServiceResponse newOrderResp = wrapperAPIManager.newOrderToEOD(
                REQUEST_TYPE_CODE, PRIORITY_ID, DISPENSE_TYPE,
                patientId, storeId, pickupDate, rxExpDate, NUM_REFILLS, drugInfo);

        Assert.assertEquals(newOrderResp.getStatusCode(), 201,
                "newOrderToEOD failed — status: " + newOrderResp.getStatusCode()
                        + " | response: " + newOrderResp.getDataResponse());

        // Step 5: Parse rxNumber from Success[0].rxNbr
        JsonObject responseJson = gson.fromJson(newOrderResp.getDataResponse(), JsonObject.class);
        JsonArray successArray = responseJson.getAsJsonArray("Success");
        Assert.assertNotNull(successArray, "newOrderToEOD response missing 'Success' array");
        Assert.assertFalse(successArray.size() == 0, "newOrderToEOD 'Success' array is empty");

        String rxNumber = String.valueOf(successArray.get(0).getAsJsonObject().get("rxNbr").getAsInt());

        return rxNumber;
    }

    /**
     * Builds AddPatient request for Connexus patient creation.
     * Follows the pattern used in other Connexus tests (E2EWrapper, ConnexusTestScripts).
     *
     * @param storeId Store number as integer
     * @param dobDotNet Date of birth in .NET format (/Date(epochMillis)/)
     * @return AddPatient object ready for API call
     */
    private AddPatient buildAddPatient(int storeId, String dobDotNet) {
        String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();

        AddPatient patient = new AddPatient();

        // Required fields for Connexus patient creation
        patient.setSiteID(storeId);
        patient.setCommunicationID("5555555555");
        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setMiddleName("");
        patient.setPatientName(lastName + "," + firstName);
        patient.setDob(dobDotNet);
        patient.setGender("F");
        patient.setLanguage("101");                // 101 = English
        patient.setStatus(20700);                  // Active patient status
        patient.setIsPatientMinor(false);          // Adult patient
        patient.setAddressTypeCode(3);             // Home address
        patient.setVerifyFreCode(1);               // Verified
        patient.setPatientTypeCode(10200);         // 10200 = Human, 10202 = Pet
        patient.setUserId("APITEST");              // Test user ID
        patient.setAddressLine1("123 Test St");
        patient.setAddressLine2("");
        patient.setCity("Bentonville");
        patient.setState("AR");
        patient.setZipCode("72712");
        patient.setCountry("USA");
        patient.setHomePhone("5555555555");
        patient.setCellPhone("5555555555");
        patient.setWorkPhone("");

        return patient;
    }
}

