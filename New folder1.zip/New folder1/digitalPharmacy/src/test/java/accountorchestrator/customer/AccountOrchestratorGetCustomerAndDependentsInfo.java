package accountorchestrator.customer;

import accountorchestrator.utils.AccountOrchestratorCommonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreateP13nsRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.PharmacyOnlineIdentityV1Response;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.WalmartPlusStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerAccountInfoV2Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;
import accountorchestrator.utils.CommonAccountHelper;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class AccountOrchestratorGetCustomerAndDependentsInfo {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private WCPRetroFit wcpRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String samsDomainId = "SAMS-PHARMACY";
  private String accountCreationSource = "idVerification";
  private String accountType = "INDIVIDUAL";
  private String customerType = "INDIVIDUAL";
  private String commonPhoneNo = "1234567829";
  private String commonPassword = "Test@12345";
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String caregiverCustomerEmailId = null;
  private String dependent1CustomerEmailId = null;
  private String dependent2CustomerEmailId = null;
  private String caregiverCustomerAccountId = null;
  private String dependent1CustomerAccountId = null;
  private String dependent2CustomerAccountId = null;
  private String caregiverStoreNbr = null;
  private String caregiverPatientId = null;
  private String dependent1StoreNbr = null;
  private String dependent1PatientId = null;
  private String dependent2StoreNbr = null;
  private String dependent2PatientId = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;
  private String commonDobCPRFormatForLessThan18 = null;
  private String commonDobDPFormatForLessThan18 = null;
  private String caregiverFirstName = null;
  private String caregiverLastName = null;
  private String dependent1FirstName = null;
  private String dependent1LastName = null;
  private String dependent2FirstName = null;
  private String dependent2LastName = null;
  private String caregiver7CustomerAccountId = null;
  private String caregiver7emailId = null;
  private String caregiver7StoreNbr = null;
  private String caregiver7StoreNbr2 = null;
  private String caregiver7PatientId = null;
  private String caregiver7PatientId2 = null;
  private String caregiver7FirstName = null;
  private String caregiver7LastName = null;
  private String dependent7emailId = null;
  private String dependent7CustomerAccountId = null;
  private String dependent7StoreNbr = null;
  private String dependent7PatientId = null;
  private String dependent7FirstName = null;
  private String dependent7LastName = null;
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
  // ── G10/G11 dedicated accounts: isolated caregiver with ADULT APPROVED + MINOR APPROVED ──
  private String cgG11EmailId = null;
  private String cgG11CustomerAccountId = null;
  private String cgG11StoreNbr = null;
  private String cgG11PatientId = null;
  private String cgG11FirstName = null;
  private String cgG11LastName = null;
  private String adultDepG11EmailId = null;
  private String adultDepG11CustomerAccountId = null;
  private String adultDepG11StoreNbr = null;
  private String adultDepG11PatientId = null;
  private String adultDepG11FirstName = null;
  private String adultDepG11LastName = null;
  private String minorDepEmailId = null;
  private String minorDepCustomerAccountId = null;
  private String minorDepStoreNbr = null;
  private String minorDepPatientId = null;
  private String minorDepFirstName = null;
  private String minorDepLastName = null;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetrofit = new WCPRetroFit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);

    Date dateForOlderThan18 =
            new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
            new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
    commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

    // making test accounts
    caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
    caregiverPatientId = CommonUtil.generateRandomNumber(9);
    caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiverCustomerEmailId, commonPassword, commonPhoneNo,
            caregiverFirstName, caregiverLastName, CommonUtil.randomUUID());
    createCPRAccount(
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverFirstName,
            caregiverLastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiverCustomerAccountId,
            caregiverStoreNbr,
            caregiverPatientId,
            commonDobDPFormatForOlderThan18);
    CommonAccountHelper.addWalmartPlusMembershipViaAstro(caregiverCustomerEmailId);

    dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent1CustomerEmailId);
    dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent1PatientId = CommonUtil.generateRandomNumber(9);
    dependent1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent1StoreNbr,
            dependent1PatientId,
            dependent1FirstName,
            dependent1LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent1CustomerAccountId,
            dependent1StoreNbr,
            dependent1PatientId,
            commonDobDPFormatForOlderThan18);
      wcpAddDependent(
            DependentInfo.TypeEnum.ADULT,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent1CustomerAccountId,
            caregiverCustomerAccountId);

    dependent2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent2CustomerEmailId);
    dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent2PatientId = CommonUtil.generateRandomNumber(9);
    dependent2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent2StoreNbr,
            dependent2PatientId,
            dependent2FirstName,
            dependent2LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent2CustomerAccountId,
            dependent2StoreNbr,
            dependent2PatientId,
            commonDobDPFormatForOlderThan18);
      wcpAddDependent(
            DependentInfo.TypeEnum.ADULT,
            DependentInfo.LinkageStatusEnum.ACTIVE,
            dependent2CustomerAccountId,
            caregiverCustomerAccountId);

    caregiver7emailId = CommonUtil.generateRandomEmailId(10);
    caregiver7CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver7emailId);
    caregiver7StoreNbr = "5596"; // Sams club store number
    caregiver7PatientId = CommonUtil.generateRandomNumber(9);
    caregiver7FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver7LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    caregiver7StoreNbr2 = CommonUtil.generateRandomNumber(6);
    caregiver7PatientId2 = CommonUtil.generateRandomNumber(9);

    createCPRAccount(
            caregiver7StoreNbr,
            caregiver7PatientId,
            caregiver7FirstName,
            caregiver7LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createCPRAccount(
            caregiver7StoreNbr2,
            caregiver7PatientId2,
            caregiver7FirstName,
            caregiver7LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccountForSamsDomainId(
            caregiver7CustomerAccountId,
            caregiver7StoreNbr,
            caregiver7PatientId,
            commonDobDPFormatForOlderThan18);
    createPharmacyAccount(
            caregiver7CustomerAccountId,
            caregiver7StoreNbr2,
            caregiver7PatientId2,
            commonDobDPFormatForOlderThan18);

    dependent7emailId = CommonUtil.generateRandomEmailId(10);
    dependent7CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent7emailId);
    dependent7StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent7PatientId = CommonUtil.generateRandomNumber(9);
    dependent7FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    dependent7LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent7StoreNbr,
            dependent7PatientId,
            dependent7FirstName,
            dependent7LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent7CustomerAccountId,
            dependent7StoreNbr,
            dependent7PatientId,
            commonDobDPFormatForOlderThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.ADULT,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent7CustomerAccountId,
            caregiver7CustomerAccountId);

    // ── G10/G11: isolated caregiver with ADULT APPROVED + MINOR APPROVED dependents ──────────
    cgG11EmailId = CommonUtil.generateRandomEmailId(10);
    cgG11CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(cgG11EmailId);
    cgG11StoreNbr = CommonUtil.generateRandomNumber(6);
    cgG11PatientId = CommonUtil.generateRandomNumber(9);
    cgG11FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    cgG11LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            cgG11StoreNbr, cgG11PatientId, cgG11FirstName, cgG11LastName,
            commonDobCPRFormatForOlderThan18, HUMAN);
    createPharmacyAccount(
            cgG11CustomerAccountId, cgG11StoreNbr, cgG11PatientId, commonDobDPFormatForOlderThan18);

    adultDepG11EmailId = CommonUtil.generateRandomEmailId(10);
    adultDepG11CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adultDepG11EmailId);
    adultDepG11StoreNbr = CommonUtil.generateRandomNumber(6);
    adultDepG11PatientId = CommonUtil.generateRandomNumber(9);
    adultDepG11FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adultDepG11LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            adultDepG11StoreNbr, adultDepG11PatientId, adultDepG11FirstName, adultDepG11LastName,
            commonDobCPRFormatForOlderThan18, HUMAN);
    createPharmacyAccount(
            adultDepG11CustomerAccountId, adultDepG11StoreNbr, adultDepG11PatientId, commonDobDPFormatForOlderThan18);
    wcpAddDependent(
            DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.APPROVED,
            adultDepG11CustomerAccountId, cgG11CustomerAccountId);

    minorDepEmailId = CommonUtil.generateRandomEmailId(10);
    minorDepCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(minorDepEmailId);
    minorDepStoreNbr = CommonUtil.generateRandomNumber(6);
    minorDepPatientId = CommonUtil.generateRandomNumber(9);
    minorDepFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    minorDepLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            minorDepStoreNbr, minorDepPatientId, minorDepFirstName, minorDepLastName,
            commonDobCPRFormatForLessThan18, HUMAN);
    createPharmacyAccount(
            minorDepCustomerAccountId, minorDepStoreNbr, minorDepPatientId, commonDobDPFormatForLessThan18);
    wcpAddDependent(
            DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.APPROVED,
            minorDepCustomerAccountId, cgG11CustomerAccountId);

  }

  /**
   * Clean up for all created cpr accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() throws IOException {
    cprProfilesToBeDeletedList.forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                Response<ValidationServiceResponse> response =
                        cprPatientUpdateRetrofit.validateProfile(request);
              } catch (IOException e) {
              }
            });

    pharmacyProfilesToBeDeleted.forEach(
            request -> {
              try {
                Response<ServiceResponse> getOnlineIdentityResp =
                        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                request, domainId, reqIdString, reqTrackingString);

                if (getOnlineIdentityResp.code() == 204) {
                  // If the response is 204, skip the deletion
                  return;
                }

                accountEntityServiceRetrofit.deleteAccountV1(
                        request, domainId, reqIdString, reqTrackingString);

              } catch (IOException e) {
                // Handle the IOException
              }
            });
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  private void createPharmacyAccount(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      domainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
      }
      break;
    }
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  private void createPharmacyAccountForSamsDomainId(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      samsDomainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        pharmacyProfilesToBeDeleted.add(customerAccountId);
      }
      break;
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(dob)
                            .build())
            .build();
  }

  /**
   * Create personalisations for acc-entity
   *
   * @throws IOException
   */
  private void createP13nsV1(String customerAccountId)
          throws IOException {
    CreateP13nsRequest createP13nsRequest = getCreateP13nsV1Request();
    Response<ServiceResponseHolder<Void>> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createP13nsV1(
                      customerAccountId,
                      createP13nsRequest,
                      domainId,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200 && response.body() != null)) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account personalisation failed in Account Entity. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Builds accEn Create P13ns Request
   *
   * @return
   */
  private CreateP13nsRequest getCreateP13nsV1Request() {
    List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
    p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
    p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));

    return CreateP13nsRequest.builder().p13ns(p13nList).build();
  }

  private CreateP13nsRequest.P13n buildP13ns(String entity, String type, int count) {
    return CreateP13nsRequest.P13n.builder()
            .entity(entity)
            .type(type)
            .identifiers(null)
            .build();
  }

  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  private void createCPRAccount(
          String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
          throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
      }
      break;
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * deletes cpr account by setting the PatientStatusCode as 20708
   *
   * @param storeNbr
   * @param patientId
   * @param firstName
   * @param lastName
   * @throws IOException
   */
  private void deleteCPRAccount(
          String storeNbr, String patientId, String firstName, String lastName, String dob)
          throws IOException {
    ValidationServiceRequest cprRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprRequest.setPatientId(Integer.parseInt(patientId));
    cprRequest.getPatientInfo().setBirthDate(dob);
    cprRequest.getPatientInfo().setFirstName(firstName);
    cprRequest.getPatientInfo().setLastName(lastName);
    cprRequest.getPatientInfo().setPatientStatusCode(20708);

    // This will try to delete an account in CPR 3 times if account deletion fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account deletion failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // This is needed because CPR account deletion is async, and it usually takes a couple of
    // seconds to reflect account deletion
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Call ca add dependent api
   *
   * @param type'
   * @throws IOException
   */
  private void wcpAddDependent(
          DependentInfo.TypeEnum type,
          DependentInfo.LinkageStatusEnum status,
          String dependentAccountId,
          String caregiverAccountId)
          throws Exception {

      WCPAddDependentRequest wcpAddDependentRequest = AccountOrchestratorCommonUtils.getWCPAddDependentRequest(type, status, dependentAccountId, caregiverAccountId);
      Response<WCPAddDependentResponse> response = null;

    // This will try to create a person account in CA, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = wcpRetrofit.addDependent(wcpAddDependentRequest, caregiverAccountId);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CA add dependent failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }


  @Test(
          priority = 0,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-null/false, walmartPlusStatus-true")
  public void getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoNullOrFalseWPlusTrue()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);


    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNull(response.getDependentsInfo());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE);
  }

  @Test(
          priority = 1,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-null/false, walmartPlusStatus-false")
  public void getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoNullOrFalseWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNull(response.getDependentsInfo());
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
  }

  @Test(
          priority = 2,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-null/false, walmartPlusStatus-false")
  public void getCustomerInfoV2SuccessLookUpCIDNonNullDependentsInfoNullOrFalseWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            dependent1CustomerAccountId,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    false,
                    false,
                    dependent1CustomerAccountId,
                    false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNull(response.getCustomerInfo());
    Assert.assertNull(response.getDependentsInfo().get(0).getWalmartPlusStatus());
    Assert.assertEquals(response.getDependentsInfo().get(0).getAuthStoreNbr(), dependent1StoreNbr);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getAuthPatientId(), dependent1PatientId);
    Assert.assertEquals(response.getDependentsInfo().get(0).getFirstName(), dependent1FirstName);
    Assert.assertEquals(response.getDependentsInfo().get(0).getLastName(), dependent1LastName);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getEmailId(), dependent1CustomerEmailId);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getCustomerAccountId(), dependent1CustomerAccountId);
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.ADULT);
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
  }

  @Test(
          priority = 3,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-null/false, walmartPlusStatus-true")
  public void getCustomerInfoV2SuccessLookUpCIDNonNullDependentsInfoNullOrFalseWPlusTrue()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            dependent1CustomerAccountId,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    false,
                    true,
                    dependent1CustomerAccountId,
                    false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNull(response.getCustomerInfo());
    Assert.assertEquals(response.getDependentsInfo().get(0).getAuthStoreNbr(), dependent1StoreNbr);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getAuthPatientId(), dependent1PatientId);
    Assert.assertEquals(response.getDependentsInfo().get(0).getFirstName(), dependent1FirstName);
    Assert.assertEquals(response.getDependentsInfo().get(0).getLastName(), dependent1LastName);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getEmailId(), dependent1CustomerEmailId);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getCustomerAccountId(), dependent1CustomerAccountId);
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.ADULT);
    Assert.assertEquals(
            response.getDependentsInfo().get(0).getWalmartPlusStatus(), WalmartPlusStatus.INACTIVE);
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
  }

  @Test(
          priority = 4,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true")
  public void getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoTrueWPlusTrue()
          throws Exception {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 6: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE);
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertNotNull(response.getCustomerInfo().getOnlineCustId());
    Assert.assertNotNull(response.getCustomerInfo().getOnlineStoreNbr());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertNotNull(response.getCustomerInfo().getRaceTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getEthnicityTypeCode());

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 5,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-false")
  public void getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoTrueWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 6,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-true, walmartPlusStatus-true")
  public void getCustomerInfoV2SuccessLookUpCIDNonNullDependentsInfoTrueWPlusTrue()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            dependent1CustomerEmailId,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    true,
                    true,
                    dependent1CustomerEmailId,
                    false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE);

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 7,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-true, walmartPlusStatus-false")
  public void getCustomerInfoV2SuccessLookUpCIDNonNullDependentsInfoTrueWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            dependent1CustomerEmailId,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    true,
                    false,
                    dependent1CustomerEmailId,
                    false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 8,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for invalid domainId")
  public void getCustomerInfoV2InvalidDomainIdForLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    logAccountDetails(
            invalidDomainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, invalidDomainId, false, false, null, false,false, false, false, false);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");
  }

  @Test(
          priority = 9,
          description =
                  "Get customer info v2 204 from Account Entity for loggedIn user with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for valid domainId")
  public void
  getCustomerInfoV204FromAccEnForLoggedInUserHavingLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            customerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 204, errorMessage);
  }

  @Test(
          priority = 10,
          description =
                  "Get customer info v2 204 from CPR for loggedIn user with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for valid domainId")
  public void
  getCustomerInfoV204FromCPRForLoggedInUserForLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data
    String caregiver1emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver1StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver1PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(caregiver1emailId,commonPassword,commonPhoneNo,caregiver1FirstName,caregiver1LastName,trackID);
    createCPRAccount(
            caregiver1StoreNbr,
            caregiver1PatientId,
            caregiver1FirstName,
            caregiver1LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver1CustomerAccountId,
            caregiver1StoreNbr,
            caregiver1PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: delete the caregiver account from cpr
    deleteCPRAccount(
            caregiver1StoreNbr,
            caregiver1PatientId,
            caregiver1FirstName,
            caregiver1LastName,
            commonDobCPRFormatForOlderThan18);

    logAccountDetails(
            domainId,
            caregiver1StoreNbr,
            caregiver1PatientId,
            caregiver1CustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver1CustomerAccountId, domainId, false, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 404, errorMessage);
  }

  @Test(
          priority = 11,
          description =
                  "Get customer info v2 204 from CPR with lookUpCID-non-null, dependentsInfo-false, walmartPlusStatus-false for valid domainId")
  public void getCustomerInfoV204FromCPRForLookUpNonNullDependentsInfoFalseAndWPlusFalse()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver2emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver2StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver2PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(caregiver2emailId,commonPassword,commonPhoneNo,caregiver2FirstName,caregiver2LastName,trackID);
    createCPRAccount(
            caregiver2StoreNbr,
            caregiver2PatientId,
            caregiver2FirstName,
            caregiver2LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver2CustomerAccountId,
            caregiver2StoreNbr,
            caregiver2PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for dependent
    String dependent3emailId = CommonUtil.generateRandomEmailId(10);
    String dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent3PatientId = CommonUtil.generateRandomNumber(9);
    String dependent3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(dependent3emailId,commonPassword,commonPhoneNo,dependent3FirstName,dependent3LastName,trackID);
    createCPRAccount(
            dependent3StoreNbr,
            dependent3PatientId,
            dependent3FirstName,
            dependent3LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent3CustomerAccountId,
            dependent3StoreNbr,
            dependent3PatientId,
            commonDobDPFormatForOlderThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.ADULT,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent3CustomerAccountId,
            caregiver2CustomerAccountId);

    // Step - 1d: delete the lookUp cid account from cpr
    deleteCPRAccount(
            dependent3StoreNbr,
            dependent3PatientId,
            dependent3FirstName,
            dependent3LastName,
            commonDobCPRFormatForOlderThan18);

    logAccountDetails(
            domainId,
            caregiver2StoreNbr,
            caregiver2PatientId,
            caregiver2CustomerAccountId,
            null,
            dependent3CustomerAccountId,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver2CustomerAccountId,
                    domainId,
                    false,
                    false,
                    dependent3CustomerAccountId,
                    false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response (cpr 204 is mapped to application 404)
    Assert.assertEquals(getCustomerInfoV2Response.code(), 404, errorMessage);
  }

  @Test(
          priority = 12,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true for a PET dependent")
  public void getCustomerInfoV2ForLookUpNullDependentsInfoTrueAndWPlusTrueForPETDependent()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver3emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver3emailId);
    String caregiver3StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver3PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3FirstName,
            caregiver3LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver3CustomerAccountId,
            caregiver3StoreNbr,
            caregiver3PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for PET dependent
    String dependent4CustomerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent4PatientId = CommonUtil.generateRandomNumber(9);
    String dependent4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent4StoreNbr,
            dependent4PatientId,
            dependent4FirstName,
            dependent4LastName,
            commonDobCPRFormatForLessThan18,
            PET);
    createPharmacyAccount(
            dependent4CustomerAccountId,
            dependent4StoreNbr,
            dependent4PatientId,
            commonDobDPFormatForLessThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.PET,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent4CustomerAccountId,
            caregiver3CustomerAccountId);

    logAccountDetails(
            domainId,
            caregiver3StoreNbr,
            caregiver3PatientId,
            caregiver3CustomerAccountId,
            dependent4CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver3CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiver3StoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiver3PatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver3FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver3LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver3emailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.INACTIVE);

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
    Assert.assertNull(response.getDependentsInfo().get(0).getWalmartPlusStatus());
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.PET);
  }

  @Test(
          priority = 13,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true for a MINOR dependent")
  public void getCustomerInfoV2ForLookUpNonNullDependentsInfoTrueAndWPlusTrueForMINORDependent()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver4emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver4StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver4PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver4CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(caregiver4emailId,commonPassword,commonPhoneNo,caregiver4FirstName,caregiver4LastName,trackID);
    createCPRAccount(
            caregiver4StoreNbr,
            caregiver4PatientId,
            caregiver4FirstName,
            caregiver4LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver4CustomerAccountId,
            caregiver4StoreNbr,
            caregiver4PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for MINOR dependent
    String dependent4CustomerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent4PatientId = CommonUtil.generateRandomNumber(9);
    String dependent4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent4StoreNbr,
            dependent4PatientId,
            dependent4FirstName,
            dependent4LastName,
            commonDobCPRFormatForLessThan18,
            HUMAN);
    createPharmacyAccount(
            dependent4CustomerAccountId,
            dependent4StoreNbr,
            dependent4PatientId,
            commonDobDPFormatForLessThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.MINOR,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent4CustomerAccountId,
            caregiver4CustomerAccountId);

    logAccountDetails(
            domainId,
            caregiver4StoreNbr,
            caregiver4PatientId,
            caregiver4CustomerAccountId,
            dependent4CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver4CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiver4StoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiver4PatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver4FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver4LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver4emailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.INACTIVE);

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
    Assert.assertNull(response.getDependentsInfo().get(0).getEmailId());
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.INACTIVE);
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.MINOR);
  }

  @Test(
          priority = 14,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true for a MINOR dependent greater than 18")
  public void
  getCustomerInfoV2ForLookUpNonNullDependentsInfoTrueAndWPlusTrueForMINORDependentGreaterThan18()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver4emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver4CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver4emailId);
    String caregiver4StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver4PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver4StoreNbr,
            caregiver4PatientId,
            caregiver4FirstName,
            caregiver4LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver4CustomerAccountId,
            caregiver4StoreNbr,
            caregiver4PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for MINOR dependent
    String dependent4CustomerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent4PatientId = CommonUtil.generateRandomNumber(9);
    String dependent4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent4StoreNbr,
            dependent4PatientId,
            dependent4FirstName,
            dependent4LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent4CustomerAccountId,
            dependent4StoreNbr,
            dependent4PatientId,
            commonDobDPFormatForOlderThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.MINOR,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent4CustomerAccountId,
            caregiver4CustomerAccountId);

    logAccountDetails(
            domainId,
            caregiver4StoreNbr,
            caregiver4PatientId,
            caregiver4CustomerAccountId,
            dependent4CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver4CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiver4StoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiver4PatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver4FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver4LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver4emailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.INACTIVE);

    // dependent
    // if a dependent is minor and greater than 18 it won't show in the final list
    Assert.assertEquals(response.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 15,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true, verifies onlineCustId, onlineStoreNbr and cprDigitalProfileSync")
  public void
  getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoTrueWPlusTrueVerifiesOnlineProfileData()
          throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Calling getOnline Identity and getCprPatientInfo for response assertion

    Response<ServiceResponse> getPharmacyOnlineIdentityV1Response =
            accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                    caregiverCustomerAccountId, domainId, reqId, reqTrackingId);

    PharmacyOnlineIdentityV1Response pharmacyOnlineIdentityV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getPharmacyOnlineIdentityV1Response.body().getPayload()),
                    PharmacyOnlineIdentityV1Response.class);

    // Step - 6: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(
            response.getCustomerInfo().getAccountCreationSource(), accountCreationSource);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(), WalmartPlusStatus.ACTIVE);
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(
            response.getCustomerInfo().getCustomerAccountId(), caregiverCustomerAccountId);
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertEquals(
            response.getCustomerInfo().getAccountCreationSource(), accountCreationSource);
    Assert.assertEquals(
            response.getCustomerInfo().getOnlineCustId(),
            pharmacyOnlineIdentityV1Response.getOnlineCustId());
    Assert.assertEquals(
            response.getCustomerInfo().getOnlineStoreNbr(),
            pharmacyOnlineIdentityV1Response.getOnlineStoreNbr());
    Assert.assertEquals(
            response.getCustomerInfo().getCprDigitalProfileSync(),
            pharmacyOnlineIdentityV1Response.isCprDigitalProfileSync());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertNotNull(response.getCustomerInfo().getRaceTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getEthnicityTypeCode());

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 16,
          description =
                  "Get customer info v2 204 from Account Entity for dependent with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for valid domainId")
  public void
  getCustomerInfoV204FromAccEnForDependentForLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws Exception {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver5emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver5CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver5emailId);
    String caregiver5StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver5PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver5FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver5LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver5StoreNbr,
            caregiver5PatientId,
            caregiver5FirstName,
            caregiver5LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver5CustomerAccountId,
            caregiver5StoreNbr,
            caregiver5PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for MINOR dependent
    String dependent5CustomerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
      wcpAddDependent(
            DependentInfo.TypeEnum.MINOR,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent5CustomerAccountId,
            caregiver5CustomerAccountId);

    logAccountDetails(
            domainId,
            caregiver5StoreNbr,
            caregiver5PatientId,
            caregiver5CustomerAccountId,
            dependent5CustomerAccountId,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver5CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiver5StoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiver5PatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver5FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver5LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver5emailId);

    // dependent
    Assert.assertEquals(response.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 17,
          description =
                  "Get customer info v2 204 from CPR for dependent with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for valid domainId")
  public void getCustomerInfoV204FromCPRForDependentForLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for caregiver
    String caregiver6emailId = CommonUtil.generateRandomEmailId(10);
    String caregiver6CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiver6emailId);
    String caregiver6StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver6PatientId = CommonUtil.generateRandomNumber(9);
    String caregiver6FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String caregiver6LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            caregiver6StoreNbr,
            caregiver6PatientId,
            caregiver6FirstName,
            caregiver6LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            caregiver6CustomerAccountId,
            caregiver6StoreNbr,
            caregiver6PatientId,
            commonDobDPFormatForOlderThan18);

    // Step - 1c: creating test data for MINOR dependent
    String dependent6CustomerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String dependent6StoreNbr = CommonUtil.generateRandomNumber(6);
    String dependent6PatientId = CommonUtil.generateRandomNumber(9);
    String dependent6FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String dependent6LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            dependent6StoreNbr,
            dependent6PatientId,
            dependent6FirstName,
            dependent6LastName,
            commonDobCPRFormatForOlderThan18,
            HUMAN);
    createPharmacyAccount(
            dependent6CustomerAccountId,
            dependent6StoreNbr,
            dependent6PatientId,
            commonDobDPFormatForOlderThan18);

      wcpAddDependent(
            DependentInfo.TypeEnum.MINOR,
            DependentInfo.LinkageStatusEnum.APPROVED,
            dependent6CustomerAccountId,
            caregiver6CustomerAccountId);

    logAccountDetails(
            domainId,
            caregiver6StoreNbr,
            caregiver6PatientId,
            caregiver6CustomerAccountId,
            dependent6CustomerAccountId,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 1d: delete the dependent account from cpr
    deleteCPRAccount(
            dependent6StoreNbr,
            dependent6PatientId,
            dependent6FirstName,
            dependent6LastName,
            commonDobCPRFormatForOlderThan18);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver6CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiver6StoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiver6PatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver6FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver6LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver6emailId);

    // dependent
    Assert.assertEquals(response.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 18,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for a PET loggedInUser")
  public void getCustomerInfoV2ForLookUpNullDependentsInfoFalseAndWPlusFalseForPETLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for pet account
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, PET);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId, storeNbr, patientId, customerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid pet customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertNotNull(response.getCustomerInfo().getType());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), storeNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), patientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), firstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), lastName);
    Assert.assertNull(response.getCustomerInfo().getEmailId());
    Assert.assertEquals(response.getCustomerInfo().getCustomerAccountId(), customerAccountId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.PET);
    Assert.assertNull(response.getDependentsInfo());
  }

  @Test(
          priority = 19,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true, includeP13n-true, for a PET loggedInUser")
  public void
  getCustomerInfoV2ForLookUpNullDependentsInfoTrueAndWPlusTrueForPETLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for pet account
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, PET);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId, storeNbr, patientId, customerAccountId, null, null, true, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid pet customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, true, true, null, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertNotNull(response.getCustomerInfo().getType());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), storeNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), patientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), firstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), lastName);
    Assert.assertNull(response.getCustomerInfo().getEmailId());
    Assert.assertEquals(response.getCustomerInfo().getCustomerAccountId(), customerAccountId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.PET);
    Assert.assertEquals(0, response.getDependentsInfo().size());
  }

  @Test(
          priority = 20,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-null, walmartPlusStatus-true, includeP13n-true, for a PET loggedInUser")
  public void
  getCustomerInfoV2ForLookUpNonNullDependentsInfoNullAndWPlusFalseForPETLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for pet account
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String lookUpCid = CommonUtil.randomUUID();
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, PET);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId,
            storeNbr,
            patientId,
            customerAccountId,
            null,
            lookUpCid,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid pet customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, true, lookUpCid, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response (Since lookUpCID is not present in dependent list for guest
    // account, it will throw 500)
    Assert.assertEquals(getCustomerInfoV2Response.code(), 400, errorMessage);
  }

  @Test(
          priority = 21,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for a MINOR loggedInUser")
  public void getCustomerInfoV2ForLookUpNullDependentsInfoFalseAndWPlusFalseForMINORLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for minor account
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, HUMAN);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId, storeNbr, patientId, customerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid minor customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, false, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertNotNull(response.getCustomerInfo().getType());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), storeNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), patientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), firstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), lastName);
    Assert.assertNull(response.getCustomerInfo().getEmailId());
    Assert.assertEquals(response.getCustomerInfo().getCustomerAccountId(), customerAccountId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.MINOR);
    Assert.assertNull(response.getDependentsInfo());
  }

  @Test(
          priority = 22,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true, includeP13n-true, for a MINOR loggedInUser")
  public void
  getCustomerInfoV2ForLookUpNullDependentsInfoTrueAndWPlusTrueForMINORLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for minor account
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, HUMAN);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId, storeNbr, patientId, customerAccountId, null, null, true, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid minor customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, true, true, null, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertNull(response.getCustomerInfo().getWalmartPlusStatus());
    Assert.assertNotNull(response.getCustomerInfo().getGender());
    Assert.assertNotNull(response.getCustomerInfo().getDob());
    Assert.assertNotNull(response.getCustomerInfo().getLanguage());
    Assert.assertNotNull(response.getCustomerInfo().getType());
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks());
    Assert.assertNotNull(response.getCustomerInfo().getAddressInfo());
    Assert.assertNotNull(response.getCustomerInfo().getCommunicationInfo());
    Assert.assertNotNull(response.getCustomerInfo().getPatientTypeCode());
    Assert.assertNotNull(response.getCustomerInfo().getPatientStatusCode());
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), storeNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), patientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), firstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), lastName);
    Assert.assertNull(response.getCustomerInfo().getEmailId());
    Assert.assertEquals(response.getCustomerInfo().getCustomerAccountId(), customerAccountId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.MINOR);
    Assert.assertEquals(0, response.getDependentsInfo().size());
  }

  @Test(
          priority = 23,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-null, walmartPlusStatus-true, includeP13n-true, for a MINOR loggedInUser")
  public void
  getCustomerInfoV2ForLookUpNonNullDependentsInfoNullAndWPlusFalseForMINORLoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for minor account
    String customerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String lookUpCid = CommonUtil.randomUUID();
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForLessThan18, HUMAN);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForLessThan18);

    logAccountDetails(
            domainId,
            storeNbr,
            patientId,
            customerAccountId,
            null,
            lookUpCid,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid minor customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, true, lookUpCid, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response (Since lookUpCID is not present in dependent list for guest
    // account, it will throw 500)
    Assert.assertEquals(getCustomerInfoV2Response.code(), 400, errorMessage);
  }

  @Test(
          priority = 24,
          description =
                  "Get customer info v2 with lookUpCID-non-null, dependentsInfo-null, walmartPlusStatus-true, includeP13n-true, for a MINOR>18 loggedInUser")
  public void
  getCustomerInfoV2ForLookUpNonNullDependentsInfoNullAndWPlusFalseForMINORGreaterThan18LoggedInUser()
          throws Exception {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: creating test data for minor greater than 18 yrs
    String customerAccountId =  CommonAccountHelper.createGuestAccountWithWCPWithRandomName(commonDobCPRFormatForLessThan18);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    createCPRAccount(
            storeNbr, patientId, firstName, lastName, commonDobCPRFormatForOlderThan18, HUMAN);
    createPharmacyAccount(customerAccountId, storeNbr, patientId, commonDobDPFormatForOlderThan18);

    logAccountDetails(
            domainId, storeNbr, patientId, customerAccountId, null, null, true, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid minor customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    customerAccountId, domainId, false, true, null, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Asserting response (Since MINOR is a loggedInUser it will throw 204)
    Assert.assertEquals(getCustomerInfoV2Response.code(), 204, errorMessage);
  }

  @Test(
          priority = 25,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true, includeP13n=false")
  public void
  getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoTrueWPlusTrueIncludeP13NFalse()
          throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId includeP13n=false
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertNull(response.getCustomerInfo().getP13ns());

    // dependent
    Assert.assertNull(response.getDependentsInfo().get(0).getP13ns());
  }

  @Test(
          priority = 26,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true, includeP13n=true")
  public void
  getCustomerInfoV2SuccessLookUpCIDNullDependentsInfoTrueWPlusTrueIncludeP13NTrue()
          throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            true,
            reqId,
            reqTrackingId);

    createP13nsV1(caregiverCustomerAccountId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId and includeP13n=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, true, null, true,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    List<String> typeList = new ArrayList<>();
    List<String> entityList = new ArrayList<>();

    response.getCustomerInfo().getP13ns()
            .forEach(d -> {
              if (d.getType() != null && d.getType().getValue() != null) {
                typeList.add(d.getType().getValue());
              }
            });

    response.getCustomerInfo().getP13ns()
            .forEach(d -> {
              if (d.getEntity() != null && d.getEntity().getValue() != null) {
                entityList.add(d.getEntity().getValue());
              }
            });

    // customer
    Assert.assertNotNull(response.getCustomerInfo().getP13ns());
    Assert.assertEquals(entityList.size(),3);
    Assert.assertEquals(typeList.size(),3);

    // dependent
    Assert.assertNull(response.getDependentsInfo().get(0).getP13ns());
  }

  @Test(
          priority = 27,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true storeFilter=true")
  public void getCustomerInfoV2ForLookUpNullDependentsInfoTrueWPlusTrueAndStoreFilterTrue()
          throws IOException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;


    logAccountDetails(
            domainId,
            caregiver7StoreNbr,
            caregiver7PatientId,
            caregiver7CustomerAccountId,
            dependent7CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver7CustomerAccountId, domainId, true, true, null, false,true, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    List<GetCustomerAccountInfoV2Response.CustomerInfo.PatientLink> customerPatientLinks = response.getCustomerInfo().getPatientLinks();
    boolean hasSamsStore = customerPatientLinks.stream()
            .anyMatch(link -> "5596".equals(link.getStoreNbr()) || "7108".equals(link.getStoreNbr()));



    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertNotNull(response.getCustomerInfo().getAuthStoreNbr());
    Assert.assertNotNull(response.getCustomerInfo().getAuthPatientId());
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver7FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver7LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver7emailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(response.getCustomerInfo().getPatientLinks().size(),2);
    Assert.assertFalse(hasSamsStore, "PatientLinks should not contain Sams storeNbr");

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.ADULT);
  }

  @Test(
          priority = 28,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true storeFilter=true for domainId='SAMS-PHARMACY'")
  public void getCustomerInfoV2ForSamsDomainLookUpNullDependentsInfoTrueWPlusTrueAndStoreFilterTrue()
          throws IOException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;


    logAccountDetails(
            domainId,
            caregiver7StoreNbr,
            caregiver7PatientId,
            caregiver7CustomerAccountId,
            dependent7CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver7CustomerAccountId, samsDomainId, true, true, null, false,true, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    List<GetCustomerAccountInfoV2Response.CustomerInfo.PatientLink> customerPatientLinks = response.getCustomerInfo().getPatientLinks();
    boolean hasSamsStore = customerPatientLinks.stream()
            .anyMatch(link -> "5596".equals(link.getStoreNbr()) || "7108".equals(link.getStoreNbr()));

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertNotNull(response.getCustomerInfo().getAuthStoreNbr());
    Assert.assertNotNull(response.getCustomerInfo().getAuthPatientId());
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver7FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver7LastName);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertEquals(response.getCustomerInfo().getPatientLinks().size(),2);
    Assert.assertTrue(hasSamsStore, "PatientLinks should contain Sams storeNbr");

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 0);

  }
  @Test(
          priority = 29,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true storeFilter=false")
  public void getCustomerInfoV2ForLookUpNullDependentsInfoTrueWPlusTrueAndStoreFilterFalse()
          throws IOException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    logAccountDetails(
            domainId,
            caregiver7StoreNbr,
            caregiver7PatientId,
            caregiver7CustomerAccountId,
            dependent7CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver7CustomerAccountId, domainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    List<GetCustomerAccountInfoV2Response.CustomerInfo.PatientLink> customerPatientLinks = response.getCustomerInfo().getPatientLinks();
    boolean hasSamsStore = customerPatientLinks.stream()
            .anyMatch(link -> "5596".equals(link.getStoreNbr()) || "7108".equals(link.getStoreNbr()));

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertNotNull(response.getCustomerInfo().getAuthStoreNbr());
    Assert.assertNotNull(response.getCustomerInfo().getAuthPatientId());
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver7FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver7LastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiver7emailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertTrue(hasSamsStore, "PatientLinks should contain Sams storeNbr");
    Assert.assertEquals(response.getCustomerInfo().getPatientLinks().size(),4);

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 1);
    Assert.assertEquals(response.getDependentsInfo().get(0).getType(), Type.ADULT);
  }

  @Test(
          priority = 30,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-true, walmartPlusStatus-true storeFilter=false")
  public void getCustomerInfoV2ForSamsDomainLookUpNullDependentsInfoTrueWPlusTrueAndStoreFilterFalse()
          throws IOException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    logAccountDetails(
            domainId,
            caregiver7StoreNbr,
            caregiver7PatientId,
            caregiver7CustomerAccountId,
            dependent7CustomerAccountId,
            null,
            true,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiver7CustomerAccountId, samsDomainId, true, true, null, false,false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class so that we can
    // assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    List<GetCustomerAccountInfoV2Response.CustomerInfo.PatientLink> customerPatientLinks = response.getCustomerInfo().getPatientLinks();
    boolean hasSamsStore = customerPatientLinks.stream()
            .anyMatch(link -> "5596".equals(link.getStoreNbr()) || "7108".equals(link.getStoreNbr()));

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");

    // customer
    Assert.assertNotNull(response.getCustomerInfo().getAuthStoreNbr());
    Assert.assertNotNull(response.getCustomerInfo().getAuthPatientId());
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiver7FirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiver7LastName);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertTrue(hasSamsStore, "PatientLinks should contain Sams storeNbr");
    Assert.assertEquals(response.getCustomerInfo().getPatientLinks().size(),4);

    // dependent
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 31,
          description =
                  "Get customer info v2 with lookUpCID-null, dependentsInfo-false, walmartPlusStatus-false for invalid domainId")
  public void getCustomerInfoV2InvalidSamsDomainIdForLookUpNullDependentsInfoFalseAndWPlusFalse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "SAMS-PHARMAC";
    logAccountDetails(
            invalidDomainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, invalidDomainId, false, false, null, false,false, false, false, false);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV2Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");
  }

  @Test(
          priority = 32,
          description =
                  "Get customer info v2 with includeEC=true - should return emergency contact info")
  public void getCustomerInfoV2SuccessWithEmergencyContactInfoIncluded()
          throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, false, null, false, true, true, false, false);
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName);
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName);
    Assert.assertEquals(response.getCustomerInfo().getEmailId(), caregiverCustomerEmailId);
    Assert.assertEquals(response.getCustomerInfo().getType(), Type.ADULT);
    Assert.assertNotNull(response.getCustomerInfo().getEmergencyContactInfo(), "Emergency contact info should be included");
  }

  @Test(
          priority = 33,
          description =
                  "Get customer info v2 with includeEC=false - should not return emergency contact info")
  public void getCustomerInfoV2SuccessWithEmergencyContactInfoExcluded()
          throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, false, null, false, false, false, false, false);
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr);
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId);
    Assert.assertNull(response.getCustomerInfo().getEmergencyContactInfo(), "Emergency contact info should not be included when includeEC=false");
  }

  @Test(
          priority = 34,
          description =
                  "Get customer info v2 with includeEC=true and dependentsInfo=true - emergency contact only for customer, not dependents")
  public void getCustomerInfoV2SuccessWithEmergencyContactInfoAndDependentsIncluded()
          throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, true, false, null, false, true, true, false, false);
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo().getEmergencyContactInfo(), "Customer emergency contact info should be included");
    Assert.assertNotNull(response.getDependentsInfo());
    Assert.assertEquals(response.getDependentsInfo().size(), 2);
  }

  @Test(
          priority = 35,
          description =
                  "Get customer info v2 with caregiversInfo-true")
  public void getCustomerInfoV2SuccessWithCaregiversInfoAsTrue()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            dependent1StoreNbr,
            dependent1PatientId,
            dependent1CustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    dependent1CustomerAccountId,
                    domainId,
                    false,
                    true,
                    null,
                    false,true, false, true, true);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCaregiversInfo());
    Assert.assertEquals(response.getCaregiversInfo().size(), 1);
    Assert.assertEquals(response.getCaregiversInfo().get(0).getCustomerAccountId(), caregiverCustomerAccountId);
  }

  @Test(
          priority = 36,
          description =
                  "Get customer info v2 with caregiversInfo-null")
  public void getCustomerInfoV2SuccessCustomerAccountIdWithCaregiversInfoAsNull()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            caregiverStoreNbr,
            caregiverPatientId,
            caregiverCustomerAccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with a valid caregiverCustomerAccountId ,valid domainId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId,
                    domainId,
                    false,
                    true,
                    null,
                    false,true, false, true, null);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerInfoV2Response class so that we can assert
    // GetCustomerInfoV2
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo());
    Assert.assertTrue(
            response.getCaregiversInfo() == null || response.getCaregiversInfo().isEmpty(),
            "caregiversInfo should be null or empty when caregiversInfo flag is null");
  }

  @Test(
          priority = 37,
          description =
                  "Get customer info v2 with a random UUID that has no AES pharmacy account - must return 204 (no content)")
  public void getCustomerInfoV2NonExistentAccountReturns204()
          throws IOException {
    // Step - 1: Log the non-existent account id
    String nonExistentAccountId = CommonUtil.randomUUID();
    Reporter.logJSON("customerAccountId", nonExistentAccountId);
    Reporter.logJSON("note", "No AES pharmacy account for this UUID - expect 204");

    // Step - 2: Calling getCustomerInfoV2 with a non-existent customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    nonExistentAccountId, domainId, false, false, null, false, false, false, false, false);

    // Step - 3: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 204,
            "getCustomerInfoV2 with a non-existent customerAccountId must return 204 (no content)");
  }

  @Test(
          priority = 38,
          description =
                  "Get customer info v2 with all flags false - core customerInfo identity fields"
                          + " (authPatientId, authStoreNbr, firstName, lastName, patientLinks)"
                          + " validated on V2 response model")
  public void getCustomerInfoV2CoreCustomerInfoFieldValidation()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with all flags false
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, false, null, false, false, false, false, false);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response to the GetCustomerAccountInfoV2Response class
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo(), "customerInfo must not be null");
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId,
            "customerInfo.authPatientId must match the CPR-assigned patientId");
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr,
            "customerInfo.authStoreNbr must match the registered store number");
    Assert.assertEquals(response.getCustomerInfo().getFirstName(), caregiverFirstName,
            "customerInfo.firstName must match the CPR-registered first name");
    Assert.assertEquals(response.getCustomerInfo().getLastName(), caregiverLastName,
            "customerInfo.lastName must match the CPR-registered last name");
    Assert.assertNotNull(response.getCustomerInfo().getPatientLinks(),
            "customerInfo.patientLinks must not be null");
    Assert.assertFalse(response.getCustomerInfo().getPatientLinks().isEmpty(),
            "customerInfo.patientLinks must contain at least one entry");
  }

  @Test(
          priority = 39,
          description =
                  "Get customer info v2 with dependentsInfo=true for a customer who has no linked"
                          + " dependents - must return null or empty dependentsInfo list")
  public void getCustomerInfoV2DependentsInfoTrueWithNoDependentsReturnsNullOrEmpty()
          throws IOException {
    // dependent1CustomerAccountId is an ADULT dependent of caregiverCustomerAccountId
    // with no dependents of its own - dependentsInfo must be null or empty
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, dependent1StoreNbr, dependent1PatientId,
            dependent1CustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with dependentsInfo=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    dependent1CustomerAccountId, domainId, true, false, null, false, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertTrue(
            response.getDependentsInfo() == null || response.getDependentsInfo().isEmpty(),
            "dependentsInfo must be null or empty when the customer has no linked dependents");
  }

  @Test(
          priority = 40,
          description =
                  "Get customer info v2 with both dependentsInfo=true and caregiversInfo=true in a single"
                          + " call - dependentsInfo and caregiversInfo lists must be correctly isolated")
  public void getCustomerInfoV2DependentsAndCaregiversBothTrue()
          throws IOException {
    // dependent1CustomerAccountId: ADULT dependent of caregiverCustomerAccountId, no dependents below
    // dependentsInfo must be null/empty; caregiversInfo must contain caregiverCustomerAccountId
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, dependent1StoreNbr, dependent1PatientId,
            dependent1CustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with dependentsInfo=true and caregiversInfo=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    dependent1CustomerAccountId, domainId, true, false, null, false, false, false, false, true);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertTrue(
            response.getDependentsInfo() == null || response.getDependentsInfo().isEmpty(),
            "dependentsInfo must be null/empty: dependent1 has no linked dependents of its own");
    Assert.assertNotNull(response.getCaregiversInfo(),
            "caregiversInfo must not be null: dependent1 has caregiverCustomerAccountId as caregiver");
    Assert.assertFalse(response.getCaregiversInfo().isEmpty(),
            "caregiversInfo must contain at least one entry");
    Assert.assertEquals(response.getCaregiversInfo().get(0).getCustomerAccountId(),
            caregiverCustomerAccountId,
            "caregiversInfo[0].customerAccountId must be caregiverCustomerAccountId");
  }

  @Test(
          priority = 41,
          description =
                  "Get customer info v2 with includeP13n=true - response must be valid 200 with core"
                          + " identity fields correctly populated")
  public void getCustomerInfoV2IncludeP13nTrueDoesNotBreakResponse()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with includeP13n=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId, false, false, null, true, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCustomerInfo(),
            "customerInfo must not be null when includeP13n=true");
    Assert.assertEquals(response.getCustomerInfo().getAuthPatientId(), caregiverPatientId,
            "authPatientId must remain correct when includeP13n=true");
    Assert.assertEquals(response.getCustomerInfo().getAuthStoreNbr(), caregiverStoreNbr,
            "authStoreNbr must remain correct when includeP13n=true");
  }

  @Test(
          priority = 42,
          description =
                  "Get customer info v2 with caregiversInfo=true and walmartPlusStatus=false -"
                          + " caregiversInfo[0].walmartPlusStatus must be null even if caregiver has active W+ membership")
  public void getCustomerInfoV2CaregiversInfoEntryWalmartPlusStatusNullWhenWalmartPlusStatusFalse()
          throws IOException {
    // dependent1CustomerAccountId has caregiverCustomerAccountId (W+ ACTIVE) as caregiver.
    // With walmartPlusStatus=false the W+ field on the caregiver entry must not be populated.
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, dependent1StoreNbr, dependent1PatientId,
            dependent1CustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with caregiversInfo=true and walmartPlusStatus=false
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    dependent1CustomerAccountId, domainId, false, false, null, false, false, false, false, true);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(response.getCaregiversInfo(), "caregiversInfo must be present");
    Assert.assertFalse(response.getCaregiversInfo().isEmpty(),
            "caregiversInfo must have at least one entry");
    Assert.assertNull(response.getCaregiversInfo().get(0).getWalmartPlusStatus(),
            "caregiversInfo[0].walmartPlusStatus must be null when walmartPlusStatus flag=false");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G1 – paymentMethods=true → paymentMethods field is non-null in response
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 43,
          description =
                  "G1: getCustomerInfoV2 with paymentMethods=true returns 200 with valid customerInfo."
                          + " paymentMethods field presence depends on whether the account has pharmacy payment"
                          + " methods registered; test validates the flag is accepted and customerInfo is returned.")
  public void getCustomerInfoV2PaymentMethodsTrueReturnsNonNullField() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with paymentMethods=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId,
                    false, false, null, false, false, false, true, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(
            response.getCustomerInfo(),
            "customerInfo should be present when paymentMethods=true");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G2 – paymentMethods=false → 200 + customerInfo present
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 44,
          description =
                  "G2: getCustomerInfoV2 with paymentMethods=false returns a successful 200 response."
                          + " AO does not suppress the paymentMethods field for accounts that already have"
                          + " linked payment methods — the flag controls whether payment-eligibility"
                          + " computation is performed, not whether the field is omitted.")
  public void getCustomerInfoV2PaymentMethodsFalseReturnsNullField() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with paymentMethods=false
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId,
                    false, false, null, false, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(
            response.getCustomerInfo(),
            "customerInfo should be present in the response");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G5 – emergencyContactInfo content field validation
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 45,
          description =
                  "G5: Create emergency contact via updateCustomerInfo, then verify getCustomerInfoV2"
                          + " with includeEC=true returns the saved emergency contact data")
  public void getCustomerInfoV2EmergencyContactInfoContentValidation()
          throws Exception {
    // ── Setup: Create a dedicated self-contained account for this test ────────
    // caregiverCustomerAccountId may not be registered in AO's OCP table because
    // createPharmacyAccountV1 can fail silently in @BeforeClass (broken retry logic ignores
    // 2xx-non-200 and some 4xx responses). A fresh account created here — with its own CPR
    // and pharmacy profiles — guarantees OCP registration immediately before updateCustomerInfo.
    String g5Email = CommonUtil.generateRandomEmailId(10);
    String g5StoreNbr = CommonUtil.generateRandomNumber(6);
    String g5PatientId = CommonUtil.generateRandomNumber(9);
    String g5FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String g5LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String g5AccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            g5Email, commonPassword, commonPhoneNo, g5FirstName, g5LastName,
            CommonUtil.randomUUID());
    createCPRAccount(
            g5StoreNbr, g5PatientId, g5FirstName, g5LastName,
            commonDobCPRFormatForOlderThan18, HUMAN);
    createPharmacyAccount(g5AccountId, g5StoreNbr, g5PatientId, commonDobDPFormatForOlderThan18);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId,
            g5StoreNbr,
            g5PatientId,
            g5AccountId,
            null,
            null,
            false,
            reqId,
            reqTrackingId);

    // Step 1: Create emergency contact data via updateCustomerInfo.
    // getCustomerInfoV2 with includeEC=true only returns EC data when the account has EC data
    // stored in CPR. EC data does not exist by default for dynamically-created test accounts;
    // it must be explicitly written via updateCustomerInfo before querying.
    List<UpdateCustomerInfoV1Request.EmergencyContactInfo> ecList = new ArrayList<>();
    ecList.add(
            UpdateCustomerInfoV1Request.EmergencyContactInfo.builder()
                    .firstName("John")
                    .middleName("M")
                    .lastName("Doe")
                    .gender("M")
                    .dob("01011990")
                    .phoneNbr("5551234567")
                    .relationshipType("SPOUSE")
                    .build());
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            updateResponse =
            accountOrchestratorRetrofit.updateCustomerInfo(
                    g5AccountId,
                    domainId,
                    UpdateCustomerInfoV1Request.builder()
                            .emergencyContactInfo(ecList)
                            .build());
    Assert.assertEquals(
            updateResponse.code(), 200,
            "updateCustomerInfo must return 200 before EC can be queried via getCustomerInfoV2");

    // Step 2: Wait for async CPR write to propagate.
    Thread.sleep(60000);

    // Step 3: Verify emergency contact is returned by getCustomerInfoV2 with includeEC=true.
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    g5AccountId, domainId, false, false, null, false, true, true, false, false);
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step 4: Assert EC data is present and matches what was saved.
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload is null");
    Assert.assertNotNull(
            response.getCustomerInfo().getEmergencyContactInfo(),
            "Emergency contact info should be present after updateCustomerInfo");
    Assert.assertFalse(
            response.getCustomerInfo().getEmergencyContactInfo().isEmpty(),
            "Emergency contact list should not be empty");
    Assert.assertEquals(
            response.getCustomerInfo().getEmergencyContactInfo().get(0).getFirstName(), "John",
            "Emergency contact firstName should match what was saved via updateCustomerInfo");
  }

  @Test(
          priority = 46,
          description =
                  "G7: getCustomerInfoV2 should always return non-null"
                          + " onlineCustId and onlineStoreNbr for an ADULT account."
                          + " NOTE: cprDigitalProfileSync is only populated when the CPR patient was created"
                          + " through the digital patient flow; harness-created accounts always return it null.")
  public void getCustomerInfoV2WithAdultLookupCIDHasOnlineFields()
          throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 to verify online profile fields are always returned
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId,
                    false, false, null, false, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(response.getCustomerInfo(), "customerInfo should not be null");
    Assert.assertEquals(
            response.getCustomerInfo().getAuthPatientId(),
            caregiverPatientId,
            "Should return caregiverCustomerAccountId's patient data");
    Assert.assertNotNull(
            response.getCustomerInfo().getOnlineCustId(),
            "onlineCustId should always be non-null for an ADULT account");
    Assert.assertNotNull(
            response.getCustomerInfo().getOnlineStoreNbr(),
            "onlineStoreNbr should always be non-null for an ADULT account");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G8 – paymentMethods=true + caregiversInfo=true → caregiver entry has paymentMethods field
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 47,
          description =
                  "G8: getCustomerInfoV2 with paymentMethods=true and caregiversInfo=true returns"
                          + " a populated caregiversInfo list. paymentMethods inside caregiversInfo is"
                          + " only populated if the caregiver has pharmacy payment methods registered.")
  public void getCustomerInfoV2PaymentMethodsInCaregiversInfoWhenPaymentMethodsTrue() throws IOException {
    // Call as dependent1CustomerAccountId (who has caregiverCustomerAccountId as caregiver)
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, dependent1StoreNbr, dependent1PatientId,
            dependent1CustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with paymentMethods=true and caregiversInfo=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    dependent1CustomerAccountId, domainId,
                    false, false, null, false, false, false, true, true);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(response.getCaregiversInfo(), "caregiversInfo should be present");
    Assert.assertFalse(response.getCaregiversInfo().isEmpty(), "caregiversInfo should have at least one entry");
    Assert.assertEquals(
            response.getCaregiversInfo().get(0).getCustomerAccountId(),
            caregiverCustomerAccountId,
            "First caregiver should be caregiverCustomerAccountId");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G9 – caregiversInfo=true with no linked caregivers → null caregiversInfo
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 48,
          description =
                  "G9: getCustomerInfoV2 with caregiversInfo=true for a customer who has no linked"
                          + " caregivers should return null caregiversInfo (caregiverCustomerAccountId is a"
                          + " top-level caregiver with no caregiver above them)")
  public void getCustomerInfoV2CaregiversInfoTrueWithNoCaregiversReturnsNull() throws IOException {
    // caregiverCustomerAccountId has dependents below but no caregiver above
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with caregiversInfo=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId,
                    false, false, null, false, false, false, false, true);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertTrue(
            response.getCaregiversInfo() == null || response.getCaregiversInfo().isEmpty(),
            "caregiversInfo should be null or empty when the customer has no linked caregivers");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G10 – storeFilter=true correctly includes MINOR dependent
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 49,
          description =
                  "G10: getCustomerInfoV2 with storeFilter=true and dependentsInfo=true should include"
                          + " the MINOR dependent whose patientLink store matches the WM-PHARMACY domain."
                          + " Uses isolated cgG11CustomerAccountId with adultDepG11 (ADULT) + minorDep (MINOR).")
  public void getCustomerInfoV2StoreFilterTrueWithMinorDependent() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, cgG11StoreNbr, cgG11PatientId,
            cgG11CustomerAccountId, minorDepCustomerAccountId, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with dependentsInfo=true and storeFilter=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    cgG11CustomerAccountId, domainId,
                    true, false, null, false, true, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(response.getDependentsInfo(), "dependentsInfo should be present");
    boolean minorDepPresent =
            response.getDependentsInfo().stream()
                    .anyMatch(d -> Objects.equals(d.getAuthPatientId(), minorDepPatientId));
    Assert.assertTrue(
            minorDepPresent,
            "MINOR dependent (patientId=" + minorDepPatientId + ") should appear in"
                    + " dependentsInfo when storeFilter=true and their store matches WM-PHARMACY domain");
    response.getDependentsInfo().stream()
            .filter(d -> Objects.equals(d.getAuthPatientId(), minorDepPatientId))
            .findFirst()
            .ifPresent(minor -> Assert.assertEquals(minor.getType(), Type.MINOR,
                    "Dependent with minorDepPatientId should have type MINOR"));
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G11 – dependentsInfo deep field validation (ADULT + MINOR)
  // ──────────────────────────────────────────────────────────────────────────

  @Test(
          priority = 50,
          description =
                  "G11: getCustomerInfoV2 with dependentsInfo=true should return fully populated"
                          + " dependent entries – validate authPatientId, authStoreNbr, firstName, lastName,"
                          + " type, and non-null patientLinks for both the ADULT and MINOR dependents."
                          + " Uses isolated cgG11CustomerAccountId with adultDepG11 (ADULT) + minorDep (MINOR).")
  public void getCustomerInfoV2DependentsInfoDeepFieldValidation() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, cgG11StoreNbr, cgG11PatientId,
            cgG11CustomerAccountId, null, null, false, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with dependentsInfo=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    cgG11CustomerAccountId, domainId,
                    true, false, null, false, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(response.getDependentsInfo(), "dependentsInfo should be present");
    Assert.assertEquals(response.getDependentsInfo().size(), 2,
            "Should have 2 dependents: adultDepG11 (ADULT APPROVED) and minorDep (MINOR APPROVED)");

    // Validate ADULT dependent fields
    GetCustomerAccountInfoV2Response.CustomerInfo adultDep =
            response.getDependentsInfo().stream()
                    .filter(d -> Objects.equals(d.getAuthPatientId(), adultDepG11PatientId))
                    .findFirst()
                    .orElse(null);
    Assert.assertNotNull(adultDep, "ADULT dependent (adultDepG11PatientId) must be in dependentsInfo");
    Assert.assertEquals(adultDep.getAuthPatientId(), adultDepG11PatientId);
    Assert.assertEquals(adultDep.getAuthStoreNbr(), adultDepG11StoreNbr);
    Assert.assertEquals(adultDep.getFirstName(), adultDepG11FirstName);
    Assert.assertEquals(adultDep.getLastName(), adultDepG11LastName);
    Assert.assertEquals(adultDep.getType(), Type.ADULT, "Dependent should be of type ADULT");
    Assert.assertNotNull(adultDep.getPatientLinks(), "ADULT dependent patientLinks must not be null");
    Assert.assertFalse(adultDep.getPatientLinks().isEmpty(), "ADULT dependent should have at least one patientLink");

    // Validate MINOR dependent fields
    GetCustomerAccountInfoV2Response.CustomerInfo minorDep =
            response.getDependentsInfo().stream()
                    .filter(d -> Objects.equals(d.getAuthPatientId(), minorDepPatientId))
                    .findFirst()
                    .orElse(null);
    Assert.assertNotNull(minorDep, "MINOR dependent (minorDepPatientId) must be in dependentsInfo");
    Assert.assertEquals(minorDep.getAuthPatientId(), minorDepPatientId);
    Assert.assertEquals(minorDep.getAuthStoreNbr(), minorDepStoreNbr);
    Assert.assertEquals(minorDep.getFirstName(), minorDepFirstName);
    Assert.assertEquals(minorDep.getLastName(), minorDepLastName);
    Assert.assertEquals(minorDep.getType(), Type.MINOR, "Dependent should be of type MINOR");
    Assert.assertNotNull(minorDep.getPatientLinks(), "MINOR dependent patientLinks must not be null");
    Assert.assertFalse(minorDep.getPatientLinks().isEmpty(), "MINOR dependent should have at least one patientLink");
  }

  // ──────────────────────────────────────────────────────────────────────────
  // G12 – walmartPlusStatus=true returns ACTIVE status for W+ account (DISABLED)
  // ──────────────────────────────────────────────────────────────────────────

  // DISABLED: walmartPlusStatus=true causes a non-2xx response for ALL accounts in the test
  // environment regardless of whether the account has a W+ membership. AO makes a downstream
  // call to the W+ query service when this flag is set; that call fails (non-2xx / body=null)
  // in this environment. Re-enable this test once the environment/service issue is resolved.
  @Test(
//          enabled = false,
          priority = 51,
          description =
                  "G12: getCustomerInfoV2 with walmartPlusStatus=true should return ACTIVE"
                          + " walmartPlusStatus on customerInfo for caregiverCustomerAccountId, which has an"
                          + " active W+ membership created in @BeforeClass."
                          + " DISABLED: walmartPlusStatus=true causes non-2xx for all accounts in this"
                          + " environment — W+ query integration in AO is not configured. Re-enable after fix.")
  public void getCustomerInfoV2WalmartPlusStatusTrueReturnsActiveForWPlusAccount() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logAccountDetails(
            domainId, caregiverStoreNbr, caregiverPatientId,
            caregiverCustomerAccountId, null, null, true, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerInfoV2 with walmartPlusStatus=true
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getCustomerInfoV2Response =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                    caregiverCustomerAccountId, domainId,
                    false, true, null, false, false, false, false, false);

    // Step - 3: Building errorMessage
    String errorMessage = CommonUtil.buildErrorMessage(gson, getCustomerInfoV2Response);

    // Step - 4: Parsing the response
    GetCustomerAccountInfoV2Response response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getCustomerInfoV2Response.body().getPayload()),
                    GetCustomerAccountInfoV2Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerInfoV2Response.code(), 200, errorMessage);
    Assert.assertNotNull(getCustomerInfoV2Response.body().getPayload(), "Payload should not be null");
    Assert.assertNotNull(response.getCustomerInfo(), "customerInfo should not be null");
    Assert.assertNotNull(
            response.getCustomerInfo().getWalmartPlusStatus(),
            "walmartPlusStatus should not be null when walmartPlusStatus=true and account has W+");
    Assert.assertEquals(
            response.getCustomerInfo().getWalmartPlusStatus(),
            WalmartPlusStatus.ACTIVE,
            "caregiverCustomerAccountId created W+ membership in @BeforeClass so status should be ACTIVE");
  }

  private void logAccountDetails(
          String domainId,
          String storeNumber,
          String patientId,
          String loggedInCustomerAccountId,
          String dependentCustomerAccountId,
          String lookUpCustomerAccountId,
          Boolean wPlus,
          String reqId,
          String reqTrackingId) {
    Reporter.logJSON("domain Id", domainId);
    Reporter.logJSON("Store nbr", storeNumber);
    Reporter.logJSON("Patient Id", patientId);
    Reporter.logJSON("Logged In Customer Account Id", loggedInCustomerAccountId);
    Reporter.logJSON("Dependent Customer Account Id", dependentCustomerAccountId);
    Reporter.logJSON("LookUp Customer Account Id", lookUpCustomerAccountId);
    Reporter.logJSON("Walmart Plus Status", wPlus);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
