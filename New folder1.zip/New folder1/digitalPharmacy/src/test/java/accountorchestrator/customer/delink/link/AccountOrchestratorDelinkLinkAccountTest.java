package accountorchestrator.customer.delink.link;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CAServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.EntityServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import accountorchestrator.utils.CommonAccountHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.DelinkAndLinkAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.DelinkAndLinkAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.AESUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMGetPrefDataResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetCareGiverResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetDependentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetProfileResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.PharmacyOnlineIdentityV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AccountOrchestratorDelinkLinkAccountTest {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private String existingCareGiverId;
  private String newCareGiverId;
  private String alreadyLinkedCID;
  private AESUtil aesUtil;
  private static final String DOMAIN = "WM-PHARMACY";
  private String existingCustomertoken;
  private String newCustomertoken;

  /** Pharmacy details for existingCareGiverId — verified by P8 and P10 after P6 success. */
  private String storeNbr;
  private String patientId;
  /** Pharmacy details for alreadyLinkedCID — used in P7 "already exists" scenario. */
  private String alreadyLinkedStoreNbr;
  private String alreadyLinkedPatientId;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private final Gson gson = new GsonBuilder().create();
  private WCPRetroFit wcpRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;

  private static final String COMMON_PASSWORD = "Test@12345";
  private static final String COMMON_PHONE    = "1234567829";
  private String dobDPFormat;
  private String dobCPRFormat;
  private String firstName;
  private String lastName;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit  = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    wcpRetrofit                  = new WCPRetroFit();
    dmPostPreferencesRetrofit    = new DMPostPreferencesRetrofit();
    cprPatientUpdateRetrofit     = new CprPatientUpdateRetrofit();
    aesUtil                      = new AESUtil();

    // MDM-safe name/DOB (avoids data-quality rejections from CPR)
    dobDPFormat  = "01011900";
    dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd")
                       .format(new SimpleDateFormat("MMddyyyy").parse(dobDPFormat));
    firstName    = "BB";
    lastName     = "DC";

    // ── Group 1: Create 5 fresh WCP accounts ──────────────────────────────
    existingCareGiverId = createAccount();
    Thread.sleep(500);
    newCareGiverId      = createAccount();
    Thread.sleep(500);
    alreadyLinkedCID    = createAccount();
    Thread.sleep(500);
    String dependentCID = createAccount();
    Thread.sleep(500);
    String caregiverCID = createAccount();

    Reporter.logJSON("existingCareGiverId", existingCareGiverId);
    Reporter.logJSON("newCareGiverId",      newCareGiverId);
    Reporter.logJSON("alreadyLinkedCID",    alreadyLinkedCID);

    Thread.sleep(1000);

    // ── Group 2: FAM linkages (verified by P11–P14 after P6 success) ───────
    // existingCareGiverId owns dependentCID
    CAServiceHelper.callCAAddDependentAPI(
        wcpRetrofit,
        CAServiceHelper.buildCAAddDependentRequest(
            existingCareGiverId, dependentCID,
            DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE));
    Thread.sleep(500);
    // caregiverCID owns existingCareGiverId → caregiverCID becomes a caregiver of existingCareGiverId
    CAServiceHelper.callCAAddDependentAPI(
        wcpRetrofit,
        CAServiceHelper.buildCAAddDependentRequest(
            caregiverCID, existingCareGiverId,
            DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE));

    Thread.sleep(1000);

    // ── Group 3: CPR registrations ────────────────────────────────────────
    storeNbr               = CommonUtil.generateRandomNumber(6);
    patientId              = CommonUtil.generateRandomNumber(9);
    alreadyLinkedStoreNbr  = CommonUtil.generateRandomNumber(6);
    alreadyLinkedPatientId = CommonUtil.generateRandomNumber(9);

    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit, storeNbr, patientId, dobCPRFormat, firstName, lastName);
    Thread.sleep(500);
    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit, alreadyLinkedStoreNbr, alreadyLinkedPatientId,
        dobCPRFormat, firstName, lastName);

    // Wait for both CPR records to propagate to AES
    Thread.sleep(10000);

    // ── Group 4: Pharmacy accounts in AES ────────────────────────────────
    EntityServiceHelper.createPharmacyAccount(               // P6 source account
        accountEntityServiceRetrofit, existingCareGiverId, DOMAIN,
        EntityServiceHelper.buildCreatePharmacyAccountV1Request(
            storeNbr, patientId, dobDPFormat, "smsOtpVerification"));
    Thread.sleep(1000);
    EntityServiceHelper.createPharmacyAccount(               // P7 "already exists" target
        accountEntityServiceRetrofit, alreadyLinkedCID, DOMAIN,
        EntityServiceHelper.buildCreatePharmacyAccountV1Request(
            alreadyLinkedStoreNbr, alreadyLinkedPatientId, dobDPFormat, "smsOtpVerification"));

    existingCustomertoken = aesUtil.encrypt(existingCareGiverId);
    newCustomertoken      = aesUtil.encrypt(newCareGiverId);

    Reporter.logJSON("storeNbr",              storeNbr);
    Reporter.logJSON("patientId",             patientId);
    Reporter.logJSON("existingCustomertoken", existingCustomertoken);
  }

  @Test(priority = 1, description = "Delink link account invalid domain")
  public void delinkAndLinkAccountV1InvalidDomain() throws IOException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> delinkLinkAccountResponse =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId,
                    "dummy",
                    delinkAndLinkAccountV1Request,
                    reqId,
                    reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("domainId"));
    Assert.assertTrue(errorResponse.getMessage().contains("is invalid"));
  }

  @Test(priority = 2, description = "Delink link account invalid token")
  public void delinkAndLinkAccountV1InvalidToken() throws IOException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setToken(UUID.randomUUID().toString());

    Response<ServiceResponse> delinkLinkAccountResponse =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 500, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1007");
    Assert.assertTrue(errorResponse.getMessage().contains("Error decrypting token"));
  }

  @Test(priority = 3, description = "Delink link account 400 from CA (truncated / malformed CID in token)")
  public void delinkAndLinkAccountV1400FromCA() throws IOException, GeneralSecurityException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();
    String cid = UUID.randomUUID().toString();
    cid = cid.substring(0, cid.length() - 2);
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(cid));

    Response<ServiceResponse> delinkLinkAccountResponse =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7002");
    Assert.assertTrue(errorResponse.getMessage().contains("Invalid customerAccountId"));
  }

  @Test(priority = 4, description = "Delink link account 404 from CA (valid UUID format but unknown CID in token)")
  public void delinkAndLinkAccountV1404FromCA() throws IOException, GeneralSecurityException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();
    String cid = UUID.randomUUID().toString();
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(cid));

    Response<ServiceResponse> delinkLinkAccountResponse =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertTrue(
            errorResponse.getMessage().contains("No information found for given customerAccountId"));
  }

  @Test(priority = 5, description = "Delink link account, account not found error")
  public void delinkAndLinkAccountNotFoundError() throws Exception {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Fresh WCP account: exists in WCP but has no pharmacy profile in OCP → DPR-DPACCOR-2002
    String freshCid = createAccount();

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(freshCid));

    Response<ServiceResponse> delinkLinkAccountResponse =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }

  @Test(priority = 6, description = "Delink link account success")
  public void delinkAndLinkAccount1Success() throws IOException, InterruptedException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    newCareGiverId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, response);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 200, errorMessage);

    DelinkAndLinkAccountV1Response delinkAndLinkAccountV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                    DelinkAndLinkAccountV1Response.class);
    Assert.assertEquals(
            delinkAndLinkAccountV1Response.getCustomerAccountId(), newCareGiverId);

    // Let all async operations complete for further verification
    Thread.sleep(10000);
  }

  @Test(priority = 7, description = "Delink link account, account already exists error")
  public void delinkAndLinkAccountAlreadyExistsError() throws IOException, GeneralSecurityException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request = buildDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setToken(aesUtil.encrypt(newCareGiverId));

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.delinkAndLinkAccountV1(
                    alreadyLinkedCID, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId, false);

    Error errorResponse  = CommonUtil.getErrorResponse(gson, response);
    String errorMessage  = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2004");
    Assert.assertTrue(errorResponse.getMessage().contains("Online account id already exists"));
  }

  @Test(
          priority = 8,
          description = "Delink link account, verify new cid has auth store nbr and auth patient id present after API success")
  public void delinkAndLinkAccountNewCIDHasStoreProfilePresentAsyncOperationVerification()
          throws IOException {

    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
            serviceResponse =
            EntityServiceHelper.getPharmacyOnlineIdentityV1(
                    accountEntityServiceRetrofit, newCareGiverId, DOMAIN);

    PharmacyOnlineIdentityV1Response pharmacyOnlineIdentityV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) serviceResponse.body().getPayload()),
                    PharmacyOnlineIdentityV1Response.class);

    Assert.assertEquals(storeNbr,  pharmacyOnlineIdentityV1Response.getAuthStoreNbr());
    Assert.assertEquals(patientId, pharmacyOnlineIdentityV1Response.getAuthPatientId());
  }

  @Test(
          priority = 9,
          description = "Delink link account, verify existing cid has no auth store nbr and auth patient id present after API success")
  public void delinkAndLinkAccountExistingCIDHasNoStoreProfilePresentAsyncOperationVerification()
          throws IOException {

    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
            serviceResponse =
            EntityServiceHelper.getPharmacyOnlineIdentityV1(
                    accountEntityServiceRetrofit, existingCareGiverId, DOMAIN);

    Assert.assertEquals(204, serviceResponse.code());
  }

  @Test(
          priority = 10,
          description = "Delink link account, verify enrollment in DM for new cid after API success")
  public void delinkAndLinkAccountNewCidHasDMEnrollmentPresentAsyncOperationVerification()
          throws Exception {

    // Dynamically fetch the expected email from WCP profile (email enrolled in DM after delink/link)
    Response<WCPGetProfileResponse> wcpProfileResponse =
        CAServiceHelper.getPersonByCustomerAccountId(wcpRetrofit, newCareGiverId);
    String expectedEmail =
        wcpProfileResponse.body().getPayload().getAccount().getEmailAddress();

    List<String> shortCodeTypes = new ArrayList<>();
    shortCodeTypes.add("RX");
    shortCodeTypes.add("CS");

    Response<DMGetPrefDataResponse> dmResponse =
            DMServiceHelper.getPrefData(
                    dmPostPreferencesRetrofit,
                    DMServiceHelper.buildDMGetPrefDataRequest(
                            patientId, storeNbr, "1", "true", shortCodeTypes));
    String actualEmail = dmResponse.body().getPatientPreferences().get(0).getNotificationVal();

    Assert.assertEquals(expectedEmail, actualEmail);
    Assert.assertEquals(
            "26802", dmResponse.body().getPatientPreferences().get(0).getEnrollmentStatusCode());
  }

  @Test(
          priority = 11,
          description = "Delink link account, existing cid to not have any caregiver after API success")
  public void delinkAndLinkAccountExistingCidHasNoCaregiverPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetCareGiverResponse> response =
            wcpRetrofit.getCareGivers(existingCareGiverId);

    Assert.assertEquals(response.code(), 200);
    Assert.assertEquals(response.body().getPayload().getOwners().size(), 0);
  }

  @Test(
          priority = 12,
          description = "Delink link account, existing cid to not have any dependents after API success")
  public void delinkAndLinkAccountExistingCidHasNoDependentPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetDependentsResponse> response =
            wcpRetrofit.getDependents(existingCareGiverId);

    Assert.assertEquals(response.body().getPayload().getDependents().size(), 0);
  }

  @Test(
          priority = 13,
          description = "Delink link account, new cid to have all caregivers of existing cid after API success")
  public void delinkAndLinkAccountNewCidHasAllCaregiversPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetCareGiverResponse> response =
            wcpRetrofit.getCareGivers(newCareGiverId);

    Assert.assertEquals(response.body().getPayload().getOwners().size(), 1);
  }

  @Test(
          priority = 14,
          description = "Delink link account, new cid to have all dependents of existing cid after API success")
  public void delinkAndLinkAccountNewCidHasAllDependentsPresentAsyncOperationVerification()
          throws Exception {

    Response<WCPGetDependentsResponse> response =
            wcpRetrofit.getDependents(newCareGiverId);

    Assert.assertEquals(response.body().getPayload().getDependents().size(), 1);
  }

  @Test(priority = 15, description = "Delink link account with empty token — input validation error")
  public void delinkAndLinkAccountV1EmptyToken() throws IOException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request request =
        DelinkAndLinkAccountV1Request.builder().token("").build();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            newCareGiverId, DOMAIN, request, reqId, reqTrackingId, false);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().toLowerCase().contains("token"));
  }

  @Test(priority = 16,
      description = "Delink link account with blank customerAccountId — service skips input "
          + "validation, passes blank CID through to OCP lookup which returns no profile found")
  public void delinkAndLinkAccountV1BlankCustomerAccountId() throws IOException {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            " ", DOMAIN, buildDelinkAndLinkAccountV1Request(), reqId, reqTrackingId, false);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }

  @Test(priority = 17,
      description = "Delink link account with reconcileLinks=true — success with FAM reconciliation")
  public void delinkAndLinkAccountV1ReconcileLinksSuccess() throws Exception {
    String trackID       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // ── Create dedicated fresh accounts for this test inline ──────────────
    String recExistingCID = createAccount();
    String recNewCID      = createAccount();
    String recStoreNbr    = CommonUtil.generateRandomNumber(6);
    String recPatientId   = CommonUtil.generateRandomNumber(9);

    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit, recStoreNbr, recPatientId, dobCPRFormat, firstName, lastName);
    // Wait for CPR record to propagate to AES before creating pharmacy account
    Thread.sleep(10000);
    EntityServiceHelper.createPharmacyAccount(
        accountEntityServiceRetrofit, recExistingCID, DOMAIN,
        EntityServiceHelper.buildCreatePharmacyAccountV1Request(
            recStoreNbr, recPatientId, dobDPFormat, "smsOtpVerification"));

    // ── Invoke API with reconcileLinks=true ───────────────────────────────
    DelinkAndLinkAccountV1Request request =
        DelinkAndLinkAccountV1Request.builder().token(aesUtil.encrypt(recExistingCID)).build();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.delinkAndLinkAccountV1(
            recNewCID, DOMAIN, request, reqId, reqTrackingId, true);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 204, errorMessage);
    // HTTP 204 No Content — response body is null, nothing to parse
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  private DelinkAndLinkAccountV1Request buildDelinkAndLinkAccountV1Request() {
    return DelinkAndLinkAccountV1Request.builder().token(existingCustomertoken).build();
  }

  /** Creates a fresh DotCom account and returns its CID from WIAP. */
  private String createAccount() throws Exception {
    return CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
        CommonUtil.generateRandomEmailId(10),
        COMMON_PASSWORD,
        COMMON_PHONE,
        firstName,
        lastName,
        null);
  }
}
