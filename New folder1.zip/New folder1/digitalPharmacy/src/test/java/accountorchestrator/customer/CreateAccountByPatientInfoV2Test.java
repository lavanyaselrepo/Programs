package accountorchestrator.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.CreateAccountByPatientInfoV2Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.CreateAccountByPatientInfoV2Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.UUID;

public class CreateAccountByPatientInfoV2Test {

    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private final Gson gson = new GsonBuilder().create();

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private IDatabaseContext accountDbContext;

    @BeforeClass
    void setContext() throws IOException {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        accountDbContext =
                AutomationManager.getInstance().getDPAccountDBContext();
    }
    @Test(
            priority = 0,
            description = "Call Create Account By Patient Profile V2 API With Invalid Input Request")
    public void createAccountByPatientProfileV2InvalidRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String onlineAccountId = UUID.randomUUID().toString();
        String customerAccountId = "9c79ebe8-d188-4295-85fc-64b23a102141";


        CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                CreateAccountByPatientInfoV2Request.builder()
                        .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                .verificationId(null)
                                .gender("M")
                                .build())
                        .build();

        Response<ServiceResponse> createAccountByPatientInfoResponse =
                accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                        customerAccountId,
                        domainId,
                        createAccountByPatientInfoV2Request,
                        reqId,
                        reqTrackingId,
                        Boolean.FALSE);

        Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertTrue(errorResponse.getMessage().contains("VerificationId is null/empty"));
    }


    @Test(
            priority = 1,
            description = "Call Create Account By Patient Profile V2 API With CustomerAccountId is not verified")
    public void createAccountByPatientProfileV2WithCustomerAccountIdNotVerified() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = "9c79ebe8-d188-4295-85fc-64b23a102141";
        String verificationId = "4cddbc56-6312-4e6a-810c-9f24a9b68564";

        CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                CreateAccountByPatientInfoV2Request.builder()
                        .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                .verificationId(verificationId)
                                .tAndCPolicyLanguage("EN")
                                .build())
                        .build();

        Response<ServiceResponse> createAccountByPatientInfoResponse =
                accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                        customerAccountId,
                        domainId,
                        createAccountByPatientInfoV2Request,
                        reqId,
                        reqTrackingId,
                        false);

        Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-23003");
        Assert.assertTrue(errorResponse.getMessage().contains(String.format(" Accounts not found for customerIdentifier - %s, and verificationId - %s", customerAccountId, verificationId)));
    }



    @Test(
            priority = 2,
            description = "Call Create Account By Patient Profile V2 API With patient not found in cpr")
    public void createAccountByPatientProfileV2WithPatientNotFoundInCPR() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = "e7694077-8db1-415c-a750-507b8cf98c2b";
        String verificationId = "4ddc7263-a34c-422d-941d-b0f5db78ea06";

        CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                CreateAccountByPatientInfoV2Request.builder()
                        .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                .verificationId(verificationId)
                                .tAndCPolicyLanguage("EN")
                                .build())
                        .build();

        Response<ServiceResponse> createAccountByPatientInfoResponse =
                accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                        customerAccountId,
                        domainId,
                        createAccountByPatientInfoV2Request,
                        reqId,
                        reqTrackingId,
                        false);

        Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(createAccountByPatientInfoResponse.code(), 404, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6005");
        Assert.assertTrue(errorResponse.getMessage().contains("No Profile Found by CPR MPI Search. {}"));
    }

    @Test(
            priority = 3,
            description = "Call Create Account By Patient Profile V1 API Success and second time should fail with pharmacy account already exists")
    public void createAccountByPatientProfileSuccess() throws IOException, InterruptedException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = "2ff86042-4080-464a-bddf-2aeb66c00591";
        String verificationId = "2ad78c43-6221-47e1-a989-0c89405c406e";

        try {
            CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                    CreateAccountByPatientInfoV2Request.builder()
                            .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                    .verificationId(verificationId)
                                    .tAndCPolicyLanguage("EN")
                                    .build())
                            .build();

            Response<ServiceResponse> createAccountByPatientInfoResponse =
                    accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                            customerAccountId,
                            domainId,
                            createAccountByPatientInfoV2Request,
                            reqId,
                            reqTrackingId,
                            Boolean.FALSE);

            Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
            String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

            Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
            Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
            CreateAccountByPatientInfoV2Response createAccountByPatientInfoV2Response =
                    ResponseUtil.parseResponse(
                            gson,
                            ((LinkedTreeMap<String, Object>)
                                    createAccountByPatientInfoResponse.body().getPayload()),
                            CreateAccountByPatientInfoV2Response.class);
            Assert.assertEquals(
                    createAccountByPatientInfoV2Response.getCustomerAccountId(), customerAccountId);

            Thread.sleep(30000);

            Response<ServiceResponse> createAccountByPatientInfoResponseSecondTime =
                    accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                            customerAccountId,
                            domainId,
                            createAccountByPatientInfoV2Request,
                            reqId,
                            reqTrackingId,
                            Boolean.FALSE);
            Error errorResponseSecondTime = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponseSecondTime);
            String errorMessageSecondTime = CommonUtil.buildErrorMessage(errorResponseSecondTime);

            Assert.assertEquals(createAccountByPatientInfoResponseSecondTime.code(), 409, errorMessageSecondTime);
            Assert.assertEquals(errorResponseSecondTime.getCode(), "DPR-DPACCOR-2011");
        } finally {
            // Clean up - Delete the pharmacy Account
             deleteOCPRecord(customerAccountId );
        }

    }


    @Test(
            priority = 4,
            description = "Call Create Account Without Rx V2 API With Invalid Input Request")
    public void createAccountWithoutRxV2InvalidRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = UUID.randomUUID().toString();

        CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                CreateAccountByPatientInfoV2Request.builder()
                        .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                .verificationId("123456789")
                                .tAndCPolicyLanguage("EN")
                                .build())
                        .build();

        Response<ServiceResponse> createAccountByPatientInfoResponse =
                accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                        customerAccountId,
                        domainId,
                        createAccountByPatientInfoV2Request,
                        reqId,
                        reqTrackingId,
                        Boolean.TRUE);

        Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertTrue(errorResponse.getMessage().contains("Gender is null/empty"));
    }


    @Test(
            priority = 5,
            description = "Call Create Account Without Rx V2 API With CustomerAccountId is not verified")
    public void createAccountWithoutRxV2WithCustomerAccountIdNotVerified() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = "9c79ebe8-d188-4295-85fc-64b23a102141";
        String verificationId = "4cddbc56-6312-4e6a-810c-9f24a9b68564";

        CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                CreateAccountByPatientInfoV2Request.builder()
                        .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                .verificationId(verificationId)
                                .tAndCPolicyLanguage("EN")
                                .gender("M")
                                .build())
                        .build();

        Response<ServiceResponse> createAccountByPatientInfoResponse =
                accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                        customerAccountId,
                        domainId,
                        createAccountByPatientInfoV2Request,
                        reqId,
                        reqTrackingId,
                        Boolean.TRUE);

        Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(createAccountByPatientInfoResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-23003");
        Assert.assertTrue(errorResponse.getMessage().contains(String.format(" Accounts not found for customerIdentifier - %s, and verificationId - %s", customerAccountId, verificationId)));
    }

    @Test(
            priority = 6,
            description = "Call Create Account Without Rx V2 API with one cpr profile found success nd second should fail with pharmacy account already exists")
    public void createAccountWithoutRxV2WithOneProfileFoundInCprSuccess() throws IOException, InterruptedException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerAccountId = "e7694077-8db1-415c-a750-507b8cf98c2b";
        String verificationId = "4ddc7263-a34c-422d-941d-b0f5db78ea06";

        try {
            CreateAccountByPatientInfoV2Request createAccountByPatientInfoV2Request =
                    CreateAccountByPatientInfoV2Request.builder()
                            .customerInfo(CreateAccountByPatientInfoV2Request.CustomerInfo.builder()
                                    .verificationId(verificationId)
                                    .tAndCPolicyLanguage("EN")
                                    .gender("M")
                                    .build())
                            .build();
            Response<ServiceResponse> createAccountByPatientInfoResponse =
                    accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                            customerAccountId,
                            domainId,
                            createAccountByPatientInfoV2Request,
                            reqId,
                            reqTrackingId,
                            Boolean.TRUE);

            Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponse);
            String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

            Assert.assertEquals(createAccountByPatientInfoResponse.code(), 200, errorMessage);
            Assert.assertNotNull(createAccountByPatientInfoResponse.body().getPayload(), "Payload is null");
            CreateAccountByPatientInfoV2Response createAccountByPatientInfoV2Response =
                    ResponseUtil.parseResponse(
                            gson,
                            ((LinkedTreeMap<String, Object>)
                                    createAccountByPatientInfoResponse.body().getPayload()),
                            CreateAccountByPatientInfoV2Response.class);
            Assert.assertEquals(
                    createAccountByPatientInfoV2Response.getCustomerAccountId(), customerAccountId);

            Thread.sleep(60000);

            Response<ServiceResponse> createAccountByPatientInfoResponseSecondTime =
                    accountOrchestratorRetrofit.createAccountByPatientInfoV2(
                            customerAccountId,
                            domainId,
                            createAccountByPatientInfoV2Request,
                            reqId,
                            reqTrackingId,
                            Boolean.TRUE);

            Error errorResponseSecondTime = CommonUtil.getErrorResponse(gson, createAccountByPatientInfoResponseSecondTime);
            String errorMessageSecondTime = CommonUtil.buildErrorMessage(errorResponseSecondTime);

            Assert.assertEquals(createAccountByPatientInfoResponseSecondTime.code(), 409, errorMessageSecondTime);
            Assert.assertEquals(errorResponseSecondTime.getCode(), "DPR-DPACCOR-2011");
        } finally {
            // Clean up - Delete the pharmacy Account
            accountEntityServiceRetrofit.deleteAccountV1(
                    customerAccountId, domainId, reqId, reqTrackingId);
        }
    }


    private void deleteOCPRecord(String uuid) {
        String deleteQuery = String.format(
                "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

}
