package accountorchestrator.customer.accountStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateStageISACRecordV1Request;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.GetAccountStatusV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateAccountByISACInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.DrRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.models.updateIdVerification.UpdateIdVerificationRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dr.models.updateIdVerification.UpdateIdVerificationResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

import static accountorchestrator.utils.CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName;

public class AccountOrchestratorGetAccountStatusTest {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private IsacHelper isacHelper;
  private DrRetrofit drRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonCustomerAccountId = null;
  private String commonPhoneNbr = null;
  private String commonDobCPRFormat = null;
  private String commonDobDPFormat = null;
  private String commonCustomerEmailId = null;
  // Shared dynamic DOB for all adult CPR/AccEn setup calls (generated once in setContext)
  // adultDobCPRFormat : yyyy-MM-dd  used in CPR setBirthDate(...)
  // adultDobDPFormat  : MMddyyyy    used as the CORRECT DOB in AccEn / ISAC calls
  // adultWrongDobDPFormat : MMddyyyy, year-1, used only in P6 DOB-retry exhaustion test
  private String adultDobCPRFormat = null;
  private String adultDobDPFormat = null;
  private String adultWrongDobDPFormat = null;
  private String adult1StoreNbr = null;
  private String adult1FirstName = null;
  private String adult1LastName = null;
  private String adult1PhoneNbr = null;
  private String adult1EmailId = null;
  private String adult1CustomerAccountId = null;
  private String adult1StageId = null;
  private String adult2StoreNbr = null;
  private String adult2FirstName = null;
  private String adult2LastName = null;
  private String adult2PhoneNbr = null;
  private String adult2EmailId = null;
  private String adult2CustomerAccountId = null;
  private String adult2StageId = null;
  private String adult3StoreNbr = null;
  private String adult3FirstName = null;
  private String adult3LastName = null;
  private String adult3PhoneNbr = null;
  private String adult3EmailId = null;
  private String adult3CustomerAccountId = null;
  private String adult3StageId = null;
  private String adult4StoreNbr = null;
  private String adult4FirstName = null;
  private String adult4LastName = null;
  private String adult4PhoneNbr = null;
  private String adult4EmailId = null;
  private String adult4CustomerAccountId = null;
  private String adult4StageId = null;
  private String adult5StoreNbr = null;
  private String adult5FirstName = null;
  private String adult5LastName = null;
  private String adult5PhoneNbr = null;
  private String adult5EmailId = null;
  private String adult5CustomerAccountId = null;
  private String adult5StageId = null;
  private String adult6StoreNbr = null;
  private String adult6FirstName = null;
  private String adult6LastName = null;
  private String adult6PhoneNbr = null;
  private String adult6EmailId = null;
  private String adult6CustomerAccountId = null;
  private String adult6StageId = null;
  private String adult7StoreNbr = null;
  private String adult7FirstName = null;
  private String adult7LastName = null;
  private String adult7PhoneNbr = null;
  private String adult7EmailId = null;
  private String adult7CustomerAccountId = null;
  private String adult7StageId = null;

  // adult8: ISAC stage record with idVerified=false (createStageIsacRecord)
  // Tests: AccEn 204 → CA 200 → ISAC 200 (idVerified=false) → NOT_CREATED + idVerified based on CCM flag
  private String adult8StoreNbr = null;
  private String adult8FirstName = null;
  private String adult8LastName = null;
  private String adult8PhoneNbr = null;
  private String adult8EmailId = null;
  private String adult8CustomerAccountId = null;
  private String adult8StageId = null;

  // adult9: real CPR patient created at storeNbr=9928 then soft-deleted (patientStatusCode=20708, ONLINE_DEL);
  //         AccEn pharmacy account at storeNbr=9928.
  // Tests:  AccEn 200 (authStoreNbr=9928) → CPR 200 (ONLINE_DEL does NOT suppress GET; record still returned)
  //         → patientLinks=[9928] (CCM virtual store) → PARTIAL + CPR_LINK_PENDING
  // adult9PatientId is set explicitly so AccEn can validate against CPR by (storeNbr=9928, patientId)
  private String adult9StoreNbr = null;
  private String adult9FirstName = null;
  private String adult9LastName = null;
  private String adult9PhoneNbr = null;
  private String adult9EmailId = null;
  private String adult9CustomerAccountId = null;
  private String adult9PatientId = null;

  // adult10: CPR patient at adult10StoreNbr (random non-CCM store); AccEn account also at adult10StoreNbr.
  // Tests: AccEn 200 (authStoreNbr=adult10StoreNbr, non-CCM) → CPR 200 (patientLinks at non-CCM store) → ACTIVE
  // adult10PatientId is set explicitly so AccEn can validate against CPR by (storeNbr=adult10StoreNbr, patientId)
  private String adult10StoreNbr = null;
  private String adult10FirstName = null;
  private String adult10LastName = null;
  private String adult10PhoneNbr = null;
  private String adult10EmailId = null;
  private String adult10CustomerAccountId = null;
  private String adult10PatientId = null;

  // adult6PatientId: explicit CPR patientId for adult6, used in P9 (createPharmacyAccountV1 requires
  // AccEn to look up CPR patient by storeNbr+patientId; explicit id ensures the lookup succeeds)
  private String adult6PatientId = null;

  // adult11: CPR patient registered at BOTH adult11NonCcmStoreNbr (random non-CCM) AND storeNbr=9928.
  // The dual registration allows AccEn to validate createPharmacyAccountV1 by (storeNbr=9928, patientId=adult11PatientId),
  // while ensuring CPR getPatientInfo returns patientLinks containing a non-CCM store.
  // GetAccountStatus flow: AccEn 200 (authStoreNbr=9928) → CPR 200 (patientLinks has non-CCM store) → ACTIVE + async update.
  private String adult11NonCcmStoreNbr = null;
  private String adult11FirstName = null;
  private String adult11LastName = null;
  private String adult11PhoneNbr = null;
  private String adult11EmailId = null;
  private String adult11CustomerAccountId = null;
  private String adult11PatientId = null;

  // adult12: no pharmacy account; ISAC stage record created inline in P14 test body.
  // GetAccountStatus flow: AccEn 204 → CA 200 → ISAC 200 → linkExpired=true → NOT_CREATED, idVerified=null.
  // NOTE: P14 requires CCM config isacIdVerificationLinkActiveDurationInMonths=0
  //       OR an ISAC helper method that backdates lastEmailSentTs. Enable only in a matching environment.
  private String adult12StoreNbr = null;
  private String adult12FirstName = null;
  private String adult12LastName = null;
  private String adult12PhoneNbr = null;
  private String adult12EmailId = null;
  private String adult12CustomerAccountId = null;
  private String adult12StageId = null;

  // adult13: pharmacy account created with accountCreationSource="idVerification" (no SMS OTP flow → no 2FA setup).
  // GetAccountStatus flow: AccEn 200 (authStoreNbr=adult13StoreNbr, non-CCM) → ACTIVE, twoFASetUpStatus=INACTIVE.
  // NOTE: twoFASetUpStatus=INACTIVE is expected when the account creation flow does not involve OTP 2FA setup.
  private String adult13StoreNbr = null;
  private String adult13FirstName = null;
  private String adult13LastName = null;
  private String adult13PhoneNbr = null;
  private String adult13EmailId = null;
  private String adult13CustomerAccountId = null;
  private String adult13PatientId = null;

  // adult14: pharmacy account created with accountCreationSource="idVerification".
  // GetAccountStatus flow: AccEn 200 (authStoreNbr=adult14StoreNbr, non-CCM) → ACTIVE, accountCreationSource="idVerification".
  private String adult14StoreNbr = null;
  private String adult14FirstName = null;
  private String adult14LastName = null;
  private String adult14PhoneNbr = null;
  private String adult14EmailId = null;
  private String adult14CustomerAccountId = null;
  private String adult14PatientId = null;

  private String postalCode = "55709";
  private Boolean type = Boolean.FALSE;
  private String accountCreationSource = "smsOtpVerification";
  private String domainId = "WM-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private Integer cprAdult1HumanPatientId, cprAdult2HumanPatientId, cprAdult3HumanPatientId, cprAdult4HumanPatientId, cprAdult5HumanPatientId, cprAdult6HumanPatientId, cprAdult7HumanPatientId, cprAdult8HumanPatientId, cprAdult9HumanPatientId, cprAdult10HumanPatientId;
  // adult11: two CPR registrations (non-CCM store + 9928); adult12-14: one each
  private Integer cprAdult11NonCcmPatientId, cprAdult11At9928PatientId, cprAdult12HumanPatientId, cprAdult13HumanPatientId, cprAdult14HumanPatientId;
  ValidationServiceRequest cprPatientRequest = null,
          adult1HumanCprPatientRequest, adult2HumanCprPatientRequest, adult3HumanCprPatientRequest, adult4HumanCprPatientRequest, adult5HumanCprPatientRequest, adult6HumanCprPatientRequest, adult7HumanCprPatientRequest, adult8HumanCprPatientRequest, adult9HumanCprPatientRequest, adult10HumanCprPatientRequest,
          // adult11: non-CCM store registration; adult11Cpr9928PatientRequest: storeNbr=9928 registration (same patientId)
          adult11HumanCprPatientRequest, adult11Cpr9928PatientRequest,
          adult12HumanCprPatientRequest, adult13HumanCprPatientRequest, adult14HumanCprPatientRequest;
  java.util.List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    isacHelper = new IsacHelper();
    drRetrofit = new DrRetrofit();

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    commonPhoneNbr = CommonUtil.generateRandomNumber(10);
    commonCustomerEmailId = CommonUtil.generateRandomEmailId(10);

    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

    // Generate a random adult DOB shared across all adult CPR/AccEn setup calls.
    // Age range 25–54; day 1–28 avoids February edge cases.
    ThreadLocalRandom rng = ThreadLocalRandom.current();
    int adultRandomMonth = rng.nextInt(12) + 1;                           // 1–12
    int adultRandomDay   = rng.nextInt(28) + 1;                           // 1–28
    int adultRandomYear  = LocalDate.now().getYear() - rng.nextInt(30) - 25; // age 25–54
    adultDobCPRFormat     = String.format("%04d-%02d-%02d", adultRandomYear, adultRandomMonth, adultRandomDay);
    adultDobDPFormat      = String.format("%02d%02d%04d",   adultRandomMonth, adultRandomDay, adultRandomYear);
    // One year before the actual DOB — guaranteed mismatch for P6's DOB-retry exhaustion test
    adultWrongDobDPFormat = String.format("%02d%02d%04d",   adultRandomMonth, adultRandomDay, adultRandomYear - 1);

    adult1StoreNbr = CommonUtil.generateRandomNumber(6);
    adult1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult1PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult1EmailId = CommonUtil.generateRandomEmailId(10);

    adult2StoreNbr = CommonUtil.generateRandomNumber(6);
    adult2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult2PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult2EmailId = CommonUtil.generateRandomEmailId(10);

    adult3StoreNbr = CommonUtil.generateRandomNumber(6);
    adult3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult3PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult3EmailId = CommonUtil.generateRandomEmailId(10);

    adult4StoreNbr = CommonUtil.generateRandomNumber(6);
    adult4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    adult4PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult4EmailId = CommonUtil.generateRandomEmailId(10);

    adult5StoreNbr = CommonUtil.generateRandomNumber(6);
    adult5FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult5LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult5PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult5EmailId = CommonUtil.generateRandomEmailId(10);

    adult6StoreNbr = CommonUtil.generateRandomNumber(6);
    adult6FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult6LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult6PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult6EmailId = CommonUtil.generateRandomEmailId(10);
    // Explicit CPR patientId for adult6: used directly in createPharmacyAccountV1 to guarantee
    // AccEn can look up the CPR patient via (storeNbr=adult6StoreNbr, patientId=adult6PatientId).
    adult6PatientId = CommonUtil.generateRandomNumber(9);

    adult7StoreNbr = "9928";
    adult7FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult7LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult7PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult7EmailId = CommonUtil.generateRandomEmailId(10);

    // adult8: CPR patient at a random store; ISAC stage record (idVerified=false) created in post-setup
    adult8StoreNbr = CommonUtil.generateRandomNumber(6);
    adult8FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult8LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult8PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult8EmailId = CommonUtil.generateRandomEmailId(10);

    // adult9: real CPR patient created at storeNbr=9928 (so AccEn can validate the pharmacy account
    // creation by (storeNbr=9928, patientId=adult9PatientId)), then immediately soft-deleted in post-setup.
    adult9StoreNbr = "9928";    // CPR patient lives at 9928 so AccEn can look it up during account creation
    adult9FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult9LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult9PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult9EmailId = CommonUtil.generateRandomEmailId(10);
    // Explicit CPR patientId for adult9: used in createPharmacyAccountV1 (storeNbr=9928) and soft-delete.
    adult9PatientId = CommonUtil.generateRandomNumber(9);

    // adult10: CPR patient at adult10StoreNbr (random 6-digit non-CCM store).
    // AccEn pharmacy account is created with storeNbr=adult10StoreNbr (not 9928) so AccEn can validate
    // by (storeNbr=adult10StoreNbr, patientId=adult10PatientId).
    // GetAccountStatus: AccEn 200 (authStoreNbr=adult10StoreNbr, non-CCM) → CPR 200 (same non-CCM store) → ACTIVE.
    adult10StoreNbr = CommonUtil.generateRandomNumber(6);
    adult10FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult10LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult10PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult10EmailId = CommonUtil.generateRandomEmailId(10);
    // Explicit CPR patientId for adult10: used directly in createPharmacyAccountV1.
    adult10PatientId = CommonUtil.generateRandomNumber(9);

    // adult11 (P13): CPR patient at adult11NonCcmStoreNbr (random non-CCM) AND at storeNbr=9928 (same patientId).
    // Pharmacy account at storeNbr=9928. GetAccountStatus: AccEn 200 (authStoreNbr=9928) → CPR 200
    // (patientLinks has non-CCM store → storeNbrFromCCM.size() < union.size()) → ACTIVE + async AccEn update.
    adult11NonCcmStoreNbr = CommonUtil.generateRandomNumber(6);
    adult11FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult11LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult11PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult11EmailId = CommonUtil.generateRandomEmailId(10);
    // Explicit CPR patientId shared across both CPR registrations (non-CCM store + 9928).
    adult11PatientId = CommonUtil.generateRandomNumber(9);

    // adult12 (P14 — linkExpired): CPR patient only; no pharmacy account.
    // ISAC stage record created in P14 test body. linkExpired=true requires CCM linkActiveDurationInMonths=0
    // OR a backdating mechanism in ISAC helper.
    adult12StoreNbr = CommonUtil.generateRandomNumber(6);
    adult12FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult12LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult12PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult12EmailId = CommonUtil.generateRandomEmailId(10);

    // adult13 (P15 — twoFASetUpStatus=INACTIVE): CPR patient at adult13StoreNbr (random non-CCM).
    // Pharmacy account created with accountCreationSource="idVerification" (non-OTP flow → 2FA not set up).
    // GetAccountStatus: AccEn 200 (authStoreNbr=adult13StoreNbr, non-CCM) → ACTIVE, twoFASetUpStatus=INACTIVE.
    adult13StoreNbr = CommonUtil.generateRandomNumber(6);
    adult13FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult13LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult13PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult13EmailId = CommonUtil.generateRandomEmailId(10);
    adult13PatientId = CommonUtil.generateRandomNumber(9);

    // adult14 (P16 — accountCreationSource=idVerification): CPR patient at adult14StoreNbr (non-CCM).
    // Pharmacy account created with accountCreationSource="idVerification" (non-OTP flow, no 2FA setup).
    // GetAccountStatus: AccEn 200 (authStoreNbr=adult14StoreNbr, non-CCM) → ACTIVE, accountCreationSource="idVerification".
    adult14StoreNbr = CommonUtil.generateRandomNumber(6);
    adult14FirstName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult14LastName = RandomStringUtils.randomAlphabetic(8).toUpperCase();
    adult14PhoneNbr = CommonUtil.generateRandomNumber(10);
    adult14EmailId = CommonUtil.generateRandomEmailId(10);
    adult14PatientId = CommonUtil.generateRandomNumber(9);

    createAllCPRAccount();
    createAllCAAccount();

    // Post-setup for adult8: create ISAC stage record with idVerified=false
    // This produces the AccEn 204 → CA 200 → ISAC 200 (idVerified=false) branch
    String adult8SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult8SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    adult8StageId = createStageIsacRecord(
            adult8StoreNbr, cprAdult8HumanPatientId, adult8EmailId,
            adultDobDPFormat,
            adult8SetupReqId, adult8SetupReqTrackingId);

    // Post-setup for adult6: create pharmacy account with smsOtpVerification at adult6StoreNbr (random non-CCM store).
    // Done here in @BeforeClass (not inline in P9) so that AccEn has time to propagate the pharmacy account
    // before P9 calls getAccountStatusV1. Without this delay, getOnlineIdentity returns 204 → NOT_CREATED.
    // GetAccountStatus flow: AccEn 200 (authStoreNbr=adult6StoreNbr, non-CCM) → ACTIVE
    String adult6SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult6SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> adult6PharmacyAccountResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                    adult6CustomerAccountId, domainId,
                    getCreatePharmacyAccountV1Request(adult6StoreNbr, adult6PatientId, adultDobDPFormat),
                    adult6SetupReqId, adult6SetupReqTrackingId);
    if (adult6PharmacyAccountResponse.code() != 200) {
      throw new RuntimeException(
              "createPharmacyAccountV1 for adult6 failed — getAccountStatusV1WithAccountCreatedWithSmsOtpVerification (P9) will not return ACTIVE. "
                      + "HttpStatusCode: " + adult6PharmacyAccountResponse.code());
    }

    // Post-setup for adult9: create pharmacy account using the explicit adult9PatientId at storeNbr=9928.
    // AccEn validates by (storeNbr=9928, patientId=adult9PatientId) → finds CPR patient → 200.
    // Then immediately soft-delete the CPR patient (patientStatusCode=20708 → ONLINE_DEL).
    // NOTE: CPR ONLINE_DEL does NOT suppress GET — CPR still returns HTTP 200 with the patient record.
    // GetAccountStatus flow: AccEn 200 (authStoreNbr=9928, adult9PatientId) → CPR 200 (ONLINE_DEL patient)
    //   → patientLinks=[9928] → storeNbr=9928 is a CCM virtual store → all links are CCM → PARTIAL + CPR_LINK_PENDING
    String adult9SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult9SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> adult9PharmacyAccountResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                    adult9CustomerAccountId, domainId,
                    getCreatePharmacyAccountV1Request("9928", adult9PatientId, adultDobDPFormat),
                    adult9SetupReqId, adult9SetupReqTrackingId);
    if (adult9PharmacyAccountResponse.code() != 200) {
      throw new RuntimeException(
              "createPharmacyAccountV1 for adult9 failed — getAccountStatusV1WithCprProfileNotCreated (P11) will not return PARTIAL + CPR_LINK_PENDING. "
                      + "HttpStatusCode: " + adult9PharmacyAccountResponse.code());
    }
    // Soft-delete adult9's CPR patient immediately after pharmacy account is created.
    // P11 (getAccountStatusV1WithCprProfileNotCreated) runs after all prior tests complete.
    // NOTE: CPR ONLINE_DEL (patientStatusCode=20708) does NOT suppress GET — CPR will still return 200
    // with the patient record (including storeNbr=9928 in patientLinks) → all CCM → CPR_LINK_PENDING.
    adult9HumanCprPatientRequest.getPatientInfo().setPatientStatusCode(20708);
    Response<ValidationServiceResponse> adult9SoftDeleteResponse =
            cprPatientUpdateRetrofit.validateProfile(adult9HumanCprPatientRequest);
    if (adult9SoftDeleteResponse.code() != 202) {
      throw new RuntimeException(
              "CPR soft-delete (patientStatusCode=20708) for adult9 failed — CPR patient will not be ONLINE_DEL "
                      + "and getAccountStatusV1WithCprProfileNotCreated (P11) may not return PARTIAL + CPR_LINK_PENDING. "
                      + "HttpStatusCode: " + adult9SoftDeleteResponse.code());
    }

    // Post-setup for adult10: create pharmacy account with storeNbr=adult10StoreNbr (random non-CCM store)
    // and explicit adult10PatientId. AccEn validates by (storeNbr=adult10StoreNbr, patientId=adult10PatientId).
    // When GetAccountStatus is called: AccEn 200 (authStoreNbr=adult10StoreNbr) → CPR 200
    // (patientLinks contain adult10StoreNbr which is NOT in CCM virtual list) → ACTIVE
    String adult10SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult10SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    accountEntityServiceRetrofit.createPharmacyAccountV1(
            adult10CustomerAccountId, domainId,
            getCreatePharmacyAccountV1Request(adult10StoreNbr, adult10PatientId, adultDobDPFormat),
            adult10SetupReqId, adult10SetupReqTrackingId);

    // Post-setup for adult11 (P13): create pharmacy account at storeNbr=9928 with adult11PatientId.
    // AccEn validates by (storeNbr=9928, patientId=adult11PatientId) → finds the CPR registration at 9928 → 200.
    // When GetAccountStatus is called: AccEn 200 (authStoreNbr=9928) → CPR getPatientInfo(adult11PatientId)
    // returns 200 with patientLinks=[adult11NonCcmStoreNbr, 9928]. adult11NonCcmStoreNbr is NOT in CCM
    // virtual store list → storeNbrFromCCM.size() < union.size() → ACTIVE + async AccEn update.
    String adult11SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult11SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> adult11PharmacyAccountResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                    adult11CustomerAccountId, domainId,
                    getCreatePharmacyAccountV1Request("9928", adult11PatientId, adultDobDPFormat),
                    adult11SetupReqId, adult11SetupReqTrackingId);
    if (adult11PharmacyAccountResponse.code() != 200) {
      throw new RuntimeException(
              "createPharmacyAccountV1 for adult11 (storeNbr=9928) failed — "
                      + "getAccountStatusV1With9928AccountAndNonCcmCprStoreActive (P13) will not return ACTIVE. "
                      + "HttpStatusCode: " + adult11PharmacyAccountResponse.code());
    }

    // Post-setup for adult13 (P15): create pharmacy account with accountCreationSource="idVerification".
    // The idVerification flow does not involve SMS OTP verification, so AccEn should NOT set up 2FA
    // → getAccountVerification returns twoFASetUp as null or non-ACTIVE → twoFASetUpStatus=INACTIVE.
    String adult13SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult13SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> adult13PharmacyAccountResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                    adult13CustomerAccountId, domainId,
                    getCreatePharmacyAccountV1Request(adult13StoreNbr, adult13PatientId, adultDobDPFormat, "idVerification"),
                    adult13SetupReqId, adult13SetupReqTrackingId);
    if (adult13PharmacyAccountResponse.code() != 200) {
      throw new RuntimeException(
              "createPharmacyAccountV1 for adult13 (accountCreationSource=idVerification) failed — "
                      + "getAccountStatusV1WithTwoFAInactive (P15) setup incomplete. "
                      + "HttpStatusCode: " + adult13PharmacyAccountResponse.code());
    }

    // Post-setup for adult14 (P16): create pharmacy account with accountCreationSource="idVerification".
    // AccEn stores "idVerification" → getOnlineIdentity returns accountCreationSource="idVerification".
    // Non-OTP flow → no 2FA setup → getAccountVerification returns non-ACTIVE → twoFASetUpStatus=INACTIVE.
    String adult14SetupReqId = reqIdString + CommonUtil.randomUUID();
    String adult14SetupReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> adult14PharmacyAccountResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                    adult14CustomerAccountId, domainId,
                    getCreatePharmacyAccountV1Request(adult14StoreNbr, adult14PatientId, adultDobDPFormat, "idVerification"),
                    adult14SetupReqId, adult14SetupReqTrackingId);
    if (adult14PharmacyAccountResponse.code() != 200) {
      throw new RuntimeException(
              "createPharmacyAccountV1 for adult14 (accountCreationSource=idVerification) failed — "
                      + "getAccountStatusV1WithNullAccountCreationSourceDefaultsToIdVerification (P16) setup incomplete. "
                      + "HttpStatusCode: " + adult14PharmacyAccountResponse.code());
    }
  }

  private void createAllCPRAccount() throws IOException {
    cprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    cprPatientRequest.setStoreNbr(Integer.parseInt(commonStoreNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5));
    cprPatientRequest.getPatientInfo().setLastName(RandomStringUtils.randomAlphabetic(5));

    adult1HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult1HumanCprPatientRequest.getPatientInfo().setFirstName(adult1FirstName);
    adult1HumanCprPatientRequest.getPatientInfo().setLastName(adult1LastName);
    adult1HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult1StoreNbr));
    adult1HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult1PhoneNbr);
    adult1HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult2HumanCprPatientRequest.getPatientInfo().setFirstName(adult2FirstName);
    adult2HumanCprPatientRequest.getPatientInfo().setLastName(adult2LastName);
    adult2HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult2StoreNbr));
    adult2HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult2PhoneNbr);
    adult2HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    adult3HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult3HumanCprPatientRequest.getPatientInfo().setFirstName(adult3FirstName);
    adult3HumanCprPatientRequest.getPatientInfo().setLastName(adult3LastName);
    adult3HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult3StoreNbr));
    adult3HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult3PhoneNbr);
    adult3HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    adult4HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult4HumanCprPatientRequest.getPatientInfo().setFirstName(adult4FirstName);
    adult4HumanCprPatientRequest.getPatientInfo().setLastName(adult4LastName);
    adult4HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult4StoreNbr));
    adult4HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult4PhoneNbr);
    adult4HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    adult5HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult5HumanCprPatientRequest.getPatientInfo().setFirstName(adult5FirstName);
    adult5HumanCprPatientRequest.getPatientInfo().setLastName(adult5LastName);
    adult5HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult5StoreNbr));
    adult5HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult5PhoneNbr);
    adult5HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult5HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    adult6HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult6HumanCprPatientRequest.getPatientInfo().setFirstName(adult6FirstName);
    adult6HumanCprPatientRequest.getPatientInfo().setLastName(adult6LastName);
    adult6HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult6StoreNbr));
    // Explicit patientId so AccEn createPharmacyAccountV1 can look up the CPR patient by (storeNbr, patientId)
    adult6HumanCprPatientRequest.setPatientId(Integer.parseInt(adult6PatientId));
    adult6HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult6PhoneNbr);
    adult6HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult6HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    adult7HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult7HumanCprPatientRequest.getPatientInfo().setFirstName(adult7FirstName);
    adult7HumanCprPatientRequest.getPatientInfo().setLastName(adult7LastName);
    adult7HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult7StoreNbr));
    adult7HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult7PhoneNbr);
    adult7HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult7HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    // adult8: CPR patient at adult8StoreNbr; ISAC stage record (idVerified=false) will be created in post-setup
    adult8HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult8HumanCprPatientRequest.getPatientInfo().setFirstName(adult8FirstName);
    adult8HumanCprPatientRequest.getPatientInfo().setLastName(adult8LastName);
    adult8HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult8StoreNbr));
    adult8HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult8PhoneNbr);
    adult8HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    // adult9: CPR patient created at storeNbr=9928 with explicit patientId so AccEn createPharmacyAccountV1
    // can validate by (storeNbr=9928, patientId=adult9PatientId). Immediately soft-deleted (ONLINE_DEL) in
    // post-setup. NOTE: CPR ONLINE_DEL does NOT suppress GET — CPR still returns 200 with the patient record
    // → all patientLinks are CCM (storeNbr=9928) → P11 getAccountStatusV1 returns PARTIAL + CPR_LINK_PENDING.
    adult9HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult9HumanCprPatientRequest.getPatientInfo().setFirstName(adult9FirstName);
    adult9HumanCprPatientRequest.getPatientInfo().setLastName(adult9LastName);
    adult9HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult9StoreNbr));  // adult9StoreNbr = "9928"
    // Explicit patientId so AccEn createPharmacyAccountV1 can look up the CPR patient by (storeNbr=9928, patientId)
    adult9HumanCprPatientRequest.setPatientId(Integer.parseInt(adult9PatientId));
    adult9HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult9PhoneNbr);
    adult9HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    // adult10: CPR patient at adult10StoreNbr (random 6-digit non-CCM store).
    // AccEn pharmacy account is created at storeNbr=adult10StoreNbr (not 9928) so AccEn can validate by
    // (storeNbr=adult10StoreNbr, patientId=adult10PatientId).
    // GetAccountStatus: AccEn 200 (authStoreNbr=adult10StoreNbr, non-CCM) → CPR 200 (same non-CCM store) → ACTIVE.
    adult10HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult10HumanCprPatientRequest.getPatientInfo().setFirstName(adult10FirstName);
    adult10HumanCprPatientRequest.getPatientInfo().setLastName(adult10LastName);
    adult10HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult10StoreNbr));
    // Explicit patientId so AccEn createPharmacyAccountV1 can look up the CPR patient by (storeNbr, patientId)
    adult10HumanCprPatientRequest.setPatientId(Integer.parseInt(adult10PatientId));
    adult10HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult10PhoneNbr);
    adult10HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    // adult11 (P13): CPR patient registered at adult11NonCcmStoreNbr (random non-CCM) with explicit adult11PatientId.
    // A second CPR registration is created at storeNbr=9928 with the SAME adult11PatientId so AccEn can validate
    // createPharmacyAccountV1(storeNbr=9928, patientId=adult11PatientId).
    // When getAccountStatusV1 is called, CPR getPatientInfo returns patientLinks=[adult11NonCcmStoreNbr, 9928].
    // adult11NonCcmStoreNbr is NOT in CCM virtual store list → storeNbrFromCCM.size() < union.size() → ACTIVE.
    adult11HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult11HumanCprPatientRequest.getPatientInfo().setFirstName(adult11FirstName);
    adult11HumanCprPatientRequest.getPatientInfo().setLastName(adult11LastName);
    adult11HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult11NonCcmStoreNbr));
    // Explicit patientId shared with adult11Cpr9928PatientRequest — both registrations use the same patientId
    adult11HumanCprPatientRequest.setPatientId(Integer.parseInt(adult11PatientId));
    adult11HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult11PhoneNbr);
    adult11HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult11HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    // Second CPR registration for adult11: storeNbr=9928 with the same adult11PatientId.
    // This ensures AccEn's CPR validation succeeds when createPharmacyAccountV1 is called with storeNbr=9928.
    adult11Cpr9928PatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult11Cpr9928PatientRequest.getPatientInfo().setFirstName(adult11FirstName);
    adult11Cpr9928PatientRequest.getPatientInfo().setLastName(adult11LastName);
    adult11Cpr9928PatientRequest.setStoreNbr(9928);
    adult11Cpr9928PatientRequest.setPatientId(Integer.parseInt(adult11PatientId));
    adult11Cpr9928PatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult11PhoneNbr);
    adult11Cpr9928PatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult11Cpr9928PatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    // adult12 (P14 — linkExpired): CPR patient at adult12StoreNbr; no pharmacy account.
    // ISAC stage record is created in P14 test body. The link-expired branch fires when
    // isacIdVerificationLinkActiveDurationInMonths=0 (or record is backdated in a supported env).
    adult12HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult12HumanCprPatientRequest.getPatientInfo().setFirstName(adult12FirstName);
    adult12HumanCprPatientRequest.getPatientInfo().setLastName(adult12LastName);
    adult12HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult12StoreNbr));
    adult12HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult12PhoneNbr);
    adult12HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);

    // adult13 (P15 — twoFASetUpStatus=INACTIVE): CPR patient at adult13StoreNbr (random non-CCM).
    // Pharmacy account created in @BeforeClass with accountCreationSource="idVerification" (non-OTP flow).
    // Expected: AccEn getAccountVerification returns twoFASetUp as not ACTIVE → twoFASetUpStatus=INACTIVE.
    adult13HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult13HumanCprPatientRequest.getPatientInfo().setFirstName(adult13FirstName);
    adult13HumanCprPatientRequest.getPatientInfo().setLastName(adult13LastName);
    adult13HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult13StoreNbr));
    adult13HumanCprPatientRequest.setPatientId(Integer.parseInt(adult13PatientId));
    adult13HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult13PhoneNbr);
    adult13HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult13HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    // adult14 (P16 — accountCreationSource=idVerification): CPR patient at adult14StoreNbr (random non-CCM).
    // Pharmacy account created with accountCreationSource="idVerification" (non-OTP flow, no 2FA setup).
    adult14HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult14HumanCprPatientRequest.getPatientInfo().setFirstName(adult14FirstName);
    adult14HumanCprPatientRequest.getPatientInfo().setLastName(adult14LastName);
    adult14HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult14StoreNbr));
    adult14HumanCprPatientRequest.setPatientId(Integer.parseInt(adult14PatientId));
    adult14HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult14PhoneNbr);
    adult14HumanCprPatientRequest.getPatientInfo().setBirthDate(adultDobCPRFormat);
    adult14HumanCprPatientRequest.getPatientAddressInfo().get(0).setZipCode(postalCode);

    cprAdult1HumanPatientId = SharedUtils.createCprAccount(adult1HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult2HumanPatientId = SharedUtils.createCprAccount(adult2HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult3HumanPatientId = SharedUtils.createCprAccount(adult3HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult4HumanPatientId = SharedUtils.createCprAccount(adult4HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult5HumanPatientId = SharedUtils.createCprAccount(adult5HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult6HumanPatientId = SharedUtils.createCprAccount(adult6HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult7HumanPatientId = SharedUtils.createCprAccount(adult7HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult8HumanPatientId = SharedUtils.createCprAccount(adult8HumanCprPatientRequest, cprPatientUpdateRetrofit);
    // adult9: created here; will be immediately soft-deleted in post-setup — NOT in cprProfilesToBeDeletedList
    cprAdult9HumanPatientId = SharedUtils.createCprAccount(adult9HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult10HumanPatientId = SharedUtils.createCprAccount(adult10HumanCprPatientRequest, cprPatientUpdateRetrofit);
    // adult11: two CPR registrations with the same patientId — non-CCM store + storeNbr=9928
    cprAdult11NonCcmPatientId = SharedUtils.createCprAccount(adult11HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult11At9928PatientId = SharedUtils.createCprAccount(adult11Cpr9928PatientRequest, cprPatientUpdateRetrofit);
    cprAdult12HumanPatientId = SharedUtils.createCprAccount(adult12HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult13HumanPatientId = SharedUtils.createCprAccount(adult13HumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdult14HumanPatientId = SharedUtils.createCprAccount(adult14HumanCprPatientRequest, cprPatientUpdateRetrofit);

    cprProfilesToBeDeletedList.add(cprPatientRequest);
    cprProfilesToBeDeletedList.add(adult1HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult2HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult3HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult4HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult5HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult6HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult7HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult8HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult10HumanCprPatientRequest);
    // adult11: both CPR registrations must be cleaned up
    cprProfilesToBeDeletedList.add(adult11HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult11Cpr9928PatientRequest);
    cprProfilesToBeDeletedList.add(adult12HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult13HumanCprPatientRequest);
    cprProfilesToBeDeletedList.add(adult14HumanCprPatientRequest);

    try {
      Thread.sleep(50000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createAllCAAccount() throws Exception {
    commonCustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(commonCustomerEmailId);
    adult1CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult1EmailId);
    adult2CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult2EmailId);
    adult3CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult3EmailId);
    adult4CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult4EmailId);
    adult5CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult5EmailId);
    adult6CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult6EmailId);
    adult7CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult7EmailId);
    // adult8: CA account; ISAC stage record with idVerified=false will be created in post-setup
    adult8CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult8EmailId);
    // adult9: CA account; pharmacy account with real CPR patientId (then CPR soft-deleted) created in post-setup
    adult9CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult9EmailId);
    // adult10: CA account; pharmacy account with storeNbr=adult10StoreNbr (non-CCM) and adult10PatientId created in post-setup
    adult10CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult10EmailId);
    // adult11: CA account; pharmacy account at storeNbr=9928 with adult11PatientId created in post-setup (P13)
    adult11CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult11EmailId);
    // adult12: CA account only; no pharmacy account — ISAC stage record created in P14 test body
    adult12CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult12EmailId);
    // adult13: CA account; pharmacy account with accountCreationSource="idVerification" created in post-setup (P15)
    adult13CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult13EmailId);
    // adult14: CA account; pharmacy account with accountCreationSource="idVerification" created in post-setup (P16)
    adult14CustomerAccountId = createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult14EmailId);
  }

  /**
   * Request builder, CA CreatePersonRequest
   *
   * @param emailAddress
   * @return
   */
  private CACreatePersonRequest getCACreatePersonRequest(String emailAddress) {
    java.util.List<CACreatePersonRequest.Accounts> accountsList = new ArrayList<>();
    accountsList.add(
        CACreatePersonRequest.Accounts.builder()
            .accountType("INDIVIDUAL")
            .emailAddress(emailAddress)
            .build());
    return CACreatePersonRequest.builder()
        .payload(
            CACreatePersonRequest.CreatePersonRequestPayload.builder()
                .person(CACreatePersonRequest.Person.builder().accounts(accountsList).build())
                .build())
        .build();
  }

  /**
   * Updated the idVerificationSource through DR Service
   *
   * @param customerId
   * @return
   * @throws IOException
   */
  private UpdateIdVerificationResponse createIdVerificationInDrService(String customerId, String firstName, String lastName, String postalCode)
          throws IOException {
    UpdateIdVerificationRequest updateIdVerificationRequest =
            UpdateIdVerificationRequest.builder()
                    .payload(
                            UpdateIdVerificationRequest.UpdateIdVerificationRequestPayload.builder()
                                    .customerId(customerId)
                                    .idVerificationSource("EXPERIAN")
                                    .idValidated(Boolean.TRUE.toString())
                                    .personName(UpdateIdVerificationRequest.PersonName.builder()
                                            .firstName(firstName)
                                            .lastName(lastName)
                                            .build())
                                    .postalAddress(UpdateIdVerificationRequest.PostalAddress.builder()
                                            .addressLineOne("927 E 15th St")
                                            .city("FAIRBANKS")
                                            .stateOrProvinceCode("AK")
                                            .countryCode("USA")
                                            .postalCode(postalCode)
                                            .build())
                                    .photoId(UpdateIdVerificationRequest.PhotoId.builder()
                                            .photoIdType("DRV")
                                            .photoIdNumber("90808567456567")
                                            .photoIdState("AR")
                                            .photoIdCountry("US")
                                            .photoIdExpirationDate("06-22-2021")
                                            .build())
                                    .build())
                    .build();
    Response<UpdateIdVerificationResponse> response = null;

    for (int i = 0; i < 3; i++) {
      response = drRetrofit.updateIdVerification(updateIdVerificationRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !"OK".equals(response.body().getStatus())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "dr UpdateIdVerification failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }

    return response.body();
  }

  @AfterClass
  void cleanUp() throws IOException {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account

    cprProfilesToBeDeletedList.forEach(
        request -> {
          request.getPatientInfo().setPatientStatusCode(20708);
          try {
            Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(request);
            if (!(response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty())) {
              throw new RuntimeException(
                  "CPR Account failed to update with status code 20708 for PatientId "
                      + commonPatientId
                      + " . HttpStatusCode : "
                      + response.code());
            }
          } catch (IOException e) {
          }
        });
  }

  @Test(
      priority = 0,
      description = "Get Account Status success case for ISAC flow with IdVerified as true")
  public void getAccountStatusV1IsacIdVerifiedTrue() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult3CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Creating idVerification
    adult3StageId = isacHelper.saveIsacIdVerification(adult3StoreNbr, cprAdult3HumanPatientId, adult3EmailId, reqId, reqTrackingId);

    // Step - 3: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
                adult3CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
            GetAccountStatusV1Response.class);

    // Step - 7: Asserting response
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
        getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getTwoFASetUpStatus(),
        "TwoFASetUpStatus was expected to be null");
    Assert.assertTrue(
        getAccountStatusV1Response.getIdVerified().isStatus(), "Status was expected to be true");
    Assert.assertEquals(
        getAccountStatusV1Response.getIdVerified().getLastVerificationSource(), "STORE");
    Assert.assertNull(
        getAccountStatusV1Response.getAccountCreationSource(),
        "AccountCreationSource was expected to be null");
    Assert.assertNotNull(
        getAccountStatusV1Response.getIdVerified().getAttribute(),
        "IdVerified attribute was expected to be non-null");
    Assert.assertEquals(
        getAccountStatusV1Response.getIdVerified().getAttribute().getStageId(), adult3StageId,
        "StageId in idVerified attribute did not match expected value");
  }

  @Test(
      priority = 1,
      description = "Get Account Status success case for ISAC flow with IdVerified as false")
  public void getAccountStatusV1IsacIdVerifiedFalse() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
                commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
            GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
        getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getTwoFASetUpStatus(),
        "TwoFASetUpStatus was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getIdVerified(), "IdVerified was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getAccountCreationSource(),
        "AccountCreationSource was expected to be null");
  }

  @Test(
      priority = 2,
      description =
          "Get Account Status ISAC flow with idVerified=false")
  public void getAccountStatusV1IsacIdVerifiedFalseWithStageRecord() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult8CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
                adult8CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
            GetAccountStatusV1Response.class);

    // Step - 6: Asserting common fields (account NOT_CREATED, no pharmacy account)
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
        getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getTwoFASetUpStatus(),
        "TwoFASetUpStatus was expected to be null");
    Assert.assertNull(
        getAccountStatusV1Response.getAccountCreationSource(),
        "AccountCreationSource was expected to be null");

    // Step - 7: Branch-aware idVerified assertion
      Assert.assertFalse(
          getAccountStatusV1Response.getIdVerified().isStatus(),
          "IdVerified status was expected to be false for ISAC stage record with idVerified=false");
      Assert.assertNull(
          getAccountStatusV1Response.getIdVerified().getLastVerificationSource(),
          "LastVerificationSource was expected to be null when idVerified=false");
      Assert.assertNotNull(
          getAccountStatusV1Response.getIdVerified().getAttribute(),
          "IdVerified attribute was expected to be non-null");
      Assert.assertEquals(
          getAccountStatusV1Response.getIdVerified().getAttribute().getStageId(), adult8StageId);
  }

  @Test(priority = 3, description = "Get Account Status 400 error due to invalid domain id")
  public void getAccountStatusV1InvalidDomainId() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
                commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getAccountStatusV1APIResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", invalidDomainId));
  }

  @Test(
      priority = 4,
      description =
          "Get Account Status 404 error from CA get person by customerAccountId API after GetOnlineIdentityV1API gives 204 for the given customerAccountId")
  public void getAccountStatusV1404FromCAGetPerson() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
            customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getAccountStatusV1APIResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 404, errorMessage);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertTrue(
            errorResponse.getMessage().contains("No information found for given customerAccountId")
    );
  }

  @Test(
          priority = 5,
          description =
                  "Get Account Status success case for account creation source idVerification")
  public void getAccountStatusV1ForAccountCreationSourceIdVerification() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Create IsacIdVerification for adult 1
    adult1StageId = isacHelper.saveIsacIdVerification(adult1StoreNbr, cprAdult1HumanPatientId, adult1EmailId, reqId, reqTrackingId);

    // Step - 3: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult1CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 5: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 7: Asserting response
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(getAccountStatusV1Response.getTwoFASetUpStatus(), "TwoFASetUpStatus was expected to be null");
    Assert.assertTrue(
            getAccountStatusV1Response.getIdVerified().isStatus(), "Status was expected to be true");
    Assert.assertEquals(
            getAccountStatusV1Response.getIdVerified().getLastVerificationSource(), "STORE");
    Assert.assertNotNull(getAccountStatusV1Response.getIdVerified().getAttribute());
    Assert.assertEquals(getAccountStatusV1Response.getIdVerified().getAttribute().getStageId(), adult1StageId);
    Assert.assertNull(getAccountStatusV1Response.getAccountCreationSource(), "AccountCreationSource was expected to be null");
  }

  @Test(
          priority = 6,
          description =
                  "Get Account Status with DOB retries exhausted")
  public void getAccountStatusV1WithDbRetriesExhaustedCase() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult2CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Create ISAC stage record for adult2 with isIdVerified=false (createStageIsacRecord).
    adult2StageId = createStageIsacRecord(adult2StoreNbr, cprAdult2HumanPatientId, adult2EmailId, adultDobDPFormat, reqId, reqTrackingId);

    // Step - 3: Calling createAccountByIsac three times with incorrect dob to exceed dobRetries
    CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request = getCreateAccountByISACInfoV1Request(adult2StageId, adultWrongDobDPFormat);

    for(int i = 0; i < 3; i++){
      accountOrchestratorRetrofit.createAccountByISACInfoV1(adult2CustomerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);
    }

    // Step - 4: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult2CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 6: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 7: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 8: Asserting response
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(getAccountStatusV1Response.getTwoFASetUpStatus(), "TwoFASetUpStatus was expected to be null");

      Assert.assertFalse(
              getAccountStatusV1Response.getIdVerified().isStatus(),
              "IdVerified status was expected to be false when DOB retries are exhausted");
      Assert.assertNull(
              getAccountStatusV1Response.getIdVerified().getLastVerificationSource(),
              "LastVerificationSource was expected to be null when retries exhausted and idVerified=false");
      Assert.assertNotNull(
              getAccountStatusV1Response.getIdVerified().getAttribute(),
              "IdVerified attribute was expected to be non-null");
      Assert.assertEquals(
              getAccountStatusV1Response.getIdVerified().getAttribute().getStageId(), adult2StageId,
              "StageId in idVerified attribute did not match the stage created in the test body");


    Assert.assertNull(getAccountStatusV1Response.getAccountCreationSource(), "AccountCreationSource was expected to be null");
  }

  @Test(
          priority = 7,
          description =
                  "Get Account Status response when account created by isac")
  public void getAccountStatusV1WithAccountCreatedByIsac() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult4CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Create IsacIdVerification for adult4
    adult4StageId = isacHelper.saveIsacIdVerification(adult4StoreNbr, cprAdult4HumanPatientId, adult4EmailId, reqId, reqTrackingId);

    // Step - 3: Calling createAccountByIsac
    CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request = getCreateAccountByISACInfoV1Request(adult4StageId, adultDobDPFormat);
    accountOrchestratorRetrofit.createAccountByISACInfoV1(adult4CustomerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult4CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertEquals(getAccountStatusV1Response.getTwoFASetUpStatus(), "ACTIVE");
    Assert.assertNull(getAccountStatusV1Response.getIdVerified());
    Assert.assertEquals(getAccountStatusV1Response.getAccountCreationSource(), "associateVerificationStore");
  }

  @Test(
          priority = 8,
          description =
                  "Get Account Status response when account created by patient info")
  public void getAccountStatusV1WithAccountCreatedByPatientInfo() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult5CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult5CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertNull(getAccountStatusV1Response.getTwoFASetUpStatus());
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified());
    Assert.assertNull(getAccountStatusV1Response.getAccountCreationSource());
  }

  @Test(
          priority = 9,
          description =
                  "Get Account Status response when account created with smsOtpVerification")
  public void getAccountStatusV1WithAccountCreatedWithSmsOtpVerification() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    // adult6 pharmacy account was created in @BeforeClass so AccEn has had time to propagate it.
    // Calling createPharmacyAccountV1 inline (immediately before getAccountStatusV1) caused AccEn's
    // getOnlineIdentity to return 204 due to propagation delay → NOT_CREATED instead of ACTIVE.
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult6CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    // AccEn getOnlineIdentity returns 200 (authStoreNbr=adult6StoreNbr, random non-CCM) → ACTIVE
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult6CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting desired responses
    // AccEn 200 (authStoreNbr=adult6StoreNbr, non-CCM) → authStoreNbr != 9928 → ACTIVE
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE",
            "Account status was expected to be ACTIVE when AccEn returns authStoreNbr != 9928");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(), "Code was expected to be null");
    Assert.assertEquals(getAccountStatusV1Response.getTwoFASetUpStatus(), "ACTIVE");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(), "IdVerified was expected to be null");
    Assert.assertEquals(getAccountStatusV1Response.getAccountCreationSource(), "smsOtpVerification");
  }

  @Test(
          priority = 10,
          description =
                  "Get Account Status response when 9928 profile created in cpr and account created with isac")
  public void getAccountStatusV1With9928ProfileCreatedWithCprAndAccountCreatedWithISAC() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult7CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Create IsacIdVerification for adult7
    adult7StageId = isacHelper.saveIsacIdVerification(adult7StoreNbr, cprAdult7HumanPatientId, adult7EmailId, reqId, reqTrackingId);

    // Step - 3: Calling createAccountByIsac
    CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request = getCreateAccountByISACInfoV1Request(adult7StageId, adultDobDPFormat);
    accountOrchestratorRetrofit.createAccountByISACInfoV1(adult7CustomerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult7CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountStatusV1Response.getAccount().getStatus(), "PARTIAL");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getCode(), "CPR_LINK_PENDING");
    Assert.assertEquals(getAccountStatusV1Response.getTwoFASetUpStatus(), "ACTIVE");
    Assert.assertNull(getAccountStatusV1Response.getIdVerified());
    Assert.assertEquals(getAccountStatusV1Response.getAccountCreationSource(), "associateVerificationStore");
  }

  @Test(
          priority = 11,
          description =
                  "Get Account Status PARTIAL + CPR_PROFILE_NOT_CREATED when AccEn returns authStoreNbr=9928 "
                          + "and the soft-deleted CPR patient at storeNbr=9928 still returns 200 (CPR ONLINE_DEL "
                          + "status does not suppress the record — all CPR links are CCM → CPR_PROFILE_NOT_CREATED)")
  public void getAccountStatusV1WithCprProfileNotCreated() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    // adult9 has a pharmacy account created in @BeforeClass with storeNbr=9928 and adult9PatientId.
    // The CPR patient was created at storeNbr=9928 and then soft-deleted (patientStatusCode=20708).
    // CPR ONLINE_DEL status does NOT cause CPR to return 204 — CPR still returns 200 with the patient
    // record (including storeNbr=9928 in patientLinks). Since 9928 is a CCM store, all CPR links are
    // CCM virtual stores → service returns PARTIAL + CPR_LINK_PENDING.
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult9CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult9CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    // AccEn 200 (authStoreNbr=9928, adult9PatientId) → CPR 200 (patient at storeNbr=9928, ONLINE_DEL
    // status does not suppress GET) → patientLinks=[9928] → all CCM → PARTIAL + CPR_PROFILE_NOT_CREATED
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "PARTIAL",
            "Account status was expected to be PARTIAL when authStoreNbr=9928 and CPR links are all CCM");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getCode(), "CPR_PROFILE_NOT_CREATED",
            "Account code was expected to be CPR_PROFILE_NOT_CREATED when CPR returns 204 with only CCM store links");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(), "IdVerified was expected to be null for PARTIAL account");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccountCreationSource(), "smsOtpVerification",
            "AccountCreationSource was expected to be smsOtpVerification");
  }

  @Test(
          priority = 12,
          description =
                  "Get Account Status ACTIVE when AccEn authStoreNbr is a random non-CCM store "
                          + "and CPR patient is at the same non-CCM store → ACTIVE")
  public void getAccountStatusV1With9928AccountAndCprStoreNotInCCMList() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    // adult10 has a pharmacy account created in @BeforeClass with storeNbr=adult10StoreNbr (random non-CCM)
    // and adult10PatientId. The CPR patient is also at adult10StoreNbr (non-CCM store).
    // GetAccountStatus: AccEn returns 200 (authStoreNbr=adult10StoreNbr, non-CCM) → ACTIVE.
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult10CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult10CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    // AccEn 200 (authStoreNbr=adult10StoreNbr, non-CCM store) → CPR getPatientInfo 200
    // CPR patient at adult10StoreNbr which is NOT in CCM virtual store list → ACTIVE
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE",
            "Account status was expected to be ACTIVE when CPR storeNbr is not in the CCM virtual store list");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(),
            "Account code was expected to be null for ACTIVE status");
    Assert.assertNotNull(
            getAccountStatusV1Response.getTwoFASetUpStatus(),
            "TwoFASetUpStatus was expected to be non-null for an ACTIVE account");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(), "IdVerified was expected to be null for ACTIVE account");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccountCreationSource(), "smsOtpVerification",
            "AccountCreationSource was expected to be smsOtpVerification");
  }

  @Test(
          priority = 13,
          description =
                  "Get Account Status ACTIVE when AccEn authStoreNbr=9928 AND CPR getPatientInfo returns 200 "
                          + "with patientLinks containing a non-CCM store → storeNbrFromCCM.size() < union.size() → ACTIVE "
                          + "with async AccEn updateAccount triggered")
  public void getAccountStatusV1With9928AccountAndNonCcmCprStoreActive() throws IOException {
    // adult11 has a pharmacy account at storeNbr=9928 (created in @BeforeClass with adult11PatientId).
    // CPR has adult11 registered at BOTH adult11NonCcmStoreNbr (random non-CCM) AND storeNbr=9928.
    // The dual CPR registration ensures:
    //   1. AccEn can validate createPharmacyAccountV1(storeNbr=9928, patientId=adult11PatientId) → 200.
    //   2. CPR getPatientInfo returns patientLinks=[adult11NonCcmStoreNbr, 9928].
    //      adult11NonCcmStoreNbr ∉ CCM virtual store list → storeNbrFromCCM.size() < union.size() → ACTIVE.
    // Step - 1: Setting and logging tracking IDs
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult11CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API to fetch the account
    // AccEn getOnlineIdentity returns 200 (authStoreNbr=9928) → service calls CPR getPatientInfo(adult11PatientId)
    // → CPR 200 (patientLinks has adult11NonCcmStoreNbr ∉ CCM) → ACTIVE + async AccEn update
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult11CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    // authStoreNbr=9928 → CPR 200 with non-CCM store in patientLinks → storeNbrFromCCM.size() < union.size() → ACTIVE
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE",
            "Account status was expected to be ACTIVE when authStoreNbr=9928 "
                    + "and CPR patientLinks contain a non-CCM store");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(),
            "Account code was expected to be null for ACTIVE status");
    Assert.assertNotNull(
            getAccountStatusV1Response.getTwoFASetUpStatus(),
            "TwoFASetUpStatus was expected to be non-null for an ACTIVE account");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(),
            "IdVerified was expected to be null for ACTIVE account");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccountCreationSource(), "smsOtpVerification",
            "AccountCreationSource was expected to be smsOtpVerification");
  }

  /**
   * P14 — ISAC stage record (isIdVerified=false), no pharmacy account.
   * AccEn 204 → CA 200 → ISAC 200 → NOT_CREATED.
   *
   * <p>idVerified in the response depends on two CCM flags:
   * <ul>
   *   <li>When {@code isacIdVerificationLinkActiveDurationInMonths=0}: linkExpired=true →
   *       idVerified=null regardless of {@code isIsacAssociateTriggeredAccountCreationEnabled}.</li>
   *   <li>When {@code linkActiveDurationInMonths > 0} (link NOT expired) and
   *       {@code isIsacAssociateTriggeredAccountCreationEnabled=true}: idVerified={status=false, stageId}.</li>
   *   <li>When {@code linkActiveDurationInMonths > 0} and
   *       {@code isIsacAssociateTriggeredAccountCreationEnabled=false}: idVerified=null.</li>
   * </ul>
   * The assertion is branch-aware and passes in all three configurations.
   */
  @Test(
          priority = 14,
          description =
                  "Get Account Status NOT_CREATED for ISAC stage record (isIdVerified=false) with no pharmacy account. "
                          + "idVerified is null when link is expired or CCM flag is off; "
                          + "idVerified={status=false, stageId} when link is active and CCM flag is on.")
  public void getAccountStatusV1WithIsacLinkExpired() throws IOException {
    // adult12 has a CA account + CPR patient (no pharmacy account).
    // ISAC stage record is created here in the test body (isIdVerified=false, lastEmailSentTs=now).
    // account.status is always NOT_CREATED; idVerified varies by CCM flags (see Javadoc above).
    // Step - 1: Setting and logging tracking IDs
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult12CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Create ISAC stage record for adult12 with isIdVerified=false
    // lastEmailSentTs is set to now by the ISAC service.
    adult12StageId = createStageIsacRecord(
            adult12StoreNbr, cprAdult12HumanPatientId, adult12EmailId,
            adultDobDPFormat, reqId, reqTrackingId);

    // Step - 3: calling the getAccountStatusV1 orchestrator API
    // Flow: AccEn 204 (no pharmacy account) → CA 200 → ISAC 200 → NOT_CREATED
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult12CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 5: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 7: Asserting response
    // account.status=NOT_CREATED and twoFASetUpStatus=null are always true (no pharmacy account).
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "NOT_CREATED",
            "Account status was expected to be NOT_CREATED (no pharmacy account for adult12)");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(),
            "Account code was expected to be null for NOT_CREATED status");
    Assert.assertNull(
            getAccountStatusV1Response.getTwoFASetUpStatus(),
            "TwoFASetUpStatus was expected to be null when account is NOT_CREATED");
    Assert.assertNull(
            getAccountStatusV1Response.getAccountCreationSource(),
            "AccountCreationSource was expected to be null for NOT_CREATED account");

      Assert.assertFalse(
              getAccountStatusV1Response.getIdVerified().isStatus(),
              "IdVerified status was expected to be false for ISAC stage record with isIdVerified=false");
      Assert.assertNull(
              getAccountStatusV1Response.getIdVerified().getLastVerificationSource(),
              "LastVerificationSource was expected to be null when idVerified=false");
      Assert.assertNotNull(
              getAccountStatusV1Response.getIdVerified().getAttribute(),
              "IdVerified attribute was expected to be non-null");
      Assert.assertEquals(
              getAccountStatusV1Response.getIdVerified().getAttribute().getStageId(), adult12StageId,
              "StageId in idVerified attribute did not match the stage created in the test body");
    }

  @Test(
          priority = 15,
          description =
                  "Get Account Status ACTIVE with twoFASetUpStatus=INACTIVE when pharmacy account was "
                          + "created via idVerification flow (accountCreationSource=idVerification) without SMS OTP 2FA setup")
  public void getAccountStatusV1WithTwoFAInactive() throws IOException {
    // adult13 has a pharmacy account created in @BeforeClass with accountCreationSource="idVerification".
    // The idVerification flow does not involve SMS OTP verification, so AccEn's getAccountVerification
    // should return twoFASetUp as null or a non-ACTIVE status → twoFASetUpStatus=INACTIVE.
    // Step - 1: Setting and logging tracking IDs
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult13CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API
    // AccEn getOnlineIdentity returns 200 (authStoreNbr=adult13StoreNbr, non-CCM) → ACTIVE
    // getAccountVerification: twoFASetUp not ACTIVE (no OTP was done) → twoFASetUpStatus=INACTIVE
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult13CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    // AccEn 200 (authStoreNbr=adult13StoreNbr, non-CCM) → ACTIVE
    // twoFASetUpStatus=INACTIVE because accountCreationSource=idVerification did not trigger OTP/2FA setup
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE",
            "Account status was expected to be ACTIVE for an account created via idVerification flow");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(),
            "Account code was expected to be null for ACTIVE status");
    Assert.assertEquals(
            getAccountStatusV1Response.getTwoFASetUpStatus(), "INACTIVE",
            "TwoFASetUpStatus was expected to be INACTIVE when pharmacy account was created "
                    + "via idVerification flow without OTP 2FA setup");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(),
            "IdVerified was expected to be null for ACTIVE account");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccountCreationSource(), "idVerification",
            "AccountCreationSource was expected to be idVerification");
  }

  @Test(
          priority = 16,
          description =
                  "Get Account Status ACTIVE with accountCreationSource=idVerification when pharmacy account "
                          + "was created via idVerification flow (non-OTP, no 2FA setup) at a random non-CCM store")
  public void getAccountStatusV1WithNullAccountCreationSourceDefaultsToIdVerification() throws IOException {
    // adult14 has a pharmacy account created in @BeforeClass with accountCreationSource="idVerification".
    // Non-OTP flow → AccEn does not set up 2FA → getAccountVerification returns non-ACTIVE → twoFASetUpStatus=INACTIVE.
    // Step - 1: Setting and logging tracking IDs
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(adult14CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountStatusV1 orchestrator API
    // AccEn getOnlineIdentity returns 200 (authStoreNbr=adult14StoreNbr, non-CCM) → ACTIVE
    // accountCreationSource="idVerification" stored by AccEn → returned as-is in response
    Response<ServiceResponse> getAccountStatusV1APIResponse =
            accountOrchestratorRetrofit.getAccountStatusV1(
                    adult14CustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 4: Asserting HTTP response code
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 5: Parsing the response
    GetAccountStatusV1Response getAccountStatusV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
                    GetAccountStatusV1Response.class);

    // Step - 6: Asserting response
    // AccEn 200 (authStoreNbr=adult14StoreNbr, non-CCM) → ACTIVE
    // accountCreationSource="idVerification" stored and returned by AccEn
    Assert.assertEquals(
            getAccountStatusV1Response.getAccount().getStatus(), "ACTIVE",
            "Account status was expected to be ACTIVE");
    Assert.assertNull(
            getAccountStatusV1Response.getAccount().getCode(),
            "Account code was expected to be null for ACTIVE status");
    Assert.assertEquals(
            getAccountStatusV1Response.getTwoFASetUpStatus(), "INACTIVE",
            "TwoFASetUpStatus was expected to be INACTIVE for idVerification (non-OTP) flow");
    Assert.assertNull(
            getAccountStatusV1Response.getIdVerified(),
            "IdVerified was expected to be null for ACTIVE account");
    Assert.assertEquals(
            getAccountStatusV1Response.getAccountCreationSource(), "idVerification",
            "AccountCreationSource was expected to be idVerification");
  }

  private CreateAccountByISACInfoV1Request getCreateAccountByISACInfoV1Request(String stageId, String dob) {
    return CreateAccountByISACInfoV1Request.builder()
                    .dob(dob)
                    .stageId(stageId)
                    .tAndCPolicyLanguage("EN")
                    .build();
  }

  /**
   * Builds an AccEn createPharmacyAccountV1 request using the class-level accountCreationSource ("smsOtpVerification").
   *
   * @param storeNbr  pharmacy store number
   * @param patientId CPR patient ID
   * @param dob       date of birth in MMddyyyy format
   * @return CreatePharmacyAccountV1Request
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String storeNbr, String patientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(storeNbr)
                            .patientId(patientId)
                            .dob(dob)
                            .build())
            .build();
  }

  /**
   * Builds an AccEn createPharmacyAccountV1 request with an explicit accountCreationSource.
   * Use this overload when you need a source other than the class-level "smsOtpVerification" — e.g.
   * "idVerification" (P15 — twoFASetUpStatus=INACTIVE) or {@code null} (P16 — ID_VERIFICATION default).
   *
   * @param storeNbr  pharmacy store number
   * @param patientId CPR patient ID
   * @param dob       date of birth in MMddyyyy format
   * @param source    accountCreationSource value; may be {@code null}
   * @return CreatePharmacyAccountV1Request
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String storeNbr, String patientId, String dob, String source) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(source)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(storeNbr)
                            .patientId(patientId)
                            .dob(dob)
                            .build())
            .build();
  }

  public String createStageIsacRecord(
      String storeNbr,
      Integer cprPatientId,
      String emailId,
      String dob,
      String reqId,
      String reqTrackingId) throws IOException {

    AccountOrchestratorRetrofit accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();

    CreateStageISACRecordV1Request request = CreateStageISACRecordV1Request.builder()
        .storeNbr(storeNbr)
        .patientId(String.valueOf(cprPatientId))
        .emailId(emailId)
        .dob(dob)
        .idVerified(Boolean.FALSE)
        .build();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createStageIsacRecordV1(
            domainId,
            request,
            reqId,
            reqTrackingId);

    if (response.body() == null || response.body().getPayload() == null) {
      throw new RuntimeException(
          "createStageIsacRecord failed — null payload. HTTP " + response.code()
              + (response.errorBody() != null ? " body=" + response.errorBody().string() : ""));
    }

    @SuppressWarnings("unchecked")
    LinkedTreeMap<String, Object> payload =
        (LinkedTreeMap<String, Object>) response.body().getPayload();

    String stageId = (String) payload.get("stageId");
    if (stageId == null || stageId.isBlank()) {
      throw new RuntimeException(
          "createStageIsacRecord succeeded (HTTP " + response.code()
              + ") but stageId is absent in response payload: " + payload);
    }
    return stageId;
  }

}
