package accountorchestrator.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetsmsEnrolledProfilelListByPhoneNbrResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.GetsmsEnrolledProfilelListByPhoneNbrErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.restapi.DMStageIDRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import accountorchestrator.utils.CommonAccountHelper;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CreateAccountByPatientIdV1Request;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.SMSEnrolledProfileListV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.request.PharmaAuthPatientIdStoreNbrRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.eclipse.jetty.http.HttpStatus;
import org.jetbrains.annotations.NotNull;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Set;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.createSMSEnrollmentOrUnenroll;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.getDmPostPreferencesRequest;

public class AccountOrchestratorGetSMSEnrolledProfileListV1FlowTestCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private AccountOrchestratorWrapper accountOrchestratorWrapper;
  private DMStageIDRetrofit dmStageIDRetrofit;

  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private final String domainId = "WM-PHARMACY";
  private final  String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId;
  private String flowAdultDobIso;
  private String flowAdultDobMmDdYyyy;
  private String customerAccountId;
  ValidationServiceRequest adultHumanCprPatientRequest = null,
      minorHumanCprPatientRequest,
      petCprPatientRequest;
  private PharmaAuthPatientIdStoreNbrRequest pharmaAuthPatientIdStoreNbrRequest;

  private String wmCoveragePhoneNumber;
  private Integer wmCoverageAdultPatientId;
  private Integer wmCoverageMinorPatientId;
  private String wmCaregiverAccountId;
  private ValidationServiceRequest wmCoverageAdultCprRequest;
  private ValidationServiceRequest wmCoverageMinorCprRequest;

  private String samsAccountId;
  private String samsPhoneNumber;
  private Integer samsPatientId;
  private final String samsDomainId = "SAMS-PHARMACY";
  private final String samsStoreNbr = "5596";

  private static final DateTimeFormatter FMT_MMDDYYYY = DateTimeFormatter.ofPattern("MMddyyyy");

  private static final String DM_SMS_NOTIFY_TYPE   = "1";      // "1" = phone / SMS channel
  private static final String DM_SMS_ENROLL_STATUS = "26805";  // DM enrollment status code

  private static final String STAGE_ID_TYPE_IMZ_RECOMM = "IMZ_RECOMM";
  private static final String REF_TYPE_REFILL_SMS       = "refill-confirmation-sms";
  private static final String REF_TYPE_CI_IMZ_RECO      = "ci-imz-reco";

  private static final String CPR_PATIENT_TYPE_HUMAN = "HUMAN";
  private static final String CPR_GENDER_MALE        = "M";


  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    pharmacyAuthServiceRetrofit =  new PharmacyAuthServiceRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    dmStageIDRetrofit = new DMStageIDRetrofit();
    accountOrchestratorWrapper = new AccountOrchestratorWrapper();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    wmCoveragePhoneNumber = CommonUtil.generateRandomNumber(10);
    LocalDate wmAdultDob      = LocalDate.now().minusYears(38);
    String wmAdultDobIso      = wmAdultDob.format(DateTimeFormatter.ISO_LOCAL_DATE); // YYYY-MM-DD
    String wmAdultDobMmDdYyyy = wmAdultDob.format(FMT_MMDDYYYY);                    // MMDDYYYY
    wmCaregiverAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName(wmAdultDobIso);
    customerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName(wmAdultDobIso);

    wmCoverageAdultCprRequest = SharedUtils.getTemplateCprRequest(mapper);
    wmCoverageAdultCprRequest.getPatientInfo().setFirstName(CommonUtil.randomUUID().replace("-", "").substring(0, 6).toUpperCase());
    wmCoverageAdultCprRequest.getPatientInfo().setLastName(CommonUtil.randomUUID().replace("-", "").substring(0, 6).toUpperCase());
    wmCoverageAdultCprRequest.getPatientInfo().setBirthDate(wmAdultDobIso);
    wmCoverageAdultCprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    wmCoverageAdultCprRequest.getPatientCommunicationInfo().get(0).setCommunicationId(CommonUtil.generateRandomNumber(10));
    wmCoverageAdultPatientId = SharedUtils.createCprAccount(wmCoverageAdultCprRequest, cprPatientUpdateRetrofit);

    wmCoverageMinorCprRequest = SharedUtils.getTemplateCprRequest(mapper);
    wmCoverageMinorCprRequest.getPatientInfo().setFirstName(CommonUtil.randomUUID().replace("-", "").substring(0, 6).toUpperCase());
    wmCoverageMinorCprRequest.getPatientInfo().setLastName(CommonUtil.randomUUID().replace("-", "").substring(0, 6).toUpperCase());
    wmCoverageMinorCprRequest.getPatientInfo().setBirthDate(
        LocalDate.now().minusYears(8).format(DateTimeFormatter.ISO_LOCAL_DATE));
    wmCoverageMinorCprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    wmCoverageMinorCprRequest.getPatientCommunicationInfo().get(0).setCommunicationId(CommonUtil.generateRandomNumber(10));
    wmCoverageMinorPatientId = SharedUtils.createCprAccount(wmCoverageMinorCprRequest, cprPatientUpdateRetrofit);

    LocalDate flowAdultDob = LocalDate.now().minusYears(47);
    flowAdultDobIso      = flowAdultDob.format(DateTimeFormatter.ISO_LOCAL_DATE);
    flowAdultDobMmDdYyyy = flowAdultDob.format(FMT_MMDDYYYY);

    createAllCprAccounts();
    createSMSEnrollments();

    CreateAccountByPatientIdV1Request createPharmacyAccountRequest = SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, flowAdultDobMmDdYyyy);
    SharedUtils.createPharmacyAccount(createPharmacyAccountRequest, customerAccountId, domainId, accountOrchestratorRetrofit);

    createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit,
        getDmPostPreferencesRequest(storeNbr, String.valueOf(wmCoverageAdultPatientId), DM_SMS_NOTIFY_TYPE, wmCoveragePhoneNumber, DM_SMS_ENROLL_STATUS));
    createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit,
        getDmPostPreferencesRequest(storeNbr, String.valueOf(wmCoverageMinorPatientId), DM_SMS_NOTIFY_TYPE, wmCoveragePhoneNumber, DM_SMS_ENROLL_STATUS));

    CreateAccountByPatientIdV1Request wmCoverageAccountReq =
        SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(wmCoverageAdultPatientId), wmCoveragePhoneNumber, wmAdultDobMmDdYyyy);
    SharedUtils.createPharmacyAccount(wmCoverageAccountReq, wmCaregiverAccountId, domainId, accountOrchestratorRetrofit);

    LocalDate samsDob      = LocalDate.now().minusYears(33);
    String samsDobIso      = samsDob.format(DateTimeFormatter.ISO_LOCAL_DATE);
    String samsDobMmDdYyyy = samsDob.format(FMT_MMDDYYYY);

    samsPhoneNumber = CommonUtil.generateRandomNumber(10);
    samsAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName(samsDobIso);

    String samsCprPatientIdStr = CommonUtil.generateRandomNumber(9);
    SharedUtils.cprCreateOrUpdatePatient(
        samsStoreNbr, samsCprPatientIdStr,
        CommonUtil.generateRandomFirstName(6), CommonUtil.generateRandomLastName(6),
        CPR_GENDER_MALE, samsDobIso, CPR_PATIENT_TYPE_HUMAN,
        CommonUtil.generateRandomPhoneNo(10), CommonUtil.generateRandomNumber(5),
        cprPatientUpdateRetrofit);
    samsPatientId = Integer.parseInt(samsCprPatientIdStr);

    createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit,
        getDmPostPreferencesRequest(samsStoreNbr, String.valueOf(samsPatientId), DM_SMS_NOTIFY_TYPE, samsPhoneNumber, DM_SMS_ENROLL_STATUS));

    SharedUtils.createPharmacyAccount(
        samsAccountId, samsStoreNbr, String.valueOf(samsPatientId), samsDobMmDdYyyy,
        accountEntityServiceRetrofit);
  }

  @Test(description = "Fetch SMS Enrolled Profiles List with no type filter - Failure")
  public void fetchSMSEnrolledProfileListWithNoTypeFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "";
    CommonUtil.logFlowIdentifiers(
        customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, smsEnrolledProfileListsResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
            errorResponse.getMessage(), "Invalid input request. Type is null/empty in request");
  }

  @Test(description = "Fetch SMS Enrolled Profiles List with type=MINOR - Success")
  public void fetchSMSEnrolledProfileListWithMinorOnlyFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "MINOR";
    CommonUtil.logFlowIdentifiers(
        customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
        ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListV1Response> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(1, profilesList.size());

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet = profilesList.stream()
            .map(profile -> profile.getCustomerInfo().getPatientId()).collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertFalse(patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet returned in response, even though not expected");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test( description = "Fetch SMS Enrolled Profiles List with type=PET - Success")
  public void fetchSMSEnrolledProfileListWithPetOnlyFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "PET";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListV1Response> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(1, profilesList.size());

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet = profilesList.stream().map(profile -> profile.getCustomerInfo().getPatientId()).collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet not returned in response");
    Assert.assertFalse(patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor returned in response, even though  not expected");
  }

  @Test(description = "Fetch SMS Enrolled Profiles List with type=PET,MINOR - Success")
  public void fetchSMSEnrolledProfileListWithPetAndMinorFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "PET,MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListV1Response> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(2, profilesList.size());

    //        Assert responses - 2 Profile returned in response
    Set<String> patientIdsSet = profilesList.stream()
            .map(profile -> profile.getCustomerInfo().getPatientId())
            .collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet not returned in response");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test(description = "Fetch SMS Enrolled Profiles List with type=ADULT - Success")
  public void fetchSMSEnrolledProfileListWithAdultFilterAndInCoolDown() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListV1Response> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(1, profilesList.size());

    //        Assert responses - 2 Profile returned in response
    Set<String> patientIdsSet = profilesList.stream()
            .map(profile -> profile.getCustomerInfo().getPatientId())
            .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult not returned in response");
    Assert.assertFalse(patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet returned in response, even though not expected");
    Assert.assertFalse(patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor returned in response, even though not expected");

    SMSEnrolledProfileListV1Response smsEnrolledProfileListV1Response = profilesList.stream().filter(p -> p.getCustomerInfo().getPatientId().equals(String.valueOf(cprAdultHumanPatientId))).findFirst().orElse(null);
    Assert.assertTrue(smsEnrolledProfileListV1Response.getCustomerInfo().isIsInCooldown());
    Assert.assertEquals(smsEnrolledProfileListV1Response.getCustomerInfo().getCoolDownStatus().getFailedAttemptsCount(), 5);
  }

  @Test(description = "Fetch SMS Enrolled Profiles List with type=ADULT,PET,MINOR - Success")
  public void fetchSMSEnrolledProfileListWithAdultPetMinorFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT,PET,MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
                    customerAccountId, domainId, phoneNumber, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListV1Response> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(3, profilesList.size());

    //        Assert responses - 2 Profile returned in response
    Set<String> patientIdsSet = profilesList.stream()
            .map(profile -> profile.getCustomerInfo().getPatientId())
            .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult not returned in response");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet not returned in response");
    Assert.assertTrue(patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  /**
   * Validates that providing a non-empty stageIdType with an empty stageId returns 400.
   * Service rule: stageIdType non-empty + stageId empty → validation error.
   */
  @Test(priority = 94,
      description = "stageIdType provided with empty stageId should return 400 Bad Request")
  public void stageIdTypeProvidedWithEmptyStageId_shouldReturn400() {
    com.walmart.hwqe.commons.apicontext.ServiceResponse serRes =
        accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(
            wmCaregiverAccountId, wmCoveragePhoneNumber, "ADULT", "", STAGE_ID_TYPE_IMZ_RECOMM);
    Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400,
        "Expected HTTP 400 when stageIdType is provided but stageId is empty");
    GetsmsEnrolledProfilelListByPhoneNbrErrorResponse errorResponse =
        serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrErrorResponse.class);
    Assert.assertNotNull(errorResponse.getError(), "Error object should be present in 400 response");
  }

  /**
   * Validates that providing an unrecognized stageIdType value returns 400.
   * Service rule: stageIdType must be one of the valid StageIdType enum values (e.g. IMZ_RECOMM).
   */
  @Test(priority = 95,
      description = "Invalid stageIdType value should return 400 Bad Request")
  public void invalidStageIdType_shouldReturn400() {
    com.walmart.hwqe.commons.apicontext.ServiceResponse serRes =
        accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(
            wmCaregiverAccountId, wmCoveragePhoneNumber, "ADULT", "some-stage-id-value", "INVALID_STAGE_TYPE");
    Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400,
        "Expected HTTP 400 for an invalid stageIdType");
    GetsmsEnrolledProfilelListByPhoneNbrErrorResponse errorResponse =
        serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrErrorResponse.class);
    Assert.assertNotNull(errorResponse.getError(), "Error object should be present in 400 response");
  }

  /**
   * Validates that a non-existent stageId (random UUID not registered in DM SIS) returns 500.
   * When DM SIS responds 404 for an unknown stageId, AO does not handle that path gracefully;
   * it propagates an internal server error instead of falling back to a null isStageIdOwner.
   */
  @Test(priority = 96,
      description = "Non-existent stageId returns 500 — AO does not handle unknown stageId gracefully")
  public void nonExistentStageId_returns500() {
    String nonExistentStageId = CommonUtil.randomUUID();
    com.walmart.hwqe.commons.apicontext.ServiceResponse serRes =
        accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(
            wmCaregiverAccountId, wmCoveragePhoneNumber, "ADULT", nonExistentStageId, STAGE_ID_TYPE_IMZ_RECOMM);

    Assert.assertEquals(serRes.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR_500,
        "AO returns 500 when DM SIS stageId lookup returns 404 for a non-existent stageId");
  }

  /**
   * Validates that a MINOR profile has isInCooldown=false and null coolDownStatus.
   * MINOR patients are enrolled for SMS but are not subject to pharmacy-auth cooldown.
   */
  @Test(priority = 97,
      description = "MINOR profile has isInCooldown=false and null coolDownStatus")
  public void minorProfile_isInCooldownFalse_coolDownStatusNull() throws IOException {
    String reqId = reqIdString + CommonUtil.randomUUID();
    String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            wmCaregiverAccountId, domainId, wmCoveragePhoneNumber, reqId, reqTrackingId, "MINOR");

    Assert.assertEquals(response.code(), 200,
        CommonUtil.buildErrorMessage(gson, response));
    Assert.assertNotNull(response.body().getPayload(), "MINOR profile payload should be non-null");

    ArrayList<Object> payload = (ArrayList<Object>) response.body().getPayload();
    Assert.assertFalse(payload.isEmpty(), "At least one MINOR profile should be returned");

    java.util.List<SMSEnrolledProfileListV1Response> profiles = payload.stream()
        .map(p -> ResponseUtil.parseResponse(gson,
            (LinkedTreeMap<String, Object>) p, SMSEnrolledProfileListV1Response.class))
        .collect(Collectors.toList());

    SMSEnrolledProfileListV1Response minorProfile = profiles.get(0);
    Assert.assertNotNull(minorProfile.getCustomerInfo(), "CustomerInfo should be non-null");
    Assert.assertFalse(minorProfile.getCustomerInfo().isIsInCooldown(),
        "MINOR profile should have isInCooldown=false");
    Assert.assertNull(minorProfile.getCustomerInfo().getCoolDownStatus(),
        "MINOR profile should have null coolDownStatus when not in cooldown");
  }

  /**
   * Validates that each enrolled profile contains a non-null, non-empty validationToken.
   * validationToken is an AES-encrypted token built from patientId, storeNbr, and callerAccountId.
   */
  @Test(priority = 98,
      description = "Each SMS enrolled profile response should contain a non-null validationToken")
  public void validationToken_isNonNullAndNonEmpty() throws IOException {
    String reqId = reqIdString + CommonUtil.randomUUID();
    String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            wmCaregiverAccountId, domainId, wmCoveragePhoneNumber, reqId, reqTrackingId, "ADULT");

    Assert.assertEquals(response.code(), 200,
        CommonUtil.buildErrorMessage(gson, response));

    ArrayList<Object> payload = (ArrayList<Object>) response.body().getPayload();
    Assert.assertFalse(payload.isEmpty(), "At least one ADULT profile should be returned");

    LinkedTreeMap<String, Object> profileMap = (LinkedTreeMap<String, Object>) payload.get(0);
    String validationToken = (String) profileMap.get("validationToken");
    Assert.assertNotNull(validationToken,
        "validationToken should be non-null in each SMS enrolled profile response");
    Assert.assertFalse(validationToken.isEmpty(),
        "validationToken should not be empty");
  }

  /**
   * Validates that each enrolled profile's customerInfo contains a non-null uniqueId.
   * uniqueId is a hashed identifier derived from patientLinks (patientId + storeNbr combinations).
   */
  @Test(priority = 99,
      description = "Each SMS enrolled profile customerInfo should contain a non-null uniqueId")
  public void uniqueId_isNonNull() throws IOException {
    String reqId = reqIdString + CommonUtil.randomUUID();
    String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            wmCaregiverAccountId, domainId, wmCoveragePhoneNumber, reqId, reqTrackingId, "ADULT");

    Assert.assertEquals(response.code(), 200,
        CommonUtil.buildErrorMessage(gson, response));

    ArrayList<Object> payload = (ArrayList<Object>) response.body().getPayload();
    Assert.assertFalse(payload.isEmpty(), "At least one ADULT profile should be returned");
    LinkedTreeMap<String, Object> profileMap = (LinkedTreeMap<String, Object>) payload.get(0);
    LinkedTreeMap<String, Object> customerInfoMap =
        (LinkedTreeMap<String, Object>) profileMap.get("customerInfo");
    Assert.assertNotNull(customerInfoMap, "customerInfo should be non-null");
    Assert.assertNotNull(customerInfoMap.get("uniqueId"),
        "uniqueId should be non-null in customerInfo of each SMS enrolled profile");
  }

  /**
   * G1: Validates that creating a stageId using RefillSmsPayload (ref-type=refill-confirmation-sms)
   * sets isStageIdOwner=true for the matching profile.
   * Matching logic for RefillSmsPayload: patientId + storeId (same value as storeNbr) must match
   * the profile's patientLinks.
   */
  @Test(priority = 100,
      description = "G1: RefillSmsPayload stageId (refill-confirmation-sms) sets isStageIdOwner=true for matching profile")
  public void refillSmsPayloadStageId_isStageIdOwnerTrue()
      throws IOException, GeneralSecurityException {
    DMCreateStageIdRequest refillStageIdRequest = DMCreateStageIdRequest.builder()
        .refType(REF_TYPE_REFILL_SMS)
        .payload(DMCreateStageIdRequest.Payload.builder()
            .comms(DMCreateStageIdRequest.Comms.builder()
                .storeId(storeNbr)
                .patientId(String.valueOf(wmCoverageAdultPatientId))
                .phoneNumber(wmCoveragePhoneNumber)
                .build())
            .build())
        .build();

    Response<DMCreateStageIdResponse> createStageIdResponse =
        dmStageIDRetrofit.callDMStageIdAPI(refillStageIdRequest);
    Assert.assertEquals(createStageIdResponse.code(), 201,
        "DM SIS stageId creation with refill-confirmation-sms should succeed");
    String stageId = createStageIdResponse.body().getId();
    Assert.assertNotNull(stageId, "Created stageId should not be null");

    com.walmart.hwqe.commons.apicontext.ServiceResponse serRes =
        accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(
            wmCaregiverAccountId, wmCoveragePhoneNumber, "ADULT", stageId, STAGE_ID_TYPE_IMZ_RECOMM);

    Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200,
        "Expected HTTP 200 for valid RefillSmsPayload stageId");
    GetsmsEnrolledProfilelListByPhoneNbrResponse response =
        serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);
    Assert.assertNotNull(response.getPayload(), "Payload should be present");
    Assert.assertFalse(response.getPayload().isEmpty(), "At least one ADULT profile should be returned");
    Assert.assertEquals(response.getPayload().get(0).getCustomerInfo().getIsStageIdOwner(), Boolean.TRUE,
        "isStageIdOwner should be true when stageId RefillSmsPayload matches the profile's patientId+storeId");
  }

  /**
   * G4: Validates that providing a valid stageId without a stageIdType (null) returns 400.
   * AO's validateStageIdAndStageIdType rule: stageId present + stageIdType null → validation error.
   * This is the symmetric counterpart to P1 (stageIdType present + stageId empty → 400).
   */
  @Test(priority = 101,
      description = "G4: valid stageId with null stageIdType returns 200 OK")
  public void stageIdWithNullStageIdType_shouldReturn200()
      throws IOException, GeneralSecurityException {
    DMCreateStageIdRequest stageIdRequest = getDMCreateStageIdRequest(
        String.valueOf(wmCoverageAdultPatientId), wmCoveragePhoneNumber, storeNbr);

    Response<DMCreateStageIdResponse> createStageIdResponse =
        dmStageIDRetrofit.callDMStageIdAPI(stageIdRequest);
    Assert.assertEquals(createStageIdResponse.code(), 201,
        "DM SIS stageId creation should succeed");
    String stageId = createStageIdResponse.body().getId();
    Assert.assertNotNull(stageId, "Created stageId should not be null");

    com.walmart.hwqe.commons.apicontext.ServiceResponse serRes =
        accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(
            wmCaregiverAccountId, wmCoveragePhoneNumber, "ADULT", stageId, null);

    Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200,
        "AO now accepts stageId without stageIdType and returns 200");
    GetsmsEnrolledProfilelListByPhoneNbrResponse response =
        serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);
    Assert.assertNotNull(response.getPayload(), "Payload should be present in 200 response");
    Assert.assertFalse(response.getPayload().isEmpty(), "At least one ADULT profile should be returned");
  }

  /**
   * G5: Validates that the getSMSEnrolledProfileListV1 API works for SAMS-PHARMACY domain.
   * A patient enrolled at SAMS store 5596 should be returned when queried with SAMS-PHARMACY domainId.
   */
  @Test(priority = 102,
      description = "G5: SAMS-PHARMACY domain returns SMS enrolled profiles for SAMS patients")
  public void samsDomain_enrolledProfilesReturned() throws IOException {
    String reqId = reqIdString + CommonUtil.randomUUID();
    String reqTrackingId = reqTrackingString + CommonUtil.randomUUID();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            samsAccountId, samsDomainId, samsPhoneNumber, reqId, reqTrackingId, "ADULT");

    String errorMessage = CommonUtil.buildErrorMessage(gson, response);
    Assert.assertEquals(response.code(), 200, errorMessage);
    Assert.assertNotNull(response.body(), "Response body should be non-null for SAMS-PHARMACY domain");
    Assert.assertNotNull(response.body().getPayload(),
        "SAMS-PHARMACY should return enrolled profiles");

    ArrayList<Object> payload = (ArrayList<Object>) response.body().getPayload();
    Assert.assertFalse(payload.isEmpty(),
        "SAMS-PHARMACY domain should return at least 1 enrolled ADULT profile");
  }


  @NotNull
  private java.util.List<SMSEnrolledProfileListV1Response>
  extractProfilesFromResponsePayload(ArrayList<Object> payload) {
    return payload.stream()
        .map(
            profile ->
                ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) profile),
                    SMSEnrolledProfileListV1Response.class))
        .collect(Collectors.toList());
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(flowAdultDobIso);

    minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorHumanCprPatientRequest
        .getPatientInfo()
        .setBirthDate((LocalDate.now().getYear() - 1) + "-01-01");

    petCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest, petCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprMinorHumanPatientId = SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId = SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprPetPatientId = SharedUtils.createCprAccount(petCprPatientRequest, cprPatientUpdateRetrofit);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    // creating coolDown Status for the patientId and storeNbr by hitting the api for 5 times
    for(int i=0;i<5;i++) {
      pharmaAuthPatientIdStoreNbrRequest = SharedUtils.incrementCoolDownForStorePatient(storeNbr, String.valueOf(cprAdultHumanPatientId), "FAM", pharmacyAuthServiceRetrofit);
    }
  }

  private void createSMSEnrollments() {
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId)
      .forEach(
        patientId -> {
          try { createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit,
                    getDmPostPreferencesRequest(storeNbr, String.valueOf(patientId), DM_SMS_NOTIFY_TYPE, phoneNumber, DM_SMS_ENROLL_STATUS));
          } catch (IOException e) {
            throw new RuntimeException(
              String.format(
                "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                storeNbr, patientId, e.getMessage()));
          }
        });
  }

  /**
   * Helper: builds DMCreateStageIdRequest with ci-imz-reco ref-type (IMZ_RECOMM matching).
   * Matching logic: patientId + storeNbr must match a profile's patientLinks.
   */
  private DMCreateStageIdRequest getDMCreateStageIdRequest(
      String patientId, String phoneNumber, String storeNo) {
    DMCreateStageIdRequest.Comms comms = DMCreateStageIdRequest.Comms.builder()
        .patientId(patientId)
        .phoneNumber(phoneNumber)
        .storeNbr(storeNo)
        .build();
    DMCreateStageIdRequest.Payload payload = DMCreateStageIdRequest.Payload.builder()
        .comms(comms)
        .build();
    return DMCreateStageIdRequest.builder()
        .refType(REF_TYPE_CI_IMZ_RECO)
        .payload(payload)
        .build();
  }

  @AfterClass
  void cleanUp() throws IOException {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);
    petCprPatientRequest.setPatientId(cprPetPatientId);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest, petCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
              }
            });
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId).forEach(patientId -> {
      try {
        cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
      } catch (IOException e) {
      }
    });

    pharmacyAuthServiceRetrofit.resetFailedAuthenticationForPatientLinks(pharmaAuthPatientIdStoreNbrRequest);

    wmCoverageAdultCprRequest.setPatientId(wmCoverageAdultPatientId);
    wmCoverageMinorCprRequest.setPatientId(wmCoverageMinorPatientId);
    List.of(wmCoverageAdultCprRequest, wmCoverageMinorCprRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
              }
            });
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
            cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
            && response.body() != null
            && response.body().getErrors().isEmpty()) {
    } else {
        Reporter.logJSON("errorMessage",
        String.format("CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                cprRequest.getPatientId(),response.code()));
    }
  }

  public void cleanUpSMSEnrollment(String storeNbr, String patientId)
          throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
                .storeNbr(storeNbr)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .patientId(patientId)
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type(DM_SMS_NOTIFY_TYPE)
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code(DM_SMS_ENROLL_STATUS)
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
            dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
            && response.body() != null
            && response.body().getResponseStatus() != null
            && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
    }
  }
}
