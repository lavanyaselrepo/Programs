package accountorchestrator.customer.getCustomerInfoByPid;

import accountorchestrator.utils.CprPatientRequestBuilder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerInfoByPidV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import static accountorchestrator.constants.AccountOrchestratorConstants.*;

public class AccountOrchestratorGetCustomerInfoByPidValidationTest {
    private final Gson gson = new GsonBuilder().create();
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForLessThan18 = null;
    private String commonDobDPFormatForLessThan18 = null;
    private ValidationServiceRequest cprPatientRequest = null;
    private List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    private List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
    private String customerEmailId = CommonUtil.generateRandomEmailId(10);
    private String customerStoreNbr = CommonUtil.generateRandomNumber(6);
    private String customerPatientId = CommonUtil.generateRandomNumber(9);
    private String customerFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    private String customerLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    private String customerAccountId = CommonUtil.randomUUID();

    @BeforeClass
    void setContext() throws IOException, GeneralSecurityException {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
        commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);
    }

    @AfterClass
    void cleanUp() throws IOException {
        // Delete CPR profiles
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        cprPatientUpdateRetrofit.validateProfile(request);
                    } catch (IOException e) {
                        Reporter.logJSON("Exception during CPR profile deletion", e.getMessage());
                    }
                });

        // Delete pharmacy profiles
        pharmacyProfilesToBeDeleted.forEach(
                accountId -> {
                    try {
                        Response<
                                com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
                                getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        accountId, PHARMACY_DOMAIN_ID, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                accountId, PHARMACY_DOMAIN_ID, reqIdString, reqTrackingString);
                    } catch (IOException e) {
                        Reporter.logJSON("Exception during pharmacy profile deletion", e.getMessage());
                    }
                });
    }

    private void createCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob, String type)
            throws IOException {
        cprPatientRequest =
                CprPatientRequestBuilder.buildValidationServiceRequest(
                        storeNbr, patientId, CommonUtil.generateRandomNumber(10), dob);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : "
                                    + response.code()
                                    + response.errorBody().string());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(50000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void createPharmacyAccount(
            String customerAccountId,
            String commonStoreNbr,
            String commonPatientId,
            String dob,
            String domainId)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
                response = null;

        // Retry up to 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);

            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : "
                                    + response.code()
                                    + response.errorBody().string());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
                break;
            }
        }
    }

    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(ACCOUNT_CREATION_SOURCE)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    @Test(
            priority = 0,
            description =
                    "Call Get Customer Info By Pid V1 API with Invalid input request when patient id is null or empty")
    public void getCustomerInfoByPidWithInvalidRequestWhenPatientIdIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters set to true (but will be overridden by request body AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body AttributeFilters set to false (these take HIGHEST PRIORITY over URL params)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, null, filterOptions);

        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request1 =
                getCustomerInfoByPidV1Request(customerStoreNbr, "", filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Response<ServiceResponse> getCustomerInfoByPidResponse1 =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request1,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Error errorResponse1 = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse1);
        String errorMessage1 = CommonUtil.buildErrorMessage(errorResponse1);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");

        Assert.assertEquals(getCustomerInfoByPidResponse1.code(), 400, errorMessage1);
        Assert.assertEquals(errorResponse1.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 1,
            description =
                    "Call Get Customer Info By Pid V1 API with Invalid input request when store nbr is null or empty")
    public void getCustomerInfoByPidWithInvalidRequestWhenStoreNbrIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters set to true (but will be overridden by request body AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body AttributeFilters set to false (these take HIGHEST PRIORITY over URL params)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(null, customerPatientId, filterOptions);

        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request1 =
                getCustomerInfoByPidV1Request("", customerPatientId, filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Response<ServiceResponse> getCustomerInfoByPidResponse1 =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request1,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Error errorResponse1 = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse1);
        String errorMessage1 = CommonUtil.buildErrorMessage(errorResponse1);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");

        Assert.assertEquals(getCustomerInfoByPidResponse1.code(), 400, errorMessage1);
        Assert.assertEquals(errorResponse1.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 2,
            description =
                    "Call Get Customer Info By Pid V1 API with random storenbr and patient id not present in cpr")
    public void getCustomerInfoByPidWithInvalidRequestWhenRandomStoreNbrAndPatientId()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters set to true (but will be overridden by request body AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Request body AttributeFilters set to false (these take HIGHEST PRIORITY over URL params)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 204, errorMessage);
    }

    @Test(
            priority = 3,
            description = "Call Get Customer Info By Pid V1 API with pharmacy account but no CA account")
    public void getCustomerInfoByPidWithInvalidRequestWhenPharmacyAccountIsThereButNoCAAccount()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // URL parameters set to true (but will be overridden by request body AttributeFilters)
        Boolean walmartPlusStatus = true;
        Boolean storePatientInfo = true;
        Boolean emailId = true;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        createTestData();

        // Request body AttributeFilters set to false (these take HIGHEST PRIORITY over URL params)
        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(true)
                                        .caregivers(true)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 204, errorMessage);
    }

    @Test(
            priority = 4,
            description =
                    "Call Get Customer Info By Pid V1 API when both patientId and storeNbr are null - patientId validation fires first returning 400")
    public void getCustomerInfoByPidWithInvalidRequestWhenBothPatientIdAndStoreNbrAreNull()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                null,
                null,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();

        // Both patientId and storeNbr are null simultaneously
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(null, null, filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // patientId is validated first in the service — expect 400 with DPR-DPACCOR-1001
        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");

        // Also test both as empty strings simultaneously
        String trackID2 = CommonUtil.randomUUID();
        String reqId2 = reqIdString + trackID2;
        String reqTrackingId2 = reqTrackingString + trackID2;

        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request2 =
                getCustomerInfoByPidV1Request("", "", filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse2 =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request2,
                        reqId2,
                        reqTrackingId2,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse2 = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse2);
        String errorMessage2 = CommonUtil.buildErrorMessage(errorResponse2);

        Assert.assertEquals(getCustomerInfoByPidResponse2.code(), 400, errorMessage2);
        Assert.assertEquals(errorResponse2.getCode(), "DPR-DPACCOR-1001");
    }

    @Test(
            priority = 5,
            description =
                    "Call Get Customer Info By Pid V1 API with an invalid/unrecognized domainId - should return 400 or 404")
    public void getCustomerInfoByPidWithInvalidDomainId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;

        // Generate a random invalid domain ID that will never be recognized
        String invalidDomainId = "INVALID-DOMAIN-" + CommonUtil.randomUUID();
        logFlowIdentifiers(
                invalidDomainId,
                customerPatientId,
                customerStoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();

        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(customerStoreNbr, customerPatientId, filterOptions);

        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        invalidDomainId,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        // An invalid domain ID should not return a successful 200 response
        Assert.assertTrue(
                getCustomerInfoByPidResponse.code() == 400
                        || getCustomerInfoByPidResponse.code() == 404
                        || getCustomerInfoByPidResponse.code() == 204,
                "Expected 400, 404 or 204 for an invalid domain ID, but got: "
                        + getCustomerInfoByPidResponse.code());
    }

    @Test(
            priority = 6,
            description =
                    "When a pharmacy account exists but the CA account is missing (404 from CA),"
                            + " the orchestrator should return 204 AND asynchronously delete the orphaned pharmacy account."
                            + " Verifies the auto-delete side-effect by checking getPharmacyOnlineIdentityV1 returns 204 after the call.")
    public void getCustomerInfoByPidWhenCa404TriggersAutoDeleteOfOrphanedPharmacyAccount()
            throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        // Generate fresh unique identifiers for this test - must not exist as a real CA/DotCom account
        String ca404StoreNbr = CommonUtil.generateRandomNumber(6);
        String ca404PatientId = CommonUtil.generateRandomNumber(9);
        String ca404AccountId = CommonUtil.randomUUID();   // random UUID → no CA backing
        String ca404FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String ca404LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();

        Boolean walmartPlusStatus = false;
        Boolean storePatientInfo = false;
        Boolean emailId = false;
        logFlowIdentifiers(
                PHARMACY_DOMAIN_ID,
                ca404PatientId,
                ca404StoreNbr,
                reqId,
                reqTrackingId,
                walmartPlusStatus,
                storePatientInfo,
                emailId);

        // Step 1: Create CPR account so Account Entity can look up by patientId+storeNbr
        createCPRAccount(
                ca404StoreNbr,
                ca404PatientId,
                ca404FirstName,
                ca404LastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);

        // Step 2: Create pharmacy account with a UUID that has NO CA/DotCom backing
        createPharmacyAccount(
                ca404AccountId,
                ca404StoreNbr,
                ca404PatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);

        GetCustomerInfoByPidV1Request.FilterOptions filterOptions =
                GetCustomerInfoByPidV1Request.FilterOptions.builder()
                        .attributeFilters(
                                GetCustomerInfoByPidV1Request.AttributeFilters.builder()
                                        .walmartPlusStatus(false)
                                        .storePatientInfo(false)
                                        .emailId(false)
                                        .paymentMethods(false)
                                        .build())
                        .relationshipFilters(
                                GetCustomerInfoByPidV1Request.RelationshipFilters.builder()
                                        .primary(true)
                                        .dependents(false)
                                        .caregivers(false)
                                        .build())
                        .build();
        GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request =
                getCustomerInfoByPidV1Request(ca404StoreNbr, ca404PatientId, filterOptions);

        // Step 3: Call the orchestrator API — CA returns 404 → triggers async auto-delete → 204 response
        Response<ServiceResponse> getCustomerInfoByPidResponse =
                accountOrchestratorRetrofit.getCustomerInfoByPidV1(
                        PHARMACY_DOMAIN_ID,
                        getCustomerInfoByPidV1Request,
                        reqId,
                        reqTrackingId,
                        walmartPlusStatus,
                        storePatientInfo,
                        emailId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByPidResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Primary assertion: orchestrator should return 204 (account not found after CA 404)
        Assert.assertEquals(getCustomerInfoByPidResponse.code(), 204, errorMessage);

        // Step 4: Wait briefly for the async auto-delete to complete
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Step 5: Verify the orphaned pharmacy account was auto-deleted
        // getPharmacyOnlineIdentityV1 should return 204 (no content = account deleted)
        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
                getOnlineIdentityResp =
                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                        ca404AccountId,
                        PHARMACY_DOMAIN_ID,
                        reqIdString + CommonUtil.randomUUID(),
                        reqTrackingString + CommonUtil.randomUUID());

        Assert.assertEquals(
                getOnlineIdentityResp.code(),
                204,
                "Pharmacy account " + ca404AccountId
                        + " should have been auto-deleted when CA returned 404,"
                        + " but getPharmacyOnlineIdentityV1 returned HTTP "
                        + getOnlineIdentityResp.code());
    }

    private void createTestData() throws IOException {
        customerEmailId = CommonUtil.generateRandomEmailId(10);
        customerStoreNbr = CommonUtil.generateRandomNumber(6);
        customerPatientId = CommonUtil.generateRandomNumber(9);
        customerFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        customerLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        createCPRAccount(
                customerStoreNbr,
                customerPatientId,
                customerFirstName,
                customerLastName,
                commonDobCPRFormatForOlderThan18,
                HUMAN);
        createPharmacyAccount(
                customerAccountId,
                customerStoreNbr,
                customerPatientId,
                commonDobDPFormatForOlderThan18,
                PHARMACY_DOMAIN_ID);
    }

    public GetCustomerInfoByPidV1Request getCustomerInfoByPidV1Request(
            String storeNbr,
            String patientId,
            GetCustomerInfoByPidV1Request.FilterOptions filterOptions) {
        return GetCustomerInfoByPidV1Request.builder()
                .patientId(patientId)
                .storeNbr(storeNbr)
                .filterOptions(filterOptions)
                .build();
    }

    public void logFlowIdentifiers(
            String domainId,
            String patientId,
            String storeNbr,
            String reqId,
            String reqTrackingId,
            Boolean walmartPlusStatus,
            Boolean storePatientInfo,
            Boolean emailId) {
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("patientId", patientId);
        Reporter.logJSON("storeNbr", storeNbr);
        Reporter.logJSON("walmartPlusStatusFlag", walmartPlusStatus);
        Reporter.logJSON("storePatientInfoFlag", storePatientInfo);
        Reporter.logJSON("emailId", emailId);
    }
}
