package accountorchestrator.customer.accountStatus;

import accountorchestrator.constants.AccountOrchestratorConstants;
import accountorchestrator.utils.CommonAccountHelper;
import accountorchestrator.utils.CprPatientRequestBuilder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CreateAccountByPatientIdV1Request;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CreateAccountCustomerInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateAccountStatusV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.UpdateAccountStatusV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AccountOrchestratorUpdateAccountStatusTest {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private WCPRetroFit wcpRetroFit;
  private final Gson gson = new GsonBuilder().create();
  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonCustomerAccountId = null;
  private String commonPhoneNbr = null;
  private String commonDobCPRFormat = null;
  private String commonDobDPFormat = null;
  private String commonCustomerEmailId = null;
  private String domainId = AccountOrchestratorConstants.PHARMACY_DOMAIN_ID;
  private String reqIdString = AccountOrchestratorConstants.reqIdString;
  private String reqTrackingString = AccountOrchestratorConstants.reqTrackingString;
  private String trackID = null;
  private String reqId = null;
  private String reqTrackingId = null;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    wcpRetroFit = new WCPRetroFit();

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    commonPhoneNbr = CommonUtil.generateRandomNumber(10);
    commonCustomerAccountId = CommonUtil.randomUUID();
    commonCustomerEmailId = CommonUtil.generateRandomEmailId(10);

    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    trackID = CommonUtil.randomUUID();
    createCPRAccount();
    createSMSEnrollment();
    reqId = reqIdString + trackID;
    reqTrackingId = reqTrackingString + trackID;
    CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(commonCustomerEmailId);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Create CPR Account before running create a pharmacy account
   *
   * @throws IOException
   */
  public void createCPRAccount() throws IOException {
    ValidationServiceRequest cprPatientRequest =
        CprPatientRequestBuilder.buildValidationServiceRequest(
            commonStoreNbr, commonPatientId, commonPhoneNbr, commonDobCPRFormat);
    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Call DM Post Preferences API to link above created store number and patient Id with new phone
   * number
   *
   * @throws IOException
   */
  public void createSMSEnrollment() throws IOException {
    DMPostPreferencesRequest dmPostPreferencesRequest =
        CprPatientRequestBuilder.buildDMPostPreferencesRequest(
            commonStoreNbr, commonPatientId, commonPhoneNbr);

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }


  private CreateAccountByPatientIdV1Request getCreateAccountByPatientIdV1Request() {
    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(commonStoreNbr);
    customerInfo.setPatientId(commonPatientId);
    customerInfo.setPhoneNumber(commonPhoneNbr);
    customerInfo.setDob(commonDobDPFormat);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        new CreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

    return createAccountByPatientIdV1Request;
  }

  private void logAccountDetails() {
    Reporter.logJSON("Store nbr", commonStoreNbr);
    Reporter.logJSON("Patient Id", commonPatientId);
    Reporter.logJSON("Phone nbr", commonPhoneNbr);
    Reporter.logJSON("Customer Account Id", commonCustomerAccountId);
    Reporter.logJSON("Dob", commonDobDPFormat);
  }

  @Test(priority = 0, description = "Update Account Status Id Verified 400 error due to null Id verified status ")
  public void testNullIdVerifiedStatusForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setStatus(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. IdVerified status can not be null/empty");
  }

  @Test(priority = 1, description = "Update Account Status Id Verified 400 error due to false Id verified status ")
  public void testFalseIdVerifiedStatusForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setStatus(false);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. IdVerified status can not be false");
  }

  @Test(priority = 2, description = "Update Account Status Id Verified 400 error due to null Auth data ")
  public void testNullAuthDataForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setAuthData(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Auth Data can not be null for IdVerified");
  }

  @Test(priority = 3, description = "Update Account Status Id Verified 400 error due to null twoFASetUpStatus ")
  public void testNullTwoFASetupStatusForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);
    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setTwoFASetUpStatus(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. TwoFASetupStatus can not be null/empty");
  }

  @Test(priority = 4, description = "Update Account Status Id Verified 400 error due to Invalid twoFASetUpStatus ")
  public void testInvalidTwoFASetupStatusForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setTwoFASetUpStatus(AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. TwoFASetupStatus should be ACTIVE");
  }

  @Test(priority = 5, description = "Update Account Status Id Verified 400 error due to CustomerInfo null ")
  public void testNullCustomerInfoForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo can not be null for VerificationSource type EXPERIAN");
  }

  @Test(priority = 6, description = "Update Account Status Id Verified 400 error due to CustomerInfo.FirstName null ")
  public void testNullCustomerInfoFirstNameForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setFirstName(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo FirstName cannot be null/empty");
  }

  @Test(priority = 7, description = "Update Account Status Id Verified 400 error due to CustomerInfo.LastName null ")
  public void testNullCustomerInfoLastNameForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setLastName(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo LastName cannot be null/empty");
  }

  @Test(priority = 8, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Dob null ")
  public void testNullCustomerInfoDobForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setDob(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo Dob cannot be null/empty");
  }

  @Test(priority = 9, description = "Update Account Status Id Verified 400 error due to Invalid CustomerInfo.Dob")
  public void testInvalidCustomerInfoDobForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setDob("25012001");

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Dob Date should be in MMddyyyy format");
  }

  @Test(priority = 10, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address null ")
  public void testNullCustomerInfoAddressForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setAddress(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo Address cannot be null/empty");
  }

  @Test(priority = 11, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address.addressLine1 null ")
  public void testNullAddressLine1ForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().getAddress().setAddressLine1(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo-Address AddressLine1 cannot be null/empty");
  }

  @Test(priority = 12, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address.city null ")
  public void testNulCityForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().getAddress().setCity(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo-Address City cannot be null/empty");
  }

  @Test(priority = 13, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address.state null ")
  public void testNulStateForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().getAddress().setState(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo-Address State cannot be null/empty");
  }

  @Test(priority = 14, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address.zipcode null ")
  public void testNulZipCodeForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().getAddress().setZipCode(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo-Address ZipCode cannot be null/empty");
  }

  @Test(priority = 15, description = "Update Account Status Id Verified 400 error due to CustomerInfo.Address.country null ")
  public void testNulCountryForUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().getAddress().setCountry(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. CustomerInfo-Address Country cannot be null/empty");
  }

  @Test(priority = 16, description = "Update Account Status Id Verified 400 error due to IdVerified source null ")
  public void testNulIdVerifiedSourceExpirationDateUpdateAccountIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. VerificationSource can not be null/empty");
  }

  @Test(priority = 17, description = "Update Account Status Id Verified 400 error due to Invalid IdVerified source")
  public void testInvalidVerifiedSourceExpirationDateUpdateAccountIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource("WALMART");

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. VerificationSource should be EXPERIAN/RX_STORE");
  }

  @Test(priority = 18, description = "Update Account Status for TwoFASetupStatus 400 error due to TwoFASetupStatus null ")
  public void testNulTwoFASetupStatusUpdateAccountStatusTwoFASetupStatusError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus(null);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. TwoFASetupStatus can not be null/empty");
  }

  @Test(priority = 19, description = "Update Account Status for TwoFASetupStatus 400 error due to TwoFASetupStatus status invalid ")
  public void testInvalidTwoFASetupStatusUpdateAccountStatusTwoFASetupStatusError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus("WALMART");

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. TwoFASetupStatus should be ACTIVE/INACTIVE");
  }

  @Test(priority = 20, description = "Update Account Status for TwoFASetupStatus 400 error due to Invalid TwoFASetupStatus when photoId has value ")
  public void testInActiveTwoFASetupStatusUpdateAccountStatusTwoFASetupStatusError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus(AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. TwoFASetupStatus should be ACTIVE in case of Connexus");
  }

  @Test(priority = 21, description = "Update Account Status for TwoFASetupStatus 400 error due to Invalid TwoFASetupStatus when photoId has value ")
  public void testInvalidExpirationDateUpdateAccountStatusTwoFASetupStatusError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.getAuthData().getPhotoId().setExpirationDate("56-12-2002");

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. PhotoId of Expiration Date should be in MM-dd-yyyy format");
  }

  @Test(priority = 22, description = "Update Account Status 400 error due to invalid domain id")
  public void updateAccountStatusV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    String twoFASetUpStatus = AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountStatusV1Request class
    UpdateAccountStatusV1Request updateAccountStatusV1Request = new UpdateAccountStatusV1Request();

    // Step - 3: Setting TwoFASetUpStatus in the updateAccountStatusV1Request
    updateAccountStatusV1Request.setTwoFASetUpStatus(twoFASetUpStatus);

    // Step - 4: calling the updateAccountStatusV1 orchestrator API to update the account with the
    // above-made request and using twoFASetUpStatus
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            invalidDomainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. domainId is null/Invalid domainId");
  }

  @Test(priority = 23, description = "Update Account Status success for Insert Id Verification")
  public void updateAccountStatusV1RequestForIdVerificationSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1ResponseEntity =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1ResponseEntity);

    // Step - 5: Asserting response
    Assert.assertEquals(updateAccountStatusV1ResponseEntity.code(), 200, errorMessage);

    // Step - 6: Parsing the response to UpdateAccountVerifiedV1Response class so that we can assert
    UpdateAccountStatusV1Response updateAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountStatusV1ResponseEntity.body().getPayload()),
            UpdateAccountStatusV1Response.class);

    // Step - 7: Asserting response
    Assert.assertEquals(AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE, updateAccountStatusV1Response.getTwoFASetUpStatus());
    Assert.assertEquals(commonCustomerAccountId, updateAccountStatusV1Response.getCustomerAccountId());
    Assert.assertTrue(updateAccountStatusV1Response.getIdVerified());
  }

  @Test(priority = 25, description = "Update TwoFASetUpStatus for existing Account in Update Account Status")
  public void testUpdateTwoFASetupStatusAccountExistForTwoFASetupStatusSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.setAuthData(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus(AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1ResponseEntity =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1ResponseEntity);
    UpdateAccountStatusV1Response updateAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountStatusV1ResponseEntity.body().getPayload()),
            UpdateAccountStatusV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(updateAccountStatusV1ResponseEntity.code(), 200, errorMessage);
    Assert.assertEquals(AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE, updateAccountStatusV1Response.getTwoFASetUpStatus());
    Assert.assertEquals(commonCustomerAccountId, updateAccountStatusV1Response.getCustomerAccountId());
  }

  @Test(priority = 26, description = "Update TwoFASetUpStatus for existing Account with photoId in Update Account Status")
  public void testUpdateTwoFASetupStatusWithPhotoIdAccountExistForTwoFASetupStatusSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus(AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    Response<ServiceResponse> updateAccountStatusV1ResponseEntity =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1ResponseEntity);
    UpdateAccountStatusV1Response updateAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountStatusV1ResponseEntity.body().getPayload()),
            UpdateAccountStatusV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(updateAccountStatusV1ResponseEntity.code(), 200, errorMessage);
    Assert.assertEquals(commonCustomerAccountId, updateAccountStatusV1Response.getCustomerAccountId());
    Assert.assertEquals(AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE, updateAccountStatusV1Response.getTwoFASetUpStatus());
  }

  @Test(priority = 27, description = "Update TwoFASetUpStatus for existing Account in Update Account Status")
  public void testNoContentUpdateTwoFASetupStatusAccountExistForTwoFASetupStatusError() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String nonExistentAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(nonExistentAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting updateAccountStatusV1Request
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.setIdVerified(null);
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);
    updateAccountStatusV1Request.setTwoFASetUpStatus(AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API with a non-existent account id
    Response<ServiceResponse> updateAccountStatusV1ResponseEntity =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            nonExistentAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1ResponseEntity);

    // Step - 5: Asserting response
    Assert.assertEquals(updateAccountStatusV1ResponseEntity.code(), 400, errorMessage);
    Assert.assertEquals("Error response: \n" +
        "Code: DPR-DPACCOR-2002\n" +
        "Message: Bad Request returned from entity service. Entity Service for Upsert Account Verification failed - errorCode: DPR-DPACCENSR-1001, errorMessage: Invalid input request. No Data found for OnlineAccountId : " + nonExistentAccountId + " and OnlineStoreNbr : 9928\n", errorMessage);
  }

  @Test(priority = 24, description = "Update Account Status success for Insert Id Verification with RX_STORE source")
  public void updateAccountStatusV1RequestForRxStoreIdVerificationSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: RX_STORE does not require customerInfo; photoId is the verification document
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource(AccountOrchestratorConstants.VERIFICATION_SOURCE_RX_STORE);
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);

    // Step - 3: Call updateAccountStatusV1
    Response<ServiceResponse> updateAccountStatusV1ResponseEntity =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1ResponseEntity);

    // Step - 5: Asserting HTTP 200
    Assert.assertEquals(updateAccountStatusV1ResponseEntity.code(), 200, errorMessage);

    // Step - 6: Parsing response payload
    UpdateAccountStatusV1Response updateAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountStatusV1ResponseEntity.body().getPayload()),
            UpdateAccountStatusV1Response.class);

    // Step - 7: Asserting response fields
    Assert.assertTrue(updateAccountStatusV1Response.getIdVerified());
    Assert.assertEquals(AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE, updateAccountStatusV1Response.getTwoFASetUpStatus());
    Assert.assertEquals(commonCustomerAccountId, updateAccountStatusV1Response.getCustomerAccountId());
  }

  @Test(priority = 28, description = "Update Account Status Id Verified 400 error - CustomerInfo phoneNumber is null for EXPERIAN source")
  public void testNullPhoneNumberFromCustomerInfoForUpdateAccountStatusIdVerifiedError()
      throws IOException {

    // Step - 1: Setting and logging tracking ID's
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: EXPERIAN requires phoneNumber in customerInfo
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource(AccountOrchestratorConstants.VERIFICATION_SOURCE_EXPERIAN);
    updateAccountStatusV1Request.getAuthData().getCustomerInfo().setPhoneNumber(null);

    // Step - 3: Call updateAccountStatusV1
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid input request. CustomerInfo Phone Number cannot be null/empty");
  }

  @Test(priority = 29, description = "Update Account Status Id Verified 400 error - photoId is null when source is RX_STORE")
  public void testNullPhotoIdForRxStoreUpdateAccountStatusIdVerifiedError() throws IOException {

    // Step - 1: Setting and logging tracking ID's
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: RX_STORE mandates a non-null photoId
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource(AccountOrchestratorConstants.VERIFICATION_SOURCE_RX_STORE);
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);
    updateAccountStatusV1Request.getAuthData().setPhotoId(null);

    // Step - 3: Call updateAccountStatusV1
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid input request. PhotoId can not be null for VerificationSource type RX_STORE");
  }

  @Test(priority = 30, description = "Update Account Status Id Verified 400 error - photoId expirationDate is in wrong format for RX_STORE")
  public void testInvalidPhotoIdExpirationDateForRxStoreUpdateAccountStatusIdVerifiedError()
      throws IOException {

    // Step - 1: Setting and logging tracking ID's
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Valid format is MM-dd-yyyy; providing a wrong format triggers validation error
    UpdateAccountStatusV1Request updateAccountStatusV1Request = CprPatientRequestBuilder.buildUpdateAccountStatusRequest();
    updateAccountStatusV1Request.getIdVerified().setSource(AccountOrchestratorConstants.VERIFICATION_SOURCE_RX_STORE);
    updateAccountStatusV1Request.getAuthData().setCustomerInfo(null);
    updateAccountStatusV1Request.getAuthData().getPhotoId().setExpirationDate("35122005");

    // Step - 3: Call updateAccountStatusV1
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            domainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid input request. PhotoId of Expiration Date should be in MM-dd-yyyy format");
  }

  // These test for Existing CA flows

  /*
  @Test(priority = 0, description = "Update Account Status success case")
  public void updateAccountStatusV1RequestSuccess() throws IOException {

    // Step - 1: Creating a new account in CPR and doing sms enrollment
    // ******************************Create a new account******************************
    logAccountDetails();
    caCreatePerson(commonCustomerEmailId);
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 200, errorMessage);
    // ********************************************************************************

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String twoFASetUpStatus = AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // ******************************Get account status******************************
    // Step - 3: calling the getAccountStatusV1 orchestrator API to fetch the account
    Response<ServiceResponse> getAccountStatusV1APIResponse =
        accountOrchestratorRetrofit.getAccountStatusV1(
            commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, getAccountStatusV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getAccountStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to GetAccountStatusV1Response class so that we can assert
    GetAccountStatusV1Response getAccountStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountStatusV1APIResponse.body().getPayload()),
            GetAccountStatusV1Response.class);

    // Step - 7: Asserting response
    Assert.assertEquals(getAccountStatusV1Response.getTwoFASetUpStatus(), AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE);
    // ******************************************************************************

    // Step - 8: Preparing the request payload of UpdateAccountStatusV1Request class
    UpdateAccountStatusV1Request updateAccountStatusV1Request = new UpdateAccountStatusV1Request();

    // Step - 9: Setting TwoFASetUpStatus in the updateAccountStatusV1Request
    updateAccountStatusV1Request.setTwoFASetUpStatus(twoFASetUpStatus);

    // Step - 10: calling the updateAccountStatusV1 orchestrator API to update the account with the
    // above-made request and using twoFASetUpStatus
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId, domainId, updateAccountStatusV1Request, reqId, reqTrackingId);

    // Step - 11: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountStatusV1Response);

    // Step - 12: Asserting response
    Assert.assertEquals(updateAccountStatusV1Response.code(), 200, errorMessage);

    // Step - 13: Parsing the response to UpdateAccountStatusV1Response class so that we can assert
    // twoFASetUpStatus
    UpdateAccountStatusV1Response updateAccountStatusV1Res =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountStatusV1Response.body().getPayload()),
            UpdateAccountStatusV1Response.class);

    Assert.assertEquals(updateAccountStatusV1Res.getTwoFASetUpStatus(), twoFASetUpStatus);
  }

  @Test(priority = 1, description = "Update Account Status 400 error due to invalid domain id")
  public void updateAccountStatusV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    String twoFASetUpStatus = AccountOrchestratorConstants.TWO_FA_STATUS_INACTIVE;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountStatusV1Request class
    UpdateAccountStatusV1Request updateAccountStatusV1Request = new UpdateAccountStatusV1Request();

    // Step - 3: Setting TwoFASetUpStatus in the updateAccountStatusV1Request
    updateAccountStatusV1Request.setTwoFASetUpStatus(twoFASetUpStatus);

    // Step - 4: calling the updateAccountStatusV1 orchestrator API to update the account with the
    // above-made request and using twoFASetUpStatus
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId,
            invalidDomainId,
            updateAccountStatusV1Request,
            reqId,
            reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. domainId is null/Invalid domainId");
  }

  @Test(priority = 2, description = "Update Account Status 400 error due to invalid request")
  public void updateAccountStatusV1InvalidRequest() throws IOException {

    // *****  CASE 1 - twoFASetUpStatus is null *****
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountStatusV1Request class
    UpdateAccountStatusV1Request updateAccountStatusV1Request = new UpdateAccountStatusV1Request();

    // Step - 3: Setting TwoFASetUpStatus in the updateAccountStatusV1Request
    updateAccountStatusV1Request.setTwoFASetUpStatus(null);

    // Step - 4: calling the updateAccountStatusV1 orchestrator API to update the account with the
    // above-made request and using twoFASetUpStatus
    Response<ServiceResponse> updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId, domainId, updateAccountStatusV1Request, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Value is not valid");

    // *****  CASE 2 - twoFASetUpStatus is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidTwoFASetUpStatus = "INACTIV";
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Setting TwoFASetUpStatus in the updateAccountStatusV1Request
    updateAccountStatusV1Request.setTwoFASetUpStatus(invalidTwoFASetUpStatus);

    // Step - 3: calling the updateAccountStatusV1 orchestrator API to update the account with the
    // above-made request and using twoFASetUpStatus
    updateAccountStatusV1Response =
        accountOrchestratorRetrofit.updateAccountStatusV1(
            commonCustomerAccountId, domainId, updateAccountStatusV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, updateAccountStatusV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updateAccountStatusV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Value is not valid");
  }
   */

}
