package accountorchestrator.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class AccountOrchestratorPharmacyAccountTest {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonCustomerAccountId = null;
  private String commonPhoneNbr = null;
  private String commonDobCPRFormat = null;
  private String commonDobDPFormat = null;
  private String firstName = null;
  private String lastName = null;
  private String domainId = "WM-PHARMACY";

  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() throws IOException {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    commonPhoneNbr = CommonUtil.generateRandomNumber(10);
    commonCustomerAccountId = CommonUtil.randomUUID();

    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

    createCPRAccount();
    createSMSEnrollment();

    // Both CPR account creation and DM SMS enrollment are async.
    // Poll readiness every 10 seconds (up to 2 minutes) using a probe request with a
    // deliberately wrong DOB so no account is ever created.
    //
    // Infrastructure NOT ready (keep waiting) when:
    //   - DPR-DPACCOR-8004              → DM enrollment not yet propagated ("phone not sms enrolled")
    //   - "not enrolled with given phone number" in message → DM enrollment not found
    //   - "No data found in CPR" in message                → CPR not yet propagated
    //
    // Infrastructure READY (stop waiting) when:
    //   - Any other response (e.g. DOB mismatch DPR-DPACCOR-2002 with a CPR-found message)
    //     confirms both DM and CPR are available for the common patient.
    final int MAX_CPR_WAIT_ATTEMPTS = 12;
    final long CPR_POLL_INTERVAL_MS = 10_000L;

    CreateAccountCustomerInfo probeInfo = new CreateAccountCustomerInfo();
    probeInfo.setStoreNbr(commonStoreNbr);
    probeInfo.setPatientId(commonPatientId);
    probeInfo.setPhoneNumber(commonPhoneNbr);
    probeInfo.setDob("01011900"); // Deliberately wrong DOB — never creates an account
    probeInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request probeRequest = new CreateAccountByPatientIdV1Request();
    probeRequest.setCustomerInfo(probeInfo);

    for (int attempt = 1; attempt <= MAX_CPR_WAIT_ATTEMPTS; attempt++) {
      try {
        Response<ServiceResponse> probeResp =
            accountOrchestratorRetrofit.createAccountByPatientIdV1(
                CommonUtil.randomUUID(), domainId, probeRequest);
        Error probeError = CommonUtil.getErrorResponse(gson, probeResp);

        boolean dmNotReady = probeError != null
            && ("DPR-DPACCOR-8004".equals(probeError.getCode())
                || (probeError.getMessage() != null
                    && probeError.getMessage().contains("not enrolled with given phone number")));

        boolean cprNotReady = probeError != null
            && probeError.getMessage() != null
            && probeError.getMessage().contains("No data found in CPR");

        if (dmNotReady || cprNotReady) {
          String reason = dmNotReady ? "DM enrollment not yet propagated" : "CPR not yet propagated";
          Reporter.logJSON(
              "BeforeClass infra wait",
              reason + " for patientId=" + commonPatientId
                  + " (attempt " + attempt + "/" + MAX_CPR_WAIT_ATTEMPTS
                  + "). Retrying in " + (CPR_POLL_INTERVAL_MS / 1000) + "s...");
          Thread.sleep(CPR_POLL_INTERVAL_MS);
        } else {
          // Both DM and CPR are available — DOB mismatch (or similar) confirmed
          Reporter.logJSON(
              "BeforeClass infra ready",
              "DM + CPR available for patientId=" + commonPatientId
                  + " after " + attempt + " probe(s). errorCode="
                  + (probeError != null ? probeError.getCode() : "none"));
          break;
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        break;
      }
    }
  }

  public void deleteCPRAccount() throws IOException {
    ValidationServiceRequest cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(commonStoreNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(firstName);
    cprPatientRequest.getPatientInfo().setLastName(lastName);
    cprPatientRequest.getPatientInfo().setPatientStatusCode(20708);

    // This will try to delete an account in CPR 3 times if account deletion fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account deletion failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // This is needed because CPR account deletion is async, and it usually takes a couple of
    // seconds to reflect account deletion
    try {
      Thread.sleep(10000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  /**
   * Create CPR Account before running create a pharmacy account
   *
   * @throws IOException
   */
  public void createCPRAccount() throws IOException {
    ValidationServiceRequest cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);
    firstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    lastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();

    cprPatientRequest.setStoreNbr(Integer.parseInt(commonStoreNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(firstName);
    cprPatientRequest.getPatientInfo().setLastName(lastName);

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Creates a CPR account for an arbitrary storeNbr+patientId (not the common test data).
   * Used by tests that need a real CPR entry for isolated stub data before AES entity creation.
   */
  private void createCPRAccountForPatient(
      String storeNbr, String patientId, String dobCPRFormat,
      String stubFirstName, String stubLastName) throws IOException {
    ValidationServiceRequest cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(patientId));
    cprPatientRequest.getPatientInfo().setBirthDate(dobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(stubFirstName);
    cprPatientRequest.getPatientInfo().setLastName(stubLastName);

    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed for storeNbr=" + storeNbr
                  + ", patientId=" + patientId + ". HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Deletes a CPR account for an arbitrary storeNbr+patientId (patientStatusCode 20708) and
   * waits 10 seconds for the async deletion to propagate.
   * Used to put the system into the "entity exists, CPR gone" state for
   * {@code getCustomerInfoV1RequestNoContentFromCPR}.
   */
  private void deleteCPRAccountForPatient(
      String storeNbr, String patientId, String dobCPRFormat,
      String stubFirstName, String stubLastName) throws IOException {
    ValidationServiceRequest cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(patientId));
    cprPatientRequest.getPatientInfo().setBirthDate(dobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(stubFirstName);
    cprPatientRequest.getPatientInfo().setLastName(stubLastName);
    cprPatientRequest.getPatientInfo().setPatientStatusCode(20708);

    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account deletion failed for storeNbr=" + storeNbr
                  + ", patientId=" + patientId + ". HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // CPR deletion is async — wait for it to propagate before querying
    try {
      Thread.sleep(10_000L);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }

  /**
   * Call DM Post Preferences API to link above created store number and patient Id with new phone
   * number
   *
   * @throws IOException
   */
  public void createSMSEnrollment() throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(commonStoreNbr)
            .patientId(commonPatientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(commonPhoneNbr)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }

  /**
   * Creates a DM SMS enrollment for a given storeNbr + patientId + phoneNbr WITHOUT creating a
   * corresponding CPR account. Used by {@code createPharmacyAccountByPatientIdV1CPRAccountNotFound}
   * to simulate a patient who is DM-enrolled but has no CPR record.
   */
  private void createSMSEnrollmentForPatient(String storeNbr, String patientId, String phoneNbr)
      throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
            .zipCode("96898")
            .userId("SIGPAD")
            .storePhone("8009666546")
            .timeStamp(timestamp)
            .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNbr)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure for CPRAccountNotFound test setup. HttpStatusCode : "
              + response.code());
    }
  }

  @Test(
      priority = 0,
      description = "Create pharmacy account by patient id v1 API failure due to invalid store nbr")
  public void createPharmacyAccountByPatientIdV1InvalidStoreNbr() throws IOException {
    logAccountDetails();

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setStoreNbr(null);

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Store nbr is null/empty");
  }

  @Test(
      priority = 1,
      description =
          "Create pharmacy account by patient id v1 API failure due to invalid patient Id")
  public void createPharmacyAccountByPatientIdV1InvalidPatientId() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setPatientId(null);

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Patient Id is null/empty");
  }

  @Test(
      priority = 2,
      description = "Create pharmacy account by patient id v1 API failure due to invalid phone nbr")
  public void createPharmacyAccountByPatientIdV1InvalidPhoneNbr() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setPhoneNumber(null);

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Phone nbr is null/empty");
  }

  @Test(
      priority = 3,
      description = "Create pharmacy account by patient id v1 API failure due to invalid dob")
  public void createPharmacyAccountByPatientIdV1InvalidDob() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setDob(null);

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Dob is null/empty");
  }

  @Test(
      priority = 4,
      description = "Create pharmacy account by patient id v1 API failure due to invalid domain")
  public void createPharmacyAccountByPatientIdV1InvalidDomain() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, "WRONG_DOMAIN", createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Domain is invalid");
  }

  @Test(
      priority = 5,
      description =
          "Create pharmacy account by patient id v1 API failure due to store nbr and patient Id not enrolled with given phone number")
  public void createPharmacyAccountByPatientIdV1StoreNbrPatientIdNotLinkedWithPhoneNbr()
      throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request
        .getCustomerInfo()
        .setStoreNbr(CommonUtil.generateRandomNumber(5));
    createAccountByPatientIdV1Request
        .getCustomerInfo()
        .setPatientId(CommonUtil.generateRandomNumber(8));

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid input request. Store Nbr/ Patient Id present in request not enrolled with given phone number");
  }

  @Test(
      priority = 6,
      description =
          "Create pharmacy account by patient id v1 API failure due to incorrect dob format")
  public void createPharmacyAccountByPatientIdV1InvalidDobFormat() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setDob(commonDobCPRFormat);

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002");
  }

  /**
   * Valid storeNbr + patientId + phoneNbr but DOB does not match the CPR record.
   *
   * <p>The service returns {@code 400 DPR-DPACCOR-2005} with message {@code "DOB Mismatch"}.
   * This is a dedicated DOB-mismatch error code, distinct from the generic entity-service
   * bad-request code ({@code DPR-DPACCOR-2002}). Earlier runs incorrectly observed
   * {@code DPR-DPACCOR-2002} because CPR had not yet propagated — the request never reached
   * the DOB comparison stage. With CPR reliably available (via {@code @BeforeClass} readiness
   * poll), the true behaviour is now confirmed.
   */
  @Test(
      priority = 7,
      description =
          "createAccountByPatientId fails when DOB mismatches CPR record → 400 DPR-DPACCOR-2005")
  public void createPharmacyAccountByPatientIdV1RequestDobMismatchWithCPR() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    createAccountByPatientIdV1Request.getCustomerInfo().setDob("10101990");

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            CommonUtil.randomUUID(), domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "Error response should not be null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2005", errorMessage);
    Assert.assertTrue(errorResponse.getMessage().contains("DOB Mismatch"), errorMessage);
  }

  /**
   * Verifies that {@code createAccountByPatientIdV1} returns {@code 400 DPR-DPACCOR-3001}
   * after 5 consecutive DOB-mismatch failures for the same {@code customerAccountId}.
   *
   * <p><b>Why DM-only data did not work:</b> Previous iterations used DM-enrolled data with
   * no CPR record. Those requests failed at the entity-service DOB validation stage with
   * {@code DPR-DPACCOR-2002} — a level that does <em>not</em> increment the cooldown counter.
   * Only CPR-level DOB-mismatch failures ({@code DPR-DPACCOR-2005}) reach the stage that
   * increments the counter.
   *
   * <p><b>Setup:</b> Isolated CPR + DM enrollment is created for fresh storeNbr+patientId so
   * that the 5 wrong-DOB calls do not pollute the common patient used by the priority-10 success
   * test. A readiness probe (same dual DM+CPR logic as {@code @BeforeClass}) ensures both systems
   * are available before the failure loop starts.
   *
   * <p><b>Failure sequence:</b>
   * <ol>
   *   <li>Attempts 1–5: wrong DOB → {@code 400 DPR-DPACCOR-2005} (CPR-level DOB mismatch,
   *       increments cooldown counter each time).</li>
   *   <li>Attempt 6: same CID → {@code 400 DPR-DPACCOR-3001} (cooldown threshold reached).</li>
   * </ol>
   */
  @Test(
      priority = 8,
      description =
          "createAccountByPatientId returns DPR-DPACCOR-3001 after 5 consecutive DOB-mismatch failures for the same customerAccountId")
  public void createPharmacyAccountByPatientIdV1CustomerInCoolDown() throws IOException {
    // Isolated storeNbr+patientId with both CPR and DM enrollment — prevents common patient
    // pollution while ensuring failures reach CPR (DPR-DPACCOR-2005) not entity-service level.
    String isolatedStoreNbr  = CommonUtil.generateRandomNumber(6);
    String isolatedPatientId = CommonUtil.generateRandomNumber(9);
    String isolatedPhoneNbr  = CommonUtil.generateRandomNumber(10);
    String isolatedFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String isolatedLastName  = RandomStringUtils.randomAlphabetic(5).toUpperCase();

    Date isolatedDate = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000L);
    String isolatedDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(isolatedDate);

    // Step 1: Create CPR account + DM enrollment for isolated data
    createCPRAccountForPatient(isolatedStoreNbr, isolatedPatientId, isolatedDobCPRFormat,
        isolatedFirstName, isolatedLastName);
    createSMSEnrollmentForPatient(isolatedStoreNbr, isolatedPatientId, isolatedPhoneNbr);

    // Step 2: Poll until both CPR and DM are ready for the isolated patient
    //   - DPR-DPACCOR-8004 / "not enrolled with given phone number" → DM not ready yet
    //   - "No data found in CPR"                                    → CPR not ready yet
    //   - Any other code (e.g. DPR-DPACCOR-2005 DOB mismatch)      → both ready, stop polling
    final int  MAX_WAIT_ATTEMPTS = 12;
    final long POLL_INTERVAL_MS  = 10_000L;

    CreateAccountCustomerInfo probeInfo = new CreateAccountCustomerInfo();
    probeInfo.setStoreNbr(isolatedStoreNbr);
    probeInfo.setPatientId(isolatedPatientId);
    probeInfo.setPhoneNumber(isolatedPhoneNbr);
    probeInfo.setDob("01011900"); // Deliberately wrong DOB — never creates an account
    probeInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request probeRequest = new CreateAccountByPatientIdV1Request();
    probeRequest.setCustomerInfo(probeInfo);

    for (int attempt = 1; attempt <= MAX_WAIT_ATTEMPTS; attempt++) {
      try {
        Response<ServiceResponse> probeResp =
            accountOrchestratorRetrofit.createAccountByPatientIdV1(
                CommonUtil.randomUUID(), domainId, probeRequest);
        Error probeError = CommonUtil.getErrorResponse(gson, probeResp);

        boolean dmNotReady = probeError != null
            && ("DPR-DPACCOR-8004".equals(probeError.getCode())
                || (probeError.getMessage() != null
                    && probeError.getMessage().contains("not enrolled with given phone number")));
        boolean cprNotReady = probeError != null
            && probeError.getMessage() != null
            && probeError.getMessage().contains("No data found in CPR");

        if (dmNotReady || cprNotReady) {
          Thread.sleep(POLL_INTERVAL_MS);
        } else {
          break;
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        break;
      }
    }

    // Step 3: Build the request with the correct phone but wrong DOB
    String cooldownCid = CommonUtil.randomUUID();

    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(isolatedStoreNbr);
    customerInfo.setPatientId(isolatedPatientId);
    customerInfo.setPhoneNumber(isolatedPhoneNbr);
    customerInfo.setDob("10101990"); // Wrong DOB → DPR-DPACCOR-2005 each time
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request cooldownRequest = new CreateAccountByPatientIdV1Request();
    cooldownRequest.setCustomerInfo(customerInfo);

    // Step 4: Send 5 failing requests — each reaches CPR and returns DPR-DPACCOR-2005,
    // incrementing the cooldown counter on every attempt.
    for (int i = 1; i <= 5; i++) {
      accountOrchestratorRetrofit.createAccountByPatientIdV1(cooldownCid, domainId, cooldownRequest);
    }

    // Step 5: 6th attempt — cooldown threshold reached → DPR-DPACCOR-3001
    Response<ServiceResponse> cooldownResponse =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(cooldownCid, domainId, cooldownRequest);

    Error errorResponse = CommonUtil.getErrorResponse(gson, cooldownResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(cooldownResponse.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "Error response should not be null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-3001", errorMessage);
  }

  @Test(
      priority = 9,
      description =
          "Create pharmacy account by patient id v1 API failure due to phone nbr not being sms enrolled")
  public void createPharmacyAccountByPatientIdV1PhoneNbrNotSMSEnrolled() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request
        .getCustomerInfo()
        .setPhoneNumber(CommonUtil.generateRandomNumber(10));

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-8004");
    Assert.assertEquals(errorResponse.getMessage(), "Given phone number is not sms enrolled.");
  }

  @Test(priority = 10, description = "Create pharmacy account by patient id v1 API success")
  public void createPharmacyAccountByPatientIdV1Success() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 200, errorMessage);

    CreateAccountByPatientIdV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                createAccountByPatientIdV1Response.body().getPayload()),
            CreateAccountByPatientIdV1Response.class);

    Assert.assertEquals(response.getCustomerAccountId(), commonCustomerAccountId);
  }

  @Test(
      priority = 11,
      description =
          "Create pharmacy account by patient id v1 API failure due to online account Id already exists")
  public void createPharmacyAccountByPatientIdV1OnlineAccountIdAlreadyExists() throws IOException {
    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        getCreateAccountByPatientIdV1Request();

    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, createAccountByPatientIdV1Request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, createAccountByPatientIdV1Response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(createAccountByPatientIdV1Response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2011");
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  ADDITIONAL INPUT VALIDATION — EMPTY STRINGS
  //  Empty string is a distinct validation path from null; the service must
  //  trim/blank-check inputs rather than relying only on null checks.
  // ══════════════════════════════════════════════════════════════════════════

  @Test(
      priority = 0,
      description = "createAccountByPatientId fails when storeNbr is an empty string → DPR-DPACCOR-1001")
  public void createPharmacyAccountByPatientIdV1EmptyStoreNbr() throws IOException {
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();
    request.getCustomerInfo().setStoreNbr("");

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Store nbr is null/empty");
  }

  @Test(
      priority = 0,
      description = "createAccountByPatientId fails when patientId is an empty string → DPR-DPACCOR-1001")
  public void createPharmacyAccountByPatientIdV1EmptyPatientId() throws IOException {
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();
    request.getCustomerInfo().setPatientId("");

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Patient Id is null/empty");
  }

  @Test(
      priority = 0,
      description = "createAccountByPatientId fails when phoneNumber is an empty string → DPR-DPACCOR-1001")
  public void createPharmacyAccountByPatientIdV1EmptyPhoneNbr() throws IOException {
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();
    request.getCustomerInfo().setPhoneNumber("");

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Phone nbr is null/empty");
  }

  @Test(
      priority = 0,
      description = "createAccountByPatientId fails when dob is an empty string → DPR-DPACCOR-1001")
  public void createPharmacyAccountByPatientIdV1EmptyDob() throws IOException {
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();
    request.getCustomerInfo().setDob("");

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            commonCustomerAccountId, domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Dob is null/empty");
  }

  /**
   * Empty {@code customerAccountId} path parameter — {@code null} cannot be used because
   * {@code customerAccountId} is a Retrofit {@code @Path} parameter; passing {@code null}
   * throws {@link IllegalArgumentException} client-side before any HTTP request is made.
   *
   * <p>Empty string ({@code ""}) is used instead. The service does not guard against an empty
   * CID at the entry point and crashes internally → 500 {@code CHP-DPACCOR-1003} with a
   * {@code null} message body.
   *
   * <p><b>Service defect:</b> An empty {@code customerAccountId} should be rejected with
   * 400 DPR-DPACCOR-1001 at input validation, before any business logic is invoked.
   * This test documents the current (buggy) behaviour.
   * TODO: Downgrade to 400 DPR-DPACCOR-1001 assertion once the service validates the CID.
   */
  @Test(
      priority = 0,
      description = "createAccountByPatientId with empty customerAccountId — service crashes → 500 CHP-DPACCOR-1003 (service bug)")
  public void createPharmacyAccountByPatientIdV1EmptyCustomerAccountId() throws IOException {
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();

    // Cannot use null — Retrofit throws IllegalArgumentException for null @Path values.
    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1("", domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // SERVICE BUG: empty CID causes an unhandled exception → 500 CHP-DPACCOR-1003 instead of 400.
    // Expected (correct) behaviour: 400 DPR-DPACCOR-1001 "customerAccountId is null/empty".
    // Note: the service returns a null message body for this error code.
    // TODO: Downgrade to 400 DPR-DPACCOR-1001 assertion once the service validates the CID.
    Assert.assertEquals(response.code(), 500, errorMessage);
    Assert.assertNotNull(errorResponse, "Error response should not be null");
    Assert.assertEquals(errorResponse.getCode(), "CHP-DPACCOR-1003", errorMessage);
  }

  /**
   * Null {@code tandCPolicyLanguage} — confirmed OPTIONAL field.
   *
   * <p><b>Test strategy:</b> Uses fresh DM-enrolled data with NO corresponding CPR account.
   * A null {@code tandCPolicyLanguage} with otherwise valid inputs will reach the CPR lookup
   * stage and fail with {@code DPR-DPACCOR-2002 "No data found in CPR"}.
   * This proves the field is optional: if it were required, the service would reject it with
   * {@code DPR-DPACCOR-1001} at input validation — before CPR is ever contacted.
   *
   * <p><b>Why not use commonStoreNbr/commonPatientId:</b> Using common patient data creates a
   * real account (HTTP 200), linking that patient to a local CID. The subsequent
   * {@code deletePharmacyAccountV1} cleanup does not remove the storeNbr+patientId linkage row
   * (orphaned linkage), causing {@code DPR-DPACCOR-2004} in the priority-10 success test.
   * Using isolated DM-only data avoids any account creation and requires no cleanup.
   */
  @Test(
      priority = 0,
      description = "createAccountByPatientId with null tandCPolicyLanguage passes input validation — field is optional (reaches CPR, not DPR-DPACCOR-1001)")
  public void createPharmacyAccountByPatientIdV1NullTandCPolicyLanguage() throws IOException {
    // Fresh patient with DM enrollment only — no CPR account.
    // Null tandCPolicyLanguage passes input validation → reaches CPR → "No data found in CPR".
    String isolatedStoreNbr = CommonUtil.generateRandomNumber(6);
    String isolatedPatientId = CommonUtil.generateRandomNumber(9);
    String isolatedPhoneNbr = CommonUtil.generateRandomNumber(10);
    createSMSEnrollmentForPatient(isolatedStoreNbr, isolatedPatientId, isolatedPhoneNbr);

    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(isolatedStoreNbr);
    customerInfo.setPatientId(isolatedPatientId);
    customerInfo.setPhoneNumber(isolatedPhoneNbr);
    customerInfo.setDob(commonDobDPFormat);
    customerInfo.setTandCPolicyLanguage(null); // Field under test — null

    CreateAccountByPatientIdV1Request request = new CreateAccountByPatientIdV1Request();
    request.setCustomerInfo(customerInfo);

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            CommonUtil.randomUUID(), domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Null tandCPolicyLanguage passes input validation → reaches CPR → DPR-DPACCOR-2002.
    // If tandCPolicyLanguage were required, the service would return DPR-DPACCOR-1001 instead.
    // No account is created — no cleanup required.
    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "Error response should not be null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002", errorMessage);
    Assert.assertTrue(
        errorResponse.getMessage().contains("No data found in CPR"), errorMessage);
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  DUPLICATE / CONFLICT GUARD — PATIENT ALREADY LINKED TO DIFFERENT CID
  //  Runs at priority 11 — after priority-10 success creates the account for
  //  commonCustomerAccountId. A fresh CID with the same storeNbr+patientId+phone
  //  should be rejected because the patient is already linked.
  // ══════════════════════════════════════════════════════════════════════════

  @Test(
      priority = 11,
      description = "createAccountByPatientId fails when patient is already linked to a different CID")
  public void createPharmacyAccountByPatientIdV1PatientAlreadyLinkedToDifferentCID()
      throws IOException {
    String differentCid = CommonUtil.randomUUID();
    CreateAccountByPatientIdV1Request request = getCreateAccountByPatientIdV1Request();

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(differentCid, domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // TODO: Confirm exact error code on first run.
    // Expected: 409 with a code indicating the patient/store is already linked to another online account.
    Assert.assertEquals(response.code(), 409, errorMessage);
    Assert.assertNotNull(errorResponse.getCode(), "Error code should not be null");
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  CPR NOT FOUND — patient DM-enrolled but no CPR record exists
  //  Enrols a fresh storeNbr+patientId in DM (no CPR account created), then
  //  verifies that createAccountByPatientIdV1 returns a CPR-not-found error.
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Verifies that {@code createAccountByPatientIdV1} returns 400 {@code DPR-DPACCOR-2002} when
   * the storeNbr+patientId is enrolled in DM but has no corresponding CPR record.
   *
   * <p>The entity service propagates a "No data found in CPR" bad-request response upstream,
   * resulting in {@code DPR-DPACCOR-2002} rather than a 404. The error message confirms the
   * CPR lookup failure: {@code "Bad Request returned from entity service. No data found in CPR
   * for patientId: ..., storeNbr: ..."}.
   */
  @Test(
      priority = 5,
      description = "createAccountByPatientId fails when patient is DM-enrolled but has no CPR record → 400 DPR-DPACCOR-2002")
  public void createPharmacyAccountByPatientIdV1CPRAccountNotFound() throws IOException {
    String noCprStoreNbr = CommonUtil.generateRandomNumber(6);
    String noCprPatientId = CommonUtil.generateRandomNumber(9);
    String noCprPhoneNbr = CommonUtil.generateRandomNumber(10);

    // Enrol storeNbr+patientId with the phone number in DM only — no CPR account is created.
    createSMSEnrollmentForPatient(noCprStoreNbr, noCprPatientId, noCprPhoneNbr);

    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(noCprStoreNbr);
    customerInfo.setPatientId(noCprPatientId);
    customerInfo.setPhoneNumber(noCprPhoneNbr);
    customerInfo.setDob(commonDobDPFormat);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request request = new CreateAccountByPatientIdV1Request();
    request.setCustomerInfo(customerInfo);

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            CommonUtil.randomUUID(), domainId, request);

    Error errorResponse = CommonUtil.getErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(response.code(), 400, errorMessage);
    Assert.assertNotNull(errorResponse, "Error response should not be null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2002", errorMessage);
    Assert.assertTrue(
        errorResponse.getMessage().contains("No data found in CPR"),
        errorMessage);
  }

  @Test(
      priority = 12,
      description = "Get customer info with valid customerAccountId and domainId passed")
  public void getCustomerInfoV1Success() throws IOException {
    // logging to automation portal
    Reporter.logJSON("customerAccountId", commonCustomerAccountId);
    Reporter.logJSON("domainId", domainId);

    // call getCustomerInfoV1 API
    Response<ServiceResponse> getCustomerInfoV1Response =
        accountOrchestratorRetrofit.getCustomerInfoV1(commonCustomerAccountId, domainId);
    GetCustomerInfoV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoV1Response.body().getPayload()),
            GetCustomerInfoV1Response.class);
    Assert.assertEquals(response.getAuthStoreNbr(), commonStoreNbr);
    Assert.assertEquals(response.getAuthPatientId(), commonPatientId);
    Assert.assertEquals(response.getAccountCreationSource(), "smsOtpVerification");
    Assert.assertEquals(response.getFirstName(), firstName);
    Assert.assertEquals(response.getLastName(), lastName);
  }

  @Test(
      priority = 13,
      description = "Get customer info with invalid customerAccountId and valid domainId passed")
  public void getCustomerInfoV1NoContentFromEntity() throws IOException {
    String customerAccountId = "12345";

    // logging to automation portal
    Reporter.logJSON("customerAccountId", customerAccountId);
    Reporter.logJSON("domainId", domainId);

    // call getCustomerInfoV1 API
    Response<ServiceResponse> getCustomerInfoV1Response =
        accountOrchestratorRetrofit.getCustomerInfoV1(customerAccountId, domainId);

    // Assertions
    Assert.assertEquals(getCustomerInfoV1Response.code(), 204);
  }

  @Test(
      priority = 14,
      description = "Get customer info with valid customerAccountId and invalid domainId passed")
  public void getCustomerInfoV1InvalidDomainId() throws IOException {
    String domainId = "INVALID_DOMAIN";

    // logging to automation portal
    Reporter.logJSON("customerAccountId", commonCustomerAccountId);
    Reporter.logJSON("domainId", domainId);

    // call getCustomerInfoV1 API
    Response<ServiceResponse> getCustomerInfoV1Response =
        accountOrchestratorRetrofit.getCustomerInfoV1(commonCustomerAccountId, domainId);

    // Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV1Response);

    // Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Asserting desired responses
    Assert.assertEquals(getCustomerInfoV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", domainId));
  }

  /**
   * Scenario: account entity exists in the DB (storeNbr+patientId are linked to an onlineAccountId)
   * but CPR no longer holds a record for that storeNbr+patientId.
   * {@code getCustomerInfoV1} finds the entity, calls CPR, gets no data → 404 DPR-DPACCOR-6001.
   *
   * <p><b>Setup sequence:</b>
   * <ol>
   *   <li>Create a fresh CPR account for isolated stub storeNbr+patientId.</li>
   *   <li>Wait 15 s for CPR creation to propagate.</li>
   *   <li>Create the account entity via AES {@code createPharmacyAccountV1} — succeeds because CPR
   *       now has the stub record (AES verifies CPR during entity creation).</li>
   *   <li>Delete the CPR account (patientStatusCode 20708) and wait 10 s for deletion to
   *       propagate — entity row remains in DB, CPR record is gone.</li>
   * </ol>
   *
   * <p><b>Why not use the DB insert helper:</b> {@code accountDbContext}
   * ({@code AutomationManager.getInstance().getDPAccountDBContext()}) returns {@code null} in this
   * environment → {@code JdbcTemplate.update()} NPE → entity row never created.
   *
   * <p><b>Why not skip CPR creation and call AES directly with random data:</b> AES
   * {@code createPharmacyAccountV1} also verifies against CPR — a random storeNbr+patientId with
   * no CPR entry returns {@code 400 DPR-DPACCENSR-6004 "No data found in CPR"} from AES itself.
   *
   * <p><b>Cleanup:</b> The stub entity row is removed via {@code deleteAccountV1} in a
   * {@code finally} block to avoid orphaned DB entries.
   */
  @Test(priority = 15, description = "getCustomerInfoV1 returns 404 DPR-DPACCOR-6001 when entity exists but CPR has no record for the linked storeNbr+patientId")
  public void getCustomerInfoV1RequestNoContentFromCPR() throws IOException {
    String trackId       = CommonUtil.randomUUID();
    String reqId         = reqIdString + trackId;
    String reqTrackingId = reqTrackingString + trackId;

    // Fresh isolated stub data — no overlap with any other test
    String stubStoreNbr  = CommonUtil.generateRandomNumber(6);
    String stubPatientId = CommonUtil.generateRandomNumber(9);
    String stubFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String stubLastName  = RandomStringUtils.randomAlphabetic(5).toUpperCase();
    String onlineAccountId = CommonUtil.randomUUID();

    // Derive dob in both CPR (yyyy-MM-dd) and DP (MMddyyyy) formats
    Date stubDate = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000L);
    String stubDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(stubDate);
    String stubDobDPFormat  = new SimpleDateFormat("MMddyyyy").format(stubDate);

    // Step 1: Create CPR account for stub data
    createCPRAccountForPatient(stubStoreNbr, stubPatientId, stubDobCPRFormat,
        stubFirstName, stubLastName);

    // Step 2: Wait for CPR creation to propagate
    try {
      Thread.sleep(15_000L);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }

    // Step 3: Create account entity via AES (CPR now exists → succeeds)
    CreatePharmacyAccountV1Request stubRequest =
        CreatePharmacyAccountV1Request.builder()
            .accountCreationSource("smsOtpVerification")
            .customerInfo(
                CreatePharmacyAccountV1Request.CustomerInfo.builder()
                    .storeNbr(stubStoreNbr)
                    .patientId(stubPatientId)
                    .dob(stubDobDPFormat)
                    .build())
            .build();

    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
        createEntityResponse =
            accountEntityServiceRetrofit.createPharmacyAccountV1(
                onlineAccountId, domainId, stubRequest, reqId, reqTrackingId);
    Assert.assertEquals(
        createEntityResponse.code(), 200,
        "AES createPharmacyAccountV1 must succeed when CPR account exists; actual HTTP: "
            + createEntityResponse.code());

    try {
      // Step 4: Delete the CPR account — entity row remains, CPR record is removed
      // (deleteCPRAccountForPatient includes the 10 s async-propagation wait)
      deleteCPRAccountForPatient(stubStoreNbr, stubPatientId, stubDobCPRFormat,
          stubFirstName, stubLastName);

      // logging to automation portal
      Reporter.logJSON("onlineAccountId (entity exists, CPR deleted)", onlineAccountId);
      Reporter.logJSON("stubStoreNbr", stubStoreNbr);
      Reporter.logJSON("stubPatientId", stubPatientId);
      Reporter.logJSON("domainId", domainId);

      // Step 5: getCustomerInfoV1 — orchestrator finds entity → calls CPR → no data → 404
      Response<ServiceResponse> getCustomerInfoV1Response =
          accountOrchestratorRetrofit.getCustomerInfoV1(onlineAccountId, domainId);

      Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoV1Response);
      String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

      Assert.assertEquals(getCustomerInfoV1Response.code(), 404, errorMessage);
      Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6001", errorMessage);
      Assert.assertNotNull(
          errorResponse.getMessage(), "No information found for given input request in CPR");
    } finally {
      // Clean up the stub entity row to avoid orphaned DB entries
      accountEntityServiceRetrofit.deleteAccountV1(onlineAccountId, domainId, reqId, reqTrackingId);
    }
  }

  private CreateAccountByPatientIdV1Request getCreateAccountByPatientIdV1Request() {
    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(commonStoreNbr);
    customerInfo.setPatientId(commonPatientId);
    customerInfo.setPhoneNumber(commonPhoneNbr);
    customerInfo.setDob(commonDobDPFormat);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        new CreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

    return createAccountByPatientIdV1Request;
  }

  private void logAccountDetails() {
    Reporter.logJSON("Store nbr", commonStoreNbr);
    Reporter.logJSON("Patient Id", commonPatientId);
    Reporter.logJSON("Phone nbr", commonPhoneNbr);
    Reporter.logJSON("Customer Account Id", commonCustomerAccountId);
    Reporter.logJSON("Dob", commonDobDPFormat);
  }
}
