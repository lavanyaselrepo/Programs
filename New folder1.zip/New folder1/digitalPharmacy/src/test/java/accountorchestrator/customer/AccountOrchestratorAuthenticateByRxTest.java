package accountorchestrator.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.DropOff.Drug;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.DropOff.FetchDrug;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.datacontext.DataTable;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import static accountorchestrator.constants.AccountOrchestratorConstants.generatePassword;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class AccountOrchestratorAuthenticateByRxTest {

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();
    private final Random random = new Random();

    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";

    // Constants for Rx creation
    private static final String CONTROL_CODE = "2304";  // Non-controlled drugs
    private static final int REQUEST_TYPE_CODE = 1600;
    private static final int PRIORITY_ID = 21101; // Matches LookupByRxTest — uses DataRow overload of newOrderToEOD (compatible with DP-created patients)
    private static final int DISPENSE_TYPE = 1;
    private static final int NUM_REFILLS = 30;

    // Domain ID constants
    private static final String WM_PHARMACY_DOMAIN = "WM-PHARMACY";
    private static final String SAMS_PHARMACY_DOMAIN = "SAMS-PHARMACY";

    // Dynamic data fields
    private String domainId = WM_PHARMACY_DOMAIN;  // Default domain for most tests
    private String dynamicStoreNbr;
    private String dynamicRxNbr1;      // For single-item tests
    private String dynamicRxNbr2;      // For multi-item tests
    private String dynamicRxNbr3;      // For multi-item tests
    private String dynamicDob;         // DOB in MMddyyyy format (for API requests)
    private String dynamicWrongDob;    // Incorrect DOB for authentication failure tests (dynamicDob + 1 day)
    private String dobDotNet;          // DOB in .NET format (for Connexus API)
    private int dynamicPatientId;
    private String dynamicFirstName;
    private String dynamicLastName;

    // Managers
    private ConnexusAPIManager connexusAPIManager;
    private WrapperAPIManager wrapperAPIManager;
    private AutomationManager automationManager;
    private DBUtils dbUtils;
    private WrapperUtils wrapperUtils;

    // ── P27: Branch A — HTTP 200 full success (OCID found in Account Entity) ────────────────
    // Patient created via createDigitalPharmacyConnectedStorePatientAccount — has OCID in AE.
    // authenticateByRxV1: authStatus=true (DOB match + ACTIVE status) → ACCEN returns OCID
    //                     → customerAccountId set → applyExecutionState COMPLETE → HTTP 200.
    private String linkedCid;         // OCP customerAccountId (= onlineAccountId from Account Entity)
    private String linkedRxNbr;       // Rx for P27 full-success test
    private String linkedDob;         // DOB in MMddyyyy format — must match CPR patient record
    private int    linkedPatientId;   // CPR-verified patientId for AE mapping

    // ── P28: Branch B — patient status mismatch (DPR-DPACCOR-1013) ───────────────────────────
    // Patient created ACTIVE (20700), then status changed to 20708 (ONLINE_DEL) after Rx creation.
    // 20708 ∉ AUTH_ENABLED_PATIENT_CODES [20700 ACTIVE, 20705 MERGED] → patientStatusMatch=false
    // → authStatus=false → ACCEN NOT called → !patientStatusMatch branch → DPR-DPACCOR-1013.
    private String statusMismatchRxNbr;   // Rx for P28 patient status mismatch test
    private String statusMismatchDob;     // DOB in MMddyyyy format for status-mismatch patient

    // ── STATIC ERROR DATA — loaded from JSON file ─────────────────────────────────────────────
    @BeforeClass
    void setContext() throws Exception {

        // Initialize components
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        connexusAPIManager = new ConnexusAPIManager();
        wrapperAPIManager = new WrapperAPIManager();
        automationManager = AutomationManager.getInstance();
        dbUtils = new DBUtils();
        wrapperUtils = new WrapperUtils();

        // Set store number
        dynamicStoreNbr = "5548";
        int storeId = Integer.parseInt(dynamicStoreNbr);

        // ── P27: Create linked patient FIRST — gives RXOR maximum time to async-index the Rx ──
        // createDigitalPharmacyConnectedStorePatientAccount: Connexus patient → CPR (12s sleep)
        // → dotcom account → AE WM-PHARMACY OCID write (enableTestAccountInQa internal).
        // authenticateByRxV1 full success (HTTP 200): DOB match + ACTIVE status → authStatus=true
        // → ACCEN returns onlineAccountId (linkedCid) → customerAccountId set → HTTP 200.
        DigitalPharmacyAPIManager dpApiManager = new DigitalPharmacyAPIManager();
        linkedDob = "0101" + LocalDate.now().minusYears(25).getYear(); // Jan 1, 25 years ago (MMddyyyy)
        String linkedPassword      = generatePassword();
        String linkedEmail         = CommonUtil.generateRandomEmailId(10);
        String linkedFirstNameLocal = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String linkedLastNameLocal  = RandomStringUtils.randomAlphabetic(5).toUpperCase();

        DigitalPharmacyOperationsUtil linkedDpUtil = new DigitalPharmacyOperationsUtil(
                storeId,
                linkedFirstNameLocal,
                linkedLastNameLocal,
                linkedDob,
                0,
                linkedEmail,
                linkedPassword);
        // Creates: Connexus patient → CPR propagation (12s sleep) → dotcom account →
        //          Account Entity WM-PHARMACY OCID write → enableTestAccountInQa.
        linkedDpUtil.createDigitalPharmacyConnectedStorePatientAccount(false, false);

        linkedCid = dpApiManager.getCidFromEmailUsingAstro(linkedEmail);
        linkedPatientId = dpApiManager.getStorePatientIdFromCPR(
                linkedDpUtil.getPatientFirstName(),
                linkedDpUtil.getPatientLastName(),
                linkedDpUtil.getDates().get(1),
                storeId + "");
        Assert.assertNotNull(linkedCid,
                "linkedCid must not be null — getCidFromEmailUsingAstro must return a valid CID");
        Assert.assertTrue(linkedPatientId > 0,
                "linkedPatientId from CPR must be positive — getStorePatientIdFromCPR returned 0 or negative");

        // Write WM-PHARMACY OCID to Account Entity using CPR-verified patientId (ensures AE key matches RXOR)
        linkedDpUtil.enableTestAccountInQa(
                linkedCid,
                storeId + "",
                linkedPatientId + "",
                linkedDpUtil.getPatientDob());

        // Create Rx early — RXOR dot-com sync is in progress; Rx will be indexed when P27 runs
        linkedRxNbr = createDynamicRx(storeId, linkedPatientId, "Rx for P27 HTTP 200 full success (Branch A)");

        // Generate dynamic DOB (CRITICAL for authentication)
        LocalDate dob = LocalDate.now().minusYears(18 + random.nextInt(42)); // Age 18-60
        dynamicDob = dob.format(DateTimeFormatter.ofPattern("MMddyyyy"));
        dobDotNet = "/Date(" + dob.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() + ")/";
        dynamicWrongDob = dob.plusDays(1).format(DateTimeFormatter.ofPattern("MMddyyyy")); // Always differs from dynamicDob

        // Generate random patient names
        dynamicFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        dynamicLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();

        // Create Connexus patient with DOB
        AddPatient addPatient = buildAddPatient(storeId, dobDotNet);
        dynamicPatientId = connexusAPIManager.addPatientWithGenericAllParam(addPatient);

        // Create 3 dynamic Rx prescriptions
        dynamicRxNbr1 = createDynamicRx(storeId, dynamicPatientId, "Rx #1");
        dynamicRxNbr2 = createDynamicRx(storeId, dynamicPatientId, "Rx #2");
        dynamicRxNbr3 = createDynamicRx(storeId, dynamicPatientId, "Rx #3");

        // ── P28: Create status-mismatch patient for DPR-DPACCOR-1013 (Branch B) ─────────────────
        // Strategy: create ACTIVE (20700) first so newOrderToEOD succeeds, then change
        // status_code to 20708 (ONLINE_DEL) in Connexus DB after Rx creation, then re-sync to CPR.
        // Using ONLINE_DEL instead of DECEASED because RXOR filters deceased patients (Rx not found).
        // After status changed: 20708 ∉ AUTH_ENABLED_PATIENT_CODES [20700, 20705]
        // → patientStatusMatch=false → authStatus=false → ACCEN NOT called
        // → !patientStatusMatch branch → DPR-DPACCOR-1013, INVALID DOB/PTNT STATUS, HTTP 206.
        LocalDate statusMismatchDobDate = LocalDate.now().minusYears(30);
        statusMismatchDob = statusMismatchDobDate.format(DateTimeFormatter.ofPattern("MMddyyyy"));
        String statusMismatchDobDotNet = "/Date("
                + statusMismatchDobDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() + ")/";
        String statusMismatchFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String statusMismatchLastName  = RandomStringUtils.randomAlphabetic(5).toUpperCase();

        AddPatient statusMismatchPatient = new AddPatient();
        statusMismatchPatient.setSiteID(storeId);
        statusMismatchPatient.setCommunicationID("5555555555");
        statusMismatchPatient.setFirstName(statusMismatchFirstName);
        statusMismatchPatient.setLastName(statusMismatchLastName);
        statusMismatchPatient.setMiddleName("");
        statusMismatchPatient.setPatientName(statusMismatchLastName + "," + statusMismatchFirstName);
        statusMismatchPatient.setDob(statusMismatchDobDotNet);
        statusMismatchPatient.setGender("F");
        statusMismatchPatient.setLanguage("101");
        statusMismatchPatient.setStatus(20700); // ACTIVE — required so newOrderToEOD succeeds
        statusMismatchPatient.setIsPatientMinor(false);
        statusMismatchPatient.setAddressTypeCode(3);
        statusMismatchPatient.setVerifyFreCode(1);
        statusMismatchPatient.setPatientTypeCode(10200); // Human
        statusMismatchPatient.setUserId("APITEST");
        statusMismatchPatient.setAddressLine1("123 Test St");
        statusMismatchPatient.setAddressLine2("");
        statusMismatchPatient.setCity("Bentonville");
        statusMismatchPatient.setState("AR");
        statusMismatchPatient.setZipCode("72712");
        statusMismatchPatient.setCountry("USA");
        statusMismatchPatient.setHomePhone("5555555555");
        statusMismatchPatient.setCellPhone("5555555555");
        statusMismatchPatient.setWorkPhone("");

        int statusMismatchPatientId = connexusAPIManager.addPatientWithGenericAllParam(statusMismatchPatient);
        Assert.assertTrue(statusMismatchPatientId > 0,
                "statusMismatchPatientId must be positive — addPatientWithGenericAllParam returned 0 or negative");

        // Create Rx WHILE patient is ACTIVE — newOrderToEOD requires ACTIVE status
        statusMismatchRxNbr = createDynamicRx(storeId, statusMismatchPatientId,
                "Rx for P28 patient status mismatch (status changed to 20708 ONLINE_DEL post-creation)");

        // Debug: Verify Rx was created successfully
        Assert.assertNotNull(statusMismatchRxNbr,
                "statusMismatchRxNbr must not be null - createDynamicRx must return a valid Rx number");
        Assert.assertTrue(statusMismatchRxNbr.length() > 0,
                "statusMismatchRxNbr must not be empty - got: " + statusMismatchRxNbr);
        

        // Sleep to allow RXOR to index the newly created Rx before changing patient status.
        // Without this sleep, RXOR may not have indexed the Rx yet when the test runs
        // → RXOR returns "not found" (DPR-DPACCOR-4003) instead of allowing patient status check.
        try {
            Thread.sleep(10000); // 10 seconds for RXOR indexing
        } catch (InterruptedException e) {
            throw new RuntimeException("Sleep interrupted during RXOR indexing wait", e);
        }

        // Change patient status_code to 20708 (ONLINE_DEL) in Connexus DB AFTER Rx creation.
        // 20708 ∉ AUTH_ENABLED_PATIENT_CODES [20700, 20705] → patientStatusMatch=false in service.
        // Uses the same pattern as IMZWorkflowManager which updates patient.status_code directly.
        // Using 20708 (ONLINE_DEL) instead of 20701 (DECEASED) because RXOR filters deceased patients.
        int rowsUpdated = automationManager.getConnexusDB(storeId).executeUpdateQuery(
                "update patient set status_code = 20708 where patient_id = " + statusMismatchPatientId + ";");
        Assert.assertTrue(rowsUpdated > 0,
                "DB update of patient status_code to 20708 must affect at least 1 row — "
                        + "patientId: " + statusMismatchPatientId);

        // Re-sync updated status_code to CPR so authenticateByRxV1 reads patientStatusCode=20708.
        // Without this sync CPR retains the old 20700 → patientStatusMatch=true → Branch B NOT triggered.
        connexusAPIManager.updatePatientInfoCentralData(statusMismatchPatientId, storeId, "APITEST");

        // Sleep to allow CPR sync to complete — updatePatientInfoCentralData is async
        // Without this sleep, P28 runs before CPR has the updated status → test gets wrong error code
        try {
            Thread.sleep(15000); // 15 seconds for CPR propagation
        } catch (InterruptedException e) {
            throw new RuntimeException("Sleep interrupted during CPR sync wait", e);
        }
    }

    @Test(
            priority = 1,
            description = "AuthenticateByRx Invalid domainId - Tests validation of domainId field. " +
                    "Invalid domain should be rejected with HTTP 400.")
    void authenticateByRxV1InvalidDomainId() throws IOException {
        String domainId = "WM-PHARMAC"; // Invalid - missing 'Y'
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic values
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(errorResponse.getMessage(),
                "Invalid input request. domainId WM-PHARMAC in input is invalid");
    }

    @Test(
            priority = 2,
            description = "AuthenticateByRx Rx_Nbr is Null - Tests validation of rxNbr field. " +
                    "Null rxNbr should be rejected with HTTP 400.")
    void authenticateByRxV1RxNbrIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with null rxNbr
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(null);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Rx nbr is null/empty",
                "Expected exact error message but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 3,
            description = "AuthenticateByRx Store_Nbr is Null - Tests validation of storeNbr field. " +
                    "Null storeNbr should be rejected with HTTP 400.")
    void authenticateByRxV1StoreNbrIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with null storeNbr
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(null);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Store nbr is null/empty/invalid",
                "Expected exact error message but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 4,
            description = "AuthenticateByRx DOB is Null - Tests validation of DOB field. " +
                    "DOB is MANDATORY for authentication and null value should be rejected with HTTP 400.")
    void authenticateByRxV1DOBIsNull() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with null DOB
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(null);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. dob is null/empty",
                "Expected exact error message but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 5,
            description = "AuthenticateByRx single-item success - Authenticates Rx with correct DOB. " +
                    "Uses dynamic Rx from Connexus with matching DOB for successful authentication.")
    void authenticateByRxV1Success() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx and CORRECT DOB
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob); // SAME as patient's DOB - authentication will succeed

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        // Track requested rxNbr for validation
        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Dynamic Connexus patient has no linked online account — authentication succeeds but OCID not found → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 (auth success but no linked OCID) but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        // Collect response fields
        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(AuthenticateByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // rxNbr must echo back
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back requested rxNbr. Requested: " + requestedRxNbrs + ", got: " + rxNbrsSet);

        // DOB matched but no linked OCID → error code DPR-DPACCOR-2007 (Customer Profile Not Found In OCP)
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (no linked OCID) but got: " + errorCodeResponseSet);

        // Authentication status must be SUCCESS (DOB matched — OCID linkage is a separate concern)
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                "Expected authenticationStatus SUCCESS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());

        // patientId must be returned (populated from CPR via buildAuthenticateRxInfo when authStatus=true)
        Assert.assertEquals(responseList.get(0).getRxInfo().getPatientId(), String.valueOf(dynamicPatientId),
                "Expected patientId " + dynamicPatientId + " but got: "
                        + responseList.get(0).getRxInfo().getPatientId());

        // firstName must be returned from CPR
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getFirstName(), dynamicFirstName,
                "Expected firstName " + dynamicFirstName + " but got: "
                        + responseList.get(0).getCustomerInfo().getFirstName());

        // fillQuantity must be populated (buildAuthenticateRxInfo is called when authStatus=true)
        Assert.assertNotNull(responseList.get(0).getRxInfo().getFillQuantity(),
                "fillQuantity should not be null when authStatus=true");
    }

    @Test(
            priority = 6,
            description = "AuthenticateByRx multi-item success - Authenticates multiple Rx with correct DOB. " +
                    "Uses dynamic Rx from Connexus with matching DOB for successful authentication.")
    void authenticateByRxV1SuccessMultipleItems() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build multi-item request with dynamic Rx data
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}]",
                dynamicRxNbr2, dynamicStoreNbr, dynamicDob,
                dynamicRxNbr3, dynamicStoreNbr, dynamicDob);

        AuthenticateByRxV1Request request = objectMapper.readValue(payload, AuthenticateByRxV1Request.class);

        // Track requested rxNbrs
        Set<String> requestedRxNbrs = new HashSet<>(Arrays.asList(dynamicRxNbr2, dynamicRxNbr3));

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Dynamic Connexus patients have no linked online account — authentication succeeds but OCID not found → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 (auth success but no linked OCID) but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2, "Expected 2 items in response");

        // Collect rxNbrs
        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(AuthenticateByRxRxInfo::getRxNbr).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> authStatusSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getCustomerInfo()))
                .map(apiResponse -> apiResponse.getCustomerInfo().getAuthenticationStatus())
                .collect(Collectors.toSet());

        // Both rxNbrs must echo back
        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back all requested rxNbrs. Requested: " + requestedRxNbrs + ", got: " + rxNbrsSet);

        // Both items DOB matched but no linked OCID → error code DPR-DPACCOR-2007
        Assert.assertEquals(errorCodeResponseSet.size(), 1,
                "Expected exactly one distinct error code but got: " + errorCodeResponseSet);
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 for all items but got: " + errorCodeResponseSet);

        // Both items must have authenticationStatus SUCCESS
        Assert.assertEquals(authStatusSet.size(), 1,
                "Expected exactly one distinct authenticationStatus but got: " + authStatusSet);
        Assert.assertTrue(authStatusSet.contains("SUCCESS"),
                "Expected authenticationStatus SUCCESS for all items but got: " + authStatusSet);
    }

    @Test(
            priority = 7,
            description = "AuthenticateByRx SAMS domain success - Tests SAMS domain with dynamic Rx. " +
                    "Uses correct DOB for successful authentication.")
    void authenticateByRxV1SuccessSams() throws IOException {
        String domainId = SAMS_PHARMACY_DOMAIN;
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx and CORRECT DOB
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // SAMS domain: dynamic Connexus patient has no linked SAMS OCID — authentication succeeds but OCID not found → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 (auth success but no linked SAMS OCID) but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> Optional.ofNullable(apiResponse.getRxInfo())
                        .map(AuthenticateByRxRxInfo::getRxNbr).orElse(null))
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back requested rxNbr for SAMS domain");

        // DOB matched but no linked SAMS OCID → error code DPR-DPACCOR-2007
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (no linked SAMS OCID) but got: " + errorCodeResponseSet);

        // Authentication status must be SUCCESS (DOB matched)
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                "Expected authenticationStatus SUCCESS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());

        // fillQuantity must be populated (buildAuthenticateRxInfo is called when authStatus=true)
        Assert.assertNotNull(responseList.get(0).getRxInfo().getFillQuantity(),
                "fillQuantity should not be null when authStatus=true");
    }

    @Test(
            priority = 8,
            description = "AuthenticateByRx partial success - Rx not found in upstream. " +
                    "Uses non-existent Rx number to test error handling.")
    void authenticateByRxV1PartialSuccessRxNotFoundInUpstream() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with non-existent Rx
        String nonExistentRx = "999999999";
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(nonExistentRx);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(nonExistentRx);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for partial success");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1);

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> apiResponse.getRxInfo().getRxNbr())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back requested rxNbr");
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 for Rx Not Found but got: " + errorCodeResponseSet);
    }

    @Test(
            priority = 9,
            description = "AuthenticateByRx partial success - Customer profile not found. " +
                    "Uses dynamic Rx from Connexus. May return customer not found or Rx not found " +
                    "depending on data replication timing.")
    void authenticateByRxV1PartialSuccessCustomerProfileNotFoundInOCP() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with dynamic Rx
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Set<String> requestedRxNbrs = new HashSet<>();
        requestedRxNbrs.add(dynamicRxNbr1);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for partial success");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1);

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> apiResponse.getRxInfo().getRxNbr())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        Assert.assertTrue(rxNbrsSet.containsAll(requestedRxNbrs),
                "Response must echo back requested rxNbr");

        // Dynamic Connexus patient: DOB matches, RXOR and CPR find data, but no linked OCID → DPR-DPACCOR-2007
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 (no linked OCID) but got: " + errorCodeResponseSet);

        // authenticationStatus must be SUCCESS (DOB matched successfully)
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                "Expected authenticationStatus SUCCESS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 10,
            description = "AuthenticateByRx partial success - Multi-item with mixed errors. " +
                    "One non-existent Rx, one dynamic Rx. Tests partial success handling.")
    void authenticateByRxV1PartialSuccessMultipleItems() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build multi-item request: one non-existent, one dynamic
        String nonExistentRx = "999999999";
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}]",
                nonExistentRx, dynamicStoreNbr, dynamicDob,
                dynamicRxNbr1, dynamicStoreNbr, dynamicDob);

        AuthenticateByRxV1Request request = objectMapper.readValue(payload, AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for partial success");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2);

        Set<String> rxNbrsSet = responseList.stream()
                .map(apiResponse -> apiResponse.getRxInfo().getRxNbr())
                .collect(Collectors.toSet());
        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(apiResponse -> Objects.nonNull(apiResponse.getError()))
                .map(apiResponse -> apiResponse.getError().getCode())
                .collect(Collectors.toSet());

        // Both rxNbrs must echo back
        Assert.assertTrue(rxNbrsSet.contains(nonExistentRx),
                "Expected non-existent rxNbr in response");
        Assert.assertTrue(rxNbrsSet.contains(dynamicRxNbr1),
                "Expected dynamic rxNbr in response");

        // Non-existent Rx (999999999) → RXOR not found → DPR-DPACCOR-4003
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 for non-existent Rx but got: " + errorCodeResponseSet);

        // Dynamic Rx → DOB matched, OCID not linked → DPR-DPACCOR-2007
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected error code DPR-DPACCOR-2007 for dynamic Rx (no OCID) but got: " + errorCodeResponseSet);
    }

    @Test(
            priority = 11,
            description = "AuthenticateByRx with empty request - Tests service behavior with empty request array. " +
                    "Service accepts empty requests and returns HTTP 200 with empty payload.")
    void authenticateByRxV1EmptyRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Empty request
        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Service accepts empty requests and returns 200 with empty response
        Assert.assertEquals(authenticateByRxV1Response.code(), 200,
                "Service should accept empty request and return HTTP 200");

        // Verify response payload is an empty (non-null) list — service returns empty Flux → empty ArrayList
        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        Assert.assertNotNull(response, "Response payload must not be null for empty request");
        Assert.assertTrue(response.isEmpty(), "Empty request should return empty payload list");
    }

    @Test(
            priority = 12,
            description = "AuthenticateByRx with wrong DOB - CRITICAL authentication test. " +
                    "Uses valid Rx with INCORRECT DOB to test authentication failure. " +
                    "This is the KEY test that validates DOB-based authentication logic.")
    void authenticateByRxV1WrongDOBAuthenticationFailure() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with INCORRECT DOB (different from patient's actual DOB)
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicWrongDob); // WRONG DOB - authentication should fail

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Wrong DOB: validation passes (dob is non-empty), RXOR and CPR find data, DOB comparison fails
        // → buildAuthenticateV1Response sets getDOBMismatchError() → HTTP 206, DPR-DPACCOR-1012
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for DOB mismatch but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());

        // DOB mismatch → getDOBMismatchError() = AUTHENTICATE_RX_DOB_MISMATCH(1012) → DPR-DPACCOR-1012
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-1012"),
                "Expected error code DPR-DPACCOR-1012 for DOB mismatch but got: " + errorCodeResponseSet);

        // authenticationStatus must be INVALID DOB/PTNT STATUS
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "INVALID DOB/PTNT STATUS",
                "Expected authenticationStatus INVALID DOB/PTNT STATUS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 13,
            description = "AuthenticateByRx multi-item with mixed DOB authentication - " +
                    "One item with correct DOB, one with wrong DOB. Tests partial authentication.")
    void authenticateByRxV1MultiItemMixedAuthentication() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build multi-item request: one correct DOB, one wrong DOB
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}]",
                dynamicRxNbr2, dynamicStoreNbr, dynamicDob,         // Correct DOB
                dynamicRxNbr3, dynamicStoreNbr, dynamicWrongDob);   // Wrong DOB

        AuthenticateByRxV1Request request = objectMapper.readValue(payload, AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Expect 206 for mixed authentication results
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for mixed authentication results");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2, "Expected 2 items in response");

        // Find item for dynamicRxNbr2 (correct DOB) and dynamicRxNbr3 (wrong DOB) by rxNbr
        AuthenticateByRxV1Response itemCorrectDob = responseList.stream()
                .filter(item -> dynamicRxNbr2.equals(item.getRxInfo().getRxNbr()))
                .findFirst()
                .orElse(null);
        AuthenticateByRxV1Response itemWrongDob = responseList.stream()
                .filter(item -> dynamicRxNbr3.equals(item.getRxInfo().getRxNbr()))
                .findFirst()
                .orElse(null);

        Assert.assertNotNull(itemCorrectDob, "Expected item for dynamicRxNbr2 in response");
        Assert.assertNotNull(itemWrongDob, "Expected item for dynamicRxNbr3 in response");

        // dynamicRxNbr2 with correct DOB → DOB matches, no linked OCID → DPR-DPACCOR-2007, authStatus=SUCCESS
        Assert.assertNotNull(itemCorrectDob.getError(), "Expected error for item with correct DOB (no linked OCID)");
        Assert.assertEquals(itemCorrectDob.getError().getCode(), "DPR-DPACCOR-2007",
                "Expected DPR-DPACCOR-2007 for correct DOB item but got: " + itemCorrectDob.getError().getCode());
        Assert.assertEquals(itemCorrectDob.getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                "Expected SUCCESS for correct DOB item but got: "
                        + itemCorrectDob.getCustomerInfo().getAuthenticationStatus());

        // dynamicRxNbr3 with wrong DOB → DOB mismatch → DPR-DPACCOR-1012, authStatus=INVALID DOB/PTNT STATUS
        Assert.assertNotNull(itemWrongDob.getError(), "Expected error for item with wrong DOB");
        Assert.assertEquals(itemWrongDob.getError().getCode(), "DPR-DPACCOR-1012",
                "Expected DPR-DPACCOR-1012 for wrong DOB item but got: " + itemWrongDob.getError().getCode());
        Assert.assertEquals(itemWrongDob.getCustomerInfo().getAuthenticationStatus(), "INVALID DOB/PTNT STATUS",
                "Expected INVALID DOB/PTNT STATUS for wrong DOB item but got: "
                        + itemWrongDob.getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 14,
            description = "AuthenticateByRx with invalid DOB format - Tests DOB format validation. " +
                    "Non-numeric DOB should cause error in response payload (HTTP 206 partial success).")
    void authenticateByRxV1InvalidDOBFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with invalid DOB format
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob("ABC123XYZ"); // Invalid: non-numeric

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // "ABC123XYZ" is non-empty → passes validation. RXOR and CPR find the Rx and patient.
        // DOB comparison: CPR DOB vs "ABC123XYZ" → always mismatch → getDOBMismatchError() → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for invalid DOB format but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());

        // DOB mismatch → AUTHENTICATE_RX_DOB_MISMATCH(1012) → DPR-DPACCOR-1012
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-1012"),
                "Expected error code DPR-DPACCOR-1012 for DOB mismatch but got: " + errorCodeResponseSet);

        // authenticationStatus must be INVALID DOB/PTNT STATUS
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "INVALID DOB/PTNT STATUS",
                "Expected authenticationStatus INVALID DOB/PTNT STATUS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 15,
            description = "AuthenticateByRx with invalid rxNbr format - Tests rxNbr format validation. " +
                    "Alphanumeric rxNbr 'ABC123XYZ' passes controller validation (non-empty) but causes RXOR service exception. " +
                    "Expected: HTTP 500, DPR-DPACCOR-4001.")
    void authenticateByRxV1InvalidRxNbrFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with invalid rxNbr format
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr("ABC123XYZ");
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // "ABC123XYZ" passes format validation (non-empty rxNbr, numeric storeNbr, non-empty dob).
        // RXOR call with alphanumeric rxNbr → RXOR service throws exception → HTTP 500, DPR-DPACCOR-4001
        Assert.assertEquals(authenticateByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 for RXOR exception on invalid rxNbr but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 16,
            description = "AuthenticateByRx with invalid storeNbr format - Tests storeNbr validation. " +
                    "Service validates storeNbr format and rejects with HTTP 400.")
    void authenticateByRxV1InvalidStoreNbrFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with invalid storeNbr format
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr("STORE123");
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Service validates storeNbr format — "STORE123" is non-numeric → rejects with HTTP 400
        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
                "Expected error code DPR-DPACCOR-1001 but got: " + errorResponse.getCode());
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Store nbr is null/empty/invalid",
                "Expected exact error message but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 17,
            description = "AuthenticateByRx with special characters in rxNbr - Tests input sanitization.")
    void authenticateByRxV1SpecialCharactersInRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with special characters
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr("12345@#$%");
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 18,
            description = "AuthenticateByRx with very long rxNbr - Tests boundary condition.")
    void authenticateByRxV1VeryLongRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with very long rxNbr
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr("1".repeat(1000));
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(authenticateByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
                "Expected error code DPR-DPACCOR-4001 but got: " + errorResponse.getCode());
    }

    @Test(
            priority = 19,
            description = "AuthenticateByRx with very long DOB - Tests DOB length validation. " +
                    "Service returns HTTP 206 (partial success) or error codes.")
    void authenticateByRxV1VeryLongDOB() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with very long DOB
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob("1".repeat(1000));

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // "1"×1000 is non-empty → passes validation. RXOR and CPR find data.
        // DOB comparison: CPR DOB vs "1111...1" (1000 chars) → always mismatch → getDOBMismatchError() → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for very long DOB but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());

        // DOB mismatch → AUTHENTICATE_RX_DOB_MISMATCH(1012) → DPR-DPACCOR-1012
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-1012"),
                "Expected error code DPR-DPACCOR-1012 for DOB mismatch but got: " + errorCodeResponseSet);

        // authenticationStatus must be INVALID DOB/PTNT STATUS
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "INVALID DOB/PTNT STATUS",
                "Expected authenticationStatus INVALID DOB/PTNT STATUS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 20,
            description = "AuthenticateByRx with special characters in DOB - Tests DOB sanitization. " +
                    "Service returns HTTP 206 (partial success) or error codes.")
    void authenticateByRxV1SpecialCharactersInDOB() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with special characters in DOB
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob("01@01@1990");

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // "01@01@1990" is non-empty → passes validation. RXOR and CPR find data.
        // DOB comparison: CPR DOB vs "01@01@1990" → always mismatch → getDOBMismatchError() → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for special characters in DOB but got: " + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());

        // DOB mismatch → AUTHENTICATE_RX_DOB_MISMATCH(1012) → DPR-DPACCOR-1012
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-1012"),
                "Expected error code DPR-DPACCOR-1012 for DOB mismatch but got: " + errorCodeResponseSet);

        // authenticationStatus must be INVALID DOB/PTNT STATUS
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "INVALID DOB/PTNT STATUS",
                "Expected authenticationStatus INVALID DOB/PTNT STATUS but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 21,
            description = "AuthenticateByRx large multi-item request Part 1 - Tests batch processing with 5 items (3 dynamic Rx + 2 non-existent).")
    void authenticateByRxV1LargeMultiItemRequest_Part1() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request: 3 dynamic Rx + 2 non-existent (5 items)
        StringBuilder payloadBuilder = new StringBuilder("[");
        payloadBuilder.append(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"},",
                dynamicRxNbr1, dynamicStoreNbr, dynamicDob));
        payloadBuilder.append(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"},",
                dynamicRxNbr2, dynamicStoreNbr, dynamicDob));
        payloadBuilder.append(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"},",
                dynamicRxNbr3, dynamicStoreNbr, dynamicDob));

        for (int i = 0; i < 2; i++) {
            payloadBuilder.append(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}",
                    "99999999" + i, dynamicStoreNbr, dynamicDob));
            if (i < 1) payloadBuilder.append(",");
        }
        payloadBuilder.append("]");

        AuthenticateByRxV1Request request = objectMapper.readValue(payloadBuilder.toString(),
                AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for multi-item partial success");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 5, "Expected 5 items in response");

        // Build sets for distinguishing non-existent vs dynamic Rx items
        Set<String> nonExistentRxNbrs = new HashSet<>(Arrays.asList("999999990","999999991"));
        Set<String> dynamicRxNbrs = new HashSet<>(Arrays.asList(dynamicRxNbr1, dynamicRxNbr2, dynamicRxNbr3));

        // 2 non-existent Rx items: RXOR not found → DPR-DPACCOR-4003, authStatus=INVALID RX/STORE
        responseList.stream()
                .filter(item -> nonExistentRxNbrs.contains(item.getRxInfo().getRxNbr()))
                .forEach(item -> {
                    Assert.assertNotNull(item.getError(),
                            "Expected error for non-existent Rx: " + item.getRxInfo().getRxNbr());
                    Assert.assertEquals(item.getError().getCode(), "DPR-DPACCOR-4003",
                            "Expected DPR-DPACCOR-4003 for non-existent Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getError().getCode());
                    Assert.assertEquals(item.getCustomerInfo().getAuthenticationStatus(), "INVALID RX/STORE",
                            "Expected INVALID RX/STORE for non-existent Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getCustomerInfo().getAuthenticationStatus());
                });

        // 3 dynamic Rx items: DOB matched, no linked OCID → DPR-DPACCOR-2007, authStatus=SUCCESS
        responseList.stream()
                .filter(item -> dynamicRxNbrs.contains(item.getRxInfo().getRxNbr()))
                .forEach(item -> {
                    Assert.assertNotNull(item.getError(),
                            "Expected error for dynamic Rx (no OCID): " + item.getRxInfo().getRxNbr());
                    Assert.assertEquals(item.getError().getCode(), "DPR-DPACCOR-2007",
                            "Expected DPR-DPACCOR-2007 for dynamic Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getError().getCode());
                    Assert.assertEquals(item.getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                            "Expected SUCCESS for dynamic Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getCustomerInfo().getAuthenticationStatus());
                });
    }

    @Test(
            priority = 22,
            description = "AuthenticateByRx large multi-item request Part 2 - Tests batch processing with 5 items (all non-existent).")
    void authenticateByRxV1LargeMultiItemRequest_Part2() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request: 0 dynamic Rx + 5 non-existent (5 items)
        StringBuilder payloadBuilder = new StringBuilder("[");
        for (int i = 2; i < 7; i++) {  // Start from index 2 to continue from Part1
            payloadBuilder.append(String.format("{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}",
                    "99999999" + i, dynamicStoreNbr, dynamicDob));
            if (i < 6) payloadBuilder.append(",");
        }
        payloadBuilder.append("]");

        AuthenticateByRxV1Request request = objectMapper.readValue(payloadBuilder.toString(),
                AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for all-error multi-item request");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 5, "Expected 5 items in response");

        // Build set for non-existent Rx items
        Set<String> nonExistentRxNbrs = new HashSet<>(
                Arrays.asList("999999992","999999993","999999994","999999995","999999996"));

        // All 5 non-existent Rx items: RXOR not found → DPR-DPACCOR-4003, authStatus=INVALID RX/STORE
        responseList.stream()
                .filter(item -> nonExistentRxNbrs.contains(item.getRxInfo().getRxNbr()))
                .forEach(item -> {
                    Assert.assertNotNull(item.getError(),
                            "Expected error for non-existent Rx: " + item.getRxInfo().getRxNbr());
                    Assert.assertEquals(item.getError().getCode(), "DPR-DPACCOR-4003",
                            "Expected DPR-DPACCOR-4003 for non-existent Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getError().getCode());
                    Assert.assertEquals(item.getCustomerInfo().getAuthenticationStatus(), "INVALID RX/STORE",
                            "Expected INVALID RX/STORE for non-existent Rx " + item.getRxInfo().getRxNbr()
                                    + " but got: " + item.getCustomerInfo().getAuthenticationStatus());
                });
    }

    @Test(
            priority = 23,
            description = "AuthenticateByRx with duplicate Rx - Tests duplicate handling with same DOB.")
    void authenticateByRxV1DuplicateRxMultiItem() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with duplicate Rx
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}]",
                dynamicRxNbr1, dynamicStoreNbr, dynamicDob,
                dynamicRxNbr1, dynamicStoreNbr, dynamicDob); // Same Rx twice

        AuthenticateByRxV1Request request = objectMapper.readValue(payload, AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        // Both items use same dynamic Rx with correct DOB — DOB matches, but no linked OCID → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 (auth success but no linked OCID for both duplicate items) but got: "
                        + authenticateByRxV1Response.code());

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2, "Expected 2 items in response for duplicate Rx");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> authStatusSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getCustomerInfo()))
                .map(item -> item.getCustomerInfo().getAuthenticationStatus())
                .collect(Collectors.toSet());

        // Both duplicate items: DOB matched, no OCID → DPR-DPACCOR-2007
        Assert.assertEquals(errorCodeResponseSet.size(), 1,
                "Expected exactly one distinct error code for duplicate items but got: " + errorCodeResponseSet);
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected DPR-DPACCOR-2007 for both duplicate items but got: " + errorCodeResponseSet);

        // Both items must have authenticationStatus SUCCESS (DOB matched)
        Assert.assertEquals(authStatusSet.size(), 1,
                "Expected exactly one distinct authenticationStatus for duplicate items but got: " + authStatusSet);
        Assert.assertTrue(authStatusSet.contains("SUCCESS"),
                "Expected SUCCESS for both duplicate items but got: " + authStatusSet);
    }

    @Test(
            priority = 24,
            description = "AuthenticateByRx same Rx with different DOBs - Tests authentication with different DOBs.")
    void authenticateByRxV1SameRxDifferentDOBs() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request: same Rx with correct and wrong DOB
        String payload = String.format(
                "[{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}," +
                        "{\"rxNbr\":\"%s\",\"storeNbr\":\"%s\",\"dob\":\"%s\"}]",
                dynamicRxNbr1, dynamicStoreNbr, dynamicDob,         // Correct DOB
                dynamicRxNbr1, dynamicStoreNbr, dynamicWrongDob);   // Wrong DOB

        AuthenticateByRxV1Request request = objectMapper.readValue(payload, AuthenticateByRxV1Request.class);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(authenticateByRxV1Response.code(), 206,
                "Expected HTTP 206 for mixed authentication results");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 2, "Expected 2 items in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());
        Set<String> authStatusSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getCustomerInfo()))
                .map(item -> item.getCustomerInfo().getAuthenticationStatus())
                .collect(Collectors.toSet());

        // Item with correct DOB (dynamicDob): DOB matched, no linked OCID → DPR-DPACCOR-2007, authStatus=SUCCESS
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-2007"),
                "Expected DPR-DPACCOR-2007 for correct DOB item but got: " + errorCodeResponseSet);
        Assert.assertTrue(authStatusSet.contains("SUCCESS"),
                "Expected SUCCESS authenticationStatus for correct DOB item but got: " + authStatusSet);

        // Item with wrong DOB (dynamicWrongDob): DOB mismatch → DPR-DPACCOR-1012, authStatus=INVALID DOB/PTNT STATUS
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-1012"),
                "Expected DPR-DPACCOR-1012 for wrong DOB item but got: " + errorCodeResponseSet);
        Assert.assertTrue(authStatusSet.contains("INVALID DOB/PTNT STATUS"),
                "Expected INVALID DOB/PTNT STATUS for wrong DOB item but got: " + authStatusSet);
    }

    @Test(
            priority = 25,
            description = "AuthenticateByRx with lowercase domain - Tests domain case sensitivity behaviour. " +
                    "Service enum lookup is case-insensitive for 'wm-pharmacy' → passes controller validation " +
                    "→ forwarded to Account Entity Service (AE) which IS case-sensitive → AE returns 500 " +
                    "→ orchestrator wraps as HTTP 500, DPR-DPACCOR-2003.")
    void authenticateByRxV1LowercaseDomain() throws IOException {
        String domainId = "wm-pharmacy"; // lowercase — passes controller enum lookup but AE rejects it
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // "wm-pharmacy" passes orchestrator enum validation (case-insensitive) but Account Entity Service
        // is case-sensitive — rejects the domain → orchestrator wraps the AE 500 as DPR-DPACCOR-2003.
        Assert.assertEquals(authenticateByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2003",
                "Expected error code DPR-DPACCOR-2003 (AE downstream failure) but got: " + errorResponse.getCode());
        Assert.assertTrue(errorResponse.getMessage().contains("Account Entity Service"),
                "Expected message to mention Account Entity Service but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 26,
            description = "AuthenticateByRx with mixed-case domain - Tests domain case sensitivity behaviour. " +
                    "Service enum lookup is case-insensitive for 'Wm-PhArMaCy' → passes controller validation " +
                    "→ forwarded to Account Entity Service (AE) which IS case-sensitive → AE returns 500 " +
                    "→ orchestrator wraps as HTTP 500, DPR-DPACCOR-2003.")
    void authenticateByRxV1MixedCaseDomain() throws IOException {
        String domainId = "Wm-PhArMaCy"; // mixed case — passes controller enum lookup but AE rejects it
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // "Wm-PhArMaCy" passes orchestrator enum validation (case-insensitive) but Account Entity Service
        // is case-sensitive — rejects the domain → orchestrator wraps the AE 500 as DPR-DPACCOR-2003.
        Assert.assertEquals(authenticateByRxV1Response.code(), 500, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-2003",
                "Expected error code DPR-DPACCOR-2003 (AE downstream failure) but got: " + errorResponse.getCode());
        Assert.assertTrue(errorResponse.getMessage().contains("Account Entity Service"),
                "Expected message to mention Account Entity Service but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 27,
            description = "AuthenticateByRx with negative rxNbr - Tests boundary condition.")
    void authenticateByRxV1NegativeRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with negative rxNbr
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr("-12345");
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // "-12345" is non-empty → passes rxNbr validation. RXOR lookup with "-12345" → Rx not found in upstream
        // → buildAuthenticateV1Response sets INVALID RX/STORE + DPR-DPACCOR-4003 → HTTP 206
        Assert.assertEquals(authenticateByRxV1Response.code(), 206, errorMessage);

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        Set<String> errorCodeResponseSet = responseList.stream()
                .filter(item -> Objects.nonNull(item.getError()))
                .map(item -> item.getError().getCode())
                .collect(Collectors.toSet());

        // Rx not found in upstream → DPR-DPACCOR-4003
        Assert.assertTrue(errorCodeResponseSet.contains("DPR-DPACCOR-4003"),
                "Expected error code DPR-DPACCOR-4003 (Rx Not Found) for negative rxNbr but got: " + errorCodeResponseSet);

        // authenticationStatus must be INVALID RX/STORE
        Assert.assertEquals(responseList.get(0).getCustomerInfo().getAuthenticationStatus(), "INVALID RX/STORE",
                "Expected authenticationStatus INVALID RX/STORE but got: "
                        + responseList.get(0).getCustomerInfo().getAuthenticationStatus());
    }

    @Test(
            priority = 28,
            description = "AuthenticateByRx full success — WM-PHARMACY, single item, linked patient (OCID pre-set in AE). "
                    + "Service Branch A: RXOR found → CPR patientInfo non-null → DOB matches + ACTIVE status (20700) "
                    + "→ authStatus=true → ACCEN returns onlineAccountId (linkedCid) → customerAccountId set "
                    + "→ applyExecutionState COMPLETE → HTTP 200. No per-item error. "
                    + "fillQuantity populated (buildAuthenticateRxInfo called when authStatus=true). "
                    + "AE WM-PHARMACY mapping (linkedCid → linkedPatientId) written in @BeforeClass "
                    + "via createDigitalPharmacyConnectedStorePatientAccount + enableTestAccountInQa.")
    void authenticateByRxV1FullSuccessWithLinkedOcid() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Use linked patient Rx with CORRECT DOB — authStatus=true → ACCEN called → OCID returned → HTTP 200
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(linkedRxNbr);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(linkedDob); // CORRECT DOB — must match CPR patient DOB

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error topLevelError = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(topLevelError);

        // Branch A: authStatus=true + OCID found → all items COMPLETE → applyExecutionState → HTTP 200
        Assert.assertEquals(authenticateByRxV1Response.code(), 200, errorMessage);

        // No top-level error in response body for HTTP 200 full success
        Assert.assertNull(authenticateByRxV1Response.body().getError(),
                "Top-level error must be null for HTTP 200 full success response");

        ArrayList<Object> response = (ArrayList<Object>) authenticateByRxV1Response.body().getPayload();
        List<AuthenticateByRxV1Response> responseList = extractAuthenticateByRxV1ResponsePayload(response);

        Assert.assertEquals(responseList.size(), 1, "Expected 1 item in response");

        AuthenticateByRxV1Response item = responseList.get(0);

        // No per-item error — Branch A: RXOR + CPR + OCID all succeeded, no error path triggered
        Assert.assertNull(item.getError(),
                "Per-item error must be null — Branch A: onlineAccountId non-null, "
                        + "no error set in buildAuthenticateV1Response");

        // customerAccountId = onlineAccountId from Account Entity → must equal linkedCid
        Assert.assertEquals(item.getCustomerInfo().getCustomerAccountId(), linkedCid,
                "customerAccountId must equal linkedCid (= OCP onlineAccountId from Account Entity) "
                        + "— OCID returned by ACCEN and set in customerInfoBuilder");

        // authenticationStatus must be SUCCESS (dobMatch=true + patientStatusMatch=true)
        Assert.assertEquals(item.getCustomerInfo().getAuthenticationStatus(), "SUCCESS",
                "Expected authenticationStatus SUCCESS but got: "
                        + item.getCustomerInfo().getAuthenticationStatus());

        // fillQuantity must be populated — buildAuthenticateRxInfo is called when authStatus=true
        Assert.assertNotNull(item.getRxInfo().getFillQuantity(),
                "fillQuantity must be non-null — buildAuthenticateRxInfo is called when authStatus=true "
                        + "(includes full Rx details: fillQuantity, patientId, dispensedDate, etc.)");

        // patientId must be returned — populated from CPR via buildAuthenticateRxInfo
        Assert.assertNotNull(item.getRxInfo().getPatientId(),
                "patientId must be non-null — set from CPR patientInfo in buildAuthenticateRxInfo");
    }

    @Test(
            priority = 30,
            description = "AuthenticateByRx with empty string rxNbr - Tests validation edge case. "
                    + "Empty string ('') triggers StringUtils.isEmpty() just like null. "
                    + "validateLookupByRxRequest: StringUtils.isEmpty('') = true → 'Rx nbr is null/empty' "
                    + "→ INVALID_REQUEST_EXCEPTION(1001) → HTTP 400, DPR-DPACCOR-1001.")
    void authenticateByRxV1EmptyStringRxNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with empty string rxNbr (distinct from P2 which uses null)
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(""); // Empty string — StringUtils.isEmpty("") = true → same path as null
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // validateLookupByRxRequest: StringUtils.isEmpty("") = true → "Rx nbr is null/empty"
        // → AccountOrchestratorRuntimeException(1001) → HTTP 400
        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
                "Expected error code DPR-DPACCOR-1001 for empty rxNbr but got: " + errorResponse.getCode());
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Rx nbr is null/empty",
                "Expected exact error message 'Rx nbr is null/empty' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 31,
            description = "AuthenticateByRx with empty string storeNbr - Tests validation edge case. "
                    + "Empty string ('') fails StringUtils.isNumeric() check (isNumeric('') = false). "
                    + "validateLookupByRxRequest: !StringUtils.isNumeric('') = true → 'Store nbr is null/empty/invalid' "
                    + "→ INVALID_REQUEST_EXCEPTION(1001) → HTTP 400, DPR-DPACCOR-1001.")
    void authenticateByRxV1EmptyStringStoreNbr() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with empty string storeNbr (distinct from P3 which uses null)
        // StringUtils.isNumeric("") = false → "Store nbr is null/empty/invalid" (same as null)
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(""); // Empty string — StringUtils.isNumeric("") = false
        requestObject.setDob(dynamicDob);

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // validateLookupByRxRequest: StringUtils.isNumeric("") = false → "Store nbr is null/empty/invalid"
        // → AccountOrchestratorRuntimeException(1001) → HTTP 400
        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
                "Expected error code DPR-DPACCOR-1001 for empty storeNbr but got: " + errorResponse.getCode());
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Store nbr is null/empty/invalid",
                "Expected exact error message 'Store nbr is null/empty/invalid' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 32,
            description = "AuthenticateByRx with empty string dob - Tests DOB validation edge case. "
                    + "Empty string ('') triggers StringUtils.isEmpty() just like null. "
                    + "validateAuthenticateByRxRequest: validateLookupByRxRequest passes (rxNbr non-empty, "
                    + "storeNbr numeric), then StringUtils.isEmpty('') = true → 'dob is null/empty' "
                    + "→ INVALID_REQUEST_EXCEPTION(1001) → HTTP 400, DPR-DPACCOR-1001.")
    void authenticateByRxV1EmptyStringDob() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Build request with empty string dob (distinct from P4 which uses null)
        AuthenticateByRxV1RequestObject requestObject = new AuthenticateByRxV1RequestObject();
        requestObject.setRxNbr(dynamicRxNbr1);
        requestObject.setStoreNbr(dynamicStoreNbr);
        requestObject.setDob(""); // Empty string — StringUtils.isEmpty("") = true → same path as null

        AuthenticateByRxV1Request request = new AuthenticateByRxV1Request();
        request.add(requestObject);

        Response<ServiceResponse> authenticateByRxV1Response =
                accountOrchestratorRetrofit.authenticateByRxV1(domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, authenticateByRxV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // validateAuthenticateByRxRequest: validateLookupByRxRequest passes (rxNbr non-empty, storeNbr numeric)
        // then StringUtils.isEmpty("") = true → "dob is null/empty"
        // → AccountOrchestratorRuntimeException(1001) → HTTP 400
        Assert.assertEquals(authenticateByRxV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
                "Expected error code DPR-DPACCOR-1001 for empty dob but got: " + errorResponse.getCode());
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. dob is null/empty",
                "Expected exact error message 'dob is null/empty' but got: " + errorResponse.getMessage());
    }

    /**
     * Creates a dynamic Rx prescription using Connexus Wrapper API.
     * Aligned with LookupByRxTest pattern: DB query → fetchDrugInfo → getDrugInfo → newOrderToEOD(DataRow).
     *
     * Steps:
     * 1. Query database for available drug by control code (with inventory > 0)
     * 2. Fetch drug details using fetchDrugInfo API
     * 3. Get full drug info from Connexus DB for newOrderToEOD
     * 4. Create Rx order via newOrderToEOD
     * 5. Parse and return rxNumber
     *
     * @param storeId Store number as integer
     * @param patientId Patient ID from Connexus
     * @param description Log description for this Rx
     * @return Generated rxNumber as String
     */
    private String createDynamicRx(int storeId, int patientId, String description) throws Exception {
        // Step 1: Query database for available drug by control code with inventory
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);

        // Query for a drug with the specified control code and available inventory (on_hand_qty > 0)
        // Note: Informix syntax uses "FIRST n" not "TOP n"
        String queryDrug = "SELECT FIRST 1 pi.ndc_nbr, pi.on_hand_qty " +
                "FROM pharmacy_offering:pharmacy_product AS pp, " +
                "     pharmacy_offering:pharmacy_item AS pi " +
                "WHERE pp.product_mds_fam_id = pi.product_mds_fam_id " +
                "  AND pp.drug_control_code = '" + CONTROL_CODE + "' " +
                "  AND pi.on_hand_qty > 0 " +
                "ORDER BY pi.ndc_nbr";

        DataTable drugTable = cnx.getDataTable(queryDrug);
        Assert.assertTrue(drugTable.getRowCount() > 0,
                "No drugs found in DB for store " + storeId + " with controlCode " + CONTROL_CODE + " and inventory > 0");

        DataRow drugRow = drugTable.getDataRows().get(0);
        String ndc = drugRow.getValue("ndc_nbr").toString().trim();
        int onHandQty = Integer.parseInt(drugRow.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", ""));

        // Step 2: Fetch drug details using Connexus wrapper API
        FetchDrug fetchDrugPayload = new FetchDrug();
        fetchDrugPayload.setSiteId(String.valueOf(storeId));
        fetchDrugPayload.setNdc(ndc);

        Drug drug = wrapperAPIManager.fetchDrugInfo(fetchDrugPayload);
        Assert.assertNotNull(drug, "fetchDrugInfo returned null for NDC: " + ndc);

        // Step 3: Get full drug info from Connexus DB for newOrderToEOD
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, ndc);
        Assert.assertNotNull(drugInfo, "Drug info not found in Connexus DB for NDC: " + ndc);

        // Step 4: Create Rx order via newOrderToEOD
        String pickupDate = wrapperUtils.getPickUpDate();
        String rxExpDate = wrapperUtils.getExpiryDate();

        // Note: Using fully qualified name to avoid conflict with Account Orchestrator's ServiceResponse
        com.walmart.hwqe.commons.apicontext.ServiceResponse newOrderResp = wrapperAPIManager.newOrderToEOD(
                REQUEST_TYPE_CODE, PRIORITY_ID, DISPENSE_TYPE,
                patientId, storeId, pickupDate, rxExpDate, NUM_REFILLS, drugInfo);

        Assert.assertEquals(newOrderResp.getStatusCode(), 201,
                "newOrderToEOD failed — status: " + newOrderResp.getStatusCode()
                        + " | response: " + newOrderResp.getDataResponse());

        // Step 5: Parse rxNumber from Success[0].rxNbr
        JsonObject responseJson = gson.fromJson(newOrderResp.getDataResponse(), JsonObject.class);
        JsonArray successArray = responseJson.getAsJsonArray("Success");
        Assert.assertNotNull(successArray, "newOrderToEOD response missing 'Success' array");
        Assert.assertFalse(successArray.size() == 0, "newOrderToEOD 'Success' array is empty");

        String rxNumber = String.valueOf(successArray.get(0).getAsJsonObject().get("rxNbr").getAsInt());

        return rxNumber;
    }

    /**
     * Builds AddPatient object for Connexus patient creation
     */
    private AddPatient buildAddPatient(int storeId, String dobDotNet) {
        AddPatient patient = new AddPatient();
        patient.setSiteID(storeId);
        patient.setCommunicationID("5555555555");
        patient.setFirstName(dynamicFirstName);
        patient.setLastName(dynamicLastName);
        patient.setMiddleName("");
        patient.setPatientName(dynamicLastName + "," + dynamicFirstName);
        patient.setDob(dobDotNet); // CRITICAL - This stores the authentication key
        patient.setGender("F");
        patient.setLanguage("101");
        patient.setStatus(20700);
        patient.setIsPatientMinor(false);
        patient.setAddressTypeCode(3);
        patient.setVerifyFreCode(1);
        patient.setPatientTypeCode(10200); // Human
        patient.setUserId("APITEST");
        patient.setAddressLine1("123 Test St");
        patient.setAddressLine2("");
        patient.setCity("Bentonville");
        patient.setState("AR");
        patient.setZipCode("72712");
        patient.setCountry("USA");
        patient.setHomePhone("5555555555");
        patient.setCellPhone("5555555555");
        patient.setWorkPhone("");

        return patient;
    }

    /**
     * Extracts AuthenticateByRxV1Response list from response payload
     */
    private List<AuthenticateByRxV1Response> extractAuthenticateByRxV1ResponsePayload(ArrayList<Object> payload) {
        return payload.stream()
                .map(profile -> gson.fromJson(gson.toJson(profile), AuthenticateByRxV1Response.class))
                .collect(Collectors.toList());
    }
}

