package accountorchestrator.customer;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.IsSMSEnrolledV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class AccountOrchestratorCustomerTestFlow {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private WCPRetroFit wcpRetroFit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonCustomerAccountId = null;
  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonPhoneNbr = null;
  private String commonDobDPFormat = null;
  private String commonDomainId = null;
  ValidationServiceRequest cprPatientRequest = null;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    wcpRetroFit = new WCPRetroFit();

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    commonPhoneNbr = CommonUtil.generateRandomNumber(10);
    commonDomainId = "WM-PHARMACY";

    createCPRAccount();
    createSMSEnrollment();
    commonCustomerAccountId =CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(CommonUtil.generateRandomEmailId(10));
    createPharmacyAccountEntity();
  }

  @AfterClass
  void cleanUp() throws IOException {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setPatientStatusCode(20708);
    Response<ValidationServiceResponse> response =
            cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
    if (!(response.code() == 202
            && response.body() != null
            && response.body().getErrors().isEmpty())) {
      throw new RuntimeException(
              "CPR Account failed to update with status code 20708 for PatientId "
                      + commonPatientId
                      + " . HttpStatusCode : "
                      + response.code());
    }
  }

  public void createCPRAccount() throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(commonStoreNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setBirthDate("1990-10-10");
    cprPatientRequest.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5));
    cprPatientRequest.getPatientInfo().setLastName(RandomStringUtils.randomAlphabetic(5));

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Call DM Post Preferences API to link above created store number and patient Id with new phone
   * number
   *
   * @throws IOException
   */
  public void createSMSEnrollment() throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
            DMPostPreferencesRequest.builder()
                    .storeNbr(commonStoreNbr)
                    .zipCode("96898")
                    .userId("SIGPAD")
                    .storePhone("8009666546")
                    .patientId(commonPatientId)
                    .timeStamp(timestamp)
                    .language("101")
                    .preferences(
                            org.openjdk.tools.javac.util.List.of(
                                    DMPostPreferencesRequest.Preference.builder()
                                            .notification_type("1")
                                            .notification_val(commonPhoneNbr)
                                            .short_code_type_id("1")
                                            .enrollment_status_code("26805")
                                            .build()))
                    .build();

    Response<DMPostPreferencesResponse> response =
            dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
            && response.body() != null
            && response.body().getResponseStatus() != null
            && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
              "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }

  public void createPharmacyAccountEntity() throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            CreatePharmacyAccountV1Request.builder()
                    .customerInfo(
                            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                    .dob("10101990")
                                    .storeNbr(commonStoreNbr)
                                    .patientId(commonPatientId)
                                    .build())
                    .accountCreationSource("idVerification")
                    .build();

    // This will try to create an account in Account Entity 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
              response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      commonCustomerAccountId,
                      commonDomainId,
                      createPharmacyAccountV1Request,
                      CommonUtil.randomUUID(),
                      CommonUtil.randomUUID());
      if (!(response.code() == 200 && response.body() != null)) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account creation failed in Account Entity. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  @Test(
      priority = 0,
      description = "Get sms enrolled profile list success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledProfileListV1Req")
  public void getSMSEnrolledProfileListV1RequestSuccess(
      String domainId, String type, String phoneNumber) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with a valid phoneNumber,valid
    // customerAccountId,valid domainId
    Response<ServiceResponse> getSMSEnrolledProfileListV1Response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            commonCustomerAccountId, domainId, commonPhoneNbr, reqId, reqTrackingId, type);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getSMSEnrolledProfileListV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getSMSEnrolledProfileListV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(
        getSMSEnrolledProfileListV1Response.body().getPayload(), "Payload is null");
  }

  @Test(
      priority = 1,
      description = "Get sms enrolled profile list invalid request case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledProfileListV1Req")
  public void getSMSEnrolledProfileListV1InvalidRequest(
      String domainId, String type, String phoneNumber) throws IOException {

    // *****  CASE 1 - Type is invalid *****
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    String invalidType = "ADUL";
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, commonPhoneNbr, invalidType, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with a valid phoneNumber,valid
    // customerAccountId,valid domainId and invalid type
    Response<ServiceResponse> getSMSEnrolledProfileListV1Response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            commonCustomerAccountId, domainId, commonPhoneNbr, reqId, reqTrackingId, invalidType);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getSMSEnrolledProfileListV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getSMSEnrolledProfileListV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Invalid input request . type is not ADULT");

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, invalidDomainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with a valid phoneNumber,valid
    // customerAccountId,invalid domainId and valid type
    getSMSEnrolledProfileListV1Response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            commonCustomerAccountId, invalidDomainId, commonPhoneNbr, reqId, reqTrackingId, type);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getSMSEnrolledProfileListV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getSMSEnrolledProfileListV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");

    // *****  CASE 3 - phoneNbr is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls

    String invalidPhnNbr = CommonUtil.generateRandomNumber(9);
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, invalidPhnNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with an invalid phoneNumber,valid
    // customerAccountId,valid domainId and valid type
    getSMSEnrolledProfileListV1Response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            commonCustomerAccountId, domainId, invalidPhnNbr, reqId, reqTrackingId, type);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getSMSEnrolledProfileListV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getSMSEnrolledProfileListV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request . phoneNbr is null/Invalid length");
  }

  @Test(
      priority = 2,
      description =
          "Get SMS Enrolled Profile List API call 404 found case where 404 is returned from DM for given phoneNbr",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledProfileListV1Req")
  public void getSMSEnrolledProfileListRequest404FromDM(
      String domainId, String type, String phoneNumber) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    String phnNbr = CommonUtil.generateRandomNumber(10);

    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, phnNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with a phnNbr which doesn't exists in DM
    Response<ServiceResponse> getSMSEnrolledProfileListV1Response =
        accountOrchestratorRetrofit.getSMSEnrolledProfileListV1(
            commonCustomerAccountId, domainId, phnNbr, reqId, reqTrackingId, type);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getSMSEnrolledProfileListV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getSMSEnrolledProfileListV1Response.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-8001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "No Content returned from DM Preference service for given input request.");
  }

  @Test(
      priority = 3,
      description = "Get is sms enrolled success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledV1Request")
  public void getIsSMSEnrolledV1RequestSuccess(String domainId, String type, String phoneNumber)
      throws IOException {

    // *****  CASE 1 - Account exists for a given phoneNbr *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with a valid phoneNumber,valid
    // customerAccountId,valid domainId
    Response<ServiceResponse> getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, domainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the IsSMSEnrolledV1Response class so that we can assert
    // isSMSEnrolled
    IsSMSEnrolledV1Response isSMSEnrolledV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getIsSMSEnrolledV1Response.body().getPayload()),
            IsSMSEnrolledV1Response.class);

    Assert.assertNotNull(isSMSEnrolledV1Response.isIsSMSEnrolled(), "isSMSEnrolled found null");
    Assert.assertEquals(isSMSEnrolledV1Response.isIsSMSEnrolled(), Boolean.TRUE);

    // *****  CASE 2 - Account doesn't exists for a given phoneNbr *****
    // Step - 1: Generate random phoneNbr
    String phoneNbr = CommonUtil.generateRandomNumber(10);
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, phoneNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with a valid phoneNumber,valid
    // customerAccountId,valid domainId
    getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, domainId, phoneNbr, type, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the IsSMSEnrolledV1Response class so that we can assert
    // isSMSEnrolled
    IsSMSEnrolledV1Response isSMSEnrolledV1Response1 =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getIsSMSEnrolledV1Response.body().getPayload()),
            IsSMSEnrolledV1Response.class);

    Assert.assertNotNull(isSMSEnrolledV1Response1.isIsSMSEnrolled(), "isSMSEnrolled found null");
    Assert.assertEquals(isSMSEnrolledV1Response1.isIsSMSEnrolled(), Boolean.FALSE);
  }

  @Test(
      priority = 4,
      description = "Get is sms enrolled invalid request case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledV1Request")
  public void getIsSMSEnrolledV1InvalidRequest(String domainId, String type, String phoneNumber)
      throws IOException {

    // *****  CASE 1 - Type is invalid *****
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    String invalidType = "ADUL";
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, commonPhoneNbr, invalidType, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with a valid phoneNumber,valid
    // customerAccountId,valid domainId and invalid type
    Response<ServiceResponse> getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, domainId, commonPhoneNbr, invalidType, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Invalid input request . type is not ADULT");

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, invalidDomainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with a valid phoneNumber,valid
    // customerAccountId,invalid domainId and valid type
    getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, invalidDomainId, commonPhoneNbr, type, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");

    // *****  CASE 4 - phoneNbr is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls

    String invalidPhnNbr = CommonUtil.generateRandomNumber(9);
    CommonUtil.logFlowIdentifiers(
        commonCustomerAccountId, domainId, invalidPhnNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with an invalid phoneNumber,valid
    // customerAccountId,valid domainId and valid type
    getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, domainId, invalidPhnNbr, type, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request . phoneNbr is null/Invalid length");
  }

  @Test(
      priority = 5,
      description =
          "Get is SMS Enrolled API call 404 found case where 404 is returned from DM for given phoneNbr",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData.xlsx",
      sheetName = "getSMSEnrolledV1Request")
  public void getIsSMSEnrolledV1Request404FromDM(String domainId, String type, String phoneNumber)
      throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    String phnNbr = CommonUtil.generateRandomNumber(10);

    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, phnNbr, type, reqId, reqTrackingId);

    // Step - 2: Calling getIsSMSEnrolledV1 with a phnNbr which doesn't exists in DM
    Response<ServiceResponse> getIsSMSEnrolledV1Response =
        accountOrchestratorRetrofit.isSMSEnrolledV1(
            commonCustomerAccountId, domainId, phnNbr, type, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the IsSMSEnrolledV1Response class so that we can assert
    // isSMSEnrolled
    IsSMSEnrolledV1Response isSMSEnrolledV1Response1 =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getIsSMSEnrolledV1Response.body().getPayload()),
            IsSMSEnrolledV1Response.class);

    Assert.assertEquals(isSMSEnrolledV1Response1.isIsSMSEnrolled(), Boolean.FALSE);
  }
}
