package accountorchestrator.customer;

import accountorchestrator.utils.CommonAccountHelper;
import static accountorchestrator.constants.AccountOrchestratorConstants.*;
import java.time.LocalDate;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.GetCustomerInfoByRxV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetCustomerInfoByRxV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.request.PharmaAuthPatientIdStoreNbrRequest;

import static com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo.LinkageStatusEnum.ACTIVE;
import static com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo.LinkageStatusEnum.APPROVED;
import static com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo.LinkageStatusEnum.REJECTED;
import static com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo.TypeEnum.ADULT;
import static com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo.TypeEnum.MINOR;

public class AccountOrchestratorGetCustomerInfoByRxTest {

  public Gson gson = new Gson();
  AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
  DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
  String caregiverEmail;
  private WCPRetroFit wcpRetroFit;
  private String reqId = reqIdString;
  private String reqTrackingId = reqTrackingString;
  private String caregiverFirstName;
  private String caregiverLastName;
  private String caregiverCid;
  private String caregiverPatientId;
  private String dependent1FirstName;
  private String dependent1LastName;
  private String dependent1Email;
  private String dependent1Cid;
  private String dependent1PatientId;
  private String dependent2FirstName;
  private String dependent2LastName;
  private String dependent2Email;
  private String dependent2Cid;
  private String dependent2PatientId;
  private String dependent3FirstName;
  private String dependent3LastName;
  private String dependent3Email;
  private String dependent3Cid;
  private String dependent3PatientId;
  // dependent4 — ADULT linked with APPROVED linkage status
  private String dependent4FirstName;
  private String dependent4LastName;
  private String dependent4Email;
  private String dependent4Cid;
  private String dependent4PatientId;
  // dependent5 — ADULT linked with REJECTED linkage status
  private String dependent5FirstName;
  private String dependent5LastName;
  private String dependent5Email;
  private String dependent5Cid;
  private String dependent5PatientId;
  // dependentFemale — Female adult, not linked to caregiver
  private String dependentFemaleFirstName;
  private String dependentFemaleLastName;
  private String dependentFemaleEmail;
  private String dependentFemaleCid;
  private String dependentFemalePatientId;
  private String domainId = PHARMACY_DOMAIN_ID;
  private String commonStore = TEST_STORE_NBR;
  private String commonDobForAdult = "0101" + LocalDate.now().minusYears(20).getYear();
  private String commonDobForMinor = "0101" + LocalDate.now().minusYears(5).getYear();
  private String commonPassword = generatePassword();
  private String rxNbr1;
  private String rxNbr2;
  private String rxNbr3;
  private String rxNbr4;
  private String rxNbr5;
  private String rxNbrFemale;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private String cooldownPatientId;
  private String cooldownRxNbr;
  private String noOcidFirstName;
  private String noOcidLastName;
  private String noOcidPatientId;
  private String noOcidRxNbr;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    pharmacyAuthServiceRetrofit = new PharmacyAuthServiceRetrofit();
    String phoneNumber = CommonUtil.generateRandomPhoneNo(10);

    // caregiver
    caregiverEmail = CommonUtil.generateRandomEmailId(10);
    caregiverFirstName = CommonUtil.generateRandomFirstName(5);
    caregiverLastName = CommonUtil.generateRandomLastName(5);

    DigitalPharmacyOperationsUtil caregiverObj =
        new DigitalPharmacyOperationsUtil(
            Integer.parseInt(commonStore),
            caregiverFirstName,
            caregiverLastName,
            commonDobForAdult,
            0,
            caregiverEmail,
            commonPassword);
    caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
    caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
    caregiverPatientId =
        ""
            + digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                caregiverObj.getPatientFirstName(),
                caregiverObj.getPatientLastName(),
                caregiverObj.getDates().get(1),
                caregiverObj.getStoreId() + "");
    digitalPharmacyOperationsUtil.enableTestAccountInQa(
        caregiverCid,
        caregiverObj.getStoreId() + "",
        caregiverPatientId,
        caregiverObj.getPatientDob());

    // dependent1
    dependent1Email = CommonUtil.generateRandomEmailId(10);
    dependent1FirstName = CommonUtil.generateRandomFirstName(5);
    dependent1LastName = CommonUtil.generateRandomLastName(5);

    DigitalPharmacyOperationsUtil dependent1Obj =
        new DigitalPharmacyOperationsUtil(
            Integer.parseInt(commonStore),
            dependent1FirstName,
            dependent1LastName,
            commonDobForAdult,
            0,
            dependent1Email,
            commonPassword);
    dependent1Obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
    dependent1Cid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependent1Email);
    dependent1PatientId =
        ""
            + digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                dependent1Obj.getPatientFirstName(),
                dependent1Obj.getPatientLastName(),
                dependent1Obj.getDates().get(1),
                dependent1Obj.getStoreId() + "");
    digitalPharmacyOperationsUtil.enableTestAccountInQa(
        dependent1Cid,
        dependent1Obj.getStoreId() + "",
        dependent1PatientId,
        dependent1Obj.getPatientDob());

    digitalPharmacyOperationsUtil.linkDependentToCaregiver(caregiverObj, dependent1Obj, phoneNumber, "ADULT", false);

    // dependent2 , not linked with caregiver
    dependent2Email = CommonUtil.generateRandomEmailId(10);
    dependent2FirstName = CommonUtil.generateRandomFirstName(5);
    dependent2LastName = CommonUtil.generateRandomLastName(5);

    DigitalPharmacyOperationsUtil dependent2Obj =
        new DigitalPharmacyOperationsUtil(
            Integer.parseInt(commonStore),
            dependent2FirstName,
            dependent2LastName,
            commonDobForAdult,
            0,
            dependent2Email,
            commonPassword);
    dependent2Obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
    dependent2Cid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependent2Email);
    dependent2PatientId =
        ""
            + digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                dependent2Obj.getPatientFirstName(),
                dependent2Obj.getPatientLastName(),
                dependent2Obj.getDates().get(1),
                dependent2Obj.getStoreId() + "");
    digitalPharmacyOperationsUtil.enableTestAccountInQa(
        dependent2Cid,
        dependent2Obj.getStoreId() + "",
        dependent2PatientId,
        dependent2Obj.getPatientDob());

    // dependent3
    dependent3Email = CommonUtil.generateRandomEmailId(10);
    dependent3FirstName = CommonUtil.generateRandomFirstName(5);
    dependent3LastName = CommonUtil.generateRandomLastName(5);

    DigitalPharmacyOperationsUtil dependent3Obj =
        new DigitalPharmacyOperationsUtil(
            Integer.parseInt(commonStore),
            dependent3FirstName,
            dependent3LastName,
            commonDobForMinor,
            0,
            dependent3Email,
            commonPassword);
    dependent3Obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
    dependent3Cid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependent3Email);
    dependent3Obj.createMinorAndDropAnRx();

    dependent3PatientId =
        ""
            + digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                dependent3Obj.getPatientFirstName(),
                dependent3Obj.getPatientLastName(),
                dependent3Obj.getDates().get(1),
                dependent3Obj.getStoreId() + "");

    digitalPharmacyOperationsUtil.enableTestAccountInQa(
        dependent3Cid,
        dependent3Obj.getStoreId() + "",
        dependent3PatientId,
        dependent3Obj.getPatientDob());
    WCPAddDependentRequest wcpAddDependentRequest =
        CommonAccountHelper.getWCPAddDependentRequest(MINOR, ACTIVE, dependent3Cid, caregiverCid);
    wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCid);

    // ── PHASE: Parallel account creation for dep4, dep5, and dependentFemale ──────────────
    // Pre-generate all identifiers before launching threads (must be effectively final)
    dependent4Email     = CommonUtil.generateRandomEmailId(10);
    dependent4FirstName = CommonUtil.generateRandomFirstName(5);
    dependent4LastName  = CommonUtil.generateRandomLastName(5);
    dependent5Email     = CommonUtil.generateRandomEmailId(10);
    dependent5FirstName = CommonUtil.generateRandomFirstName(5);
    dependent5LastName  = CommonUtil.generateRandomLastName(5);
    dependentFemaleEmail     = CommonUtil.generateRandomEmailId(10);
    dependentFemaleFirstName = CommonUtil.generateRandomFirstName(5);
    dependentFemaleLastName  = CommonUtil.generateRandomLastName(5);

    // Cooldown patient identifiers — adult with Rx, no linkage; used for isInCooldown=true test
    String cooldownEmail = CommonUtil.generateRandomEmailId(10);
    String cooldownFirstName = CommonUtil.generateRandomFirstName(5);
    String cooldownLastName  = CommonUtil.generateRandomLastName(5);

    // No-OCID patient identifiers — created via generatePatient only (no online account)
    noOcidFirstName = CommonUtil.generateRandomFirstName(5);
    noOcidLastName  = CommonUtil.generateRandomLastName(5);

    // Capture fields as effectively-final locals for lambda capture
    final String dep4Email  = dependent4Email,  dep4First  = dependent4FirstName,  dep4Last  = dependent4LastName;
    final String dep5Email  = dependent5Email,  dep5First  = dependent5FirstName,  dep5Last  = dependent5LastName;
    final String femEmail   = dependentFemaleEmail, femFirst = dependentFemaleFirstName, femLast = dependentFemaleLastName;
    final String cdEmail    = cooldownEmail,    cdFirst    = cooldownFirstName,    cdLast    = cooldownLastName;
    final String noOcidFirst = noOcidFirstName, noOcidLast = noOcidLastName;
    final String store = commonStore;
    final String caregiverCidFinal = caregiverCid;

    // Each Callable returns String[]{cid, patientId}.
    // Fresh local instances per thread avoid shared-state race conditions.
    Callable<String[]> dep4SetupTask = () -> {
      DigitalPharmacyOperationsUtil obj =
          new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dep4First, dep4Last, commonDobForAdult, 0, dep4Email, commonPassword);
      obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
      DigitalPharmacyAPIManager api = new DigitalPharmacyAPIManager();
      String cid = api.getCidFromEmailUsingAstro(dep4Email);
      String pid = "" + api.getStorePatientIdFromCPR(
          obj.getPatientFirstName(), obj.getPatientLastName(), obj.getDates().get(1), obj.getStoreId() + "");
      new DigitalPharmacyOperationsUtil().enableTestAccountInQa(cid, obj.getStoreId() + "", pid, obj.getPatientDob());
      return new String[]{cid, pid};
    };

    Callable<String[]> dep5SetupTask = () -> {
      DigitalPharmacyOperationsUtil obj =
          new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dep5First, dep5Last, commonDobForAdult, 0, dep5Email, commonPassword);
      obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
      DigitalPharmacyAPIManager api = new DigitalPharmacyAPIManager();
      String cid = api.getCidFromEmailUsingAstro(dep5Email);
      String pid = "" + api.getStorePatientIdFromCPR(
          obj.getPatientFirstName(), obj.getPatientLastName(), obj.getDates().get(1), obj.getStoreId() + "");
      new DigitalPharmacyOperationsUtil().enableTestAccountInQa(cid, obj.getStoreId() + "", pid, obj.getPatientDob());
      return new String[]{cid, pid};
    };

    // Female patient: uses the same createDigitalPharmacyConnectedStorePatientAccount pattern
    // as dep4/dep5. This is required because getCidFromEmailUsingAstro (signInV2) needs the
    // account to be fully activated before it can return an authCode. Manually splitting
    // generatePatient + createDotComAccount caused signInV2 to return authCode=null (account
    // not yet active). createDigitalPharmacyConnectedStorePatientAccount handles the full
    // lifecycle — including activation — before returning, so sign-in succeeds immediately.
    // Note: generatePatient() internally hardcodes gender="M" regardless of the Gender param,
    // so the female patient is created as male — consistent with the repurposed test assertion.
    Callable<String[]> femaleSetupTask = () -> {
      DigitalPharmacyOperationsUtil obj =
          new DigitalPharmacyOperationsUtil(Integer.parseInt(store), femFirst, femLast, commonDobForAdult, 0, femEmail, commonPassword);
      obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
      DigitalPharmacyAPIManager api = new DigitalPharmacyAPIManager();
      String cid = api.getCidFromEmailUsingAstro(femEmail);
      String pid = "" + api.getStorePatientIdFromCPR(
          obj.getPatientFirstName(), obj.getPatientLastName(), obj.getDates().get(1), obj.getStoreId() + "");
      new DigitalPharmacyOperationsUtil().enableTestAccountInQa(cid, obj.getStoreId() + "", pid, obj.getPatientDob());
      return new String[]{cid, pid};
    };

    // Cooldown patient: full account creation (needs OCID for signInV2 / enableTestAccountInQa).
    // Returns [cid, patientId]. The cid is not needed at test time but enableTestAccountInQa
    // requires it during setup. Only patientId is stored as a class field.
    Callable<String[]> cooldownSetupTask = () -> {
      DigitalPharmacyOperationsUtil obj =
          new DigitalPharmacyOperationsUtil(Integer.parseInt(store), cdFirst, cdLast, commonDobForAdult, 0, cdEmail, commonPassword);
      obj.createDigitalPharmacyConnectedStorePatientAccount(false, false);
      DigitalPharmacyAPIManager api = new DigitalPharmacyAPIManager();
      String cid = api.getCidFromEmailUsingAstro(cdEmail);
      String pid = "" + api.getStorePatientIdFromCPR(
          obj.getPatientFirstName(), obj.getPatientLastName(), obj.getDates().get(1), obj.getStoreId() + "");
      new DigitalPharmacyOperationsUtil().enableTestAccountInQa(cid, obj.getStoreId() + "", pid, obj.getPatientDob());
      return new String[]{cid, pid};
    };

    // No-OCID patient: creates patient in PMART/CPR via generatePatient ONLY.
    // No createDotComAccount call → no Account Entity record (OCID = null).
    // Returns [patientFirstName, patientLastName, patientId] for Rx creation and assertions.
    Callable<String[]> noOcidSetupTask = () -> {
      DigitalPharmacyOperationsUtil obj =
          new DigitalPharmacyOperationsUtil(Integer.parseInt(store), noOcidFirst, noOcidLast, commonDobForAdult, 0,
              noOcidFirst + ".noocid@test.com", commonPassword);
      // generatePatient creates the patient in PMART+CPR but NOT in Account Entity (no dotcom account)
      obj.generatePatient(Integer.parseInt(store), noOcidFirst, noOcidLast,
          "/Date(" + obj.getDates().get(0) + ")/", false, "M", false);
      Thread.sleep(10000); // allow PMART → CPR propagation before querying
      DigitalPharmacyAPIManager api = new DigitalPharmacyAPIManager();
      String pid = "" + api.getStorePatientIdFromCPR(
          obj.getPatientFirstName(), obj.getPatientLastName(), obj.getDates().get(1), store);
      return new String[]{obj.getPatientFirstName(), obj.getPatientLastName(), pid};
    };

    ExecutorService accountExecutor = Executors.newFixedThreadPool(5); // 3 original + 2 new patients
    Future<String[]> dep4Future     = accountExecutor.submit(dep4SetupTask);
    Future<String[]> dep5Future     = accountExecutor.submit(dep5SetupTask);
    Future<String[]> femaleFuture   = accountExecutor.submit(femaleSetupTask);
    Future<String[]> cooldownFuture = accountExecutor.submit(cooldownSetupTask);
    Future<String[]> noOcidFuture   = accountExecutor.submit(noOcidSetupTask);

    // Block until all 5 accounts are ready, then populate class fields
    String[] dep4Result = dep4Future.get();
    dependent4Cid       = dep4Result[0];
    dependent4PatientId = dep4Result[1];

    String[] dep5Result = dep5Future.get();
    dependent5Cid       = dep5Result[0];
    dependent5PatientId = dep5Result[1];

    String[] femaleResult    = femaleFuture.get();
    dependentFemaleCid       = femaleResult[0];
    dependentFemalePatientId = femaleResult[1];

    String[] cooldownResult = cooldownFuture.get();
    // cooldownResult[0] = cid (not stored; only needed during setup for enableTestAccountInQa)
    cooldownPatientId = cooldownResult[1];

    String[] noOcidResult = noOcidFuture.get();
    noOcidFirstName  = noOcidResult[0]; // actual name after PMART normalisation (may be uppercased)
    noOcidLastName   = noOcidResult[1];
    noOcidPatientId  = noOcidResult[2];

    accountExecutor.shutdown();

    // WCP linking calls are sequential (each needs the CID obtained above)
    WCPAddDependentRequest wcpApprovedRequest =
        CommonAccountHelper.getWCPAddDependentRequest(ADULT, APPROVED, dependent4Cid, caregiverCidFinal);
    wcpRetroFit.addDependent(wcpApprovedRequest, caregiverCidFinal);

    WCPAddDependentRequest wcpRejectedRequest =
        CommonAccountHelper.getWCPAddDependentRequest(ADULT, REJECTED, dependent5Cid, caregiverCidFinal);
    wcpRetroFit.addDependent(wcpRejectedRequest, caregiverCidFinal);

    // ── PHASE: Parallel Rx creation for all 6 patients ──────────────────────────────────
    // Fresh DigitalPharmacyOperationsUtil instances per thread to avoid shared-state issues.
    // Wall-clock time ≈ single Rx creation time instead of 6x.
    final int storeInt = Integer.parseInt(commonStore);
    final int pid1  = Integer.parseInt(dependent1PatientId);
    final int pid2  = Integer.parseInt(dependent2PatientId);
    final int pid3  = Integer.parseInt(dependent3PatientId);
    final int pid4  = Integer.parseInt(dependent4PatientId);
    final int pid5  = Integer.parseInt(dependent5PatientId);
    final int pidF  = Integer.parseInt(dependentFemalePatientId);
    final int pidCd = Integer.parseInt(cooldownPatientId);
    final int pidNo = Integer.parseInt(noOcidPatientId);

    ExecutorService rxExecutor = Executors.newFixedThreadPool(8); // 6 original + 2 new patients
    Future<String> rx1Future        = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pid1,  storeInt).get(0));
    Future<String> rx2Future        = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pid2,  storeInt).get(0));
    Future<String> rx3Future        = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pid3,  storeInt).get(0));
    Future<String> rx4Future        = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pid4,  storeInt).get(0));
    Future<String> rx5Future        = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pid5,  storeInt).get(0));
    Future<String> rxFemaleFuture   = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pidF,  storeInt).get(0));
    Future<String> rxCooldownFuture = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pidCd, storeInt).get(0));
    Future<String> rxNoOcidFuture   = rxExecutor.submit(() -> new DigitalPharmacyOperationsUtil().CreateRxForPatient(pidNo, storeInt).get(0));

    rxNbr1       = rx1Future.get();
    rxNbr2       = rx2Future.get();
    rxNbr3       = rx3Future.get();
    rxNbr4       = rx4Future.get();
    rxNbr5       = rx5Future.get();
    rxNbrFemale  = rxFemaleFuture.get();
    cooldownRxNbr = rxCooldownFuture.get();
    noOcidRxNbr   = rxNoOcidFuture.get();
    rxExecutor.shutdown();

    Thread.sleep(120000); // wait for all Rx to propagate through downstream systems
  }

  @Test(priority = 0, description = "Successfully fetched data from GetInfoByRx for fam False")
  public void successGetInfoByRxForFamFalseTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent1FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent1LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), dependent1Email);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent1Cid);
  }

  @Test(priority = 1, description = "Successfully fetched data from GetInfoByRx for fam True")
  public void successGetInfoByRxForFamTrueTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent1FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent1LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), dependent1Email);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent1Cid);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getFamInfo().getIsDependent(), Boolean.TRUE);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getFamInfo().getLinkageStatus(), "PENDING");
  }

  @Test(priority = 2, description = "rx Not found error")
  public void rxNotFound() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(CommonUtil.generateRandomNumber(5), commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            dependent1Cid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 500);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4003");
    Assert.assertTrue(errorResponse.getMessage().contains("Rx Not Found In upstream service."));
  }

  @Test(priority = 3, description = "rx not found for random store")
  public void rxNotFoundInRandomStore() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, CommonUtil.generateRandomNumber(5));
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            dependent1Cid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 500);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4003");
    Assert.assertTrue(errorResponse.getMessage().contains("Rx Not Found In upstream service."));
  }

  @Test(priority = 4, description = "Successfully fetched data from GetInfoByRx fam False for Minor")
  public void successGetInfoByRxForFamFalseForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent3FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent3LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.MINOR.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent3Cid);
  }

  @Test(priority = 5, description = "Successfully fetched data from GetInfoByRx for fam Minor True")
  public void successGetInfoByRxForFamTrueForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent3FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent3LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.MINOR.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent3Cid);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getFamInfo().getIsDependent(), Boolean.TRUE);
  }

  @Test(priority = 6, description = "Successfully fetched data from GetInfoByRx for fam Minor False")
  public void successGetInfoByRxForFamFalseForDependentNotFoundTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr2, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent2FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent2LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), dependent2Email);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent2Cid);
  }

  @Test(priority = 7, description = "Successfully fetched data from GetInfoByRx for fam True")
  public void successGetInfoByRxForFamTrueForDependentNotFoundTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr2, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response getCustomerInfoByRxV1ResponsePayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getFirstName(),
        dependent2FirstName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getMiddleName(), "");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getLastName(),
        dependent2LastName.toUpperCase());
    Assert.assertEquals(getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getGender(), "M");
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getStoreNbr(), commonStore);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getEmailId(), dependent2Email);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getCustomerInfo().getCustomerAccountId(),
        dependent2Cid);
    Assert.assertEquals(
        getCustomerInfoByRxV1ResponsePayload.getFamInfo().getIsDependent(), Boolean.FALSE);
  }

  @Test(priority = 8, description = "Returns 400 when rxNbr is empty string")
  public void emptyRxNbrReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request("", commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Rx number is null/empty"));
  }

  @Test(priority = 9, description = "Returns 400 when rxNbr is null in request body")
  public void nullRxNbrReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(null, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Rx number is null/empty"));
  }

  @Test(priority = 10, description = "Returns 400 when storeNbr is empty string (rxNbr is valid)")
  public void emptyStoreNbrReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, "");
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Store number is null/empty"));
  }

  @Test(priority = 11, description = "Returns 400 when storeNbr is null (rxNbr is valid)")
  public void nullStoreNbrReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, null);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Store number is null/empty"));
  }

  @Test(priority = 12, description = "Returns 400 when both rxNbr and storeNbr are empty — rxNbr error returned first")
  public void bothRxNbrAndStoreNbrEmptyReturns400WithRxErrorFirstTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request("", "");
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    // Service validates rxNbr before storeNbr — rxNbr error is returned first
    Assert.assertTrue(errorResponse.getMessage().contains("Rx number is null/empty"));
  }

  @Test(priority = 13, description = "Returns 400 when domainId is invalid")
  public void invalidDomainIdReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, "INVALID-DOMAIN", false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("INVALID-DOMAIN"));
  }

  @Test(priority = 14, description = "Verify famInfo block is null when famInfo=false (adult)")
  public void famInfoBlockIsNullWhenFamFalseForAdultTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNull(payload.getFamInfo(), "famInfo block should be null when famInfo=false");
  }

  @Test(priority = 15, description = "Verify famInfo block is null when famInfo=false (minor)")
  public void famInfoBlockIsNullWhenFamFalseForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNull(payload.getFamInfo(), "famInfo block should be null when famInfo=false");
  }

  @Test(priority = 16, description = "Verify validationToken is not null for an adult with a known patientId")
  public void validationTokenNotNullForAdultTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getValidationToken(),
        "validationToken must not be null for adult customer with a valid patientId");
  }

  @Test(priority = 17, description = "Verify validationToken is not null for a minor")
  public void validationTokenNotNullForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getValidationToken(),
        "validationToken must not be null for minor customer with a valid patientId");
  }

  @Test(priority = 18, description = "Verify patientId is present in customerInfo for adult")
  public void patientIdNotNullInCustomerInfoForAdultTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getCustomerInfo().getPatientId(), "patientId must not be null");
    Assert.assertEquals(payload.getCustomerInfo().getPatientId(), dependent1PatientId);
  }

  @Test(priority = 19, description = "Verify patientId is present in customerInfo for minor")
  public void patientIdNotNullInCustomerInfoForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getCustomerInfo().getPatientId(), "patientId must not be null for minor");
    Assert.assertEquals(payload.getCustomerInfo().getPatientId(), dependent3PatientId);
  }

  @Test(priority = 20, description = "famInfo=true for minor — verify linkageStatus is ACTIVE (linked via WCP with ACTIVE status)")
  public void famTrueForMinorAssertActiveLinkageStatusTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getFamInfo(), "famInfo must not be null when famInfo=true");
    Assert.assertEquals(payload.getFamInfo().getIsDependent(), Boolean.TRUE);
    // Minor was linked via WCP addDependent with ACTIVE membership status
    Assert.assertEquals(payload.getFamInfo().getLinkageStatus(), "ACTIVE");
  }

  @Test(priority = 21, description = "famInfo=true — verify isInCooldown is false for a non-cooldown customer")
  public void famTrueAssertIsInCooldownFalseForNonCooldownCustomerTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getFamInfo(), "famInfo must not be null when famInfo=true");
    Assert.assertEquals(payload.getFamInfo().getIsInCooldown(), Boolean.FALSE,
        "isInCooldown should be false for a freshly created test customer");
  }

  @Test(priority = 22, description = "famInfo=true — verify coolDownStatus is null when customer is not in cooldown")
  public void famTrueAssertCoolDownStatusNullWhenNotInCooldownTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getFamInfo(), "famInfo must not be null when famInfo=true");
    Assert.assertNull(payload.getFamInfo().getCoolDownStatus(),
        "coolDownStatus should be null when customer is not in cooldown (isInCooldown=false)");
  }

  @Test(priority = 23, description = "famInfo=true for non-linked dependent — verify isInCooldown=false, linkageStatus=null")
  public void famTrueForNonLinkedDependentAssertIsInCooldownFalseTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr2, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getFamInfo(), "famInfo must not be null when famInfo=true");
    Assert.assertEquals(payload.getFamInfo().getIsDependent(), Boolean.FALSE);
    Assert.assertEquals(payload.getFamInfo().getIsInCooldown(), Boolean.FALSE,
        "isInCooldown should be false for a non-linked customer with no failed attempts");
    Assert.assertNull(payload.getFamInfo().getCoolDownStatus(),
        "coolDownStatus should be null when isInCooldown=false");
    Assert.assertNull(payload.getFamInfo().getLinkageStatus(),
        "linkageStatus should be null when customer is not a dependent of the caregiver");
  }

  @Test(priority = 24, description = "famInfo=true — verify all FamInfo fields together for a linked adult (PENDING)")
  public void famTrueAdultLinkedDependentAllFamInfoFieldsTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    GetCustomerInfoByRxV1Response.FamInfo famInfo = payload.getFamInfo();
    Assert.assertNotNull(famInfo, "famInfo must not be null when famInfo=true");
    Assert.assertEquals(famInfo.getIsDependent(), Boolean.TRUE);
    Assert.assertEquals(famInfo.getLinkageStatus(), "PENDING");
    Assert.assertEquals(famInfo.getIsInCooldown(), Boolean.FALSE);
    Assert.assertNull(famInfo.getCoolDownStatus(), "coolDownStatus must be null when isInCooldown=false");
  }

  @Test(priority = 25, description = "famInfo=true for minor linked via WCP — assert all FamInfo fields")
  public void famTrueMinorLinkedViaWcpAllFamInfoFieldsTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    GetCustomerInfoByRxV1Response.FamInfo famInfo = payload.getFamInfo();
    Assert.assertNotNull(famInfo, "famInfo must not be null when famInfo=true");
    Assert.assertEquals(famInfo.getIsDependent(), Boolean.TRUE);
    Assert.assertEquals(famInfo.getLinkageStatus(), "ACTIVE");
    Assert.assertEquals(famInfo.getIsInCooldown(), Boolean.FALSE);
    Assert.assertNull(famInfo.getCoolDownStatus(), "coolDownStatus must be null when isInCooldown=false");
  }

  @Test(priority = 26, description = "famInfo query param defaults to false when not provided — famInfo block absent")
  public void famInfoDefaultsToFalseWhenNotProvidedTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    // Pass null for famInfo — Retrofit omits the query param; service defaults to false
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, null, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNull(payload.getFamInfo(),
        "famInfo block must be null when famInfo query param is not sent (defaults to false)");
  }

  @Test(priority = 27, description = "Complete response integrity: all customerInfo fields validated for an adult")
  public void completeResponseIntegrityForAdultTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);

    GetCustomerInfoByRxV1Response.CustomerInfo ci = payload.getCustomerInfo();
    Assert.assertNotNull(ci, "customerInfo must not be null");
    Assert.assertEquals(ci.getFirstName(), dependent1FirstName.toUpperCase());
    Assert.assertEquals(ci.getLastName(), dependent1LastName.toUpperCase());
    Assert.assertEquals(ci.getMiddleName(), "");
    Assert.assertEquals(ci.getGender(), "M");
    Assert.assertEquals(ci.getType(), Type.ADULT.name());
    Assert.assertEquals(ci.getStoreNbr(), commonStore);
    Assert.assertEquals(ci.getEmailId(), dependent1Email);
    Assert.assertEquals(ci.getCustomerAccountId(), dependent1Cid);
    Assert.assertNotNull(ci.getPatientId(), "patientId must not be null");
    Assert.assertEquals(ci.getPatientId(), dependent1PatientId);
    Assert.assertNotNull(payload.getValidationToken(), "validationToken must not be null");
    Assert.assertFalse(payload.getValidationToken().isEmpty(), "validationToken must not be empty");
    Assert.assertNull(payload.getFamInfo(), "famInfo must be null when famInfo=false");
  }

  @Test(priority = 28, description = "Complete response integrity: all customerInfo fields validated for a minor")
  public void completeResponseIntegrityForMinorTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr3, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);

    GetCustomerInfoByRxV1Response.CustomerInfo ci = payload.getCustomerInfo();
    Assert.assertNotNull(ci, "customerInfo must not be null");
    Assert.assertEquals(ci.getFirstName(), dependent3FirstName.toUpperCase());
    Assert.assertEquals(ci.getLastName(), dependent3LastName.toUpperCase());
    Assert.assertEquals(ci.getMiddleName(), "");
    Assert.assertEquals(ci.getGender(), "M");
    Assert.assertEquals(ci.getType(), Type.MINOR.name());
    Assert.assertEquals(ci.getStoreNbr(), commonStore);
    Assert.assertNull(ci.getEmailId(), "emailId must be null for a minor");
    Assert.assertNotNull(ci.getCustomerAccountId(), "customerAccountId must not be null for minor");
    Assert.assertEquals(ci.getCustomerAccountId(), dependent3Cid);
    Assert.assertNotNull(ci.getPatientId(), "patientId must not be null for minor");
    Assert.assertEquals(ci.getPatientId(), dependent3PatientId);
    Assert.assertNotNull(payload.getValidationToken(), "validationToken must not be null for minor");
    Assert.assertFalse(payload.getValidationToken().isEmpty(), "validationToken must not be empty for minor");
    Assert.assertNull(payload.getFamInfo(), "famInfo must be null when famInfo=false");
  }


  @Test(priority = 29, description = "famInfo=true for APPROVED linked adult — verify linkageStatus is APPROVED")
  public void famTrueAdultWithApprovedLinkageStatusTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr4, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(payload.getCustomerInfo().getFirstName(), dependent4FirstName.toUpperCase());
    Assert.assertEquals(payload.getCustomerInfo().getLastName(), dependent4LastName.toUpperCase());
    Assert.assertEquals(payload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(payload.getCustomerInfo().getEmailId(), dependent4Email);
    Assert.assertEquals(payload.getCustomerInfo().getCustomerAccountId(), dependent4Cid);
    GetCustomerInfoByRxV1Response.FamInfo famInfo = payload.getFamInfo();
    Assert.assertNotNull(famInfo, "famInfo must not be null when famInfo=true");
    Assert.assertEquals(famInfo.getIsDependent(), Boolean.TRUE);
    Assert.assertEquals(famInfo.getLinkageStatus(), "APPROVED",
        "linkageStatus must be APPROVED for dependent linked via WCP with APPROVED membership status");
    Assert.assertEquals(famInfo.getIsInCooldown(), Boolean.FALSE);
    Assert.assertNull(famInfo.getCoolDownStatus(), "coolDownStatus must be null when isInCooldown=false");
  }

  @Test(priority = 30, description = "famInfo=false for APPROVED linked adult — famInfo block must be absent")
  public void famFalseAdultWithApprovedLinkageStatusTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr4, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(payload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertNull(payload.getFamInfo(),
        "famInfo must be null when famInfo=false, regardless of linkage status");
  }

  @Test(priority = 31, description = "famInfo=true for REJECTED linked adult — verify linkageStatus is REJECTED")
  public void famTrueAdultWithRejectedLinkageStatusTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr5, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(payload.getCustomerInfo().getFirstName(), dependent5FirstName.toUpperCase());
    Assert.assertEquals(payload.getCustomerInfo().getLastName(), dependent5LastName.toUpperCase());
    Assert.assertEquals(payload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertEquals(payload.getCustomerInfo().getEmailId(), dependent5Email);
    Assert.assertEquals(payload.getCustomerInfo().getCustomerAccountId(), dependent5Cid);
    GetCustomerInfoByRxV1Response.FamInfo famInfo = payload.getFamInfo();
    Assert.assertNotNull(famInfo, "famInfo must not be null when famInfo=true");
    Assert.assertEquals(famInfo.getIsDependent(), Boolean.TRUE);
    Assert.assertEquals(famInfo.getLinkageStatus(), "REJECTED",
        "linkageStatus must be REJECTED for dependent linked via WCP with REJECTED membership status");
    Assert.assertEquals(famInfo.getIsInCooldown(), Boolean.FALSE);
    Assert.assertNull(famInfo.getCoolDownStatus(), "coolDownStatus must be null when isInCooldown=false");
  }

  @Test(priority = 32, description = "famInfo=false for REJECTED linked adult — famInfo block must be absent")
  public void famFalseAdultWithRejectedLinkageStatusTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr5, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertEquals(payload.getCustomerInfo().getType(), Type.ADULT.name());
    Assert.assertNull(payload.getFamInfo(),
        "famInfo must be null when famInfo=false, regardless of linkage status");
  }


  @Test(priority = 33, description = "Verify full response for a patient created via generatePatient() pathway (no caregiver linkage)")
  public void femaleGenderReturnedCorrectlyTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbrFemale, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);

    GetCustomerInfoByRxV1Response.CustomerInfo ci = payload.getCustomerInfo();
    Assert.assertNotNull(ci, "customerInfo must not be null");
    Assert.assertEquals(ci.getFirstName(), dependentFemaleFirstName.toUpperCase());
    Assert.assertEquals(ci.getLastName(), dependentFemaleLastName.toUpperCase());
    Assert.assertEquals(ci.getType(), Type.ADULT.name());
    // generatePatient() hardcodes gender="M" regardless of the Gender param — assert "M"
    Assert.assertEquals(ci.getGender(), "M",
        "generatePatient() always creates patients with gender=M (Gender param is ignored internally)");
    Assert.assertEquals(ci.getEmailId(), dependentFemaleEmail);
    Assert.assertEquals(ci.getCustomerAccountId(), dependentFemaleCid);
    Assert.assertNotNull(ci.getPatientId(), "patientId must not be null");
    Assert.assertEquals(ci.getPatientId(), dependentFemalePatientId);
    Assert.assertNotNull(payload.getValidationToken(), "validationToken must not be null");
    Assert.assertNull(payload.getFamInfo(),
        "famInfo must be null when famInfo=false");
  }


  @Test(priority = 34, description = "API handles missing req-id header gracefully")
  public void missingReqIdHeaderHandledGracefullyTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, null, reqTrackingId);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200,
        "API must return 200 when req-id header is missing — it is a tracing header, not a validated one");

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getCustomerInfo(),
        "customerInfo must still be returned when req-id is missing");
  }

  @Test(priority = 35, description = "API handles missing req-tracking-id header gracefully")
  public void missingReqTrackingIdHeaderHandledGracefullyTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, null);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200,
        "API must return 200 when req-tracking-id header is missing — tracing header, not validated");

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getCustomerInfo(),
        "customerInfo must still be returned when req-tracking-id is missing");
  }

  @Test(priority = 36, description = "API handles both req-id and req-tracking-id headers missing gracefully")
  public void bothTracingHeadersMissingHandledGracefullyTest() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, null, null);
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200,
        "API must return 200 when both tracing headers are missing");

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);
    Assert.assertNull(getCustomerInfoByRxresponse.body().getError(), null);
    Assert.assertNotNull(payload.getCustomerInfo(),
        "customerInfo must still be returned when both tracing headers are missing");
  }


  @Test(priority = 37, description = "rxNbr with special characters passes isEmpty() validation — RxOrchestrator cannot parse format, returns 500 unknown exception")
  public void rxNbrWithSpecialCharactersReturnsErrorTest() throws IOException {

    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request("RX@INVALID!123", commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 500);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
        "Special-char rxNbr is unrecognisable to RxOrchestrator → unknown exception → DPR-DPACCOR-4001");
  }

  @Test(priority = 38, description = "Non-numeric storeNbr (alphabetic) — StringUtils.isNumeric fails in LookupByRxRequestValidationHelper → 400 DPR-DPACCOR-1001")
  public void nonNumericStoreNbrReturnsErrorTest() throws IOException {

    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, "ABCDE");
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
        "Non-numeric storeNbr fails StringUtils.isNumeric() check → INVALID_REQUEST_EXCEPTION → DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Store nbr is null/empty/invalid"));
  }

  @Test(priority = 39, description = "rxNbr with whitespace-only string passes isEmpty() validation — RxOrchestrator cannot parse format, returns 500 unknown exception")
  public void whitespaceOnlyRxNbrReturns400Test() throws IOException {

    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request("   ", commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 500);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-4001",
        "Whitespace-only rxNbr is unrecognisable to RxOrchestrator → unknown exception → DPR-DPACCOR-4001");
  }

  @Test(priority = 40, description = "storeNbr with whitespace-only string — StringUtils.isNumeric fails in LookupByRxRequestValidationHelper → 400 DPR-DPACCOR-1001")
  public void whitespaceOnlyStoreNbrReturns400Test() throws IOException {
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(rxNbr1, "   ");
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 400);
    Error errorResponse = CommonUtil.getErrorResponse(gson, getCustomerInfoByRxresponse);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001",
        "Whitespace-only storeNbr fails StringUtils.isNumeric() check → INVALID_REQUEST_EXCEPTION → DPR-DPACCOR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("Store nbr is null/empty/invalid"));
  }


  @Test(priority = 41, description = "famInfo=true — patient in cooldown → isInCooldown=true, coolDownStatus fully populated")
  public void famTrueAssertIsInCooldownTrueForPatientInCooldownTest() throws IOException {
    // ── Step 1: Trigger cooldown for the dedicated cooldown patient ─────────────────────────
    // CoolDownUtil.callCustomerCoolDownStatusAPI always uses Constants.FAM_LITERAL = "FAM"
    // as the flowName, so we increment against the same flow type.
    PharmaAuthPatientIdStoreNbrRequest pharmaAuthRequest =
        PharmaAuthPatientIdStoreNbrRequest.builder()
            .storeNbr(Integer.parseInt(commonStore))
            .patientId(Integer.parseInt(cooldownPatientId))
            .flowName(FAM_FLOW_NAME)
            .build();
    for (int i = 0; i < 5; i++) {
      pharmacyAuthServiceRetrofit.incrementFailedAuthenticationForPatientLinks(pharmaAuthRequest);
    }

    // ── Step 2: Call getCustomerInfoByRx with famInfo=true ──────────────────────────────────
    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(cooldownRxNbr, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, true, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    // ── Step 3: Assert ──────────────────────────────────────────────────────────────────────
    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200);
    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);

    GetCustomerInfoByRxV1Response.FamInfo famInfo = payload.getFamInfo();
    Assert.assertNotNull(famInfo, "famInfo must be present when famInfo=true");
    Assert.assertTrue(famInfo.getIsInCooldown(),
        "Patient should be in cooldown after 5 failed PharmacyAuth increments");

    // coolDownStatus must be fully populated (covers the .map(...) branch in
    // buildGetCustomerInfoResponseWithDependentAndLookUpByRx that was previously unreachable)
    GetCustomerInfoByRxV1Response.CoolDownStatus coolDownStatus = famInfo.getCoolDownStatus();
    Assert.assertNotNull(coolDownStatus,
        "coolDownStatus must be non-null when isInCooldown=true");
    Assert.assertNotNull(coolDownStatus.getFailedAttemptsCount(),
        "failedAttemptsCount must be present in coolDownStatus");
    Assert.assertNotNull(coolDownStatus.getAttemptsRemaining(),
        "attemptsRemaining must be present in coolDownStatus");
    Assert.assertNotNull(coolDownStatus.getRemainingTime(),
        "remainingTime must be present in coolDownStatus");
  }


  @Test(priority = 42, description = "Patient has Rx in PMART + CPR record but no online account → 200 with customerAccountId=null, emailId=null")
  public void getCustomerInfoByRxReturns200WithNullCustomerAccountIdWhenNoOnlineAccountTest()
      throws IOException {

    GetCustomerInfoByRxV1Request getCustomerInfoByRxV1Request =
        new GetCustomerInfoByRxV1Request(noOcidRxNbr, commonStore);
    Response<ServiceResponse> getCustomerInfoByRxresponse =
        accountOrchestratorRetrofit.getCustomerInfoByRx(
            caregiverCid, domainId, false, getCustomerInfoByRxV1Request, reqId, reqTrackingId);

    Assert.assertEquals(getCustomerInfoByRxresponse.code(), 200,
        "Service must return 200 even when OCID is absent (2007 is a pass-through in CIBRLookUpByRxHelper)");

    GetCustomerInfoByRxV1Response payload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerInfoByRxresponse.body().getPayload()),
            GetCustomerInfoByRxV1Response.class);

    // customerAccountId and emailId must be null — no Account Entity record exists
    Assert.assertNull(payload.getCustomerInfo().getCustomerAccountId(),
        "customerAccountId must be null when patient has no online account (OCID not found)");
    Assert.assertNull(payload.getCustomerInfo().getEmailId(),
        "emailId must be null when customerAccountId is null (getPersonByCustomerAccountId is skipped)");

    // Other fields must still be populated from PMART/CPR (Rx was found)
    Assert.assertNotNull(payload.getCustomerInfo().getFirstName(),
        "firstName must be populated from CPR even when OCID is absent");
    Assert.assertNotNull(payload.getCustomerInfo().getLastName(),
        "lastName must be populated from CPR even when OCID is absent");
    Assert.assertNotNull(payload.getCustomerInfo().getStoreNbr(),
        "storeNbr must be populated from RxInfo");
    Assert.assertNotNull(payload.getCustomerInfo().getPatientId(),
        "patientId must be populated from RxInfo");
    Assert.assertNotNull(payload.getValidationToken(),
        "validationToken must be generated (uses storeNbr+patientId from RxInfo, not customerAccountId)");

    // famInfo must be null (famInfo=false was passed)
    Assert.assertNull(payload.getFamInfo(),
        "famInfo must be null when famInfo=false");
  }

}
