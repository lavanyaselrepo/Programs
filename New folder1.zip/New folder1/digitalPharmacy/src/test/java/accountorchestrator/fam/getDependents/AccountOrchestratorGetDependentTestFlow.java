package accountorchestrator.fam.getDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpdateFamRequestsV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.ApprovalStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.GetFamLinksResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CAAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequestByCustomerType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CAAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CACreatePersonByCustomerTypeResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CACreatePersonResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class AccountOrchestratorGetDependentTestFlow {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private WCPRetroFit wcpRetroFit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String filter = "DEPENDENT";
  private List<String> validFilterTypes = Arrays.asList("DEPENDENT", "CAREGIVER");
  private String accountCreationSource = "idVerification";
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  private String trackID = CommonUtil.randomUUID();
  private String caregiverCustomerEmailId = null;
  private String dependent1CustomerEmailId = null;
  private String dependent2CustomerEmailId = null;
  private String dependent3CustomerEmailId = null;
  private String dependent4CustomerEmailId = null;
  private String dependent5CustomerEmailId = null;
  private String caregiverCustomerAccountId = null;
  private String dependent1CustomerAccountId = null;
  private String dependent2CustomerAccountId = null;
  private String dependent3CustomerAccountId = null;
  private String dependent4CustomerAccountId = null;
  private String dependent5CustomerAccountId = null;
  private String caregiverStoreNbr = null;
  private String caregiverPatientId = null;
  private String dependent1StoreNbr = null;
  private String dependent1PatientId = null;
  private String dependent2StoreNbr = null;
  private String dependent2PatientId = null;
  private String dependent3StoreNbr = null;
  private String dependent3PatientId = null;
  private String dependent4StoreNbr = null;
  private String dependent4PatientId = null;
  private String dependent5StoreNbr = null;
  private String dependent5PatientId = null;
  private String caregiverFirstName = null;
  private String caregiverLastName = null;
  private String dependent1FirstName = null;
  private String dependent1LastName = null;
  private String dependent2FirstName = null;
  private String dependent2LastName = null;
  private String dependent3FirstName = null;
  private String dependent3LastName = null;
  private String dependent4FirstName = null;
  private String dependent4LastName = null;
  private String dependent5FirstName = null;
  private String dependent5LastName = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;
  private String commonDobCPRFormatForLessThan18 = null;
  private String commonDobDPFormatForLessThan18 = null;
  private String commonPhoneNo = "1234567829";
  private String commonPassword = "Test@12345";
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

    caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent3CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent4CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent5CustomerEmailId = CommonUtil.generateRandomEmailId(10);

    Date dateForOlderThan18 =
            new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    Date dateForLessThan18 = new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
            new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    commonDobCPRFormatForLessThan18 = new SimpleDateFormat("yyyy-MM-dd").format(dateForLessThan18);
    commonDobDPFormatForLessThan18 = new SimpleDateFormat("MMddyyyy").format(dateForLessThan18);

    // caregiver
    caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
    caregiverPatientId = CommonUtil.generateRandomNumber(9);
    caregiverFirstName = RandomStringUtils.randomAlphabetic(5);
    caregiverLastName = RandomStringUtils.randomAlphabetic(5);
    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiverCustomerEmailId,
            commonPassword,
            commonPhoneNo,
            caregiverFirstName,
            caregiverLastName,
            trackID);
    createCPRAccount(
            caregiverStoreNbr,
            caregiverPatientId,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            caregiverFirstName,
            caregiverLastName);
    createPharmacyAccount(
            caregiverCustomerAccountId,
            caregiverStoreNbr,
            caregiverPatientId,
            commonDobDPFormatForOlderThan18);

    // dependent1 -MINOR,ACTIVE
    dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent1PatientId = CommonUtil.generateRandomNumber(9);
    dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent1LastName = RandomStringUtils.randomAlphabetic(5);
    dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependent1CustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);
    createCPRAccount(
            dependent1StoreNbr,
            dependent1PatientId,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            dependent1FirstName,
            dependent1LastName);
    createPharmacyAccount(
            dependent1CustomerAccountId,
            dependent1StoreNbr,
            dependent1PatientId,
            commonDobDPFormatForLessThan18);
    //   Add dependent to WCP using the new common method
    WCPAddDependentRequest.Dependent wcpDependent1 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverCustomerAccountId).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent1CustomerAccountId).build())
            .memberType(Type.MINOR.name())
            .notificationEmail(dependent1CustomerEmailId)
            .membershipStatus(ApprovalStatus.ACTIVE.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest1 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent1)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest1, dependent1CustomerAccountId);


    // dependent2 -PET,APPROVED
    dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent2PatientId = CommonUtil.generateRandomNumber(9);
    dependent2FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent2LastName = RandomStringUtils.randomAlphabetic(5);
    dependent2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependent2CustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent2FirstName,
            dependent2LastName,
            trackID);
    createCPRAccount(
            dependent2StoreNbr,
            dependent2PatientId,
            commonDobCPRFormatForLessThan18,
            PET,
            dependent2FirstName,
            dependent2LastName);
    createPharmacyAccount(
            dependent2CustomerAccountId,
            dependent2StoreNbr,
            dependent2PatientId,
            commonDobDPFormatForLessThan18);
    WCPAddDependentRequest.Dependent wcpDependent2 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverCustomerAccountId).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent2CustomerAccountId).build())
            .memberType(Type.PET.name())
            .notificationEmail(dependent1CustomerEmailId)
            .membershipStatus(ApprovalStatus.APPROVED.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest2 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent2)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest2, dependent2CustomerAccountId);


    // dependent3 -MINOR>18,ACTIVE
    dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent3PatientId = CommonUtil.generateRandomNumber(9);
    dependent3FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent3LastName = RandomStringUtils.randomAlphabetic(5);
    dependent3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependent3CustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent3FirstName,
            dependent3LastName,
            trackID);
    createCPRAccount(
            dependent3StoreNbr,
            dependent3PatientId,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            dependent3FirstName,
            dependent3LastName);
    createPharmacyAccount(
            dependent3CustomerAccountId,
            dependent3StoreNbr,
            dependent3PatientId,
            commonDobDPFormatForOlderThan18);
    WCPAddDependentRequest.Dependent wcpDependent3 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverCustomerAccountId).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent3CustomerAccountId).build())
            .memberType(Type.MINOR.name())
            .notificationEmail(dependent3CustomerEmailId)
            .membershipStatus(ApprovalStatus.ACTIVE.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest3 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent3)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest3, dependent3CustomerAccountId);


    // dependent 4 - ADULT, PENDING
    dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent4PatientId = CommonUtil.generateRandomNumber(9);
    dependent4FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent4LastName = RandomStringUtils.randomAlphabetic(5);
    dependent4CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependent4CustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent4FirstName,
            dependent4LastName,
            trackID);
    createCPRAccount(
            dependent4StoreNbr,
            dependent4PatientId,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            dependent4FirstName,
            dependent4LastName);
    createPharmacyAccount(
            dependent4CustomerAccountId,
            dependent4StoreNbr,
            dependent4PatientId,
            commonDobDPFormatForOlderThan18);
    WCPAddDependentRequest.Dependent wcpDependent4 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverCustomerAccountId).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent4CustomerAccountId).build())
            .memberType(Type.ADULT.name())
            .notificationEmail(dependent4CustomerEmailId)
            .membershipStatus(ApprovalStatus.PENDING.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest4 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent4)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest4, dependent4CustomerAccountId);


    // dependent 5 - ADULT, PENDING_ACCOUNT_CREATION
    dependent5StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent5PatientId = CommonUtil.generateRandomNumber(9);
    dependent5FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent5LastName = RandomStringUtils.randomAlphabetic(5);
    dependent5CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependent5CustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent5FirstName,
            dependent5LastName,
            null);
    createCPRAccount(
            dependent5StoreNbr,
            dependent5PatientId,
            commonDobCPRFormatForOlderThan18,
            HUMAN,
            dependent5FirstName,
            dependent5LastName);
    InsertDataToFamReqTable(dependent5CustomerEmailId, dependent5PatientId, dependent5StoreNbr);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(40000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Clean up for all created cpr accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() throws IOException {
    cprProfilesToBeDeletedList.forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                Response<ValidationServiceResponse> response =
                        cprPatientUpdateRetrofit.validateProfile(request);
                if (!(response.code() == 202
                        && response.body() != null
                        && response.body().getErrors().isEmpty())
                        && response.code() != 406) {
                  throw new RuntimeException(
                          "CPR Account failed to update with status code 20708 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });
  }

  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  public void createCPRAccount(
          String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
          throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
      }
      break;
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * deletes cpr account by setting the PatientStatusCode as 20708
   *
   * @param storeNbr
   * @param patientId
   * @param firstName
   * @param lastName
   * @throws IOException
   */
  public void deleteCPRAccount(
          String storeNbr, String patientId, String firstName, String lastName, String dob)
          throws IOException {
    ValidationServiceRequest cprRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprRequest.setPatientId(Integer.parseInt(patientId));
    cprRequest.getPatientInfo().setBirthDate(dob);
    cprRequest.getPatientInfo().setFirstName(firstName);
    cprRequest.getPatientInfo().setLastName(lastName);
    cprRequest.getPatientInfo().setPatientStatusCode(20708);

    // This will try to delete an account in CPR 3 times if account deletion fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account deletion failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // This is needed because CPR account deletion is async, and it usually takes a couple of
    // seconds to reflect account deletion
    try {
      Thread.sleep(10000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  public void createPharmacyAccount(
          String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
          throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      domainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * This will add a dependent in fam request table in pending acc creation state
   *
   * @throws IOException
   */
  public void InsertDataToFamReqTable(
          String dependentCustomerAccountId, String commonPatientId, String commonStoreNbr)
          throws IOException {
    UpdateFamRequestsV1Request updateFamRequestsV1Request =
            getUpdateFamRequestsV1Request(dependentCustomerAccountId, commonPatientId, commonStoreNbr);
    Response<ServiceResponse> response = null;

    // This will try to insert a record in fam request table, 3 times if insertion fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.updateFamRequests(
                      domainId,
                      updateFamRequestsV1Request,
                      reqIdString,
                      reqTrackingString,
                      DependentInfo.LinkageStatusEnum.PENDING_ACCOUNT_CREATION.toString());
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity update fam links failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  private UpdateFamRequestsV1Request getUpdateFamRequestsV1Request(
          String dependentCustomerAccountId, String commonPatientId, String commonStoreNbr) {
    LinkedHashMap<String, String> additionalInfo = new LinkedHashMap<>();
    additionalInfo.put("storeNbr", commonStoreNbr);
    additionalInfo.put("patientId", commonPatientId);
    return UpdateFamRequestsV1Request.builder()
            .requestInfo(
                    org.openjdk.tools.javac.util.List.of(
                            UpdateFamRequestsV1Request.RequestInfo.builder()
                                    .additionalInfo(additionalInfo)
                                    .dependentId(dependentCustomerAccountId)
                                    .caregiverId(caregiverCustomerAccountId)
                                    .build()))
            .build();
  }
  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(dob)
                            .build())
            .build();
  }

  /**
   * Builds CA add dependent request
   *
   * @param type
   * @return
   */
  private CAAddDependentRequest getCAAddDependentRequest(
          DependentInfo.TypeEnum type,
          DependentInfo.LinkageStatusEnum status,
          String dependentAccountId,
          String caregiverId) {
    return CAAddDependentRequest.builder()
            .payload(
                    CAAddDependentRequest.Payload.builder()
                            .dependent(
                                    CAAddDependentRequest.Dependent.builder()
                                            .groupType(GroupType.FAM)
                                            .memberId(
                                                    CAAddDependentRequest.Identifier.builder()
                                                            .id(dependentAccountId)
                                                            .build())
                                            .membershipStatus(status)
                                            .memberType(type)
                                            .ownerId(CAAddDependentRequest.Identifier.builder().id(caregiverId).build())
                                            .build())
                            .build())
            .build();
  }

  @Test(
          priority = 0,
          description = "Get fam links success case for dependents with all linkage status")
  public void getFamLinksV1SuccessForDependentsWithAllLinkageStatus() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "ALL";

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);


    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForDependents.body().getPayload(), "Payload is null");
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 5);

    for (DependentInfo dependent : getFamLinksResponse.getDependentsInfo()) {
      Assert.assertNotNull(dependent.getUniqueId(), "Dependent uniqueId should not be null");
      if (dependent.getLinkageStatus() == DependentInfo.LinkageStatusEnum.PENDING) {
        Assert.assertEquals(dependent.getCustomerAccountId(), dependent4CustomerAccountId,
                "customerAccountId for PENDING linkageStatus should match dependent4CustomerAccountId");
      }
    }
  }

  @Test(
          priority = 1,
          description = "Get fam links success case for dependents with filter on linkage status")
  public void getFamLinksV1SuccessForDependentsWithFilterOnLinkageStatus() throws IOException {

    //     creating test data
    String email = CommonUtil.generateRandomEmailId(10);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String famReqDependentFirstName = RandomStringUtils.randomAlphabetic(5);
    String famReqDependentLastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
            storeNbr,
            patientId,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            famReqDependentFirstName,
            famReqDependentLastName);
    InsertDataToFamReqTable(email, patientId, storeNbr);

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "PENDING_ACCOUNT_CREATION";

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks

    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForDependents.body().getPayload(), "Payload is null");
    List<DependentInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getDependentsInfo().stream()
                    .map(DependentInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertTrue(
            linkageStatusEnumList.contains(DependentInfo.LinkageStatusEnum.PENDING_ACCOUNT_CREATION));
    for (DependentInfo dependent : getFamLinksResponse.getDependentsInfo()) {
      Assert.assertNotNull(dependent.getUniqueId(), "Dependent uniqueId should not be null");
    }
  }

  @Test(
          priority = 1,
          description =
                  "Get fam links success case for dependents with linkage status as active and approved")
  public void getFamLinksV1SuccessForDependentsWithLinkageStatusAsActiveAndApproved()
          throws IOException {

    //     creating test data
    String email = CommonUtil.generateRandomEmailId(10);
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    String famReqDependentFirstName = RandomStringUtils.randomAlphabetic(5);
    String famReqDependentLastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
            storeNbr,
            patientId,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            famReqDependentFirstName,
            famReqDependentLastName);
    InsertDataToFamReqTable(email, patientId, storeNbr);

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "ACTIVE,APPROVED";

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks

    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForDependents.body().getPayload(), "Payload is null");
    List<DependentInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getDependentsInfo().stream()
                    .map(DependentInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertTrue(linkageStatusEnumList.contains(DependentInfo.LinkageStatusEnum.ACTIVE));
    Assert.assertTrue(linkageStatusEnumList.contains(DependentInfo.LinkageStatusEnum.APPROVED));
    for (DependentInfo dependent : getFamLinksResponse.getDependentsInfo()) {
      Assert.assertNotNull(dependent.getUniqueId(), "Dependent uniqueId should not be null");
    }
  }

  @Test(priority = 2, description = "Get fam links invalid request case for dependents")
  public void getFamLinksV1InvalidRequestForDependents() throws IOException {

    // *****  CASE 1 - Filter is invalid *****
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidFilter = "DEPENDEN";
    logFlowIdentifiers(caregiverCustomerAccountId, domainId, invalidFilter, reqId, reqTrackingId);
    String linkageStatus = "ALL";
    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId,valid domainId and
    // invalid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId,
                    domainId,
                    invalidFilter,
                    reqId,
                    reqTrackingId,
                    linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(),
            String.format(
                    "Input contains following disallowed type: %s, the allowed types are %s",
                    invalidFilter, validFilterTypes));

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    logFlowIdentifiers(caregiverCustomerAccountId, invalidDomainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getSMSEnrolledProfileListV1 with a valid caregiverCustomerAccountId,invalid
    // domainId and valid filter
    getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCustomerAccountId,
                    invalidDomainId,
                    filter,
                    reqId,
                    reqTrackingId,
                    linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");
  }

  @Test(
          priority = 3,
          description =
                  "Get fam links API call empty list would be returned because of no dependents from CA for given caregiverCustomerAccountId and there are no pending account creation for dependents so dependentInfo List is empty")
  public void getFamLinksV1WhenNoDependentsFromCAAndNoPendingAccCreationEntryInFamRequest()
          throws Exception {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    String caregiverFirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiverLastName = RandomStringUtils.randomAlphabetic(5);

    String caregiver  = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiverCustomerEmailId,
            commonPassword,
            commonPhoneNo,
            caregiverFirstName,
            caregiverLastName,
            trackID);
    logFlowIdentifiers(caregiver, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "ALL";
    // Step - 2: Calling getFamLinksV1 with a caregiverCustomerAccountId which exists in CA but have
    // empty dependentList
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiver, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks

    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 4: Asserting response
    // Since CA get dependents gives us an empty list and there are no dependents in fam request
    // table, it will return an empty list
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 4,
          description =
                  "Get fam links API call 404 not found case where 404 is returned from CA for given caregiverCustomerAccountId for dependents")
  public void getFamLinksV1Request404FromCAForDependents() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    logFlowIdentifiers(customerAccountId, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "ALL";
    // Step - 2: Calling getFamLinksV1 with a caregiverCustomerAccountId which doesn't exists in CA
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    customerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "No information found for given customerAccountId in CA");
  }

  @Test(
          priority = 5,
          description =
                  "Get fam links API call returns empty list when account is not present in OCP for given caregiverCustomerAccountId, so dependentInfo List is empty as there is only one dependent which is not in OCP")
  public void getFamLinksV1EmptyListWhenNoEntryInOCPAndNoPendingAccCreationEntryInFamRequest()
          throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    String dependentCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    String linkageStatus = "ALL";
    // Step - 1b: Creating test accounts
    String caregiverId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiverCustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);
    String dependent3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependentCustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);
    WCPAddDependentRequest.Dependent wcpDependent = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverId).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependent3CustomerAccountId).build())
            .memberType(Type.MINOR.name())
            .notificationEmail(dependentCustomerEmailId)
            .membershipStatus(ApprovalStatus.ACTIVE.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest, dependent3CustomerAccountId);

    logFlowIdentifiers(caregiverId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a caregiverId whose dependent doesn't have an entry in
    // OCP
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks

    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 4: Asserting response
    // Since CA get dependents gives us an empty list and there are no dependents in fam request
    // table, it will return an empty list
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 6,
          description =
                  "Get fam links API call returns empty list when account is not present in CPR for given caregiverCustomerAccountId, so dependentInfo List is empty as there is only one dependent which is not in CPR")
  public void getFamLinksV1EmptyListWhenNoEntryInCPRAndNoPendingAccCreationEntryInFamRequest()
          throws Exception {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String linkageStatus = "ALL";

    // Step - 1b: creating test data
    String caregiverFirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiverLastName = RandomStringUtils.randomAlphabetic(5);

    String caregiverCid  = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            CommonUtil.generateRandomEmailId(10),
            commonPassword,
            commonPhoneNo,
            caregiverFirstName,
            caregiverLastName,
            trackID);
    String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
    String dependentPatientId = CommonUtil.generateRandomNumber(9);
    String dependentFirstName = RandomStringUtils.randomAlphabetic(5);
    String dependentLastName = RandomStringUtils.randomAlphabetic(5);
    String dependentCid  = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            CommonUtil.generateRandomEmailId(10),
            commonPassword,
            commonPhoneNo,
            dependentFirstName,
            dependentLastName,
            trackID);
    createCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            commonDobCPRFormatForLessThan18,
            HUMAN,
            dependentFirstName,
            dependentLastName);
    createPharmacyAccount(
            dependentCid, dependentStoreNbr, dependentPatientId, commonDobDPFormatForLessThan18);
//   Add dependent to WCP using the new common method
    WCPAddDependentRequest.Dependent wcpDependent = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverCid).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentCid).build())
            .memberType(Type.MINOR.name())
            .notificationEmail(dependentCid)
            .membershipStatus(ApprovalStatus.ACTIVE.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest, dependentCid);


    // Step - 1c: delete the dependent account from cpr
    deleteCPRAccount(
            dependentStoreNbr,
            dependentPatientId,
            dependentFirstName,
            dependentLastName,
            commonDobCPRFormatForLessThan18);

    logFlowIdentifiers(caregiverCid, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a caregiverCustomerAccountId which have dependent in OCP
    // but not in CPR
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    caregiverCid, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks

    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForDependents.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 4: Asserting response
    // Since CA get dependents gives us an empty list and there are no dependents in fam request
    // table, it will return an empty list
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 0);
  }

  @Test(
          priority = 7,
          description =
                  "Get fam links API call 400 case where 400 is returned from CA for given caregiverCustomerAccountId for dependents")
  public void getFamLinksV1Request400FromCAForDependents() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = "2345058";
    logFlowIdentifiers(customerAccountId, domainId, filter, reqId, reqTrackingId);
    String linkageStatus = "ALL";

    // Step - 2: Calling getFamLinksV1 with a invalid caregiverCustomerAccountId which doesn't
    // exists in CA
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForDependents =
            accountOrchestratorRetrofit.getFamLinksV1(
                    customerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForDependents);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7002");
    Assert.assertNotNull(errorResponse.getMessage(), "Invalid customerAccountId sent to CA");
  }

  private static void logFlowIdentifiers(
          String customerAccountId,
          String domainId,
          String filter,
          String reqId,
          String reqTrackingId) {
    Reporter.logJSON("customerAccountId", customerAccountId);
    Reporter.logJSON("domainId", domainId);
    Reporter.logJSON("filter", filter);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
