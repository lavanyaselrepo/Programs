package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetDependentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.FamUpdateDependentLinkageStatusV1Request;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AccountOrchestratorFamUpdateDependentLinkageStatusTest {
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetrofit;
    private ObjectMapper mapper = new ObjectMapper();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String accountCreationSource = "idVerification";
    private String dependent1CustomerEmailId = null;
    private String dependent2CustomerEmailId = null;
    private String dependent3CustomerEmailId = null;
    private String caregiverCustomerEmailId = null;
    private String caregiverCustomerAccountId = null;
    private String dependent1CustomerAccountId = null;
    private String dependent2CustomerAccountId = null;
    private String dependent3CustomerAccountId = null;
    private String dependent4CustomerAccountId = null;
    private String dependent5CustomerAccountId = null;
    private String dependent6CustomerAccountId = null;
    private String customerStoreNbr = null;
    private String customerPatientId = null;
    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent2StoreNbr = null;
    private String dependent2PatientId = null;
    private String dependent3StoreNbr = null;
    private String dependent3PatientId = null;
    private String dependent4StoreNbr = null;
    private String dependent4PatientId = null;
    private String dependent5StoreNbr = null;
    private String dependent5PatientId = null;
    private String dependent6StoreNbr = null;
    private String dependent6PatientId = null;
    private String customerFirstName = null;
    private String customerLastName = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent2FirstName = null;
    private String dependent2LastName = null;
    private String dependent3FirstName = null;
    private String dependent3LastName = null;
    private String dependent4FirstName = null;
    private String dependent4LastName = null;
    private String dependent5FirstName = null;
    private String dependent5LastName = null;
    private String dependent6FirstName = null;
    private String dependent6LastName = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    private String commonDobCPRFormatForYoungerThan18 = null;
    private String commonDobDPFormatForYoungerThan18 = null;

    private static void logFlowIdentifiers(
            String customerAccountId, String domainId, String reqId, String reqTrackingId) {
        Reporter.logJSON("customerAccountId", customerAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetrofit= new WCPRetroFit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

        caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent3CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        Date dateForYoungerThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        commonDobCPRFormatForYoungerThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForYoungerThan18);
        commonDobDPFormatForYoungerThan18 =
                new SimpleDateFormat("MMddyyyy").format(dateForYoungerThan18);

        // customer accounts
        caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverCustomerEmailId);
        customerStoreNbr = CommonUtil.generateRandomNumber(6);
        customerPatientId = CommonUtil.generateRandomNumber(9);
        customerFirstName = RandomStringUtils.randomAlphabetic(5);
        customerLastName = RandomStringUtils.randomAlphabetic(5);

        createCPRAccount(
                customerStoreNbr,
                customerPatientId,
                commonDobCPRFormatForOlderThan18,
                customerFirstName,
                customerLastName);
        createPharmacyAccount(
                caregiverCustomerAccountId,
                customerStoreNbr,
                customerPatientId,
                commonDobDPFormatForOlderThan18);

        // dependent1
        dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent1CustomerEmailId);
        dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent1LastName = RandomStringUtils.randomAlphabetic(5);
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobCPRFormatForOlderThan18,
                dependent1FirstName,
                dependent1LastName);
        createPharmacyAccount(
                dependent1CustomerAccountId,
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobDPFormatForOlderThan18);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent1CustomerAccountId,
                caregiverCustomerAccountId);

        // dependent2
        dependent2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent2CustomerEmailId);
        dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent2PatientId = CommonUtil.generateRandomNumber(9);
        dependent2FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent2LastName = RandomStringUtils.randomAlphabetic(5);
        createCPRAccount(
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobCPRFormatForOlderThan18,
                dependent2FirstName,
                dependent2LastName);
        createPharmacyAccount(
                dependent2CustomerAccountId,
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobDPFormatForOlderThan18);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.REJECTED,
                dependent2CustomerAccountId,
                caregiverCustomerAccountId);

        // dependent3
        dependent3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent3CustomerEmailId);
        dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent3PatientId = CommonUtil.generateRandomNumber(9);
        dependent3FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent3LastName = RandomStringUtils.randomAlphabetic(5);

        createCPRAccount(
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobCPRFormatForOlderThan18,
                dependent3FirstName,
                dependent3LastName);
        createPharmacyAccount(
                dependent3CustomerAccountId,
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobDPFormatForOlderThan18);
        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.DELINKED,
                dependent3CustomerAccountId,
                caregiverCustomerAccountId);

        // dependent4
        dependent4CustomerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2008-01-02");;
        dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent4PatientId = CommonUtil.generateRandomNumber(9);
        dependent4FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent4LastName = RandomStringUtils.randomAlphabetic(5);

        createCPRAccount(
                dependent4StoreNbr,
                dependent4PatientId,
                commonDobCPRFormatForOlderThan18,
                dependent4FirstName,
                dependent4LastName);
        createPharmacyAccount(
                dependent4CustomerAccountId,
                dependent4StoreNbr,
                dependent4PatientId,
                commonDobDPFormatForOlderThan18);

        wcpAddDependent(
                DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent4CustomerAccountId,
                caregiverCustomerAccountId);

        // dependent5
        dependent5CustomerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2005-01-02");
        dependent5StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent5PatientId = CommonUtil.generateRandomNumber(9);
        dependent5FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent5LastName = RandomStringUtils.randomAlphabetic(5);

        createCPRAccount(
                dependent5StoreNbr,
                dependent5PatientId,
                commonDobCPRFormatForYoungerThan18,
                dependent5FirstName,
                dependent5LastName);
        createPharmacyAccount(
                dependent5CustomerAccountId,
                dependent5StoreNbr,
                dependent5PatientId,
                commonDobDPFormatForYoungerThan18);

        wcpAddDependent(
                DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent5CustomerAccountId,
                caregiverCustomerAccountId);

        // dependent6
        dependent6CustomerAccountId = CommonAccountHelper.createGuestAccountWithWCPWithRandomName("2006-01-02");
        dependent6StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent6PatientId = CommonUtil.generateRandomNumber(9);
        dependent6FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent6LastName = RandomStringUtils.randomAlphabetic(5);

        createCPRAccount(
                dependent6StoreNbr,
                dependent6PatientId,
                commonDobCPRFormatForOlderThan18,
                dependent6FirstName,
                dependent6LastName);
        createPharmacyAccount(
                dependent6CustomerAccountId,
                dependent6StoreNbr,
                dependent6PatientId,
                commonDobDPFormatForOlderThan18);

        wcpAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent6CustomerAccountId,
                caregiverCustomerAccountId);
    }

    /**
     * Clean up for all created cpr accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                        // Handle the IOException
                    }
                });
    }

    /**
     * Call WCP add dependent api
     *
     * @param type'
     * @throws IOException
     */
    public void wcpAddDependent(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId)
            throws Exception {
        WCPAddDependentRequest.Dependent wcpDependent = WCPAddDependentRequest.Dependent.builder()
                .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiverAccountId).build())
                .groupType(GroupType.FAM.name())
                .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentAccountId).build())
                .memberType(String.valueOf(type))
                .notificationEmail(dependentAccountId)
                .membershipStatus(String.valueOf(status))
                .build();
        WCPAddDependentRequest wcpAddDependentRequest = WCPAddDependentRequest.builder()
                .payload(WCPAddDependentRequest.Payload.builder()
                        .dependent(wcpDependent)
                        .build())
                .build();
        wcpRetrofit.addDependent(wcpAddDependentRequest, dependentAccountId);


    }

    private FamUpdateDependentLinkageStatusV1Request getFamUpdateDependentLinkageStatusRequest(
            String status, String dependentCustomerAccountId) {
        FamUpdateDependentLinkageStatusV1Request request =
                new FamUpdateDependentLinkageStatusV1Request();
        request.setLinkageStatus(status);
        request.setDependentCustomerAccountId(dependentCustomerAccountId);
        return request;
    }

    private String getUpdatedMembershipStatus(
            Response<WCPGetDependentsResponse> response, String dependentId) {
        return response.body().getPayload().getDependents().stream()
                .filter(d -> d.getDependent().getMemberId().getId().toString().equals(dependentId))
                .map(d -> d.getDependent().getMembershipStatus())
                .findFirst()
                .orElse(null);
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    public void createCPRAccount(
            String storeNbr, String patientId, String dob, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(dob);
        cprPatientRequest.getPatientInfo().setFirstName(firstName);
        cprPatientRequest.getPatientInfo().setLastName(lastName);

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    public void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                } else {
                    pharmacyProfilesToBeDeleted.add(customerAccountId);
                }
            } else break;
        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    @Test(
            priority = 0,
            description = "fam update linkage status case for Approved to Active for Adult")
    public void updateDependentLinkageStatusApprovedToActive() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("ACTIVE", dependent1CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);

        Response<WCPGetDependentsResponse> response = wcpRetrofit.getDependents(caregiverCustomerAccountId);

        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent1CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 200);
        Assert.assertEquals(updatedMembershipStatus, "ACTIVE");
    }

    @Test(
            priority = 1,
            description = "fam update linkage status case for Rejected to Pending for Adult")
    public void updateDependentLinkageStatusRejectedToPending() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("PENDING", dependent2CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Response<WCPGetDependentsResponse> response =
                wcpRetrofit.getDependents(caregiverCustomerAccountId);
        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent2CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 200);
        Assert.assertEquals(updatedMembershipStatus, "PENDING");
    }

    @Test(
            priority = 2,
            description = "fam update linkage status case for Delinked to Pending for Adult")
    public void updateDependentLinkageStatusDelinkedToPending() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("PENDING", dependent3CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Response<WCPGetDependentsResponse> response =
                wcpRetrofit.getDependents(caregiverCustomerAccountId);
        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent3CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 200);
        Assert.assertEquals(updatedMembershipStatus, "PENDING");
    }

    @Test(
            priority = 3,
            description = "fam update linkage status case for Active to DelinkedAgeOver for Minor")
    public void updateDependentLinkageStatusActiveToDelinkedAgeOver() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("DELINKED_AGE_OVER", dependent4CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Response<WCPGetDependentsResponse> response =
                wcpRetrofit.getDependents(caregiverCustomerAccountId);
        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent4CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 200);
        Assert.assertEquals(updatedMembershipStatus, "DELINKED_AGE_OVER");
    }

    @Test(
            priority = 4,
            description = "fam update linkage status case for Active to Pending for Minor failed")
    public void updateDependentLinkageStatusActiveToDelinkedAgeOverFailed() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);

        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("PENDING", dependent5CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Response<WCPGetDependentsResponse> response =
                wcpRetrofit.getDependents(caregiverCustomerAccountId);
        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent5CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 400);
        Assert.assertEquals(updatedMembershipStatus, "ACTIVE");
    }

    @Test(
            priority = 5,
            description = "fam update linkage status case for Active to DelinkedAgeOver for Adult failed")
    public void updateDependentLinkageStatusActiveToDelinkedAgeOverForAdultFailed()
            throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);

        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("DELINKED_AGE_OVER", dependent6CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Response<WCPGetDependentsResponse> response =
                wcpRetrofit.getDependents(caregiverCustomerAccountId);
        String updatedMembershipStatus =
                getUpdatedMembershipStatus(response, dependent6CustomerAccountId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 400);
        Assert.assertEquals(updatedMembershipStatus, "ACTIVE");
    }

    @Test(priority = 6, description = "invalid Customer Id")
    public void updateDependentLinkageStatusNullCustomerId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("PENDING", null);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 400);
    }

    @Test(priority = 7, description = "Invalid Linkage Status")
    public void updateDependentLinkageStatusInvalidLinkageStatus() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("DELINKED", dependent1CustomerAccountId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        caregiverCustomerAccountId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 400);
    }

    @Test(priority = 8, description = "CustomerId not Found")
    public void updateDependentLinkageStatusCustomerIdNotFound() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String randomCustomerId = CommonUtil.generateRandomString(36);

        logFlowIdentifiers(randomCustomerId, domainId, reqId, reqTrackingId);
        FamUpdateDependentLinkageStatusV1Request famUpdateDependentLinkageStatusV1Request =
                getFamUpdateDependentLinkageStatusRequest("ACTIVE", randomCustomerId);
        Response<Void> famUpdateLinkageStatusresponse =
                accountOrchestratorRetrofit.famUpdateDependentLinkageStatus(
                        randomCustomerId,
                        domainId,
                        famUpdateDependentLinkageStatusV1Request,
                        reqId,
                        reqTrackingId);
        Assert.assertEquals(famUpdateLinkageStatusresponse.code(), 400);
    }
}
