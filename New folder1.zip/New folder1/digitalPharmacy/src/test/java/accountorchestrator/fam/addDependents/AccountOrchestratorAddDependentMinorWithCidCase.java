package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper.deleteCprAccount;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.createSMSEnrollmentOrUnenroll;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.getDmPostPreferencesRequest;

public class AccountOrchestratorAddDependentMinorWithCidCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private String emailAddress;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprMinorHumanPatientId;
  private String caregiverCustomerAccountId, minorCustomerAccountId;
  //  private final String customerAccountId = CommonUtil.randomUUID();
  private String caAdultDob = "1977-01-02";
  private String dpAdultDob = "01021977";
  private String caMinorDob = (LocalDate.now().getYear() - 2) + "-01-11";
  private String dpMinorDob = "0111" + (LocalDate.now().getYear() - 2);
  private String type = "PET,MINOR";
  Map<String, java.util.List<SMSEnrolledProfileListByCidResponse>>
      patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null, minorHumanCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    emailAddress = CommonUtil.generateRandomEmailId(10);

    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

    minorCustomerAccountId =CommonAccountHelper.createGuestAccountWithWCPWithRandomName(CommonUtil.generateRandomEmailId(10));


    createAllCprAccounts();
    createSMSEnrollments();

    CreateAccountByPatientIdV1Request caregiverCreatePharmacyAccount =
        SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob);
    SharedUtils.createPharmacyAccount(
        caregiverCreatePharmacyAccount,
        caregiverCustomerAccountId,
        domainId,
        accountOrchestratorRetrofit);

    CreateAccountByPatientIdV1Request minorCreatePharmacyAccount =
        SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprMinorHumanPatientId), phoneNumber, dpMinorDob);
    SharedUtils.createPharmacyAccount(
        minorCreatePharmacyAccount, minorCustomerAccountId, domainId, accountOrchestratorRetrofit);

    java.util.List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
  }

  @Test(description = "Add Minor Account with CustomerAccountId - Success")
  public void addMinorAccountWithCustomerAccountId() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    SMSEnrolledProfileListByCidResponse minorPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprMinorHumanPatientId)).get(0);
    DependentInfo2 minorDependentInfo = createDependentInfo2(minorPatientProfile);
    minorDependentInfo.setType("MINOR");
    minorDependentInfo.setDob(dpMinorDob);
    minorDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(minorDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, addDependentResponse);

    Assert.assertEquals(addDependentResponse.code(), 200, errorMessage);
    Assert.assertNotNull(addDependentResponse.body().getPayload(), "Payload is null");

    AddDependentsV1Response responseBody =
        extractDependentsFromResponsePayload(addDependentResponse.body().getPayload());
    Assert.assertEquals(1, responseBody.getDependents().size());

    validateFamLinksResponse(reqId, reqTrackingId);
  }

  private void validateFamLinksResponse(String reqId, String reqTrackingId) throws IOException {
    String linkageStatus = "ALL";
    Response<ServiceResponse> getFamLinksV1Response =
        accountOrchestratorRetrofit.getFamLinksV1(
            caregiverCustomerAccountId,
            domainId,
            "DEPENDENT",
            reqId,
            reqTrackingId,
                linkageStatus);

    String getFamLinksErrorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1Response);

    GetFamLinksResponse getFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getFamLinksV1Response.body().getPayload()),
            GetFamLinksResponse.class);

    Assert.assertEquals(getFamLinksV1Response.code(), 200, getFamLinksErrorMessage);
    Assert.assertNotNull(getFamLinksV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 1);

    DependentInfo dependentInfo = getFamLinksResponse.getDependentsInfo().get(0);

    Assert.assertEquals(dependentInfo.getLinkageStatus(), DependentInfo.LinkageStatusEnum.ACTIVE);
    Assert.assertEquals(dependentInfo.getType().getValue(), "MINOR");
    Assert.assertEquals(dependentInfo.getCustomerAccountId(), minorCustomerAccountId);
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorHumanCprPatientRequest.getPatientInfo().setBirthDate(caMinorDob);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprMinorHumanPatientId =
        SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId)
        .forEach(
            patientId -> {
              try {
                createSMSEnrollmentOrUnenroll(
                    dmPostPreferencesRetrofit,
                    getDmPostPreferencesRequest(
                        storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805"));
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(cprPatientUpdateRetrofit, request);
              } catch (IOException e) {
              }
            });
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId)
        .forEach(
            patientId -> {
              try {
                SharedUtils.cleanUpSMSEnrollment(
                    storeNbr, String.valueOf(patientId), dmPostPreferencesRetrofit);
              } catch (IOException e) {
              }
            });
  }

  private AddDependentsV1Response extractDependentsFromResponsePayload(Object payload) {
    return ResponseUtil.parseResponse(
        gson, ((LinkedTreeMap<String, Object>) payload), AddDependentsV1Response.class);
  }

  public DependentInfo2 createDependentInfo2(
      SMSEnrolledProfileListByCidResponse enrolledProfileResponse) {
    CustomerInfo2 enrolledProfile = enrolledProfileResponse.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(enrolledProfileResponse.getValidationToken());
    return fadDependentInfo;
  }
}
