package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DPExtendedOpsUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.FamVerifyEligibilityByPrescriberInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.FamVerifyEligibilityByPrescriberInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AccountOrchestratorVerifyEligibilityByPrescriberInfoTest {
  public Gson gson = new Gson();
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  public DigitalPharmacyAPIManager digitalPharmacyAPIManager;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private ObjectMapper mapper = new ObjectMapper();
  private String dependentFirstName;
  private String dependentLastName;
  private String dependentEmail;
  private String phoneNumber;
  private String dependentCid;
  private String domainId = "WM-PHARMACY";
  private String commonStore = "5524";
  private String accountType = "INDIVIDUAL";
  private String customerType = "INDIVIDUAL";
  private String accountCreationSource = "smsOtpVerification";
  private String caregiverCid;
  private String commonDobInStoreFormat = null;
  private String commonDobInDPFormat = null;
  private String currentDateFormat = null;
  private String commonDobCPRFormat = null;
  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  private WCPRetroFit wcpRetroFit;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    wcpRetroFit = new WCPRetroFit();
    Date date = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    commonDobInStoreFormat = new SimpleDateFormat("ddMMyyyy").format(date);
    commonDobInDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    Date currentDate = new Date();
    currentDateFormat = new SimpleDateFormat("yyyy-MM-dd").format(currentDate);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    phoneNumber = CommonUtil.generateRandomPhoneNo(10);
    dependentEmail = SharedUtils.getRandomEmailAddress();
    dependentFirstName = CommonUtil.generateRandomFirstName(5);
    dependentLastName = CommonUtil.generateRandomLastName(5);

    DPExtendedOpsUtils patient1 =
        new DPExtendedOpsUtils(
            Integer.parseInt(commonStore),
            dependentFirstName,
            dependentLastName,
            commonDobInStoreFormat,
            1,
            dependentEmail,
            "Test@1234");
    List<String> patient1Info =
        patient1.testAccountCreation(
            dependentEmail,
            dependentFirstName,
            dependentLastName,
            commonDobInStoreFormat,
            commonStore,
            phoneNumber,
            false,
            false);
    String patientId1 = patient1Info.get(1);
    dependentCid = patient1Info.get(0);
    patient1.getRxForPatientWithRetry(
        Integer.parseInt(patientId1),
        Integer.parseInt(commonStore),
        accountOrchestratorRetrofit,
        gson);

    String dependentEmailId = CommonUtil.generateRandomEmailId(10);
    caregiverCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependentEmailId);
    String caregiverFirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiverLastName = RandomStringUtils.randomAlphabetic(5);
    String commonStoreNbr = CommonUtil.generateRandomNumber(6);
    String commonPatientId = CommonUtil.generateRandomNumber(9);
    createCPRAccount(commonStoreNbr, commonPatientId, caregiverFirstName, caregiverLastName);
    createPharmacyAccount(caregiverCid, commonStoreNbr, commonPatientId);
  }

  /**
   * Create CPR Account
   *
   * @throws IOException
   */
  public void createCPRAccount(String storeNbr, String patientId, String firstName, String lastName)
      throws IOException {
    cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(patientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(firstName);
    cprPatientRequest.getPatientInfo().setLastName(lastName);

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
        break;
      }
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  public void createPharmacyAccount(
      String customerAccountId, String commonStoreNbr, String commonPatientId) throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId);
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
        response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
          accountEntityServiceRetrofit.createPharmacyAccountV1(
              customerAccountId,
              domainId,
              createPharmacyAccountV1Request,
              reqIdString,
              reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
      String commonStoreNbr, String commonPatientId) {
    return CreatePharmacyAccountV1Request.builder()
        .accountCreationSource(accountCreationSource)
        .customerInfo(
            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                .storeNbr(commonStoreNbr)
                .patientId(commonPatientId)
                .dob(commonDobInDPFormat)
                .build())
        .build();
  }

  @Test(priority = 0, description = "verifyEligibilityByPrescriberInfo Success")
  void verifyEligibilityByPrescriberInfoSuccess() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    // Step - 2: Preparing the request payload by mapping the JSON payload
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
        FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
            .firstName(dependentFirstName)
            .lastName(dependentLastName)
            .gender("M")
            .dob(commonDobInDPFormat)
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
        FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
            .labelName("SMITH, AARON CHRISTOPHER DO")
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
        FamVerifyEligibilityByPrescriberInfoV1Request.builder()
            .demographicsInfo(demographicsInfo)
            .prescriber(prescriber)
            .isPetType(false)
            .rxWrittenDate(currentDateFormat)
            .build();
    // Step -3: Calling Verify Eligibility By Prescriber Info API
    Response<ServiceResponse> verifyEligibilityResponse =
        accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
            caregiverCid, domainId, request, reqId, reqTrackingId);
    // Step - 4: Parsing the response to the FamVerifyEligibilityByPrescriberInfoV1Response class so
    // that we can assert Response
    FamVerifyEligibilityByPrescriberInfoV1Response famVerifyEligibilityByPrescriberInfoV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) verifyEligibilityResponse.body().getPayload()),
            FamVerifyEligibilityByPrescriberInfoV1Response.class);
    Assert.assertEquals(verifyEligibilityResponse.code(), 200);
    Assert.assertNotNull(verifyEligibilityResponse.body().getPayload(), "Payload is null");
    Assert.assertNotNull(famVerifyEligibilityByPrescriberInfoV1Response.getCustomerInfo());
  }

  @Test(priority = 1, description = "verifyEligibilityByPrescriberInfoNoProfileFound")
  void verifyEligibilityByPrescriberInfoNoProfileFound() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    // Step - 2: Preparing the request payload by mapping the JSON payload
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
        FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
            .firstName(dependentFirstName)
            .lastName(dependentLastName)
            .gender("M")
            .dob(commonDobInDPFormat)
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
        FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
            .labelName("SMITH")
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
        FamVerifyEligibilityByPrescriberInfoV1Request.builder()
            .demographicsInfo(demographicsInfo)
            .prescriber(prescriber)
            .isPetType(false)
            .rxWrittenDate(currentDateFormat)
            .build();
    Response<ServiceResponse> verifyEligibilityResponse =
        accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
            caregiverCid, domainId, request, reqId, reqTrackingId);
    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1063");
  }

  @Test(priority = 2, description = "verifyEligibilityByPrescriberInfo No Content From CPR")
  void verifyEligibilityByPrescriberInfoNoContentFromCPR()
      throws IOException, InterruptedException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String firstName = CommonUtil.generateRandomFirstName(5);
    String lastName = CommonUtil.generateRandomFirstName(5);
    // Step - 2: Preparing the request payload by mapping the JSON payload
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
        FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
            .firstName(firstName)
            .lastName(lastName)
            .gender("M")
            .dob(commonDobInDPFormat)
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
        FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
            .labelName("SMITH, AARON CHRISTOPHER DO")
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
        FamVerifyEligibilityByPrescriberInfoV1Request.builder()
            .demographicsInfo(demographicsInfo)
            .prescriber(prescriber)
            .isPetType(false)
            .rxWrittenDate(currentDateFormat)
            .build();

    Response<ServiceResponse> verifyEligibilityResponse =
        accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
            caregiverCid, domainId, request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(verifyEligibilityResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6005");
  }

  @Test(priority = 3, description = "verifyEligibilityByPrescriberInfo with Empty lastName")
  void verifyEligibilityByPrescriberInfoInvalidRequest() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    // Step - 2: Preparing the request payload by mapping the JSON payload
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
        FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
            .firstName(dependentFirstName)
            .lastName(null)
            .gender("M")
            .dob(commonDobInDPFormat)
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
        FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
            .labelName("SMITH, AARON CHRISTOPHER DO")
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
        FamVerifyEligibilityByPrescriberInfoV1Request.builder()
            .demographicsInfo(demographicsInfo)
            .prescriber(prescriber)
            .isPetType(false)
            .rxWrittenDate(currentDateFormat)
            .build();
    Response<ServiceResponse> verifyEligibilityResponse =
        accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
            caregiverCid, domainId, request, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
  }

  @Test(priority = 4, description = "verifyEligibilityByPrescriberInfo Dependent Already Exists")
  void verifyEligibilityByPrescriberInfoDependentAlreadyExists()
          throws Exception {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    // Step - 2: Preparing the request payload by mapping the JSON payload

      WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
              DependentInfo.LinkageStatusEnum.ACTIVE,
              dependentCid,caregiverCid);
      wcpRetroFit.addDependent(wcpAddDependentRequest,caregiverCid);
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
        FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
            .firstName(dependentFirstName)
            .lastName(dependentLastName)
            .gender("M")
            .dob(commonDobInDPFormat)
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
        FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
            .labelName("SMITH, AARON CHRISTOPHER DO")
            .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
        FamVerifyEligibilityByPrescriberInfoV1Request.builder()
            .demographicsInfo(demographicsInfo)
            .prescriber(prescriber)
            .isPetType(false)
            .rxWrittenDate(currentDateFormat)
            .build();
    Response<ServiceResponse> verifyEligibilityResponse =
        accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
            caregiverCid, domainId, request, reqId, reqTrackingId);
    //         Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1059");
  }

  @Test(priority = 5, description = "verifyEligibilityByPrescriberInfoMultipleProfileFound")
  void verifyEligibilityByPrescriberInfoMultipleProfileFound()
          throws IOException, InterruptedException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 2: Create DIFFERENT names for this test to avoid dependency conflicts
    String multiProfileFirstName = "AARON";
    String multiProfileLastName = "SMITH";
    String multiProfileEmail = SharedUtils.getRandomEmailAddress();

    // Step - 3: Create FIRST patient profile
    DPExtendedOpsUtils patient1 =
            new DPExtendedOpsUtils(
                    Integer.parseInt(commonStore),
                    multiProfileFirstName,
                    multiProfileLastName,
                    commonDobInStoreFormat,
                    1,
                    multiProfileEmail,
                    "Test@1234");
    String address1 = "ADDRESS ONE";
    String patientId1 =
            patient1.testCPRAccountCreation(
                    multiProfileEmail,
                    multiProfileFirstName,
                    multiProfileLastName,
                    commonDobInStoreFormat,
                    commonStore,
                    phoneNumber,
                    false,
                    false,
                    address1);
    patient1.getRxForPatientWithRetry(
            Integer.parseInt(patientId1),
            Integer.parseInt(commonStore),
            accountOrchestratorRetrofit,
            gson);

    // Step - 4: Create SECOND patient profile with SAME name but DIFFERENT address/store
    DPExtendedOpsUtils patient2 =
            new DPExtendedOpsUtils(
                    Integer.parseInt("5525"), // Different store number
                    multiProfileFirstName,    // Same first name
                    multiProfileLastName,     // Same last name
                    commonDobInStoreFormat,
                    1,
                    SharedUtils.getRandomEmailAddress(), // Different email
                    "Test@1234");
    String address2 = "ADDRESS TWO";
    String patientId2 =
            patient2.testCPRAccountCreation(
                    SharedUtils.getRandomEmailAddress(),
                    multiProfileFirstName,
                    multiProfileLastName,
                    commonDobInStoreFormat,
                    "5525", // Different store
                    CommonUtil.generateRandomPhoneNo(10), // Different phone
                    false,
                    false,
                    address2);
    patient2.getRxForPatientWithRetry(
            Integer.parseInt(patientId2),
            Integer.parseInt("5525"),
            accountOrchestratorRetrofit,
            gson);

    // Step - 5: Prepare request with the names that should match BOTH profiles
    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
            FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
                    .firstName(multiProfileFirstName) // This should match both profiles
                    .lastName(multiProfileLastName)   // This should match both profiles
                    .gender("M")
                    .dob(commonDobInDPFormat)
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
            FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
                    .labelName("Dr. Aaron Smith Medical Center")
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
            FamVerifyEligibilityByPrescriberInfoV1Request.builder()
                    .demographicsInfo(demographicsInfo)
                    .prescriber(prescriber)
                    .isPetType(false)
                    .rxWrittenDate(currentDateFormat)
                    .build();

    Response<ServiceResponse> verifyEligibilityResponse =
            accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
                    caregiverCid, domainId, request, reqId, reqTrackingId);

    // Step - 6: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);

    // Step - 7: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 8: Asserting response
    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1064");
  }

  @Test(priority = 6, description = "verifyEligibilityByPrescriberInfo Contains Only FirstName - Should Fail")
  void verifyEligibilityByPrescriberInfoContainsOnlyFirstName() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
            FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
                    .firstName(dependentFirstName)
                    .lastName(dependentLastName)
                    .gender("M")
                    .dob(commonDobInDPFormat)
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
            FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
                    .labelName(dependentFirstName.toUpperCase() + "Middle Name" + "Medical Center")
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
            FamVerifyEligibilityByPrescriberInfoV1Request.builder()
                    .demographicsInfo(demographicsInfo)
                    .prescriber(prescriber)
                    .isPetType(false)
                    .rxWrittenDate(currentDateFormat)
                    .build();

    Response<ServiceResponse> verifyEligibilityResponse =
            accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
                    caregiverCid, domainId, request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1063");
  }

  @Test(priority = 7, description = "verifyEligibilityByPrescriberInfo Contains Only LastName - Should Fail")
  void verifyEligibilityByPrescriberInfoContainsOnlyLastName() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo demographicsInfo =
            FamVerifyEligibilityByPrescriberInfoV1Request.DemographicsInfo.builder()
                    .firstName(dependentFirstName)
                    .lastName(dependentLastName)
                    .gender("M")
                    .dob(commonDobInDPFormat)
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber prescriber =
            FamVerifyEligibilityByPrescriberInfoV1Request.Prescriber.builder()
                    .labelName("Dr. John " + dependentLastName.toUpperCase() + " Medical Center")
                    .build();
    FamVerifyEligibilityByPrescriberInfoV1Request request =
            FamVerifyEligibilityByPrescriberInfoV1Request.builder()
                    .demographicsInfo(demographicsInfo)
                    .prescriber(prescriber)
                    .isPetType(false)
                    .rxWrittenDate(currentDateFormat)
                    .build();

    Response<ServiceResponse> verifyEligibilityResponse =
            accountOrchestratorRetrofit.verifyEligibilityByPrescriberInfo(
                    caregiverCid, domainId, request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, verifyEligibilityResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(verifyEligibilityResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1063");
  }
}
