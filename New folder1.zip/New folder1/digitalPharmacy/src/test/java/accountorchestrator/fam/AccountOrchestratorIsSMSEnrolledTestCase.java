package accountorchestrator.fam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class AccountOrchestratorIsSMSEnrolledTestCase {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().create();
    private String storeNbr;
    private String phoneNumber;
    private final String domainId = "WM-PHARMACY";
    private final  String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";

    private Integer cprAdultHumanPatientId, cprPetPatientId;
    private final String customerAccountId = CommonUtil.randomUUID();
    ValidationServiceRequest adultHumanCprPatientRequest = null,
            petCprPatientRequest;

    @BeforeClass
    void setContext() throws IOException {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

        storeNbr = CommonUtil.generateRandomNumber(6);
        phoneNumber = CommonUtil.generateRandomNumber(10);

        createAllCprAccounts();
        createSMSEnrollments();
        createPharmacyAccount(
                getCreatePharmacyAccountByPatientIdV1Request(
                        storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, "12121977"),
                customerAccountId);
    }

    @Test(description = "Fetch isSMSEnrolled with type=MINOR filter - Success")
    public void fetchIsSMSEnrolledWithMinorTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("MINOR", Boolean.FALSE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=PET filter - Success")
    public void fetchIsSMSEnrolledWithPetTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("PET", Boolean.TRUE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=ADULT filter - Success")
    public void fetchIsSMSEnrolledWithAdultTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("ADULT", Boolean.TRUE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=MINOR,PET filter - Success")
    public void fetchIsSMSEnrolledWithMinorPetTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("MINOR,PET", Boolean.TRUE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=PET,ADULT filter - Success")
    public void fetchIsSMSEnrolledWithPetAdultTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("PET,ADULT", Boolean.TRUE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=PET,ADULT,MINOR filter - Success")
    public void fetchIsSMSEnrolledWithMinorPetAdultMinorTypeFilter() throws IOException {
        makeSuccessCallWithTypeAndValidateResponse("PET,ADULT,MINOR", Boolean.TRUE);
    }

    @Test(description = "Fetch isSMSEnrolled with type=INVALID filter - Failure")
    public void fetchIsSMSEnrolledWithInvalidTypeFilter() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type  = "INVALID_TYPE";
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, String.format("Invalid type: %s", type), reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid input request. Input contains following disallowed types: [INVALID_TYPE]");
    }

    @Test(description = "Fetch isSMSEnrolled with Empty type filter - Failure")
    public void fetchIsSMSEnrolledWithEmptyTypeFilter() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type  = "";
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, String.format("Invalid type: %s", type), reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                "Invalid input request. Type is null/empty in request");
    }

    @Test(description = "Fetch isSMSEnrolled with domainId=INVALID - Failure")
    public void fetchIsSMSEnrolledWithInvalidDomainId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type  = "MINOR";
        String invalidDomainId = "INVALID";
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, String.format("Invalid domainId: %s", invalidDomainId), reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, invalidDomainId, phoneNumber, type, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(), "Invalid input request. domainId INVALID in input is invalid");
    }

    @Test(description = "Fetch isSMSEnrolled with incorrect phone number - Failure")
    public void fetchIsSMSEnrolledWithInvalidPhoneNumber() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type  = "MINOR";
        String invalidPhoneNumber = "123";
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, String.format("Invalid phoneNumber: %s", invalidPhoneNumber), reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, domainId, invalidPhoneNumber, type, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(), "Invalid input request. phoneNbr is null/Invalid length");
    }

    @Test(description = "Fetch isSMSEnrolled with alphabetical phone number- Failure")
    public void fetchIsSMSEnrolledWithInvalidPhoneNumber2() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type  = "MINOR";
        String invalidPhoneNumber = "abcdefghij";
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, String.format("Invalid phoneNumber: %s", invalidPhoneNumber), reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, domainId, invalidPhoneNumber, type, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, getIsSMSEnrolledV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-8002");
        Assert.assertEquals(
                errorResponse.getMessage(), "Invalid input request sent to DM Preference service. Validation Error. invalid phone number");
    }

    private void makeSuccessCallWithTypeAndValidateResponse(String type, Boolean expectedResponse) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(
                customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);
        Response<ServiceResponse> getIsSMSEnrolledV1Response =
                accountOrchestratorRetrofit.isSMSEnrolledV1(
                        customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

        String errorMessage = CommonUtil.buildErrorMessage(gson, getIsSMSEnrolledV1Response);
        Assert.assertEquals(getIsSMSEnrolledV1Response.code(), 200, errorMessage);
        IsSMSEnrolledV1Response isSMSEnrolledV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) getIsSMSEnrolledV1Response.body().getPayload()),
                        IsSMSEnrolledV1Response.class);

        Assert.assertNotNull(isSMSEnrolledV1Response.isIsSMSEnrolled(), "isSMSEnrolled found null");
        Assert.assertEquals(isSMSEnrolledV1Response.isIsSMSEnrolled(), expectedResponse);
    }

    public void createSMSEnrollment(String storeNbr, String patientId, String phoneNumber)
            throws IOException {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
        String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

        DMPostPreferencesRequest dmPostPreferencesRequest =
                DMPostPreferencesRequest.builder()
                        .storeNbr(storeNbr)
                        .patientId(patientId)
                        .zipCode("96898")
                        .userId("SIGPAD")
                        .storePhone("8009666546")
                        .timeStamp(timestamp)
                        .language("101")
                        .preferences(
                                List.of(
                                        DMPostPreferencesRequest.Preference.builder()
                                                .notification_type("1")
                                                .notification_val(phoneNumber)
                                                .short_code_type_id("1")
                                                .enrollment_status_code("26805")
                                                .build()))
                        .build();

        Response<DMPostPreferencesResponse> response =
                dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

        if (!(response.code() == 200
                && response.body() != null
                && response.body().getResponseStatus() != null
                && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
            throw new RuntimeException(
                    "DM Post Preference call failure. HttpStatusCode : " + response.code());
        }
    }

    private void createAllCprAccounts() throws IOException {
        // Create CPR Account before running "create pharmacy account" related test cases
        adultHumanCprPatientRequest = getTemplateCprRequest();
        adultHumanCprPatientRequest.getPatientInfo().setBirthDate("1977-12-12");

        petCprPatientRequest = getTemplateCprRequest();
        petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        List.of(adultHumanCprPatientRequest, petCprPatientRequest)
                .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

        cprAdultHumanPatientId = createCprAccount(adultHumanCprPatientRequest);
        cprPetPatientId = createCprAccount(petCprPatientRequest);
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private Integer createCprAccount(ValidationServiceRequest cprCreationRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprCreationRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
            return response.body().getPatientId();
        } else {
            throw new RuntimeException(
                    "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
    }

    private void createSMSEnrollments() {
        List.of(cprAdultHumanPatientId, cprPetPatientId)
                .forEach(
                        patientId -> {
                            try {
                                createSMSEnrollment(storeNbr, String.valueOf(patientId), phoneNumber);
                            } catch (IOException e) {
                                throw new RuntimeException(
                                        String.format(
                                                "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                                                storeNbr, patientId, e.getMessage()));
                            }
                        });
    }

    private void createPharmacyAccount(
            CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request, String customerAccountId)
            throws IOException {
        Response<ServiceResponse> createAccountByPatientIdV1Response =
                accountOrchestratorRetrofit.createAccountByPatientIdV1(
                        customerAccountId, domainId, createAccountByPatientIdV1Request);
        if (createAccountByPatientIdV1Response.code() == 200
                && createAccountByPatientIdV1Response.body() != null) {

        } else {
            throw new RuntimeException(
                    "Create patient account failed for customerId: "
                            + customerAccountId
                            + " with HttpStatusCode : "
                            + createAccountByPatientIdV1Response.code());
        }
    }

    private CreateAccountByPatientIdV1Request getCreatePharmacyAccountByPatientIdV1Request(
            String storeNbr, String patientId, String phoneNbr, String dob) {
        CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
        customerInfo.setStoreNbr(storeNbr);
        customerInfo.setPatientId(patientId);
        customerInfo.setPhoneNumber(phoneNbr);
        customerInfo.setDob(dob);
        customerInfo.setTandCPolicyLanguage("EN");

        CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
                new CreateAccountByPatientIdV1Request();
        createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

        return createAccountByPatientIdV1Request;
    }

    private ValidationServiceRequest getTemplateCprRequest() throws IOException {
        return mapper.readValue(
                new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                ValidationServiceRequest.class);
    }

    @AfterClass
    void cleanUp() {
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
        // delete CPR account
        adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
        petCprPatientRequest.setPatientId(cprPetPatientId);

        List.of(adultHumanCprPatientRequest, petCprPatientRequest)
                .forEach(
                        request -> {
                            request.getPatientInfo().setPatientStatusCode(20708);
                            try {
                                deleteCprAccount(request);
                            } catch (IOException e) {
                            }
                        });
        List.of(cprAdultHumanPatientId, cprPetPatientId).forEach(patientId -> {
            try {
                cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
            } catch (IOException e) {
            }
        });
    }

    private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
        } else {
            Reporter.logJSON("errorMessage",
                    String.format("CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                            cprRequest.getPatientId(),response.code()));
        }
    }

    public void cleanUpSMSEnrollment(String storeNbr, String patientId)
            throws IOException {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
        String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

        DMPostPreferencesRequest dmPostPreferencesRequest =
                DMPostPreferencesRequest.builder()
                        .storeNbr(storeNbr)
                        .patientId(patientId)
                        .zipCode("96898")
                        .userId("SIGPAD")
                        .storePhone("8009666546")
                        .timeStamp(timestamp)
                        .language("101")
                        .preferences(
                                List.of(
                                        DMPostPreferencesRequest.Preference.builder()
                                                .notification_type("1")
                                                .notification_val(phoneNumber)
                                                .short_code_type_id("1")
                                                .enrollment_status_code("26805")
                                                .build()))
                        .build();

        Response<DMPostPreferencesResponse> response =
                dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

        if (!(response.code() == 200
                && response.body() != null
                && response.body().getResponseStatus() != null
                && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
        }
    }

}
