package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.BomTestDataSetupRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.FamVerifyEligibilityByInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.FamVerifyEligibilityByInsuranceV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CAServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class VerifyEligibilityByInsuranceTest {

    public static final String BIN_NUMBER = "610502";
    public static final String PCN = "00670000";
    public static final String CARDHOLDER_ID = "248201700";
    public static final Integer CARRIER_ID = 100426;
    public static final Integer PLAN_ID = 171;
    public static final Integer CATEGORY_CODE = 1006;
    public static final String CONTAINS_CARDHOLDER_ID = "201700";
    public static final int RANDOM_CARRIER_ID = 2321731;
    public static final int RANDOM_PLAN_ID = 98373;
    public static final String WRONG_CARDHOLDER_ID = "7293483";
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private ObjectMapper objectMapper;
    private InsuranceWrapper insuranceWrapper;
    private final Gson gson = new GsonBuilder().create();
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    String domainId = "WM-PHARMACY";
    private String trackID = CommonUtil.randomUUID();
    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private IDatabaseContext accountDbContext;

    String addressLineOne = "101 HYDE STREET";
    String city = "SAN FRANCISCO";
    String stateOrProvinceCode = "CA";
    String zipCode = "94102";
    String gender = "M";
    String dependentDobMMddyyyy = "11111997";
    String dependentDobyyyyMMdd = "19971111";
    String dependentDobyyyy_MM_dd = "1997-11-11";
    String loggedInCID;
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private WCPRetroFit wcpRetrofit;


    @BeforeClass
    void setContext() throws Exception {
        accountDbContext =
                AutomationManager.getInstance().getDPAccountDBContext();
        insuranceWrapper = new InsuranceWrapper();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();

        loggedInCID = getALoggedInAccount();
        wcpRetrofit= new WCPRetroFit();

    }

    @Test(
            priority = 1,
            description = "Verify Add Dependent Eligibility By Insurance Single profile from CPR search and No Content in CPR View Insurance.Insurance Matched in BOM." +
                    "Two Success scenarios. " +
                    "1.With Correct cardHolderId addDependent flow " +
                    "2. wrong CardHolderId FuzzyApiFlow")
    void verifyAddDependentEligibilityByInsuranceSingleProfileFromCPRTwoSuccessScenarios() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID =CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        emailAddress,
                        commonPassword,
                        commonPhoneNo,
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.cprCreateOrUpdatePatient(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, "HUMAN", CommonUtil.generateRandomNumber(10), zipCode, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        BomTestDataSetupRequest.Address address = new BomTestDataSetupRequest.Address(addressLineOne, city, zipCode, stateOrProvinceCode);
        BomTestDataSetupRequest.Patient patient = new BomTestDataSetupRequest.Patient(lastName, firstName, dependentDobyyyyMMdd, gender, address);
        BomTestDataSetupRequest.Request bomrequest = new BomTestDataSetupRequest.Request(patient, "9989", "US");
        BomTestDataSetupRequest bomTestDataSetupRequest = new BomTestDataSetupRequest(bomrequest, 1, Collections.singletonList(CARDHOLDER_ID), Collections.singletonList("YJSS0"), Collections.singletonList(BIN_NUMBER), Collections.singletonList(PCN));
        insuranceWrapper.setupBomTestData(objectMapper.writeValueAsString(bomTestDataSetupRequest));


        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.DELINKED,
                dependentCID,loggedInCID);
        wcpRetrofit.addDependent(wcpAddDependentRequest,loggedInCID);


        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus(), DependentInfo.LinkageStatusEnum.DELINKED.name());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId(), dependentCID);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId().toLowerCase(), emailAddress.toLowerCase());

        // With same data pass wrong CardHolderId in request. Then response should be for fuzzy flow
        FamVerifyEligibilityByInsuranceV1Request requestFuzzyCase = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, WRONG_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> responseFuzzy =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, requestFuzzyCase, reqId, reqTrackingId);

        Error errorResponseFuzzy = CommonUtil.getErrorResponse(gson, responseFuzzy);
        String messageFuzzy = "";
        if (errorResponseFuzzy != null) {
            messageFuzzy = errorResponseFuzzy.getMessage();
        }

        // Asserting desired responses
        Assert.assertEquals(responseFuzzy.code(), 200, messageFuzzy);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1ResponseFuzzy = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) responseFuzzy.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNull(eligibilityByInsuranceV1ResponseFuzzy.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getToken());
        Assert.assertFalse(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo().get(0).getProcessorName());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo().get(0).getIsWalmartEligible());

        wcpRetrofit.deleteDependent(loggedInCID, dependentCID);
    }


    @Test(
            priority = 2,
            description = "Verify Add Dependent Eligibility By Insurance Single profile from CPR Insurance Found in CPR and not matched But No Content from RDM.Insurance Matched in BOM." +
                    "Two Success scenarios. " +
                    "1.With Correct cardHolderId addDependent flow " +
                    "2. wrong CardHolderId FuzzyApiFlow")
    void testVerifyEligibilitySingleProfileFromCPRNoContentInRDMMatchedInBomSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                emailAddress,
                commonPassword,
                commonPhoneNo,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        BomTestDataSetupRequest.Address address = new BomTestDataSetupRequest.Address(addressLineOne, city, zipCode, stateOrProvinceCode);
        BomTestDataSetupRequest.Patient patient = new BomTestDataSetupRequest.Patient(lastName, firstName, dependentDobyyyyMMdd, gender, address);
        BomTestDataSetupRequest.Request bomrequest = new BomTestDataSetupRequest.Request(patient, "9989", "US");
        BomTestDataSetupRequest bomTestDataSetupRequest = new BomTestDataSetupRequest(bomrequest, 1, Collections.singletonList(CARDHOLDER_ID), Collections.singletonList("YJSS0"), Collections.singletonList(BIN_NUMBER), Collections.singletonList(PCN));
        insuranceWrapper.setupBomTestData(objectMapper.writeValueAsString(bomTestDataSetupRequest));


        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.DELINKED,
                dependentCID,loggedInCID);
        wcpRetrofit.addDependent(wcpAddDependentRequest,loggedInCID);


        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CONTAINS_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus(), DependentInfo.LinkageStatusEnum.DELINKED.name());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId(), dependentCID);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId().toLowerCase(), emailAddress.toLowerCase());


        // With same data pass wrong CardHolderId in request. Then response should be for fuzzy flow
        FamVerifyEligibilityByInsuranceV1Request requestFuzzyCase = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, WRONG_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> responseFuzzy =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, requestFuzzyCase, reqId, reqTrackingId);

        Error errorResponseFuzzy = CommonUtil.getErrorResponse(gson, responseFuzzy);
        String messageFuzzy = "";
        if (errorResponseFuzzy != null) {
            messageFuzzy = errorResponseFuzzy.getMessage();
        }

        // Asserting desired responses
        Assert.assertEquals(responseFuzzy.code(), 200, messageFuzzy);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1ResponseFuzzy = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) responseFuzzy.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNull(eligibilityByInsuranceV1ResponseFuzzy.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getToken());
        Assert.assertFalse(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo().get(0).getProcessorName());
        Assert.assertNotNull(eligibilityByInsuranceV1ResponseFuzzy.getInsuranceInfo().get(0).getIsWalmartEligible());


        wcpRetrofit.deleteDependent(loggedInCID, dependentCID);
    }

    @Test(
            priority = 3,
            description = "Verify Add Dependent Eligibility By Insurance Single profile from CPR Insurance Found in CPR And Matched." +
                    "Success scenarios With Correct cardHolderId addDependent flow ")
    void testVerifyEligibilitySingleProfileFromCPRMatchedInCPRInsuranceSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID =
                CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        emailAddress,
                        commonPassword,
                        commonPhoneNo,
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                        trackID);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID,
                RANDOM_CARRIER_ID,
                RANDOM_PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.DELINKED,
                dependentCID,loggedInCID);
        wcpRetrofit.addDependent(wcpAddDependentRequest,loggedInCID);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus(), DependentInfo.LinkageStatusEnum.DELINKED.name());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId(), dependentCID);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId().toLowerCase(), emailAddress.toLowerCase());

        wcpRetrofit.deleteDependent(loggedInCID, dependentCID);
    }

    @Test(
            priority = 4,
            description = "Verify Add Dependent Eligibility By Insurance Single profile from CPR Insurance Found in CPR And Contains Matched. And Bin fully matched from RDM" +
                    "Success scenarios With Correct cardHolderId addDependent flow ")
    void testVerifyEligibilitySingleProfileFromCPRFuzzyMatchedWithRDMSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                emailAddress,
                commonPassword,
                commonPhoneNo,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.DELINKED,
                dependentCID,loggedInCID);
        wcpRetrofit.addDependent(wcpAddDependentRequest,loggedInCID);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CONTAINS_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus(), DependentInfo.LinkageStatusEnum.DELINKED.name());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId(), dependentCID);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId().toLowerCase(), emailAddress.toLowerCase());

        wcpRetrofit.deleteDependent(loggedInCID, dependentCID);
    }

    @Test(
            priority = 5,
            description = "Verify Add Dependent Eligibility By Insurance Already Dependent Error")
    void verifyAddDependentEligibilityByInsurancAlreadyDependentError() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                emailAddress,
                commonPassword,
                commonPhoneNo,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.cprCreateOrUpdatePatient(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, "HUMAN", CommonUtil.generateRandomNumber(10), zipCode, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependentCID,loggedInCID);
        wcpRetrofit.addDependent(wcpAddDependentRequest,loggedInCID);


        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        // Asserting desired responses
        Assert.assertEquals(response.code(), 400);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1059");

        wcpRetrofit.deleteDependent(loggedInCID, dependentCID);
    }

    @Test(
            priority = 6,
            description = "Verify Add Dependent Eligibility By Insurance No Profile Found Error")
    void verifyAddDependentEligibilityByInsuranceNoProfileProfileError() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomLastName(8);

        FamVerifyEligibilityByInsuranceV1Request.Address address = FamVerifyEligibilityByInsuranceV1Request.Address.builder()
                .addressLineOne(addressLineOne)
                .city(city)
                .stateOrProvinceCode(stateOrProvinceCode)
                .zipCode(zipCode)
                .build();
        FamVerifyEligibilityByInsuranceV1Request.DemographicsInfo demographicsInfo = FamVerifyEligibilityByInsuranceV1Request.DemographicsInfo.builder()
                .firstName(firstName)
                .lastName(lastName)
                .dob(dependentDobMMddyyyy)
                .gender(gender)
                .address(address)
                .build();

        FamVerifyEligibilityByInsuranceV1Request request = FamVerifyEligibilityByInsuranceV1Request.builder()
                .demographicsInfo(demographicsInfo)
                .cardHolderId("3232e413")
                .rxBin("YJSS0")
                .build();

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }

        // Asserting desired responses
        Assert.assertEquals(response.code(), 404, message);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6005");
    }


    @Test(
            priority = 7,
            description = "Verify Add Dependent Eligibility By Insurance Multiple profiles in CPR and No insurance in all of them")
    void testVerifyEligibilityMultiProfileFromCPRButNoInsurancesInCPRFailure() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);

        CPRUpdatePatientRequest cprUpdatePatientRequest1 = SharedUtils.cprCreateOrUpdatePatient(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, "HUMAN", CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6), cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest1);

        CPRUpdatePatientRequest cprUpdatePatientRequest2 = SharedUtils.cprCreateOrUpdatePatient(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, "HUMAN", CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6), cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest2);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        // Asserting desired responses
        Assert.assertEquals(response.code(), 400);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1058");
    }


    @Test(
            priority = 8,
            description = "Verify Add Dependent Eligibility By Insurance Multiple profile from CPR Insurance Found in one of the CPR And Matched." +
                    "Two Success scenarios With Correct cardHolderId addDependent Flow")
    void testVerifyEligibilityMultiProfileFromCPRMatchedInCPRInsuranceWithOneProfileSuccess() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String emailAddress = SharedUtils.getRandomEmailAddress();
        String dependentCID = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                emailAddress,
                commonPassword,
                commonPhoneNo,
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                trackID);


        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, "M", dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                CARDHOLDER_ID,
                RANDOM_CARRIER_ID,
                RANDOM_PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(dependentCPRRequest.getStoreNbr()), String.valueOf(dependentCPRRequest.getPatientId()), dependentCID));
        pharmacyAccountToBeDeleted.add(dependentCID);

        CPRUpdatePatientRequest cprUpdatePatientRequest2 = SharedUtils.cprCreateOrUpdatePatient(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, "HUMAN", CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6), cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest2);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertNull(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId(), dependentCID);
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId().toLowerCase(), emailAddress.toLowerCase());

    }

    @Test(
            priority = 9,
            description = "Verify Add Dependent Eligibility By Insurance Multiple profile from CPR Insurance Found in one of the CPR But not Matched with RDM Bin." +
                    "Two Failure scenarios")
    void testVerifyEligibilityMultiProfileFromCPRNoContentInRDMFailure() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                CARDHOLDER_ID,
                RANDOM_CARRIER_ID,
                RANDOM_PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        CPRUpdatePatientRequest cprUpdatePatientRequest2 = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                WRONG_CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest2);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CONTAINS_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);
        // Asserting desired responses
        Assert.assertEquals(response.code(), 400);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1058");
    }

    @Test(
            priority = 10,
            description = "Verify Add Dependent Eligibility By Insurance Multiple profile from CPR Insurance Found in one of the CPR and Matched with RDM Bin." +
                    "Success scenarios With Correct cardHolderId addDependent Flow")
    void testVerifyEligibilityMultiProfileFromCPRFuzzyMatchedWithOneProfileInRDMSuccess() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        CPRUpdatePatientRequest cprUpdatePatientRequest2 = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                WRONG_CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest2);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CONTAINS_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);


        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        String message = "";
        if (errorResponse != null) {
            message = errorResponse.getMessage();
        }
        // Asserting desired responses
        Assert.assertEquals(response.code(), 200, message);

        FamVerifyEligibilityByInsuranceV1Response eligibilityByInsuranceV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                FamVerifyEligibilityByInsuranceV1Response.class);

        Assert.assertNotNull(eligibilityByInsuranceV1Response.getCustomerInfo());
        Assert.assertNotNull(eligibilityByInsuranceV1Response.getToken());
        Assert.assertTrue(eligibilityByInsuranceV1Response.getInsuranceMatchedForAddDependentEligibility());
        Assert.assertNull(eligibilityByInsuranceV1Response.getInsuranceInfo());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getFirstName().toUpperCase(), firstName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getLastName().toUpperCase(), lastName.toUpperCase());
        Assert.assertEquals(eligibilityByInsuranceV1Response.getCustomerInfo().getDob(), dependentDobMMddyyyy);
        Assert.assertNull(eligibilityByInsuranceV1Response.getCustomerInfo().getLinkageStatus());
        Assert.assertNull(eligibilityByInsuranceV1Response.getCustomerInfo().getCustomerAccountId());
        Assert.assertNull(eligibilityByInsuranceV1Response.getCustomerInfo().getEmailId());
    }


    @Test(
            priority = 10,
            description = "Verify Add Dependent Eligibility By Insurance Multiple profile from CPR Insurance Found and Matched with multiple profile" +
                    "Failure scenarios With Correct cardHolderId addDependent Flow")
    void testVerifyEligibilityMultiProfileFromCPRFuzzyMatchedWithMultiProfileInRDMSuccess() throws IOException, InterruptedException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);

        CPRUpdatePatientRequest dependentCPRRequest = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(dependentCPRRequest);

        CPRUpdatePatientRequest cprUpdatePatientRequest2 = SharedUtils.createCPRAccountWithInsurance(CommonUtil.generateRandomNumber(4), CommonUtil.generateRandomNumber(6), firstName, lastName, gender, dependentDobyyyy_MM_dd, CommonUtil.generateRandomNumber(10), CommonUtil.generateRandomNumber(6),
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY_CODE,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest2);

        FamVerifyEligibilityByInsuranceV1Request request = getFamVerifyEligibilityByInsuranceV1Request(firstName, lastName, gender, dependentDobMMddyyyy, addressLineOne, city, stateOrProvinceCode, zipCode, CONTAINS_CARDHOLDER_ID, BIN_NUMBER);

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.verifyEligibilityByInsuranceV1(loggedInCID, domainId, request, reqId, reqTrackingId);
        // Asserting desired responses
        Assert.assertEquals(response.code(), 400);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1060");
    }

    private FamVerifyEligibilityByInsuranceV1Request getFamVerifyEligibilityByInsuranceV1Request(
            String firstName,
            String lastName,
            String gender,
            String dependentDobMMddyyyy,
            String addressLineOne,
            String city,
            String stateOrProvinceCode,
            String zipCode,
            String cardHolderId,
            String binNumber) {
        FamVerifyEligibilityByInsuranceV1Request.Address address = FamVerifyEligibilityByInsuranceV1Request.Address.builder()
                .addressLineOne(addressLineOne)
                .city(city)
                .stateOrProvinceCode(stateOrProvinceCode)
                .zipCode(zipCode)
                .build();
        FamVerifyEligibilityByInsuranceV1Request.DemographicsInfo demographicsInfo = FamVerifyEligibilityByInsuranceV1Request.DemographicsInfo.builder()
                .firstName(firstName)
                .lastName(lastName)
                .dob(dependentDobMMddyyyy)
                .gender(gender)
                .address(address)
                .build();

        return FamVerifyEligibilityByInsuranceV1Request.builder()
                .demographicsInfo(demographicsInfo)
                .cardHolderId(cardHolderId)
                .rxBin(binNumber)
                .build();
    }

    private String getALoggedInAccount() throws Exception {

                Date dob =
                        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
                String dobMMddyyyy = new SimpleDateFormat("MMddyyyy").format(dob);
                String dobyyyy_MM_dd = new SimpleDateFormat("yyyy-MM-dd").format(dob);

                String loggedInCID = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
                        CommonUtil.generateRandomEmailId(10),
                        commonPassword,
                        commonPhoneNo,
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                        RandomStringUtils.randomAlphabetic(5).toUpperCase(),
                        trackID);
        CPRUpdatePatientRequest adultCPRAccount = SharedUtils.createAdultCPRAccount(dobyyyy_MM_dd, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(adultCPRAccount);
                SharedUtils.createPharmacyAccount(loggedInCID, String.valueOf(adultCPRAccount.getStoreNbr()), String.valueOf(adultCPRAccount.getPatientId()), dobMMddyyyy, accountEntityServiceRetrofit);
                pharmacyAccountToBeDeleted.add(loggedInCID);
                return loggedInCID;
    }

    private static String getInsertOcidQuery(
            String onlineCustId,
            String authStore,
            String authPatientId,
            String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery = String.format(
                "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterTest
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted
                .forEach(this::deleteOCPRecord);
    }

}
