package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

public class AccountOrchestratorAddDependentMinorNotInCACase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String emailAddress;
  private String phoneNumber;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprMinorHumanPatientId;
  private String caregiverCustomerAccountId, minorCustomerAccountId;
  //  private final String customerAccountId = CommonUtil.randomUUID();
  private String caAdultDob = "1977-01-02";
  private String dpAdultDob = "01021977";
  private String caMinorDob = (LocalDate.now().getYear() - 2) + "-01-11";
  private String dpMinorDob = "0111" + (LocalDate.now().getYear() - 2);
  private String type = "MINOR";
  Map<String, java.util.List<SMSEnrolledProfileListByCidResponse>>
      patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null, minorHumanCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    emailAddress = CommonUtil.generateRandomEmailId(10);

    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

    minorCustomerAccountId =
        UUID.randomUUID().toString(); // No CA account created for Minor. This would cause  error
    createAllCprAccounts();
    createSMSEnrollments();
    createPharmacyAccount(
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob),
        caregiverCustomerAccountId);
    createPharmacyAccount(
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprMinorHumanPatientId), phoneNumber, dpMinorDob),
        minorCustomerAccountId);

    java.util.List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
            AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(reqIdString,reqTrackingString,caregiverCustomerAccountId,domainId,type, accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
  }

  @Test(
      priority = 1,
      description = "Add Minor Account With CustomerAccountId but Without a CA account - Failure")
  public void addMinorAccountWithCidWithoutCaAccount() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    SMSEnrolledProfileListByCidResponse minorPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprMinorHumanPatientId)).get(0);
    DependentInfo2 minorDependentInfo = createDependentInfo2(minorPatientProfile);
    minorDependentInfo.setType("MINOR");
    minorDependentInfo.setDob(dpMinorDob);
    minorDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(minorDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);
    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
    Assert.assertEquals(addDependentResponse.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertTrue(
              errorResponse.getMessage().contains("No information found for given customerAccountId"),
              "Error message does not contain expected text");
  }

  public void createSMSEnrollment(String storeNbr, String patientId, String phoneNumber)
      throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = getTemplateCprRequest();
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    minorHumanCprPatientRequest = getTemplateCprRequest();
    minorHumanCprPatientRequest.getPatientInfo().setBirthDate(caMinorDob);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprMinorHumanPatientId =
        SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId)
        .forEach(
            patientId -> {
              try {
                createSMSEnrollment(storeNbr, String.valueOf(patientId), phoneNumber);
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  private void createPharmacyAccount(
      CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request, String customerAccountId)
      throws IOException {
    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            customerAccountId, domainId, createAccountByPatientIdV1Request);
    if (createAccountByPatientIdV1Response.code() == 200
        && createAccountByPatientIdV1Response.body() != null) {

    } else {
      throw new RuntimeException(
          "Create patient account failed for customerId: "
              + customerAccountId
              + " with HttpStatusCode : "
              + createAccountByPatientIdV1Response.code());
    }
  }


  private CreateAccountByPatientIdV1Request getCreatePharmacyAccountByPatientIdV1Request(
      String storeNbr, String patientId, String phoneNbr, String dob) {
    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(storeNbr);
    customerInfo.setPatientId(patientId);
    customerInfo.setPhoneNumber(phoneNbr);
    customerInfo.setDob(dob);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        new CreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

    return createAccountByPatientIdV1Request;
  }

  private ValidationServiceRequest getTemplateCprRequest() throws IOException {
    return mapper.readValue(
        new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
        ValidationServiceRequest.class);
  }

  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
              }
            });
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId)
        .forEach(
            patientId -> {
              try {
                cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
              } catch (IOException e) {
              }
            });
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
        cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
        && response.body() != null
        && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON(
          "errorMessage",
          String.format(
              "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
              cprRequest.getPatientId(), response.code()));
    }
  }

  public void cleanUpSMSEnrollment(String storeNbr, String patientId) throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {}
  }

  private java.util.List<SMSEnrolledProfileListByCidResponse> extractProfilesFromResponsePayload(
      ArrayList<Object> payload) {
    return payload.stream()
        .map(
            profile ->
                ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) profile),
                    SMSEnrolledProfileListByCidResponse.class))
        .collect(Collectors.toList());
  }

  public DependentInfo2 createDependentInfo2(
      SMSEnrolledProfileListByCidResponse enrolledProfileResponse) {
    CustomerInfo2 enrolledProfile = enrolledProfileResponse.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(enrolledProfileResponse.getValidationToken());
    return fadDependentInfo;
  }
}
