package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper.createPharmacyAccount;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper.getCreatePharmacyAccountByPatientIdV1Request;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper.deleteCprAccount;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.createSMSEnrollmentOrUnenroll;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.getDmPostPreferencesRequest;

public class AccountOrchestratorAddDependentAddPetFlowsTestCaseEmptyDOB {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String emailAddress;
  private String phoneNumber;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprPetPatientId;
  private String caregiverCustomerAccountId;
  private String petDependentCustomerAccountId;
  private String caAdultDob = "1977-01-02";
  private String dpAdultDob = "01021977";
  private String type = "PET";
  Map<String, List<SMSEnrolledProfileListByCidResponse>> patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null, petCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    emailAddress = CommonUtil.generateRandomEmailId(10);

    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    petDependentCustomerAccountId = CommonAccountHelper.createGuestAccountWithWCP("BUGGS", "BUNNY","2010-01-02");

    createAllCprAccounts();
    createSMSEnrollments();
    createPharmacyAccount(
        accountOrchestratorRetrofit,
        domainId,
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob),
        caregiverCustomerAccountId);
    createPharmacyAccount(
        accountOrchestratorRetrofit,
        domainId,
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprPetPatientId), phoneNumber, dpAdultDob),
        petDependentCustomerAccountId);
    List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
  }

  @Test(priority = 1, description = "Add Pet Account - Success")
  public void addPetAccount_Success() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType(type);
    petDependentInfo.setDob("");
    petDependentInfo.tAndCPolicyLanguage("EN");
    DependentConsent consent = new DependentConsent();
    consent.setValue("TRUE");
    consent.setType("PET_DEPENDENT");
    petDependentInfo.setConsent(consent);
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(org.openjdk.tools.javac.util.List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, addDependentResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1001"));
    Assert.assertNotNull(errorMessage);
    Assert.assertTrue(errorMessage.contains("Invalid input request"));
    Assert.assertTrue(errorMessage.contains("Invalid input request. dob has invalid value"));
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = getTemplateCprRequest();
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    petCprPatientRequest = getTemplateCprRequest();
    petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    petCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);
    org.openjdk.tools.javac.util.List.of(adultHumanCprPatientRequest, petCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprPetPatientId = SharedUtils.createCprAccount(petCprPatientRequest, cprPatientUpdateRetrofit);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    org.openjdk.tools.javac.util.List.of(cprAdultHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                DMPostPreferencesRequest dmPostPreferencesRequest =
                    getDmPostPreferencesRequest(
                        storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805");
                createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit, dmPostPreferencesRequest);
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  private ValidationServiceRequest getTemplateCprRequest() throws IOException {
    return mapper.readValue(
        new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
        ValidationServiceRequest.class);
  }

  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    petCprPatientRequest.setPatientId(cprPetPatientId);

    org.openjdk.tools.javac.util.List.of(adultHumanCprPatientRequest, petCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(cprPatientUpdateRetrofit, request);
              } catch (IOException e) {
              }
            });
    org.openjdk.tools.javac.util.List.of(cprAdultHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
              } catch (IOException e) {
              }
            });
  }

  public void cleanUpSMSEnrollment(String storeNbr, String patientId) throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        getDmPostPreferencesRequest(storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805");
    createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit, dmPostPreferencesRequest);
  }

  private AddDependentsV1Response extractDependentsFromResponsePayload(Object payload) {
    return ResponseUtil.parseResponse(
        gson, ((LinkedTreeMap<String, Object>) payload), AddDependentsV1Response.class);
  }

  public DependentInfo2 createDependentInfo2(
      SMSEnrolledProfileListByCidResponse enrolledProfileResponse) {
    CustomerInfo2 enrolledProfile = enrolledProfileResponse.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(enrolledProfileResponse.getValidationToken());
     return fadDependentInfo;
  }
}
