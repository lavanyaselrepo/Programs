package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class AccountOrchestratorAddDependentSimpleFlowsTestCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private String emailAddress;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId;
  private String caregiverCustomerAccountId;
  //  private final String customerAccountId = CommonUtil.randomUUID();
  private String caAdultDob = "1977-01-02";
  private String dpAdultDob = "01021977";
  private String caMinorDob = (LocalDate.now().getYear() - 2) + "-01-11";
  private String dpMinorDob = "0111" + (LocalDate.now().getYear() - 2);
  private String type = "PET,MINOR";
  Map<String, java.util.List<SMSEnrolledProfileListByCidResponse>>
      patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null,
      minorHumanCprPatientRequest,
      petCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    String emailAddress = CommonUtil.generateRandomNumber(10);

    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    createAllCprAccounts();
    createSMSEnrollments();
    createPharmacyAccount(
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob),
        caregiverCustomerAccountId);
    java.util.List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
  }

  @Test(priority = 1, description = "Add Minor Account - Success")
  public void addMinorAccount() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    SMSEnrolledProfileListByCidResponse minorPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprMinorHumanPatientId)).get(0);
    DependentInfo2 minorDependentInfo = createDependentInfo2(minorPatientProfile);
    minorDependentInfo.setType("MINOR");
    minorDependentInfo.setDob(dpMinorDob);
    minorDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(minorDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, addDependentResponse);

    Assert.assertEquals(addDependentResponse.code(), 200, errorMessage);
    Assert.assertNotNull(addDependentResponse.body().getPayload(), "Payload is null");

    AddDependentsV1Response responseBody =
        extractDependentsFromResponsePayload(addDependentResponse.body().getPayload());
    Assert.assertEquals(1, responseBody.getDependents().size());

    validateFamLinksResponse(
        reqId, reqTrackingId, responseBody.getDependents().get(0).getCustomerAccountId());
  }

  @Test(description = "Invalid DomainId - Failure")
  public void invalidDomainIdFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "xyz";

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("PET");
    petDependentInfo.setDob(dpAdultDob);
    petDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, invalidDomainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId,
            invalidDomainId,
            addDependentV1Request,
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. domainId xyz in input is invalid");
  }

  @Test(description = "DoB Mismatch - Failure")
  public void dobMismatch_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse minorPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprMinorHumanPatientId)).get(0);
    DependentInfo2 minorDependentInfo = createDependentInfo2(minorPatientProfile);
    minorDependentInfo.setType("MINOR");
    minorDependentInfo.setDob("01012023");
    minorDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(minorDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);
    Reporter.logJSON("caregiverCustomerAccountId ", caregiverCustomerAccountId);
    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1009");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "DoB mismatch between input and CPR, number of failed authentication attempt has been incremented");
  }

  @Test(description = "Minor DoB Validation - Failure")
  public void minorOlderThan18_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("MINOR");
    petDependentInfo.setDob("01011951");
    petDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
  }

  @Test(description = "Invalid validation token - Failure")
  public void invalidValidationToken_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("PET");
    petDependentInfo.setConsent(new DependentConsent().type("pet_dependent").value("true"));
    petDependentInfo.tAndCPolicyLanguage("EN");
    petDependentInfo.setValidationToken("erUL6TYp1pkePTsuImnrqI7RYr4o0q40zxy6rm6fVskwDmcYrmOxrv6OPdN+Sqg2fD6gywtG/aD15yFu4ioPuYfIwqxkWfVPHoPStWz3I7u8sGoliJ3IInDcl5/yBFVP0xSZymNsDX/PhuKV2ABrk2bK/haSmjhMpygI0GhNOqSlPE1RZUgTW4vM+PYeeqAxmTJHezcPSw==");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "PET", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 500, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1007");
    Assert.assertTrue(
        errorResponse
            .getMessage()
            .contains(
                "Error in encryption at DP Account Orchestrator: Error decrypting validation token: Tag mismatch"));
  }

  @Test(description = "Invalid validation token - another patient's token passed - Failure")
  public void incorrectValiationToken_AnotherPatientTokenPassed_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("PET");
    petDependentInfo.setDob(dpAdultDob);
    petDependentInfo.tAndCPolicyLanguage("EN");

    String minorPatientValidationToken =
        patientIdToEnrolledProfilesListMap
            .get(String.valueOf(cprMinorHumanPatientId))
            .get(0)
            .getValidationToken();
    petDependentInfo.setValidationToken(minorPatientValidationToken);
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "PET", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1009");
    Assert.assertTrue(
        errorResponse
            .getMessage()
            .contains("DoB mismatch between input and CPR, number of failed authentication attempt has been incremented"));
  }

  @Test(description = "ADULT dependent addition - Failure")
  public void adultDependentAddition_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("ADULT");
    petDependentInfo.setDob(LocalDate.now().toString());
    petDependentInfo.tAndCPolicyLanguage("EN");
    petDependentInfo.setValidationToken("xyz");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "ADULT", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(), "Invalid input request. Date of Birth "+LocalDate.now().toString()+" could not be parsed. Expected format is : MMddyyyy");
  }

  @Test(priority = 1, description = "Minor Empty DoB Validation - Failure")
  public void minorWithEmptyDOB_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("MINOR");
    petDependentInfo.setDob("");
    petDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorMessage.contains("Invalid input request. dob has invalid value"));
  }

  @Test(priority = 2, description = "Minor NULL DoB Validation - Failure")
  public void minorWithNullDOB_Failure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setType("MINOR");
    petDependentInfo.setDob(null);
    petDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, "MINOR", reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, addDependentResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertTrue(errorMessage.contains("Invalid input request. dob has invalid value"));
  }

  private void validateFamLinksResponse(
      String reqId, String reqTrackingId, String minorCustomerAccountId) throws IOException {
    String linkageStatus = "ALL";
    Response<ServiceResponse> getFamLinksV1Response =
        accountOrchestratorRetrofit.getFamLinksV1(
            caregiverCustomerAccountId,
            domainId,
            "DEPENDENT",
            reqId,
            reqTrackingId,
                linkageStatus);

    String getFamLinksErrorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1Response);

    GetFamLinksResponse getFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getFamLinksV1Response.body().getPayload()),
            GetFamLinksResponse.class);

    Assert.assertEquals(getFamLinksV1Response.code(), 200, getFamLinksErrorMessage);
    Assert.assertNotNull(getFamLinksV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 1);

    DependentInfo dependentInfo = getFamLinksResponse.getDependentsInfo().get(0);

    Assert.assertEquals(dependentInfo.getLinkageStatus(), DependentInfo.LinkageStatusEnum.ACTIVE);
    Assert.assertEquals(dependentInfo.getType().getValue(), "MINOR");
    Assert.assertEquals(dependentInfo.getCustomerAccountId(), minorCustomerAccountId);
  }

  private void createSMSEnrollment(String storeNbr, String patientId, String phoneNumber)
      throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = getTemplateCprRequest();
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    minorHumanCprPatientRequest = getTemplateCprRequest();
    minorHumanCprPatientRequest.getPatientInfo().setBirthDate(caMinorDob);

    petCprPatientRequest = getTemplateCprRequest();
    petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    petCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);
    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest, petCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprMinorHumanPatientId =
        SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprPetPatientId = SharedUtils.createCprAccount(petCprPatientRequest, cprPatientUpdateRetrofit);

    Reporter.logJSON("cprMinorHumanPatientId ", cprMinorHumanPatientId);
    Reporter.logJSON("cprAdultHumanPatientId ", cprAdultHumanPatientId);
    Reporter.logJSON("cprPetPatientId ", cprPetPatientId);
    Reporter.logJSON("storeNbr ", storeNbr);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                createSMSEnrollment(storeNbr, String.valueOf(patientId), phoneNumber);
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  private void createPharmacyAccount(
      CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request, String customerAccountId)
      throws IOException {
    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            customerAccountId, domainId, createAccountByPatientIdV1Request);
    if (createAccountByPatientIdV1Response.code() == 200
        && createAccountByPatientIdV1Response.body() != null) {

    } else {
      throw new RuntimeException(
          "Create patient account failed for customerId: "
              + customerAccountId
              + " with HttpStatusCode : "
              + createAccountByPatientIdV1Response.code());
    }
  }


  private CreateAccountByPatientIdV1Request getCreatePharmacyAccountByPatientIdV1Request(
      String storeNbr, String patientId, String phoneNbr, String dob) {
    CreateAccountCustomerInfo customerInfo = new CreateAccountCustomerInfo();
    customerInfo.setStoreNbr(storeNbr);
    customerInfo.setPatientId(patientId);
    customerInfo.setPhoneNumber(phoneNbr);
    customerInfo.setDob(dob);
    customerInfo.setTandCPolicyLanguage("EN");

    CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request =
        new CreateAccountByPatientIdV1Request();
    createAccountByPatientIdV1Request.setCustomerInfo(customerInfo);

    return createAccountByPatientIdV1Request;
  }

  private ValidationServiceRequest getTemplateCprRequest() throws IOException {
    return mapper.readValue(
        new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
        ValidationServiceRequest.class);
  }

  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);
    petCprPatientRequest.setPatientId(cprPetPatientId);

    List.of(adultHumanCprPatientRequest, minorHumanCprPatientRequest, petCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
              }
            });
    List.of(cprAdultHumanPatientId, cprMinorHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
              } catch (IOException e) {
              }
            });
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
        cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
        && response.body() != null
        && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON(
          "errorMessage",
          String.format(
              "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
              cprRequest.getPatientId(), response.code()));
    }
  }

  private void cleanUpSMSEnrollment(String storeNbr, String patientId) throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {}
  }

  private AddDependentsV1Response extractDependentsFromResponsePayload(Object payload) {
    return ResponseUtil.parseResponse(
        gson, ((LinkedTreeMap<String, Object>) payload), AddDependentsV1Response.class);
  }

  private DependentInfo2 createDependentInfo2(
      SMSEnrolledProfileListByCidResponse enrolledProfileResponse) {
    CustomerInfo2 enrolledProfile = enrolledProfileResponse.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(enrolledProfileResponse.getValidationToken());
    return fadDependentInfo;
  }
}
