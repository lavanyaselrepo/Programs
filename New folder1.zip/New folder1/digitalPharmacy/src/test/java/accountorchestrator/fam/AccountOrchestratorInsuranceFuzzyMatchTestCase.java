package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.InsuranceFuzzyMatchV1Request;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.InsuranceFuzzyMatchV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class AccountOrchestratorInsuranceFuzzyMatchTestCase {
    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private final Gson gson = new GsonBuilder().create();
    private String accountType = "INDIVIDUAL";
    private String customerType = "INDIVIDUAL";
    private String caregiverCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    private String caregiverCustomerAccountId ;
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;

    @BeforeClass
    void setContext() throws Exception {

        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverCustomerEmailId);
    }

    @Test(
            priority = 0,
            description = "Insurance Fuzzy Match Success")
    public void insuranceInfoMatchSuccessWithGivenInfo() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.insuranceFuzzyMatchV1(
                        caregiverCustomerAccountId,
                        domainId,
                        getRequest(),
                        reqId,
                        reqTrackingId);
        InsuranceFuzzyMatchV1Response insuranceFuzzyMatchResponse =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) response.body().getPayload()),
                        InsuranceFuzzyMatchV1Response.class);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body().getPayload(), "Payload is null");

        // Add assertions to check response content
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getCustomerAccountId(), "3ea300c4-343b-4c0f-8698-42baec4f9bd8");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getEmailId(), "randomDependentEmailId@gmail.com");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getFirstName(), "MPISER");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getMiddleName(), "M");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getLastName(), "FROMCPR");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getGender(), "F");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getType(), "ADULT");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getDob(), "12211997");
        Assert.assertEquals(insuranceFuzzyMatchResponse.getCustomerInfo().getLinkageStatus(), "DELINKED");
    }

    @Test(
            priority = 1,
            description = "Insurance Fuzzy Match Failed")
    public void insuranceInfoMatchFailedWithGivenInfo() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = trackID;
        String reqTrackingId = trackID;
        InsuranceFuzzyMatchV1Request insuranceFuzzyMatchV1Request = getRequest();
        insuranceFuzzyMatchV1Request.setCardHolderId("WBR45");
        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.insuranceFuzzyMatchV1(
                        caregiverCustomerAccountId,
                        domainId,
                        insuranceFuzzyMatchV1Request,
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);

        // Step - 4: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1057");
        Assert.assertNotNull(
                errorResponse.getMessage(),
                String.format(
                        "InsuranceInfo doesn't matched"));
    }

    @Test(
            priority = 2,
            description = "token Decryption failed")
    public void insuranceInfoMatchtokenDecryptionFailed() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = trackID;
        String reqTrackingId = trackID;
        InsuranceFuzzyMatchV1Request insuranceFuzzyMatchV1Request = getRequest();
        insuranceFuzzyMatchV1Request.setCardHolderId(CommonUtil.generateRandomString(10));
        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.insuranceFuzzyMatchV1(
                        caregiverCustomerAccountId,
                        domainId,
                        insuranceFuzzyMatchV1Request,
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);

        // Step - 4: Building errorMessage in case the Assert for response fails
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1057");
        Assert.assertNotNull(
                errorResponse.getMessage(),
                String.format(
                        "InsuranceInfo doesn't matched"));
    }


    private InsuranceFuzzyMatchV1Request getRequest() {

        InsuranceFuzzyMatchV1Request request = new InsuranceFuzzyMatchV1Request();
        request.setToken("ep1bqGAjxoQeGzJpagK0/NjFd7wqhYZnm1Po6UOIV59lQTdf2zjw7amDPOluB+VpLl3wzQUAo+Tfty5n9HxZ8NGZlvl6TPFFFJvLszn3dfXqtTJywZGPbBvPhoznR1QVhl/ZoWEiQjLNnrKz8zBbvXf82jyxuw99miMj/l5jKp+3A39mPQZAR8LCrq0pmxnMNZx+dKn7eYHZN3thkw1XYuDMXxhbNgm0SuahtcyShjxM5idX1n6cdNWDwNtwjkeyQnzpR+jRx7DwLLE63yPHE8RUyspq0C2daz2Gc7In+/6581FYOY7wz47oJ9Kc1yc/uKWkVK5BUYTOwgkYAEwkiL6IGwuuXkbNnK6VEoXlHQE90nCwqfEUNReC5eqA/vsv+ozHrHl/A/Crzn+JFOnlrwUzWqtw6FzZCfHZFcakbS8FL8kG7VxgFSdWH8HuNpqd3CG5YOSRO41dkjUMCZIaWXCrga8s0Pkkyeo35D4kLNzg2IZ3rIkf90ChULi3ctvs8iBOW3ZmksydRWyF1rcOPyOCxVJXOXJIXzAeAF30l775hjslCacjEd3/WEPkG2O34Fry9VC6xFIFqjwx8conKmXrlDM+l6OTeE/hC7Th5YWeESMBOPvZlGL5dePJBw==");
        request.setCardHolderId("WBR345");
        request.setRxBin("AGCFWQ");
        return request;
    }

}
