package accountorchestrator.fam.getCaregivers;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpdateFamRequestsV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.ApprovalStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wiapp.restapi.WIAppRetrofit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CaregiverInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.GetFamLinksResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class AccountOrchestratorGetCaregiverTestFlow {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private WCPRetroFit wcpRetroFit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String filter = "CAREGIVER";
  private List<String> validFilterTypes = Arrays.asList("DEPENDENT", "CAREGIVER");
  private String accountCreationSource = "smsOtpVerification";
  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonDobCPRFormat = null;
  private String commonDobDPFormat = null;
  private String caregiver1 = null;
  private String dependentCustomerAccountId = null;
  private String dependentCustomerEmailId = null;
  private String commonPhoneNo = "1234567829";
  private String commonPassword = "Test@12345";
  private String trackID = CommonUtil.randomUUID();

  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetroFit = new WCPRetroFit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    dependentCustomerEmailId = CommonUtil.generateRandomEmailId(10);
    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    Date date = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

    String caregiver1EmailId = CommonUtil.generateRandomEmailId(10);
    String caregiver1FirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiver1LastName = RandomStringUtils.randomAlphabetic(5);

    caregiver1 = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiver1EmailId,
            commonPassword,
            commonPhoneNo,
            caregiver1FirstName,
            caregiver1LastName,
            trackID);

    createCPRAccount(commonStoreNbr, commonPatientId, caregiver1FirstName, caregiver1LastName);
    createPharmacyAccount(caregiver1, commonStoreNbr, commonPatientId);

    String dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
    String dependent1LastName = RandomStringUtils.randomAlphabetic(5);
    dependentCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            dependentCustomerEmailId,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);


//   Add dependent to WCP using the new common method
    WCPAddDependentRequest.Dependent wcpDependent = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiver1).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentCustomerAccountId).build())
            .memberType(Type.ADULT.name())
            .notificationEmail(dependentCustomerEmailId)
            .membershipStatus(ApprovalStatus.PENDING.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest, dependentCustomerAccountId);

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    String caregiver2EmailId = CommonUtil.generateRandomEmailId(10);
    String caregiver2FirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiver2LastName = RandomStringUtils.randomAlphabetic(5);
    String caregiver2  = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiver2EmailId,
            commonPassword,
            commonPhoneNo,
            caregiver2FirstName,
            caregiver2LastName,
            trackID);

    createCPRAccount(commonStoreNbr, commonPatientId, caregiver2FirstName, caregiver2LastName);
    createPharmacyAccount(caregiver2, commonStoreNbr, commonPatientId);

    // Add dependent to WCP for caregiver2 with ACTIVE status
    WCPAddDependentRequest.Dependent wcpDependent2 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiver2).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentCustomerAccountId).build())
            .memberType(Type.ADULT.name())
            .notificationEmail(dependentCustomerEmailId)
            .membershipStatus(ApprovalStatus.ACTIVE.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest2 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent2)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest2, dependentCustomerAccountId);

    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    String caregiver3EmailId = CommonUtil.generateRandomEmailId(10);
    String caregiver3FirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiver3LastName = RandomStringUtils.randomAlphabetic(5);
    String caregiver3  = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            caregiver3EmailId,
            commonPassword,
            commonPhoneNo,
            caregiver3FirstName,
            caregiver3LastName,
            trackID);
    createCPRAccount(commonStoreNbr, commonPatientId, caregiver3FirstName, caregiver3LastName);
    createPharmacyAccount(caregiver3, commonStoreNbr, commonPatientId);

    // Add dependent to WCP for caregiver3 with APPROVED status
    WCPAddDependentRequest.Dependent wcpDependent3 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiver3).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentCustomerAccountId).build())
            .memberType(Type.ADULT.name())
            .notificationEmail(dependentCustomerEmailId)
            .membershipStatus(ApprovalStatus.APPROVED.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequest3 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependent3)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequest3, dependentCustomerAccountId);
  }

  @AfterClass
  void cleanUp() throws IOException {

    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account

    cprProfilesToBeDeletedList.forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                Response<ValidationServiceResponse> response =
                        cprPatientUpdateRetrofit.validateProfile(request);
                if (!(response.code() == 202
                        && response.body() != null
                        && response.body().getErrors().isEmpty())
                        && response.code() != 406) {
                  throw new RuntimeException(
                          "CPR Account failed to update with status code 20708 for PatientId :"
                                  + request.getPatientId()
                                  + " StoreNbr :"
                                  + request.getStoreNbr()
                                  + " . HttpStatusCode : "
                                  + response.code());
                }
              } catch (IOException e) {
              }
            });
  }

  public void InsertDataToFamReqTable(
          String dependentCustomerEmailId,
          String caregiverCustomerAccountId,
          String patientId,
          String storeNbr)
          throws IOException {
    UpdateFamRequestsV1Request updateFamRequestsV1Request =
            getUpdateFamRequestsV1Request(
                    dependentCustomerEmailId, caregiverCustomerAccountId, patientId, storeNbr);
    Response<ServiceResponse> response = null;

    // This will try to insert a record in fam request table, 3 times if insertion fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.updateFamRequests(
                      domainId,
                      updateFamRequestsV1Request,
                      reqIdString,
                      reqTrackingString,
                      DependentInfo.LinkageStatusEnum.PENDING_ACCOUNT_CREATION.toString());
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity update fam links failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  private UpdateFamRequestsV1Request getUpdateFamRequestsV1Request(
          String dependentCustomerAccountId,
          String caregiverCustomerAccountId,
          String patientId,
          String storeNbr) {
    LinkedHashMap<String, String> additionalInfo = new LinkedHashMap<>();
    additionalInfo.put("storeNbr", storeNbr);
    additionalInfo.put("patientId", patientId);
    return UpdateFamRequestsV1Request.builder()
            .requestInfo(
                    org.openjdk.tools.javac.util.List.of(
                            UpdateFamRequestsV1Request.RequestInfo.builder()
                                    .additionalInfo(additionalInfo)
                                    .dependentId(dependentCustomerAccountId)
                                    .caregiverId(caregiverCustomerAccountId)
                                    .build()))
            .build();
  }

  /**
   * Create CPR Account
   *
   * @throws IOException
   */
  public void createCPRAccount(String storeNbr, String patientId, String firstName, String lastName)
          throws IOException {
    cprPatientRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(patientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(firstName);
    cprPatientRequest.getPatientInfo().setLastName(lastName);

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
        break;
      }
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  public void createPharmacyAccount(
          String customerAccountId, String commonStoreNbr, String commonPatientId) throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
            getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
              accountEntityServiceRetrofit.createPharmacyAccountV1(
                      customerAccountId,
                      domainId,
                      createPharmacyAccountV1Request,
                      reqIdString,
                      reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
              && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
          String commonStoreNbr, String commonPatientId) {
    return CreatePharmacyAccountV1Request.builder()
            .accountCreationSource(accountCreationSource)
            .customerInfo(
                    CreatePharmacyAccountV1Request.CustomerInfo.builder()
                            .storeNbr(commonStoreNbr)
                            .patientId(commonPatientId)
                            .dob(commonDobDPFormat)
                            .build())
            .build();
  }

  /**
   * deletes cpr account by setting the PatientStatusCode as 20708
   *
   * @param storeNbr
   * @param patientId
   * @param firstName
   * @param lastName
   * @throws IOException
   */
  public void deleteCPRAccount(String storeNbr, String patientId, String firstName, String lastName)
          throws IOException {
    ValidationServiceRequest cprRequest =
            mapper.readValue(
                    new File(
                            "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                    ValidationServiceRequest.class);

    cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprRequest.setPatientId(Integer.parseInt(patientId));
    cprRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprRequest.getPatientInfo().setFirstName(firstName);
    cprRequest.getPatientInfo().setLastName(lastName);
    cprRequest.getPatientInfo().setPatientStatusCode(20708);

    // This will try to delete an account in CPR 3 times if account deletion fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
              cprPatientUpdateRetrofit.validateProfile(cprRequest);
      if (!(response.code() == 202
              && response.body() != null
              && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
                  "CPR Account deletion failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    // This is needed because CPR account deletion is async, and it usually takes a couple of
    // seconds to reflect account deletion
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test(
          priority = 0,
          description = "Get fam links success case for caregivers with all linkage status")
  public void getFamLinksV1SuccessForCaregiversWithAllLinkageStatus() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForCaregivers.body().getPayload(), "Payload is null");
    List<CaregiverInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getCaregiversInfo().stream()
                    .map(CaregiverInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.PENDING));
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.ACTIVE));
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.APPROVED));
  }

  @Test(priority = 1, description = "Get fam links for caregivers with filter on linkage status")
  public void getFamLinksV1ForCaregiversWithFilterOnLinkageStatus() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String linkageStatus = "PENDING";
    logFlowIdentifiers(dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);
    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForCaregivers.body().getPayload(), "Payload is null");
    List<CaregiverInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getCaregiversInfo().stream()
                    .map(CaregiverInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.PENDING));
    Assert.assertEquals(1, getFamLinksResponse.getCaregiversInfo().size());
  }

  @Test(
          priority = 2,
          description = "Get fam links for caregivers with linkage status as Active and Approved")
  public void getFamLinksV1ForCaregiversWithLinkageStatusAsActiveAndApproved() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String linkageStatus = "ACTIVE,APPROVED";
    logFlowIdentifiers(dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);
    // Step - 5: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForCaregivers.body().getPayload(), "Payload is null");
    List<CaregiverInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getCaregiversInfo().stream()
                    .map(CaregiverInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.APPROVED));
    Assert.assertTrue(linkageStatusEnumList.contains(CaregiverInfo.LinkageStatusEnum.ACTIVE));
    Assert.assertEquals(2, getFamLinksResponse.getCaregiversInfo().size());
  }

  @Test(
          priority = 3,
          description = "Get fam links for caregivers with linkage status as Active and Approved")
  public void getFamLinksV1ForCaregiversWithCAAddDependent404()
          throws IOException, InterruptedException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId);
    String caregiverCustomerAccountId = CommonUtil.randomUUID();
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    // Step -2: Insert a caregiver who don't have CA account in fam request table
    InsertDataToFamReqTable(
            dependentCustomerEmailId, caregiverCustomerAccountId, storeNbr, patientId);
    // Step - 3: Calling getFamLinksV1 with a valid caregiverCustomerAccountId ,valid domainId and
    // valid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 5: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);
    // Step - 6: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 200, errorMessage);
    Assert.assertNotNull(getFamLinksV1ResponseForCaregivers.body().getPayload(), "Payload is null");
    List<CaregiverInfo.LinkageStatusEnum> linkageStatusEnumList =
            getFamLinksResponse.getCaregiversInfo().stream()
                    .map(CaregiverInfo::getLinkageStatus)
                    .collect(Collectors.toList());
    Assert.assertEquals(getFamLinksResponse.getCaregiversInfo().size(), 3);
  }

  @Test(priority = 4, description = "Get fam links invalid request case for caregivers")
  public void getFamLinksV1InvalidRequestForCaregivers() throws IOException {

    // *****  CASE 1 - Filter is invalid *****
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidFilter = "CARE";
    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentCustomerAccountId, domainId, invalidFilter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId,valid domainId and
    // invalid filter
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId,
                    domainId,
                    invalidFilter,
                    reqId,
                    reqTrackingId,
                    linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(),
            String.format(
                    "Input contains following disallowed type: %s, the allowed types are %s",
                    invalidFilter, validFilterTypes));

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    logFlowIdentifiers(dependentCustomerAccountId, invalidDomainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a valid caregiverCustomerAccountId,invalid
    // domainId and valid filter
    getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentCustomerAccountId,
                    invalidDomainId,
                    filter,
                    reqId,
                    reqTrackingId,
                    linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "Invalid input request . domainId is null/Invalid domainId");
  }

  @Test(
          priority = 5,
          description =
                  "Get fam links API call 404 not found case where 404 is returned from CA for given caregiverCustomerAccountId for Caregivers")
  public void getFamLinksV1Request404FromCAForCaregivers() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String dependentAccountId = CommonUtil.randomUUID();
    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentAccountId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a caregiverCustomerAccountId which doesn't exists in CA
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 404, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7001");
    Assert.assertNotNull(
            errorResponse.getMessage(), "No information found for given customerAccountId in CA");
  }

  @Test(
          priority = 6,
          description =
                  "Get fam links API for caregivers call returns empty list because account is not present in OCP for given caregiverCustomerAccountId, so caregiverInfo List is empty as there is only one caregiver which is not in OCP")
  public void getFamLinksV1EmptyListWhenNoEntryInOCP() throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerEmailId1 = CommonUtil.generateRandomEmailId(10);
    String customerEmailId2 = CommonUtil.generateRandomEmailId(10);
    String caregiver3FirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiver3LastName = RandomStringUtils.randomAlphabetic(5);
    String dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
    String dependent1LastName = RandomStringUtils.randomAlphabetic(5);

    String caregiver3 = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            customerEmailId1,
            commonPassword,
            commonPhoneNo,
            caregiver3FirstName,
            caregiver3LastName,
            trackID);
    String dependentId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            customerEmailId2,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);

    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentId, domainId, filter, reqId, reqTrackingId);

    // Step - 1b:  Adding caregiver3 to dependentId using WCP
    WCPAddDependentRequest.Dependent wcpDependentMinor = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiver3).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentId).build())
            .memberType(Type.MINOR.name())
            .membershipStatus(ApprovalStatus.PENDING.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequestMinor = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependentMinor)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequestMinor, dependentId);

    // Step - 2: Calling getFamLinksV1 with a caregiver4 which is having caregiver3 which is not in
    // OCP
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 4: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step -5: Check if the list is empty or not
    Assert.assertEquals(getFamLinksResponse.getCaregiversInfo().size(), 0);
  }

  @Test(
          priority = 7,
          description =
                  "Get fam links API call for caregivers returns empty list because account is not present in CPR for given caregiverCustomerAccountId, so caregiverInfo List is empty as there is only one caregiver which is not in CPR")
  public void getFamLinksV1EmptyListWhenNoEntryInCPR() throws Exception {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerEmailId2 = CommonUtil.generateRandomEmailId(10);
    String dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
    String dependent1LastName = RandomStringUtils.randomAlphabetic(5);

    String dependentId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            customerEmailId2,
            commonPassword,
            commonPhoneNo,
            dependent1FirstName,
            dependent1LastName,
            trackID);

    String linkageStatus = "ALL";
    logFlowIdentifiers(dependentId, domainId, filter, reqId, reqTrackingId);

    // Step - 1b: Creating test data
    String customerEmailId1 = CommonUtil.generateRandomEmailId(10);
    String caregiver3FirstName = RandomStringUtils.randomAlphabetic(5);
    String caregiver3LastName = RandomStringUtils.randomAlphabetic(5);

    String caregiver3 = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(
            customerEmailId1,
            commonPassword,
            commonPhoneNo,
            caregiver3FirstName,
            caregiver3LastName,
            trackID);

    String caregiver3StoreNbr = CommonUtil.generateRandomNumber(6);
    String caregiver3PatientId = CommonUtil.generateRandomNumber(9);

    // Add dependent to WCP for caregiver3 using WCP
    WCPAddDependentRequest.Dependent wcpDependentMinor2 = WCPAddDependentRequest.Dependent.builder()
            .ownerId(WCPAddDependentRequest.Identifier.builder().id(caregiver3).build())
            .groupType(GroupType.FAM.name())
            .memberId(WCPAddDependentRequest.Identifier.builder().id(dependentId).build())
            .memberType(Type.MINOR.name())
            .membershipStatus(ApprovalStatus.PENDING.name())
            .build();
    WCPAddDependentRequest wcpAddDependentRequestMinor2 = WCPAddDependentRequest.builder()
            .payload(WCPAddDependentRequest.Payload.builder()
                    .dependent(wcpDependentMinor2)
                    .build())
            .build();
    wcpRetroFit.addDependent(wcpAddDependentRequestMinor2, dependentId);

    createCPRAccount(
            caregiver3StoreNbr, caregiver3PatientId, caregiver3FirstName, caregiver3LastName);
    createPharmacyAccount(caregiver3, caregiver3StoreNbr, caregiver3PatientId);

    // Step - 1c: delete the caregiver3 account from cpr which is also a dependent of caregiver4
    deleteCPRAccount(
            caregiver3StoreNbr, caregiver3PatientId, caregiver3FirstName, caregiver3LastName);

    // Step - 2: Calling getFamLinksV1 with caregiver4 customerAccountId
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    dependentId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing the response to the GetFamLinksResponse class so that we can assert
    // GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1ResponseForCaregivers.body().getPayload()),
                    GetFamLinksResponse.class);

    // Step -4: Check if the list is empty or not
    Assert.assertEquals(getFamLinksResponse.getCaregiversInfo().size(), 0);
  }

  @Test(
          priority = 8,
          description =
                  "Get fam links API call 400 case where 400 is returned from CA for given caregiverCustomerAccountId for Caregivers")
  public void getFamLinksV1Request400FromCAForCaregivers() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId =  "2345058";
    String linkageStatus = "ALL";
    logFlowIdentifiers(customerAccountId, domainId, filter, reqId, reqTrackingId);

    // Step - 2: Calling getFamLinksV1 with a invalid caregiverCustomerAccountId which doesn't
    // exists in CA
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
            getFamLinksV1ResponseForCaregivers =
            accountOrchestratorRetrofit.getFamLinksV1(
                    customerAccountId, domainId, filter, reqId, reqTrackingId, linkageStatus);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getFamLinksV1ResponseForCaregivers);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getFamLinksV1ResponseForCaregivers.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-7002");
    Assert.assertNotNull(errorResponse.getMessage(), "Invalid customerAccountId sent to CA");
  }

  private static void logFlowIdentifiers(
          String customerAccountId,
          String domainId,
          String filter,
          String reqId,
          String reqTrackingId) {
    Reporter.logJSON("customerAccountId", customerAccountId);
    Reporter.logJSON("domainId", domainId);
    Reporter.logJSON("filter", filter);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
