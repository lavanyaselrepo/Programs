package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.postpreferenceorch.model.response.UpdatePreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.postpreferenceorch.restapi.PostPreferenceOrchRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPCreateGuestAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPCreateGuestAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetDependentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DelinkDependentRes;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DelinkDependentsRequestV1;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AccountOrchestratorDelinkDependentsTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetroFit;
    private PostPreferenceOrchRetrofit postPreferenceOrchRetrofit;
    private ObjectMapper mapper = new ObjectMapper();
    private Gson gson = new GsonBuilder().create();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String filter = "DEPENDENT";
    private String accountCreationSource = "idVerification";
    private String accountType = "INDIVIDUAL";
    private String HUMAN = "HUMAN";
    private String PET = "PET";
    private String ADULT = "ADULT";
    private String customerType = "INDIVIDUAL";
    private final String MINOR = "MINOR";
    // Common store number for all accounts
    private final String commonStoreNumber = "9928";
    private final String commonDobCPRFormatForOlderThan18 = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis() - 568025138000L)); // setting dob to 18 years ago from current date

    // Caregiver - hardcoded values
    private final String caregiverCustomerAccountId = "b56f47af-e03a-4787-89d6-267e5c8f325c";
    private final String caregiverPatientId = "910580428";
    private final String caregiverStoreNbr = commonStoreNumber;

    // Dependent 1 - ADULT, ACTIVE
    private final String dependent1CustomerAccountId = "595f223c-95b5-4848-9e4b-67065320fac7";
    private final String dependent1PatientId = "910580431";
    private final String dependent1StoreNbr = commonStoreNumber;

    // Dependent 2 - ADULT, APPROVED
    private final String dependent2CustomerAccountId = "21106ac7-d34f-4fbe-a14f-963c91503212";
    private final String dependent2PatientId = "910580435";
    private final String dependent2StoreNbr = commonStoreNumber;

    // Dependent 3 - MINOR
    private final String dependent3CustomerAccountId = "22a0519b-f582-44c6-8ba1-87716033c614";
    private final String dependent3PatientId = "910580453";
    private final String dependent3StoreNbr = commonStoreNumber;

    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetroFit = new WCPRetroFit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        postPreferenceOrchRetrofit = new PostPreferenceOrchRetrofit();

        // Add dependent1 - ADULT, ACTIVE
        WCPAddDependentRequest wcpAddDependentRequest1 = CommonAccountHelper.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent1CustomerAccountId,
                caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest1, caregiverCustomerAccountId);

        // Add dependent2 - ADULT, APPROVED
        WCPAddDependentRequest wcpAddDependentRequest2 = CommonAccountHelper.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent2CustomerAccountId,
                caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest2, caregiverCustomerAccountId);

        // Add dependent3 - MINOR
        WCPAddDependentRequest wcpAddDependentRequest3 = CommonAccountHelper.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent3CustomerAccountId,
                caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest3, caregiverCustomerAccountId);

        // Wait for dependent linkage to be reflected
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Clean up for all created cpr accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    @Test(
            priority = 1,
            description = "Delink Dependent Invalid Dependent ")
    public void deLinkDependentInValidDependent() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);

        // Step - 2: Calling delinkDependent with a valid caregiverCustomerAccountId ,valid domainId
        DelinkDependentsRequestV1 delinkDependentsRequestV1 = new DelinkDependentsRequestV1();
        String dependentCustomerAccountId = UUID.randomUUID().toString();
        delinkDependentsRequestV1.setDependentCustomerAccountId(dependentCustomerAccountId);
        List<DelinkDependentsRequestV1> lis = new ArrayList<>();
        lis.add(delinkDependentsRequestV1);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> delinkDependentsResponse = accountOrchestratorRetrofit.delinkDependent(
                caregiverCustomerAccountId, domainId, lis, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, delinkDependentsResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(delinkDependentsResponse.code(), 500, errorMessage);


    }


    @Test(
            priority = 2,
            description = "Delink Dependent Success ")
    public void deLinkDependentSuccess() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);


        // Step - 2: Calling delinkDependent with a valid caregiverCustomerAccountId ,valid domainId
        DelinkDependentsRequestV1 delinkDependentsRequestV1 = new DelinkDependentsRequestV1();
        delinkDependentsRequestV1.setDependentCustomerAccountId(dependent1CustomerAccountId);
        List<DelinkDependentsRequestV1> lis = new ArrayList<>();
        lis.add(delinkDependentsRequestV1);
        Response<UpdatePreferencesResponse> updatePreferenceResponse1 = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId,
                caregiverCustomerAccountId,
                dependent1CustomerAccountId,
                true);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getFamLinksV1ResponseForDependents =
                accountOrchestratorRetrofit.delinkDependent(
                        caregiverCustomerAccountId, domainId, lis, reqId, reqTrackingId);

        // Step - 4: Parsing the response to the DelinkDependent Response class so that we can assert
        ArrayList<LinkedTreeMap<String, Object>> responseList = (ArrayList<LinkedTreeMap<String, Object>>) getFamLinksV1ResponseForDependents.body().getPayload();
        DelinkDependentRes res =
                ResponseUtil.parseResponse(
                        gson,
                        responseList.get(0),
                        DelinkDependentRes.class);
        Response<UpdatePreferencesResponse> updatePreferenceResponse = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId,
                caregiverCustomerAccountId,
                dependent1CustomerAccountId,
                false);
        // Step - 5: Asserting response
        Assert.assertEquals(updatePreferenceResponse.code(), 400);
        Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 200);
        Assert.assertNotNull(responseList, "Payload is null");
        Assert.assertEquals(res.getDependentCustomerAccountId(),
                dependent1CustomerAccountId);

    }

    @Test(
            priority = 3,
            description = "Delink Dependent Multiple dependents partial success ")
    public void deLinkDependentMultipleDependentPartialSuccess() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);

        // Step - 2: Calling delinkDependent with a valid caregiverCustomerAccountId ,valid domainId
        DelinkDependentsRequestV1 delinkDependentsRequestV1 = new DelinkDependentsRequestV1();
        delinkDependentsRequestV1.setDependentCustomerAccountId(dependent1CustomerAccountId);
        DelinkDependentsRequestV1 delinkDependentsRequestV11 = new DelinkDependentsRequestV1();
        delinkDependentsRequestV11.setDependentCustomerAccountId(dependent2CustomerAccountId);
        List<DelinkDependentsRequestV1> lis = new ArrayList<>();
        lis.add(delinkDependentsRequestV1);
        lis.add(delinkDependentsRequestV11);

        // Add dependent2 - ADULT, APPROVED
        WCPAddDependentRequest wcpAddDependentRequest2 = CommonAccountHelper.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent2CustomerAccountId,
                caregiverCustomerAccountId);
        wcpRetroFit.addDependent(wcpAddDependentRequest2, caregiverCustomerAccountId);

        postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId,
                caregiverCustomerAccountId,
                dependent2CustomerAccountId,
                true);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getFamLinksV1ResponseForDependents =
                accountOrchestratorRetrofit.delinkDependent(
                        caregiverCustomerAccountId, domainId, lis, reqId, reqTrackingId);

        // Step - 4: Parsing the response to the DelinkDependent Response class so that we can assert
        ArrayList<LinkedTreeMap<String, Object>> responseList = (ArrayList<LinkedTreeMap<String, Object>>) getFamLinksV1ResponseForDependents.body().getPayload();
        DelinkDependentRes res =
                ResponseUtil.parseResponse(
                        gson,
                        responseList.get(0),
                        DelinkDependentRes.class);
        DelinkDependentRes res1 =
                ResponseUtil.parseResponse(
                        gson,
                        responseList.get(1),
                        DelinkDependentRes.class);
        Response<UpdatePreferencesResponse> updatePreferenceResponse1 = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId,
                caregiverCustomerAccountId,
                dependent1CustomerAccountId,
                false);
        Response<UpdatePreferencesResponse> updatePreferenceResponse2 = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId,
                caregiverCustomerAccountId,
                dependent2CustomerAccountId,
                false);
        // Step - 5: Asserting response
        Assert.assertEquals(updatePreferenceResponse1.code(), 400);
        Assert.assertEquals(updatePreferenceResponse2.code(), 400);
        // Step - 5: Asserting response
        Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 206);
        Assert.assertNotNull(responseList, "Payload is null");
        Assert.assertEquals(res.getDependentCustomerAccountId(),
                dependent1CustomerAccountId);
        Assert.assertEquals(res1.getDependentCustomerAccountId(),
                dependent2CustomerAccountId);
    }

    @Test(
            priority = 4,
            description = "Delink Dependent Multiple dependents Success ")
    public void deLinkDependentMultipleDependentSuccess() throws Exception {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String caregiverCustomerAccountId2 = "a1f113ae-b556-4b03-821c-5c0d32504452";

        WCPAddDependentRequest wcpDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.MINOR,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent3CustomerAccountId,caregiverCustomerAccountId2);
        wcpRetroFit.addDependent(wcpDependentRequest,caregiverCustomerAccountId2);

        // dependent 4 - ADULT, PENDING
        String   dependent4CustomerAccountId = "9ebad71b-be34-47a8-b56b-5a16bcf645e8";

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.PENDING,
                dependent4CustomerAccountId,caregiverCustomerAccountId2);
        wcpRetroFit.addDependent(wcpAddDependentRequest,caregiverCustomerAccountId2);

        // Step - 2: Calling delinkDependent with a valid caregiverCustomerAccountId ,valid domainId
        DelinkDependentsRequestV1 delinkDependentsRequestV1 = new DelinkDependentsRequestV1();
        delinkDependentsRequestV1.setDependentCustomerAccountId(dependent3CustomerAccountId);
        DelinkDependentsRequestV1 delinkDependentsRequestV11 = new DelinkDependentsRequestV1();
        delinkDependentsRequestV11.setDependentCustomerAccountId(dependent4CustomerAccountId);
        List<DelinkDependentsRequestV1> lis = new ArrayList<>();
        lis.add(delinkDependentsRequestV1);
        lis.add(delinkDependentsRequestV11);

        Response<WCPGetDependentsResponse> getDependents = wcpRetroFit.getDependents(caregiverCustomerAccountId2);
        Assert.assertEquals(getDependents.body().getPayload().getDependents().size(),2);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
                getFamLinksV1ResponseForDependents =
                accountOrchestratorRetrofit.delinkDependent(
                        caregiverCustomerAccountId2, domainId, lis, reqId, reqTrackingId);

        // Step - 4: Parsing the response to the DelinkDependent Response class so that we can assert
        ArrayList<LinkedTreeMap<String, Object>> responseList = (ArrayList<LinkedTreeMap<String, Object>>) getFamLinksV1ResponseForDependents.body().getPayload();
        DelinkDependentRes res =
                ResponseUtil.parseResponse(
                        gson,
                        responseList.get(0),
                        DelinkDependentRes.class);
        DelinkDependentRes res1 =
                ResponseUtil.parseResponse(
                        gson,
                        responseList.get(1),
                        DelinkDependentRes.class);
        // Step - 5: Asserting response
        Response<UpdatePreferencesResponse> updatePreferenceResponse3 = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId2,
                caregiverCustomerAccountId2,
                dependent3CustomerAccountId,
                false);
        Response<UpdatePreferencesResponse> updatePreferenceResponse4 = postPreferenceOrchRetrofit.updatePreferences(
                reqTrackingId,
                caregiverCustomerAccountId2,
                caregiverCustomerAccountId2,
                dependent4CustomerAccountId,
                false);
        // Step - 5: Asserting response
        Assert.assertEquals(updatePreferenceResponse3.code(), 400);
        Assert.assertEquals(updatePreferenceResponse4.code(), 400);
        // TODO: Knwon defect - CA Optimistic locking excepting - setting assertion  to 206
        Assert.assertEquals(getFamLinksV1ResponseForDependents.code(), 206);
        Assert.assertNotNull(responseList, "Payload is null");
        Assert.assertEquals(responseList.size(),2);
    }


    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    public void createCPRAccount(
            String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        if (Objects.equals(type, PET)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
            // setting patientType code for PET profile
            cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
        } else if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * deletes cpr account by setting the PatientStatusCode as 20708
     *
     * @param storeNbr
     * @param patientId
     * @param firstName
     * @param lastName
     * @throws IOException
     */
    public void deleteCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob)
            throws IOException {
        ValidationServiceRequest cprRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprRequest.setPatientId(Integer.parseInt(patientId));
        cprRequest.getPatientInfo().setBirthDate(dob);
        cprRequest.getPatientInfo().setFirstName(firstName);
        cprRequest.getPatientInfo().setLastName(lastName);
        cprRequest.getPatientInfo().setPatientStatusCode(20708);

        // This will try to delete an account in CPR 3 times if account deletion fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account deletion failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
        // This is needed because CPR account deletion is async, and it usually takes a couple of
        // seconds to reflect account deletion
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    public void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }


    private String createWcpGuestAccount(
            String firstName, String lastName, String customerType, String dob) throws Exception {
        WCPCreateGuestAccountRequest wcpCreateGuestAccountRequest =
                getWcpCreateGuestAccountRequest(firstName, lastName, customerType, dob);
        Response<WCPCreateGuestAccountResponse> response = null;

        // Retry up to 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetroFit.createGuestAccount(wcpCreateGuestAccountRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && response.body().getStatus() != "OK") {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP Guest account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
        return response
                .body()
                .getPayload()
                .getCustomerAccountId();
    }

    private static WCPCreateGuestAccountRequest getWcpCreateGuestAccountRequest(
            String firstName, String lastName, String customerType, String dob) {
        return WCPCreateGuestAccountRequest.builder()
                .payload(
                        WCPCreateGuestAccountRequest.Payload.builder()
                                .account(
                                        WCPCreateGuestAccountRequest.Account.builder()
                                                .accountType("GUEST")
                                                .customerType(customerType)
                                                .firstName(firstName)
                                                .lastName(lastName)
                                                .dateOfBirth(dob)
                                                .build())
                                .build())
                .build();
    }

    private static void logFlowIdentifiers(
            String customerAccountId,
            String domainId,
            String filter,
            String reqId,
            String reqTrackingId) {
        Reporter.logJSON("customerAccountId", customerAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("filter", filter);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }
}