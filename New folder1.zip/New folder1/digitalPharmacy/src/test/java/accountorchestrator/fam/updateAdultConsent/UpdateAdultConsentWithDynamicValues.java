package accountorchestrator.fam.updateAdultConsent;

import accountorchestrator.utils.AccountOrchestratorCommonUtils;
import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.ApprovalStatus;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPGetDependentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.updateAdultConsentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequestByCustomerType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class UpdateAdultConsentWithDynamicValues {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private WCPRetroFit wcpRetrofit;
    private ObjectMapper mapper = new ObjectMapper();
    private Gson gson = new GsonBuilder().create();
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String filter = "DEPENDENT";
    private String accountCreationSource = "idVerification";
    private String accountType = "INDIVIDUAL";
    private String HUMAN = "HUMAN";
    private String customerType = "INDIVIDUAL";
    private String trackID = CommonUtil.randomUUID();
    private String caregiverCustomerEmailId = null;
    private String dependent1CustomerEmailId = null;
    private String dependent2CustomerEmailId = null;
    private String dependent3CustomerEmailId = null;
    private String dependent4CustomerEmailId = null;
    private String caregiverCustomerAccountId = null;
    private String dependent1CustomerAccountId = null;
    private String dependent2CustomerAccountId = null;
    private String dependent3CustomerAccountId = null;
    private String dependent4CustomerAccountId = null;
    private String caregiverStoreNbr = null;
    private String caregiverPatientId = null;
    private String dependent1StoreNbr = null;
    private String dependent1PatientId = null;
    private String dependent2StoreNbr = null;
    private String dependent2PatientId = null;
    private String dependent3StoreNbr = null;
    private String dependent3PatientId = null;
    private String dependent4StoreNbr = null;
    private String dependent4PatientId = null;
    private String caregiverFirstName = null;
    private String caregiverLastName = null;
    private String dependent1FirstName = null;
    private String dependent1LastName = null;
    private String dependent2FirstName = null;
    private String dependent2LastName = null;
    private String dependent3FirstName = null;
    private String dependent3LastName = null;
    private String dependent4FirstName = null;
    private String dependent4LastName = null;
    private String commonDobCPRFormatForOlderThan18 = null;
    private String commonDobDPFormatForOlderThan18 = null;
    ValidationServiceRequest cprPatientRequest = null;
    List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
    List<String> pharmacyProfilesToBeDeleted  = new ArrayList<>();

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        wcpRetrofit = new WCPRetroFit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

        caregiverCustomerEmailId = "Caregiver.FamUpdateAdultConsent@gmail.com";
        dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);
        dependent3CustomerEmailId = "fljkx.xysvut@gmail.com";
        dependent4CustomerEmailId = "jklims.tuxsjj@gmail.com";

        Date dateForOlderThan18 =
                new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

        commonDobCPRFormatForOlderThan18 =
                new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
        commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

        // caregiver
        caregiverStoreNbr = "659914";
        caregiverPatientId = "450992117";
        caregiverFirstName = "Caregiver";
        caregiverLastName = "FamUpdateAdultConsent";
        caregiverCustomerAccountId = "75643f3c-4e98-42fe-8d99-9f41e233edf3";
        /*createCPRAccount(
                caregiverStoreNbr,
                caregiverPatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                caregiverFirstName,
                caregiverLastName);*/
        createPharmacyAccount(
                caregiverCustomerAccountId,
                caregiverStoreNbr,
                caregiverPatientId,
                "10102000");

        // dependent1 -ADULT,PENDING
        dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent1PatientId = CommonUtil.generateRandomNumber(9);
        dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent1LastName = RandomStringUtils.randomAlphabetic(5);
        dependent1CustomerAccountId =CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(dependent1CustomerEmailId,commonPassword,commonPhoneNo,dependent1FirstName,dependent1LastName,trackID);
        createCPRAccount(
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                dependent1FirstName,
                dependent1LastName);
        createPharmacyAccount(
                dependent1CustomerAccountId,
                dependent1StoreNbr,
                dependent1PatientId,
                commonDobDPFormatForOlderThan18);
        wcpAddDependent(
                caregiverCustomerAccountId,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.PENDING,
                dependent1CustomerAccountId);

        // dependent2 -ADULT,PENDING
        dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
        dependent2PatientId = CommonUtil.generateRandomNumber(9);
        dependent2FirstName = RandomStringUtils.randomAlphabetic(5);
        dependent2LastName = RandomStringUtils.randomAlphabetic(5);
        dependent2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(dependent2CustomerEmailId,commonPassword,commonPhoneNo,dependent2FirstName,dependent2LastName,trackID);
        createCPRAccount(
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                dependent2FirstName,
                dependent2LastName);
        createPharmacyAccount(
                dependent2CustomerAccountId,
                dependent2StoreNbr,
                dependent2PatientId,
                commonDobDPFormatForOlderThan18);


        // dependent3 -ADULT,ACTIVE
        dependent3StoreNbr = "255632";
        dependent3PatientId = "521738751";
        dependent3FirstName = "Fljkx";
        dependent3LastName = "Xysvut";
        dependent3CustomerAccountId = "a6eab02b-e782-445d-a17c-c49698725641";
        /*createCPRAccount(
                dependent3StoreNbr,
                dependent3PatientId,
                commonDobCPRFormatForOlderThan18,
                HUMAN,
                dependent3FirstName,
                dependent3LastName);*/
        createPharmacyAccount(
                dependent3CustomerAccountId,
                dependent3StoreNbr,
                dependent3PatientId,
                "10102000");
        wcpAddDependent(
                caregiverCustomerAccountId,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE,
                dependent3CustomerAccountId);

        // dependent 4 - ADULT, APPROVED
        dependent4StoreNbr = "331367";
        dependent4PatientId = "724187554";
        dependent4FirstName = "jklims";
        dependent4LastName = "tuxsjj";
        dependent4CustomerAccountId = "2d813e37-0470-4a6b-bff4-122cd9f130b2";
        createPharmacyAccount(
                dependent4CustomerAccountId,
                dependent4StoreNbr,
                dependent4PatientId,
                "10102000");


        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(40000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        wcpAddDependent(
                caregiverCustomerAccountId,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.PENDING,
                dependent2CustomerAccountId);

        wcpAddDependent(
                caregiverCustomerAccountId,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                dependent4CustomerAccountId);
    }

    /**
     * Clean up for all created cpr accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws Exception {

        wcpRetrofit.deleteDependent(caregiverCustomerAccountId, dependent3CustomerAccountId);
        wcpRetrofit.deleteDependent(caregiverCustomerAccountId, dependent4CustomerAccountId);

        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<ValidationServiceResponse> response =
                                cprPatientUpdateRetrofit.validateProfile(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });
        pharmacyProfilesToBeDeleted.forEach(
                request -> {
                    try {
                        Response<ServiceResponse> getOnlineIdentityResp =
                                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                                        request, domainId, reqIdString, reqTrackingString);

                        if (getOnlineIdentityResp.code() == 204) {
                            // If the response is 204, skip the deletion
                            return;
                        }

                        accountEntityServiceRetrofit.deleteAccountV1(
                                request, domainId, reqIdString, reqTrackingString);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                });


    }

    /**
     * Build ca create person request
     *
     * @return
     */
    private CACreatePersonRequestByCustomerType getCACreatePersonRequest(
            String dependentCustomerEmailId) {
        List<CACreatePersonRequestByCustomerType.Accounts> accountsList = new ArrayList<>();
        accountsList.add(
                CACreatePersonRequestByCustomerType.Accounts.builder()
                        .accountType(accountType)
                        .emailAddress(dependentCustomerEmailId)
                        .build());
        return CACreatePersonRequestByCustomerType.builder()
                .payload(
                        CACreatePersonRequestByCustomerType.CreatePersonRequestPayload.builder()
                                .person(
                                        CACreatePersonRequestByCustomerType.Person.builder()
                                                .accounts(accountsList)
                                                .customerType(customerType)
                                                .build())
                                .build())
                .build();
    }

    /**
     * Build ca create person request for caregiver
     *
     * @return
     */
    private CACreatePersonRequest getCACreatePersonRequestForCaregiver(
            String caregiverCustomerEmailId) {
        List<CACreatePersonRequest.Accounts> accountsList = new ArrayList<>();
        accountsList.add(
                CACreatePersonRequest.Accounts.builder()
                        .accountType(accountType)
                        .emailAddress(caregiverCustomerEmailId)
                        .build());
        return CACreatePersonRequest.builder()
                .payload(
                        CACreatePersonRequest.CreatePersonRequestPayload.builder()
                                .person(CACreatePersonRequest.Person.builder().accounts(accountsList).build())
                                .build())
                .build();
    }

    /**
     * Build ca create person request for dependent
     *
     * @return
     */
    private CACreatePersonRequest getCACreatePersonRequestForDependent(
            String dependentCustomerEmailId) {
        List<CACreatePersonRequest.Accounts> accountsList = new ArrayList<>();
        accountsList.add(
                CACreatePersonRequest.Accounts.builder()
                        .accountType(accountType)
                        .emailAddress(dependentCustomerEmailId)
                        .build());
        return CACreatePersonRequest.builder()
                .payload(
                        CACreatePersonRequest.CreatePersonRequestPayload.builder()
                                .person(CACreatePersonRequest.Person.builder().accounts(accountsList).build())
                                .build())
                .build();
    }

    /**
     * Create CPR Account using storeNbr and patientId
     *
     * @throws IOException
     */
    public void createCPRAccount(
            String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
            throws IOException {
        cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
          if (Objects.equals(type, HUMAN)) {
            cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
            cprPatientRequest.setPatientId(Integer.parseInt(patientId));
            cprPatientRequest.getPatientInfo().setBirthDate(dob);
            cprPatientRequest.getPatientInfo().setFirstName(firstName);
            cprPatientRequest.getPatientInfo().setLastName(lastName);
        }

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                cprProfilesToBeDeletedList.add(cprPatientRequest);
            }
            break;
        }
        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * deletes cpr account by setting the PatientStatusCode as 20708
     *
     * @param storeNbr
     * @param patientId
     * @param firstName
     * @param lastName
     * @throws IOException
     */
    public void deleteCPRAccount(
            String storeNbr, String patientId, String firstName, String lastName, String dob)
            throws IOException {
        ValidationServiceRequest cprRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprRequest.setPatientId(Integer.parseInt(patientId));
        cprRequest.getPatientInfo().setBirthDate(dob);
        cprRequest.getPatientInfo().setFirstName(firstName);
        cprRequest.getPatientInfo().setLastName(lastName);
        cprRequest.getPatientInfo().setPatientStatusCode(20708);

        // This will try to delete an account in CPR 3 times if account deletion fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account deletion failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
        // This is needed because CPR account deletion is async, and it usually takes a couple of
        // seconds to reflect account deletion
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
     * storeNbr and patient id from cpr response
     *
     * @throws IOException
     */
    public void createPharmacyAccount(
            String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
            throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
        Response<ServiceResponse> response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                pharmacyProfilesToBeDeleted.add(customerAccountId);
                break;
            }

        }
    }

    /**
     * Builds accEn Create pharmacy request
     *
     * @return
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String commonStoreNbr, String commonPatientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource(accountCreationSource)
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(commonStoreNbr)
                                .patientId(commonPatientId)
                                .dob(dob)
                                .build())
                .build();
    }

    /**
     * Call WCP add dependent api
     *
     * @param type
     * @throws IOException
     */
    public void wcpAddDependent(
            String caregiverId,
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId)
            throws Exception {

        WCPAddDependentRequest wcpAddDependentRequest =  AccountOrchestratorCommonUtils.getWCPAddDependentRequest(type, status, dependentAccountId, caregiverId);
        Response<WCPAddDependentResponse> response = null;

        // This will try to create a person account in CA, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = wcpRetrofit.addDependent(wcpAddDependentRequest,caregiverId);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "WCP add dependent failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    /**
     *
     * @param customerAccountId
     * @return
     * @throws IOException
     */
    public  Response<WCPGetDependentsResponse> getDependents(
             String customerAccountId) throws Exception {
        Response<WCPGetDependentsResponse> response = null;
        for (int i = 0; i < 3; i++) {
            response = wcpRetrofit.getDependents(customerAccountId);
            if (response.code() == 200) break;
            else {
                if (i == 2)
                    throw new RuntimeException(
                            "WCP get dependents failed. HttpStatusCode : " + response.code());
            }
        }
        return response;
    }

    @Test(priority = 1, description = "Test case for adult patient valid the consent request"
    )
    public void adultPatientValidConsentTransitions() throws Exception {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);

        // Valid PENDING to APPROVED
        updateAdultConsentRequest updateAdultConsentRequest = new updateAdultConsentRequest();
        updateAdultConsentRequest.setCaregiverCustomerAccountId(caregiverCustomerAccountId);
        updateAdultConsentRequest.setApprovalStatus("APPROVED");
        accountOrchestratorRetrofit.updateAdultConsent(
                dependent1CustomerAccountId, domainId, updateAdultConsentRequest, reqId, reqTrackingId);



        // Valid PENDING to REJECTED
        updateAdultConsentRequest updateAdultConsentRequest2 = new updateAdultConsentRequest();
        updateAdultConsentRequest2.setCaregiverCustomerAccountId(caregiverCustomerAccountId);
        updateAdultConsentRequest2.setApprovalStatus("REJECTED");
         accountOrchestratorRetrofit.updateAdultConsent(
                dependent2CustomerAccountId, domainId, updateAdultConsentRequest2, reqId, reqTrackingId);


        // Valid ACTIVE  to DELINKED

        updateAdultConsentRequest updateAdultConsentRequest3 = new updateAdultConsentRequest();
        updateAdultConsentRequest3.setCaregiverCustomerAccountId(caregiverCustomerAccountId);
        updateAdultConsentRequest3.setApprovalStatus("DELINKED");
 accountOrchestratorRetrofit.updateAdultConsent(
                dependent3CustomerAccountId, domainId, updateAdultConsentRequest3, reqId, reqTrackingId);



        // Valid APPROVED to DELINKED
        updateAdultConsentRequest updateAdultConsentRequest4 = new updateAdultConsentRequest();
        updateAdultConsentRequest4.setCaregiverCustomerAccountId(caregiverCustomerAccountId);
        updateAdultConsentRequest4.setApprovalStatus("DELINKED");
        accountOrchestratorRetrofit.updateAdultConsent(
                dependent4CustomerAccountId, domainId, updateAdultConsentRequest4, reqId, reqTrackingId);


        Response<WCPGetDependentsResponse> wcpgetDependentsResponse = getDependents(caregiverCustomerAccountId);

        WCPGetDependentsResponse.DependentInfo dependent1AfterStatusUpdate = wcpgetDependentsResponse.body().getPayload().getDependents().stream()
                .filter(dependent -> dependent.getDependent().getMemberId().getId().toString().equals(dependent1CustomerAccountId))
                .findFirst().orElse(null);


        Assert.assertEquals(dependent1AfterStatusUpdate.getDependent().getMembershipStatus(),
                ApprovalStatus.APPROVED.name());


        WCPGetDependentsResponse.DependentInfo dependent2AfterStatusUpdate = wcpgetDependentsResponse.body().getPayload().getDependents().stream()
                .filter(dependent -> dependent.getDependent().getMemberId().getId().toString().equals(dependent2CustomerAccountId))
                .findFirst().orElse(null);


        Assert.assertEquals(dependent2AfterStatusUpdate.getDependent().getMembershipStatus(),
                ApprovalStatus.REJECTED.name());



        WCPGetDependentsResponse.DependentInfo dependent3AfterStatusUpdate = wcpgetDependentsResponse.body().getPayload().getDependents().stream()
                .filter(dependent -> dependent.getDependent().getMemberId().getId().toString().equals(dependent3CustomerAccountId))
                .findFirst().orElse(null);


        Assert.assertEquals(dependent3AfterStatusUpdate.getDependent().getMembershipStatus(),
                ApprovalStatus.DELINKED.name());


        WCPGetDependentsResponse.DependentInfo dependent4AfterStatusUpdate = wcpgetDependentsResponse.body().getPayload().getDependents().stream()
                .filter(dependent -> dependent.getDependent().getMemberId().getId().toString().equals(dependent4CustomerAccountId))
                .findFirst().orElse(null);


        Assert.assertEquals(dependent4AfterStatusUpdate.getDependent().getMembershipStatus(),
                ApprovalStatus.DELINKED.name());

    }

    @Test(priority = 2, description = "Test case for adult patient invalid transition and not a valid dependent request"
    )
    public void adultPatientConsentExecptions() throws IOException {
        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(caregiverCustomerAccountId, domainId, filter, reqId, reqTrackingId);

        // Invalid transition
        updateAdultConsentRequest updateAdultConsentRequest = new updateAdultConsentRequest();
        updateAdultConsentRequest.setCaregiverCustomerAccountId(caregiverCustomerAccountId);
        updateAdultConsentRequest.setApprovalStatus("APPROVED");
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> response = accountOrchestratorRetrofit.updateAdultConsentError(
                dependent1CustomerAccountId, domainId, updateAdultConsentRequest, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, response);

        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(response.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1027");



        // Invalid Caregiver
        updateAdultConsentRequest updateAdultConsentRequest1 = new updateAdultConsentRequest();
        updateAdultConsentRequest1.setCaregiverCustomerAccountId(UUID.randomUUID().toString());
        updateAdultConsentRequest1.setApprovalStatus("DELINKED");
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> response1 = accountOrchestratorRetrofit.updateAdultConsentError(
                dependent1CustomerAccountId, domainId, updateAdultConsentRequest1, reqId, reqTrackingId);

        Error errorResponse1 = CommonUtil.getErrorResponse(gson, response1);

        String errorMessage1 = CommonUtil.buildErrorMessage(errorResponse1);

        Assert.assertEquals(response1.code(), 400, errorMessage1);
        Assert.assertEquals(errorResponse1.getCode(), "DPR-DPACCOR-1027");
    }


        private static void logFlowIdentifiers(
            String customerAccountId,
            String domainId,
            String filter,
            String reqId,
            String reqTrackingId) {
        Reporter.logJSON("customerAccountId", customerAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("filter", filter);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

}
