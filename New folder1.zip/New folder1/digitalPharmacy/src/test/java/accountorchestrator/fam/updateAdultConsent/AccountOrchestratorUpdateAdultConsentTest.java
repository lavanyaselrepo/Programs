package accountorchestrator.fam.updateAdultConsent;

import accountorchestrator.utils.AccountOrchestratorCommonUtils;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.getCareGiverResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.getDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.updateAdultConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.wrapper.UpdateAdultConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Balaji Rajaram
 */
public class AccountOrchestratorUpdateAdultConsentTest {

    UpdateAdultConsentWrapper adultConsentWrapper = new UpdateAdultConsentWrapper();
    CommonUtils utility  = new CommonUtils();

    WCPRetroFit wcpRetrofit = new WCPRetroFit();

    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();

    ConsentOrchestratorWrapper consentOrchestratorWrapper=new ConsentOrchestratorWrapper();
    HashMap<String, String> consentData = new HashMap<>();

    @Test(priority = 1, description = "Test case for adult patient approving the consent request",dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData-qe.xlsx", sheetName = "updateAccountConsent")
    public void adultPatientApprovingConsent(Map<String, String> inputData) throws Exception {

        // Getting test data for validation
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5);
        String adultDependentLastName = CommonUtil.generateRandomLastName(5);
        String caregiverDOB =utility.nullStringValidation(inputData.get("caregiverdob"));
        String storeNo = utility.nullStringValidation(inputData.get("storeno"));
        String adultDependentDOB = utility.nullStringValidation(inputData.get("adultdependentdob"));
        consentData.put("ApprovalStatus", "APPROVED");

        // creating primary patient and adding pharmacy account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
        consentData.put("CaregiverAccId", caregiver_cid);

        // creating dependent patient
        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);
        consentData.put("dependentId",adultDependent_cid);

        // Primary customer adding dependent
        WCPAddDependentRequest wcpAddDependentRequest =  AccountOrchestratorCommonUtils.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.PENDING,adultDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest, caregiver_cid);

        // Calling updateAdultConsent api and getting response
        ServiceResponse adultConsentResponse = adultConsentWrapper.performPostforUpdateAccountConsentApi(consentData);
        int serviceResponseValue = adultConsentResponse.getStatusCode();
        Assert.assertEquals(serviceResponseValue,Integer.parseInt(inputData.get("Status")));
        Reporter.log("Status code ==== " + serviceResponseValue);

        // Verify the approved status updated in the system
        ServiceResponse caregiverResponse = adultConsentWrapper.performget_CaregiverApi(consentData);
        int caregiverreponseValue = caregiverResponse.getStatusCode();
        Assert.assertEquals(caregiverreponseValue,200);
        getCareGiverResponse caregiverPayload = caregiverResponse.getDataResponse(getCareGiverResponse.class);
        String linkedStatus = caregiverPayload.getPayload().getCaregiversInfo().get(0).getLinkageStatus();
        String caregiverId = caregiverPayload.getPayload().getCaregiversInfo().get(0).getCustomerAccountId();
        Assert.assertEquals(linkedStatus,"APPROVED");
        Assert.assertEquals(caregiverId,consentData.get("CaregiverAccId"));

    }

    @Test(priority = 2, description = "Test case for adult patient rejecting the consent request",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData-qe.xlsx", sheetName = "updateAccountConsent")
    public void adultPatientRejectingConsent(Map<String, String> inputData) throws Exception {

        // Getting test data for validation
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5);
        String adultDependentLastName = CommonUtil.generateRandomLastName(5);
        String caregiverDOB =utility.nullStringValidation(inputData.get("caregiverdob"));
        String storeNo = utility.nullStringValidation(inputData.get("storeno"));
        String adultDependentDOB = utility.nullStringValidation(inputData.get("adultdependentdob"));
        consentData.put("ApprovalStatus", utility.nullStringValidation(inputData.get("approvalStatus")));

        // creating primary patient and adding pharmacy account
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
        consentData.put("CaregiverAccId", caregiver_cid);

        // creating dependent patient
        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);
        consentData.put("dependentId",adultDependent_cid);

        // Primary customer adding dependent
        WCPAddDependentRequest wcpAddDependentRequest =  AccountOrchestratorCommonUtils.getWCPAddDependentRequest( DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.PENDING, adultDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest, caregiver_cid);

        // Calling updateAdultConsent api and getting response
        ServiceResponse adultConsentResponse = adultConsentWrapper.performPostforUpdateAccountConsentApi(consentData);
        int serviceResponseValue = adultConsentResponse.getStatusCode();
        Assert.assertEquals(serviceResponseValue,Integer.parseInt(inputData.get("Status")));
        Reporter.log("Status code ====" + serviceResponseValue);

        // Verify the rejected status updated in the system
        ServiceResponse dependentsResponse = adultConsentWrapper.performget_DependentApi(consentData);
        int caregiverreponseValue = dependentsResponse.getStatusCode();
        Assert.assertEquals(caregiverreponseValue,Integer.parseInt(inputData.get("Status")));

        getDependentResponse dependentPayload = dependentsResponse.getDataResponse(getDependentResponse.class);
        String linkedStatus = dependentPayload.getPayload().getDependentsInfo().get(0).getLinkageStatus();
        String caregiverId = dependentPayload.getPayload().getDependentsInfo().get(0).getCustomerAccountId();
        Assert.assertEquals(linkedStatus,"REJECTED");
        Assert.assertEquals(adultDependent_cid,consentData.get("dependentId"));

    }

    @Test(priority = 3, description = "Test case for validating the failure condition",
            dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/accountOrchestratorCustomerData-qe.xlsx", sheetName = "updateAccountConsent")
    public void failureCasesValidation(Map<String, String> inputData) {

        // Getting test data for validation
        consentData.put("CaregiverAccId", utility.nullStringValidation(inputData.get("caregiverCustomerAccountId")));
        consentData.put("ApprovalStatus", utility.nullStringValidation(inputData.get("approvalStatus")));
        consentData.put("dependentId",utility.nullStringValidation(inputData.get("dependentaccountId")));

        // Calling updateAdultConsent api and getting response
        ServiceResponse adultConsentResponse = adultConsentWrapper.performPostforUpdateAccountConsentApi(consentData);
        updateAdultConsentResponse adultConsentDataResponse = adultConsentResponse.getDataResponse(updateAdultConsentResponse.class);
        int serviceResponseValue = adultConsentResponse.getStatusCode();
            Assert.assertEquals(serviceResponseValue,Integer.parseInt(inputData.get("Status")));
        Reporter.log("Status code ====" + serviceResponseValue);
        Reporter.log("Error Code === " +  adultConsentDataResponse.getError().getCode());
        Reporter.log("Error Description === " +  adultConsentDataResponse.getError().getMessage());
        Reporter.log("Action needed for the error === " +  adultConsentDataResponse.getError().getAction());

    }





}
