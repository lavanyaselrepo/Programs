package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper.createPharmacyAccount;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper.getCreatePharmacyAccountByPatientIdV1Request;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper.deleteCprAccount;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.createSMSEnrollmentOrUnenroll;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.getDmPostPreferencesRequest;

public
class AccountOrchestratorAddDependentAddPetTypeValidationBetweenCPRAndInputValidationTestCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private String emailAddress;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, cprPetPatientId;
  private String caregiverCustomerAccountId;
  private String caAdultDob = "2024-01-02";
  private String dpAdultDob = "01022024";
  private String type = "PET";
  Map<String, List<SMSEnrolledProfileListByCidResponse>> patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null, petCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    emailAddress = CommonUtil.generateRandomEmailId(10);

    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

    Reporter.logJSON("caregiverId", caregiverCustomerAccountId);
    Reporter.logJSON("Store nbr", storeNbr);
    Reporter.logJSON("Phone nbr", phoneNumber);

    createAllCprAccounts();
    createSMSEnrollments();
    CreateAccountByPatientIdV1Request createPharmacyAccountByPatientIdV1Request =
        getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob);
    createPharmacyAccount(
        accountOrchestratorRetrofit,
        domainId,
        createPharmacyAccountByPatientIdV1Request,
        caregiverCustomerAccountId);
    List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
  }

  @Test(
      priority = 1,
      description = "Add Pet Account Type validation between input and CPR - Failure")
  public void addPetAccount_TypeValidationBetweenInputAndCPR() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    SMSEnrolledProfileListByCidResponse petPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(cprPetPatientId)).get(0);
    DependentInfo2 petDependentInfo = createDependentInfo2(petPatientProfile);
    petDependentInfo.setConsent(null);
    petDependentInfo.setType("MINOR");
    petDependentInfo.setDob("01022024");
    petDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(org.openjdk.tools.javac.util.List.of(petDependentInfo));

    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> addDependentResponse =
        accountOrchestratorRetrofit.famAddDependent(
            caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, addDependentResponse);

    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1001"));
    Assert.assertNotNull(errorMessage);
    Assert.assertTrue(errorMessage.contains("Invalid input request"));
    Assert.assertTrue(
        errorMessage.contains(
            "Invalid input request. Incorrect dependent type given in request, does not match with our record"));
  }

  private void validateFamLinksResponse(String reqId, String reqTrackingId, String dependentCid)
      throws IOException {
    String linkageStatus = "ALL";
    Response<ServiceResponse> getFamLinksV1Response =
        accountOrchestratorRetrofit.getFamLinksV1(
            caregiverCustomerAccountId,
            domainId,
            "DEPENDENT",
            reqId,
            reqTrackingId,
                linkageStatus);

    String getFamLinksErrorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1Response);
    Assert.assertEquals(getFamLinksV1Response.code(), 200, getFamLinksErrorMessage);
    Assert.assertNotNull(getFamLinksV1Response.body().getPayload(), "Payload is null");
    GetFamLinksResponse getFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getFamLinksV1Response.body().getPayload()),
            GetFamLinksResponse.class);
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(), 1);

    DependentInfo dependentInfo = getFamLinksResponse.getDependentsInfo().get(0);

    Assert.assertEquals(dependentInfo.getLinkageStatus(), DependentInfo.LinkageStatusEnum.ACTIVE);
    Assert.assertEquals(dependentInfo.getType().getValue(), type);
    Assert.assertEquals(dependentInfo.getCustomerAccountId(), dependentCid);
  }

  private AddDependentsV1Response extractDependentsFromResponsePayload(Object payload) {
    return ResponseUtil.parseResponse(
        gson, ((LinkedTreeMap<String, Object>) payload), AddDependentsV1Response.class);
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = getTemplateCprRequest();
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    petCprPatientRequest = getTemplateCprRequest();
    petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    petCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);
    org.openjdk.tools.javac.util.List.of(adultHumanCprPatientRequest, petCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprPetPatientId = SharedUtils.createCprAccount(petCprPatientRequest, cprPatientUpdateRetrofit);

    Reporter.logJSON("cprPetPatientId", cprPetPatientId);
    Reporter.logJSON("cprAdultHumanPatientId", cprAdultHumanPatientId);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    org.openjdk.tools.javac.util.List.of(cprAdultHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                DMPostPreferencesRequest dmPostPreferencesRequest =
                    getDmPostPreferencesRequest(
                        storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805");
                createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit, dmPostPreferencesRequest);
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  private ValidationServiceRequest getTemplateCprRequest() throws IOException {
    return mapper.readValue(
        new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
        ValidationServiceRequest.class);
  }

  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    petCprPatientRequest.setPatientId(cprPetPatientId);

    org.openjdk.tools.javac.util.List.of(adultHumanCprPatientRequest, petCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(cprPatientUpdateRetrofit, request);
              } catch (IOException e) {
              }
            });
    org.openjdk.tools.javac.util.List.of(cprAdultHumanPatientId, cprPetPatientId)
        .forEach(
            patientId -> {
              try {
                DMPostPreferencesRequest dmPostPreferencesRequest =
                    getDmPostPreferencesRequest(
                        storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805");
                createSMSEnrollmentOrUnenroll(dmPostPreferencesRetrofit, dmPostPreferencesRequest);
              } catch (IOException e) {
              }
            });
  }

  public DependentInfo2 createDependentInfo2(
      SMSEnrolledProfileListByCidResponse enrolledProfileResponse) {
    CustomerInfo2 enrolledProfile = enrolledProfileResponse.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(enrolledProfileResponse.getValidationToken());
    return fadDependentInfo;
  }
}
