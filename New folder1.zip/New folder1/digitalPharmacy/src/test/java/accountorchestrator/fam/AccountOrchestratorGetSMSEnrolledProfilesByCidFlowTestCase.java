package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.CreateAccountByPatientIdV1Request;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.SMSEnrolledProfileListByCidResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.models.request.PharmaAuthPatientIdStoreNbrRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.jetbrains.annotations.NotNull;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Set;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.createSMSEnrollmentOrUnenroll;
import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.DMServiceHelper.getDmPostPreferencesRequest;

public class AccountOrchestratorGetSMSEnrolledProfilesByCidFlowTestCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId,
          cprAdultHumanPatientId1,
          cprMinorHumanPatientId,
          cprPetPatientId;
  private String customerAccountId = null;
  ValidationServiceRequest adultHumanCprPatientRequest = null,
          minorHumanCprPatientRequest,
          minorHumanCprPatientRequest2,
          petCprPatientRequest,
          adultHumanCprPatientRequest1;
  private PharmaAuthPatientIdStoreNbrRequest pharmaAuthPatientIdStoreNbrRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();
    pharmacyAuthServiceRetrofit =  new PharmacyAuthServiceRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    customerAccountId = CommonAccountHelper.
            createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(
                    CommonUtil.generateRandomEmailId(15));

    createAllCprAccounts();
    createSMSEnrollments();

    CreateAccountByPatientIdV1Request createPharmacyAccountRequest =
            SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
                    storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, "12121977");
    SharedUtils.createPharmacyAccount(
            createPharmacyAccountRequest, customerAccountId, domainId, accountOrchestratorRetrofit);
  }


  @Test(
          priority = 0,
          description = "Fetch SMS Enrolled Profiles List with no type filter - Failure")
  public void fetchSMSEnrolledProfileListWithNoTypeFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, smsEnrolledProfileListsResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
            errorResponse.getMessage(), "Invalid input request. Type is null/empty in request");
  }

  @Test(priority = 1, description = "Fetch SMS Enrolled Profiles List with type=MINOR - Success")
  public void fetchSMSEnrolledProfileListWithMinorOnlyFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(1, profilesList.size());

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet returned in response, even though not expected");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test(priority = 3, description = "Fetch SMS Enrolled Profiles List with type=PET - Success")
  public void fetchSMSEnrolledProfileListWithPetOnlyFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "PET";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(1, profilesList.size());

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)), "Pet not returned in response");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor returned in response, even though  not expected");
  }

  @Test(
          priority = 4,
          description = "Fetch SMS Enrolled Profiles List with type=PET,MINOR - Success")
  public void fetchSMSEnrolledProfileListWithPetAndMinorFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "PET,MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(2, profilesList.size());

    //        Assert responses - 2 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId)),
            "Adult returned in response, even though not expected");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)), "Pet not returned in response");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test(priority = 5, description = "Fetch SMS Enrolled Profiles List with type=ADULT - Success")
  public void fetchSMSEnrolledProfileListWithAdultOnlyFilterAndInCoolDown() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(profilesList.size(), 2);

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId1)),
            "Adult not returned in response");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet returned in response, even though not expected");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor returned in response, even though not expected");
    SMSEnrolledProfileListByCidResponse smsEnrolledProfileListByCidResponse = profilesList.stream().filter(p -> p.getCustomerInfo().getPatientId().equals(String.valueOf(cprAdultHumanPatientId))).findFirst().orElse(null);
    Assert.assertTrue(smsEnrolledProfileListByCidResponse.getCustomerInfo().isIsInCooldown());
    Assert.assertEquals(smsEnrolledProfileListByCidResponse.getCustomerInfo().getCoolDownStatus().getFailedAttemptsCount(), 5);
  }

  @Test(
          priority = 6,
          description = "Fetch SMS Enrolled Profiles List with type=ADULT,MINOR - Success")
  public void fetchSMSEnrolledProfileListWithAdultAndMinorFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT,MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(profilesList.size(), 3);

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId1)),
            "Adult not returned in response");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)),
            "Pet returned in response, even though not expected");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test(
          priority = 7,
          description = "Fetch SMS Enrolled Profiles List with type=ADULT,PET - Success")
  public void fetchSMSEnrolledProfileListWithAdultAndPetFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT,PET";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(profilesList.size(), 3);

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId1)),
            "Adult not returned in response");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)), "Pet not returned in response");
    Assert.assertFalse(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor returned in response, even though not expected");
  }

  @Test(
          priority = 8,
          description = "Fetch SMS Enrolled Profiles List with type=ADULT,PET,MINOR - Success")
  public void fetchSMSEnrolledProfileListWithAdultAndPetAndMinorFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "ADULT,PET,MINOR";
    CommonUtil.logFlowIdentifiers(
            customerAccountId, domainId, phoneNumber, type, reqId, reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);
    String errorMessage = CommonUtil.buildErrorMessage(gson, smsEnrolledProfileListsResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 200, errorMessage);
    Assert.assertNotNull(smsEnrolledProfileListsResponse.body().getPayload(), "Payload is null");

    ArrayList<Object> payload =
            ((ArrayList<Object>) smsEnrolledProfileListsResponse.body().getPayload());
    java.util.List<SMSEnrolledProfileListByCidResponse> profilesList =
            extractProfilesFromResponsePayload(payload);
    Assert.assertEquals(profilesList.size(), 4);

    //        Assert responses - 1 Profile returned in response
    Set<String> patientIdsSet =
            profilesList.stream()
                    .map(profile -> profile.getCustomerInfo().getPatientId())
                    .collect(Collectors.toSet());
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprAdultHumanPatientId1)),
            "Adult not returned in response");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprPetPatientId)), "Pet not returned in response");
    Assert.assertTrue(
            patientIdsSet.contains(String.valueOf(cprMinorHumanPatientId)),
            "Minor not returned in response");
  }

  @Test(
          priority = 9,
          description = "Fetch SMS Enrolled Profiles List with type=LIVESTOCK - Failure")
  public void fetchSMSEnrolledProfileListWithLIVESTOCKFilter() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "LIVESTOCK";
    CommonUtil.logFlowIdentifiers(
            customerAccountId,
            domainId,
            phoneNumber,
            String.format("Disallowed type: %s", type),
            reqId,
            reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, domainId, reqId, reqTrackingId, type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, smsEnrolledProfileListsResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
            errorResponse.getMessage(),
            "Invalid input request. Input contains following disallowed types: [LIVESTOCK]");
  }

  @Test(
          priority = 10,
          description = "Fetch SMS Enrolled Profiles List with invalid domainId - Failure")
  public void fetchSMSEnrolledProfileListWithInvalidDomainId() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "";
    String invalidDomainId = "paloma";
    CommonUtil.logFlowIdentifiers(
            customerAccountId,
            String.format("invalidDomainId: %s", invalidDomainId),
            phoneNumber,
            type,
            reqId,
            reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    customerAccountId, invalidDomainId, reqId, reqTrackingId, type);

    Error errorResponse = CommonUtil.getErrorResponse(gson, smsEnrolledProfileListsResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    Assert.assertEquals(smsEnrolledProfileListsResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
            errorResponse.getMessage(), "Invalid input request. domainId paloma in input is invalid");
  }

  @Test(
          priority = 11,
          description = "Fetch SMS Enrolled Profiles List with invalid customerAccountId - No Content")
  public void fetchSMSEnrolledProfileListWithInvalidCid() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String type = "MINOR";
    String invalidCustomerAccountId = "xyz";
    CommonUtil.logFlowIdentifiers(
            String.format("Invalid customerAccountId: %s", invalidCustomerAccountId),
            domainId,
            phoneNumber,
            type,
            reqId,
            reqTrackingId);

    Response<ServiceResponse> smsEnrolledProfileListsResponse =
            accountOrchestratorRetrofit.getSMSEnrolledProfileListByCid(
                    invalidCustomerAccountId, domainId, reqId, reqTrackingId, type);

    Assert.assertEquals(
            smsEnrolledProfileListsResponse.code(),
            204,
            String.format("204 expected, but found: %s", smsEnrolledProfileListsResponse.code()));
  }

  @NotNull
  private java.util.List<SMSEnrolledProfileListByCidResponse> extractProfilesFromResponsePayload(
          ArrayList<Object> payload) {
    return payload.stream()
            .map(
                    profile ->
                            ResponseUtil.parseResponse(
                                    gson,
                                    ((LinkedTreeMap<String, Object>) profile),
                                    SMSEnrolledProfileListByCidResponse.class))
            .collect(Collectors.toList());
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate("1977-12-12");

    adultHumanCprPatientRequest1 = SharedUtils.getTemplateCprRequest(mapper);
    adultHumanCprPatientRequest1.getPatientInfo().setBirthDate("1978-12-12");

    minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorHumanCprPatientRequest
            .getPatientInfo()
            .setBirthDate((LocalDate.now().getYear() - 1) + "-01-01");

    petCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    petCprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    List.of(
                    adultHumanCprPatientRequest,
                    adultHumanCprPatientRequest1,
                    minorHumanCprPatientRequest,
                    petCprPatientRequest)
            .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprMinorHumanPatientId =
            SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId =
            SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    cprPetPatientId = SharedUtils.createCprAccount(petCprPatientRequest, cprPatientUpdateRetrofit);
    cprAdultHumanPatientId1 =
            SharedUtils.createCprAccount(adultHumanCprPatientRequest1, cprPatientUpdateRetrofit);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    // creating coolDown Status for the patientId and storeNbr by hitting the api for 5 times
    for(int i=0;i<5;i++) {
      pharmaAuthPatientIdStoreNbrRequest = SharedUtils.incrementCoolDownForStorePatient(storeNbr, String.valueOf(cprAdultHumanPatientId), "FAM", pharmacyAuthServiceRetrofit);
    }
  }

  private void createSMSEnrollments() {
    List.of(
                    cprAdultHumanPatientId,
                    cprAdultHumanPatientId1,
                    cprMinorHumanPatientId,
                    cprPetPatientId)
            .forEach(
                    patientId -> {
                      try {
                        createSMSEnrollmentOrUnenroll(
                                dmPostPreferencesRetrofit,
                                getDmPostPreferencesRequest(
                                        storeNbr, String.valueOf(patientId), "1", phoneNumber, "26805"));
                      } catch (IOException e) {
                        throw new RuntimeException(
                                String.format(
                                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                                        storeNbr, patientId, e.getMessage()));
                      }
                    });
  }

  @AfterClass
  void cleanUp() throws IOException {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);
    adultHumanCprPatientRequest1.setPatientId(cprAdultHumanPatientId1);
    petCprPatientRequest.setPatientId(cprPetPatientId);

    List.of(
                    adultHumanCprPatientRequest,
                    adultHumanCprPatientRequest1,
                    minorHumanCprPatientRequest,
                    petCprPatientRequest)
            .forEach(
                    request -> {
                      request.getPatientInfo().setPatientStatusCode(20708);
                      try {
                        deleteCprAccount(request);
                      } catch (IOException e) {
                      }
                    });
    List.of(
                    cprAdultHumanPatientId,
                    adultHumanCprPatientRequest1,
                    cprMinorHumanPatientId,
                    cprPetPatientId)
            .forEach(
                    patientId -> {
                      try {
                        cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
                      } catch (IOException e) {
                      }
                    });

    pharmacyAuthServiceRetrofit.resetFailedAuthenticationForPatientLinks(pharmaAuthPatientIdStoreNbrRequest);
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
            cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
            && response.body() != null
            && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON(
              "errorMessage",
              String.format(
                      "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                      cprRequest.getPatientId(), response.code()));
    }
  }

  public void cleanUpSMSEnrollment(String storeNbr, String patientId) throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
            DMPostPreferencesRequest.builder()
                    .storeNbr(storeNbr)
                    .patientId(patientId)
                    .zipCode("96898")
                    .userId("SIGPAD")
                    .storePhone("8009666546")
                    .timeStamp(timestamp)
                    .language("101")
                    .preferences(
                            List.of(
                                    DMPostPreferencesRequest.Preference.builder()
                                            .notification_type("1")
                                            .notification_val(null)
                                            .short_code_type_id("1")
                                            .enrollment_status_code("26805")
                                            .build()))
                    .build();

    Response<DMPostPreferencesResponse> response =
            dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
            && response.body() != null
            && response.body().getResponseStatus() != null
            && "100".equals(response.body().getResponseStatus().getStatus_code()))) {}
  }
}
