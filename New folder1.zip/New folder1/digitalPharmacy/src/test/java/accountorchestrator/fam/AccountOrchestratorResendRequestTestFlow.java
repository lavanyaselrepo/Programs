package accountorchestrator.fam;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.FamResendRequestV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.FamResendRequestV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class AccountOrchestratorResendRequestTestFlow {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private WCPRetroFit wcpRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String HUMAN = "HUMAN";
  private String PET = "PET";
  private String accountType = "INDIVIDUAL";
  private String customerType = "INDIVIDUAL";
  private String accountCreationSource = "idVerification";
  private String dependent1CustomerEmailId = null;
  private String dependent2CustomerEmailId = null;
  private String dependent3CustomerEmailId = null;
  private String dependent4CustomerEmailId = null;
  private String customerEmailId = null;
  private String customerAccountId = null;
  private String dependent1CustomerAccountId = null;
  private String dependent2CustomerAccountId = null;
  private String dependent3CustomerAccountId = null;
  private String dependent4CustomerAccountId = null;
  private String customerStoreNbr = null;
  private String customerPatientId = null;
  private String dependent1StoreNbr = null;
  private String dependent1PatientId = null;
  private String dependent2StoreNbr = null;
  private String dependent2PatientId = null;
  private String dependent3StoreNbr = null;
  private String dependent3PatientId = null;
  private String dependent4StoreNbr = null;
  private String dependent4PatientId = null;
  private String customerFirstName = null;
  private String customerLastName = null;
  private String dependent1FirstName = null;
  private String dependent1LastName = null;
  private String dependent2FirstName = null;
  private String dependent2LastName = null;
  private String dependent3FirstName = null;
  private String dependent3LastName = null;
  private String dependent4FirstName = null;
  private String dependent4LastName = null;
  private String commonDobCPRFormatForOlderThan18 = null;
  private String commonDobDPFormatForOlderThan18 = null;

  ValidationServiceRequest cprPatientRequest = null;
  List<ValidationServiceRequest> cprProfilesToBeDeletedList = new ArrayList<>();
  List<String> pharmacyProfilesToBeDeleted = new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    wcpRetrofit = new WCPRetroFit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

    customerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent1CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent2CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent3CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    dependent4CustomerEmailId = CommonUtil.generateRandomEmailId(10);

    Date dateForOlderThan18 =
        new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

    commonDobCPRFormatForOlderThan18 =
        new SimpleDateFormat("yyyy-MM-dd").format(dateForOlderThan18);
    commonDobDPFormatForOlderThan18 = new SimpleDateFormat("MMddyyyy").format(dateForOlderThan18);

    // caregiver
    customerStoreNbr = CommonUtil.generateRandomNumber(6);
    customerPatientId = CommonUtil.generateRandomNumber(9);
    customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(customerEmailId);
    customerFirstName = RandomStringUtils.randomAlphabetic(5);
    customerLastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
        customerStoreNbr,
        customerPatientId,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        customerFirstName,
        customerLastName);
    createPharmacyAccount(
        customerAccountId, customerStoreNbr, customerPatientId, commonDobDPFormatForOlderThan18);

    // dependent1 -ADULT,REJECTED
    dependent1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent1CustomerEmailId);
    dependent1StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent1PatientId = CommonUtil.generateRandomNumber(9);
    dependent1FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent1LastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
        dependent1StoreNbr,
        dependent1PatientId,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        dependent1FirstName,
        dependent1LastName);
    createPharmacyAccount(
        dependent1CustomerAccountId,
        dependent1StoreNbr,
        dependent1PatientId,
        commonDobDPFormatForOlderThan18);
    WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
            DependentInfo.LinkageStatusEnum.REJECTED,
            dependent1CustomerAccountId,customerAccountId);
      wcpRetrofit.addDependent(wcpAddDependentRequest,customerAccountId);

    // dependent2 -ADULT,DELINKED
    dependent2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent2CustomerEmailId);
    dependent2StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent2PatientId = CommonUtil.generateRandomNumber(9);
    dependent2FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent2LastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
        dependent2StoreNbr,
        dependent2PatientId,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        dependent2FirstName,
        dependent2LastName);
    createPharmacyAccount(
        dependent2CustomerAccountId,
        dependent2StoreNbr,
        dependent2PatientId,
        commonDobDPFormatForOlderThan18);

      WCPAddDependentRequest wcpDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
              DependentInfo.LinkageStatusEnum.DELINKED,
              dependent2CustomerAccountId,customerAccountId);
      wcpRetrofit.addDependent(wcpDependentRequest,customerAccountId);

    // dependent3 -ADULT,ACTIVE
    dependent3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent3CustomerEmailId);
    dependent3StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent3PatientId = CommonUtil.generateRandomNumber(9);
    dependent3FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent3LastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
        dependent3StoreNbr,
        dependent3PatientId,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        dependent3FirstName,
        dependent3LastName);
    createPharmacyAccount(
        dependent3CustomerAccountId,
        dependent3StoreNbr,
        dependent3PatientId,
        commonDobDPFormatForOlderThan18);
      WCPAddDependentRequest wcpAddDependentReq = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT,
              DependentInfo.LinkageStatusEnum.ACTIVE,
              dependent3CustomerAccountId,customerAccountId);
      wcpRetrofit.addDependent(wcpAddDependentReq,customerAccountId);

    // dependent4 -ADULT (This dependent is not added to the caregiver)
    dependent4CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependent4CustomerEmailId);
    dependent4StoreNbr = CommonUtil.generateRandomNumber(6);
    dependent4PatientId = CommonUtil.generateRandomNumber(9);
    dependent4FirstName = RandomStringUtils.randomAlphabetic(5);
    dependent4LastName = RandomStringUtils.randomAlphabetic(5);
    createCPRAccount(
        dependent4StoreNbr,
        dependent4PatientId,
        commonDobCPRFormatForOlderThan18,
        HUMAN,
        dependent4FirstName,
        dependent4LastName);
    createPharmacyAccount(
        dependent4CustomerAccountId,
        dependent4StoreNbr,
        dependent4PatientId,
        commonDobDPFormatForOlderThan18);

    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(40000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Clean up for all created cpr accounts
   *
   * @throws IOException
   */
  @AfterClass
  void cleanUp() throws IOException {
    cprProfilesToBeDeletedList.forEach(
        request -> {
          request.getPatientInfo().setPatientStatusCode(20708);
          try {
            Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(request);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())
                && response.code() != 406) {
              throw new RuntimeException(
                  "CPR Account failed to update with status code 20708 for PatientId :"
                      + request.getPatientId()
                      + " StoreNbr :"
                      + request.getStoreNbr()
                      + " . HttpStatusCode : "
                      + response.code());
            }
          } catch (IOException e) {
          }
        });
    pharmacyProfilesToBeDeleted.forEach(
        request -> {
          try {
            Response<ServiceResponse> getOnlineIdentityResp =
                accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
                    request, domainId, reqIdString, reqTrackingString);

            if (getOnlineIdentityResp.code() == 204) {
              // If the response is 204, skip the deletion
              return;
            }

            accountEntityServiceRetrofit.deleteAccountV1(
                request, domainId, reqIdString, reqTrackingString);

          } catch (IOException e) {
            // Handle the IOException
          }
        });
  }


  /**
   * Create CPR Account using storeNbr and patientId
   *
   * @throws IOException
   */
  public void createCPRAccount(
      String storeNbr, String patientId, String dob, String type, String firstName, String lastName)
      throws IOException {
    cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);
    if (Objects.equals(type, PET)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
      // setting patientType code for PET profile
      cprPatientRequest.getPatientInfo().setPatientTypeCode(10202);
    } else if (Objects.equals(type, HUMAN)) {
      cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
      cprPatientRequest.setPatientId(Integer.parseInt(patientId));
      cprPatientRequest.getPatientInfo().setBirthDate(dob);
      cprPatientRequest.getPatientInfo().setFirstName(firstName);
      cprPatientRequest.getPatientInfo().setLastName(lastName);
    }

    // This will try to create an account in CPR 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else {
        cprProfilesToBeDeletedList.add(cprPatientRequest);
      }
      break;
    }
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  /**
   * Create pharmacy account from online acc id from the customer id we get after ca create and dob,
   * storeNbr and patient id from cpr response
   *
   * @throws IOException
   */
  public void createPharmacyAccount(
      String customerAccountId, String commonStoreNbr, String commonPatientId, String dob)
      throws IOException {
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request(commonStoreNbr, commonPatientId, dob);
    Response<ServiceResponse> response = null;

    // This will try to create a person account in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
          accountEntityServiceRetrofit.createPharmacyAccountV1(
              customerAccountId,
              domainId,
              createPharmacyAccountV1Request,
              reqIdString,
              reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "Account Entity create account creation failed. HttpStatusCode : " + response.code());
        } else {
          pharmacyProfilesToBeDeleted.add(customerAccountId);
        }
      } else break;
    }
  }

  /**
   * Builds accEn Create pharmacy request
   *
   * @return
   */
  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
      String commonStoreNbr, String commonPatientId, String dob) {
    return CreatePharmacyAccountV1Request.builder()
        .accountCreationSource(accountCreationSource)
        .customerInfo(
            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                .storeNbr(commonStoreNbr)
                .patientId(commonPatientId)
                .dob(dob)
                .build())
        .build();
  }

  @Test(priority = 0, description = "Call Resend Fam Request API With Dependent in Rejected State")
  public void resendFamRequestSuccessWithDependentInRejectedState() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(
            dependent1CustomerAccountId, commonDobDPFormatForOlderThan18);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, famResendRequestV1Response);

    // Step - 4: Parsing the response to the FamResendResponse class so that we can assert
    // Response
    FamResendRequestV1Response resendFamRequestResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) famResendRequestV1Response.body().getPayload()),
            FamResendRequestV1Response.class);
    // Step - 5: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(famResendRequestV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        dependent1CustomerAccountId, resendFamRequestResponse.getCustomerAccountId());
  }

  @Test(priority = 1, description = "Call Resend Fam Request API With Dependent in Delinked State")
  public void resendFamRequestSuccessWithDependentInDelinkedState() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(
            dependent2CustomerAccountId, commonDobDPFormatForOlderThan18);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);
    String errorMessage = CommonUtil.buildErrorMessage(gson, famResendRequestV1Response);

    // Step - 4: Parsing the response to the FamResendResponse class so that we can assert
    // Response
    FamResendRequestV1Response resendFamRequestResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) famResendRequestV1Response.body().getPayload()),
            FamResendRequestV1Response.class);
    // Step - 5: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(famResendRequestV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        dependent2CustomerAccountId, resendFamRequestResponse.getCustomerAccountId());
  }

  @Test(priority = 2, description = "Call Resend Fam Request API With Dependent in Active State")
  public void resendFamRequestWithDependentInActiveState() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(
            dependent2CustomerAccountId, commonDobDPFormatForOlderThan18);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, famResendRequestV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 400, errorMessage);
    Assert.assertTrue(errorResponse.getMessage().contains("Transition not allowed."));
  }

  @Test(priority = 3, description = "Call Resend Fam Request API With Invalid Request")
  public void resendFamRequestWithInvalidRequest() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(dependent2CustomerAccountId, null);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, famResendRequestV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 400, errorMessage);
    Assert.assertTrue(
        errorResponse.getMessage().contains("Invalid input request. Dob is null/empty"));
  }

  @Test(
      priority = 4,
      description =
          "Call Resend Fam Request API With random UUID which does not have pharmacy account")
  public void resendFamRequestWith204FromEn() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    String dependentAccountId = CommonUtil.randomUUID();
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(dependentAccountId, commonDobDPFormatForOlderThan18);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 204);
  }

  @Test(priority = 5, description = "Call Resend Fam Request API With Invalid Dependent")
  public void resendFamRequestWithInvalidDependent() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(
            dependent4CustomerAccountId, commonDobDPFormatForOlderThan18);

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, famResendRequestV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 400, errorMessage);
    Assert.assertTrue(errorResponse.getMessage().contains("The given dependent is invalid."));
  }

  @Test(priority = 6, description = "Call Resend Fam Request API With Invalid Dob")
  public void resendFamRequestWithInvalidDob() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Build Request for Resend Fam Request API Call
    FamResendRequestV1Request famResendRequestV1Request =
        buildFamResendRequestV1Request(dependent4CustomerAccountId, "01012000");

    // Step -3: Calling Resend Fam Request API with Valid Request
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        famResendRequestV1Response =
            accountOrchestratorRetrofit.resendFamRequestV1(
                customerAccountId, domainId, famResendRequestV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, famResendRequestV1Response);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(famResendRequestV1Response.code(), 400, errorMessage);
    Assert.assertTrue(errorResponse.getMessage().contains("DoB mismatch between input and CPR"));
  }

  public FamResendRequestV1Request buildFamResendRequestV1Request(
      String dependentAccountId, String dob) {
    return FamResendRequestV1Request.builder()
        .dependentCustomerAccountId(dependentAccountId)
        .dob(dob)
        .build();
  }
}
