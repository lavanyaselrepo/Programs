package accountorchestrator.fam.addDependents;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.AccountOrchestratorServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.restapi.DMPostPreferencesRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.openjdk.tools.javac.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class AccountOrchestratorAddDependentCooldownTestCase {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private DMPostPreferencesRetrofit dmPostPreferencesRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String storeNbr;
  private String phoneNumber;
  private String emailAddress;
  private final String domainId = "WM-PHARMACY";
  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";

  private Integer cprAdultHumanPatientId, minorCprPatientId;
  private String caregiverCustomerAccountId;
  private Date dob = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);

  private Date minorDob = new Date(System.currentTimeMillis() - 2L * 365 * 24 * 60 * 60 * 1000);

  private Date minorIncorrectDob =
      new Date(System.currentTimeMillis() - 1L * 365 * 24 * 60 * 60 * 1000);
  private final String caAdultDob = new SimpleDateFormat("yyyy-MM-dd").format(dob);
  private final String dpAdultDob = new SimpleDateFormat("MMddyyyy").format(dob);

  private final String caMinorDob = new SimpleDateFormat("yyyy-MM-dd").format(minorDob);

  private final String dpMinorDobIncorrect =
      new SimpleDateFormat("MMddyyyy").format(minorIncorrectDob);
  private final String type = "MINOR";
  private final String dobMismatchErrorMessage =
      "DoB mismatch between input and CPR, number of failed authentication attempt has been incremented";
  private final String cooldownErrorMessage = "Customer is in Cooldown Period";

  private final String dobMismatchErrorCode = "DPR-DPACCOR-1009";
  private final String cooldownErrorCode = "DPR-DPACCOR-3001";

  String trackID = CommonUtil.randomUUID();
  String reqId;
  String reqTrackingId;
  Map<String, java.util.List<SMSEnrolledProfileListByCidResponse>>
      patientIdToEnrolledProfilesListMap;
  ValidationServiceRequest adultHumanCprPatientRequest = null, minorCprPatientRequest;

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    dmPostPreferencesRetrofit = new DMPostPreferencesRetrofit();

    storeNbr = CommonUtil.generateRandomNumber(6);
    phoneNumber = CommonUtil.generateRandomNumber(10);
    emailAddress= CommonUtil.generateRandomEmailId(10);
    //    1. Create Astro account for an ADULT patient - get customerAccountId for the ADULT
    caregiverCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

    //    2. Create CPR Accounts
    //        A. for one ADULT patient
    //        B. for one MINOR
    createAllCprAccounts();

    //    3. Enroll both patients with same phone number for SMS
    createSMSEnrollments();

    //    4. Create a Pharmacy Account for the ADULT patient - using customerAccountId gotten in
    // step 1
    CreateAccountByPatientIdV1Request createPharmacyAccountRequest =
        SharedUtils.getCreatePharmacyAccountByPatientIdV1Request(
            storeNbr, String.valueOf(cprAdultHumanPatientId), phoneNumber, dpAdultDob);
    createPharmacyAccount(createPharmacyAccountRequest, caregiverCustomerAccountId);

    //    5. Call getSMSEnrolledProfileListByCid API on the ADULT customerAccountId
    java.util.List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));

    reqId = reqIdString + trackID;
    reqTrackingId = reqTrackingString + trackID;
  }

  @Test(priority = 1, description = "Add Minor Account Trigger Cooldown - Failure")
  public void addMinorAccountTriggerCooldownFailure() throws IOException {
    //    1. Build Add Dependent Request based on getSMSEnrolledProfileList response for the Minor
    AddDependentsV1Request addDependentV1Request = buildMinorAddDependentRequest();
    int attemptNumber = 1;

    //    2. Make 4 attempts to addDependent API with incorrect DoB and verify the response code,
    //        error message, failedAttemptsCount
    for (; attemptNumber <= 4; attemptNumber++) {
      Reporter.logJSON("Attempt number started", attemptNumber);
      Response<ServiceResponse> addDependentResponse =
          callWithIncorrectDobAndValidateResponseCode(addDependentV1Request, attemptNumber);
      validateErrorResponse(
          addDependentResponse, dobMismatchErrorCode, dobMismatchErrorMessage, attemptNumber);
      Reporter.logJSON("Attempt number ended", attemptNumber);
    }

    //    3. Make 2 attempts to addDependent API with incorrect DoB and verify the response code,
    //        error message, failedAttemptsCount
    for (; attemptNumber <= 6; attemptNumber++) {
      Reporter.logJSON("Attempt number started", attemptNumber);
      Response<ServiceResponse> addDependentResponse =
          callWithIncorrectDobAndValidateResponseCode(addDependentV1Request, attemptNumber);
      validateErrorResponse(addDependentResponse, cooldownErrorCode, cooldownErrorMessage, 5);
      Reporter.logJSON("Attempt number ended", attemptNumber);
    }

    //    4. Call getSMSEnrolledProfileListByCid on ADULT patient's customerAccountId and verify the
    // MINOR profile
    //      is in cooldown
    validatePatientInCooldown();

    //    5. Call getFamLinks on ADULT patient's customerAccountId and verify the MINOR profile
    //      has not been added
    validateFamLinksResponse();
  }

  private Response<ServiceResponse> callWithIncorrectDobAndValidateResponseCode(
      AddDependentsV1Request addDependentV1Request, int attemptNumber) throws IOException {
    String localRequestTrackingId = reqTrackingId + "_" + attemptNumber;
    CommonUtil.logFlowIdentifiers(
        caregiverCustomerAccountId, domainId, phoneNumber, type, reqId, localRequestTrackingId);
    return accountOrchestratorRetrofit.famAddDependent(
        caregiverCustomerAccountId, domainId, addDependentV1Request, reqId, localRequestTrackingId);
  }

  private void validateErrorResponse(
      Response<ServiceResponse> addDependentResponse,
      String expectedErrorCode,
      String expectedErrorMessage,
      int expectedFailedAuthCount) {

    ServiceResponse serviceResponse = CommonUtil.getServiceResponse(gson, addDependentResponse);
    Error errorResponse = serviceResponse.getError();
    Object payload = serviceResponse.getPayload();

    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);
    Assert.assertEquals(addDependentResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), expectedErrorCode);
    Assert.assertEquals(errorResponse.getMessage(), expectedErrorMessage);

    Dependent2 dependent = extractDependentFromResponse(payload);
    Assert.assertEquals(
        (int) dependent.getCoolDownStatus().getFailedAttemptsCount(), expectedFailedAuthCount);
  }

  private void validatePatientInCooldown() throws IOException {
    java.util.List<SMSEnrolledProfileListByCidResponse> smsEnrolledProfileList =
        AccountOrchestratorServiceHelper.getSMSEnrolledProfileList(
            reqIdString,
            reqTrackingString,
            caregiverCustomerAccountId,
            domainId,
            type,
            accountOrchestratorRetrofit);
    patientIdToEnrolledProfilesListMap =
        smsEnrolledProfileList.stream()
            .collect(
                Collectors.groupingBy(
                    enrolledProfile -> enrolledProfile.getCustomerInfo().getPatientId()));
    SMSEnrolledProfileListByCidResponse minorPatientProfile2 =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(minorCprPatientId)).get(0);
    Assert.assertTrue(minorPatientProfile2.getCustomerInfo().isIsInCooldown());
  }

  private void validateFamLinksResponse() throws IOException {
    String linkageStatus = "ALL";
    Response<ServiceResponse> getFamLinksV1Response =
        accountOrchestratorRetrofit.getFamLinksV1(
            caregiverCustomerAccountId,
            domainId,
            "DEPENDENT",
            reqId,
            reqTrackingId + "famLinksVerification",
                linkageStatus);

    // Parsing the response to the GetFamLinksResponse class so that we can assert GetFamLinks
    GetFamLinksResponse getFamLinksResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>)
                            getFamLinksV1Response.body().getPayload()),
                    GetFamLinksResponse.class);

    String getFamLinksErrorMessage = CommonUtil.buildErrorMessage(gson, getFamLinksV1Response);
    Assert.assertEquals(getFamLinksV1Response.code(), 200, getFamLinksErrorMessage);
    Assert.assertEquals(getFamLinksResponse.getDependentsInfo().size(),0);
  }

  private void createSMSEnrollment(String storeNbr, String patientId, String phoneNumber)
      throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {
      throw new RuntimeException(
          "DM Post Preference call failure. HttpStatusCode : " + response.code());
    }
  }

  private void createAllCprAccounts() throws IOException {
    // Create CPR Account before running "create pharmacy account" related test cases
    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adultHumanCprPatientRequest.getPatientInfo().setBirthDate(caAdultDob);

    minorCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorCprPatientRequest.getPatientInfo().setPatientTypeCode(10200);
    minorCprPatientRequest.getPatientInfo().setBirthDate(caMinorDob);
    List.of(adultHumanCprPatientRequest, minorCprPatientRequest)
        .forEach(patientRequest -> patientRequest.setStoreNbr(Integer.parseInt(storeNbr)));

    cprAdultHumanPatientId =
        SharedUtils.createCprAccount(adultHumanCprPatientRequest, cprPatientUpdateRetrofit);
    minorCprPatientId =
        SharedUtils.createCprAccount(minorCprPatientRequest, cprPatientUpdateRetrofit);

    Reporter.logJSON("cprAdultHumanPatientId: ", cprAdultHumanPatientId);
    Reporter.logJSON("minorCprPatientId: ", minorCprPatientId);
    Reporter.logJSON("storeNbr: ", storeNbr);
    // This is needed because CPR account creation is async, and it usually takes a couple of
    // seconds to reflect account creation
    try {
      Thread.sleep(30000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private void createSMSEnrollments() {
    List.of(cprAdultHumanPatientId, minorCprPatientId)
        .forEach(
            patientId -> {
              try {
                createSMSEnrollment(storeNbr, String.valueOf(patientId), phoneNumber);
              } catch (IOException e) {
                throw new RuntimeException(
                    String.format(
                        "Error Enrolling storeNbr: %s, patientId: %s for SMS Enrollment at phone number: %s, error:  ",
                        storeNbr, patientId, e.getMessage()));
              }
            });
  }

  private void createPharmacyAccount(
      CreateAccountByPatientIdV1Request createAccountByPatientIdV1Request, String customerAccountId)
      throws IOException {
    Response<ServiceResponse> createAccountByPatientIdV1Response =
        accountOrchestratorRetrofit.createAccountByPatientIdV1(
            customerAccountId, domainId, createAccountByPatientIdV1Request);
    if (createAccountByPatientIdV1Response.code() == 200
        && createAccountByPatientIdV1Response.body() != null) {

    } else {
      throw new RuntimeException(
          "Create patient account failed for customerId: "
              + customerAccountId
              + " with HttpStatusCode : "
              + createAccountByPatientIdV1Response.code());
    }
  }


  @AfterClass
  void cleanUp() {
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorCprPatientRequest.setPatientId(minorCprPatientId);

    List.of(adultHumanCprPatientRequest, minorCprPatientRequest)
        .forEach(
            request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
              }
            });
    List.of(cprAdultHumanPatientId, minorCprPatientId)
        .forEach(
            patientId -> {
              try {
                cleanUpSMSEnrollment(storeNbr, String.valueOf(patientId));
              } catch (IOException e) {
              }
            });
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
        cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
        && response.body() != null
        && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON(
          "errorMessage",
          String.format(
              "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
              cprRequest.getPatientId(), response.code()));
    }
  }

  private void cleanUpSMSEnrollment(String storeNbr, String patientId) throws IOException {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz");
    String timestamp = dtf.format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    DMPostPreferencesRequest dmPostPreferencesRequest =
        DMPostPreferencesRequest.builder()
            .storeNbr(storeNbr)
            .patientId(patientId)
                .zipCode("96898")
                .userId("SIGPAD")
                .storePhone("8009666546")
                .timeStamp(timestamp)
                .language("101")
            .preferences(
                List.of(
                    DMPostPreferencesRequest.Preference.builder()
                        .notification_type("1")
                        .notification_val(phoneNumber)
                        .short_code_type_id("1")
                        .enrollment_status_code("26805")
                        .build()))
            .build();

    Response<DMPostPreferencesResponse> response =
        dmPostPreferencesRetrofit.callDMPostPreferencesAPI(dmPostPreferencesRequest);

    if (!(response.code() == 200
        && response.body() != null
        && response.body().getResponseStatus() != null
        && "100".equals(response.body().getResponseStatus().getStatus_code()))) {}
  }

  private AddDependentsV1Request buildMinorAddDependentRequest() {
    SMSEnrolledProfileListByCidResponse minorPatientProfile =
        patientIdToEnrolledProfilesListMap.get(String.valueOf(minorCprPatientId)).get(0);
    CustomerInfo2 enrolledProfile = minorPatientProfile.getCustomerInfo();
    DependentInfo2 fadDependentInfo = new DependentInfo2();
    fadDependentInfo.validationToken(minorPatientProfile.getValidationToken());
    fadDependentInfo.setType(type);
    fadDependentInfo.setDob(dpMinorDobIncorrect);
    fadDependentInfo.tAndCPolicyLanguage("EN");
    AddDependentsV1Request addDependentV1Request = new AddDependentsV1Request();
    addDependentV1Request.dependentsInfo(List.of(fadDependentInfo));
    return addDependentV1Request;
  }

  private Dependent2 extractDependentFromResponse(Object payload) {
    return ResponseUtil.parseResponse(
        gson, ((LinkedTreeMap<String, Object>) payload), Dependent2.class);
  }
}
