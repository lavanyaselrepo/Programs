package accountorchestrator.utils;

import accountorchestrator.constants.AccountOrchestratorConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateAccountStatusV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.postpreferences.model.DMPostPreferencesRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Shared builder for CPR and DM test request objects.
 *
 * Every invocation produces a unique request payload — all patient-identifying and PII fields
 * are randomly generated, while mandatory system-level codes remain fixed as required by the
 * respective API contracts.
 *
 * <p>Usage:
 *
 * <pre>
 *   ValidationServiceRequest cprRequest = CprPatientRequestBuilder.buildValidationServiceRequest(
 *       storeNbr, patientId, phoneNbr, dobCPRFormat);
 *
 *   DMPostPreferencesRequest dmRequest = CprPatientRequestBuilder.buildDMPostPreferencesRequest(
 *       storeNbr, patientId, phoneNbr);
 * </pre>
 */
public class CprPatientRequestBuilder {

  private static final ObjectMapper MAPPER = new ObjectMapper();

  /**
   * Builds a fully dynamic {@link ValidationServiceRequest} without any file I/O.
   *
   * @param storeNbr      the store number (numeric string)
   * @param patientId     the patient ID (numeric string)
   * @param phoneNbr      the 10-digit phone number used as the communication ID
   * @param dobCPRFormat  the patient date of birth in {@code yyyy-MM-dd} format
   * @return a populated {@link ValidationServiceRequest} instance
   * @throws IOException if Jackson fails to deserialise the built node tree
   */
  public static ValidationServiceRequest buildValidationServiceRequest(
      String storeNbr, String patientId, String phoneNbr, String dobCPRFormat)
      throws IOException {

    String timestamp =
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
    String storeChangeTs = timestamp + "Z";
    String changeUserId = RandomStringUtils.randomAlphabetic(7).toUpperCase();

    // -- patientInfo --
    ObjectNode patientInfo = MAPPER.createObjectNode();
    patientInfo.put("lastName", RandomStringUtils.randomAlphabetic(5).toUpperCase());
    patientInfo.put("firstName", RandomStringUtils.randomAlphabetic(5).toUpperCase());
    patientInfo.put("middleName", "");
    patientInfo.put("languageCode", "101");
    patientInfo.put("gender", "F");
    patientInfo.put("birthDate", dobCPRFormat);
    patientInfo.put("patientStatusCode", 20700);
    patientInfo.put("hipaaStatusCode", 9510);
    patientInfo.put("patientTypeCode", 10200);
    patientInfo.putNull("autoPaySignupCode");
    patientInfo.put("chargeFreqCode", 5900);
    patientInfo.put("ethnicityTypeCode", 1);
    patientInfo.put("raceTypeCode", 1);
    patientInfo.put("defaultAddressTypeCode", 3);
    patientInfo.put(
        "askMedicareDate",
        LocalDate.now().plusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    patientInfo.put("createTs", timestamp);
    patientInfo.put("lastChangeUserId", changeUserId);
    patientInfo.put("storeChangeTs", storeChangeTs);
    patientInfo.put("clinicId", 123);
    patientInfo.put("prescriberId", 123);
    patientInfo.put("genderIdentityCode", 2);
    patientInfo.put("mailOutCode", 6001);

    // -- patientCommunicationInfo --
    ObjectNode commInfo = MAPPER.createObjectNode();
    commInfo.put("commMethodCode", 2);
    commInfo.put("commSeqNbr", 1);
    commInfo.put("communicationId", phoneNbr);
    commInfo.put("lastChangeUserId", changeUserId);
    commInfo.put("lastChangeTs", timestamp);
    ArrayNode patientCommunicationInfo = MAPPER.createArrayNode().add(commInfo);

    // -- patientAddressInfo --
    ObjectNode addressInfo = MAPPER.createObjectNode();
    addressInfo.put("addressTypeCode", 3);
    addressInfo.put("addressSeqNbr", 1);
    addressInfo.put(
        "addressLine1",
        CommonUtil.generateRandomNumber(4)
            + " "
            + RandomStringUtils.randomAlphabetic(6).toUpperCase()
            + " RD");
    addressInfo.put("addressLine2", "");
    addressInfo.put("addressLine3", "");
    addressInfo.put("addressLine4", "");
    addressInfo.put("city", RandomStringUtils.randomAlphabetic(6).toUpperCase());
    addressInfo.put("county", RandomStringUtils.randomAlphabetic(6).toUpperCase());
    addressInfo.put("state", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    addressInfo.put("country", "US");
    addressInfo.put(
        "zipCode",
        CommonUtil.generateRandomNumber(5) + CommonUtil.generateRandomNumber(4));
    addressInfo.put("cmsQlfdFacility", "N");
    addressInfo.put("patientResidenceCode", 1001);
    addressInfo.put("lastAddressValidateDate", timestamp);
    addressInfo.put("verifyFreqCode", 2);
    addressInfo.put("lastChangeUserId", changeUserId);
    addressInfo.put("lastChangeTs", timestamp);
    ArrayNode patientAddressInfo = MAPPER.createArrayNode().add(addressInfo);

    // -- patientReferenceInfo --
    ObjectNode refInfo = MAPPER.createObjectNode();
    refInfo.put("referenceSeqNbr", 1);
    refInfo.putNull("expirationDate");
    refInfo.put("issueAgencyCode", 101);
    refInfo.put("referenceCode", 600);
    refInfo.put("referenceNbr", CommonUtil.generateRandomNumber(9));
    refInfo.put("lastChangeUserId", changeUserId);
    refInfo.put("lastChangeTs", timestamp);
    ArrayNode patientReferenceInfo = MAPPER.createArrayNode().add(refInfo);

    // -- patientAllergyInfo --
    ObjectNode allergyInfo = MAPPER.createObjectNode();
    allergyInfo.put("allergyClassCode", 26);
    allergyInfo.put("effectiveTs", timestamp);
    allergyInfo.putNull("expirationDate");
    allergyInfo.put("lastChangeUserId", changeUserId);
    allergyInfo.put("lastChangeTs", timestamp);
    allergyInfo.put("reactionText", RandomStringUtils.randomAlphabetic(5));
    allergyInfo.putNull("reasonDeactivatedText");
    allergyInfo.put("allergyClassTypeCode", 1000);
    ArrayNode patientAllergyInfo = MAPPER.createArrayNode().add(allergyInfo);

    // -- patientDiseaseInfo --
    ObjectNode diseaseInfo = MAPPER.createObjectNode();
    diseaseInfo.put("diseaseCode", 826);
    diseaseInfo.put("effectiveTs", timestamp);
    diseaseInfo.putNull("expirationDate");
    diseaseInfo.put("chronicInd", "N");
    diseaseInfo.put("lastChangeUserId", changeUserId);
    diseaseInfo.put("lastChangeTs", timestamp);
    diseaseInfo.putNull("reasonDeactivatedText");
    diseaseInfo.put("diseaseClassTypeCode", 1000);
    ArrayNode patientDiseaseInfo = MAPPER.createArrayNode().add(diseaseInfo);

    // -- patientMedicationInfo --
    ObjectNode medInfo = MAPPER.createObjectNode();
    medInfo.put("medSeqNbr", 826);
    medInfo.put("mdsFamId", 1000);
    medInfo.put(
        "medStartDate",
        LocalDate.now().minusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    medInfo.put(
        "medExpDate",
        LocalDate.now().plusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    medInfo.put("drugName", RandomStringUtils.randomAlphabetic(6));
    medInfo.put("lastChangeUserId", changeUserId);
    medInfo.put("lastChangeTs", timestamp);
    medInfo.put("centralProductId", 1000);
    ArrayNode patientMedicationInfo = MAPPER.createArrayNode().add(medInfo);

    // -- patientRestrictInfo --
    ObjectNode restrictInfo = MAPPER.createObjectNode();
    restrictInfo.put("restrictTypeCode", 726);
    restrictInfo.put("restrictValue", "Y");
    restrictInfo.put("effectiveTs", timestamp);
    restrictInfo.put("lastChangeUserId", changeUserId);
    restrictInfo.put("lastChangeTs", timestamp);
    ArrayNode patientRestrictInfo = MAPPER.createArrayNode().add(restrictInfo);

    // -- patientDemographicInfo --
    ObjectNode demogInfo = MAPPER.createObjectNode();
    demogInfo.put("demogTypeCode", 8606);
    demogInfo.put("demogChangeTs", timestamp);
    demogInfo.put("demogValue", CommonUtil.generateRandomNumber(3));
    demogInfo.put("uomCode", 101);
    demogInfo.put("lastChangeUserId", changeUserId);
    demogInfo.put("lastChangeTs", timestamp);
    ArrayNode patientDemographicInfo = MAPPER.createArrayNode().add(demogInfo);

    // -- patientInsuranceInfo shared objects --
    ObjectNode overrideInfo1 = MAPPER.createObjectNode();
    overrideInfo1.put("overrideId", 4901);
    overrideInfo1.put("overrideValue", 4800);
    ObjectNode overrideInfo2 = MAPPER.createObjectNode();
    overrideInfo2.put("overrideId", 4900);
    overrideInfo2.put("overrideValue", 4600);
    ArrayNode overrideArray =
        MAPPER.createArrayNode().add(overrideInfo1).add(overrideInfo2);

    ObjectNode workersComp = MAPPER.createObjectNode();
    workersComp.put("claimNbr", CommonUtil.generateRandomNumber(4));
    workersComp.put(
        "injuryDate",
        LocalDate.now().minusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    workersComp.put("employer", RandomStringUtils.randomAlphabetic(5));
    workersComp.put("contact", RandomStringUtils.randomAlphabetic(5));
    workersComp.put("phone", CommonUtil.generateRandomNumber(10));
    workersComp.put("carrier", RandomStringUtils.randomAlphabetic(5));
    workersComp.put(
        "addressLine1",
        CommonUtil.generateRandomNumber(3) + " " + RandomStringUtils.randomAlphabetic(5));
    workersComp.put("addressLine2", RandomStringUtils.randomAlphabetic(5));
    workersComp.put("city", RandomStringUtils.randomAlphabetic(5));
    workersComp.put("state", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    workersComp.put("zipCode", CommonUtil.generateRandomNumber(4));
    workersComp.put("country", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    workersComp.put("otherComment", RandomStringUtils.randomAlphabetic(5));

    // -- patientInsuranceInfo entry 1 (COMM / primary) --
    ObjectNode ins1 = MAPPER.createObjectNode();
    ins1.put("insPlanTypeCode", 1007);
    ins1.put("billingSeqNbr", 1);
    ins1.put("insCarrierAbbr", "QA");
    ins1.put("insPlanRefCode", "COMM");
    ins1.put("billingGroupNbr", CommonUtil.generateRandomNumber(4));
    ins1.put("cardholderId", CommonUtil.generateRandomNumber(9));
    ins1.put("cardholderFirstName", RandomStringUtils.randomAlphabetic(5));
    ins1.put("cardholderLastName", RandomStringUtils.randomAlphabetic(5));
    ins1.put("relationshipCode", 3201);
    ins1.put("dependentCode", "1");
    ins1.put("coverageInd", "Y");
    ins1.putNull("coverageExpDate");
    ins1.put("splitBillInd", "N");
    ins1.put("lastChangeTs", timestamp);
    ins1.put("lastChangeUserId", changeUserId);
    ins1.put("homePlanCoverageId", 22);
    ins1.put(
        "insuranceBirthdate",
        LocalDate.now().minusYears(30).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    ins1.put("insurancePlanId", 105);
    ins1.put("insuranceCarrierId", 10);
    ins1.put("dscntCardFirstName", RandomStringUtils.randomAlphabetic(5));
    ins1.put("dscntCardLastName", RandomStringUtils.randomAlphabetic(5));
    ins1.set("patientInsuranceOverrideInfo", overrideArray);
    ins1.set("patientInsuranceWorkersCompInfo", workersComp);

    // -- patientInsuranceInfo entry 2 (GVMT / secondary) --
    ObjectNode ins2 = MAPPER.createObjectNode();
    ins2.put("insPlanTypeCode", 1007);
    ins2.put("billingSeqNbr", 2);
    ins2.put("insCarrierAbbr", "QA");
    ins2.put("insPlanRefCode", "GVMT");
    ins2.put("billingGroupNbr", CommonUtil.generateRandomNumber(4));
    ins2.put("cardholderId", CommonUtil.generateRandomNumber(7));
    ins2.put("cardholderFirstName", RandomStringUtils.randomAlphabetic(5));
    ins2.put("cardholderLastName", RandomStringUtils.randomAlphabetic(5));
    ins2.put("relationshipCode", 3201);
    ins2.put("dependentCode", "1");
    ins2.put("coverageInd", "Y");
    ins2.putNull("coverageExpDate");
    ins2.put("splitBillInd", "N");
    ins2.put("lastChangeTs", timestamp);
    ins2.put("lastChangeUserId", changeUserId);
    ins2.put("homePlanCoverageId", 23);
    ins2.put(
        "insuranceBirthdate",
        LocalDate.now().minusYears(28).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    ins2.put("insurancePlanId", 106);
    ins2.put("insuranceCarrierId", 11);
    ins2.put("dscntCardFirstName", RandomStringUtils.randomAlphabetic(5));
    ins2.put("dscntCardLastName", RandomStringUtils.randomAlphabetic(5));
    ins2.set("patientInsuranceOverrideInfo", overrideArray);
    ArrayNode patientInsuranceInfo = MAPPER.createArrayNode().add(ins1).add(ins2);

    // -- emergencyContactInfo --
    ObjectNode emergencyContact = MAPPER.createObjectNode();
    emergencyContact.put("personId", Integer.parseInt(CommonUtil.generateRandomNumber(6)));
    emergencyContact.put("contactCode", 100);
    emergencyContact.put("relationshipCode", 3205);
    emergencyContact.put("firstName", RandomStringUtils.randomAlphabetic(5));
    emergencyContact.put("middleName", RandomStringUtils.randomAlphabetic(3));
    emergencyContact.put("lastName", RandomStringUtils.randomAlphabetic(5));
    emergencyContact.put("gender", "M");
    emergencyContact.put(
        "birthDate",
        LocalDate.now().minusYears(30).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    emergencyContact.put("phoneNbr", CommonUtil.generateRandomNumber(10));
    emergencyContact.put("lastChangeUserId", changeUserId);
    emergencyContact.put("lastChangeTs", timestamp);
    ArrayNode emergencyContactInfo = MAPPER.createArrayNode().add(emergencyContact);

    // -- patientPersonalRepInfo --
    ObjectNode personalRep = MAPPER.createObjectNode();
    personalRep.put("documentId", 1);
    personalRep.put("personId", Integer.parseInt(CommonUtil.generateRandomNumber(4)));
    personalRep.put("firstName", RandomStringUtils.randomAlphabetic(5));
    personalRep.put("lastName", RandomStringUtils.randomAlphabetic(5));
    personalRep.put("contactCode", 318);
    personalRep.put("documentTypeCode", 3);
    personalRep.put("documentStorageId", CommonUtil.generateRandomNumber(7));
    personalRep.put(
        "expireDate",
        LocalDate.now().plusYears(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    personalRep.put("lastChangeUserId", changeUserId);
    personalRep.put("lastChangeTs", timestamp);
    ArrayNode patientPersonalRepInfo = MAPPER.createArrayNode().add(personalRep);

    // -- hipaaAckInfo --
    ObjectNode hipaaAckInfo = MAPPER.createObjectNode();
    hipaaAckInfo.put("hipaaStatus", "accept");
    hipaaAckInfo.put("pharmacySignatureId", 2180);
    hipaaAckInfo.put("relationshipCode", 9550);
    hipaaAckInfo.put(
        "expirationTs",
        LocalDate.now().plusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            + "T15:00:00");
    hipaaAckInfo.put("signatureTypeCode", 3901);
    hipaaAckInfo.put("languageCode", "101");
    hipaaAckInfo.put("centralFileId", Integer.parseInt(CommonUtil.generateRandomNumber(9)));
    hipaaAckInfo.put("captureUserId", changeUserId);
    hipaaAckInfo.put("captureTs", timestamp);

    // -- patientPaymentInfo --
    ObjectNode paymentInfo = MAPPER.createObjectNode();
    paymentInfo.put("phmPymtAcctId", 49);
    paymentInfo.put("cardSeqNbr", "1");
    paymentInfo.put("pymtFreqCode", 8352);
    paymentInfo.put("phmSignatureId", 0);
    paymentInfo.put("relationshipCode", 3202);
    paymentInfo.put(
        "startDate",
        LocalDate.now().minusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    paymentInfo.put(
        "revokeDate",
        LocalDate.now().minusYears(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    paymentInfo.put("accountNbr", "");
    paymentInfo.put("expirYearNbr", LocalDate.now().plusYears(5).getYear());
    paymentInfo.put("expirMoNbr", 12);
    paymentInfo.put(
        "cardHolderName",
        RandomStringUtils.randomAlphabetic(5).toUpperCase()
            + ","
            + RandomStringUtils.randomAlphabetic(5).toUpperCase());
    paymentInfo.put("phmPymtMthdCode", 102);
    paymentInfo.put(
        "billingAddrTxt",
        RandomStringUtils.randomAlphabetic(5).toUpperCase()
            + " "
            + RandomStringUtils.randomAlphabetic(5).toUpperCase()
            + ",");
    paymentInfo.put("cityName", RandomStringUtils.randomAlphabetic(6).toUpperCase());
    paymentInfo.put("postalCode", CommonUtil.generateRandomNumber(5) + "-");
    paymentInfo.put("stateProvCode", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    paymentInfo.put("routingNbr", CommonUtil.generateRandomNumber(7));
    paymentInfo.put("phoneNbr", CommonUtil.generateRandomNumber(10));
    paymentInfo.put("checkSecurityNbr", "");
    paymentInfo.put("checkBankName", "");
    paymentInfo.put("cardRefNbr", Long.parseLong(CommonUtil.generateRandomNumber(13)));
    paymentInfo.put("cardSuffixNbr", CommonUtil.generateRandomNumber(3));
    paymentInfo.put("ascDiscCardNbr", "");
    paymentInfo.put("lastChangeUserId", changeUserId);
    paymentInfo.put("signatureFrequencyCode", 8352);
    paymentInfo.put("p2peToken", RandomStringUtils.randomAlphanumeric(22));
    ArrayNode patientPaymentInfo = MAPPER.createArrayNode().add(paymentInfo);

    // -- root node --
    ObjectNode root = MAPPER.createObjectNode();
    root.put("storeNbr", Integer.parseInt(storeNbr));
    root.put("patientId", Integer.parseInt(patientId));
    root.set("patientInfo", patientInfo);
    root.set("patientCommunicationInfo", patientCommunicationInfo);
    root.set("patientAddressInfo", patientAddressInfo);
    root.set("patientReferenceInfo", patientReferenceInfo);
    root.set("patientAllergyInfo", patientAllergyInfo);
    root.set("patientDiseaseInfo", patientDiseaseInfo);
    root.set("patientMedicationInfo", patientMedicationInfo);
    root.set("patientRestrictInfo", patientRestrictInfo);
    root.set("patientDemographicInfo", patientDemographicInfo);
    root.set("patientInsuranceInfo", patientInsuranceInfo);
    root.set("emergencyContactInfo", emergencyContactInfo);
    root.set("patientPersonalRepInfo", patientPersonalRepInfo);
    root.set("hipaaAckInfo", hipaaAckInfo);
    root.set("patientPaymentInfo", patientPaymentInfo);

    return MAPPER.treeToValue(root, ValidationServiceRequest.class);
  }

  /**
   * Builds a fully dynamic {@link DMPostPreferencesRequest} for SMS enrollment in DM Post
   * Preferences API tests.
   *
   * <p>Dynamic fields:
   * <ul>
   *   <li>{@code zipCode}    – random 5-digit number
   *   <li>{@code storePhone} – random 10-digit number
   *   <li>{@code timeStamp}  – current system timestamp
   * </ul>
   *
   * <p>Fixed system codes ({@code userId}, {@code language}, {@code notification_type},
   * {@code short_code_type_id}, {@code enrollment_status_code}) are mandatory DM API contract
   * values and are not randomised.
   *
   * @param storeNbr  the store number
   * @param patientId the patient ID
   * @param phoneNbr  the 10-digit phone number used as the notification value
   * @return a populated {@link DMPostPreferencesRequest} instance
   */
  public static DMPostPreferencesRequest buildDMPostPreferencesRequest(
      String storeNbr, String patientId, String phoneNbr) {

    String timestamp =
        DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ssz")
            .format(LocalDateTime.now().atZone(ZoneId.systemDefault()));

    return DMPostPreferencesRequest.builder()
        .storeNbr(storeNbr)
        .patientId(patientId)
        .zipCode(CommonUtil.generateRandomNumber(5))
        .userId("SIGPAD")
        .storePhone(CommonUtil.generateRandomNumber(10))
        .timeStamp(timestamp)
        .language("101")
        .preferences(
            List.of(
                DMPostPreferencesRequest.Preference.builder()
                    .notification_type("1")
                    .notification_val(phoneNbr)
                    .short_code_type_id("1")
                    .enrollment_status_code("26805")
                    .build()))
        .build();
  }

  /**
   * Builds a fully dynamic {@link UpdateAccountStatusV1Request}
   *
   * <p>Dynamic fields:
   * <ul>
   *   <li>{@code customerInfo.firstName}   – random 5-char alphabetic string
   *   <li>{@code customerInfo.lastName}    – random 5-char alphabetic string
   *   <li>{@code customerInfo.dob}         – 25 years ago in {@code MMddyyyy} format
   *   <li>{@code customerInfo.phoneNumber} – random 10-digit number
   *   <li>{@code address.addressLine1}     – random street address
   *   <li>{@code address.addressLine2}     – random 8-char alphabetic string
   *   <li>{@code address.city}             – random 7-char alphabetic string
   *   <li>{@code address.state}            – random 2-char uppercase alphabetic string
   *   <li>{@code address.zipCode}          – random 5-digit number
   *   <li>{@code photoId.number}           – random 14-digit number
   *   <li>{@code photoId.state}            – random 2-char uppercase alphabetic string
   *   <li>{@code photoId.expirationDate}   – 3 years in the future in {@code MM-dd-yyyy} format
   * </ul>
   *
   * <p>Default {@code idVerified.source} is {@code EXPERIAN} — override per-test for
   * {@code RX_STORE} scenarios.
   *
   * @return a populated {@link UpdateAccountStatusV1Request} instance
   * @throws IOException if Jackson fails to deserialise the built node tree
   */
  public static UpdateAccountStatusV1Request buildUpdateAccountStatusRequest() throws IOException {

    // -- idVerified --
    ObjectNode idVerified = MAPPER.createObjectNode();
    idVerified.put("status", true);
    idVerified.put("source", AccountOrchestratorConstants.VERIFICATION_SOURCE_EXPERIAN);

    // -- address --
    ObjectNode address = MAPPER.createObjectNode();
    address.put(
        "addressLine1",
        CommonUtil.generateRandomNumber(4)
            + " "
            + RandomStringUtils.randomAlphabetic(6)
            + " St");
    address.put("addressLine2", RandomStringUtils.randomAlphabetic(8));
    address.putNull("addressLine3");
    address.putNull("addressLine4");
    address.put("city", RandomStringUtils.randomAlphabetic(7));
    address.put("state", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    address.put("zipCode", CommonUtil.generateRandomNumber(5));
    address.put("country", AccountOrchestratorConstants.ADDRESS_COUNTRY_USA);

    // -- customerInfo --
    ObjectNode customerInfo = MAPPER.createObjectNode();
    customerInfo.put("firstName", RandomStringUtils.randomAlphabetic(5));
    customerInfo.put("lastName", RandomStringUtils.randomAlphabetic(5));
    customerInfo.put(
        "dob",
        LocalDate.now().minusYears(25).format(DateTimeFormatter.ofPattern("MMddyyyy")));
    customerInfo.put("phoneNumber", CommonUtil.generateRandomNumber(10));
    customerInfo.set("address", address);

    // -- photoId --
    ObjectNode photoId = MAPPER.createObjectNode();
    photoId.put("type", AccountOrchestratorConstants.PHOTO_ID_TYPE_DRV);
    photoId.put("number", CommonUtil.generateRandomNumber(14));
    photoId.put("state", RandomStringUtils.randomAlphabetic(2).toUpperCase());
    photoId.put("country", AccountOrchestratorConstants.PHOTO_ID_COUNTRY_US);
    photoId.put(
        "expirationDate",
        LocalDate.now().plusYears(3).format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));

    // -- authData --
    ObjectNode authData = MAPPER.createObjectNode();
    authData.set("customerInfo", customerInfo);
    authData.set("photoId", photoId);

    // -- root --
    ObjectNode root = MAPPER.createObjectNode();
    root.set("idVerified", idVerified);
    root.put("twoFASetUpStatus", AccountOrchestratorConstants.TWO_FA_STATUS_ACTIVE);
    root.set("authData", authData);

    return MAPPER.treeToValue(root, UpdateAccountStatusV1Request.class);
  }
}
