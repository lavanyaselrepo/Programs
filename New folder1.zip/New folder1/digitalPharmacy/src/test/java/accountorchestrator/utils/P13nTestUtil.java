package test.java.accountorchestrator.utils;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nAuditDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nEntity;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class for common P13N test operations
 */
public class P13nTestUtil {

    /**
     * Clean up all P13N records (main and audit) for a specific entity and account
     *
     * @param onlineAccountId the account ID to clean up
     * @param entity the P13N entity type to clean up
     * @param p13nDao the P13N DAO instance
     * @param p13nAuditDao the P13N Audit DAO instance
     */
    public static void cleanupP13nRecords(
            String onlineAccountId,
            P13nEntity entity,
            P13nDao p13nDao,
            P13nAuditDao p13nAuditDao) {
        try {
            // Get all P13N documents for the account
            List<P13nDocument> allDocs = p13nDao.getP13nDocuments(onlineAccountId);

            // Filter for specific entity documents (all types)
            List<String> entityDocIds = allDocs.stream()
                    .filter(doc -> doc.getEntity() == entity)
                    .map(P13nDocument::getId)
                    .collect(Collectors.toList());

            // Delete from main container if any exist
            if (!entityDocIds.isEmpty()) {
                p13nDao.deleteP13nDocuments(onlineAccountId, entityDocIds);
            }

            // Delete from audit container
            p13nAuditDao.deleteP13nAuditDocuments(onlineAccountId, entity);

        } catch (Exception e) {
            // Silently ignore cleanup failures
        }
    }
}
