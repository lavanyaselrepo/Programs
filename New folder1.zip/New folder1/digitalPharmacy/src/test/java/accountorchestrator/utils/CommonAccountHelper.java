package accountorchestrator.utils;

import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.AccountType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.response.WCPCreateGuestAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPCreateGuestAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wiapp.restapi.WIAppRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wiapp.response.WIAppGetUserPrincipalResponse;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import retrofit2.Response;

public class CommonAccountHelper {

    private static final int MAX_RETRIES = 3;
    private static final int RETRY_DELAY_MS[] = {2000, 5000, 10000};
    private static String commonPhoneNo = "1234567829";
    private static String commonPassword = "Test@12345";

    private static DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    private static WIAppRetrofit wiAppRetrofit = new WIAppRetrofit();
    private static WCPRetroFit wcpRetroFit = new WCPRetroFit();
    static String clientId = "d4fe2f58-c591-4519-aa46-f3bef932fd67";

    public static String createDotComAccountAndGetCidOfAstroFromWIAP(String email, String password, String phoneNumber, String firstName, String lastName, String trackingId) throws Exception {
        long startTime = System.currentTimeMillis();
        Reporter.log("Starting getCidOfAstroFromWIAP for email: " + email);

        digitalPharmacyAPIManager.createDotComAccount(email, password, phoneNumber, firstName, lastName);

        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            long attemptStartTime = System.currentTimeMillis();

            Response<WIAppGetUserPrincipalResponse> response = wiAppRetrofit.getUserPrincipal(
                clientId,
                null,
                email,
                null,
                trackingId
            );

            long attemptDuration = System.currentTimeMillis() - attemptStartTime;

            if (response.isSuccessful() && response.body() != null && response.body().getPrincipal_id() != null) {
                long totalDuration = System.currentTimeMillis() - startTime;
                Reporter.log("Successfully retrieved principal_id in attempt " + attempt +
                    " (Attempt time: " + attemptDuration + "ms, Total time: " + totalDuration + "ms)");
                return response.body().getPrincipal_id();
            }

            Reporter.logJSON("Attempt " + attempt + " failed after " + attemptDuration + "ms: Account not found from WIAP",
                response.body() != null ? response.body().toString() : "null response");

            if (attempt == MAX_RETRIES) {
                long totalDuration = System.currentTimeMillis() - startTime;
                throw new RuntimeException(
                    "WIAP Account fetching failed after " + MAX_RETRIES + " attempts and " + totalDuration + "ms. HttpStatusCode: " + response.code()
                );
            }

            Reporter.log("Waiting " + RETRY_DELAY_MS[attempt - 1] + "ms before retry " + (attempt + 1));
            Thread.sleep(RETRY_DELAY_MS[attempt - 1]);
        }

        long totalDuration = System.currentTimeMillis() - startTime;
        throw new RuntimeException("Failed to retrieve principal_id from WIAP after " + totalDuration + "ms");
    }

    public static String createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(String email) throws Exception {
        String randomFirstName = RandomStringUtils.randomAlphabetic(5);
        String randomLastName = RandomStringUtils.randomAlphabetic(5);
        return createDotComAccountAndGetCidOfAstroFromWIAP(
                email,
                commonPassword,
                commonPhoneNo,
                randomFirstName,
                randomLastName,
                null);

    }

    public static String createGuestAccountWithWCPWithRandomName(String dateOfBirth) throws Exception {
        String randomFirstName = RandomStringUtils.randomAlphabetic(5);
        String randomLastName = RandomStringUtils.randomAlphabetic(5);
        return createGuestAccountWithWCP(
                randomFirstName,
                randomLastName,
                dateOfBirth);
    }

    public static String createGuestAccountWithWCP(String firstName, String lastName, String dateOfBirth) throws Exception {
        long startTime = System.currentTimeMillis();
        Reporter.log("Starting createGuestAccountWithWCP for: " + firstName + " " + lastName);


        WCPCreateGuestAccountRequest request = WCPCreateGuestAccountRequest.builder()
                .payload(WCPCreateGuestAccountRequest.Payload.builder()
                        .account(WCPCreateGuestAccountRequest.Account.builder()
                                .accountType(AccountType.GUEST.name())
                                .customerType("INDIVIDUAL")
                                .firstName(firstName)
                                .lastName(lastName)
                                .dateOfBirth(dateOfBirth)
                                .build())
                        .build())
                .build();

        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            long attemptStartTime = System.currentTimeMillis();

            Response<WCPCreateGuestAccountResponse> response = wcpRetroFit.createGuestAccount(request);

            long attemptDuration = System.currentTimeMillis() - attemptStartTime;

            if (response.isSuccessful() && response.body() != null &&
                response.body().getPayload() != null &&
                response.body().getPayload().getCustomerAccountId() != null) {
                long totalDuration = System.currentTimeMillis() - startTime;
                String cid = response.body().getPayload().getCustomerAccountId();
                Reporter.log("Successfully retrieved customerAccountId in attempt " + attempt +
                        " (Attempt time: " + attemptDuration + "ms, Total time: " + totalDuration + "ms): " + cid);
                return cid;
            }

            Reporter.logJSON("Attempt " + attempt + " failed after " + attemptDuration + "ms: Guest account creation failed",
                    response.body() != null ? response.body().toString() : "null response");

            if (attempt == MAX_RETRIES) {
                long totalDuration = System.currentTimeMillis() - startTime;
                throw new RuntimeException(
                        "WCP Guest Account creation failed after " + MAX_RETRIES + " attempts and " + totalDuration + "ms. HttpStatusCode: " + response.code()
                );
            }

            Reporter.log("Waiting " + RETRY_DELAY_MS[attempt - 1] + "ms before retry " + (attempt + 1));
            Thread.sleep(RETRY_DELAY_MS[attempt - 1]);
        }

        long totalDuration = System.currentTimeMillis() - startTime;
        throw new RuntimeException("Failed to retrieve customerAccountId from WCP after " + totalDuration + "ms");
    }

    public static String getPreferenceIdByEmail(String email) throws Exception {
        return digitalPharmacyAPIManager.getPreferenceMethodIdFromAstroAccount(email);
    }

    /**
     * Creates a Walmart Plus membership for the given email using the Astro API.
     * This is a simpler alternative to the nxtgn membership core service —
     * it only requires the dotcom email address (no paymentPreferenceId needed).
     *
     * @param email the dotcom account email address
     */
    public static void addWalmartPlusMembershipViaAstro(String email) {
        digitalPharmacyAPIManager.addWalmartPlusMembershipViaAstro(email);
    }

    /**
     * Builds WCP add dependent request
     *
     * @param type
     * @return
     */
    public static WCPAddDependentRequest getWCPAddDependentRequest(DependentInfo.TypeEnum type,
                                                                   DependentInfo.LinkageStatusEnum status,
                                                                   String dependentAccountId,
                                                                   String caregiverAccountId){
        return WCPAddDependentRequest.builder().payload(
                        WCPAddDependentRequest.Payload.builder()
                                .dependent(
                                        WCPAddDependentRequest.Dependent.builder()
                                                .groupType(GroupType.FAM.name())
                                                .memberId(
                                                        WCPAddDependentRequest.Identifier.builder()
                                                                .id(dependentAccountId)
                                                                .build())
                                                .membershipStatus(String.valueOf(status))
                                                .memberType(String.valueOf(type))
                                                .ownerId(
                                                        WCPAddDependentRequest.Identifier.builder()
                                                                .id(caregiverAccountId)
                                                                .build())
                                                .build())
                                .build())
                .build();
    }
}
