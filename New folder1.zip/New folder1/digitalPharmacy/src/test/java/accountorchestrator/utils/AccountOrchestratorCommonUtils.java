package accountorchestrator.utils;

import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;

public class AccountOrchestratorCommonUtils {

    /**
     * Creates Astro account using email id and customerType
     *
     * @param customerEmailId
     * @return
     */

    public static String astroCreatePerson(String customerEmailId) {
        DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String phoneNumber = "" + ((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        digitalPharmacyAPIManager.createDotComAccount(customerEmailId, "Test@1234", phoneNumber, RandomStringUtils.random(5, true, false), RandomStringUtils.random(5, true, false));
        return digitalPharmacyAPIManager.getCidFromEmailUsingAstro(customerEmailId);
    }

    /**
     * Builds WCP add dependent request
     *
     * @param type
     * @return WCPAddDependentRequest
     */
    public static WCPAddDependentRequest getWCPAddDependentRequest(DependentInfo.TypeEnum type,
                                                                   DependentInfo.LinkageStatusEnum status,
                                                                   String dependentAccountId,
                                                                   String caregiverAccountId){
        return WCPAddDependentRequest.builder().payload(
                        WCPAddDependentRequest.Payload.builder()
                                .dependent(
                                        WCPAddDependentRequest.Dependent.builder()
                                                .groupType(GroupType.FAM.name())
                                                .memberId(
                                                        WCPAddDependentRequest.Identifier.builder()
                                                                .id(dependentAccountId)
                                                                .build())
                                                .membershipStatus(String.valueOf(status))
                                                .memberType(String.valueOf(type))
                                                .ownerId(
                                                        WCPAddDependentRequest.Identifier.builder()
                                                                .id(caregiverAccountId)
                                                                .build())
                                                .build())
                                .build())
                .build();
    }

    /**
     * Create Astro account for caregiver using email id
     *
     * @return
     */
    public static String astroCreatePersonForCaregiver(String caregiverCustomerEmailId) {
        DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String phoneNumber = "" + ((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        digitalPharmacyAPIManager.createDotComAccount(caregiverCustomerEmailId, "Test@1234", phoneNumber, RandomStringUtils.random(5, true, false), RandomStringUtils.random(5, true, false));
        return  digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverCustomerEmailId);
    }
}
