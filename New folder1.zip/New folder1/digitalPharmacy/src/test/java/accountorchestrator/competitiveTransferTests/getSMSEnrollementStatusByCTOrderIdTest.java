package accountorchestrator.competitiveTransferTests;

import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.GetSMSEnrollementStatusByCTOrderIdErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.GetSMSEnrollementStatusByCTOrderIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.errors.AccountOrchServiceErrorMessage;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.SubmitCTOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTBuyerInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTTestInputInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;


public class getSMSEnrollementStatusByCTOrderIdTest {

    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();
    CTBuyerInfo buyerInfo;
    String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/competitiveTransfersData.json";
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();

    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api response for Enrolled patient")
    public void Test1_getSMSEnrollementStatusByCTOrdr_Enrolled(Method method) throws InterruptedException {

        //Step 1: Creating CT order and extracting orderId
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();

        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);

        //Step 2: Calling getSMSEnrollementStatusByCTOrderId api
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdResponse getSMSEnrollementStatusByCTOrderIdResponse = serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdResponse.class);

        //Step 3: Validating response
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdResponse.getPayload().getPhone().getCompleteNumber(), buyerInfo.getBuyerPhone());
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdResponse.getPayload().getSmsEnrollmentStatus(), "ENROLLED");
    }

    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api response for Unenrolled patient")
    public void Test2_getSMSEnrollementStatusByCTOrdr_NotEnrolled(Method method) {

        //Step 1: Creating CT order and extracting orderId
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);

        String rxOwnerCid = buyerInfo.getBuyerCid();

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);

        //Step 2: Calling getSMSEnrollementStatusByCTOrderId api
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdResponse getSMSEnrollementStatusByCTOrderIdResponse = serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdResponse.class);

        //Step 3: Validating response
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdResponse.getPayload().getSmsEnrollmentStatus(), "NOT_ENROLLED");
    }

    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api response for Multi patient")
    public void Test3_getSMSEnrollementStatusByCTOrdr_MultiPatient(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);

        // First Profile
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId1 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);
        ServiceResponse rxMessagingResponse1 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId1));
        Assert.assertEquals(rxMessagingResponse1.getStatusCode(), HttpStatus.OK_200);

        // Second Profile
        String secondBuyerFirstName = CommonUtil.generateRandomFirstName(9);
        String secondBuyerLastName = buyerInfo.getBuyerLN();
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), secondBuyerFirstName, secondBuyerLastName, "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId2 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(secondBuyerFirstName, secondBuyerLastName, dates.get(1), storeId);
        ServiceResponse rxMessagingResponse2 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId2));
        Assert.assertEquals(rxMessagingResponse2.getStatusCode(), HttpStatus.OK_200);

        // Create CT order and pharmacy account for first profile
        String rxOwnerCid = buyerInfo.getBuyerCid();
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);

        //Step 2: Calling getSMSEnrollementStatusByCTOrderId api
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdResponse getSMSEnrollementStatusByCTOrderIdResponse = serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdResponse.class);

        //Step 3: Validating response
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdResponse.getPayload().getPhone().getCompleteNumber(), buyerInfo.getBuyerPhone());
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdResponse.getPayload().getSmsEnrollmentStatus(), "MULTI_PATIENT");
    }


    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api response for mismatching cid and orderId")
    public void Test4_getSMSEnrollementStatusByCTOrdr_InvalidCIDandOrderId(Method method) throws InterruptedException {

        //Step 1: Creating CT order and extracting orderId
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String orderId = testInputDetails.get("orderId").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        String CID = testInputDetails.get("rxOwnerCid").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();

        //Step 1: Calling getSMSEnrollementStatusByCTOrderId api for invalid orderId
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdErrorResponse getSMSEnrollementStatusByCTOrderIdErrorResponse = serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdErrorResponse.class);

        //Step 2: Validating response
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getCode(), AccountOrchServiceErrorMessage.SMS_ENROLLMENT_ERROR_CODE.getErrorMessage());
        Assert.assertTrue(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getMessage().contains(AccountOrchServiceErrorMessage.INCORRECT_CID_OR_ORDER_ID.getErrorMessage()));
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getAction(), AccountOrchServiceErrorMessage.CORRECT_REQUEST_PAYLOAD_ERROR.getErrorMessage());

        //Step 1: Calling getSMSEnrollementStatusByCTOrderId api for invalid CID as well as orderId
        serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(CID, orderId);
        getSMSEnrollementStatusByCTOrderIdErrorResponse = serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdErrorResponse.class);

        //Step 2: Validating response
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getCode(), AccountOrchServiceErrorMessage.SMS_ENROLLMENT_ERROR_CODE.getErrorMessage());
        Assert.assertTrue(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getMessage().contains(AccountOrchServiceErrorMessage.INCORRECT_CID_OR_ORDER_ID.getErrorMessage()));
        Assert.assertEquals(getSMSEnrollementStatusByCTOrderIdErrorResponse.getError().getAction(), AccountOrchServiceErrorMessage.CORRECT_REQUEST_PAYLOAD_ERROR.getErrorMessage());
    }

    /**
     * Validates that an invalid (unsupported) domainId in the URL returns HTTP 400.
     * The controller validates domainId against the CCM-configured valid domain list before
     * invoking the service. This bypasses the wrapper (which hardcodes WM-PHARMACY) by building
     * the URL directly with a dynamically generated CID and a random non-empty orderId.
     */
    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api returns 400 for an unsupported domainId")
    public void Test5_getSMSEnrollementStatusByCTOrdr_InvalidDomainId_Returns400() {
        PropertyReader prop = PropertyReader.getInstance();

        // Build URL directly substituting an invalid domain — wrapper hardcodes WM-PHARMACY so direct call is required
        String cid = UUID.randomUUID().toString();
        String orderId = UUID.randomUUID().toString();
        String url = prop.getProperty("dp.account.orchestrator.base.url")
                + "/v1/customer/" + cid
                + "/domain/INVALID-DOMAIN"
                + "/competitive-transfer/" + orderId
                + "/sms-enrolled-status";

        // Replicate QA headers used by the wrapper's getHeadersQA()
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.orchestrator.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.orchestrator.service.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("dp.account.orchestrator.service.env"));

        ServiceRequest req = new ServiceRequest();
        req.setUrl(url);
        req.setHeaders(headers);
        Reporter.log("Request endpoint : " + req.getUrl());

        //Step 1: Calling getSMSEnrollementStatusByCTOrderId api with invalid domainId
        ServiceResponse serRes = AutomationManager.getInstance().getRestContext().performGet(req);
        Reporter.logJSON("HTTP Response : ", serRes.getDataResponse());

        //Step 2: Validating response — controller rejects unsupported domain before reaching service
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400,
                "Expected HTTP 400 when domainId is not in the valid domain list");
        GetSMSEnrollementStatusByCTOrderIdErrorResponse errorResponse =
                serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdErrorResponse.class);
        Assert.assertNotNull(errorResponse.getError(),
                "Error object should be present in 400 response for invalid domainId");
    }

    /**
     * Validates that when a patient is enrolled for SMS but their lastName in DM
     * does not match the CT order's patientInfo.lastName, the response is NOT_ENROLLED with
     * no phone field (null).
     *
     * Service filter: StringUtils.equalsIgnoreCase(ctOrderLastName, profile.getCustomerInfo().getLastName())
     * → mismatch → filteredProfiles empty → NOT_ENROLLED, phone absent (@JsonInclude NON_NULL).
     */
    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api returns NOT_ENROLLED when enrolled patient lastName differs from CT order patientInfo")
    public void Test6_getSMSEnrollementStatusByCTOrdr_NotEnrolled_LastNameMismatch() throws InterruptedException {
        // Dynamic test data — no JSON read needed; reuse existing store/DOB used by Test1
        String dateOfBirth = "12121992";
        String storeId = "5548";

        //Step 1: Create buyer Dotcom account — buyer's lastName will appear in the CT order
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(dateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(dateOfBirth);

        // Create CPR patient with buyer's firstName but a randomly generated lastName (≠ buyer's lastName)
        // When service fetches DM profiles and filters by CT order's lastName (buyer's), this patient won't match
        String mismatchLastName = CommonUtil.generateRandomLastName(8);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId),
                buyerInfo.getBuyerFN(), mismatchLastName, "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                buyerInfo.getBuyerFN(), mismatchLastName, dates.get(1), storeId);

        // Enroll the differently-named patient for SMS at buyer's phone number
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(
                buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200,
                "SMS enrollment (rxMessaging) should succeed for mismatch-lastName patient");

        //Step 2: Submit CT order for buyer — CT order patientInfo.lastName = buyerInfo.getBuyerLN() ≠ mismatchLastName
        String rxOwnerCid = buyerInfo.getBuyerCid();
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, "Test1_getSMSEnrollementStatusByCTOrdr_Enrolled", rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);

        //Step 3: Calling getSMSEnrollementStatusByCTOrderId api
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdResponse response =
                serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdResponse.class);

        //Step 4: Validating response — lastName filter eliminates the enrolled profile → NOT_ENROLLED, phone null
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(response.getPayload().getSmsEnrollmentStatus(), "NOT_ENROLLED",
                "Expected NOT_ENROLLED when enrolled patient lastName (" + mismatchLastName + ") differs from CT order lastName (" + buyerInfo.getBuyerLN() + ")");
        Assert.assertNull(response.getPayload().getPhone(),
                "Phone field should be null/absent in NOT_ENROLLED response");
    }

    /**
     * Validates that when a patient is enrolled for SMS and their lastName
     * matches the CT order but their DOB does not, the response is NOT_ENROLLED with no phone field.
     *
     * Service filter chain: lastName matches ✓ → DOB mismatch ✗ → filteredProfiles empty → NOT_ENROLLED.
     * This exercises the DOB filter independently from the lastName filter.
     */
    @Test(description = "Validate getSMSEnrollementStatusByCTOrdr api returns NOT_ENROLLED when enrolled patient DOB differs from CT order patientInfo")
    public void Test7_getSMSEnrollementStatusByCTOrdr_NotEnrolled_DobMismatch() throws InterruptedException {
        // Buyer DOB used in CT order vs a distinct adult DOB for the enrolled CPR patient
        String buyerDateOfBirth = "12121992";   // CT order patientInfo.dob → "12121992"
        String patientDateOfBirth = "03031985"; // enrolled patient's DOB (different from CT order DOB)
        String storeId = "5548";

        //Step 1: Create buyer Dotcom account — buyer's DOB and name will appear in CT order
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(buyerDateOfBirth);

        // Get timestamps for the CPR patient's distinct DOB
        List<String> patientDates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(patientDateOfBirth);

        // Create CPR patient with buyer's exact full name but a different adult DOB
        // lastName filter will pass (same name), but DOB filter will reject → NOT_ENROLLED
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId),
                buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(),
                "/Date(" + patientDates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(
                buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), patientDates.get(1), storeId);

        // Enroll the different-DOB patient for SMS at buyer's phone number
        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(
                buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200,
                "SMS enrollment (rxMessaging) should succeed for different-DOB patient");

        //Step 2: Submit CT order for buyer — CT order patientInfo.dob = "12121992" ≠ patientDateOfBirth
        String rxOwnerCid = buyerInfo.getBuyerCid();
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, "Test1_getSMSEnrollementStatusByCTOrdr_Enrolled", rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);

        //Step 3: Calling getSMSEnrollementStatusByCTOrderId api
        ServiceResponse serRes = competitiveTransferWrapper.getSMSEnrollementStatusByCTOrderId(rxOwnerCid, orderId);
        GetSMSEnrollementStatusByCTOrderIdResponse response =
                serRes.getDataResponse(GetSMSEnrollementStatusByCTOrderIdResponse.class);

        //Step 4: Validating response — DOB filter eliminates the enrolled profile → NOT_ENROLLED, phone null
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(response.getPayload().getSmsEnrollmentStatus(), "NOT_ENROLLED",
                "Expected NOT_ENROLLED when enrolled patient DOB (" + patientDateOfBirth + ") differs from CT order DOB (" + buyerDateOfBirth + ")");
        Assert.assertNull(response.getPayload().getPhone(),
                "Phone field should be null/absent in NOT_ENROLLED response");
    }
}







