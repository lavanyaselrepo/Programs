package accountorchestrator.competitiveTransferTests;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.errors.AccountOrchServiceErrorMessage;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.SubmitCTOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTBuyerInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTTestInputInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.List;

public class CreateAccountUsingCTOrderIdTest {

    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();

    CTBuyerInfo buyerInfo;
    String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/competitiveTransfersData.json";

    @Test(description = "Create buyer pharmacy account using CT orderId and verify pharmacy connection status should be ACTIVE")
    public void createAccountUsingCTOrderIdTest(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();;

        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("payload.customerAccountId"), rxOwnerCid);

        ServiceResponse pharmacyProfileStatusRes = competitiveTransferWrapper.checkPharmacyAccountStatus(storeId, Integer.toString(patientId));
        Assert.assertEquals(pharmacyProfileStatusRes.getJsonElement("payload.account.status"), "ACTIVE");
        Assert.assertEquals(pharmacyProfileStatusRes.getJsonElement("payload.customerInfo.emailId"), buyerInfo.getBuyerEmailId());
    }

    @Test(description = "Create buyer pharmacy account using incorrect CT orderId")
    public void createAccountUsingIncorrectCTOrderIdTest(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();;

        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);
        String orderId = testInputDetails.get("orderId").toString();
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertTrue(createAccountResponse.getJsonElement("error.message").toString().contains(AccountOrchServiceErrorMessage.INCORRECT_CID_OR_ORDER_ID.getErrorMessage()));
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CORRECT_REQUEST_PAYLOAD_ERROR.getErrorMessage());
    }

    @Test(description = "Create buyer pharmacy account using unenrolled phone number")
    public void createAccountUsingUnenrolledPhoneNumber(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();;
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"), AccountOrchServiceErrorMessage.NO_ENROLLED_PROFILE_FOUND.getErrorMessage() + orderId);
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CONTACT_ACCOUNT_REVAMP_TEAM.getErrorMessage());
    }

    @Test(description = "Create buyer pharmacy account using incorrect customerAccountId and orderId")
    public void createAccountWithIncorrectCustomerIdAndOrderId(Method method) {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String phoneNumber = testInputDetails.get("patPhone").toString();
        String orderId = testInputDetails.get("orderId").toString();
        String rxOwnerCid = testInputDetails.get("rxOwnerCid").toString();
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", phoneNumber);
        Assert.assertTrue(createAccountResponse.getJsonElement("error.message").toString().contains(AccountOrchServiceErrorMessage.INCORRECT_CID_OR_ORDER_ID.getErrorMessage()));
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CORRECT_REQUEST_PAYLOAD_ERROR.getErrorMessage());
    }

    @Test(description = "Create pharmacy account for buyer who is already pharmacy connected")
    public void createAccountForPharmacyConnectedAccount(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        String patPassword = testInputDetails.get("password").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);
        String rxOwnerCid = buyerInfo.getBuyerCid();;

        digitalPharmacyAPIManager.createPharmacyAccount_DPStg(rxOwnerCid, patientId + "", DateOfBirth, storeId);
        digitalPharmacyOperationsUtil.enableTestAccountInQa(rxOwnerCid, storeId, patientId + "", DateOfBirth);
        System.out.println("Created Account: " + buyerInfo.getBuyerEmailId() + ", Password: " + patPassword + ", Patient Name: " + buyerInfo.getBuyerFN() +
                ", PatientLastName: " + buyerInfo.getBuyerLN());

        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"), AccountOrchServiceErrorMessage.ONLINE_ACCOUNT_ALREADY_EXISTS.getErrorMessage());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CONTACT_ACCOUNT_TEAM_ERROR.getErrorMessage());
    }

    @Test(description = "Create pharmacy account with phone Nbr which is different from the phone Nbr registered on the CT Order.")
    public void createAccountWithUnregisteredPhoneNumber(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);

        String rxOwnerCid = buyerInfo.getBuyerCid();;

        ServiceResponse rxMessagingResponse = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId));
        Assert.assertEquals(rxMessagingResponse.getStatusCode(), HttpStatus.OK_200);

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", testInputDetails.get("patPhone").toString());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"),
                AccountOrchServiceErrorMessage.PHONE_NUMBER_NOT_REGISTERED_FOR_CT_ORDER.getErrorMessage() + testInputDetails.get("patPhone").toString());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CORRECT_REQUEST_PAYLOAD_ERROR.getErrorMessage());
    }

    @Test(description = "Create pharmacy account with phone Nbr for which 0 or multiple profiles Enrolled in DM ")
    /* 1. Create 2 patients with same last name and DOB.
     * 2. Enroll both patients with same phone number and create order
     * 3. Trigger create account api
     */
    public void createAccountWithMultipleProfilesEnrolledInDM(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirth);

        // First Profile
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId1 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), buyerInfo.getBuyerLN(), dates.get(1), storeId);
        ServiceResponse rxMessagingResponse1 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId1));
        Assert.assertEquals(rxMessagingResponse1.getStatusCode(), HttpStatus.OK_200);

        // Second Profile
        String secondBuyerFirstName = CommonUtil.generateRandomFirstName(9);
        String secondBuyerLastName = buyerInfo.getBuyerLN();
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), secondBuyerFirstName, secondBuyerLastName, "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId2 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(secondBuyerFirstName, secondBuyerLastName, dates.get(1), storeId);
        ServiceResponse rxMessagingResponse2 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId2));
        Assert.assertEquals(rxMessagingResponse2.getStatusCode(), HttpStatus.OK_200);

        // Create CT order and pharmacy account for first profile
        String rxOwnerCid = buyerInfo.getBuyerCid();;
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"), AccountOrchServiceErrorMessage.MULTIPLE_ENROLLED_PROFILES_FOUND.getErrorMessage() + orderId);
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CONTACT_ACCOUNT_REVAMP_TEAM.getErrorMessage());
    }

    @Test(description = "Create pharmacy account for a patient for which profile is missing")
    public void createAccountWhenPatientStoreProfileIsMissing(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());
        String DateOfBirth = testInputDetails.get("patDOB").toString();
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirth);
        String rxOwnerCid = buyerInfo.getBuyerCid();;

        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"), AccountOrchServiceErrorMessage.NO_ENROLLED_PROFILE_FOUND.getErrorMessage() + orderId);
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CONTACT_ACCOUNT_REVAMP_TEAM.getErrorMessage());
    }

    @Test(description = "Check account creation failure in case of patient mismatch")
    /* 1. Create 2 patients in connexus (same first name, different last name and DOB).
       2. Enroll both patients with same phone number
       3. Place CT order with unique lastName and DOB
       4. Trigger create account endpoint and verify error message */
    public void ctOrderFailureInCaseOfPatientMismatch(Method method) throws InterruptedException {
        JSONObject testInputDetails = new CommonUtils().getJsonTestData(jsonPath, method.getName());

        // First Profile
        String DateOfBirthFirstPatientStoreDOB = testInputDetails.get("firstPatStoreProfileDOB").toString();
        String storeId = testInputDetails.get("storeNumber").toString();
        List<String> dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirthFirstPatientStoreDOB);
        buyerInfo = competitiveTransferWrapper.createDotcomAccount(DateOfBirthFirstPatientStoreDOB);
        String firstBuyerLastName = CommonUtil.generateRandomLastName(8);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), firstBuyerLastName, "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId1 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), firstBuyerLastName, dates.get(1), storeId);
        ServiceResponse rxMessagingResponse1 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId1));
        Assert.assertEquals(rxMessagingResponse1.getStatusCode(), HttpStatus.OK_200);

        // Second Profile
        String DateOfBirthSecondPatientStoreDOB = testInputDetails.get("secondPatStoreProfileDOB").toString();
        dates = digitalPharmacyOperationsUtil.dateTimeFormatterUtil(DateOfBirthSecondPatientStoreDOB);
        String secondBuyerLastName = CommonUtil.generateRandomLastName(8);
        digitalPharmacyOperationsUtil.generatePatient(Integer.parseInt(storeId), buyerInfo.getBuyerFN(), secondBuyerLastName, "/Date(" + dates.get(0) + ")/", false, "M", false);
        Thread.sleep(10000);
        int patientId2 = digitalPharmacyAPIManager.getStorePatientIdFromCPR(buyerInfo.getBuyerFN(), secondBuyerLastName, dates.get(1), storeId);
        ServiceResponse rxMessagingResponse2 = digitalPharmacyOperationsUtil.rxMessaging(buyerInfo.getBuyerPhone(), storeId, String.valueOf(patientId2));
        Assert.assertEquals(rxMessagingResponse2.getStatusCode(), HttpStatus.OK_200);

        // Create CT order and pharmacy account for first profile
        String rxOwnerCid = buyerInfo.getBuyerCid();;
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), rxOwnerCid, buyerInfo);
        Reporter.logJSON("Input Data:", inputData);
        SubmitCTOrderResponse submitCTOrderResponse = competitiveTransferWrapper.submitCTOrderRequest(inputData, HttpStatus.CREATED_201);
        String orderId = submitCTOrderResponse.getOrderId();
        System.out.println("OrderId - " + orderId);
        ServiceResponse createAccountResponse = competitiveTransferWrapper.createAccountUsingCTOrderId(rxOwnerCid, orderId, "EN", buyerInfo.getBuyerPhone());
        Assert.assertEquals(createAccountResponse.getJsonElement("error.message"), AccountOrchServiceErrorMessage.NO_ENROLLED_PROFILE_FOUND.getErrorMessage() + orderId);
        Assert.assertEquals(createAccountResponse.getJsonElement("error.action"), AccountOrchServiceErrorMessage.CONTACT_ACCOUNT_REVAMP_TEAM.getErrorMessage());
    }
}
