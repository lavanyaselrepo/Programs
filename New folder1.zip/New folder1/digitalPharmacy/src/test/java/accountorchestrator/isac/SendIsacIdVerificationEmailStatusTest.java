package accountorchestrator.isac;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.SendIsacIdVerificationEmailV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil.logFlowIdentifiers;

public class SendIsacIdVerificationEmailStatusTest {
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private Gson gson;
  private String stageId = null;
  private IsacHelper isacHelper;
  private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
  ValidationServiceRequest adultHumanCprPatientRequest,
          minorHumanCprPatientRequest,
          adult2HumanCprPatientRequest;
  Integer cprAdultHumanPatientId = 0, cprMinorHumanPatientId = 0;
  private String storeNbr;
  private String customerAccountId;
  private ObjectMapper mapper = new ObjectMapper();
  List<Integer> patientIds = new ArrayList<>();
  private String emailId=null;

  @BeforeClass
  void setContext() throws IOException {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    gson = new Gson();
    storeNbr = CommonUtil.generateRandomNumber(6);
    isacHelper = new IsacHelper();

    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);

    patientIds = isacHelper.createAllCprAccounts(
            adultHumanCprPatientRequest,
            minorHumanCprPatientRequest,
            adult2HumanCprPatientRequest,
            storeNbr);

    cprAdultHumanPatientId = patientIds.get(0);
    cprMinorHumanPatientId = patientIds.get(1);
    emailId = CommonUtil.generateRandomEmailId(10);
    customerAccountId = isacHelper.astroCreatePerson(digitalPharmacyAPIManager, emailId);
  }

  @Test(priority = 0, description = "null storeNbr for SendIsacIdVerificationEmailV1")
  public void nullStoreNbrIdSendIsacIdVerificationEmailV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .patientId("12345")
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    String errorResponse = CommonUtil.buildErrorMessage(gson, sendIsacIdVerificationEmailV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "Error response: \n" +
            "Code: DPR-DPACCOR-1001\n" +
            "Message: Invalid input request. Store Number can not be null/empty\n", errorResponse);
  }

  @Test(priority = 1, description = "null patientId for SendIsacIdVerificationEmailV1")
  public void nullPatientIdSendIsacIdVerificationEmailV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .storeNbr("5597")
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    String errorResponse = CommonUtil.buildErrorMessage(gson, sendIsacIdVerificationEmailV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "Error response: \n" +
            "Code: DPR-DPACCOR-1001\n" +
            "Message: Invalid input request. Patient Id can not be null/empty\n", errorResponse);
  }

  @Test(priority = 2, description = "invalid CPR response for SendIsacIdVerificationEmailV1")
  public void invalidCPRResponseSendIsacIdVerificationEmailV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .storeNbr("5597")
                    .patientId("12")
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    String errorResponse = CommonUtil.buildErrorMessage(gson, sendIsacIdVerificationEmailV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "Error response: \n" +
            "Code: DPR-DPACCOR-6001\n" +
            "Message: No information found for given input request in CPR. {}\n", errorResponse);
  }

  @Test(priority = 3, description = "minor/pet not allowed for SendIsacIdVerificationEmailV1")
  public void petOrMinorSendIsacIdVerificationEmailV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .patientId(String.valueOf(cprMinorHumanPatientId))
                    .storeNbr(storeNbr)
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    String errorResponse = CommonUtil.buildErrorMessage(gson, sendIsacIdVerificationEmailV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "Error response: \n" +
            "Code: DPR-DPACCOR-1044\n" +
            "Message: MINOR/PET is not allowed to create account.\n", errorResponse);
  }

  @Test(priority = 4, description = "no content error from get isac status")
  public void noContentSendIsacIdVerificationEmail1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .patientId(String.valueOf(cprAdultHumanPatientId))
                    .storeNbr(storeNbr)
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(204, sendIsacIdVerificationEmailV1Response.code());
  }

  @Test(priority = 5, description = "SendIsacIdVerificationEmailV1")
  public void SendIsacIdVerificationEmailV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    stageId = isacHelper.saveIsacIdVerification(
            storeNbr,
            cprAdultHumanPatientId,
            emailId,
            reqIdString,
            reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .patientId(String.valueOf(cprAdultHumanPatientId))
                    .storeNbr(storeNbr)
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<Void> sendIsacIdVerificationEmailV1VoidResponse =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1Void(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(200, sendIsacIdVerificationEmailV1VoidResponse.code());
  }

  @Test(priority = 6, description = "pharmacy profile exist error for SendIsacIdVerificationEmailV1")
  public void pharmacyProfileExistSendIsacIdVerificationEmailV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    isacHelper.createPharmacyAccountEntity(
            accountEntityServiceRetrofit,
            customerAccountId,
            storeNbr,
            String.valueOf(cprAdultHumanPatientId),
            "12121977");

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the sendIsacIdVerificationEmailV1 request
    SendIsacIdVerificationEmailV1Request sendIsacIdVerificationEmailV1Request =
            SendIsacIdVerificationEmailV1Request.builder()
                    .patientId(String.valueOf(cprAdultHumanPatientId))
                    .storeNbr(storeNbr)
                    .build();

    // Step - 3: Calling Send Isac Id Verification Email V1
    Response<ServiceResponse> sendIsacIdVerificationEmailV1Response =
            accountOrchestratorRetrofit.sendIsacIdVerificationEmailV1(
                    domainId, sendIsacIdVerificationEmailV1Request, reqId, reqTrackingId);

    // Step - 4: Asserting response
    String errorResponse = CommonUtil.buildErrorMessage(gson, sendIsacIdVerificationEmailV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "Error response: \n" +
            "Code: DPR-DPACCOR-1048\n" +
            "Message: Pharmacy Account already exists. " + customerAccountId + "\n", errorResponse);
  }

  @AfterClass
  void cleanUp() {
    // cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
    // delete CPR account
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);

    Arrays.asList(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
            .forEach(
                    request -> {
                      request.getPatientInfo().setPatientStatusCode(20708);
                      try {
                        deleteCprAccount(request);
                      } catch (IOException e) {
                      }
                    });
  }

  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response =
            cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() == 202
            && response.body() != null
            && response.body().getErrors().isEmpty()) {
    } else {
      Reporter.logJSON("errorMessage",
              String.format("CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                      cprRequest.getPatientId(),response.code()));
    }
  }
}
