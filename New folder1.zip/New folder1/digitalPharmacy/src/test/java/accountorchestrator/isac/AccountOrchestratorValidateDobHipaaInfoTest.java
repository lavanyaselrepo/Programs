package accountorchestrator.isac;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateStageISACRecordV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.isac.ValidateDobHipaaInfoV1Response;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.ValidateDobHipaaInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class AccountOrchestratorValidateDobHipaaInfoTest {

    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private Gson gson;
    private IsacHelper isacHelper;
    private String adult1StageId = null;
    private String adult3StageId;

    private String correctDob;
    private String cprBirthDate;
    private String wrongDob;

    private String adult1StoreNbr;
    private Integer cprAdult1HumanPatientId;
    private String adult1EmailId;
    private String adult1CustomerAccountId;
    private ValidationServiceRequest adult1CprRequest;

    private String adult2StoreNbr;
    private Integer cprAdult2HumanPatientId;
    private String adult2EmailId;
    private String adult2CustomerAccountId;
    private ValidationServiceRequest adult2CprRequest;

    private String adult3StoreNbr;
    private Integer cprAdult3HumanPatientId;
    private String adult3EmailId;
    private String adult3CustomerAccountId;
    private ValidationServiceRequest adult3CprRequest;

    private String adult4StoreNbr;
    private Integer cprAdult4HumanPatientId;
    private String adult4EmailId;
    private String adult4CustomerAccountId;
    private ValidationServiceRequest adult4CprRequest;

    private String adult5StoreNbr;
    private Integer cprAdult5HumanPatientId;
    private String adult5EmailId;
    private String adult5CustomerAccountId;
    private ValidationServiceRequest adult5CprRequest;

    private String adult6StoreNbr;
    private Integer cprAdult6HumanPatientId;
    private String adult6EmailId;
    private ValidationServiceRequest adult6CprRequest;

    private ObjectMapper mapper = new ObjectMapper();

    // Error codes
    private final String dobMismatchErrorCode = "DPR-DPACCOR-1009";
    private final String cooldownErrorCode = "DPR-DPACCOR-3001";

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        gson = new Gson();
        isacHelper = new IsacHelper();

        // ── Generate unique store numbers for each adult ─────────────────
        adult1StoreNbr = CommonUtil.generateRandomNumber(6);
        adult2StoreNbr = CommonUtil.generateRandomNumber(6);
        adult3StoreNbr = CommonUtil.generateRandomNumber(6);
        adult4StoreNbr = CommonUtil.generateRandomNumber(6);
        adult5StoreNbr = CommonUtil.generateRandomNumber(6);
        adult6StoreNbr = CommonUtil.generateRandomNumber(6);

        ThreadLocalRandom rng = ThreadLocalRandom.current();
        int randomMonth = rng.nextInt(12) + 1;
        int randomDay = rng.nextInt(28) + 1;
        int randomYear = LocalDate.now().getYear() - rng.nextInt(30) - 25;
        LocalDate baseDate = LocalDate.of(randomYear, randomMonth, randomDay);
        DateTimeFormatter mmddyyyy = DateTimeFormatter.ofPattern("MMddyyyy");
        DateTimeFormatter yyyyMmDd = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        correctDob = baseDate.format(mmddyyyy);
        cprBirthDate = baseDate.format(yyyyMmDd);

        int wrongMonthInt = (baseDate.getMonthValue() % 12) + 1;
        int wrongDayInt = (baseDate.getDayOfMonth() == 15) ? 14 : 15;
        wrongDob = LocalDate.of(baseDate.getYear() - 10, wrongMonthInt, wrongDayInt)
                .format(mmddyyyy);

        // ── Create CPR patient templates ──────────────────────────────────
        adult1CprRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult2CprRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult3CprRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult4CprRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult5CprRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult6CprRequest = SharedUtils.getTemplateCprRequest(mapper);

        adult1CprRequest.getPatientInfo().setBirthDate(cprBirthDate);
        adult2CprRequest.getPatientInfo().setBirthDate(cprBirthDate);
        adult3CprRequest.getPatientInfo().setBirthDate(cprBirthDate);
        adult4CprRequest.getPatientInfo().setBirthDate(cprBirthDate);
        adult5CprRequest.getPatientInfo().setBirthDate(cprBirthDate);
        adult6CprRequest.getPatientInfo().setBirthDate(cprBirthDate);

        adult1CprRequest.setStoreNbr(Integer.parseInt(adult1StoreNbr));
        adult2CprRequest.setStoreNbr(Integer.parseInt(adult2StoreNbr));
        adult3CprRequest.setStoreNbr(Integer.parseInt(adult3StoreNbr));
        adult4CprRequest.setStoreNbr(Integer.parseInt(adult4StoreNbr));
        adult5CprRequest.setStoreNbr(Integer.parseInt(adult5StoreNbr));
        adult6CprRequest.setStoreNbr(Integer.parseInt(adult6StoreNbr));

        adult1CprRequest.setPatientId(cprAdult1HumanPatientId);
        adult2CprRequest.setPatientId(cprAdult2HumanPatientId);
        adult3CprRequest.setPatientId(cprAdult3HumanPatientId);
        adult4CprRequest.setPatientId(cprAdult4HumanPatientId);
        adult5CprRequest.setPatientId(cprAdult5HumanPatientId);
        adult6CprRequest.setPatientId(cprAdult6HumanPatientId);

        // ── Create CPR accounts ─────────────────────────────────────────
        cprAdult1HumanPatientId = SharedUtils.createCprAccount(adult1CprRequest, cprPatientUpdateRetrofit);
        cprAdult2HumanPatientId = SharedUtils.createCprAccount(adult2CprRequest, cprPatientUpdateRetrofit);
        cprAdult3HumanPatientId = SharedUtils.createCprAccount(adult3CprRequest, cprPatientUpdateRetrofit);
        cprAdult4HumanPatientId = SharedUtils.createCprAccount(adult4CprRequest, cprPatientUpdateRetrofit);
        cprAdult5HumanPatientId = SharedUtils.createCprAccount(adult5CprRequest, cprPatientUpdateRetrofit);
        cprAdult6HumanPatientId = SharedUtils.createCprAccount(adult6CprRequest, cprPatientUpdateRetrofit);

        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        adult1EmailId = CommonUtil.generateRandomEmailId(10);
        adult2EmailId = CommonUtil.generateRandomEmailId(10);
        adult3EmailId = CommonUtil.generateRandomEmailId(10);
        adult4EmailId = CommonUtil.generateRandomEmailId(10);
        adult5EmailId = CommonUtil.generateRandomEmailId(10);
        adult6EmailId = CommonUtil.generateRandomEmailId(10);

        adult1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult1EmailId);
        adult2CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult2EmailId);
        adult3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult3EmailId);
        adult4CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult4EmailId);
        adult5CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(adult5EmailId);

        // Step 3: createStageIsacRecord to obtain stageId for adult1 (used by success + validation tests)
        adult1StageId = createStageIsacRecord(
                adult1StoreNbr,
                cprAdult1HumanPatientId,
                adult1EmailId, correctDob, Boolean.FALSE,
                reqIdString,
                reqTrackingString);

        adult3StageId = isacHelper.saveIsacIdVerification(
                adult3StoreNbr,
                cprAdult3HumanPatientId,
                adult3EmailId,
                reqIdString,
                reqTrackingString);
    }

    @Test(
            priority = 0,
            description = "validateDobHipaaInfo returns 200 when DOB matches CPR patient record - Success")
    public void validateDobHipaaInfoWithMatchingDobSuccess() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build the validateDobHipaaInfo request with matching DOB (MMddyyyy format)
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse response payload
        ValidateDobHipaaInfoV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) validateDobHipaaInfoV1Response.body().getPayload()),
                ValidateDobHipaaInfoV1Response.class);

        // Step 5: Assert HTTP 200 and payload fields
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 200,
                "Expected HTTP 200 but got: " + validateDobHipaaInfoV1Response.code());
        Assert.assertNotNull(validateDobHipaaInfoV1Response.body(),
                "Response body should not be null");
        Assert.assertNotNull(validateDobHipaaInfoV1Response.body().getPayload(),
                "Payload should not be null");

        // Assert patient identity fields
        Assert.assertNotNull(response.getFirstName(), "firstName should not be null");
        Assert.assertNotNull(response.getLastName(), "lastName should not be null");
        Assert.assertEquals(response.getDob(), correctDob,
                "DOB in response should match the submitted DOB");

        // Assert primary address info (addressTypeCode == 3)
        Assert.assertNotNull(response.getAddressInfo(), "addressInfo should not be null");
        Assert.assertFalse(response.getAddressInfo().isEmpty(), "addressInfo should not be empty");
        Assert.assertNotNull(response.getAddressInfo().get(0).getAddressLine1(),
                "Primary address line1 should not be null");
        Assert.assertNotNull(response.getAddressInfo().get(0).getType(),
                "Primary address type should not be null");

        // Assert primary communication info (commMethodCode == 3)
        Assert.assertNotNull(response.getCommunicationInfo(), "communicationInfo should not be null");
        Assert.assertFalse(response.getCommunicationInfo().isEmpty(),
                "communicationInfo should not be empty");
        Assert.assertNotNull(response.getCommunicationInfo().get(0).getCommunicationId(),
                "Primary communicationId should not be null");
        Assert.assertNotNull(response.getCommunicationInfo().get(0).getType(),
                "Primary communication type should not be null");

        Assert.assertNull(response.getCoolDownStatus(), "CoolDown status should be null");
    }

    @Test(
            priority = 1,
            description = "validateDobHipaaInfo throws IllegalArgumentException client-side when request body is null - "
                    + "Retrofit2 @Body annotation rejects null before making any HTTP call")
    public void validateDobHipaaInfoWithNullRequest() {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Assert that Retrofit2 throws IllegalArgumentException before making any HTTP call.
        //         Retrofit enforces non-null @Body parameters at the call site:
        //         "Body parameter value must not be null. (parameter #3)
        //          for method IsacControllerAPI.validateDobHipaaInfoV1"
        Assert.assertThrows(
                IllegalArgumentException.class,
                () -> accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        null,
                        reqId,
                        reqTrackingId));
    }


    @Test(
            priority = 2,
            description = "validateDobHipaaInfo returns 400 when dob is missing from request - Failure")
    public void validateDobHipaaInfoWithMissingDob() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with dob intentionally omitted (null)
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(null)
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and error code DPR-DPACCOR-1001 (INVALID_REQUEST_EXCEPTION)
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1001"),
                "Expected error code DPR-DPACCOR-1001 but got: " + errorMessage);
        Assert.assertTrue(
                errorResponse.getMessage().contains("DOB is required"),
                "Expected message to contain 'DOB is required' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 3,
            description = "validateDobHipaaInfo returns 400 when stageId is missing from request - Failure")
    public void validateDobHipaaInfoWithMissingStageId() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with stageId intentionally omitted (null)
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId(null)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and error code DPR-DPACCOR-1001 (INVALID_REQUEST_EXCEPTION)
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1001"),
                "Expected error code DPR-DPACCOR-1001 but got: " + errorMessage);
        Assert.assertTrue(
                errorResponse.getMessage().contains("Stage ID is required"),
                "Expected message to contain 'Stage ID is required' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 4,
            description = "validateDobHipaaInfo returns 400 when dob is in wrong format (not MMddyyyy) - Failure")
    public void validateDobHipaaInfoWithInvalidDobFormat() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with DOB in CPR format (yyyy-MM-dd) instead of the required MMddyyyy.
        //         cprBirthDate is the same underlying date stored in the CPR record but
        //         formatted as "yyyy-MM-dd", which the API rejects as an invalid format (DPR-DPACCOR-1019).
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(cprBirthDate)   // e.g. "1977-12-12" — wrong format; API expects "12121977"
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and error code DPR-DPACCOR-1019 (VALIDATE_DOB_IS_IN_INVALID_FORMAT)
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1019"),
                "Expected error code DPR-DPACCOR-1019 but got: " + errorMessage);
    }

    @Test(
            priority = 5,
            description = "validateDobHipaaInfo returns 400 with cooldown status when customer exceeds failed DOB attempts - Failure")
    public void validateDobHipaaInfoCustomerInCooldown() throws Exception {

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> mismatchResponse = null;
        int attemptNumber;
        String freshCooldownEmailId = CommonUtil.generateRandomEmailId(10);
        String freshCooldownCustomerAccountId = CommonAccountHelper
                .createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(freshCooldownEmailId);
        String freshCooldownStageId = createStageIsacRecord(
                adult2StoreNbr,
                cprAdult2HumanPatientId,
                freshCooldownEmailId,
                correctDob,
                Boolean.FALSE,
                reqIdString + CommonUtil.randomUUID(),
                reqTrackingString + CommonUtil.randomUUID());

        // Step 1: Submit wrong DOB 4 times to exhaust the allowed retries and trigger cooldown.
        //         Each attempt should return 400 with DOB_MISMATCH error code (DPR-DPACCOR-3001).
        for (attemptNumber = 1; attemptNumber <= 4; attemptNumber++) {
            String trackID = CommonUtil.randomUUID();
            String reqId = reqIdString + trackID;
            String reqTrackingId = reqTrackingString + trackID + "_attempt_" + attemptNumber;
            CommonUtil.logFlowIdentifiers(freshCooldownCustomerAccountId, domainId, reqId, reqTrackingId);

            ValidateDobHipaaInfoV1Request wrongDobRequest =
                    ValidateDobHipaaInfoV1Request.builder()
                            .dob(wrongDob)
                            .stageId(freshCooldownStageId)
                            .build();

            mismatchResponse =
                    accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                            freshCooldownCustomerAccountId, domainId, wrongDobRequest, reqId, reqTrackingId);
        }
        ServiceResponse errorEnvelope = gson.fromJson(mismatchResponse.errorBody().string(), ServiceResponse.class);
        Error mismatchError = errorEnvelope.getError();
        String mismatchErrorMessage = CommonUtil.buildErrorMessage(mismatchError);

        ValidateDobHipaaInfoV1Response serviceResponse = null;
        try {
            serviceResponse = ResponseUtil.parseResponse(
                    gson,
                    (LinkedTreeMap<String, Object>) errorEnvelope.getPayload(),
                    ValidateDobHipaaInfoV1Response.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody payload into ValidateDobHipaaInfoV1Response: " + e.getMessage());
        }

        Reporter.logJSON("Attempt number", attemptNumber);
        Assert.assertEquals(mismatchResponse.code(), 400,
                "Attempt " + attemptNumber + ": Expected HTTP 400 but got: " + mismatchResponse.code());
        Assert.assertEquals(mismatchError.getCode(), cooldownErrorCode,
                "Attempt " + attemptNumber + ": Expected DOB mismatch error code " + cooldownErrorCode
                        + " but got: " + mismatchErrorMessage);

        Assert.assertNotNull(serviceResponse.getCoolDownStatus(),
                "Final attempt: coolDownStatus should be present when cooldown is triggered via buildDobMismatchResponse");
        Assert.assertEquals(serviceResponse.getCoolDownStatus().getFailedAttemptsCount(), 4,
                "Final attempt: failedAttemptsCount should not be null");
        Assert.assertEquals(serviceResponse.getCoolDownStatus().getAttemptsRemaining(), 2,
                "Final attempt: attemptsRemaining should not be null when cooldown is triggered");
    }

    @Test(
            priority = 6,
            description = "validateDobHipaaInfo returns 400 when customer is already ID-verified for the stage - Failure")
    public void validateDobHipaaInfoCustomerAlreadyIdVerified() throws Exception {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult3CustomerAccountId, domainId, reqId, reqTrackingId);

        ValidateDobHipaaInfoV1Request request = ValidateDobHipaaInfoV1Request.builder()
                .dob(correctDob)
                .stageId(adult3StageId)
                .build();

        Response<ServiceResponse> response = accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                adult3CustomerAccountId, domainId, request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 when isIdVerified=true but got: " + response.code());

        ServiceResponse serviceResp = CommonUtil.getServiceResponse(gson, response);
        Assert.assertNotNull(serviceResp, "ServiceResponse should not be null");
        Assert.assertNotNull(serviceResp.getError(), "Error should not be null");
        Assert.assertTrue(serviceResp.getError().getCode().contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 for already-verified ID but got: "
                        + serviceResp.getError().getCode());
        Assert.assertTrue(serviceResp.getError().getMessage().contains("already been verified"),
                "Expected error message to contain 'already been verified' but got: "
                        + serviceResp.getError().getMessage());
    }

    @Test(
            priority = 7,
            description = "DOB mismatch: returns DPR-DPACCOR-1009 with attemptsRemaining>0 while retries remain, ")
    public void validateDobHipaaInfoDobMismatch() throws Exception {

        int attemptNumber;
        Response<ServiceResponse> attemptResponse = null;
        String dobMismatchEmailId = CommonUtil.generateRandomEmailId(10);
        String dobMismatchCustomerAccountId = CommonAccountHelper
                .createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dobMismatchEmailId);
        String firstTrackId = CommonUtil.randomUUID();
        String dobMismatchStageId = createStageIsacRecord(
                adult6StoreNbr,
                cprAdult6HumanPatientId,
                dobMismatchEmailId,
                correctDob,
                Boolean.FALSE,
                reqIdString + firstTrackId,
                reqTrackingString + firstTrackId);

        CommonUtil.logFlowIdentifiers(dobMismatchCustomerAccountId, domainId, reqIdString + firstTrackId, reqTrackingString + firstTrackId);

        // Step 1: Submit wrong DOB 5 times to exhaust the allowed retries and trigger cooldown.
        for (attemptNumber = 1; attemptNumber <= 5; attemptNumber++) {
            String trackID = CommonUtil.randomUUID();
            String reqId = reqIdString + trackID;
            String reqTrackingId = reqTrackingString + trackID + "_attempt_" + attemptNumber;
            CommonUtil.logFlowIdentifiers(dobMismatchCustomerAccountId, domainId, reqId, reqTrackingId);

            ValidateDobHipaaInfoV1Request wrongDobRequest =
                    ValidateDobHipaaInfoV1Request.builder()
                            .dob(wrongDob)
                            .stageId(dobMismatchStageId)
                            .build();

            attemptResponse =
                    accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                            dobMismatchCustomerAccountId, domainId, wrongDobRequest, reqId, reqTrackingId);


        }

        ServiceResponse errorEnvelope = gson.fromJson(attemptResponse.errorBody().string(), ServiceResponse.class);
        Error attemptError = errorEnvelope.getError();

        ValidateDobHipaaInfoV1Response serviceResponse = null;
        try {
            serviceResponse = ResponseUtil.parseResponse(
                    gson,
                    (LinkedTreeMap<String, Object>) errorEnvelope.getPayload(),
                    ValidateDobHipaaInfoV1Response.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody payload into ValidateDobHipaaInfoV1Response: " + e.getMessage());
        }

        Assert.assertEquals(attemptResponse.code(), 400,
                "Final attempt: Expected HTTP 400 but got: " + attemptResponse.code());
        Assert.assertEquals(attemptError.getCode(), dobMismatchErrorCode,
                "Final attempt: Expected DPR-DPACCOR-1009 (no attempts left) but got: "
                        + CommonUtil.buildErrorMessage(attemptError));

        Assert.assertNotNull(serviceResponse.getCoolDownStatus(),
                "Final attempt: coolDownStatus should be present when cooldown is triggered via buildDobMismatchResponse");
        Assert.assertEquals(serviceResponse.getCoolDownStatus().getFailedAttemptsCount(), 5,
                "Final attempt: failedAttemptsCount should not be null");
        Assert.assertEquals(serviceResponse.getCoolDownStatus().getAttemptsRemaining(), 1,
                "Final attempt: attemptsRemaining should not be null when cooldown is triggered");
    }

    @Test(
            priority = 8,
            description = "Sequential flow: wrong DOB (400 + DPR-DPACCOR-3001) → correct DOB (200) "
                    + "→ wrong DOB again (400 + DPR-DPACCOR-3001 with reset counter)")
    public void validateDobHipaaInfoWrongThenCorrectThenWrongDob() throws Exception {

        // ── Setup: fresh account + stageId for full test isolation ──────────────────────────────
        String freshEmailId = CommonUtil.generateRandomEmailId(10);
        String freshCustomerAccountId = CommonAccountHelper
                .createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(freshEmailId);
        String freshStageId = createStageIsacRecord(
                adult5StoreNbr,
                cprAdult5HumanPatientId,
                freshEmailId,
                correctDob,
                Boolean.FALSE,
                reqIdString + CommonUtil.randomUUID(),
                reqTrackingString + CommonUtil.randomUUID());

        ValidateDobHipaaInfoV1Request wrongDobRequest =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(wrongDob)
                        .stageId(freshStageId)
                        .build();

        ValidateDobHipaaInfoV1Request correctDobRequest =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId(freshStageId)
                        .build();

        // ════════════════════════════════════════════════════════════════════
        // CALL 1: Wrong DOB
        // ════════════════════════════════════════════════════════════════════
        String track1 = CommonUtil.randomUUID();
        CommonUtil.logFlowIdentifiers(freshCustomerAccountId, domainId, reqIdString + track1, reqTrackingString + track1);

        Response<ServiceResponse> call1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        freshCustomerAccountId, domainId, wrongDobRequest,
                        reqIdString + track1, reqTrackingString + track1);

        Assert.assertEquals(call1Response.code(), 400,
                "Call 1 (wrong DOB): Expected HTTP 400 but got: " + call1Response.code());

        ServiceResponse call1ServiceResp = CommonUtil.getServiceResponse(gson, call1Response);
        Assert.assertNotNull(call1ServiceResp, "Call 1: ServiceResponse should not be null");
        Assert.assertNotNull(call1ServiceResp.getError(), "Call 1: Error should not be null");
        Assert.assertEquals(call1ServiceResp.getError().getCode(), cooldownErrorCode,
                "Call 1: Expected " + cooldownErrorCode + " but got: "
                        + call1ServiceResp.getError().getCode());

        ValidateDobHipaaInfoV1Response call1Payload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) call1ServiceResp.getPayload()),
                ValidateDobHipaaInfoV1Response.class);
        Assert.assertNotNull(call1Payload.getCoolDownStatus(),
                "Call 1: coolDownStatus should not be null after wrong DOB");
        Assert.assertEquals(call1Payload.getCoolDownStatus().getFailedAttemptsCount(), 1,
                "Call 1: failedAttemptsCount should be 1 after first wrong attempt");
        Assert.assertEquals(call1Payload.getCoolDownStatus().getAttemptsRemaining(), 5,
                "Call 1: attemptsRemaining should be > 0 — retries still remain");

        // ════════════════════════════════════════════════════════════════════
        // CALL 2: Correct DOB → 200 OK, full patient HIPAA info, no coolDownStatus
        //         resetFailedAuthenticationAttempts is triggered server-side
        // ════════════════════════════════════════════════════════════════════
        String track2 = CommonUtil.randomUUID();
        CommonUtil.logFlowIdentifiers(freshCustomerAccountId, domainId, reqIdString + track2, reqTrackingString + track2);

        Response<ServiceResponse> call2Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        freshCustomerAccountId, domainId, correctDobRequest,
                        reqIdString + track2, reqTrackingString + track2);

        Assert.assertEquals(call2Response.code(), 200,
                "Call 2 (correct DOB): Expected HTTP 200 but got: " + call2Response.code());
        Assert.assertNotNull(call2Response.body(), "Call 2: Response body should not be null");
        Assert.assertNotNull(call2Response.body().getPayload(), "Call 2: Payload should not be null");

        ValidateDobHipaaInfoV1Response call2Payload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) call2Response.body().getPayload()),
                ValidateDobHipaaInfoV1Response.class);

        Assert.assertNotNull(call2Payload.getFirstName(), "Call 2: firstName should not be null");
        Assert.assertNotNull(call2Payload.getLastName(), "Call 2: lastName should not be null");
        Assert.assertEquals(call2Payload.getDob(), correctDob,
                "Call 2: DOB in response should match the submitted correct DOB");
        Assert.assertNull(call2Payload.getCoolDownStatus(),
                "Call 2: coolDownStatus should be null after correct DOB — counter was reset");

        // ════════════════════════════════════════════════════════════════════
        // CALL 3: Wrong DOB again → 400
        // ════════════════════════════════════════════════════════════════════
        String track3 = CommonUtil.randomUUID();
        CommonUtil.logFlowIdentifiers(freshCustomerAccountId, domainId, reqIdString + track3, reqTrackingString + track3);

        Response<ServiceResponse> call3Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        freshCustomerAccountId, domainId, wrongDobRequest,
                        reqIdString + track3, reqTrackingString + track3);

        Assert.assertEquals(call3Response.code(), 400,
                "Call 3 (wrong DOB again): Expected HTTP 400 but got: " + call3Response.code());

        ServiceResponse call3ServiceResp = CommonUtil.getServiceResponse(gson, call3Response);
        Assert.assertNotNull(call3ServiceResp, "Call 3: ServiceResponse should not be null");
        Assert.assertNotNull(call3ServiceResp.getError(), "Call 3: Error should not be null");
        Assert.assertEquals(call3ServiceResp.getError().getCode(), cooldownErrorCode,
                "Call 3: Expected " + cooldownErrorCode + " but got: "
                        + call3ServiceResp.getError().getCode());

        ValidateDobHipaaInfoV1Response call3Payload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) call3ServiceResp.getPayload()),
                ValidateDobHipaaInfoV1Response.class);
        Assert.assertNotNull(call3Payload.getCoolDownStatus(),
                "Call 3: coolDownStatus should not be null after wrong DOB");
        Assert.assertEquals(call3Payload.getCoolDownStatus().getFailedAttemptsCount(), 1,
                "Call 3: failedAttemptsCount should be reset to 1 — correct DOB cleared the prior count");
        Assert.assertEquals(call3Payload.getCoolDownStatus().getAttemptsRemaining(), 5,
                "Call 3: attemptsRemaining should be > 0 — counter was fresh-started after reset");
    }

    @Test(
            priority = 9,
            description = "validateDobHipaaInfo returns 400 via buildCooldownResponse path when customer is already "
                    + "locked out — exhausts all retries (5 wrong DOBs) then makes one more call that hits "
                    + "checkCustomerCooldownStatus=true, returning DPR-DPACCOR-3001 with coolDownStatus - Failure")
    public void validateDobHipaaInfoCustomerAlreadyInCooldown() throws Exception {

        // ── Setup: fresh account + stageId using adult4 CPR patient for full isolation ───────────
        String freshEmailId = CommonUtil.generateRandomEmailId(10);
        String freshCustomerAccountId = CommonAccountHelper
                .createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(freshEmailId);
        String freshStageId = createStageIsacRecord(
                adult4StoreNbr,
                cprAdult4HumanPatientId,
                freshEmailId,
                correctDob,
                Boolean.FALSE,
                reqIdString + CommonUtil.randomUUID(),
                reqTrackingString + CommonUtil.randomUUID());

        // ── Step 1: Submit 5 wrong DOBs to exhaust all retries and lock the customer ─────────────
        for (int attempt = 1; attempt <= 5; attempt++) {
            String trackID = CommonUtil.randomUUID();
            String reqId = reqIdString + trackID;
            String reqTrackingId = reqTrackingString + trackID + "_lockout_attempt_" + attempt;
            CommonUtil.logFlowIdentifiers(freshCustomerAccountId, domainId, reqId, reqTrackingId);

            ValidateDobHipaaInfoV1Request wrongDobRequest =
                    ValidateDobHipaaInfoV1Request.builder()
                            .dob(wrongDob)
                            .stageId(freshStageId)
                            .build();

            accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                    freshCustomerAccountId, domainId, wrongDobRequest, reqId, reqTrackingId);
        }

        // ── Step 2: Submit one more call — customer is now locked, hits buildCooldownResponse ─────
        String track6 = CommonUtil.randomUUID();
        String reqId6 = reqIdString + track6;
        String reqTrackingId6 = reqTrackingString + track6 + "_post_lockout";
        CommonUtil.logFlowIdentifiers(freshCustomerAccountId, domainId, reqId6, reqTrackingId6);

        ValidateDobHipaaInfoV1Request postLockoutRequest =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(wrongDob)
                        .stageId(freshStageId)
                        .build();

        Response<ServiceResponse> postLockoutResponse =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        freshCustomerAccountId, domainId, postLockoutRequest, reqId6, reqTrackingId6);

        // ── Step 3: Parse the error body ─────────────────────────────────────────────────────────
        ServiceResponse cooldownEnvelope = CommonUtil.getServiceResponse(gson, postLockoutResponse);
        Assert.assertNotNull(cooldownEnvelope, "Post-lockout: ServiceResponse should not be null");
        Assert.assertNotNull(cooldownEnvelope.getError(), "Post-lockout: Error should not be null");

        ValidateDobHipaaInfoV1Response cooldownPayload = null;
        try {
            cooldownPayload = ResponseUtil.parseResponse(
                    gson,
                    (LinkedTreeMap<String, Object>) cooldownEnvelope.getPayload(),
                    ValidateDobHipaaInfoV1Response.class);
        } catch (Exception e) {
            Assert.fail("Failed to parse errorBody payload into ValidateDobHipaaInfoV1Response: " + e.getMessage());
        }

        // ── Step 4: Assert buildCooldownResponse path ─────────────────────────────────────────────
        Assert.assertEquals(postLockoutResponse.code(), 400,
                "Post-lockout call: Expected HTTP 400 but got: " + postLockoutResponse.code());
        Assert.assertEquals(cooldownEnvelope.getError().getCode(), cooldownErrorCode,
                "Post-lockout call: Expected " + cooldownErrorCode + " (buildCooldownResponse path) "
                        + "but got: " + cooldownEnvelope.getError().getCode());
        Assert.assertNotNull(cooldownPayload.getCoolDownStatus(),
                "Post-lockout call: coolDownStatus should not be null (customer is actively locked)");
        Assert.assertEquals(cooldownPayload.getCoolDownStatus().getFailedAttemptsCount(), 5,
                "Post-lockout call: failedAttemptsCount should not be null");
        Assert.assertEquals(cooldownPayload.getCoolDownStatus().getAttemptsRemaining(), 1,
                "Post-lockout call: attemptsRemaining should not be null");
        Assert.assertNotNull(cooldownPayload.getCoolDownStatus().getRemainingTime(),
                "Post-lockout: remainingTime should not be null");
        Assert.assertTrue(cooldownPayload.getCoolDownStatus().getRemainingTime() > 0,
                "Post-lockout: remainingTime should be > 0 — cooldown timer must be active after lockout, "
                        + "got: " + cooldownPayload.getCoolDownStatus().getRemainingTime());

    }

    @Test(
            priority = 10,
            description = "validateDobHipaaInfo returns 400 with DPR-DPACCOR-1001 when dob is blank (whitespace only) - Failure")
    public void validateDobHipaaInfoWithBlankDob() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with dob set to whitespace (blank but non-null)
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob("   ")    // blank — triggers "DOB is required" validation
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and DPR-DPACCOR-1001 with "DOB is required" message
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1001"),
                "Expected error code DPR-DPACCOR-1001 but got: " + errorMessage);
        Assert.assertTrue(
                errorResponse.getMessage().contains("DOB is required"),
                "Expected message to contain 'DOB is required' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 11,
            description = "validateDobHipaaInfo returns 400 with DPR-DPACCOR-1001 when stageId is blank (empty string) - Failure")
    public void validateDobHipaaInfoWithBlankStageId() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build request with stageId set to empty string (blank but non-null)
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId("")   // blank — triggers "Stage ID is required" validation
                        .build();

        // Step 3: Call validateDobHipaaInfoV1
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and DPR-DPACCOR-1001 with "Stage ID is required" message
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1001"),
                "Expected error code DPR-DPACCOR-1001 but got: " + errorMessage);
        Assert.assertTrue(
                errorResponse.getMessage().contains("Stage ID is required"),
                "Expected message to contain 'Stage ID is required' but got: " + errorResponse.getMessage());
    }

    @Test(
            priority = 12,
            description = "validateDobHipaaInfo returns 204 when stageId does not exist in AccEn")
    public void validateDobHipaaInfoWithInvalidStageId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, adult1CustomerAccountId, reqId, reqTrackingId);

        // Use a fresh UUID that has never been registered in AccEn.
        String nonExistentStageId = CommonUtil.randomUUID();

        ValidateDobHipaaInfoV1Request request = ValidateDobHipaaInfoV1Request.builder()
                .dob(correctDob)
                .stageId(nonExistentStageId) // random UUID — never registered in AccEn
                .build();

        Response<ServiceResponse> response = accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                adult1CustomerAccountId, domainId, request, reqId, reqTrackingId);

        int statusCode = response.code();

        Assert.assertEquals(statusCode, 204,
                "Expected a non-success response for non-existent stageId but got HTTP 200");
    }

    @Test(
            priority = 13,
            description = "validateDobHipaaInfo returns 400 with DPR-DPACCOR-1001 when customerAccountId path variable is empty - Failure")
    public void validateDobHipaaInfoWithEmptyCustomerAccountId() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers("", domainId, reqId, reqTrackingId);

        // Step 2: Build a valid request body — the invalid part is the empty customerAccountId path variable
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1 with an empty string as customerAccountId
        //         ValidationUtil.validateCustomerAccountIdNotEmpty() rejects this with INVALID_REQUEST_EXCEPTION
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        "",                  // empty customerAccountId — triggers controller-level guard
                        domainId,
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 500, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("CHP-DPACCOR-1003"),
                "Expected error code CHP-DPACCOR-1003 for empty customerAccountId but got: " + errorMessage);
    }

    @Test(
            priority = 14,
            description = "validateDobHipaaInfo returns 400 with DPR-DPACCOR-1001 when domainId path variable is invalid - Failure")
    public void validateDobHipaaInfoWithInvalidDomainId() throws IOException {

        // Step 1: Set and log tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(adult1CustomerAccountId, domainId, reqId, reqTrackingId);

        // Step 2: Build a valid request body — the invalid part is the unrecognised domainId path variable
        ValidateDobHipaaInfoV1Request validateDobHipaaInfoV1Request =
                ValidateDobHipaaInfoV1Request.builder()
                        .dob(correctDob)
                        .stageId(adult1StageId)
                        .build();

        // Step 3: Call validateDobHipaaInfoV1 with a domainId that is not in the CCM allowlist
        //         ValidationUtil.validateDomainId() rejects any value not present in
        //         appCCMConfig.getAccountOrchestratorValidDomainId(), throwing INVALID_REQUEST_EXCEPTION
        Response<ServiceResponse> validateDobHipaaInfoV1Response =
                accountOrchestratorRetrofit.validateDobHipaaInfoV1(
                        adult1CustomerAccountId,
                        "INVALID-DOMAIN",    // not in CCM allowlist — triggers controller-level domain guard
                        validateDobHipaaInfoV1Request,
                        reqId,
                        reqTrackingId);

        // Step 4: Parse error response
        Error errorResponse = CommonUtil.getErrorResponse(gson, validateDobHipaaInfoV1Response);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        // Step 5: Assert 400 and error code DPR-DPACCOR-1001 (INVALID_REQUEST_EXCEPTION)
        Assert.assertEquals(validateDobHipaaInfoV1Response.code(), 400, errorMessage);
        Assert.assertTrue(
                errorMessage.contains("DPR-DPACCOR-1001"),
                "Expected error code DPR-DPACCOR-1001 for invalid domainId but got: " + errorMessage);
        Assert.assertTrue(
                errorResponse.getMessage().contains("invalid"),
                "Expected error message to contain 'invalid' for unrecognised domainId but got: "
                        + errorResponse.getMessage());
    }

    @AfterClass
    void cleanUp() {
        // Assign the patientIds that were returned after CPR account creation
        // (they were null at the time setPatientId was called in @BeforeClass)
        adult1CprRequest.setPatientId(cprAdult1HumanPatientId);
        adult2CprRequest.setPatientId(cprAdult2HumanPatientId);
        adult3CprRequest.setPatientId(cprAdult3HumanPatientId);
        adult4CprRequest.setPatientId(cprAdult4HumanPatientId);
        adult5CprRequest.setPatientId(cprAdult5HumanPatientId);
        adult6CprRequest.setPatientId(cprAdult6HumanPatientId);

        // Mark all CPR accounts for deletion by setting patientStatusCode to 20708 (ONLINE_DEL)
        Arrays.asList(
                        adult1CprRequest,
                        adult2CprRequest,
                        adult3CprRequest,
                        adult4CprRequest,
                        adult5CprRequest,
                        adult6CprRequest)
                .forEach(
                        request -> {
                            request.getPatientInfo().setPatientStatusCode(20708);
                            try {
                                deleteCprAccount(request);
                            } catch (IOException e) {
                            }
                        });
    }

    private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
        } else {
            Reporter.logJSON(
                    "errorMessage",
                    String.format(
                            "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                            cprRequest.getPatientId(), response.code()));
        }
    }

    public String createStageIsacRecord(
            String storeNbr,
            Integer patientId,
            String emailId,
            String dob, Boolean idVerified,
            String reqId,
            String reqTrackingId) throws IOException {

        AccountOrchestratorRetrofit accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();

        CreateStageISACRecordV1Request request = CreateStageISACRecordV1Request.builder()
                .storeNbr(storeNbr)
                .patientId(String.valueOf(patientId))
                .emailId(emailId)
                .dob(dob)
                .idVerified(idVerified)
                .build();

        Response<ServiceResponse> response =
                accountOrchestratorRetrofit.createStageIsacRecordV1(
                        domainId,
                        request,
                        reqId,
                        reqTrackingId);

        LinkedTreeMap<String, Object> payload =
                (LinkedTreeMap<String, Object>) response.body().getPayload();

        String stageId = (String) payload.get("stageId");

        return stageId;
    }
}
