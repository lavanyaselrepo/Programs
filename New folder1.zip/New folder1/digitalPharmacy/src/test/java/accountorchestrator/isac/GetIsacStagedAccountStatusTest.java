package accountorchestrator.isac;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ExistingIdInfo;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1RequestIdVerificationInfo;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Response;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateStageISACRecordV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.ValidateDobHipaaInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetIsacStagedAccountStatusV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharmacyauthservice.restapi.PharmacyAuthServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil.logFlowIdentifiers;

/**
 * Automation test suite for GET /v1/customer/domain/{domainId}/isac/stage-id/{stageId}
 * <p>
 * Test execution order (priority) is intentional — later tests depend on data
 * set up by earlier ones (e.g. BOTH_DOTCOM_PHARMACY requires the pharmacy entity
 * created at priority=2, cooldown increments accumulate across priority=11/12 using
 * cooldownCustomerAccountId, and priority=11 resets them via V1 resetFailedAuthentication).
 * <p>
 * Priority groups:
 * 0        – Error: stageId not found → HTTP 204
 * 1–2      – Success: DOTCOM_ONLY, BOTH_DOTCOM_PHARMACY (core happy paths)
 * 3–5      – Error: invalid input (domainId, malformed stageId)
 * 6–9      – Success: NOT_CREATED, linkExpired=false, dobRetriesExhausted, linkExpired upsert
 * 10       – Error: idVerified=false record → HTTP 204 (backward-compat guard active; QA CCM flag=false)
 * 10       – Success: cooldown below threshold (p=10)
 * 11       – Success: cooldown reset (p=11)
 * 12–13    – Success: stageId uniqueness (p=12), idempotency (p=13)
 * 14–15    – (COMMENTED OUT) cooldown above threshold (p=14), full cooldown flow (p=15)
 *            TODO: Uncomment once CCM flag is.isac.associate.triggered.account.creation.enabled is enabled in QA
 */
public class GetIsacStagedAccountStatusTest {

  // ─── Retrofit clients ───────────────────────────────────────────────────
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private PharmacyAuthServiceRetrofit pharmacyAuthServiceRetrofit;

  private final String reqIdString = "req-id-";
  private final String reqTrackingString = "req-tracking-";
  private final String domainId = "WM-PHARMACY";
  private Gson gson;
  private ObjectMapper mapper;
  private IsacHelper isacHelper;

  // ─── CPR patients ──────────────────────
  // adultHuman  → used for DOTCOM_ONLY → BOTH_DOTCOM_PHARMACY progression + cooldown tests
  // minorHuman  → minor patient (age < 18, birthDate=(currentYear-1)-01-01) — used in p=16
  //               saveIsacIdVerification rejects minors (error 1044) — no stageId ever created
  // adult2Human → used for linkExpired=false and isIdVerified=false tests (p=7, p=9)
  // adult3Human → used exclusively for stageId uniqueness and idempotency tests (p=12, p=13)
  // adult4Human → used exclusively for cooldown full flow test (p=15)
  //               must have NO pharmacy entity and NO prior ISAC records so that
  //               createStageISACRecordV1 passes both the pharmacy-account guard (Step 4)
  //               and the existing-ISAC-record guard (Step 5, idVerified=false branch)
  ValidationServiceRequest adultHumanCprPatientRequest;
  ValidationServiceRequest minorHumanCprPatientRequest;
  ValidationServiceRequest adult2HumanCprPatientRequest;
  ValidationServiceRequest adult3HumanCprPatientRequest;
  ValidationServiceRequest adult4HumanCprPatientRequest;

  Integer cprAdultHumanPatientId = 0;
  Integer cprMinorHumanPatientId = 0;
  Integer cprAdult2HumanPatientId = 0;
  Integer cprAdult3HumanPatientId = 0;
  Integer cprAdult4HumanPatientId = 0;

  private String emailId;
  private String customerAccountId;

  // Used exclusively for cooldown tests (p=11/12/13).
  // Must have a CA account (so the GET endpoint can resolve customerAccountId for the V1
  // PharmacyAuth cooldown lookup) but must NOT have a pharmacy entity in Account Entity
  private String cooldownEmailId;
  private String cooldownCustomerAccountId;

  // ─── Shared state ─────────────────
  private String storeNbr;
  private String stageId;

  List<Integer> patientIds = new ArrayList<>();

  @BeforeClass
  void setContext() throws Exception {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    pharmacyAuthServiceRetrofit = new PharmacyAuthServiceRetrofit();
    gson = new Gson();
    mapper = new ObjectMapper();

    storeNbr = CommonUtil.generateRandomNumber(6);
    isacHelper = new IsacHelper();

    adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult3HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
    adult4HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);

    // Create the first 3 CPR accounts (includes a 30-second async propagation delay internally)
    patientIds = isacHelper.createAllCprAccounts(
            adultHumanCprPatientRequest,
            minorHumanCprPatientRequest,
            adult2HumanCprPatientRequest,
            storeNbr);

    cprAdultHumanPatientId = patientIds.get(0);
    cprMinorHumanPatientId = patientIds.get(1);
    cprAdult2HumanPatientId = patientIds.get(2);

    adult3HumanCprPatientRequest.getPatientInfo().setBirthDate("1977-12-12");
    adult3HumanCprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprAdult3HumanPatientId = SharedUtils.createCprAccount(adult3HumanCprPatientRequest, cprPatientUpdateRetrofit);

    // adult4Human: dedicated to the cooldown full flow test (p=15).
    // Never used by any other test so it always arrives at createStageISACRecordV1 with
    // no pharmacy entity and no prior ISAC records — both orchestrator guards pass cleanly.
    adult4HumanCprPatientRequest.getPatientInfo().setBirthDate("1985-07-20");
    adult4HumanCprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
    cprAdult4HumanPatientId = SharedUtils.createCprAccount(adult4HumanCprPatientRequest, cprPatientUpdateRetrofit);

    Thread.sleep(30000); // wait for CPR async (covers both adult3 and adult4 creation)

    // Creates Dotcom (CA) account for the adult patient — used for DOTCOM_ONLY and BOTH_DOTCOM_PHARMACY tests
    emailId = CommonUtil.generateRandomEmailId(10);
    customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailId);

    // Creates a SEPARATE CA account for cooldown tests (p=11/12/13).
    // This email intentionally has NO pharmacy entity so saveIsacIdVerification does not
    // throw PHARMACY_ACCOUNT_ALREADY_EXISTS_EXCEPTION.
    cooldownEmailId = CommonUtil.generateRandomEmailId(10);
    cooldownCustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(cooldownEmailId);
  }

  @Test(priority = 0, description = "no content stageId for GetIsacStagedAccountStatusV1")
  public void noContentStageIdGetIsacIdStagedAccountStatusV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step - 2: Calling Get Isac Staged Account Status V1
    Response<ServiceResponse> getIsacIdStagedAccountStatusV1Response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    UUID.randomUUID().toString(), domainId, reqId, reqTrackingId);

    // Step - 3: Asserting response
    Assert.assertEquals(204, getIsacIdStagedAccountStatusV1Response.code());
  }

  @Test(priority = 1, description = "success GetIsacStagedAccountStatusV1 Response")
  public void getIsacIdStagedAccountStatusV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    stageId = isacHelper.saveIsacIdVerification(
            storeNbr,
            cprAdultHumanPatientId,
            emailId,
            reqIdString,
            reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step - 2: Calling Get Isac Staged Account Status V1
    Response<ServiceResponse> getIsacIdStagedAccountStatusV1Response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    stageId, domainId, reqId, reqTrackingId);

    // Step - 3: Asserting response
    Assert.assertNotNull(getIsacIdStagedAccountStatusV1Response.body());
    GetIsacStagedAccountStatusV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getIsacIdStagedAccountStatusV1Response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertNotNull(response);
    Assert.assertTrue(response.getIdVerified());
    Assert.assertFalse(response.getLinkExpired());
    Assert.assertFalse(response.getDobRetriesExhausted());
    Assert.assertEquals("DOTCOM_ONLY", response.getAccountState());
  }

  @Test(priority = 2, description = "success GetIsacStagedAccountStatusV1 Response")
  public void getIsacIdStagedAccountStatusV1Success1() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    isacHelper.createPharmacyAccountEntity(
            accountEntityServiceRetrofit,
            customerAccountId,
            storeNbr,
            String.valueOf(cprAdultHumanPatientId),
            "12121977");

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step - 2: Calling Get Isac Staged Account Status V1
    Response<ServiceResponse> getIsacIdStagedAccountStatusV1Response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    stageId, domainId, reqId, reqTrackingId);

    // Step - 3: Asserting response
    Assert.assertNotNull(getIsacIdStagedAccountStatusV1Response.body());
    GetIsacStagedAccountStatusV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getIsacIdStagedAccountStatusV1Response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertNotNull(response);
    Assert.assertTrue(response.getIdVerified());
    Assert.assertFalse(response.getLinkExpired());
    Assert.assertFalse(response.getDobRetriesExhausted());
    Assert.assertEquals("BOTH_DOTCOM_PHARMACY", response.getAccountState());
  }

  @Test(priority = 3, description = "Invalid domainId returns HTTP 400 with INVALID_REQUEST_EXCEPTION")
  public void invalidDomainIdReturns400() throws IOException {

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers("INVALID-DOMAIN", reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    UUID.randomUUID().toString(), "INVALID-DOMAIN", reqId, reqTrackingId);

    Assert.assertEquals(400, response.code(),
            "Expected HTTP 400 for an invalid domainId");
    String errorMessage = CommonUtil.buildErrorMessage(gson, response);
    Assert.assertNotNull(errorMessage,
            "Error body must not be null for invalid domainId");
    Assert.assertTrue(errorMessage.contains("DPR-DPACCOR-1001"),
            "Error code must be DPR-DPACCOR-1001 for invalid domainId. Actual: " + errorMessage);
  }

  @Test(priority = 4, description = "Empty domainId returns HTTP 500 — empty path segment causes routing failure")
  public void emptyDomainIdReturns500() throws IOException {

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers("", reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    UUID.randomUUID().toString(), "", reqId, reqTrackingId);

    // Assert HTTP 500 — empty path segment triggers a routing error, not a 400
    Assert.assertEquals(500, response.code(),
            "Expected HTTP 500 for empty domainId");
  }

  @Test(priority = 5, description = "Malformed non-UUID stageId is handled gracefully and returns HTTP 204")
  public void malformedStageIdReturns204() throws IOException {

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    "not-a-valid-uuid-format", domainId, reqId, reqTrackingId);

    Assert.assertEquals(204, response.code(),
            "Expected HTTP 204 — malformed stageId is treated as unrecognised");
  }

  @Test(priority = 6, description = "accountState=NOT_CREATED — no Dotcom or pharmacy account linked to this email")
  public void notCreatedAccountStateReturnsHttp200() throws IOException {

    String freshEmail = CommonUtil.generateRandomEmailId(10);
    String freshStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdultHumanPatientId, freshEmail, reqIdString, reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    freshStageId, domainId, reqId, reqTrackingId);

    Assert.assertEquals(200, response.code(), "Expected HTTP 200");
    Assert.assertNotNull(response.body(), "Response body must not be null for HTTP 200");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertNotNull(payload, "Parsed payload must not be null");
    Assert.assertEquals("NOT_CREATED", payload.getAccountState(),
            "accountState must be NOT_CREATED — CA service returned ACCOUNT_NOT_FOUND ");
    Assert.assertEquals(freshEmail, payload.getEmailId(),
            "emailId must match the fresh email used during saveIsacIdVerification");
    Assert.assertTrue(payload.getIdVerified(),
            "idVerified must be true — saveIsacIdVerification creates records as verified by default");
    Assert.assertFalse(payload.getLinkExpired(),
            "linkExpired must be false — this is a freshly created ISAC record");
    Assert.assertFalse(payload.getDobRetriesExhausted(),
            "dobRetriesExhausted must be false — no failed DOB attempts have been made");
    Assert.assertNotNull(payload.getFirstName(),
            "firstName must not be null — populated from CPR patient info");
    Assert.assertNotNull(payload.getLastName(),
            "lastName must not be null — populated from CPR patient info");
    Assert.assertFalse(Boolean.TRUE.equals(payload.getIsInCooldown()),
            "isInCooldown must be false — fresh account with no pharmacy auth failures");
    Assert.assertNull(payload.getCoolDownStatus(),
            "coolDownStatus must be null — no cooldown for a fresh account");
  }

  @Test(priority = 7, description = "dobRetriesExhausted=true — ISAC record created via saveIsacIdVerification then UPDATE_DOB_RETRIES")
  public void dobRetriesExhaustedTrueIsReflectedInPayload() throws IOException {

    String dobEmail = CommonUtil.generateRandomEmailId(10);
    String dobStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdultHumanPatientId, dobEmail, reqIdString, reqTrackingString);
    Assert.assertNotNull(dobStageId, "saveIsacIdVerification must return a non-null stageId");

    ExistingIdInfo dobExistingIdInfo = new ExistingIdInfo();
    dobExistingIdInfo.setStageId(dobStageId);

    UpsertIsacIdVerificationV1Request updateDobRetriesRequest = new UpsertIsacIdVerificationV1Request();
    updateDobRetriesRequest.setDobRetries("4");
    updateDobRetriesRequest.setExistingIdInfo(Collections.singletonList(dobExistingIdInfo));

    String updateTrackID = CommonUtil.randomUUID();
    String updateReqId = reqIdString + updateTrackID;
    String updateReqTrackingId = reqTrackingString + updateTrackID;
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> updateResponse =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, updateReqId, updateReqTrackingId, updateDobRetriesRequest, "UPDATE_DOB_RETRIES");

    Assert.assertEquals(200, updateResponse.code(),
            "Account Entity UPDATE_DOB_RETRIES must succeed  before asserting dobRetriesExhausted");

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    dobStageId, domainId, reqId, reqTrackingId);

    // dobRetriesExhausted is a purely informational field — it never causes HTTP 204
    Assert.assertEquals(200, response.code(),
            "Expected HTTP 200 — dobRetriesExhausted is informational only and does not close the ISAC flow");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    Assert.assertTrue(payload.getDobRetriesExhausted(),
            "dobRetriesExhausted must be true — UPDATE_DOB_RETRIES set dobRetries=4 which is strictly greater than CCM isacIdVerificationMaxDobRetries=3");
    Assert.assertFalse(Boolean.TRUE.equals(payload.getIsInCooldown()),
            "isInCooldown must be false — no pharmacy auth failures for this account");
    Assert.assertNull(payload.getCoolDownStatus(),
            "coolDownStatus must be null — no cooldown triggered for this account");
  }

  @Test(priority = 8, description = "DB-level EXPIRED upsert — orchestrator returns HTTP 204 for an expired stageId")
  public void linkExpiredViaUpsertReturns204() throws IOException {

    String linkExpiredEmail = CommonUtil.generateRandomEmailId(10);
    String expiredStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdultHumanPatientId, linkExpiredEmail, reqIdString, reqTrackingString);
    Assert.assertNotNull(expiredStageId, "saveIsacIdVerification must return a non-null stageId");

    ExistingIdInfo existingIdInfo = new ExistingIdInfo();
    existingIdInfo.setStageId(expiredStageId);

    UpsertIsacIdVerificationV1Request expireRequest = new UpsertIsacIdVerificationV1Request();
    expireRequest.setIsExpired(Boolean.TRUE.toString());
    expireRequest.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    String expireTrackID = CommonUtil.randomUUID();
    String expireReqId = reqIdString + expireTrackID;
    String expireReqTrackingId = reqTrackingString + expireTrackID;
    Response<?> expireResponse = accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
            domainId, expireReqId, expireReqTrackingId, expireRequest, "EXPIRED");

    Assert.assertEquals(200, expireResponse.code(),
            "Account Entity EXPIRED upsert must succeed before asserting orchestrator returns 204");

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    expiredStageId, domainId, reqId, reqTrackingId);

    Assert.assertEquals(204, response.code(),
            "Expected HTTP 204 — orchestrator treats a DB-level expired record as non-existent");
  }


  @Test(priority = 9, description = "isIdVerified=false record returns HTTP 204 — backward-compat guard treats non-verified records as non-existent (QA: CCM flag=false)")
  public void isIdVerifiedFalseRecordReturns204() throws IOException {

    // Step - 1: Insert a new ISAC record directly via Account Entity with isIdVerified=false
    UpsertIsacIdVerificationV1RequestIdVerificationInfo idVerificationInfo =
            new UpsertIsacIdVerificationV1RequestIdVerificationInfo();
    idVerificationInfo.isIdVerified(Boolean.FALSE.toString());

    String birthDate = adult2HumanCprPatientRequest.getPatientInfo().getBirthDate();
    String patientDob = birthDate.substring(5, 7) + birthDate.substring(8, 10) + birthDate.substring(0, 4);

    UpsertIsacIdVerificationV1Request insertRequest = new UpsertIsacIdVerificationV1Request();
    insertRequest.setPatientId(String.valueOf(cprAdult2HumanPatientId));
    insertRequest.storeNbr(storeNbr);
    insertRequest.setEmailId(CommonUtil.generateRandomEmailId(10));
    insertRequest.dob(patientDob);
    insertRequest.firstName(adult2HumanCprPatientRequest.getPatientInfo().getFirstName());
    insertRequest.lastName(adult2HumanCprPatientRequest.getPatientInfo().getLastName());
    insertRequest.idVerificationInfo(idVerificationInfo);

    String insertReqId = reqIdString + CommonUtil.randomUUID();
    String insertReqTrackingId = reqTrackingString + CommonUtil.randomUUID();
    Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> insertResponse =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, insertReqId, insertReqTrackingId, insertRequest, "INSERT");

    Assert.assertEquals(200, insertResponse.code(),
            "Account Entity INSERT (isIdVerified=false) must succeed before querying getIsacStagedAccountStatusV1");
    Assert.assertNotNull(insertResponse.body(), "INSERT response body must not be null");

    UpsertIsacIdVerificationV1Response insertBody = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertResponse.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String insertedStageId = insertBody.getStageId();
    Assert.assertNotNull(insertedStageId, "stageId from INSERT must not be null");

    // Step - 2: Query getIsacStagedAccountStatusV1 for the non-verified stageId
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    insertedStageId, domainId, reqId, reqTrackingId);

    // Step - 3: Assert HTTP 204 (QA: CCM flag=false)
    // TODO: getIsacStagedAccountStatusV1 returns 204 because CCM flag isIsacAssociateTriggeredAccountCreationEnabled() is false and isIdVerified=false.
    //       When the CCM flag is enabled in QA, this test should return 200 instead of 204.
    //       Uncomment the 200 assertions below and remove/comment the 204 assertion.
    Assert.assertEquals(204, response.code(),
            "Expected HTTP 204 for isIdVerified=false record ");

    // TODO: Uncomment when CCM flag isIsacAssociateTriggeredAccountCreationEnabled() is enabled in QA.
    //       With flag=true, getIsacStagedAccountStatusV1 returns 200 for isIdVerified=false records.

    /*Assert.assertEquals(200, response.code(),
        "Expected HTTP 200 for isIdVerified=false record when CCM flag is enabled");
    Assert.assertNotNull(response.body(), "Response body must not be null for HTTP 200");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
        gson,
        ((LinkedTreeMap<String, Object>) response.body().getPayload()),
        GetIsacStagedAccountStatusV1Response.class);
    Assert.assertNotNull(payload, "Parsed payload must not be null");
    Assert.assertFalse(Boolean.TRUE.equals(payload.getIdVerified()),
        "idVerified must be false — record was inserted with isIdVerified=false");*/

  }

  @Test(priority = 10, description = "isInCooldown=false and coolDownStatus=null when pharmacy auth attempts are below the cooldown threshold")
  public void cooldownBelowThresholdReturnsIsInCooldownFalse() throws IOException {

    // Increment pharmacy auth failures twice via V1 API (keyed by cooldownCustomerAccountId)
    for (int i = 0; i < 2; i++) {
      pharmacyAuthServiceRetrofit.incrementFailedAuthentication(cooldownCustomerAccountId);
    }

    String cooldownStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdultHumanPatientId, cooldownEmailId, reqIdString, reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    cooldownStageId, domainId, reqId, reqTrackingId);

    Assert.assertEquals(200, response.code(),
            "Expected HTTP 200 — the API must succeed even after pharmacy auth increments");
    Assert.assertNotNull(response.body(), "Response body must not be null for HTTP 200");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertNotNull(payload, "Parsed payload must not be null");
    Assert.assertFalse(Boolean.TRUE.equals(payload.getIsInCooldown()),
            "isInCooldown must be false — 2 pharmacy auth attempts are below the cooldown threshold");
    Assert.assertNull(payload.getCoolDownStatus(),
            "coolDownStatus must be null when the patient is not in cooldown — "
                    + "service only populates this field when isInCooldown=true");
    Assert.assertFalse(Boolean.TRUE.equals(payload.getDobRetriesExhausted()),
            "dobRetriesExhausted must be false — cooldown increments and DOB retries are independent counters");
  }

  @Test(priority = 11, description = "Cooldown reset — isInCooldown=false and coolDownStatus=null after reset")
  public void cooldownResetVerification() throws IOException {

    Response<Void> resetResponse =
            pharmacyAuthServiceRetrofit.resetFailedAuthentication(cooldownCustomerAccountId);
    Assert.assertEquals(200, resetResponse.code(),
            "resetFailedAuthentication (V1) must succeed before asserting isInCooldown=false");
    Reporter.logJSON("cooldown.resetCall",
            "Cooldown reset succeeded for cooldownCustomerAccountId=" + cooldownCustomerAccountId);

    String resetStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdultHumanPatientId, cooldownEmailId, reqIdString, reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    resetStageId, domainId, reqId, reqTrackingId);

    Assert.assertEquals(200, response.code(),
            "Expected HTTP 200 — cooldown has been reset");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) response.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    Assert.assertFalse(Boolean.TRUE.equals(payload.getIsInCooldown()),
            "isInCooldown must be false after cooldown reset");
    Assert.assertNull(payload.getCoolDownStatus(),
            "coolDownStatus must be null — no active cooldown after reset");
  }

  @Test(priority = 12, description = "Each saveIsacIdVerification produces a unique stageId; emailId is scoped per stageId")
  public void stageIdUniquenessAndIsolation() throws IOException {

    // Two different patients ensure stageIdB's UPDATE_RECORD cannot replace stageIdA:
    //   stageIdA: cprAdult3HumanPatientId (no prior records) → INSERT → fresh UUID
    //   stageIdB: cprAdultHumanPatientId  (has records, emailB is new) → UPDATE_RECORD → new UUID
    String emailA = CommonUtil.generateRandomEmailId(10);
    String emailB = CommonUtil.generateRandomEmailId(10);
    String stageIdA = isacHelper.saveIsacIdVerification(storeNbr, cprAdult3HumanPatientId, emailA, reqIdString, reqTrackingString);
    String stageIdB = isacHelper.saveIsacIdVerification(storeNbr, cprAdultHumanPatientId, emailB, reqIdString, reqTrackingString);

    Assert.assertNotNull(stageIdA, "stageIdA must not be null");
    Assert.assertNotNull(stageIdB, "stageIdB must not be null");
    Assert.assertNotEquals(stageIdA, stageIdB,
            "Two saveIsacIdVerification calls must produce distinct stageId UUIDs");
    Reporter.logJSON("uniqueness.setup",
            "stageIdA=" + stageIdA + " (emailA=" + emailA + ") | stageIdB=" + stageIdB + " (emailB=" + emailB + ")");

    Response<ServiceResponse> responseA =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    stageIdA, domainId, reqIdString + CommonUtil.randomUUID(), reqTrackingString + CommonUtil.randomUUID());
    Response<ServiceResponse> responseB =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    stageIdB, domainId, reqIdString + CommonUtil.randomUUID(), reqTrackingString + CommonUtil.randomUUID());

    Assert.assertEquals(200, responseA.code(),
            "stageIdA must return HTTP 200. Actual: " + responseA.code());
    Assert.assertEquals(200, responseB.code(),
            "stageIdB must return HTTP 200. Actual: " + responseB.code());

    GetIsacStagedAccountStatusV1Response payloadA = ResponseUtil.parseResponse(
            gson, ((LinkedTreeMap<String, Object>) responseA.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    GetIsacStagedAccountStatusV1Response payloadB = ResponseUtil.parseResponse(
            gson, ((LinkedTreeMap<String, Object>) responseB.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertEquals(emailA, payloadA.getEmailId(),
            "stageIdA must return emailA — stageId records are email-scoped and must not bleed into each other");
    Assert.assertEquals(emailB, payloadB.getEmailId(),
            "stageIdB must return emailB — stageId records are email-scoped and must not bleed into each other");
    Reporter.logJSON("uniqueness.result",
            "stageId uniqueness confirmed: " + stageIdA + " ≠ " + stageIdB
                    + " | emailA=" + payloadA.getEmailId() + " | emailB=" + payloadB.getEmailId());
  }

  @Test(priority = 13, description = "Same stageId queried twice returns identical HTTP status and payload — getIsacStagedAccountStatusV1 is idempotent")
  public void idempotentCallsReturnIdenticalResults() throws IOException {

    String idempotentEmail = CommonUtil.generateRandomEmailId(10);
    String idempotentStageId = isacHelper.saveIsacIdVerification(
            storeNbr, cprAdult3HumanPatientId, idempotentEmail, reqIdString, reqTrackingString);
    Assert.assertNotNull(idempotentStageId, "saveIsacIdVerification must return a non-null stageId");

    Response<ServiceResponse> firstResponse =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    idempotentStageId, domainId,
                    reqIdString + CommonUtil.randomUUID(),
                    reqTrackingString + CommonUtil.randomUUID());
    Response<ServiceResponse> secondResponse =
            accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
                    idempotentStageId, domainId,
                    reqIdString + CommonUtil.randomUUID(),
                    reqTrackingString + CommonUtil.randomUUID());

    Assert.assertEquals(200, firstResponse.code(),
            "First call must return HTTP 200. Actual: " + firstResponse.code());
    Assert.assertEquals(200, secondResponse.code(),
            "Second call must return HTTP 200. Actual: " + secondResponse.code());

    GetIsacStagedAccountStatusV1Response firstPayload = ResponseUtil.parseResponse(
            gson, ((LinkedTreeMap<String, Object>) firstResponse.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    GetIsacStagedAccountStatusV1Response secondPayload = ResponseUtil.parseResponse(
            gson, ((LinkedTreeMap<String, Object>) secondResponse.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);

    Assert.assertEquals(firstPayload.getAccountState(), secondPayload.getAccountState(),
            "accountState must be identical for repeated calls on the same stageId");
    Assert.assertEquals(firstPayload.getEmailId(), secondPayload.getEmailId(),
            "emailId must be identical for repeated calls on the same stageId");
    Assert.assertEquals(firstPayload.getIdVerified(), secondPayload.getIdVerified(),
            "idVerified must be identical for repeated calls on the same stageId");
    Assert.assertEquals(firstPayload.getLinkExpired(), secondPayload.getLinkExpired(),
            "linkExpired must be identical for repeated calls on the same stageId");
    Assert.assertEquals(firstPayload.getDobRetriesExhausted(), secondPayload.getDobRetriesExhausted(),
            "dobRetriesExhausted must be identical for repeated calls on the same stageId");
  }

  // ─── CCM Flag-Dependent Tests (commented out — waiting for QA flag enablement) ────
  // TODO: Uncomment the following two tests (priority=14, priority=15) once the CCM flag
  //       is.isac.associate.triggered.account.creation.enabled is enabled in the QA environment.
  //       These tests assert cooldown behaviour that requires isIsacAssociateTriggeredAccountCreationEnabled()=true.
  //       They work locally when the flag is enabled but will FAIL in QA while the flag is disabled.
  //       Once the QA flag is enabled, uncomment and run — no other changes needed.
  // ──────────────────────────────────────────────────────────────────────────────────────


  /*@Test(priority = 14, description = "isInCooldown=true and coolDownStatus fields populated after exceeding the cooldown threshold — counter starts at 0 (reset by p=11), incremented 6 times here to reach threshold. Requires CCM flag isIsacAssociateTriggeredAccountCreationEnabled()=true")
  public void cooldownAboveThresholdReturnsCoolDownStatusFields() throws IOException {

    // Priority=11 (cooldownResetVerification) calls resetFailedAuthentication which zeros the counter.
    // So at this point the counter is 0. Increment 6 times to reach 6 total, which is above
    // the CCM threshold of 5 and guarantees isInCooldown=true.
    for (int i = 0; i < 5; i++) {
      pharmacyAuthServiceRetrofit.incrementFailedAuthentication(cooldownCustomerAccountId);
    }

    String cooldownStageId = isacHelper.saveIsacIdVerification(
        storeNbr, cprAdultHumanPatientId, cooldownEmailId, reqIdString, reqTrackingString);

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    Response<ServiceResponse> response =
        accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
            cooldownStageId, domainId, reqId, reqTrackingId);

    Assert.assertEquals(200, response.code(),
        "Expected HTTP 200 — getIsacStagedAccountStatusV1 always returns 200 regardless of cooldown state");
    Assert.assertNotNull(response.body(), "Response body must not be null for HTTP 200");
    GetIsacStagedAccountStatusV1Response payload = ResponseUtil.parseResponse(
        gson,
        ((LinkedTreeMap<String, Object>) response.body().getPayload()),
        GetIsacStagedAccountStatusV1Response.class);

    Assert.assertNotNull(payload, "Parsed payload must not be null");
    Assert.assertTrue(Boolean.TRUE.equals(payload.getIsInCooldown()),
        "isInCooldown must be true — 5 cumulative V1 pharmacy auth failures exceed the CCM threshold of 5");
    Assert.assertNotNull(payload.getCoolDownStatus(),
        "coolDownStatus must not be null when isInCooldown=true");
    Assert.assertEquals(5, payload.getCoolDownStatus().getFailedAttemptsCount(),
        "failedAttemptsCount must be 5 ");
    Assert.assertEquals(1, payload.getCoolDownStatus().getAttemptsRemaining(),
        "attemptsRemaining must be 1");
    Assert.assertNotNull(payload.getCoolDownStatus().getRemainingTime(),
        "remainingTime must not be null in CoolDownStatus");
  }

  @Test(priority = 15, description = "Cooldown full flow — create stageId, verify 200 with no cooldown, trigger cooldown "
              + "via 5 wrong DOB submissions, assert isInCooldown=true and coolDownStatus fields, "
              + "reset cooldown via resetFailedAuthentication, verify coolDownStatus is null "
              + "— all steps use the same customer. Requires CCM flag "
              + "isIsacAssociateTriggeredAccountCreationEnabled()=true")
  public void cooldownFullFlowSingleCustomer() throws Exception {

    // Step 1: Create a fresh Dotcom account and stageId (idVerified=false) for this test
    String flowEmail = CommonUtil.generateRandomEmailId(10);
    String flowCustomerId =
        CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(flowEmail);
    Assert.assertNotNull(flowCustomerId, "Dotcom account creation must return a valid CID");

    // Derive wrong DOB for triggering cooldown
    String wrongDob = "01011900";

    String birthDate = adult4HumanCprPatientRequest.getPatientInfo().getBirthDate();
    String correctDob = birthDate.substring(5, 7) + birthDate.substring(8, 10) + birthDate.substring(0, 4);

    String initialStageId = createStageIsacRecord(
        storeNbr, cprAdult4HumanPatientId, flowEmail, correctDob, Boolean.FALSE,
        reqIdString + CommonUtil.randomUUID(), reqTrackingString + CommonUtil.randomUUID());
    Assert.assertNotNull(initialStageId, "createStageIsacRecord must return a non-null stageId");

    // Step 2: Call getIsacStagedAccountStatusV1 — assert 200 with cooldown=null
    String trackID1 = CommonUtil.randomUUID();
    logFlowIdentifiers(domainId, reqIdString + trackID1, reqTrackingString + trackID1);

    Response<ServiceResponse> initialResponse =
        accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
            initialStageId, domainId, reqIdString + trackID1, reqTrackingString + trackID1);

    Assert.assertEquals(initialResponse.code(), 200,
        "Expected HTTP 200 before any DOB attempts");
    GetIsacStagedAccountStatusV1Response initialPayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) initialResponse.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    Assert.assertFalse(
        Boolean.TRUE.equals(initialPayload.getIsInCooldown()),
        "isInCooldown must be false — no failed DOB attempts yet");
    Assert.assertNull(
        initialPayload.getCoolDownStatus(),
        "coolDownStatus must be null — customer has not exceeded the cooldown threshold");

    // Step 3: Submit wrong DOB 5 times via validateDobHipaaInfoV1 to trigger cooldown
    for (int i = 0; i < 5; i++) {
      String trackID = CommonUtil.randomUUID();
      ValidateDobHipaaInfoV1Request wrongDobRequest =
          ValidateDobHipaaInfoV1Request.builder()
              .dob(wrongDob)
              .stageId(initialStageId)
              .build();
      accountOrchestratorRetrofit.validateDobHipaaInfoV1(
          flowCustomerId, domainId, wrongDobRequest,
          reqIdString + trackID, reqTrackingString + trackID);
    }

    // Step 4: Call getIsacStagedAccountStatusV1 — assert 200 with isInCooldown=true
    String trackID2 = CommonUtil.randomUUID();
    logFlowIdentifiers(domainId, reqIdString + trackID2, reqTrackingString + trackID2);

    Response<ServiceResponse> cooldownResponse =
        accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
            initialStageId, domainId, reqIdString + trackID2, reqTrackingString + trackID2);

    Assert.assertEquals(cooldownResponse.code(), 200,
        "Expected HTTP 200 after entering cooldown via wrong DOB attempts");
    GetIsacStagedAccountStatusV1Response cooldownPayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) cooldownResponse.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    Assert.assertTrue(
        Boolean.TRUE.equals(cooldownPayload.getIsInCooldown()),
        "isInCooldown must be true — 5 wrong DOB attempts exceed the cooldown threshold");
    Assert.assertNotNull(
        cooldownPayload.getCoolDownStatus(),
        "coolDownStatus must not be null when isInCooldown=true");
    Assert.assertEquals(cooldownPayload.getCoolDownStatus().getFailedAttemptsCount() ,5,
        "failedAttemptsCount must be 5 after wrong DOB submissions");
    Assert.assertEquals(cooldownPayload.getCoolDownStatus().getAttemptsRemaining(), 1,
        "attemptsRemaining must be 1 — cooldown threshold exceeded");

    // Step 5: Reset cooldown via resetFailedAuthentication (direct PharmacyAuth API — no lock logic)
    // NOTE: validateDobHipaaInfoV1(correctDob) cannot be used here because the service checks cooldown
    // BEFORE validating DOB — once in cooldown, correct DOB is rejected with 400 without ever being validated.
    Response<Void> resetResponse =
        pharmacyAuthServiceRetrofit.resetFailedAuthentication(flowCustomerId);
    Assert.assertEquals(resetResponse.code(), 200,
        "resetFailedAuthentication must return 200 to clear the cooldown");

    // Step 6: Call getIsacStagedAccountStatusV1 — assert 200 with cooldown=null after reset
    String trackID3 = CommonUtil.randomUUID();
    logFlowIdentifiers(domainId, reqIdString + trackID3, reqTrackingString + trackID3);

    Response<ServiceResponse> afterResetResponse =
        accountOrchestratorRetrofit.getIsacStagedAccountStatusV1(
            initialStageId, domainId, reqIdString + trackID3, reqTrackingString + trackID3);

    Assert.assertEquals(afterResetResponse.code(), 200,
        "Expected HTTP 200 after cooldown reset");
    GetIsacStagedAccountStatusV1Response afterResetPayload =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) afterResetResponse.body().getPayload()),
            GetIsacStagedAccountStatusV1Response.class);
    Assert.assertFalse(
        Boolean.TRUE.equals(afterResetPayload.getIsInCooldown()),
        "isInCooldown must be false after cooldown reset");
    Assert.assertNull(
        afterResetPayload.getCoolDownStatus(),
        "coolDownStatus must be null — no active cooldown after reset");
  }*/


  // ═══════════════════════════════════════════════════════════════════════
  // CLEANUP
  // ═══════════════════════════════════════════════════════════════════════

  @AfterClass
  void cleanUp() throws IOException {
    // Best-effort cooldown reset for cooldownCustomerAccountId (V1 increments from priority=11)
    if (cooldownCustomerAccountId != null) {
      pharmacyAuthServiceRetrofit.resetFailedAuthentication(cooldownCustomerAccountId);
    }
    if (customerAccountId != null) {
      pharmacyAuthServiceRetrofit.resetFailedAuthentication(customerAccountId);
    }

    // Mark all CPR accounts as ONLINE_DEL (patientStatusCode=20708) to trigger deletion
    adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);
    minorHumanCprPatientRequest.setPatientId(cprMinorHumanPatientId);
    adult2HumanCprPatientRequest.setPatientId(cprAdult2HumanPatientId);
    adult3HumanCprPatientRequest.setPatientId(cprAdult3HumanPatientId);
    adult4HumanCprPatientRequest.setPatientId(cprAdult4HumanPatientId);

    Arrays.asList(adultHumanCprPatientRequest, minorHumanCprPatientRequest,
                    adult2HumanCprPatientRequest, adult3HumanCprPatientRequest,
                    adult4HumanCprPatientRequest)
            .forEach(request -> {
              request.getPatientInfo().setPatientStatusCode(20708);
              try {
                deleteCprAccount(request);
              } catch (IOException e) {
                Reporter.logJSON("cleanUp.error",
                        "CPR account deletion failed for patientId=" + request.getPatientId()
                                + ": " + e.getMessage());
              }
            });
  }

  // ─── Private helpers ─────────────────────────────────────────────────

  // TODO: Uncomment when CCM flag-dependent testsar e enabled — used by p=15 (cooldownFullFlowSingleCustomer)

  private String createStageIsacRecord(String storeNbr, Integer patientId, String emailId,
                                       String dob, Boolean idVerified, String reqId, String reqTrackingId) throws IOException {
    CreateStageISACRecordV1Request request = CreateStageISACRecordV1Request.builder()
            .storeNbr(storeNbr)
            .patientId(String.valueOf(patientId))
            .emailId(emailId)
            .dob(dob)
            .idVerified(idVerified)
            .build();
    Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
            domainId, request, reqId, reqTrackingId);
    Assert.assertEquals(response.code(), 200,
            "createStageIsacRecord must succeed (HTTP 200)");
    Assert.assertNotNull(response.body(), "createStageIsacRecord response body must not be null");
    LinkedTreeMap<String, Object> payload =
            (LinkedTreeMap<String, Object>) response.body().getPayload();
    return (String) payload.get("stageId");
  }


  private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
    Response<ValidationServiceResponse> response = cprPatientUpdateRetrofit.validateProfile(cprRequest);
    if (response.code() != 202 || response.body() == null || !response.body().getErrors().isEmpty()) {
      Reporter.logJSON("cleanUp.deleteCprAccount",
              String.format("CPR account update to ONLINE_DEL (20708) failed for patientId=%s — HTTP %s",
                      cprRequest.getPatientId(), response.code()));
    }
  }
}
