package accountorchestrator.isac;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateStageISACRecordV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.isac.CreateStageISACRecordV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;


/**
 * E2E tests for POST /isac/v1/sync/create-stage-isac-record
 * (IsacV1SyncController → CreateStageIsacRecordService).
 *
 * Setup mirrors GetIsacStagedAccountStatusTest / SendIsacIdVerificationEmailStatusTest patterns:
 *  - CPR accounts via SharedUtils.createCprAccount() with dynamically generated adult DOB
 *  - .com accounts via isacHelper.astroCreatePerson()
 *  - Pharmacy account link via isacHelper.createPharmacyAccountEntity() with matching MMddyyyy DOB
 */
public class CreateStageIsacRecordTest {

    // ── Retrofit / helper clients ─────────────────────────────────────────────────────────────
    private AccountOrchestratorRetrofit  accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit     cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private IsacHelper                   isacHelper;
    private DigitalPharmacyAPIManager    digitalPharmacyAPIManager;
    private Gson                         gson;
    private ObjectMapper                 mapper = new ObjectMapper();

    // ── Constants ──────────────────────────────────────────────────────────────────────────────
    private String domainId      = "WM-PHARMACY";
    private String reqIdString   = "req-id-";
    private String reqTrackingString = "req-tracking-";

    /**
     * Adult DOB values generated dynamically in @BeforeClass.
     * Both derived from the same LocalDate so CPR and Account Entity always match.
     * adultDobCprFormat  → yyyy-MM-dd (CPR)
     * adultDobDpFormat   → MMddyyyy   (API request & Account Entity)
     * mismatchDobDpFormat → MMddyyyy, 3 years earlier → guaranteed DOB mismatch
     */
    private String adultDobCprFormat;
    private String adultDobDpFormat;
    private String mismatchDobDpFormat;

    private final DateTimeFormatter CPR_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter DP_DATE_FORMAT  = DateTimeFormatter.ofPattern("MMddyyyy");

    // ── Minor DOB ─────────────────────────────────────────────────────────────────────────────
    private String minorDobCprFormat;
    private String minorDobMMddyyyy;

    // ── Not-found test coordinates ────────────────────────────────────────────────────────────
    private String notFoundStoreNbr;
    private String notFoundPatientId;

    // ── Patient: MINOR ────────────────────────────────────────────────────────────────────────
    private ValidationServiceRequest minorCprRequest;
    private Integer                  minorPatientId;
    private String                   minorStoreNbr;

    // ── Patient: Adult1 (DOB mismatch test + INSERT true) ─────────────────────────────────────
    private ValidationServiceRequest adult1CprRequest;
    private Integer                  adult1PatientId;
    private String                   adult1StoreNbr;
    private String                   adult1EmailId;

    // ── Patient: Adult2 (INSERT false) ────────────────────────────────────────────────────────
    private ValidationServiceRequest adult2CprRequest;
    private Integer                  adult2PatientId;
    private String                   adult2StoreNbr;
    private String                   adult2EmailId;

    // ── Patient: Adult3 (.com + pharmacy → tests 14, 15, 16) ─────────────────────────────────
    private ValidationServiceRequest adult3CprRequest;
    private Integer                  adult3PatientId;
    private String                   adult3StoreNbr;
    private String                   adult3EmailId;
    private String                   adult3CustomerAccountId;

    // ── Patient: Adult4 (.com only, no pharmacy → test 22) ────────────────────────────────────
    private ValidationServiceRequest adult4CprRequest;
    private Integer                  adult4PatientId;
    private String                   adult4StoreNbr;
    private String                   adult4EmailId;

    // ── Patient: Adult5 (ISAC created false → test 17: same email + false → reject) ───────────
    private ValidationServiceRequest adult5CprRequest;
    private Integer                  adult5PatientId;
    private String                   adult5StoreNbr;
    private String                   adult5EmailId;

    // ── Patient: Adult6 (ISAC created false → test 18: diff email + false → reject) ───────────
    private ValidationServiceRequest adult6CprRequest;
    private Integer                  adult6PatientId;
    private String                   adult6StoreNbr;
    private String                   adult6EmailId;

    // ── Patient: Adult7 (ISAC created false → test 23: same email + true → upgrade) ───────────
    private ValidationServiceRequest adult7CprRequest;
    private Integer                  adult7PatientId;
    private String                   adult7StoreNbr;
    private String                   adult7OriginalEmailId;

    // ── Patient: Adult8 (ISAC cretaed true → test 19: same email + already true → reject) ──────
    private ValidationServiceRequest adult8CprRequest;
    private Integer                  adult8PatientId;
    private String                   adult8StoreNbr;
    private String                   adult8EmailId;

    // ── Patient: Adult9 (ISAC created false → test 24: diff email + true → UPDATE) ─────────────
    private ValidationServiceRequest adult9CprRequest;
    private Integer                  adult9PatientId;
    private String                   adult9StoreNbr;
    private String                   adult9EmailId;

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // SETUP
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @BeforeClass
    void setContext() throws Exception {
        accountOrchestratorRetrofit  = new AccountOrchestratorRetrofit();
        cprPatientUpdateRetrofit     = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        isacHelper                   = new IsacHelper();
        digitalPharmacyAPIManager    = new DigitalPharmacyAPIManager();
        gson                         = new Gson();

        // ── Minor DOB: 10 years old today (always a minor) ───────────────────────────────────
        LocalDate minorDob = LocalDate.now().minusYears(10);
        minorDobCprFormat = minorDob.format(CPR_DATE_FORMAT);
        minorDobMMddyyyy  = minorDob.format(DP_DATE_FORMAT);

        // ── Adult DOB: random age 25–60, random month & day offset ───────────────────────────
        // Both formats derived from the SAME LocalDate so CPR and Account Entity always match.
        int yearsAgo  = 25 + (int)(Math.random() * 36);   // 25–60
        int monthsAgo = (int)(Math.random() * 12);         // 0–11
        int daysAgo   = (int)(Math.random() * 28);         // 0–27  (cap at 28 to avoid invalid dates)
        LocalDate adultDob = LocalDate.now()
                .minusYears(yearsAgo)
                .minusMonths(monthsAgo)
                .minusDays(daysAgo);
        adultDobCprFormat   = adultDob.format(CPR_DATE_FORMAT);            // yyyy-MM-dd  → CPR
        adultDobDpFormat    = adultDob.format(DP_DATE_FORMAT);             // MMddyyyy    → API & Account Entity
        mismatchDobDpFormat = adultDob.minusYears(3).format(DP_DATE_FORMAT); // 3 yrs earlier → guaranteed mismatch
        Reporter.logJSON("Adult DOB generated", "cpr=" + adultDobCprFormat
                + "  dp=" + adultDobDpFormat + "  mismatch=" + mismatchDobDpFormat);

        // ── Not-found: 9-digit randoms — intentionally absent from CPR ───────────────────────
        notFoundStoreNbr  = CommonUtil.generateRandomNumber(9);
        notFoundPatientId = CommonUtil.generateRandomNumber(9);

        // ── Unique store numbers (6-digit) ────────────────────────────────────────────────────
        minorStoreNbr  = CommonUtil.generateRandomNumber(6);
        adult1StoreNbr = CommonUtil.generateRandomNumber(6);
        adult2StoreNbr = CommonUtil.generateRandomNumber(6);
        adult3StoreNbr = CommonUtil.generateRandomNumber(6);
        adult4StoreNbr = CommonUtil.generateRandomNumber(6);
        adult5StoreNbr = CommonUtil.generateRandomNumber(6);
        adult6StoreNbr = CommonUtil.generateRandomNumber(6);
        adult7StoreNbr = CommonUtil.generateRandomNumber(6);
        adult8StoreNbr = CommonUtil.generateRandomNumber(6);
        adult9StoreNbr = CommonUtil.generateRandomNumber(6);

        // ── Unique email IDs ──────────────────────────────────────────────────────────────────
        adult1EmailId         = CommonUtil.generateRandomEmailId(10);
        adult2EmailId         = CommonUtil.generateRandomEmailId(10);
        adult3EmailId         = CommonUtil.generateRandomEmailId(10);
        adult4EmailId         = CommonUtil.generateRandomEmailId(10);
        adult5EmailId         = CommonUtil.generateRandomEmailId(10);
        adult6EmailId         = CommonUtil.generateRandomEmailId(10);
        adult7OriginalEmailId = CommonUtil.generateRandomEmailId(10);
        adult8EmailId         = CommonUtil.generateRandomEmailId(10);
        adult9EmailId         = CommonUtil.generateRandomEmailId(10);

        // ── Create .com accounts FIRST — before any CPR calls ───────────────────────────────
        // astroCreatePersonWithRetry wraps astroCreatePerson with 3-attempt retry+backoff.
        // CID for adult3 is stored now and reused after the sleep; adult4 needs no CID.
        adult3CustomerAccountId = astroCreatePersonWithRetry(adult3EmailId);
        astroCreatePersonWithRetry(adult4EmailId);

        // ── Build CPR requests ────────────────────────────────────────────────────────────────
        // All adults use the same dynamically generated adultDobCprFormat (yyyy-MM-dd)
        minorCprRequest  = buildCprRequest(minorStoreNbr,  minorDobCprFormat);
        adult1CprRequest = buildCprRequest(adult1StoreNbr, adultDobCprFormat);
        adult2CprRequest = buildCprRequest(adult2StoreNbr, adultDobCprFormat);
        adult3CprRequest = buildCprRequest(adult3StoreNbr, adultDobCprFormat);
        adult4CprRequest = buildCprRequest(adult4StoreNbr, adultDobCprFormat);
        adult5CprRequest = buildCprRequest(adult5StoreNbr, adultDobCprFormat);
        adult6CprRequest = buildCprRequest(adult6StoreNbr, adultDobCprFormat);
        adult7CprRequest = buildCprRequest(adult7StoreNbr, adultDobCprFormat);
        adult8CprRequest = buildCprRequest(adult8StoreNbr, adultDobCprFormat);
        adult9CprRequest = buildCprRequest(adult9StoreNbr, adultDobCprFormat);

        // ── Create CPR accounts ───────────────────────────────────────────────────────────────
        minorPatientId  = SharedUtils.createCprAccount(minorCprRequest,  cprPatientUpdateRetrofit);
        adult1PatientId = SharedUtils.createCprAccount(adult1CprRequest, cprPatientUpdateRetrofit);
        adult2PatientId = SharedUtils.createCprAccount(adult2CprRequest, cprPatientUpdateRetrofit);
        adult3PatientId = SharedUtils.createCprAccount(adult3CprRequest, cprPatientUpdateRetrofit);
        adult4PatientId = SharedUtils.createCprAccount(adult4CprRequest, cprPatientUpdateRetrofit);
        adult5PatientId = SharedUtils.createCprAccount(adult5CprRequest, cprPatientUpdateRetrofit);
        adult6PatientId = SharedUtils.createCprAccount(adult6CprRequest, cprPatientUpdateRetrofit);
        adult7PatientId = SharedUtils.createCprAccount(adult7CprRequest, cprPatientUpdateRetrofit);
        adult8PatientId = SharedUtils.createCprAccount(adult8CprRequest, cprPatientUpdateRetrofit);
        adult9PatientId = SharedUtils.createCprAccount(adult9CprRequest, cprPatientUpdateRetrofit);

        // CPR creation is async — 90s gives extra buffer for all 10 accounts to propagate
        Thread.sleep(90000);

        // ── Adult3: CID already obtained above; link to pharmacy now CPR is propagated ───────
        createPharmacyWithRetry(adult3CustomerAccountId, adult3StoreNbr,
                String.valueOf(adult3PatientId), adultDobDpFormat);

        // ── Adult4: .com only (no pharmacy) — account already created above ──────────────────

        // ── Create ISAC records for update / rejection scenarios ────────────────────────────────
        createStageIsacRecord(adult5StoreNbr, adult5PatientId, adult5EmailId,         adultDobDpFormat, false);
        createStageIsacRecord(adult6StoreNbr, adult6PatientId, adult6EmailId,         adultDobDpFormat, false);
        createStageIsacRecord(adult7StoreNbr, adult7PatientId, adult7OriginalEmailId, adultDobDpFormat, false);
        createStageIsacRecord(adult8StoreNbr, adult8PatientId, adult8EmailId,         adultDobDpFormat, true);
        createStageIsacRecord(adult9StoreNbr, adult9PatientId, adult9EmailId,         adultDobDpFormat, false);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 1: INPUT VALIDATION — NULL FIELDS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 0, description = "null emailId → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_NullEmailId_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(null)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 1, description = "null storeNbr → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_NullStoreNbr_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(null, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(null)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 2, description = "null patientId → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_NullPatientId_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, null, domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(null)
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }


    @Test(priority = 3, description = "null dob → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_NullDob_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(null)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 4, description = "null idVerified → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_NullIdVerified_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(null)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 1: INPUT VALIDATION — BLANK FIELDS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 5, description = "blank emailId → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_BlankEmailId_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId("   ")
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 6, description = "blank storeNbr → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_BlankStoreNbr_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers("   ", String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr("   ")
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 7, description = "blank patientId → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_BlankPatientId_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, "   ", domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId("   ")
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 8, description = "blank dob → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_BlankDob_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob("   ")
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 1: DOB FORMAT VALIDATION
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 9, description = "invalid DOB format (yyyy-MM-dd instead of MMddyyyy) → 400 DPR-DPACCOR-1019")
    public void createStageIsacRecord_InvalidDobFormat_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob("1977-12-12")    // wrong format
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1019"),
                "Expected DPR-DPACCOR-1019 but got: " + errorResponse);
    }

    @Test(priority = 10, description = "invalid domainId → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_InvalidDomainId_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), "INVALID-DOMAIN", reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                "INVALID-DOMAIN",
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 2: CPR VALIDATION
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 11, description = "patient not found in CPR → 404 DPR-DPACCOR-6001")
    public void createStageIsacRecord_PatientNotFoundInCpr_Returns404() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(notFoundStoreNbr, notFoundPatientId, domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(CommonUtil.generateRandomEmailId(10))
                        .storeNbr(notFoundStoreNbr)
                        .patientId(notFoundPatientId)
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 404);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-6001"),
                "Expected DPR-DPACCOR-6001 but got: " + errorResponse);
    }

    @Test(priority = 12, description = "minor patient (age < 18) → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_MinorPatient_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(minorStoreNbr, String.valueOf(minorPatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(CommonUtil.generateRandomEmailId(10))
                        .storeNbr(minorStoreNbr)
                        .patientId(String.valueOf(minorPatientId))
                        .dob(minorDobMMddyyyy)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 13, description = "DOB in request does not match CPR DOB → 400 DPR-DPACCOR-1069")
    public void createStageIsacRecord_DobMismatchWithCpr_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        // adult1 CPR DOB = adultDobCprFormat; mismatchDobDpFormat is 3 years earlier → guaranteed mismatch
        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(mismatchDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1069"),
                "Expected DPR-DPACCOR-1069 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 3: .COM ACCOUNT EXISTS CHECKS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 14, description = ".com account exists + idVerified=true → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_DotComExistsIdVerifiedTrue_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult3StoreNbr, String.valueOf(adult3PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult3EmailId)
                        .storeNbr(adult3StoreNbr)
                        .patientId(String.valueOf(adult3PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 15, description = "pharmacy account exists via patient links → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_PharmacyAccountExistsViaPatientLinks_Returns400() throws IOException {
        // Random email (no .com) — only patient-link check triggers rejection
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult3StoreNbr, String.valueOf(adult3PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(CommonUtil.generateRandomEmailId(10))
                        .storeNbr(adult3StoreNbr)
                        .patientId(String.valueOf(adult3PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 16, description = ".com exists + idVerified=false + pharmacy via online identity → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_DotComExistsIdVerifiedFalsePharmacyViaOnlineIdentity_Returns400()
            throws IOException {
        // adult3 has .com + pharmacy. idVerified=false → AccountEntity online identity check finds pharmacy → REJECT
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult3StoreNbr, String.valueOf(adult3PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult3EmailId)
                        .storeNbr(adult3StoreNbr)
                        .patientId(String.valueOf(adult3PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 5: EXISTING ISAC RECORD — REJECTION SCENARIOS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 17, description = "existing ISAC + same emailId + idVerified=false → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_ExistingIsacSameEmailIdVerifiedFalse_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult5StoreNbr, String.valueOf(adult5PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult5EmailId)
                        .storeNbr(adult5StoreNbr)
                        .patientId(String.valueOf(adult5PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 18, description = "existing ISAC + different emailId + idVerified=false → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_ExistingIsacDifferentEmailIdVerifiedFalse_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult6StoreNbr, String.valueOf(adult6PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(CommonUtil.generateRandomEmailId(10))   // different email
                        .storeNbr(adult6StoreNbr)
                        .patientId(String.valueOf(adult6PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 19, description = "existing ISAC already idVerified=true + same email + true → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_ExistingIsacAlreadyIdVerifiedTrue_Returns400() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult8StoreNbr, String.valueOf(adult8PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult8EmailId)
                        .storeNbr(adult8StoreNbr)
                        .patientId(String.valueOf(adult8PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 5: SUCCESS — INSERT SCENARIOS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 20, description = "no .com, no pharmacy, no ISAC record, idVerified=true → INSERT 200")
    public void createStageIsacRecord_FreshInsertIdVerifiedTrue_Returns200() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on INSERT");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null on INSERT");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank on INSERT");
    }

    @Test(priority = 21, description = "no .com, no pharmacy, no ISAC record, idVerified=false → INSERT 200")
    public void createStageIsacRecord_FreshInsertIdVerifiedFalse_Returns200() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult2StoreNbr, String.valueOf(adult2PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult2EmailId)
                        .storeNbr(adult2StoreNbr)
                        .patientId(String.valueOf(adult2PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on INSERT");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null on INSERT");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank on INSERT");
    }

    @Test(priority = 22, description = ".com exists + idVerified=false + no pharmacy → INSERT 200")
    public void createStageIsacRecord_DotComExistsIdVerifiedFalseNoPharmacy_Returns200() throws IOException {
        // adult4: has .com via astroCreatePerson but no pharmacy account → online identity 204 → CONTINUE → INSERT
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult4StoreNbr, String.valueOf(adult4PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult4EmailId)
                        .storeNbr(adult4StoreNbr)
                        .patientId(String.valueOf(adult4PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on INSERT");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank");
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 5: SUCCESS — UPDATE SCENARIOS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 23, description = "existing ISAC idVerified=false + same email + idVerified=true → UPGRADE UPDATE 200")
    public void createStageIsacRecord_UpgradeIdVerifiedFalseToTrue_Returns200() throws IOException {
        // adult7 created with idVerified=false. Same email + idVerified=true → isUpgrade=true → UPDATE
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult7StoreNbr, String.valueOf(adult7PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult7OriginalEmailId)
                        .storeNbr(adult7StoreNbr)
                        .patientId(String.valueOf(adult7PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on UPDATE");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null on UPGRADE UPDATE");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank on UPGRADE UPDATE");
    }

    @Test(priority = 24, description = "existing ISAC + different emailId + idVerified=true → UPDATE with new email 200")
    public void createStageIsacRecord_UpdateWithDifferentEmail_Returns200() throws IOException {
        // adult9 created with email9 + idVerified=false. Different email + idVerified=true → UPDATE
        String trackID  = CommonUtil.randomUUID();
        String newEmail = CommonUtil.generateRandomEmailId(10);
        logFlowIdentifiers(adult9StoreNbr, String.valueOf(adult9PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(newEmail)
                        .storeNbr(adult9StoreNbr)
                        .patientId(String.valueOf(adult9PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on UPDATE");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null on UPDATE");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank on UPDATE");
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // NON-NUMERIC INPUTS → NumberFormatException → 500
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 25, description = "non-numeric patientId → 500 DPR-DPACCOR-1003")
    public void createStageIsacRecord_NonNumericPatientId_Returns500() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult1StoreNbr, "ABCDEF", domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr(adult1StoreNbr)
                        .patientId("ABCDEF")
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 500);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1003"),
                "Expected DPR-DPACCOR-1003 but got: " + errorResponse);
    }

    @Test(priority = 26, description = "non-numeric storeNbr → 500 DPR-DPACCOR-1003")
    public void createStageIsacRecord_NonNumericStoreNbr_Returns500() throws IOException {
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers("STORE-XYZ", String.valueOf(adult1PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult1EmailId)
                        .storeNbr("STORE-XYZ")
                        .patientId(String.valueOf(adult1PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 500);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1003"),
                "Expected DPR-DPACCOR-1003 but got: " + errorResponse);
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // STEP 5: EXISTING ISAC (idVerified=true in DB) — ADDITIONAL SCENARIOS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @Test(priority = 27, description = "existing ISAC idVerified=true + same email + idVerified=false → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_ExistingIsacTrueInDb_SameEmailIdVerifiedFalse_Returns400() throws IOException {
        // adult8 created with idVerified=true. Same email + idVerified=false → idVerified=false branch → REJECT
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult8StoreNbr, String.valueOf(adult8PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(adult8EmailId)
                        .storeNbr(adult8StoreNbr)
                        .patientId(String.valueOf(adult8PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 28, description = "existing ISAC idVerified=true + diff email + idVerified=false → 400 DPR-DPACCOR-1001")
    public void createStageIsacRecord_ExistingIsacTrueInDb_DiffEmailIdVerifiedFalse_Returns400() throws IOException {
        // adult8 created with idVerified=true. Different email + idVerified=false → idVerified=false branch → REJECT
        String trackID = CommonUtil.randomUUID();
        logFlowIdentifiers(adult8StoreNbr, String.valueOf(adult8PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(CommonUtil.generateRandomEmailId(10))   // different email
                        .storeNbr(adult8StoreNbr)
                        .patientId(String.valueOf(adult8PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(false)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 400);
        String errorResponse = CommonUtil.buildErrorMessage(gson, response);
        Assert.assertNotNull(errorResponse);
        Assert.assertTrue(errorResponse.contains("DPR-DPACCOR-1001"),
                "Expected DPR-DPACCOR-1001 but got: " + errorResponse);
    }

    @Test(priority = 29, description = "existing ISAC idVerified=true + diff email + idVerified=true → UPDATE 200")
    public void createStageIsacRecord_ExistingIsacTrueInDb_DiffEmailIdVerifiedTrue_Returns200() throws IOException {
        // adult8 created with idVerified=true. Different email + idVerified=true → diffEmail+true branch → UPDATE 200
        String trackID  = CommonUtil.randomUUID();
        String newEmail = CommonUtil.generateRandomEmailId(10);
        logFlowIdentifiers(adult8StoreNbr, String.valueOf(adult8PatientId), domainId, reqIdString + trackID, reqTrackingString + trackID);

        Response<ServiceResponse> response = accountOrchestratorRetrofit.createStageIsacRecordV1(
                domainId,
                CreateStageISACRecordV1Request.builder()
                        .emailId(newEmail)
                        .storeNbr(adult8StoreNbr)
                        .patientId(String.valueOf(adult8PatientId))
                        .dob(adultDobDpFormat)
                        .idVerified(true)
                        .build(),
                reqIdString + trackID,
                reqTrackingString + trackID);

        Assert.assertEquals(response.code(), 200);
        Assert.assertNotNull(response.body(), "Response body must not be null");
        Assert.assertNotNull(response.body().getPayload(), "Payload must not be null on UPDATE");
        String stageId = parseStageId(response);
        Assert.assertNotNull(stageId, "stageId must not be null on UPDATE");
        Assert.assertFalse(stageId.isBlank(), "stageId must not be blank on UPDATE");
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // CLEANUP
    // ══════════════════════════════════════════════════════════════════════════════════════════

    @AfterClass
    void cleanUp() {
        // ── Delete pharmacy account created for adult3 ────────────────────────────────────────
        if (adult3CustomerAccountId != null) {
            try {
                accountEntityServiceRetrofit.deleteAccountV1(
                        adult3CustomerAccountId, domainId, reqIdString, reqTrackingString);
            } catch (IOException e) {
                Reporter.logJSON("cleanUp warning",
                        "Pharmacy account delete failed for customerId: " + adult3CustomerAccountId);
            }
        }

        // ── Delete all CPR accounts ───────────────────────────────────────────────────────────
        Arrays.asList(
                minorCprRequest,  adult1CprRequest, adult2CprRequest, adult3CprRequest,
                adult4CprRequest, adult5CprRequest, adult6CprRequest, adult7CprRequest,
                adult8CprRequest, adult9CprRequest
        ).forEach(req -> {
            if (req != null) {
                req.getPatientInfo().setPatientStatusCode(20708); // ONLINE_DEL
                try {
                    deleteCprAccount(req);
                } catch (IOException e) {
                    Reporter.logJSON("cleanUp warning",
                            "CPR delete failed for patientId: " + req.getPatientId());
                }
            }
        });

        // Note: .com accounts (adult3, adult4) and ISAC stage records (adult5–9) cannot be
        // deleted — no delete API is available in the framework for these resource types.
    }

    // ══════════════════════════════════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════════════════════════════════

    /**
     * Logs flow identifiers for debugging test execution.
     */
    private void logFlowIdentifiers(String storeNbr, String patientId, String domainId,
                                    String reqId, String reqTrackingId) {
        Reporter.logJSON("Store nbr", storeNbr);
        Reporter.logJSON("Patient Id", patientId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    /**
     * Wraps {@code isacHelper.astroCreatePerson} with up to 3 attempts and back-off.
     * {@code astroCreatePerson} internally calls {@code getCidFromEmailUsingAstro} which asserts
     * HTTP 200 — the .com account creation is async and CID lookup returns 400 until propagated.
     * Retrying after a longer wait (30s / 60s) gives Astro time to propagate the new account.
     */
    private String astroCreatePersonWithRetry(String emailId) throws Exception {
        int[] delaysMs = {30000, 60000};
        Throwable lastFailure = null;
        for (int attempt = 0; attempt <= 2; attempt++) {
            try {
                return isacHelper.astroCreatePerson(digitalPharmacyAPIManager, emailId);
            } catch (AssertionError | RuntimeException e) {
                lastFailure = e;
                Reporter.logJSON("astroCreatePerson attempt " + (attempt + 1) + " failed for "
                        + emailId, e.getMessage());
                if (attempt < 2) Thread.sleep(delaysMs[attempt]);
            }
        }
        throw new RuntimeException(
                "Setup failed: astroCreatePerson for email=" + emailId + " after 3 attempts",
                lastFailure);
    }

    /**
     * Create pharmacy account in Account Entity with up to 3 attempts if account creation fails.
     * Waits 10 seconds between attempts to allow transient errors to recover.
     */
    private void createPharmacyWithRetry(String customerId, String storeNbr,
                                         String patientId, String dob) throws Exception {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                getCreatePharmacyAccountV1Request(storeNbr, patientId, dob);
        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse>
                response = null;

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerId,
                            domainId,
                            createPharmacyAccountV1Request,
                            reqIdString,
                            reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account Entity create account creation failed. HttpStatusCode : " + response.code());
                }
                Thread.sleep(10000); // wait 10s before retry
            } else {
                break;
            }
        }
    }

    /**
     * Builds a CreatePharmacyAccountV1Request with idVerification source.
     */
    private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
            String storeNbr, String patientId, String dob) {
        return CreatePharmacyAccountV1Request.builder()
                .accountCreationSource("idVerification")
                .customerInfo(
                        CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                .storeNbr(storeNbr)
                                .patientId(patientId)
                                .dob(dob)
                                .build())
                .build();
    }

    /**
     * Builds a CPR request from the shared template, setting random first/last name,
     * the given storeNbr and birthDate (yyyy-MM-dd format).
     */
    private ValidationServiceRequest buildCprRequest(String storeNbr, String birthDate) throws IOException {
        ValidationServiceRequest req = SharedUtils.getTemplateCprRequest(mapper);
        req.setStoreNbr(Integer.parseInt(storeNbr));
        req.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5).toUpperCase());
        req.getPatientInfo().setLastName(RandomStringUtils.randomAlphabetic(5).toUpperCase());
        req.getPatientInfo().setBirthDate(birthDate);
        req.getPatientCommunicationInfo().get(0).setCommunicationId(CommonUtil.generateRandomNumber(10));
        return req;
    }

    /**
     * Created an ISAC stage record via the API. Retries up to 3 times with back-off.
     * Used from @BeforeClass to pre-condition ISAC update / rejection tests.
     */
    private void createStageIsacRecord(String storeNbr, Integer patientId, String emailId,
                                String dob, boolean idVerified) throws Exception {
        String trackID = CommonUtil.randomUUID();
        CreateStageISACRecordV1Request request = CreateStageISACRecordV1Request.builder()
                .emailId(emailId)
                .storeNbr(storeNbr)
                .patientId(String.valueOf(patientId))
                .dob(dob)
                .idVerified(idVerified)
                .build();

        int[] delaysMs = {10000, 20000, 30000};
        for (int attempt = 0; attempt <= 2; attempt++) {
            Response<ServiceResponse> response = accountOrchestratorRetrofit
                    .createStageIsacRecordV1(domainId, request,
                            reqIdString + trackID, reqTrackingString + trackID);
            if (response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null) {
                return;
            }
            Reporter.logJSON("createStageIsacRecord attempt " + (attempt + 1) + " failed — HTTP "
                    + response.code(), "storeNbr=" + storeNbr + " patientId=" + patientId);
            if (attempt < 2) Thread.sleep(delaysMs[attempt]);
        }
        throw new RuntimeException(
                "Setup failed: could not seed ISAC record for storeNbr=" + storeNbr
                        + " patientId=" + patientId);
    }

    /**
     * Parses the {@code stageId} string from a successful (200) response payload
     * by deserializing the payload into a typed {@link CreateStageISACRecordV1Response}.
     */
    private String parseStageId(Response<ServiceResponse> response) {
        Assert.assertNotNull(response.body().getPayload(), "Payload should not be null on 200 response");
        CreateStageISACRecordV1Response stageResponse =
                mapper.convertValue(response.body().getPayload(), CreateStageISACRecordV1Response.class);
        Assert.assertNotNull(stageResponse, "Deserialized response should not be null");
        return stageResponse.getStageId();
    }

    /**
     * Marks a CPR account as soft-deleted (patientStatusCode 20708 = ONLINE_DEL).
     */
    private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
            // deleted successfully
        } else {
            Reporter.logJSON("cleanUp warning",
                    String.format("CPR delete returned status %d for patientId %s",
                            response.code(), cprRequest.getPatientId()));
        }
    }
}
