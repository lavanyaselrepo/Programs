package accountorchestrator.isac;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.IsacHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.isac.CreateAccountByISACInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil.logFlowIdentifiers;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CreateAccountByISACInfoTest {
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private Gson gson;
    private String stageId, stageId2 = null;
    private String adult2StageId = null;
    private IsacHelper isacHelper;
    private DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    ValidationServiceRequest adultHumanCprPatientRequest,
            adult2HumanCprPatientRequest,
            minorHumanCprPatientRequest;
    Integer cprAdultHumanPatientId = 0;
    Integer cprAdult2HumanPatientId = 0;
    private String storeNbr;
    private String customerAccountId, customerAccountId2;
    private ObjectMapper mapper = new ObjectMapper();
    List<Integer> patientIds = new ArrayList<>();
    private String emailId, emailId2 = null;
    private String adult2CustomerAccountId;
    private String adult2EmailId = null;

    private String dobOfAdultPatient = "12121977";

    @BeforeClass
    void setContext() throws IOException {
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        gson = new Gson();
        storeNbr = CommonUtil.generateRandomNumber(6);
        isacHelper = new IsacHelper();

        adultHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);

        patientIds = isacHelper.createAllCprAccounts(
                adultHumanCprPatientRequest,
                minorHumanCprPatientRequest,
                adult2HumanCprPatientRequest,
                storeNbr);

        cprAdultHumanPatientId = patientIds.get(0);
        emailId = CommonUtil.generateRandomEmailId(10);
        emailId2 = CommonUtil.generateRandomEmailId(10);
        customerAccountId2 = isacHelper.astroCreatePerson(digitalPharmacyAPIManager, emailId2);
        customerAccountId = isacHelper.astroCreatePerson(digitalPharmacyAPIManager, emailId);


        stageId = isacHelper.saveIsacIdVerification(
                storeNbr,
                cprAdultHumanPatientId,
                emailId,
                reqIdString,
                reqTrackingString);

        cprAdult2HumanPatientId = patientIds.get(2);
        adult2EmailId = CommonUtil.generateRandomEmailId(10);
        adult2CustomerAccountId = isacHelper.astroCreatePerson(digitalPharmacyAPIManager, adult2EmailId);
        adult2StageId = isacHelper.saveIsacIdVerification(
                storeNbr,
                cprAdult2HumanPatientId,
                adult2EmailId,
                reqIdString,
                reqTrackingString);
    }

    @Test(priority = 0, description = "null StageId for createAccountByISACInfoV1")
    public void nullStageIdForCreateAccountByISACInfoV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob(dobOfAdultPatient)
                        .stageId(null)
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        String errorResponse = CommonUtil.buildErrorMessage(gson, createAccountByISACInfoV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "Error response: \n" +
                "Code: DPR-DPACCOR-1001\n" +
                "Message: Invalid input request. StageId is null/empty\n", errorResponse);
    }

    @Test(priority = 1, description = "null DOB for createAccountByISACInfoV1")
    public void nullDobForCreateAccountByISACInfoV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob("")
                        .stageId("3d6c92dc-4171-4311-a53d-1a43aff0d266")
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        String errorResponse = CommonUtil.buildErrorMessage(gson, createAccountByISACInfoV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "Error response: \n" +
                "Code: DPR-DPACCOR-1001\n" +
                "Message: Invalid input request. dob can't be null/empty\n", errorResponse);
    }

    @Test(priority = 2, description = "invalid DomainId for createAccountByISACInfoV1")
    public void invalidDomainIdForCreateAccountByISACInfoV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob(dobOfAdultPatient)
                        .stageId("3d6c92dc-4171-4311-a53d-1a43aff0d266")
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, "WM-PHARMACY-INVALID", createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        String errorResponse = CommonUtil.buildErrorMessage(gson, createAccountByISACInfoV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "Error response: \n" +
                "Code: DPR-DPACCOR-1001\n" +
                "Message: Invalid input request. domainId WM-PHARMACY-INVALID in input is invalid\n", errorResponse);
    }

    @Test(priority = 3, description = "dob mismatch error for createAccountByISACInfoV1")
    public void dobMismatchForCreateAccountByISACInfoV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob("12121980")
                        .stageId(stageId)
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        String errorResponse = CommonUtil.buildErrorMessage(gson, createAccountByISACInfoV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "Error response: \n" +
                "Code: DPR-DPACCOR-1052\n" +
                "Message: Couldn't create pharmacy profile due to mismatch of dob.\n", errorResponse);
    }

    @Test(priority = 4, description = "400 error for createAccountByISACInfoV1")
    public void CreateAccountByISACInfoV1400Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob("12121980")
                        .stageId(stageId)
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(400, createAccountByISACInfoV1Response.code());
    }

    @Test(priority = 5, description = "successful createAccountByISACInfoV1")
    public void createAccountByISACInfoV1Success() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob(dobOfAdultPatient)
                        .stageId(stageId)
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(200, createAccountByISACInfoV1Response.code());
    }

    @Test(priority = 6, description = "409 conflict for createAccountByISACInfoV1")
    public void createAccountByISACInfoV1ConflictScenario() throws IOException {

        stageId2 = isacHelper.saveIsacIdVerification(
                storeNbr,
                cprAdultHumanPatientId,
                emailId2,
                reqIdString,
                reqTrackingString);

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);
        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob(dobOfAdultPatient)
                        .stageId(stageId2)
                        .tAndCPolicyLanguage("EN")
                        .build();
        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        customerAccountId2, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(409, createAccountByISACInfoV1Response.code());
    }

    // Note: If this test case is failing , please check the CCM Value and if it is not sql , then this test case can be commented for auto run
    @Test(priority = 7, description = "createAccountByISACInfoV1 success and verifying the creation of account verification")
    public void createAccountByISACInfoV1SuccessAndVerifyingAccountVerificationCreationSuccess() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the createAccountByISACInfoV1 request
        CreateAccountByISACInfoV1Request createAccountByISACInfoV1Request =
                CreateAccountByISACInfoV1Request.builder()
                        .dob(dobOfAdultPatient)
                        .stageId(adult2StageId)
                        .tAndCPolicyLanguage("EN")
                        .build();

        // Step - 3: Calling createAccountByISACInfoV1
        Response<ServiceResponse> createAccountByISACInfoV1Response =
                accountOrchestratorRetrofit.createAccountByISACInfoV1(
                        adult2CustomerAccountId, domainId, createAccountByISACInfoV1Request, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(200, createAccountByISACInfoV1Response.code());

        // Calling Get Account Verification
        Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> getAccountVerificationV1ServiceResponse =
                accountEntityServiceRetrofit.getAccountVerificationV1(
                        adult2CustomerAccountId, domainId, reqId, reqTrackingId, true);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1ServiceResponse);

        // Asserting response
        Assert.assertNotNull(getAccountVerificationV1ServiceResponse.body());
        LinkedTreeMap<String, Object> payload = (LinkedTreeMap<String, Object>) getAccountVerificationV1ServiceResponse.body().getPayload();
        LinkedTreeMap<String, Object> idVerifiedPayload = (LinkedTreeMap<String, Object>) payload.get("idVerified");
        LinkedTreeMap<String, Object> twoFASetUpPayload = (LinkedTreeMap<String, Object>) payload.get("twoFASetUp");

        assertNotNull(getAccountVerificationV1ServiceResponse);
        assertNotNull(idVerifiedPayload);
        assertEquals("RX_STORE", idVerifiedPayload.get("verificationSource"));
        assertEquals("ACTIVE", twoFASetUpPayload.get("status"));
        assertNotNull(idVerifiedPayload.get("data"));
        assertNotNull(twoFASetUpPayload.get("data"));
    }

    @AfterClass
    void cleanUp() {
        // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
        // delete CPR account
        adultHumanCprPatientRequest.setPatientId(cprAdultHumanPatientId);

        Arrays.asList(adultHumanCprPatientRequest, minorHumanCprPatientRequest)
                .forEach(
                        request -> {
                            request.getPatientInfo().setPatientStatusCode(20708);
                            try {
                                deleteCprAccount(request);
                            } catch (IOException e) {
                            }
                        });
    }

    private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
        } else {
            Reporter.logJSON("errorMessage",
                    String.format("CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                            cprRequest.getPatientId(),response.code()));
        }
    }
}
