package accountorchestrator.isac;


import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.PhotoId;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.SaveIsacIdVerificationRequestV1;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.SaveIsacIdVerificationResponseV1;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CASignUpV2Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AccountOrchestratorSaveIsacIdVerificationTestFlow {
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private String accountType = "INDIVIDUAL";
    private String customerType = "INDIVIDUAL";
    private String invalidPhotoIdExpirationDateFormat = "2030-12-30";
    private String commonPhoneNo = "1234567829";
    private String commonPassword = "Test@12345";
    private String trackID = CommonUtil.randomUUID();

    private final Gson gson = new GsonBuilder().create();
    private final ObjectMapper mapper = new ObjectMapper();

    private String minorCustomerAccountId = null;
    private String minorStoreNbr = null;
    private String minorFirstName = null;
    private String minorLastName = null;
    private String minorPhoneNbr = null;
    private String minorEmailId = null;
    private String minorPhotoIdType = null;
    private String minorPhotoIdNbr = null;
    private String minorPhotoIdState = null;
    private String minorPhotoIdCountry = null;
    private String minorPhotoIdExpirationDate = null;

    private String adult1CustomerAccountId = null;
    private String adult1StoreNbr = null;
    private String adult1FirstName = null;
    private String adult1LastName = null;
    private String adult1PhoneNbr = null;
    private String adult1EmailId = null;
    private String adult1PhotoIdType = null;
    private String adult1PhotoIdNbr = null;
    private String adult1PhotoIdState = null;
    private String adult1PhotoIdCountry = null;
    private String adult1PhotoIdExpirationDate = null;

    private String adult2CustomerAccountId = null;
    private String adult2StoreNbr = null;
    private String adult2FirstName = null;
    private String adult2LastName = null;
    private String adult2PhoneNbr = null;
    private String adult2EmailId = null;
    private String adult2PhotoIdType = null;
    private String adult2PhotoIdNbr = null;
    private String adult2PhotoIdState = null;
    private String adult2PhotoIdCountry = null;
    private String adult2PhotoIdExpirationDate = null;

    private String adult3CustomerAccountId = null;
    private String adult3StoreNbr = null;
    private String adult3FirstName = null;
    private String adult3LastName = null;
    private String adult3PhoneNbr = null;
    private String adult3EmailId = null;
    private String adult3PhotoIdType = null;
    private String adult3PhotoIdNbr = null;
    private String adult3PhotoIdState = null;
    private String adult3PhotoIdCountry = null;
    private String adult3PhotoIdExpirationDate = null;

    private String adult4CustomerAccountId = null;
    private String adult4StoreNbr = null;
    private String adult4FirstName = null;
    private String adult4LastName = null;
    private String adult4PhoneNbr = null;
    private String adult4EmailId = null;
    private String adult4PhotoIdType = null;
    private String adult4PhotoIdNbr = null;
    private String adult4PhotoIdState = null;
    private String adult4PhotoIdCountry = null;
    private String adult4PhotoIdExpirationDate = null;

    private Integer cprMinorHumanPatientId,
            cprAdult1HumanPatientId,
            cprAdult2HumanPatientId,
            cprAdult3HumanPatientId,
            cprAdult4HumanPatientId;

    ValidationServiceRequest minorHumanCprPatientRequest = null,
            adult1HumanCprPatientRequest,
            adult2HumanCprPatientRequest,
            adult3HumanCprPatientRequest,
            adult4HumanCprPatientRequest;

    @BeforeClass
    void setContext() throws Exception {
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();

        minorStoreNbr = CommonUtil.generateRandomNumber(6);
        minorFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        minorLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        minorPhoneNbr = CommonUtil.generateRandomNumber(10);
        minorEmailId = CommonUtil.generateRandomEmailId(10);
        minorPhotoIdType = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        minorPhotoIdNbr = CommonUtil.generateRandomNumber(8);
        minorPhotoIdState = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        minorPhotoIdCountry = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        minorPhotoIdExpirationDate = "07-24-2030";

        adult1StoreNbr = CommonUtil.generateRandomNumber(6);
        adult1FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult1LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult1PhoneNbr = CommonUtil.generateRandomNumber(10);
        adult1EmailId = CommonUtil.generateRandomEmailId(10);
        adult1PhotoIdType = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        adult1PhotoIdNbr = CommonUtil.generateRandomNumber(8);
        adult1PhotoIdState = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult1PhotoIdCountry = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult1PhotoIdExpirationDate = "07-24-2030";

        adult2StoreNbr = CommonUtil.generateRandomNumber(6);
        adult2FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult2LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult2PhoneNbr = CommonUtil.generateRandomNumber(10);
        adult2EmailId = CommonUtil.generateRandomEmailId(10);
        adult2PhotoIdType = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        adult2PhotoIdNbr = CommonUtil.generateRandomNumber(8);
        adult2PhotoIdState = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult2PhotoIdCountry = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult2PhotoIdExpirationDate = "07-24-2030";

        adult3StoreNbr = CommonUtil.generateRandomNumber(6);
        adult3FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult3LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult3PhoneNbr = CommonUtil.generateRandomNumber(10);
        adult3EmailId = CommonUtil.generateRandomEmailId(10);
        adult3PhotoIdType = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        adult3PhotoIdNbr = CommonUtil.generateRandomNumber(8);
        adult3PhotoIdState = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult3PhotoIdCountry = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult3PhotoIdExpirationDate = "07-24-2030";

        adult4StoreNbr = CommonUtil.generateRandomNumber(6);
        adult4FirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult4LastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        adult4PhoneNbr = CommonUtil.generateRandomNumber(10);
        adult4EmailId = CommonUtil.generateRandomEmailId(10);
        adult4PhotoIdType = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        adult4PhotoIdNbr = CommonUtil.generateRandomNumber(8);
        adult4PhotoIdState = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult4PhotoIdCountry = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        adult4PhotoIdExpirationDate = "07-24-2030";

        // Creating CPR account for all
        createAllCprAccounts();

        // Creating Astro account for adult1 because customerAccountId is needed to create pharmacy account
        adult1CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(adult1EmailId,commonPassword,commonPhoneNo,adult1FirstName,adult1LastName,trackID);

        // Creating Pharmacy account for adult1 to test has pharmacy account flow
        createPharmacyAccountEntity(adult1CustomerAccountId,
                adult1StoreNbr,
                String.valueOf(cprAdult1HumanPatientId),
                "12121977");

        // Creating Astro account for adult3 to test customer account found but pharmacy account don't exist case
        adult3CustomerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAP(adult3EmailId,commonPassword,commonPhoneNo,adult3FirstName,adult3LastName,trackID);

        // Creating Isac Id verification for adult3 to test update record flow
        saveIsacIdVerification(getSaveIsacIdentityVerificationRequestForAdult3());

        // Creating Isac Id verification for adult4 to test update email counter flow
        saveIsacIdVerification(getSaveIsacIdentityVerificationRequestForAdult4());
    }

    private void createAllCprAccounts() throws IOException {
        // Create CPR Account before running "create pharmacy account" related test cases
        minorHumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        minorHumanCprPatientRequest.getPatientInfo().setFirstName(minorFirstName);
        minorHumanCprPatientRequest.getPatientInfo().setLastName(minorLastName);
        minorHumanCprPatientRequest.setStoreNbr(Integer.parseInt(minorStoreNbr));
        minorHumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(minorPhoneNbr);
        minorHumanCprPatientRequest
                .getPatientInfo()
                .setBirthDate((LocalDate.now().getYear() - 1) + "-01-01");

        adult1HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult1HumanCprPatientRequest.getPatientInfo().setFirstName(adult1FirstName);
        adult1HumanCprPatientRequest.getPatientInfo().setLastName(adult1LastName);
        adult1HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult1StoreNbr));
        adult1HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult1PhoneNbr);
        adult1HumanCprPatientRequest.getPatientInfo().setBirthDate("1977-12-12");

        adult2HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult2HumanCprPatientRequest.getPatientInfo().setFirstName(adult2FirstName);
        adult2HumanCprPatientRequest.getPatientInfo().setLastName(adult2LastName);
        adult2HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult2StoreNbr));
        adult2HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult2PhoneNbr);
        adult2HumanCprPatientRequest.getPatientInfo().setBirthDate("1978-12-12");

        adult3HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult3HumanCprPatientRequest.getPatientInfo().setFirstName(adult3FirstName);
        adult3HumanCprPatientRequest.getPatientInfo().setLastName(adult3LastName);
        adult3HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult3StoreNbr));
        adult3HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult3PhoneNbr);
        adult3HumanCprPatientRequest.getPatientInfo().setBirthDate("1978-12-12");

        adult3HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult3HumanCprPatientRequest.getPatientInfo().setFirstName(adult3FirstName);
        adult3HumanCprPatientRequest.getPatientInfo().setLastName(adult3LastName);
        adult3HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult3StoreNbr));
        adult3HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult3PhoneNbr);
        adult3HumanCprPatientRequest.getPatientInfo().setBirthDate("1978-12-12");

        adult4HumanCprPatientRequest = SharedUtils.getTemplateCprRequest(mapper);
        adult4HumanCprPatientRequest.getPatientInfo().setFirstName(adult4FirstName);
        adult4HumanCprPatientRequest.getPatientInfo().setLastName(adult4LastName);
        adult4HumanCprPatientRequest.setStoreNbr(Integer.parseInt(adult4StoreNbr));
        adult4HumanCprPatientRequest.getPatientCommunicationInfo().get(0).setCommunicationId(adult4PhoneNbr);
        adult4HumanCprPatientRequest.getPatientInfo().setBirthDate("1978-12-12");

        cprMinorHumanPatientId =
                SharedUtils.createCprAccount(minorHumanCprPatientRequest, cprPatientUpdateRetrofit);
        cprAdult1HumanPatientId =
                SharedUtils.createCprAccount(adult1HumanCprPatientRequest, cprPatientUpdateRetrofit);
        cprAdult2HumanPatientId =
                SharedUtils.createCprAccount(adult2HumanCprPatientRequest, cprPatientUpdateRetrofit);
        cprAdult3HumanPatientId =
                SharedUtils.createCprAccount(adult3HumanCprPatientRequest, cprPatientUpdateRetrofit);
        cprAdult4HumanPatientId =
                SharedUtils.createCprAccount(adult4HumanCprPatientRequest, cprPatientUpdateRetrofit);

        // This is needed because CPR account creation is async, and it usually takes a couple of
        // seconds to reflect account creation
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void createPharmacyAccountEntity(String customerAccountId, String storeNbr, String patientId, String dob) throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                CreatePharmacyAccountV1Request.builder()
                        .customerInfo(
                                CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                        .dob(dob)
                                        .storeNbr(storeNbr)
                                        .patientId(patientId)
                                        .build())
                        .accountCreationSource("idVerification")
                        .build();

        // This will try to create an account in Account Entity 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ServiceResponse>
                    response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId,
                            domainId,
                            createPharmacyAccountV1Request,
                            CommonUtil.randomUUID(),
                            CommonUtil.randomUUID());
            if (!(response.code() == 200 && response.body() != null)) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Account creation failed in Account Entity. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    /**
     * save Isac Id verification
     *
     * @throws IOException
     */
    public void saveIsacIdVerification(SaveIsacIdVerificationRequestV1 saveIsacIdVerificationRequestV1) throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> response = null;

        // This will try to save isac id verification, 3 times if it fails
        for (int i = 0; i < 3; i++) {
            response = accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                    saveIsacIdVerificationRequestV1,
                    reqId,
                    reqTrackingId);

            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "save Isac Id verification failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    /**
     * Build ca create person request
     *
     * @return
     */
    private CASignUpV2Request getCASignUpV2Request(String firstName, String lastName, String customerEmailId) {
        List<CASignUpV2Request.PersonName> personNames = new ArrayList<>();
        personNames.add(
                CASignUpV2Request.PersonName.builder()
                .firstName(firstName)
                .lastName(lastName).build());

        List<CASignUpV2Request.Account> accounts = new ArrayList<>();
        accounts.add(CASignUpV2Request.Account.builder()
                .accountType(accountType)
                .emailAddress(customerEmailId).build());

        CASignUpV2Request.Person person = CASignUpV2Request.Person.builder()
                .customerType(customerType)
                .names(personNames)
                .accounts(accounts)
                .build();

        return CASignUpV2Request.builder()
                .payload( CASignUpV2Request.Payload.builder()
                        .tenantId("WALMART.COM")
                        .realmId("WALMART.COM")
                        .person(person)
                        .password("Walmart@123")
                        .build())
                .build();
    }

    private SaveIsacIdVerificationRequestV1 getSaveIsacIdentityVerificationRequestForMinor() {
        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestV1 = new SaveIsacIdVerificationRequestV1();
        saveIsacIdentityVerificationRequestV1.setEmailId(minorEmailId);
        saveIsacIdentityVerificationRequestV1.setPatientId(String.valueOf(cprMinorHumanPatientId));
        saveIsacIdentityVerificationRequestV1.setStoreNbr(minorStoreNbr);
        saveIsacIdentityVerificationRequestV1.setIdVerified(Boolean.TRUE);

        PhotoId photoId = new PhotoId();
        photoId.setType(minorPhotoIdType);
        photoId.setNumber(minorPhotoIdNbr);
        photoId.setState(minorPhotoIdState);
        photoId.setCountry(minorPhotoIdCountry);
        photoId.setExpirationDate(minorPhotoIdExpirationDate);
        saveIsacIdentityVerificationRequestV1.setPhotoId(photoId);
        return saveIsacIdentityVerificationRequestV1;
    }

    private SaveIsacIdVerificationRequestV1 getSaveIsacIdentityVerificationRequestForAdult1() {
        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestV1 = new SaveIsacIdVerificationRequestV1();
        saveIsacIdentityVerificationRequestV1.setEmailId(adult1EmailId);
        saveIsacIdentityVerificationRequestV1.setPatientId(String.valueOf(cprAdult1HumanPatientId));
        saveIsacIdentityVerificationRequestV1.setStoreNbr(adult1StoreNbr);
        saveIsacIdentityVerificationRequestV1.setIdVerified(Boolean.TRUE);

        PhotoId photoId = new PhotoId();
        photoId.setType(adult1PhotoIdType);
        photoId.setNumber(adult1PhotoIdNbr);
        photoId.setState(adult1PhotoIdState);
        photoId.setCountry(adult1PhotoIdCountry);
        photoId.setExpirationDate(adult1PhotoIdExpirationDate);
        saveIsacIdentityVerificationRequestV1.setPhotoId(photoId);
        return saveIsacIdentityVerificationRequestV1;
    }

    private SaveIsacIdVerificationRequestV1 getSaveIsacIdentityVerificationRequestForAdult2() {
        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestV1 = new SaveIsacIdVerificationRequestV1();
        saveIsacIdentityVerificationRequestV1.setEmailId(adult2EmailId);
        saveIsacIdentityVerificationRequestV1.setPatientId(String.valueOf(cprAdult2HumanPatientId));
        saveIsacIdentityVerificationRequestV1.setStoreNbr(adult2StoreNbr);
        saveIsacIdentityVerificationRequestV1.setIdVerified(Boolean.TRUE);

        PhotoId photoId = new PhotoId();
        photoId.setType(adult2PhotoIdType);
        photoId.setNumber(adult2PhotoIdNbr);
        photoId.setState(adult2PhotoIdState);
        photoId.setCountry(adult2PhotoIdCountry);
        photoId.setExpirationDate(adult2PhotoIdExpirationDate);
        saveIsacIdentityVerificationRequestV1.setPhotoId(photoId);
        return saveIsacIdentityVerificationRequestV1;
    }

    private SaveIsacIdVerificationRequestV1 getSaveIsacIdentityVerificationRequestForAdult3() {
        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestV1 = new SaveIsacIdVerificationRequestV1();
        saveIsacIdentityVerificationRequestV1.setEmailId(adult3EmailId);
        saveIsacIdentityVerificationRequestV1.setPatientId(String.valueOf(cprAdult3HumanPatientId));
        saveIsacIdentityVerificationRequestV1.setStoreNbr(adult3StoreNbr);
        saveIsacIdentityVerificationRequestV1.setIdVerified(Boolean.TRUE);

        PhotoId photoId = new PhotoId();
        photoId.setType(adult3PhotoIdType);
        photoId.setNumber(adult3PhotoIdNbr);
        photoId.setState(adult3PhotoIdState);
        photoId.setCountry(adult3PhotoIdCountry);
        photoId.setExpirationDate(adult3PhotoIdExpirationDate);
        saveIsacIdentityVerificationRequestV1.setPhotoId(photoId);
        return saveIsacIdentityVerificationRequestV1;
    }

    private SaveIsacIdVerificationRequestV1 getSaveIsacIdentityVerificationRequestForAdult4() {
        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestV1 = new SaveIsacIdVerificationRequestV1();
        saveIsacIdentityVerificationRequestV1.setEmailId(adult4EmailId);
        saveIsacIdentityVerificationRequestV1.setPatientId(String.valueOf(cprAdult4HumanPatientId));
        saveIsacIdentityVerificationRequestV1.setStoreNbr(adult4StoreNbr);
        saveIsacIdentityVerificationRequestV1.setIdVerified(Boolean.TRUE);

        PhotoId photoId = new PhotoId();
        photoId.setType(adult4PhotoIdType);
        photoId.setNumber(adult4PhotoIdNbr);
        photoId.setState(adult4PhotoIdState);
        photoId.setCountry(adult4PhotoIdCountry);
        photoId.setExpirationDate(adult4PhotoIdExpirationDate);
        saveIsacIdentityVerificationRequestV1.setPhotoId(photoId);
        return saveIsacIdentityVerificationRequestV1;
    }

    @Test(
            priority = 0,
            description = "Save IsacId verification with invalid domainId - Failure")
    public void saveIsacIdVerificationWithInvalidDomainId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        String domainId = "WM-PHARMAC";
        // ask how should I log in if adult2customerAccountId is null
        // TODO: write another log method
        CommonUtil.logFlowIdentifiers(
                adult2CustomerAccountId, domainId, adult2PhoneNbr, type, reqId, reqTrackingId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        getSaveIsacIdentityVerificationRequestForAdult2(),
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(), String.format("Invalid input request. domainId %s in input is invalid", domainId));
    }

    @Test(
            priority = 0,
            description = "Save IsacId verification with invalid photoId expirationDate format - Failure")
    public void saveIsacIdVerificationWithInvalidPhotoIdExpirationDateFormat() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult2CustomerAccountId, domainId, adult2PhoneNbr, type, reqId, reqTrackingId);

        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestForAdult2 = getSaveIsacIdentityVerificationRequestForAdult2();
        saveIsacIdentityVerificationRequestForAdult2.getPhotoId().setExpirationDate(invalidPhotoIdExpirationDateFormat);
        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        saveIsacIdentityVerificationRequestForAdult2,
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(), "Invalid input request. Date is not valid. The format should be MM-dd-yyyy.");
    }

    @Test(
            priority = 0,
            description =
                    "Save IsacId verification V1 API failure due to input request patient data not found in CPR")
    public void savePharmacyAccountV1APIPatientDataNotFoundInCPRFailure() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult2CustomerAccountId, domainId, adult2PhoneNbr, type, reqId, reqTrackingId);

        SaveIsacIdVerificationRequestV1 saveIsacIdVerificationRequestV1 = getSaveIsacIdentityVerificationRequestForAdult2();
        saveIsacIdVerificationRequestV1
                .setStoreNbr("1");
        saveIsacIdVerificationRequestV1
                .setPatientId("1");

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        saveIsacIdVerificationRequestV1,
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 404, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-6001");
        Assert.assertEquals(
                errorResponse.getMessage(), "No information found for given input request in CPR. {}");
    }

    @Test(
            priority = 0,
            description = "Save IsacId verification with Minor cpr account - Failure")
    public void saveIsacIdVerificationWithMinorCprAccount() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                minorCustomerAccountId, domainId, minorPhoneNbr, type, reqId, reqTrackingId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        getSaveIsacIdentityVerificationRequestForMinor(),
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1044");
        Assert.assertEquals(
                errorResponse.getMessage(), "MINOR/PET is not allowed to create account.");
    }

    @Test(
            priority = 0,
            description = "Save IsacId verification with already has pharmacy account - Failure")
    public void saveIsacIdVerificationWithAlreadyHasPharmacyAccount() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult1CustomerAccountId, domainId, adult1PhoneNbr, type, reqId, reqTrackingId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        getSaveIsacIdentityVerificationRequestForAdult1(),
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 400, errorMessage);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1048");
    }

    @Test(
            priority = 0,
            description = "save IsacId verification with valid request - success")
    public void saveIsacIdVerificationWithValidRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult2CustomerAccountId, domainId, adult2PhoneNbr, type, reqId, reqTrackingId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        getSaveIsacIdentityVerificationRequestForAdult2(),
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        SaveIsacIdVerificationResponseV1 response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) saveIsacIdVerificationResponse.body().getPayload()),
                        SaveIsacIdVerificationResponseV1.class);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 200, errorMessage);
        Assert.assertNotNull(saveIsacIdVerificationResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getStageId(), "StageId is null");
    }

    @Test(
            priority = 0,
            description = "save Isac Id verification with isac id already exists with different emailId - success")
    public void saveIsacIdVerificationWithIsacIdAlreadyExistsWithDifferentEmailId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult3CustomerAccountId, domainId, adult3PhoneNbr, type, reqId, reqTrackingId);

        SaveIsacIdVerificationRequestV1 saveIsacIdentityVerificationRequestForAdult3 =
                getSaveIsacIdentityVerificationRequestForAdult3();
        saveIsacIdentityVerificationRequestForAdult3.setEmailId(CommonUtil.generateRandomEmailId(10));

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        saveIsacIdentityVerificationRequestForAdult3,
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        SaveIsacIdVerificationResponseV1 response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) saveIsacIdVerificationResponse.body().getPayload()),
                        SaveIsacIdVerificationResponseV1.class);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 200, errorMessage);
        Assert.assertNotNull(saveIsacIdVerificationResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getStageId(), "StageId is null");
    }

    @Test(
            priority = 0,
            description = "save Isac Id verification with isac id already exists with same emailId - success")
    public void saveIsacIdVerificationWithIsacIdAlreadyExistsWithSameEmailId() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String type = "";
        CommonUtil.logFlowIdentifiers(
                adult4CustomerAccountId, domainId, adult4PhoneNbr, type, reqId, reqTrackingId);

        Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse> saveIsacIdVerificationResponse =
                accountOrchestratorRetrofit.saveIsacIdVerificationV1(domainId,
                        getSaveIsacIdentityVerificationRequestForAdult4(),
                        reqId,
                        reqTrackingId);

        Error errorResponse = CommonUtil.getErrorResponse(gson, saveIsacIdVerificationResponse);
        String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

        SaveIsacIdVerificationResponseV1 response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) saveIsacIdVerificationResponse.body().getPayload()),
                        SaveIsacIdVerificationResponseV1.class);

        Assert.assertEquals(saveIsacIdVerificationResponse.code(), 200, errorMessage);
        Assert.assertNotNull(saveIsacIdVerificationResponse.body().getPayload(), "Payload is null");
        Assert.assertNotNull(response.getStageId(), "StageId is null");
    }

    @AfterClass
    void cleanUp() {
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        // Update CPR account's "patientInfo.patientStatusCode" to 20708 where ONLINE_DEL = 20708, to
        // delete CPR account
        List<ValidationServiceRequest> requests = Arrays.asList(
                minorHumanCprPatientRequest,
                adult1HumanCprPatientRequest,
                adult2HumanCprPatientRequest,
                adult3HumanCprPatientRequest,
                adult4HumanCprPatientRequest);

        for (ValidationServiceRequest request : requests) {
            request.getPatientInfo().setPatientTypeCode(20708);
            try {
                deleteCprAccount(request);
            } catch (IOException e) {

            }
        }
    }

    private void deleteCprAccount(ValidationServiceRequest cprRequest) throws IOException {
        Response<ValidationServiceResponse> response =
                cprPatientUpdateRetrofit.validateProfile(cprRequest);
        if (response.code() == 202
                && response.body() != null
                && response.body().getErrors().isEmpty()) {
        } else {
            Reporter.logJSON(
                    "errorMessage",
                    String.format(
                            "CPR Account failed to update with status code 20708 for PatientId %s, httpStatusCode: %s",
                            cprRequest.getPatientId(), response.code()));
        }
    }
}