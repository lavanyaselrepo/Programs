package accountorchestrator.accountpreference;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class AccountOrchestratorAccountPreferencesTest {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private String domainId = "WM-PHARMACY";
  private String notification = "NOTIFICATION";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonCustomerAccountId = null;

  @BeforeClass
  void setContext() throws IOException {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
  }

  @Test(
      priority = 0,
      description = "Update Account Preferences success case for random customerAccountId")
  public void updateAccountPreferencesV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 3: Setting the notificationPreference in the updateAccountPreferenceV1Request
    NotificationPreferences notificationPreferences = new NotificationPreferences();
    notificationPreferences.setLatePickup(Boolean.FALSE);
    notificationPreferences.setRxExpiry(Boolean.TRUE);
    updateAccountPreferenceV1Request.setNotificationPreferences(notificationPreferences);

    // Step - 4: calling the updateAccountPreferencesV1 orchestrator API with random
    // customerAccountId
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountPreferenceV1APIResponse);

    // Step - 6: Parsing the response to the UpdateAccountPreferencesV1Response class so that we can
    // assert updateAccountPreferences
    UpdateAccountPreferencesV1Response updateAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateAccountPreferenceV1APIResponse.body().getPayload()),
            UpdateAccountPreferencesV1Response.class);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
        updateAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(
        updateAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
    Assert.assertTrue(updateAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
  }

  @Test(priority = 1, description = "Update Account Preferences failure case for Invalid request")
  public void updateAccountPreferencesV1InvalidRequest() throws IOException {
    // *****  CASE 1 - There is no notification preference in the request *****

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    commonCustomerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 1b: Setting the notification preferences in the request
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();
    updateAccountPreferenceV1Request.setNotificationPreferences(null);

    // Step - 2: calling the updateAccountPreferencesV1 orchestrator API with null notification
    // preference
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            commonCustomerAccountId,
            domainId,
            updateAccountPreferenceV1Request,
            reqId,
            reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);

    // Step - 4 : Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1010");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid Request. No preference updates found for customerAccountId");

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: calling the updateAccountPreferencesV1 orchestrator API with invalidDomainId
    updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            commonCustomerAccountId,
            invalidDomainId,
            updateAccountPreferenceV1Request,
            reqId,
            reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);

    // Step - 4: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", invalidDomainId));
  }

  @Test(
      priority = 2,
      description = "Get Account Preferences success case for random customerAccountId")
  public void getAccountPreferencesV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with random customerAccountId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, notification);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
  }

  @Test(
      priority = 3,
      description = "Get Account Preferences success case for random customerAccountId")
  public void getAccountPreferencesWithoutQueryParamV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with random customerAccountId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, "");

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
  }

  @Test(priority = 4, description = "Get Account Preferences failure case for Invalid domain Id")
  public void getAccountPreferencesV1InvalidRequest() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with invalidDomainId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId, notification);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", invalidDomainId));
  }

  @Test(priority = 5, description = "Get Account Preferences success case on updating isLatePickup")
  public void getAccountPreferencesV1SuccessOnUpdatingIsLatePickup() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2a: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 2b: Setting the notificationPreference for latePickup in the
    // updateAccountPreferenceV1Request
    NotificationPreferences notificationPreferences = new NotificationPreferences();
    notificationPreferences.setLatePickup(Boolean.TRUE);
    updateAccountPreferenceV1Request.setNotificationPreferences(notificationPreferences);

    // Step - 2c: calling the updateAccountPreferencesV1 orchestrator API with random
    // customerAccountId
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 2d: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);

    // Step - 3: calling the getAccountPreferencesV1 orchestrator API with updated latePickup
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, notification);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 5: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertTrue(getAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
  }

  @Test(priority = 6, description = "Get Account Preferences success case on updating isRxExpiry")
  public void getAccountPreferencesV1SuccessOnUpdatingIsRxExpiry() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2a: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 2b: Setting the notificationPreference for isRxExpiry in the
    // updateAccountPreferenceV1Request
    NotificationPreferences notificationPreferences = new NotificationPreferences();
    notificationPreferences.setRxExpiry(Boolean.TRUE);
    updateAccountPreferenceV1Request.setNotificationPreferences(notificationPreferences);

    // Step - 2c: calling the updateAccountPreferencesV1 orchestrator API
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 2d: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);

    // Step - 3: calling the getAccountPreferencesV1 orchestrator API with updated rxExpiry
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, notification);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 5: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertTrue(getAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
    Assert.assertFalse(getAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
  }

  @Test(
      priority = 7,
      description = "Get Account Preferences success case on updating notificationPreferences")
  public void getAccountPreferencesV1SuccessOnUpdatingNotificationPreferences() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String customerAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2a: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 2b: Setting the notificationPreference in the updateAccountPreferenceV1Request
    NotificationPreferences notificationPreferences = new NotificationPreferences();
    notificationPreferences.setRxExpiry(Boolean.TRUE);
    notificationPreferences.setLatePickup(Boolean.TRUE);
    updateAccountPreferenceV1Request.setNotificationPreferences(notificationPreferences);

    // Step - 2c: calling the updateAccountPreferencesV1 orchestrator API with random
    // customerAccountId
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);
    String errorMessage = CommonUtil.buildErrorMessage(errorResponse);

    // Step - 2d: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);

    // Step - 3: calling the getAccountPreferencesV1 orchestrator API with updated
    // notificationPreference
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, notification);

    // Step - 4: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 5: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertTrue(getAccountPreferencesResponse.getNotificationPreferences().isRxExpiry());
    Assert.assertTrue(getAccountPreferencesResponse.getNotificationPreferences().isLatePickup());
  }
}
