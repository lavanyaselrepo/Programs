package accountorchestrator.accountpreference;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.*;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.Error;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class AccountOrchestratorNudgePreferencesTest {

  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private String domainId = "WM-PHARMACY";
  private String dashboardNudge = "DASHBOARD_NUDGE";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonCustomerAccountId = null;
  private String customerAccountId = CommonUtil.randomUUID();

  @BeforeClass
  void setContext() throws IOException {
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
  }
  @Test(
      priority = 0,
      description = "Get Dash Board Nudge Preferences success case for random customerAccountId")
  public void getNudgePreferencesV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with random customerAccountId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, dashboardNudge);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertTrue(getAccountPreferencesResponse.getDashboardNudgePreferences().isAddInsuranceCardNudge());
    Assert.assertTrue(getAccountPreferencesResponse.getDashboardNudgePreferences().isManageInsuranceCardNudge());
  }
  @Test(
      priority = 1,
      description = "Update Nudge Preferences success case for random customerAccountId")
  public void updateAddInsuranceNudgePreferencesV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 3: Setting the dashboard nudge preferences in the updateAccountPreferenceV1Request
    DashboardNudgePreferences dashboardNudgePreferences = new DashboardNudgePreferences();
    dashboardNudgePreferences.setAddInsuranceCardNudge(Boolean.FALSE);
    updateAccountPreferenceV1Request.setDashboardNudgePreferences(dashboardNudgePreferences);

    // Step - 4: calling the updateAccountPreferencesV1 orchestrator API with random
    // customerAccountId
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountPreferenceV1APIResponse);

    // Step - 6: Parsing the response to the UpdateAccountPreferencesV1Response class so that we can
    // assert updateAccountPreferences
    UpdateAccountPreferencesV1Response updateAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateAccountPreferenceV1APIResponse.body().getPayload()),
            UpdateAccountPreferencesV1Response.class);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
        updateAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertNull(
        updateAccountPreferencesResponse.getDashboardNudgePreferences().isManageInsuranceCardNudge());
    Assert.assertFalse(updateAccountPreferencesResponse.getDashboardNudgePreferences().isAddInsuranceCardNudge());
  }
  @Test(
      priority = 2,
      description = "Get Dash Board Nudge Preferences for add insurance card nudge " +
          "success case for random customerAccountId")
  public void getNudgePreferencesAfterAddInsuranceNudgeV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with random customerAccountId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, dashboardNudge);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(getAccountPreferencesResponse.getDashboardNudgePreferences().isAddInsuranceCardNudge());
    Assert.assertTrue(getAccountPreferencesResponse.getDashboardNudgePreferences().isManageInsuranceCardNudge());
  }
  @Test(
      priority = 3,
      description = "Update Nudge Preferences for manage insurance card " +
          "success case for random customerAccountId")
  public void updateManageInsuranceNudgePreferencesV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload of UpdateAccountPreferenceV1Request class
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();

    // Step - 3: Setting the dashboard nudge preferences in the updateAccountPreferenceV1Request
    DashboardNudgePreferences dashboardNudgePreferences = new DashboardNudgePreferences();
    dashboardNudgePreferences.setManageInsuranceCardNudge(Boolean.FALSE);
    updateAccountPreferenceV1Request.setDashboardNudgePreferences(dashboardNudgePreferences);

    // Step - 4: calling the updateAccountPreferencesV1 orchestrator API with random
    // customerAccountId
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId, domainId, updateAccountPreferenceV1Request, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, updateAccountPreferenceV1APIResponse);

    // Step - 6: Parsing the response to the UpdateAccountPreferencesV1Response class so that we can
    // assert updateAccountPreferences
    UpdateAccountPreferencesV1Response updateAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateAccountPreferenceV1APIResponse.body().getPayload()),
            UpdateAccountPreferencesV1Response.class);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(
        updateAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(
        updateAccountPreferencesResponse.getDashboardNudgePreferences().isManageInsuranceCardNudge());
    Assert.assertNull(updateAccountPreferencesResponse.getDashboardNudgePreferences().isAddInsuranceCardNudge());
  }

  @Test(
      priority = 4,
      description = "Get Dash Board Nudge Preferences for add/manage insurance card nudge " +
          "success case for random customerAccountId")
  public void getNudgePreferencesAfterAddAndManageInsuranceNudgeV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with random customerAccountId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, domainId, reqId, reqTrackingId, dashboardNudge);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildErrorMessage(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Parsing the response to the GetAccountPreferencesV1Response class so that we can
    // assert getAccountPreferences
    GetAccountPreferencesV1Response getAccountPreferencesResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getAccountPreferenceV1APIResponse.body().getPayload()),
            GetAccountPreferencesV1Response.class);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 200, errorMessage);
    Assert.assertNotNull(getAccountPreferenceV1APIResponse.body().getPayload(), "Payload is null");
    Assert.assertFalse(getAccountPreferencesResponse.getDashboardNudgePreferences().isAddInsuranceCardNudge());
    Assert.assertFalse(getAccountPreferencesResponse.getDashboardNudgePreferences().isManageInsuranceCardNudge());
  }

  @Test(priority = 5, description = "Update Account Preferences failure case for Invalid request")
  public void updateAccountPreferencesV1InvalidRequest() throws IOException {
    // *****  CASE 1 - There is no notification preference in the request *****

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

    // Step - 1b: Setting the notification preferences in the request
    UpdateAccountPreferenceV1Request updateAccountPreferenceV1Request =
        new UpdateAccountPreferenceV1Request();
    updateAccountPreferenceV1Request.setDashboardNudgePreferences(null);

    // Step - 2: calling the updateAccountPreferencesV1 orchestrator API with null notification
    // preference
    Response<ServiceResponse> updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId,
            domainId,
            updateAccountPreferenceV1Request,
            reqId,
            reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);

    // Step - 4 : Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1010");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid Request. No preference updates found for customerAccountId");

    // *****  CASE 2 - DomainId is invalid *****

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: calling the updateAccountPreferencesV1 orchestrator API with invalidDomainId
    updateAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.updateAccountPreferencesV1(
            customerAccountId,
            invalidDomainId,
            updateAccountPreferenceV1Request,
            reqId,
            reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getErrorResponse(gson, updateAccountPreferenceV1APIResponse);

    // Step - 4: Asserting desired responses
    Assert.assertEquals(updateAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", invalidDomainId));
  }
  @Test(priority = 6, description = "Get Account Preferences failure case for Invalid domain Id")
  public void getAccountPreferencesV1InvalidRequest() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(customerAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: calling the getAccountPreferencesV1 orchestrator API with invalidDomainId
    Response<ServiceResponse> getAccountPreferenceV1APIResponse =
        accountOrchestratorRetrofit.getAccountPreferencesV1(
            customerAccountId, invalidDomainId, reqId, reqTrackingId, dashboardNudge);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getErrorResponse(gson, getAccountPreferenceV1APIResponse);

    // Step - 4: Asserting desired responses
    Assert.assertEquals(getAccountPreferenceV1APIResponse.code(), 400);
    Assert.assertNotNull(errorResponse, "errorResponse found null");
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCOR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        String.format("Invalid input request. domainId %s in input is invalid", invalidDomainId));
  }
}
