package accountorchestrator.smsEnrollmentPreferences;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.smsEnrollment.UpdateEnrollmentPreferenceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.GetEnrollmentPreferenceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.getEnrollmentPreferenceResponsePayload;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.Dependents;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class AccountOrchestratorUpdateSMSEnrollmentPreferencesTest {

    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
    CommonUtils utility  = new CommonUtils();
    public Gson gson;

    @Test(priority = 1,
            description = "Validate that a Primary Caregiver for an account with no dependents is sms enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test1_Enrolled_Caregiver(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, cid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), cid, "cid did not match");
    }


    @Test(priority = 2,
            description = "Validate that a Primary Caregiver for an account with no dependents is sms unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test2_Unenrolled_Caregiver(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, cid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), cid, "cid did not match");
    }

    @Test(priority = 3,
            description = "Validate that a Primary Caregiver's and dependent's Enrollment Preference is successfully enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test3_Caregiver_Dependent_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), primaryCaregiverCid, "caregiver cid did not match");
        Assert.assertEquals(response.getJsonElement("payload[1].customerAccountId"), dependentCustomerId, "dependent cid did not match");
    }

    @Test(priority = 4,
            description = "Validate that a Primary Caregiver and Dependent Enrollment Preference is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test4_Caregiver_Dependent_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), primaryCaregiverCid, "dependent cid did not match");

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.remove(0);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        response  = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), dependentCustomerId, "dependent cid did not match");
    }


    @Test(priority = 5,
            description = "Validate Success For Enrolling Adult Dependent's CID",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test5_Adult_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String adultDependentCid = digitalPharmacyAPIManager.getCidFromEmail(adultDependentEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCid, adultDependentEnrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(adultDependentCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), adultDependentCid, "adult Dependent cid did not match");
    }


    @Test(priority = 6,
            description = "Validate Success For Unenrolling Adult Dependent's CID",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test6_Adult_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String adultDependentCid = digitalPharmacyAPIManager.getCidFromEmail(adultDependentEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCid, adultDependentEnrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(adultDependentCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), adultDependentCid, "adult Dependent cid did not match");
    }

    @Test(priority = 7,
            description = "Validate that a Minor Dependent is successfully Enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test7_Minor_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), dependentCustomerId, "minor Dependent cid did not match");
    }

    @Test(priority = 8,
            description = "Validate that a Minor Dependent is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test8_Minor_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), dependentCustomerId, "minor Dependent cid did not match");
    }


    @Test(priority = 9,
            description = "Validate that a Pet Dependent is successfully Enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test9_Pet_Enrollment(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String petDependentFirstName, String petDependentLastName, String petDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        String dependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(petDependentFirstName)){
                dependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, petDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), dependentCustomerId, "pet Dependent cid did not match");
    }

    @Test(priority = 10,
            description = "Validate that a Minor Dependent is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test10_Pet_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                       String petDependentFirstName, String petDependentLastName, String petDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        String dependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(petDependentFirstName)){
                dependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }


        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, petDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), dependentCustomerId, "pet Dependent cid did not match");
    }


    @Test(priority = 11,
            description = "Verify that a person can update phoneNumber for themselves and Depdendents",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test11_Updated_Phone_Number(String patientEmail, String patientFirstName, String patientLastName, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference,
                       String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        String minorDependentCustomerId = "";
        String adultDependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                minorDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
            else if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(adultDependentFirstName)){
                adultDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, minorDependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), minorDependentCustomerId, "minor Dependent cid did not match");

        UpdateEnrollmentPreferenceRequest updateCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateCaregiverEnrollmentPreferenceRequest);

        UpdateEnrollmentPreferenceRequest updateAdultEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCustomerId, adultDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateAdultEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), minorDependentCustomerId, "Minor Dependent cid did not match");
        Assert.assertEquals(response.getJsonElement("payload[1].customerAccountId"), primaryCaregiverCid, "Caregiver cid did not match");
        Assert.assertEquals(response.getJsonElement("payload[2].customerAccountId"), adultDependentCustomerId, "Adult Dependent cid did not match");
    }

    @Test(priority = 12,
            description = "Verify that a person can update phoneNumber for themselves and Depdendents with different Values",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test12_Update_Diff_Phone_Number(String patientEmail, String patientFirstName, String patientLastName, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference,
                       String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber1 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        String phoneNumber2 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        String phoneNumber3 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        String minorDependentCustomerId = "";
        String adultDependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                minorDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
            else if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(adultDependentFirstName)){
                adultDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber1, minorDependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), minorDependentCustomerId, "minor Dependent cid did not match");

        updateEnrollmentPreferenceRequestList.remove(0);
        UpdateEnrollmentPreferenceRequest updateCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber2, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateCaregiverEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), primaryCaregiverCid, "Caregiver cid did not match");

        updateEnrollmentPreferenceRequestList.remove(0);
        UpdateEnrollmentPreferenceRequest updateAdultEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber3, adultDependentCustomerId, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateAdultEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), adultDependentCustomerId, "Adult Dependent cid did not match");
    }


    @Test(priority = 13,
            description = "Validate Contrary Enrollment Statuses Are not allowed",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test13_Contrary_Enrollment_Statuses(String patientEmail, String phoneNum, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. All Preference Status should be the same, either all should be ENROLLED or all should be UNENROLLED", "Error Message did not match");
    }


    @Test(priority = 14,
            description = "Validate More than 10 Customers are not allowed to be updated",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test14_More_Than_10_Customers(String patientEmail, String phoneNum, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom1);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom2);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom3 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" + RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom3);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom4 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom4);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom5 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom5);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom6 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom6);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom7 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom7);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom8 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom8);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom9 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom9);
        UpdateEnrollmentPreferenceRequest enrollPrefReqRandom10 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber,
                RandomStringUtils.randomAlphanumeric(7) + "-9358-4c0b-93de-" +RandomStringUtils.randomAlphanumeric(7), enrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(enrollPrefReqRandom10);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Please provide upto 10 customers for which you need to update the preferences", "Error Message did not match");
    }

    @Test(priority = 15,
            description = "Invalid Data Cases",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "updateEnrollmentPreferences")
    public void Test15_Invalid_Data_cases(String patientEmail, String phoneNum, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        updatePrimaryCaregiverEnrollmentPreferenceRequest.getPreferences().get(0).setType("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Preference Type is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.getPreferences().get(0).setStatus("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Preference Status is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.getPreferences().get(0).setValue("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Preference Value is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.getPreferences().get(0).setProgram("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Preference Program is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.setCustomerAccountId("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. CustomerAccountId is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.setSource("");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Source is null/empty", "Error Message did not match");

        updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.remove(0);
        updatePrimaryCaregiverEnrollmentPreferenceRequest.getPreferences().get(0).setStatus("ENROLLMAAAAN");
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Error Code did not match");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Preference Status should be either ENROLLED or UNENROLLED", "Error Message did not match");
    }
}