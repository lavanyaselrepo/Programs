package accountorchestrator.smsEnrollmentPreferences;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.smsEnrollment.UpdateEnrollmentPreferenceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.GetEnrollmentPreferenceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.getEnrollmentPreferenceResponsePayload;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.Dependents;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccountOrchestratorGetSMSEnrollmentPreferencesTest {
    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
    CommonUtils utility  = new CommonUtils();
    public Gson gson;
    @Test(priority = 1,
            description = "Validate that a Primary Caregiver for an account with no dependents is sms enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test1_Enrolled_Caregiver(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, cid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(cid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), cid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");
    }


    @Test(priority = 2,
            description = "Validate that a Primary Caregiver for an account with no dependents is sms unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test2_Unenrolled_Caregiver(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, cid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(cid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), cid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().size(), 0, "Preferencee Type is incorrect");
    }

    @Test(priority = 3,
            description = "Validate that a Primary Caregiver's and dependent's Enrollment Preference is successfully enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test3_Caregiver_Dependent_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
    String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");
    }

    @Test(priority = 4,
            description = "Validate that a Primary Caregiver and Dependent Enrollment Preference is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test4_Caregiver_Dependent_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        UpdateEnrollmentPreferenceRequest updatePrimaryCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updatePrimaryCaregiverEnrollmentPreferenceRequest);

        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.remove(0);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        response  = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().size(), 0, "enrollment Preference is incorrect");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().size(), 0, "Dependent's Preference is incorrect");
    }


    @Test(priority = 5,
            description = "Validate Success For Enrolling Adult Dependent's CID",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test5_Adult_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String adultDependentCid = digitalPharmacyAPIManager.getCidFromEmail(adultDependentEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCid, adultDependentEnrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(adultDependentCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), adultDependentCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");
    }


    @Test(priority = 6,
            description = "Validate Success For Unenrolling Adult Dependent's CID",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test6_Adult_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String adultDependentCid = digitalPharmacyAPIManager.getCidFromEmail(adultDependentEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCid, adultDependentEnrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(adultDependentCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), adultDependentCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().size(), 0, "Adult Dependent Preference is incorrect");
    }


    @Test(priority = 7,
            description = "Validate that a Minor Dependent is successfully Enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test7_Minor_Enrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");
    }

    @Test(priority = 8,
            description = "Validate that a Minor Dependent is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test8_Minor_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(primaryCaregiverCid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        String dependentCustomerId = "";

        for(Dependents currDependent: fillSummaryResponse.getDependents()){
            if(currDependent.getName().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                dependentCustomerId = currDependent.getCustomerId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");

        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().size(), 0, "Dependent's Preference is incorrect");
    }


    @Test(priority = 9,
            description = "Validate that a Pet Dependent is successfully Enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test9_Pet_Enrollment(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String petDependentFirstName, String petDependentLastName, String petDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        String dependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(petDependentFirstName)){
                dependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, petDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);


        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), petDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), petDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "PET", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNum, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), "ENROLLED", "Incorrect Enrollment Status");
    }

    @Test(priority = 10,
            description = "Validate that a Minor Dependent is successfully Unenrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test10_Pet_Unenrolled(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference,
                      String petDependentFirstName, String petDependentLastName, String petDependentEnrollmentPreference) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();


        String dependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(petDependentFirstName)){
                dependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }


        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, dependentCustomerId, petDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);
        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");

        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), dependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), petDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), petDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "PET", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().size(), 0, "Dependent's Preference is incorrect");
    }


    @Test(priority = 11,
            description = "Verify Updated Phone Number is Successfully Displayed",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test11_Updated_Phone_Number(String patientEmail, String patientFirstName, String patientLastName, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference,
                       String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        //dpOpsUtils.enableTestAccountInQa();
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        String minorDependentCustomerId = "";
        String adultDependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                minorDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
            else if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(adultDependentFirstName)){
                adultDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, minorDependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");

        UpdateEnrollmentPreferenceRequest updateCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateCaregiverEnrollmentPreferenceRequest);

        UpdateEnrollmentPreferenceRequest updateAdultEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependentCustomerId, adultDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateAdultEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");

        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getValue(), phoneNumber, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getStatus(), enrollmentPreference, "Incorrect Enrollment Status");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), minorDependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNumber, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), minorDependentEnrollmentPreference, "Incorrect Enrollment Status");

        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getCustomerAccountId(), adultDependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getValue(), phoneNumber, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getStatus(), minorDependentEnrollmentPreference, "Incorrect Enrollment Status");
    }


    @Test(priority = 12,
            description = "Verify that a person can update phoneNumber for themselves and Depdendents with different Values",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test12_Update_Diff_Phone_Number(String patientEmail, String patientFirstName, String patientLastName, String enrollmentPreference,
                       String minorDependentFirstName, String minorDependentLastName, String minorDependentEnrollmentPreference,
                       String adultDependentFirstName, String adultDependentLastName, String adultDependentEnrollmentPreference, String adultDependentEmail) throws InterruptedException, IOException {
        String primaryCaregiverCid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber1 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        String phoneNumber2 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        String phoneNumber3 = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();

        String minorDependentCustomerId = "";
        String adultDependentCustomerId = "";

        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayloadForData = response.getDataResponse(GetEnrollmentPreferenceResponse.class);

        for(getEnrollmentPreferenceResponsePayload currPayload: responsePayloadForData.getPayload()){
            if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(minorDependentFirstName)){
                minorDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
            else if(currPayload.getCustomerInfo().getFirstName().equalsIgnoreCase(adultDependentFirstName)){
                adultDependentCustomerId = currPayload.getCustomerInfo().getCustomerAccountId();
            }
        }

        UpdateEnrollmentPreferenceRequest updateMinorEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber1, minorDependentCustomerId, minorDependentEnrollmentPreference, true);
        updateEnrollmentPreferenceRequestList.add(updateMinorEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), minorDependentCustomerId, "minor Dependent cid did not match");

        updateEnrollmentPreferenceRequestList.remove(0);
        UpdateEnrollmentPreferenceRequest updateCaregiverEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber2, primaryCaregiverCid, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateCaregiverEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), primaryCaregiverCid, "Caregiver cid did not match");

        updateEnrollmentPreferenceRequestList.remove(0);
        UpdateEnrollmentPreferenceRequest updateAdultEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber3, adultDependentCustomerId, enrollmentPreference, false);
        updateEnrollmentPreferenceRequestList.add(updateAdultEnrollmentPreferenceRequest);

        response = accountOrchestratorWrapper.updateNotificationPreference(primaryCaregiverCid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Update Notification Pereference API Call Failed");
        Assert.assertEquals(response.getJsonElement("payload[0].customerAccountId"), adultDependentCustomerId, "Adult Dependent cid did not match");

        response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(primaryCaregiverCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Get Notification Pereference API Call Failed");
        GetEnrollmentPreferenceResponse responsePayload = response.getDataResponse(GetEnrollmentPreferenceResponse.class);
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getCustomerAccountId(), primaryCaregiverCid, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getFirstName(), patientFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getLastName(), patientLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getCustomerInfo().isDependent(), Boolean.FALSE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getValue(), phoneNumber2, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(0).getPreferences().get(0).getStatus(), enrollmentPreference, "Incorrect Enrollment Status");

        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getCustomerAccountId(), minorDependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().getType(), "MINOR", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getValue(), phoneNumber1, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(1).getPreferences().get(0).getStatus(), minorDependentEnrollmentPreference, "Incorrect Enrollment Status");

        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getCustomerAccountId(), adultDependentCustomerId, "cid did not match");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase(), "patient First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase(), "patient Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getMiddleName(), "", "patient Middle Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().getType(), "ADULT", "patient type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getCustomerInfo().isDependent(), Boolean.TRUE, "patient Dependency Status incorrectly mapped");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getType(), "SMS", "Preferencee Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getValue(), phoneNumber3, "Phone Number Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getProgram(), "WALMART RX", "Program is Incorrect");
        Assert.assertEquals(responsePayload.getPayload().get(2).getPreferences().get(0).getStatus(), minorDependentEnrollmentPreference, "Incorrect Enrollment Status");
    }


    @Test(priority = 13,
            description = "Validate 204 No content for unregistered CID",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsEnrollmentPreferencesData_qe.xlsx", sheetName = "getEnrollmentPreferences")
    public void Test13_No_Content(String patientEmail, String phoneNum, String patientFirstName, String patientLastName, String enrollmentPreference) throws InterruptedException, IOException {
        String cid = digitalPharmacyAPIManager.getCidFromEmail(patientEmail);
        String phoneNumber = utility.nullStringValidation(phoneNum);
        ServiceResponse response = accountOrchestratorWrapper.getEnrollmentPreferenceResponse(cid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.NO_CONTENT_204);
    }
}
