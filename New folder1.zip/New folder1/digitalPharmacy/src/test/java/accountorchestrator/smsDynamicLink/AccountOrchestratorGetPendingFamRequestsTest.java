package accountorchestrator.smsDynamicLink;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsDynamicLink.GetPendingFamRequestResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AccountOrchestratorGetPendingFamRequestsTest {

    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
    CommonUtils utility  = new CommonUtils();
    public Gson gson;
    public String store = "5517";

    @Test(priority = 1, description = "Validate No pending request for caregiver or dependent")
    public void Test1_No_Data_For_Caregiver_Or_Dependent(){
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil caregiverObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), caregiverFirstName, caregiverLastName, "01011998", 0, caregiverEmail, "Test@1234");
        caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String caregiverPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverObj.getPatientFirstName(), caregiverObj.getPatientLastName(), caregiverObj.getDates().get(1), caregiverObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(caregiverCid, caregiverObj.getStoreId()+"", caregiverPatientId, caregiverObj.getPatientDob());

        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.getPendingFamRequest(caregiverCid);
        GetPendingFamRequestResponse responsePayload = response.getDataResponse(GetPendingFamRequestResponse.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().size(), 0, "Incorrect Pending Caregiver List");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().size(), 0, "Incorrect Pending Dependents List");
    }

    @Test(priority = 2, description = "Validate A Dependent in Pending Status")
    public void Test2_Dependent_Data_In_Pending(){
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil caregiverObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), caregiverFirstName, caregiverLastName, "01011998", 0, caregiverEmail, "Test@1234");
        caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String caregiverPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverObj.getPatientFirstName(), caregiverObj.getPatientLastName(), caregiverObj.getDates().get(1), caregiverObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(caregiverCid, caregiverObj.getStoreId()+"", caregiverPatientId, caregiverObj.getPatientDob());

        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5);
        String dependentLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil dependentObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dependentFirstName, dependentLastName, "01011998", 0, dependentEmail, "Test@1234");
        dependentObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String dependentCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependentEmail);
        String dependentPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentObj.getPatientFirstName(), dependentObj.getPatientLastName(), dependentObj.getDates().get(1), dependentObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(dependentCid, dependentObj.getStoreId()+"", dependentPatientId, dependentObj.getPatientDob());

        digitalPharmacyOperationsUtil.linkDependentToCaregiver(caregiverObj, dependentObj, phoneNumber, "ADULT", false);

        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.getPendingFamRequest(caregiverCid);
        GetPendingFamRequestResponse responsePayload = response.getDataResponse(GetPendingFamRequestResponse.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getFirstName(), dependentFirstName.toUpperCase(), "dependent First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLastName(), dependentLastName.toUpperCase(), "dependent Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getCustomerAccountId(), dependentCid, "dependent Cid is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLinkageStatus(), "PENDING", "linkage Status is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getType(), "ADULT", "Dependent Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getEmailId(), dependentEmail, "Dependent Email is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().size(), 0, "Incorrect Pending Dependents List");
    }


    @Test(priority = 3, description = "Validate A Dependent in Pending Account Creation Status")
    public void Test3_Dependent_Data_In_Pending_Account_Creation(){
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil caregiverObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), caregiverFirstName, caregiverLastName, "01011998", 0, caregiverEmail, "Test@1234");
        caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String caregiverPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverObj.getPatientFirstName(), caregiverObj.getPatientLastName(), caregiverObj.getDates().get(1), caregiverObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(caregiverCid, caregiverObj.getStoreId()+"", caregiverPatientId, caregiverObj.getPatientDob());

        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5);
        String dependentLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil dependentObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dependentFirstName, dependentLastName, "01011998", 0, dependentEmail, "Test@1234");
        dependentObj.createAdultAndDropAnRx();
        digitalPharmacyOperationsUtil.linkDependentToCaregiver(caregiverObj, dependentObj, phoneNumber, "ADULT", false);

        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.getPendingFamRequest(caregiverCid);
        GetPendingFamRequestResponse responsePayload = response.getDataResponse(GetPendingFamRequestResponse.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getFirstName(), dependentFirstName.toUpperCase(), "dependent First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLastName(), dependentLastName.toUpperCase(), "dependent Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLinkageStatus(), "PENDING_ACCOUNT_CREATION", "linkage Status is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getType(), "ADULT", "Dependent Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getEmailId(), dependentEmail, "Dependent Email is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().size(), 0, "Incorrect Pending Dependents List");
    }

    @Test(priority = 4, description = "Validate A Caregiver Yet to be Approved")
    public void Test4_Caregiver_In_Pending(){
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil caregiverObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), caregiverFirstName, caregiverLastName, "01011998", 0, caregiverEmail, "Test@1234");
        caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String caregiverPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverObj.getPatientFirstName(), caregiverObj.getPatientLastName(), caregiverObj.getDates().get(1), caregiverObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(caregiverCid, caregiverObj.getStoreId()+"", caregiverPatientId, caregiverObj.getPatientDob());

        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5);
        String dependentLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil dependentObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dependentFirstName, dependentLastName, "01011998", 0, dependentEmail, "Test@1234");
        dependentObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String dependentCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependentEmail);
        String dependentPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentObj.getPatientFirstName(), dependentObj.getPatientLastName(), dependentObj.getDates().get(1), dependentObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(dependentCid, dependentObj.getStoreId()+"", dependentPatientId, dependentObj.getPatientDob());

        digitalPharmacyOperationsUtil.linkDependentToCaregiver(caregiverObj, dependentObj, phoneNumber, "ADULT", false);

        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.getPendingFamRequest(dependentCid);
        GetPendingFamRequestResponse responsePayload = response.getDataResponse(GetPendingFamRequestResponse.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getFirstName(), caregiverFirstName.toUpperCase(), "Caregiver First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getLastName(), caregiverLastName.toUpperCase(), "Caregiver Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getCustomerAccountId(), caregiverCid, "Caregiver Cid is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getLinkageStatus(), "PENDING", "Caregiver Status is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getEmailId(), caregiverEmail, "Caregiver Email is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().size(), 0, "Caregiver Pending Dependents List");
    }

    @Test(priority = 5, description = "Validate A Patient with a caregiver and dependent Pending")
    public void Test5_Caregiver_Dependent_In_Pending(){
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil caregiverObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), caregiverFirstName, caregiverLastName, "01011998", 0, caregiverEmail, "Test@1234");
        caregiverObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String caregiverPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(caregiverObj.getPatientFirstName(), caregiverObj.getPatientLastName(), caregiverObj.getDates().get(1), caregiverObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(caregiverCid, caregiverObj.getStoreId()+"", caregiverPatientId, caregiverObj.getPatientDob());

        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5);
        String dependentLastName = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil dependentObj = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dependentFirstName, dependentLastName, "01011998", 0, dependentEmail, "Test@1234");
        dependentObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String dependentCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependentEmail);
        String dependentPatientId = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentObj.getPatientFirstName(), dependentObj.getPatientLastName(), dependentObj.getDates().get(1), dependentObj.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(dependentCid, dependentObj.getStoreId()+"", dependentPatientId, dependentObj.getPatientDob());

        digitalPharmacyOperationsUtil.linkDependentToCaregiver(caregiverObj, dependentObj, phoneNumber, "ADULT", false);

        phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String dependentEmail2 = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName2 = CommonUtil.generateRandomFirstName(5);
        String dependentLastName2 = CommonUtil.generateRandomLastName(5);

        DigitalPharmacyOperationsUtil dependentObj2 = new DigitalPharmacyOperationsUtil(Integer.parseInt(store), dependentFirstName2, dependentLastName2, "01011998", 0, dependentEmail2, "Test@1234");
        dependentObj2.createDigitalPharmacyConnectedStorePatientAccount(false,false);
        String dependentCid2 = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependentEmail2);
        String dependentPatientId2 = ""+digitalPharmacyAPIManager.getStorePatientIdFromCPR(dependentObj2.getPatientFirstName(), dependentObj2.getPatientLastName(), dependentObj2.getDates().get(1), dependentObj2.getStoreId()+"");
        digitalPharmacyOperationsUtil.enableTestAccountInQa(dependentCid2, dependentObj2.getStoreId()+"", dependentPatientId2, dependentObj2.getPatientDob());

        digitalPharmacyOperationsUtil.linkDependentToCaregiver(dependentObj, dependentObj2, phoneNumber, "ADULT", false);


        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.getPendingFamRequest(dependentCid);
        GetPendingFamRequestResponse responsePayload = response.getDataResponse(GetPendingFamRequestResponse.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getFirstName(), dependentFirstName2.toUpperCase(), "dependent First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLastName(), dependentLastName2.toUpperCase(), "dependent Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getCustomerAccountId(), dependentCid2, "dependent Cid is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getLinkageStatus(), "PENDING", "linkage Status is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getType(), "ADULT", "Dependent Type is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getDependentsInfo().get(0).getEmailId(), dependentEmail2, "Dependent Email is incorrect");

        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getFirstName(), caregiverFirstName.toUpperCase(), "Caregiver First Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getLastName(), caregiverLastName.toUpperCase(), "Caregiver Last Name is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getCustomerAccountId(), caregiverCid, "Caregiver Cid is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getLinkageStatus(), "PENDING", "Caregiver Status is incorrect");
        Assert.assertEquals(responsePayload.getPayload().getCaregiversInfo().get(0).getEmailId(), caregiverEmail, "Caregiver Email is incorrect");
    }

}
