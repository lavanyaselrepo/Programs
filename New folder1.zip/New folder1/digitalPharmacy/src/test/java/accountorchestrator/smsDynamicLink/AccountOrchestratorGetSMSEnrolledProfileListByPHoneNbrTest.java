package accountorchestrator.smsDynamicLink;

import accountorchestrator.utils.CommonAccountHelper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.model.DMCreateStageIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dm.stageId.restapi.DMStageIDRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.smsEnrollment.UpdateEnrollmentPreferenceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.GetsmsEnrolledProfilelListByPhoneNbrResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.response.smsEnrollment.GetsmsEnrolledProfilelListByPhoneNbrErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccountOrchestratorGetSMSEnrolledProfileListByPHoneNbrTest {
    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    WCPRetroFit wcpRetrofit = new WCPRetroFit();
    DMStageIDRetrofit dmStageIDRetrofit = new DMStageIDRetrofit();

    @Test(priority = 1,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for self, where self is ADULT",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test1_getSMSEnrolledProfileListByPHoneNbr_Self(String caregiverDOB, String storeNo, String type) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB,storeNo);
        String caregiver_cid = caregiverDetails.get(0);

        // Step - 2: Enrolling the patient with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

        // Step - 3: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, null, null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 4: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getPatientId(),Integer.parseInt(caregiverDetails.get(1)));
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getStoreNbr(),storeNo);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getCustomerAccountId(),caregiver_cid);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getEmailId(),caregiverEmail);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getFirstName(),caregiverFirstName.toUpperCase());
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getMiddleName(),"");
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getLastName(),caregiverLastName.toUpperCase());
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getGender(),"M");
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(0).getCustomerInfo().getType(),"ADULT");

    }

    @Test(priority = 2,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for Adult dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test2_getSMSEnrolledProfileListByPHoneNbr_AdultDependent(String caregiverDOB, String storeNo, String type) throws Exception {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10);
        String adultDependentLastName = CommonUtil.generateRandomLastName(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(adultDependentEmail, adultDependentFirstName, adultDependentLastName, caregiverDOB, storeNo,false,false);
        String adultDependent_cid = adultDependentDetails.get(0);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest( DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE,adultDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest,caregiver_cid);

        // Step - 2: Enrolling the patients with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependent_cid, "ENROLLED", true);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest1);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest2);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

        // Step - 3: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, null, null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 4: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(), 2);

        for (int i = 0; i < getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(); i++) {
            if (getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId().equals(caregiver_cid)) {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), caregiver_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), caregiverEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), caregiverFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), caregiverLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");

            } else {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(adultDependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), adultDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), adultDependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");

            }
        }
    }



    @Test(priority = 3,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for minor dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test3_getSMSEnrolledProfileListByPHoneNbr_MinorDependent(String caregiverDOB,String dependentDOB, String storeNo, String type) throws Exception {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(10);
        String minorDependentLastName = CommonUtil.generateRandomLastName(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        List<String> DependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(minorDependentEmail, minorDependentFirstName, minorDependentLastName, dependentDOB, storeNo,true,false);
        String minorDependent_cid = DependentDetails.get(0);


        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest( DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE,minorDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest,caregiver_cid);

        // Step - 2: Enrolling the patients with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, minorDependent_cid, "ENROLLED", true);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest1);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest2);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

        // Step - 3: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, null , null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 4: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(), 2);

        for (int i = 0; i < getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(); i++) {
            if (getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId().equals(caregiver_cid)) {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), caregiver_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), caregiverEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), caregiverFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), caregiverLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");

            } else {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(DependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), minorDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), minorDependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "MINOR");

            }
        }
    }

    @Test(priority = 4,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for pet dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test4_getSMSEnrolledProfileListByPHoneNbr_PetDependent(String caregiverDOB,String dependentDOB, String storeNo, String type) throws Exception {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String DependentEmail = CommonUtil.generateRandomEmailId(10);
        String DependentFirstName = CommonUtil.generateRandomFirstName(10);
        String DependentLastName = CommonUtil.generateRandomLastName(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        List<String> DependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_pet(DependentEmail, DependentFirstName, DependentLastName, dependentDOB, storeNo);
        String petDependent_cid = DependentDetails.get(0);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.PET, DependentInfo.LinkageStatusEnum.ACTIVE,petDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest,caregiver_cid);


        // Step - 2: Enrolling the patients with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, petDependent_cid, "ENROLLED", true);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest1);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest2);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

        // Step - 3: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, null, null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 4: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(), 2);

        for (int i = 0; i < getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(); i++) {
            if (getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId().equals(caregiver_cid)) {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), caregiver_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), caregiverEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), caregiverFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), caregiverLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");

            } else {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(DependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), petDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), DependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), DependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), DependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "PET");

            }
        }
    }

    @Test(priority = 1,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for adult,minor,pet dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test5_getSMSEnrolledProfileListByPHoneNbr_CaregiverDependent(String caregiverDOB,String dependentDOB, String storeNo, String type) throws Exception {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10);
        String adultDependentLastName = CommonUtil.generateRandomLastName(10);
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(10);
        String minorDependentLastName = CommonUtil.generateRandomLastName(10);
        String DependentEmail = CommonUtil.generateRandomEmailId(10);
        String DependentFirstName = CommonUtil.generateRandomFirstName(10);
        String DependentLastName = CommonUtil.generateRandomLastName(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo,false,false);
        String caregiver_cid = caregiverDetails.get(0);
        String patientId = caregiverDetails.get(1);
        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(adultDependentEmail, adultDependentFirstName, adultDependentLastName, caregiverDOB, storeNo,false,false);
        String adultDependent_cid = adultDependentDetails.get(0);
        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(minorDependentEmail, minorDependentFirstName, minorDependentLastName, dependentDOB, storeNo,true,false);
        String minorDependent_cid = minorDependentDetails.get(0);
        List<String> petDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(DependentEmail, DependentFirstName, DependentLastName, dependentDOB, storeNo,false,true);
        String petDependent_cid = petDependentDetails.get(0);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest( DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE,adultDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest,caregiver_cid);
        WCPAddDependentRequest wcpAddDependentRequestForMinor = CommonAccountHelper.getWCPAddDependentRequest( DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE,minorDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequestForMinor,caregiver_cid);
        WCPAddDependentRequest wcpAddDependentRequestForPet= CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.PET, DependentInfo.LinkageStatusEnum.ACTIVE,petDependent_cid,caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequestForPet,caregiver_cid);


        // Step - 2: Enrolling the patients with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependent_cid, "ENROLLED", true);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest3 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, minorDependent_cid, "ENROLLED", true);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest4 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, petDependent_cid, "ENROLLED", true);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest1);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest2);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest3);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest4);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);



        DMCreateStageIdRequest dmCreateStageIdRequest = getDMCreateStageIdRequest(patientId,phoneNumber,storeNo);
        DMCreateStageIdResponse dmCreateStageIdResponse = dmStageIDRetrofit.callDMStageIdAPI(dmCreateStageIdRequest).body();

        // Step - 3: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, dmCreateStageIdResponse.getId(), "IMZ_RECOMM");
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 4: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(), 4);

        for (int i = 0; i < getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(); i++) {
            if (getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType().equals("MINOR")) {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(minorDependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), minorDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), minorDependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), minorDependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), minorDependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "MINOR");

            } else if(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType().equals("PET")){
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(petDependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), petDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), DependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), DependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), DependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "PET");
            }
            else
            {
                if(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId().equals(caregiver_cid)){
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), caregiver_cid);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), caregiverEmail);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), caregiverFirstName.toUpperCase());
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), caregiverLastName.toUpperCase());
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getIsStageIdOwner(), Boolean.TRUE);
                }
                else {
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(adultDependentDetails.get(1)));
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), adultDependent_cid);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), adultDependentEmail);
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase());
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase());
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                    Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");

                }
            }

        }

        // Step - 5: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes1 = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, "PET", null, null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse1 = serRes1.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 6: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse1.getPayload().size(), 1);

        // Step - 5: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes2 = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, "MINOR", null, null);
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse2 = serRes1.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 6: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse2.getPayload().size(), 1);
    }

    @Test(priority = 3,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api - isStageIdOwner is false for caregiver when stageId belongs to adult dependent",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test7_getSMSEnrolledProfileListByPHoneNbr_IsStageIdOwnerFalse(String caregiverDOB, String storeNo, String type) throws Exception {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10);
        String caregiverLastName = CommonUtil.generateRandomLastName(10);
        String phoneNumber = CommonUtil.generateRandomPhoneNo(10);
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10);
        String adultDependentLastName = CommonUtil.generateRandomLastName(10);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, false, false);
        String caregiver_cid = caregiverDetails.get(0);
        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation(adultDependentEmail, adultDependentFirstName, adultDependentLastName, caregiverDOB, storeNo, false, false);
        String adultDependent_cid = adultDependentDetails.get(0);
        String adultDependentPatientId = adultDependentDetails.get(1);

        WCPAddDependentRequest wcpAddDependentRequest = CommonAccountHelper.getWCPAddDependentRequest(DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE, adultDependent_cid, caregiver_cid);
        wcpRetrofit.addDependent(wcpAddDependentRequest, caregiver_cid);

        // Step - 2: Enrolling the patients with PhoneNo
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest1 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, caregiver_cid, "ENROLLED", false);
        UpdateEnrollmentPreferenceRequest updateEnrollmentPreferenceRequest2 = accountOrchestratorWrapper.getUpdateEnrollmentPreferenceRequest(phoneNumber, adultDependent_cid, "ENROLLED", true);

        List<UpdateEnrollmentPreferenceRequest> updateEnrollmentPreferenceRequestList = new ArrayList<>();
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest1);
        updateEnrollmentPreferenceRequestList.add(updateEnrollmentPreferenceRequest2);
        ServiceResponse response = accountOrchestratorWrapper.updateNotificationPreference(caregiver_cid, updateEnrollmentPreferenceRequestList);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

        // Step - 3: Creating StageId with adult dependent's patientId (caregiver is NOT the stageId owner)
        DMCreateStageIdRequest dmCreateStageIdRequest = getDMCreateStageIdRequest(adultDependentPatientId, phoneNumber, storeNo);
        DMCreateStageIdResponse dmCreateStageIdResponse = dmStageIDRetrofit.callDMStageIdAPI(dmCreateStageIdRequest).body();

        // Step - 4: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId(caregiver_cid, phoneNumber, type, dmCreateStageIdResponse.getId(), "IMZ_RECOMM");
        GetsmsEnrolledProfilelListByPhoneNbrResponse getsmsEnrolledProfilelListByPhoneNbrResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrResponse.class);

        // Step - 5: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.OK_200);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(), 2);

        for (int i = 0; i < getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().size(); i++) {
            if (getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId().equals(caregiver_cid)) {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(caregiverDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), caregiver_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), caregiverEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), caregiverFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), caregiverLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getIsStageIdOwner(), Boolean.FALSE);
            } else {
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getPatientId(), Integer.parseInt(adultDependentDetails.get(1)));
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getStoreNbr(), storeNo);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getCustomerAccountId(), adultDependent_cid);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getEmailId(), adultDependentEmail);
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getFirstName(), adultDependentFirstName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getMiddleName(), "");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getLastName(), adultDependentLastName.toUpperCase());
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getGender(), "M");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getType(), "ADULT");
                Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrResponse.getPayload().get(i).getCustomerInfo().getIsStageIdOwner(), Boolean.TRUE);
            }
        }
    }

    @Test(priority = 5,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for invalid phoneNo",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void InvalidTest1_getSMSEnrolledProfileListByPHoneNbr(String errorCode, String type) throws InterruptedException, IOException {


        // Step - 1: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId("235a1d66-397a-4f74-92e8-bdc4e4076e32", "abcd", type, null, null);
        GetsmsEnrolledProfilelListByPhoneNbrErrorResponse getsmsEnrolledProfilelListByPhoneNbrErrorResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrErrorResponse.class);

        // Step - 2: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrErrorResponse.getError().getCode(),errorCode);
    }

    @Test(priority = 5,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api for invalid type",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void InvalidTest2_getSMSEnrolledProfileListByPHoneNbr(String errorCode,String type) throws InterruptedException, IOException {


        // Step - 1: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId("235a1d66-397a-4f74-92e8-bdc4e4076e32", "9999123457", type, null, null);
        GetsmsEnrolledProfilelListByPhoneNbrErrorResponse getsmsEnrolledProfilelListByPhoneNbrErrorResponse = serRes.getDataResponse(GetsmsEnrolledProfilelListByPhoneNbrErrorResponse.class);

        // Step - 2: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.BAD_REQUEST_400);
        Assert.assertEquals(getsmsEnrolledProfilelListByPhoneNbrErrorResponse.getError().getCode(),errorCode);
    }

    @Test(priority = 2,
            description = "Validate getSMSEnrolledProfileListByPHoneNbr api when no patient is enrolled",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "getSMSEnrolledProfileListByPhn")
    public void Test6_getSMSEnrolledProfileListByPHoneNbr_NoContent(String type)  {


        // Step - 1: Getting SMS Enrolled Profile List By PhoneNo
        ServiceResponse serRes = accountOrchestratorWrapper.getSMSEnrolledProfileListByPHoneNbrWithStageId("235a1d66-397a-4f74-92e8-bdc4e4076e33", "9999123456", type, null, null);

        // Step - 2: Validate response of getSMSEnrolledProfileListByPHoneNbr API
        Assert.assertEquals(serRes.getStatusCode(), HttpStatus.NOT_FOUND_404);

    }
    DMCreateStageIdRequest getDMCreateStageIdRequest(String patientId, String phoneNumber, String storeNo) {
        DMCreateStageIdRequest.Comms comms = DMCreateStageIdRequest.Comms.builder()
                .patientId(patientId)
                .phoneNumber(phoneNumber)
                .storeNbr(storeNo)
                .build();

        DMCreateStageIdRequest.Payload payload = DMCreateStageIdRequest.Payload.builder()
                .comms(comms)
                .build();

        return DMCreateStageIdRequest.builder()
                .refType("ci-imz-reco")
                .payload(payload)
                .build();
    }

}
