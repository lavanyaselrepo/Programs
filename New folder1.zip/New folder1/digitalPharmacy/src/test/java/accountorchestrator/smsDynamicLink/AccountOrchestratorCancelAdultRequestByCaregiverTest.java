package accountorchestrator.smsDynamicLink;

import accountorchestrator.utils.AccountOrchestratorCommonUtils;
import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpdateFamRequestsV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.request.WCPAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.wcp.restapi.WCPRetroFit;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;

public class AccountOrchestratorCancelAdultRequestByCaregiverTest {

    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    WCPRetroFit wcpRetroFit = new WCPRetroFit();
    CprPatientUpdateRetrofit cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    AccountEntityServiceRetrofit accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    private final ObjectMapper mapper = new ObjectMapper();
    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private final String accountCreationSource = "smsOtpVerification";

    @Test(priority = 1,
            description = "Validate a Caregiver is able to Cancel Linking Request By Cid"
    )
    public void Test1_Cancel_Cid() throws Exception {
        Date adultDob = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPR = new SimpleDateFormat("yyyy-MM-dd").format(adultDob);
        String dobDP = new SimpleDateFormat("MMddyyyy").format(adultDob);

        // Caregiver setup
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
        String caregiverPatientId = CommonUtil.generateRandomNumber(9);
        String caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String caregiverPhoneNbr = CommonUtil.generateRandomNumber(10);
        String caregiverCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverEmail);
        createCPRAccount(caregiverStoreNbr, caregiverPatientId, caregiverFirstName, caregiverLastName, dobCPR, caregiverPhoneNbr);
        createPharmacyAccount(caregiverCid, caregiverStoreNbr, caregiverPatientId, dobDP);

        // Dependent setup
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentPatientId = CommonUtil.generateRandomNumber(9);
        String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentPhoneNbr = CommonUtil.generateRandomNumber(10);
        String dependentCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependentEmail);
        createCPRAccount(dependentStoreNbr, dependentPatientId, dependentFirstName, dependentLastName, dobCPR, dependentPhoneNbr);
        createPharmacyAccount(dependentCid, dependentStoreNbr, dependentPatientId, dobDP);

        // Link as PENDING adult dependent
        WCPAddDependentRequest wcpAddDependentRequest = AccountOrchestratorCommonUtils.getWCPAddDependentRequest(
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.PENDING, dependentCid, caregiverCid);
        wcpRetroFit.addDependent(wcpAddDependentRequest, caregiverCid);

        ServiceResponse response = accountOrchestratorWrapper.cancelAdultReqByCaregiverViaCid(caregiverCid, dependentCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Cancel Adult Call Failed");
    }

    @Test(priority = 2,
            description = "Validate a Caregiver is able to Cancel Linking Request By Email"
    )
    public void Test2_Cancel_Email() throws Exception {
        Date adultDob = new Date(System.currentTimeMillis() - 20L * 365 * 24 * 60 * 60 * 1000);
        String dobCPR = new SimpleDateFormat("yyyy-MM-dd").format(adultDob);
        String dobDP = new SimpleDateFormat("MMddyyyy").format(adultDob);

        // Caregiver setup — full pharmacy account (same as Test1)
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverStoreNbr = CommonUtil.generateRandomNumber(6);
        String caregiverPatientId = CommonUtil.generateRandomNumber(9);
        String caregiverFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String caregiverLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String caregiverPhoneNbr = CommonUtil.generateRandomNumber(10);
        String caregiverCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverEmail);
        createCPRAccount(caregiverStoreNbr, caregiverPatientId, caregiverFirstName, caregiverLastName, dobCPR, caregiverPhoneNbr);
        createPharmacyAccount(caregiverCid, caregiverStoreNbr, caregiverPatientId, dobDP);

        // Dependent setup — CPR account only (no pharmacy account).
        // PENDING_ACCOUNT_CREATION means the dependent was invited by email but has no pharmacy account yet,
        // so the cancel-by-email service path can locate the FAM entry keyed on their email.
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentStoreNbr = CommonUtil.generateRandomNumber(6);
        String dependentPatientId = CommonUtil.generateRandomNumber(9);
        String dependentFirstName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentLastName = RandomStringUtils.randomAlphabetic(5).toUpperCase();
        String dependentPhoneNbr = CommonUtil.generateRandomNumber(10);
        createCPRAccount(dependentStoreNbr, dependentPatientId, dependentFirstName, dependentLastName, dobCPR, dependentPhoneNbr);

        // Insert a PENDING_ACCOUNT_CREATION FAM entry directly in Account Entity, keyed on dependent email.
        // This replicates the state produced when a caregiver invites an adult by email before they have an account.
        createFamPendingAccountCreation(dependentEmail, caregiverCid, dependentPatientId, dependentStoreNbr);

        ServiceResponse response = accountOrchestratorWrapper.cancelAdultReqByCaregiverViaEmail(caregiverCid, dependentEmail);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Cancel Adult Call Failed");
    }

    @Test(priority = 3,
            description = "Validate Error for a wrong dependent Cid"
    )
    public void Test3_Cancel_Cid_Invalid() throws Exception {
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);

        String caregiverCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverEmail);
        String dependentCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(dependentEmail);

        ServiceResponse response = accountOrchestratorWrapper.cancelAdultReqByCaregiverViaCid(caregiverCid, dependentCid);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST_400, "Dependent Info Found for a Random Account - Please Report");
        Assert.assertEquals(response.getJsonElement("error.code"), "DPR-DPACCOR-1001", "Incorrect Error Code");
        Assert.assertEquals(response.getJsonElement("error.message"), "Invalid input request. Dependent membership status or type does not match", "Incorrect Error Message");
    }

    @Test(priority = 4,
            description = "Validate No Data for a wrong dependent Email"
    )
    public void Test4_Cancel_Email_Invalid() throws Exception {
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String dependentEmail = CommonUtil.generateRandomEmailId(10);

        // Only the caregiver CID is needed; the email path in the service queries Account Entity
        // FAM records only — it never looks up whether the dependent has a dotcom account.
        String caregiverCid = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(caregiverEmail);

        // No PENDING_ACCOUNT_CREATION FAM entry for dependentEmail → Account Entity returns 204
        // → service throws ACCOUNT_ENTITY_SERVICE_NO_CONTENT_EXCEPTION → propagated as 204
        ServiceResponse response = accountOrchestratorWrapper.cancelAdultReqByCaregiverViaEmail(caregiverCid, dependentEmail);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.NO_CONTENT_204, "Dependent Info Found for a Random Account - Please Report");
    }

    private void createFamPendingAccountCreation(
            String dependentEmail,
            String caregiverCid,
            String patientId,
            String storeNbr) throws IOException {
        LinkedHashMap<String, String> additionalInfo = new LinkedHashMap<>();
        additionalInfo.put("storeNbr", storeNbr);
        additionalInfo.put("patientId", patientId);

        UpdateFamRequestsV1Request updateFamRequestsV1Request =
                UpdateFamRequestsV1Request.builder()
                        .requestInfo(
                                Collections.singletonList(
                                        UpdateFamRequestsV1Request.RequestInfo.builder()
                                                .additionalInfo(additionalInfo)
                                                .dependentId(dependentEmail)
                                                .caregiverId(caregiverCid)
                                                .build()))
                        .build();

        for (int i = 0; i < 3; i++) {
            Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response =
                    accountEntityServiceRetrofit.updateFamRequests(
                            domainId,
                            updateFamRequestsV1Request,
                            reqIdString,
                            reqTrackingString,
                            DependentInfo.LinkageStatusEnum.PENDING_ACCOUNT_CREATION.toString());
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "FAM PENDING_ACCOUNT_CREATION insert failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
    }

    private void createCPRAccount(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String dob,
            String phoneNbr) throws IOException {
        ValidationServiceRequest cprPatientRequest =
                mapper.readValue(
                        new File("src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);
        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(dob);
        cprPatientRequest.getPatientInfo().setFirstName(firstName);
        cprPatientRequest.getPatientInfo().setLastName(lastName);
        cprPatientRequest.getPatientCommunicationInfo().getFirst().setCommunicationId(phoneNbr);

        // This will try to create an account in CPR 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response = cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException("CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
        // CPR account creation is async — wait for it to propagate
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void createPharmacyAccount(
            String customerAccountId,
            String storeNbr,
            String patientId,
            String dob) throws IOException {
        CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
                CreatePharmacyAccountV1Request.builder()
                        .accountCreationSource(accountCreationSource)
                        .customerInfo(
                                CreatePharmacyAccountV1Request.CustomerInfo.builder()
                                        .storeNbr(storeNbr)
                                        .patientId(patientId)
                                        .dob(dob)
                                        .build())
                        .build();

        // This will try to create a person account in Account Entity, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse> response =
                    accountEntityServiceRetrofit.createPharmacyAccountV1(
                            customerAccountId, domainId, createPharmacyAccountV1Request, reqIdString, reqTrackingString);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException("Pharmacy Account creation failed. HttpStatusCode : " + response.code());
                }
            } else {
                break;
            }
        }
    }
}
