package accountorchestrator.smsDynamicLink;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import org.apache.commons.lang3.RandomStringUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;


public class AccountOrchestratorSendReminderSMSDynamicLink {
    AccountOrchestratorWrapper accountOrchestratorWrapper = new AccountOrchestratorWrapper();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();


    @Test(priority = 1,
            description = "send reminder when linkage status is PENDING",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "sendReminder")
    public void validateSendReminderLinkageStatusPending(String caregiverEmail, String dependentEmail, String status)  {
        int emailCounterBeforeSendingReminder = accountOrchestratorWrapper.getFamRequestEmailCounter(caregiverEmail, dependentEmail, status);
        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.sendReminder(caregiverEmail, dependentEmail, status);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Cancel Adult Call Failed");
        int emailCounterAfterSendingReminder = accountOrchestratorWrapper.getFamRequestEmailCounter(caregiverEmail, dependentEmail, status);
        Assert.assertEquals(emailCounterBeforeSendingReminder + 1, emailCounterAfterSendingReminder);
    }

    @Test(priority = 2,
            description = "send reminder when linkage status is PENDING_ACCOUNT_CREATION",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "sendReminder")
    public void validateSendReminderLinkageStatusPendingAccountCreation(String caregiverEmail, String dependentEmail, String status)  {
        int emailCounterBeforeSendingReminder = accountOrchestratorWrapper.getFamRequestEmailCounter(caregiverEmail, dependentEmail, status);
        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.sendReminder(caregiverEmail, dependentEmail, status);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200, "Cancel Adult Call Failed");
        int emailCounterAfterSendingReminder = accountOrchestratorWrapper.getFamRequestEmailCounter(caregiverEmail, dependentEmail, status);
        Assert.assertEquals(emailCounterBeforeSendingReminder + 1, emailCounterAfterSendingReminder);
    }

    @Test(priority = 3,
            description = "Validate No Content for a wrong dependent Cid",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "sendReminder")
    public void sendReminder_Dependent_Cid_Invalid(String caregiverEmail, String dependentEmail, String status) throws InterruptedException {
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String dependentEmailId = java.util.UUID.randomUUID().toString()+"@email.com";
        String phoneNumber = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        digitalPharmacyAPIManager.createDotComAccount(dependentEmailId, "Test@1234", phoneNumber, RandomStringUtils.random(5, true, false), RandomStringUtils.random(5, true, false));
        ServiceResponse response = new ServiceResponse();
        Thread.sleep(8000);
        String dependentCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(dependentEmailId);
        response = accountOrchestratorWrapper.sendReminder(caregiverEmail, dependentEmailId, status);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.NO_CONTENT_204, "Dependent Info Found for a Random Account - Please Report");
    }

    @Test(priority = 4,
            description = "Validate No Data for a wrong dependent Email",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData"
    )
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/accountorchestrator/smsDynamicLinkData_qe.xlsx", sheetName = "sendReminder")
    public void sendReminder_Dependent_Email_Invalid(String caregiverEmail, String dependentEmail, String status) throws InterruptedException {
        String caregiverCid = digitalPharmacyAPIManager.getCidFromEmailUsingAstro(caregiverEmail);
        String dependentEmailId = java.util.UUID.randomUUID().toString()+"@email.com";
        String phoneNumber = ""+((long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L);
        digitalPharmacyAPIManager.createDotComAccount(dependentEmailId, "Test@1234", phoneNumber, RandomStringUtils.random(5, true, false), RandomStringUtils.random(5, true, false));
        ServiceResponse response = new ServiceResponse();
        response = accountOrchestratorWrapper.sendReminder(caregiverEmail, dependentEmailId, status);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.NO_CONTENT_204, "Dependent Info Found for a Random Account - Please Report");
    }
}