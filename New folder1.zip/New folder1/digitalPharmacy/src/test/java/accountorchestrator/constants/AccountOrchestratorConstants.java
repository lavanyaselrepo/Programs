package accountorchestrator.constants;

import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;

public class AccountOrchestratorConstants {

    public static String generatePassword() {
        return RandomStringUtils.randomAlphabetic(1).toUpperCase()
            + RandomStringUtils.randomAlphabetic(4).toLowerCase()
            + "@"
            + RandomStringUtils.randomNumeric(4);
    }

    public static final String HUMAN = "HUMAN";
    public static final String PET = "PET";
    public static final String MINOR = "MINOR";
    public static final String ACCOUNT_CREATION_SOURCE = "smsOtpVerification";
    public static final String PHARMACY_DOMAIN_ID = "WM-PHARMACY";
    public static final String reqIdString = "req-id-";
    public static final String reqTrackingString = "req-tracking-";
    public static final String ACCOUNT_CREATION_SOURCE_ID_VERIFICATION = "idVerification";
    public static final String ACCOUNT_TYPE_INDIVIDUAL = "INDIVIDUAL";
    public static final String ACCOUNT_TYPE_GUEST = "GUEST";
    public static final String ADULT = "ADULT";
    public static final String CUSTOMER_TYPE_INDIVIDUAL = "INDIVIDUAL";
    public static final String WPLUS_PLAN_ID = "BASE30";
    public static final String WPLUS_TRIAL_PLAN_ID = "TRIAL30";
    public static final String TEST_STORE_NBR = "5548";
    public static final String TICKET_TYPE_MISSING_PRESCRIPTION = "Missing prescription";
    public static final String TICKET_ADDITIONAL_INFO = "Additional INFO";
    public static final String ADDRESS_COUNTRY_USA = "USA";
    public static final String FAM_FLOW_NAME = "FAM";
    public static final String VERIFICATION_SOURCE_EXPERIAN = "EXPERIAN";
    public static final String VERIFICATION_SOURCE_RX_STORE = "RX_STORE";
    public static final String TWO_FA_STATUS_ACTIVE = "ACTIVE";
    public static final String TWO_FA_STATUS_INACTIVE = "INACTIVE";
    public static final String PHOTO_ID_TYPE_DRV = "DRV";
    public static final String PHOTO_ID_COUNTRY_US = "US";
}
