package accountentity.isac;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.GetIsacIdVerificationV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.GetIsacIdVerificationV1Response;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.PatientLinks;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1RequestIdVerificationInfo;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;

public class GetIsacIdVerificationTest {

    // ── Operation constants ────────────────────────────────────────────────
    private static final String INSERT_OPERATION = "INSERT";

    // ── Error code constants ───────────────────────────────────────────────
    private static final String ERROR_CODE_INVALID_INPUT = "DPR-DPACCENSR-1001";

    // ── Patient fixture constants ──────────────────────────────────────────
    private static final String DOB                      = "12122002";
    private static final String FIRST_NAME               = "Sam";
    private static final String LAST_NAME                = "Walton";

    // ── ID-verification status constants ──────────────────────────────────
    private static final String IS_ID_VERIFIED_TRUE      = Boolean.TRUE.toString();
    private static final String IS_ID_VERIFIED_FALSE     = Boolean.FALSE.toString();

    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String samsDomainId = "SAMS-PHARMACY";
    private String invalidDomainId = "WM-PHARMACY-INVALID";
    private Gson gson;

    @BeforeClass
    void setContext() {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        gson = new Gson();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EXISTING TESTS (unchanged)
    // ─────────────────────────────────────────────────────────────────────────

    @Test(priority = 0, description = "all null values in request body for getIsacIdVerificationV1")
    public void nullValuesInRequestForGetIsacIdVerificationV1Error() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, new GetIsacIdVerificationV1Request());

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getIsacIdVerificationV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( ERROR_CODE_INVALID_INPUT, errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. Please provide either StageId or PatientLinks with StoreNbr/PatientId combination or EmailId", errorResponse.getMessage());
    }

    @Test(priority = 1, description = "invalid DomainId for getIsacIdVerificationV1")
    public void invalidDomainIdForGetIsacIdVerificationV1Error() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(invalidDomainId, reqId, reqTrackingId);

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        invalidDomainId, reqId, reqTrackingId, new GetIsacIdVerificationV1Request());

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getIsacIdVerificationV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( ERROR_CODE_INVALID_INPUT, errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. only [WM-PHARMACY, SAMS-PHARMACY] are permitted as domainId", errorResponse.getMessage());
    }

    @Test(priority = 2, description = "getIsacIdVerificationV1 by stage Id Success")
    public void getIsacIdVerificationV1ByStageIdSuccess() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        //Save Isac Id Verification
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> saveIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, INSERT_OPERATION);

        UpsertIsacIdVerificationV1Response upsertIsacIdVerificationV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) saveIsacIdVerificationV1Response.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);

        // Building the getIsacIdVerificationV1 request
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setStageId(upsertIsacIdVerificationV1Response.getStageId());

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Asserting response
        Assert.assertNotNull(getIsacIdVerificationV1Response.body());
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getIsacIdVerificationV1Response.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        String stageId = response.getStageId();
        Assert.assertNotNull(stageId);
        Assert.assertNotNull(response);
        Assert.assertEquals(upsertIsacIdVerificationV1Response.getStageId(), response.getStageId());
        Assert.assertEquals(storeNbr, response.getStoreNbr());
        Assert.assertEquals(patientId, response.getPatientId());
        Assert.assertEquals(emailId, response.getEmailId());
    }

    @Test(priority = 3, description = "getIsacIdVerificationV1 by email Id Success")
    public void getIsacIdVerificationV1ByEmailIdSuccess() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Insert a record with the unique email so this test is self-contained
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Building the getIsacIdVerificationV1 request with the dynamically inserted email
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(emailId);

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Asserting response
        Assert.assertNotNull(getIsacIdVerificationV1Response.body());
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getIsacIdVerificationV1Response.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertEquals(response.getPatientId(), patientId);
    }

    @Test(priority = 4, description = "getIsacIdVerificationV1 by patient links Success")
    public void getIsacIdVerificationV1ByPatientLinksSuccess() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Insert a record with unique patientId/storeNbr so this test is self-contained
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Building the getIsacIdVerificationV1 request with the dynamically inserted patientLinks
        PatientLinks patientLinks = new PatientLinks();
        patientLinks.setPatientId(patientId);
        patientLinks.setStoreNbr(storeNbr);

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(patientLinks);

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Asserting response
        Assert.assertNotNull(getIsacIdVerificationV1Response.body());
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getIsacIdVerificationV1Response.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getEmailId(), emailId);
    }

    @Test(priority = 5, description = "getIsacIdVerificationV1 No Content Found Scenario")
    public void getIsacIdVerificationV1NoContentFoundScenario() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Random email — guaranteed to never exist in the DB
        String nonExistentEmail = CommonUtil.generateRandomEmailId(10);

        // Building the getIsacIdVerificationV1 request
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(nonExistentEmail);

        // Calling Get Isac Id Verification
        Response<ServiceResponse> getIsacIdVerificationV1Response =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getIsacIdVerificationV1Response);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        Assert.assertEquals(getIsacIdVerificationV1Response.code(), 204, errorMessage);
    }

    /**
     * Verifies all response fields are correctly mapped after an INSERT_OPERATION.
     * Covers the gap where existing test 2 only checked stageId/storeNbr/patientId/emailId.
     */
    @Test(priority = 6, description = "getIsacIdVerificationV1 by stageId - verify all response fields")
    public void getIsacIdVerificationV1ByStageIdVerifyAllFields() throws IOException {

        // Step 1: Set up tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Insert a known record so we can assert every field
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Step 3: Get by the stageId returned from insert
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setStageId(upsertPayload.getStageId());

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 4: Assert HTTP 200 and response body
        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        LinkedTreeMap<String, Object> rawResponse =
                (LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0);
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson, rawResponse, GetIsacIdVerificationV1Response.class);

        // Core identity fields
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertEquals(response.getEmailId(), emailId);

        // Verification status fields
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertTrue(response.isIsIdVerified(), "isIdVerified should be true");
        Assert.assertNotNull(response.getDobRetries(), "dobRetries must not be null");
        Assert.assertNotNull(response.getEmailSentCounter(), "emailSentCounter must not be null");
        Assert.assertNotNull(response.getLastEmailSentTs(), "lastEmailSentTs must not be null");

    }

    /**
     * Self-contained email lookup test — inserts its own record with a unique email,
     * then fetches by that email. Fixes the fragile dependency on pre-existing env data
     * in test 3.
     */
    @Test(priority = 7, description = "getIsacIdVerificationV1 by email - self-contained")
    public void getIsacIdVerificationV1ByEmailIdSelfContained() throws IOException {

        // Step 1: Set up tracking IDs and a unique email for this test run
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Insert a record with the unique email
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Step 3: Get by the unique email
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(emailId);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 4: Assert HTTP 200 and all response fields
        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        LinkedTreeMap<String, Object> rawResponse =
                (LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0);
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson, rawResponse, GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertTrue(response.isIsIdVerified(), "isIdVerified should be true");
        Assert.assertNotNull(response.getLastEmailSentTs(), "lastEmailSentTs must not be null");
    }

    /**
     * Self-contained patientLinks lookup — inserts its own record with a unique
     * patientId/storeNbr pair, then fetches by those patientLinks. Fixes the fragile
     * dependency on pre-existing env data in test 4.
     */
    @Test(priority = 8, description = "getIsacIdVerificationV1 by patientLinks - self-contained")
    public void getIsacIdVerificationV1ByPatientLinksSelfContained() throws IOException {

        // Step 1: Set up tracking IDs and unique patientId/storeNbr for isolation
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Insert a record with known patientId and storeNbr
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Step 3: Get by patientLinks using the inserted patientId + storeNbr
        PatientLinks patientLinks = new PatientLinks();
        patientLinks.setPatientId(patientId);
        patientLinks.setStoreNbr(storeNbr);

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(patientLinks);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 4: Assert HTTP 200 and all response fields
        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        ArrayList responseList = (ArrayList) getResponse.body().getPayload();
        Assert.assertFalse(responseList.isEmpty(), "Response list must not be empty");

        LinkedTreeMap<String, Object> rawResponse = (LinkedTreeMap<String, Object>) responseList.get(0);
        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson, rawResponse, GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertTrue(response.isIsIdVerified(), "isIdVerified should be true");
        Assert.assertNotNull(response.getLastEmailSentTs(), "lastEmailSentTs must not be null");
    }

    /**
     * Verifies the service can find a record when searching by lowercase email.
     * The service internally passes both the original and uppercase email to the DB
     * query — this test ensures that case-insensitive lookup works end-to-end.
     */
    @Test(priority = 9, description = "getIsacIdVerificationV1 by lowercase email - case-insensitive lookup")
    public void getIsacIdVerificationV1ByEmailIdLowerCaseSuccess() throws IOException {

        // Step 1: Set up tracking IDs and a unique email in UPPERCASE for insert
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String upperCaseEmail = CommonUtil.generateRandomEmailId(10).toUpperCase();
        String lowerCaseEmail = upperCaseEmail.toLowerCase();
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Insert with uppercase email
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(upperCaseEmail, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId());

        // Step 3: Search by lowercase version of the same email
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(lowerCaseEmail);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 4: Record should be found (service passes both cases to DB)
        Assert.assertEquals(getResponse.code(), 200,
                "Lowercase email lookup should succeed - service queries both original and uppercase email");
        Assert.assertNotNull(getResponse.body());

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId(),
                "stageId should match the inserted record");
    }

    /**
     * Verifies that a non-existent stageId returns HTTP 204.
     * Existing test 5 only covered the emailId no-content path.
     */
    @Test(priority = 10, description = "getIsacIdVerificationV1 No Content - non-existent stageId returns 204")
    public void getIsacIdVerificationV1NoContentByStageId() throws IOException {

        // Step 1: Set up tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Use a random UUID as stageId — guaranteed not to exist in DB
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setStageId("00000000-0000-0000-0000-" + trackID.substring(0, 12));

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 3: Assert 204 No Content
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
        Assert.assertEquals(getResponse.code(), 204, errorMessage);
    }

    /**
     * Verifies that patientLinks with non-existent patientId/storeNbr returns HTTP 204.
     * Existing test 5 only covered the emailId no-content path.
     */
    @Test(priority = 11, description = "getIsacIdVerificationV1 No Content - non-existent patientLinks returns 204")
    public void getIsacIdVerificationV1NoContentByPatientLinks() throws IOException {

        // Step 1: Set up tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Random patientId/storeNbr guaranteed not to exist in DB
        PatientLinks nonExistentLink = new PatientLinks();
        nonExistentLink.setPatientId(CommonUtil.generateRandomNumber(9));
        nonExistentLink.setStoreNbr(CommonUtil.generateRandomNumber(6));

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(nonExistentLink);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 3: Assert 204 No Content
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
        Assert.assertEquals(getResponse.code(), 204, errorMessage);
    }

    /**
     * Verifies that a patientLinks entry with blank patientId and storeNbr
     * is rejected with DPR-DPACCENSR-1001 validation error.
     */
    @Test(priority = 12, description = "getIsacIdVerificationV1 - patientLinks with blank patientId/storeNbr returns validation error")
    public void getIsacIdVerificationV1PatientLinksWithBlankFieldsError() throws IOException {

        // Step 1: Set up tracking IDs
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Build request with patientLinks that have empty patientId and storeNbr
        PatientLinks blankPatientLink = new PatientLinks();
        blankPatientLink.setPatientId("");
        blankPatientLink.setStoreNbr("");

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(blankPatientLink);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        // Step 3: Expect validation error
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getResponse);
        Assert.assertNotNull(errorResponse, "Error response must not be null for blank patientLinks fields");
        Assert.assertEquals(errorResponse.getCode(), ERROR_CODE_INVALID_INPUT);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SAMS-PHARMACY DOMAIN TESTS — closes final coverage gap
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Verifies SAMS-PHARMACY domain is accepted and returns a record by stageId.
     */
    @Test(priority = 13, description = "getIsacIdVerificationV1 SAMS-PHARMACY domain - get by stageId Success")
    public void getIsacIdVerificationV1SamsPharmacyByStageIdSuccess() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(samsDomainId, reqId, reqTrackingId);

        // Insert under SAMS-PHARMACY domain
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert under SAMS-PHARMACY should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Get by stageId under SAMS-PHARMACY domain
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setStageId(upsertPayload.getStageId());

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get under SAMS-PHARMACY should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
    }

    /**
     * Verifies SAMS-PHARMACY domain is accepted and returns a record by emailId.
     */
    @Test(priority = 14, description = "getIsacIdVerificationV1 SAMS-PHARMACY domain - get by emailId Success")
    public void getIsacIdVerificationV1SamsPharmacyByEmailIdSuccess() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(samsDomainId, reqId, reqTrackingId);

        // Insert under SAMS-PHARMACY domain with a unique email
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert under SAMS-PHARMACY should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Get by emailId under SAMS-PHARMACY domain
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(emailId);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get under SAMS-PHARMACY should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getEmailId(), emailId);
    }

    /**
     * Verifies SAMS-PHARMACY domain is accepted and returns a record by patientLinks.
     */
    @Test(priority = 15, description = "getIsacIdVerificationV1 SAMS-PHARMACY domain - get by patientLinks Success")
    public void getIsacIdVerificationV1SamsPharmacyByPatientLinksSuccess() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(samsDomainId, reqId, reqTrackingId);

        // Insert under SAMS-PHARMACY domain with unique patientId/storeNbr
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_TRUE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert under SAMS-PHARMACY should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Get by patientLinks under SAMS-PHARMACY domain
        PatientLinks patientLinks = new PatientLinks();
        patientLinks.setPatientId(patientId);
        patientLinks.setStoreNbr(storeNbr);

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(patientLinks);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get under SAMS-PHARMACY should return HTTP 200");
        Assert.assertNotNull(getResponse.body());

        ArrayList responseList = (ArrayList) getResponse.body().getPayload();
        Assert.assertFalse(responseList.isEmpty(), "Response list must not be empty");

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) responseList.get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
        Assert.assertEquals(response.getEmailId(), emailId);
    }

    /**
     * Verifies that SAMS-PHARMACY domain returns HTTP 204 when no record found.
     */
    @Test(priority = 16, description = "getIsacIdVerificationV1 SAMS-PHARMACY domain - No Content returns 204")
    public void getIsacIdVerificationV1SamsPharmacyNoContentScenario() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String nonExistentEmail = CommonUtil.generateRandomEmailId(10);
        logFlowIdentifiers(samsDomainId, reqId, reqTrackingId);

        // Get by random email guaranteed not to exist
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(nonExistentEmail);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        samsDomainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
        Assert.assertEquals(getResponse.code(), 204, errorMessage);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // isIdVerified = false TESTS — query now returns records regardless of flag
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Verifies that a record inserted with isIdVerified=false is still returned
     * when fetched by stageId — service no longer filters on this flag.
     */
    @Test(priority = 17, description = "getIsacIdVerificationV1 - isIdVerified=false record returned by stageId")
    public void getIsacIdVerificationV1ByStageIdWithIdVerifiedFalse() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Insert a record with isIdVerified = false
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_FALSE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Fetch by stageId
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setStageId(upsertPayload.getStageId());

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200 even when isIdVerified=false");
        Assert.assertNotNull(getResponse.body());

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertFalse(response.isIsIdVerified(), "isIdVerified should be false");
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
    }

    /**
     * Verifies that a record inserted with isIdVerified=false is still returned
     * when fetched by emailId — service no longer filters on this flag.
     */
    @Test(priority = 18, description = "getIsacIdVerificationV1 - isIdVerified=false record returned by emailId")
    public void getIsacIdVerificationV1ByEmailIdWithIdVerifiedFalse() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Insert a record with isIdVerified = false
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_FALSE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Fetch by emailId
        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.setEmailId(emailId);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200 even when isIdVerified=false");
        Assert.assertNotNull(getResponse.body());

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) ((ArrayList) getResponse.body().getPayload()).get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertFalse(response.isIsIdVerified(), "isIdVerified should be false");
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
    }

    /**
     * Verifies that a record inserted with isIdVerified=false is still returned
     * when fetched by patientLinks — service no longer filters on this flag.
     */
    @Test(priority = 19, description = "getIsacIdVerificationV1 - isIdVerified=false record returned by patientLinks")
    public void getIsacIdVerificationV1ByPatientLinksWithIdVerifiedFalse() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailId = CommonUtil.generateRandomEmailId(10);
        String patientId = CommonUtil.generateRandomNumber(9);
        String storeNbr = CommonUtil.generateRandomNumber(6);
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Insert a record with isIdVerified = false
        UpsertIsacIdVerificationV1Request upsertRequest =
                buildUpsertIsacIdVerificationV1Request(emailId, patientId, storeNbr, IS_ID_VERIFIED_FALSE);
        Response<ServiceResponse> upsertResponse =
                accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, upsertRequest, INSERT_OPERATION);

        Assert.assertEquals(upsertResponse.code(), 200, "Upsert should return HTTP 200");
        UpsertIsacIdVerificationV1Response upsertPayload = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) upsertResponse.body().getPayload()),
                UpsertIsacIdVerificationV1Response.class);
        Assert.assertNotNull(upsertPayload.getStageId(), "Upsert stageId must not be null");

        // Fetch by patientLinks
        PatientLinks patientLinks = new PatientLinks();
        patientLinks.setPatientId(patientId);
        patientLinks.setStoreNbr(storeNbr);

        GetIsacIdVerificationV1Request getIsacIdVerificationV1Request = new GetIsacIdVerificationV1Request();
        getIsacIdVerificationV1Request.addPatientLinksItem(patientLinks);

        Response<ServiceResponse> getResponse =
                accountEntityServiceRetrofit.getIsacIdVerificationV1(
                        domainId, reqId, reqTrackingId, getIsacIdVerificationV1Request);

        Assert.assertEquals(getResponse.code(), 200, "Get should return HTTP 200 even when isIdVerified=false");
        Assert.assertNotNull(getResponse.body());

        ArrayList responseList = (ArrayList) getResponse.body().getPayload();
        Assert.assertFalse(responseList.isEmpty(), "Response list must not be empty");

        GetIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) responseList.get(0)),
                GetIsacIdVerificationV1Response.class);

        Assert.assertNotNull(response.getStageId());
        Assert.assertEquals(response.getStageId(), upsertPayload.getStageId());
        Assert.assertNotNull(response.isIsIdVerified(), "isIdVerified must not be null");
        Assert.assertFalse(response.isIsIdVerified(), "isIdVerified should be false");
        Assert.assertEquals(response.getEmailId(), emailId);
        Assert.assertEquals(response.getPatientId(), patientId);
        Assert.assertEquals(response.getStoreNbr(), storeNbr);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private static void logFlowIdentifiers(
            String domainId, String reqId, String reqTrackingId) {
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    
    private UpsertIsacIdVerificationV1Request buildUpsertIsacIdVerificationV1Request(
            String email, String patientId, String storeNbr, String isIdVerified) {

        UpsertIsacIdVerificationV1RequestIdVerificationInfo idVerificationInfo =
                new UpsertIsacIdVerificationV1RequestIdVerificationInfo();
        idVerificationInfo.isIdVerified(isIdVerified);

        UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request =
                new UpsertIsacIdVerificationV1Request();
        upsertIsacIdVerificationV1Request.setEmailId(email);
        upsertIsacIdVerificationV1Request.dob(DOB);
        upsertIsacIdVerificationV1Request.firstName(FIRST_NAME);
        upsertIsacIdVerificationV1Request.lastName(LAST_NAME);
        upsertIsacIdVerificationV1Request.storeNbr(storeNbr);
        upsertIsacIdVerificationV1Request.setPatientId(patientId);
        upsertIsacIdVerificationV1Request.idVerificationInfo(idVerificationInfo);

        return upsertIsacIdVerificationV1Request;
    }
}
