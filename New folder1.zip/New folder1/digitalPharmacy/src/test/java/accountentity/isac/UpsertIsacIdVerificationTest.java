package accountentity.isac;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ExistingIdInfo;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1RequestIdVerificationInfo;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpsertIsacIdVerificationV1Response;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class UpsertIsacIdVerificationTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private Gson gson;

  @BeforeClass
  void setContext() {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    gson = new Gson();
  }

  @Test(priority = 0, description = "null operation type")
  public void nullTypeForUpsertIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request,null);

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. Isac Operation Type cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 1, description = "null patientId for saveIsacIdVerificationV1")
  public void nullPatientIdForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step - 3: Calling Save Isac Id Verification
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setPatientId(null);

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: PatientId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 2, description = "zero patientId for saveIsacIdVerificationV1")
  public void zeroPatientIdForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the SaveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setPatientId("");

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: PatientId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 3, description = "null storeNbr for saveIsacIdVerificationV1")
  public void nullStoreNbrForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setStoreNbr(null);

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: StoreNbr cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 4, description = "zero storeNbr for saveIsacIdVerificationV1")
  public void zeroStoreNbrForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setStoreNbr("");

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: StoreNbr cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 5, description = "null emailId for saveIsacIdVerificationV1")
  public void nullEmailIdForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailId(null);

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: EmailId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 6, description = "invalid emailId for saveIsacIdVerificationV1")
  public void invalidEmailIdForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailId("tst#come");

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals("Invalid input request. INSERT: Invalid Email Id address", errorResponse.getMessage());
  }

  @Test(priority = 7, description = "null idVerificationInfo for saveIsacIdVerificationV1")
  public void nullIdVerificationInfoForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIdVerificationInfo(null);

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. INSERT: Id Verification Info cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 9, description = "null isIdVerified for saveIsacIdVerificationV1")
  public void nullIsIdVerifiedForSaveIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.getIdVerificationInfo().setIsIdVerified(null);

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals("Invalid input request. INSERT: ID Verified cannot be null", errorResponse.getMessage());
  }

  @Test(priority = 14, description = "null patientId for updateRecordIsacIdVerificationV1")
  public void nullPatientIdForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setPatientId(null);

    // Step - 3: Calling update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: PatientId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 15, description = "zero patientId for updateRecordIsacIdVerificationV1")
  public void zeroPatientIdForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setPatientId("");

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: PatientId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 16, description = "null storeNbr for updateRecordIsacIdVerificationV1")
  public void nullStoreNbrForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setStoreNbr(null);

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: StoreNbr cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 17, description = "zero storeNbr for updateRecordIsacIdVerificationV1")
  public void zeroStoreNbrForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setStoreNbr("");

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: StoreNbr cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 18, description = "null emailId for updateRecordIsacIdVerificationV1")
  public void nullEmailIdForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailId(null);

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: EmailId cannot be null/empty", errorResponse.getMessage());
  }

  @Test(priority = 19, description = "invalid emailId for updateRecordIsacIdVerificationV1")
  public void invalidEmailIdForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailId("test#com");

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: Invalid Email Id address", errorResponse.getMessage());
  }

  @Test(priority = 20, description = "null idVerifiedInfo for updateRecordIsacIdVerificationV1")
  public void nullIdVerifiedInfoForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIdVerificationInfo(null);

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: Id Verification Info cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 22, description = "null isIdVerified for updateRecordIsacIdVerificationV1")
  public void nullIsIdVerifiedForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.getIdVerificationInfo().setIsIdVerified(null);

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: ID Verified cannot be null", errorResponse.getMessage());
  }





  @Test(priority = 27, description = "null existingInfo for updateRecordIsacIdVerificationV1")
  public void nullExistingInfoForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setExistingIdInfo(null);

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: ExistingIdInfo cannot be null",
            errorResponse.getMessage());
  }

  @Test(priority = 28, description = "null existingInfo.stageId for updateRecordIsacIdVerificationV1")
  public void nullExistingInfoStageIdForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: ExistingIdInfo StageId cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 29, description = "null existingInfo.emailId for updateRecordIsacIdVerificationV1")
  public void nullExistingInfoEmailForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setEmailId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: ExistingIdInfo Email Id cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 30, description = "invalid existingInfo.emailId for updateRecordIsacIdVerificationV1")
  public void invalidExistingInfoEmailForUpdateRecordIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateRecordIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setEmailId("sam#com");
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Record Isac Id Verification
    Response<ServiceResponse> updateRecordIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_RECORD");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateRecordIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_RECORD: ExistingIdInfo Invalid EmailId address",
            errorResponse.getMessage());
  }

  @Test(priority = 31, description = "null dobRetries for updateDobRetriesIsacIdVerificationV1")
  public void nullDobRetriesForUpdateDobRetriesIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateDobRetriesIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setDobRetries(null);

    // Step - 3: Calling Update Dob Retries Isac Id Verification
    Response<ServiceResponse> updateDobRetriesIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_DOB_RETRIES");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateDobRetriesIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals("Invalid input request. DOB Retries cannot be null", errorResponse.getMessage());
  }

  @Test(priority = 33, description = "null existingInfo for updateDobRetriesIsacIdVerificationV1")
  public void nullExistingInfoForUpdateDobRetriesIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateDobRetriesIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setDobRetries("2");
    upsertIsacIdVerificationV1Request.setExistingIdInfo(null);

    // Step - 3: Calling Update Dob Retries Isac Id Verification
    Response<ServiceResponse> updateDobRetriesIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_DOB_RETRIES");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateDobRetriesIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_DOB_RETRIES: ExistingIdInfo cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 34, description = "null existingInfo.stagedId for updateDobRetriesIsacIdVerificationV1")
  public void nullExistingInfoStageIdForUpdateDobRetriesIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateDobRetriesIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setDobRetries("2");
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Dob Retries Isac Id Verification
    Response<ServiceResponse> updateDobRetriesIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_DOB_RETRIES");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateDobRetriesIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_DOB_RETRIES: ExistingIdInfo StageId cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 35, description = "null sentEmailCounter for updateEmailCounterIsacIdVerificationV1")
  public void nullSentEmailCounterForUpdateEmailCounterIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter(null);

    // Step - 3: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. Sent Email Counter cannot be null/0/1", errorResponse.getMessage());
  }

  @Test(priority = 36, description = "zero emailSentCounter for updateEmailCounterIsacIdVerificationV1")
  public void zeroEmailSentCounterForUpdateEmailCounterIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter("0");

    // Step - 3: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. Sent Email Counter cannot be null/0/1", errorResponse.getMessage());
  }

  @Test(priority = 37, description = "one emailSentCounter for updateEmailCounterIsacIdVerificationV1")
  public void oneEmailSentCounterForUpdateEmailCounterIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter("1");

    // Step - 3: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. Sent Email Counter cannot be null/0/1", errorResponse.getMessage());
  }

  @Test(priority = 38, description = "null existingInfo for updateEmailCounterIsacIdVerificationV1")
  public void nullExistingInfoForUpdateEmailCounterIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter("2");
    upsertIsacIdVerificationV1Request.setExistingIdInfo(null);

    // Step - 3: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_EMAIL_COUNTER: ExistingIdInfo cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 39, description = "null existingInfo.stagedId for updateEmailCounterIsacIdVerificationV1")
  public void nullExistingInfoStageIdForUpdateEmailCounterIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));
    upsertIsacIdVerificationV1Request.setEmailSentCounter("2");
    // Step - 3: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. UPDATE_EMAIL_COUNTER: ExistingIdInfo StageId cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 40, description = "null accountCreated for updateAccountCreatedIsacIdVerificationV1")
  public void nullAccountCreatedForUpdateAccountCreatedIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateAccountCreatedIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsAccountCreated(null);

    // Step - 3: Calling Update Account Created Isac Id Verification
    Response<ServiceResponse> updateAccountCreatedIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "ACCOUNT_CREATED");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateAccountCreatedIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals("Invalid input request. isAccountCreated cannot be null", errorResponse.getMessage());
  }

  @Test(priority = 41, description = "null existingInfo for updateAccountCreatedIsacIdVerificationV1")
  public void nullExistingInfoForUpdateAccountCreatedIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateAccountCreatedIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsAccountCreated(Boolean.TRUE.toString());
    upsertIsacIdVerificationV1Request.setExistingIdInfo(null);

    // Step - 3: Calling Update Account Created Isac Id Verification
    Response<ServiceResponse> updateAccountCreatedIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "ACCOUNT_CREATED");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateAccountCreatedIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. ACCOUNT_CREATED: ExistingIdInfo cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 42, description = "null existingInfo.stagedId for updateAccountCreatedIsacIdVerificationV1")
  public void nullExistingInfoStageIdForUpdateAccountCreatedIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateAccountCreatedIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsAccountCreated(Boolean.TRUE.toString());
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Account Created Isac Id Verification
    Response<ServiceResponse> updateAccountCreatedIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "ACCOUNT_CREATED");

    // Step - 4: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateAccountCreatedIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. ACCOUNT_CREATED: ExistingIdInfo StageId cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 43, description = "null expired for updateExpiredIsacIdVerificationV1")
  public void nullExpiredForUpdateExpiredIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsExpired(null);

    // Step - 3: Calling Update Expired Isac Id Verification
    Response<ServiceResponse> updateExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "EXPIRED");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals("Invalid input request. isExpired cannot be null", errorResponse.getMessage());
  }

  @Test(priority = 44, description = "null existingInfo for updateExpiredIsacIdVerificationV1")
  public void nullExistingInfoForUpdateExpiredIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsExpired(Boolean.TRUE.toString());
    upsertIsacIdVerificationV1Request.setExistingIdInfo(null);

    // Step - 3: Calling Update Expired Isac Id Verification
    Response<ServiceResponse> updateExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "EXPIRED");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. EXPIRED: ExistingIdInfo cannot be null/empty",
            errorResponse.getMessage());
  }

  @Test(priority = 45, description = "null existingInfo.stagedId for updateExpiredIsacIdVerificationV1")
  public void nullExistingInfoStageIdForUpdateExpiredIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the updateExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsExpired(Boolean.TRUE.toString());
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(null);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 3: Calling Update Expired Isac Id Verification
    Response<ServiceResponse> updateExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "EXPIRED");

    // Step - 4: Asserting response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
    Assert.assertEquals(
            "Invalid input request. EXPIRED: ExistingIdInfo StageId cannot be null/empty",
            errorResponse.getMessage());
  }
  @Test(priority = 46, description = "save Isac Id Verification")
  public void saveIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Assert.assertNotNull(saveIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);

    String stageId = response.getStageId();
    Assert.assertNotNull(stageId);
    Assert.assertNotNull(response);
  }

  @Test(priority = 47, description = "update Email Counter Isac Id Verification")
  public void updateEmailCounterIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Building the updateEmailCounterIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter("2");
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 4: Calling Update Email Counter Isac Id Verification
    Response<ServiceResponse> updateEmailCounterIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 5: Asserting response
    Assert.assertNotNull(updateEmailCounterIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateEmailCounterIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    Assert.assertEquals(stageId, response.getStageId());
  }

  @Test(priority = 48, description = "update Dob Retries Isac Id Verification")
  public void updateDobRetriesIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Building the updateDobRetriesIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setDobRetries("1");
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 4: Calling Update Dob Retries Isac Id Verification
    Response<ServiceResponse> updateDobRetriesIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_DOB_RETRIES");

    // Step - 5: Asserting response
    Assert.assertNotNull(updateDobRetriesIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateDobRetriesIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    Assert.assertEquals(stageId, response.getStageId());
  }

  @Test(priority = 49, description = "update Account Created Isac Id Verification")
  public void updateAccountCreatedIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Building the updateAccountCreatedIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsAccountCreated(Boolean.TRUE.toString());
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 4: Calling Update Account Created Isac Id Verification
    Response<ServiceResponse> updateAccountCreatedIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "ACCOUNT_CREATED");

    // Step - 5: Asserting response
    Assert.assertNotNull(updateAccountCreatedIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateAccountCreatedIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    Assert.assertEquals(stageId, response.getStageId());
  }

  @Test(priority = 51, description = "updateExpired Isac Id Verification")
  public void updateExpiredIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Building the updateExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsExpired(Boolean.TRUE.toString());
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 4: Calling Update Expired Isac Id Verification
    Response<ServiceResponse> updateExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "EXPIRED");

    // Step - 5: Asserting response
    Assert.assertNotNull(updateExpiredIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updateExpiredIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);

    Assert.assertEquals(stageId, response.getStageId());
  }

  @Test(priority = 52, description = "updateEmailCounter when expired Isac Id Verification")
  public void updateEmailCounterWhenExpiredIsacIdVerificationV1Error() throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step - 2: INSERT a new ISAC record to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertResponse =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertResponse.body());
    UpsertIsacIdVerificationV1Response insertResult = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertResponse.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String localStageId = insertResult.getStageId();
    Assert.assertNotNull(localStageId);

    // Step - 3: Expire the newly inserted record to make it inactive in DB
    String expireTrackID = CommonUtil.randomUUID();
    String expireReqId = reqIdString + expireTrackID;
    String expireReqTrackingId = reqTrackingString + expireTrackID;
    UpsertIsacIdVerificationV1Request expireRequest = new UpsertIsacIdVerificationV1Request();
    expireRequest.setIsExpired(Boolean.TRUE.toString());
    ExistingIdInfo expireExistingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    expireExistingIdInfo.setStageId(localStageId);
    expireRequest.setExistingIdInfo(Collections.singletonList(expireExistingIdInfo));
    Response<ServiceResponse> expireResponse =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, expireReqId, expireReqTrackingId, expireRequest, "EXPIRED");
    Assert.assertNotNull(expireResponse.body());

    // Step - 4: Building the updateEmailCounter request with the now-expired stageId
    String updateTrackID = CommonUtil.randomUUID();
    String updateReqId = reqIdString + updateTrackID;
    String updateReqTrackingId = reqTrackingString + updateTrackID;
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailSentCounter("2");
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(localStageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 5: Calling Update Email Counter When Expired Isac Id Verification
    Response<ServiceResponse> updateEmailCounterWhenExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, updateReqId, updateReqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_EMAIL_COUNTER");

    // Step - 6: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateEmailCounterWhenExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals("DPR-DPACCENSR-1031", errorResponse.getCode());
    Assert.assertEquals(
            "The given Stage Id is not found/inactive in DB, unable to update sent email counter. " + localStageId,
            errorResponse.getMessage());
  }

  @Test(priority = 53, description = "updateDobRetries when expired Isac Id Verification")
  public void updateDobRetriesWhenExpiredIsacIdVerificationV1Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Expire the newly inserted record to make it inactive in DB
    UpsertIsacIdVerificationV1Request expireRequest = new UpsertIsacIdVerificationV1Request();
    expireRequest.setIsExpired(Boolean.TRUE.toString());
    ExistingIdInfo expireIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    expireIdInfo.setStageId(stageId);
    expireRequest.setExistingIdInfo(Collections.singletonList(expireIdInfo));
    Response<ServiceResponse> expireIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, expireRequest, "EXPIRED");
    Assert.assertNotNull(expireIsacIdVerificationV1Response.body());

    // Step 4: Building the updateDobRetriesWhenExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setDobRetries("1");
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 5: Calling Update Dob Retries When Expired Isac Id Verification
    Response<ServiceResponse> updateDobRetriesWhenExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "UPDATE_DOB_RETRIES");

    // Step - 6: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateDobRetriesWhenExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals("DPR-DPACCENSR-1029", errorResponse.getCode());
    Assert.assertEquals("The given Stage Id is not found/inactive in DB, unable to update Dob Retries. " +
            stageId, errorResponse.getMessage());
  }

  @Test(priority = 54, description = "updateAccountCreated when expired Isac Id Verification")
  public void updateAccountCreatedWhenExpiredIsacIdVerificationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: INSERT to obtain a fresh stageId
    UpsertIsacIdVerificationV1Request insertRequest = buildUpsertIsacIdVerificationV1Request();
    Response<ServiceResponse> insertIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, insertRequest, "INSERT");
    Assert.assertNotNull(insertIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response insertResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) insertIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);
    String stageId = insertResponse.getStageId();
    Assert.assertNotNull(stageId);

    // Step 3: Expire the newly inserted record to make it inactive in DB
    UpsertIsacIdVerificationV1Request expireRequest = new UpsertIsacIdVerificationV1Request();
    expireRequest.setIsExpired(Boolean.TRUE.toString());
    ExistingIdInfo expireIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    expireIdInfo.setStageId(stageId);
    expireRequest.setExistingIdInfo(Collections.singletonList(expireIdInfo));
    Response<ServiceResponse> expireIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, expireRequest, "EXPIRED");
    Assert.assertNotNull(expireIsacIdVerificationV1Response.body());

    // Step 4: Building the updateAccountCreatedWhenExpiredIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setIsAccountCreated(Boolean.TRUE.toString());
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    upsertIsacIdVerificationV1Request.setExistingIdInfo(Collections.singletonList(existingIdInfo));

    // Step - 5: Calling Update Account Created When Expired Isac Id Verification
    Response<ServiceResponse> updateDobRetriesWhenExpiredIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "ACCOUNT_CREATED");

    // Step - 6: Asserting response
    Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, updateDobRetriesWhenExpiredIsacIdVerificationV1Response);
    Assert.assertNotNull(errorResponse);
    Assert.assertEquals( "DPR-DPACCENSR-1032", errorResponse.getCode());
    Assert.assertEquals(
            "The given Stage Id is not found/inactive in DB, unable to update Account Created. " + stageId,
            errorResponse.getMessage());
  }

  private static void logFlowIdentifiers(
          String domainId, String reqId, String reqTrackingId) {
    Reporter.logJSON("domainId", domainId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }

  private ExistingIdInfo buildUpsertIsacIdVerificationV1RequestExistingIdInfo() {
    ExistingIdInfo existingInfo = new ExistingIdInfo();
    existingInfo.setStageId("12345");
    existingInfo.setEmailId("test@walmart.com");
    return existingInfo;
  }
  private UpsertIsacIdVerificationV1Request buildUpsertIsacIdVerificationV1Request() {
    UpsertIsacIdVerificationV1RequestIdVerificationInfo idVerificationInfo =
            new UpsertIsacIdVerificationV1RequestIdVerificationInfo();
    idVerificationInfo.isIdVerified(Boolean.TRUE.toString());

    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request =
            new UpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.setEmailId("test@walmart.com");
    upsertIsacIdVerificationV1Request.dob("12122002");
    upsertIsacIdVerificationV1Request.firstName("Sam");
    upsertIsacIdVerificationV1Request.lastName("Walton");
    upsertIsacIdVerificationV1Request.storeNbr("5567");
    upsertIsacIdVerificationV1Request.setPatientId("12345");
    upsertIsacIdVerificationV1Request.idVerificationInfo(idVerificationInfo);

    return upsertIsacIdVerificationV1Request;
  }
  @Test(priority = 55, description = "save Isac Id Verification")
  public void updatingIdVerifiedForIsacIdVerficationV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(domainId, reqId, reqTrackingId);

    // Step 2: Building the saveIsacIdVerificationV1 request
    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1Request = buildUpsertIsacIdVerificationV1Request();
    upsertIsacIdVerificationV1Request.getIdVerificationInfo().setIsIdVerified(Boolean.FALSE.toString());

    // Step - 3: Calling Save Isac Id Verification
    Response<ServiceResponse> saveIsacIdVerificationV1Response =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1Request, "INSERT");

    // Step - 4: Asserting response
    Assert.assertNotNull(saveIsacIdVerificationV1Response.body());
    UpsertIsacIdVerificationV1Response response = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveIsacIdVerificationV1Response.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);

    String stageId = response.getStageId();
    Assert.assertNotNull(stageId);
    Assert.assertNotNull(response);

    UpsertIsacIdVerificationV1Request upsertIsacIdVerificationV1RequestToUpdateISACRecord = buildUpsertIsacIdVerificationV1Request();
    ExistingIdInfo existingIdInfo = buildUpsertIsacIdVerificationV1RequestExistingIdInfo();
    existingIdInfo.setStageId(stageId);
    existingIdInfo.setEmailId(upsertIsacIdVerificationV1RequestToUpdateISACRecord.getEmailId());
    upsertIsacIdVerificationV1RequestToUpdateISACRecord.setExistingIdInfo(List.of(existingIdInfo));
    upsertIsacIdVerificationV1RequestToUpdateISACRecord.getIdVerificationInfo().setIsIdVerified(Boolean.TRUE.toString());

    Response<ServiceResponse> saveIsacIdVerificationV1ResponseForUpdateRecord =
            accountEntityServiceRetrofit.upsertIsacIdVerificationV1(
                    domainId, reqId, reqTrackingId, upsertIsacIdVerificationV1RequestToUpdateISACRecord, "UPDATE_RECORD");

    Assert.assertNotNull(saveIsacIdVerificationV1ResponseForUpdateRecord.body());
    UpsertIsacIdVerificationV1Response updateResponse = ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveIsacIdVerificationV1ResponseForUpdateRecord.body().getPayload()),
            UpsertIsacIdVerificationV1Response.class);

    stageId = updateResponse.getStageId();
    Assert.assertNotNull(stageId);
    Assert.assertNotNull(updateResponse);
  }
}