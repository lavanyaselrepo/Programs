package accountentity.fam;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class AccountEntityUpdateFamLinkagesServiceTest {
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private Gson gson = new GsonBuilder().create();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String caregiverCustomerAccountId = "03d23d36-d882-4ae0-ad91-cd5a37d78d91";
    private String dependentCustomerAccountId = "4bd0866d-5768-413d-9c64-3712f59c9ebd";

    @BeforeClass
    void setContext() {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        gson = new Gson();
    }

    private static void logFlowIdentifiers(
            String domainId, String reqId, String reqTrackingId) {
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }

    private UpdateFamLinkageStatusV1Request buildUpdateFamLinkageStatusV1RequestWithCaregiverInfo(){

        CaregiverInfoWithLinkageStatus caregiverInfoWithLinkageStatus = new CaregiverInfoWithLinkageStatus();
        caregiverInfoWithLinkageStatus.setCustomerAccountId(caregiverCustomerAccountId);
        caregiverInfoWithLinkageStatus.setLinkageStatus("ACTIVE");

        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = new UpdateFamLinkageStatusV1Request();
        updateFamLinkageStatusV1Request.caregiver(caregiverInfoWithLinkageStatus);
        return updateFamLinkageStatusV1Request;
    }

    private UpdateFamLinkageStatusV1Request buildUpdateFamLinkageStatusV1RequestWithDependentInfo(){

        DependentInfoWithLinkageStatus dependentInfoWithLinkageStatus = new DependentInfoWithLinkageStatus();
        dependentInfoWithLinkageStatus.setCustomerAccountId(dependentCustomerAccountId);
        dependentInfoWithLinkageStatus.setLinkageStatus("ACTIVE");

        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = new UpdateFamLinkageStatusV1Request();
        updateFamLinkageStatusV1Request.dependent(dependentInfoWithLinkageStatus);
        return updateFamLinkageStatusV1Request;
    }

    @Test(priority = 0, description = "Invalid Domain Id")
    public void invalidDomainIdForUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithCaregiverInfo();

        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response = accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, dependentCustomerAccountId,
                "InvalidDomain", reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. domainId InvalidDomain is invalid", errorResponse.getMessage());
    }

    @Test(priority = 1, description = "caregiver's onlineAccountId is empty")
    public void nullOnlineAccountIdForCaregiverInUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithCaregiverInfo();
        updateFamLinkageStatusV1Request.getCaregiver().setCustomerAccountId(null);

        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
                accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, dependentCustomerAccountId,
                domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. CustomerAccountId for the caregiver cannot be null/empty", errorResponse.getMessage());
    }

    @Test(priority = 2, description = "null Caregiver And Null Dependent In Request")
    public void nullCaregiverAndNullDependentInRequestForUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = new UpdateFamLinkageStatusV1Request();

        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
        accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, dependentCustomerAccountId,
                domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. Update Fam Linkage Status request should either have Caregiver Info or Dependent Info present. Both cannot be null/empty", errorResponse.getMessage());
    }

    @Test(priority = 3, description = "null linkage status")
    public void nullLinkageStatusForUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithCaregiverInfo();
        updateFamLinkageStatusV1Request.getCaregiver().setLinkageStatus(null);


        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
        accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, dependentCustomerAccountId,
                domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. linkageStatus cannot be null/empty", errorResponse.getMessage());
    }

    @Test(priority = 4, description = "dependent's onlineAccountId is empty")
    public void nullOnlineAccountIdForDependentInUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithDependentInfo();
        updateFamLinkageStatusV1Request.getDependent().setCustomerAccountId(null);


        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
                accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, caregiverCustomerAccountId,
                        domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. CustomerAccountId for the dependent cannot be null/empty", errorResponse.getMessage());
    }

    @Test(priority = 5, description = "invalid value for fam linkage status")
    public void invalidValueForFamLinkageStatusInUpdateFamLinkagesV1Error() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithDependentInfo();
        updateFamLinkageStatusV1Request.getDependent().setLinkageStatus("Invalid");


        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
                accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, caregiverCustomerAccountId,
                        domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updateFamLinkageStatusV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. Invalid : Fam Linkage Status provided is invalid.", errorResponse.getMessage());
    }

    @Test(priority = 6, description = "Update fam linkages successfully with caregiver's info")
    public void updateFamLinkagesSuccessForCaregiver() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithCaregiverInfo();

        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
                accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, dependentCustomerAccountId,
                        domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertNotNull(updateFamLinkageStatusV1Response.body());
        UpdateFamLinkageStatusV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) updateFamLinkageStatusV1Response.body().getPayload()),
                UpdateFamLinkageStatusV1Response.class);

        Assert.assertNotNull(response);
        String caregiverCustomerAccountIdFromResponse = response.getCaregiver().getCustomerAccountId();
        Assert.assertNotNull(caregiverCustomerAccountIdFromResponse);
        Assert.assertEquals(caregiverCustomerAccountIdFromResponse, caregiverCustomerAccountId);
    }

    @Test(priority = 7, description = "Update fam linkages successfully with dependent's info")
    public void updateFamLinkagesSuccessForDependent() throws IOException {

        // Step - 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the updateFamLinkageStatusV1 request
        UpdateFamLinkageStatusV1Request updateFamLinkageStatusV1Request = buildUpdateFamLinkageStatusV1RequestWithDependentInfo();

        // Step - 3: Calling update Fam Linkage Status
        Response<ServiceResponse> updateFamLinkageStatusV1Response =
                accountEntityServiceRetrofit.updateFamLinkageStatusV1(updateFamLinkageStatusV1Request, caregiverCustomerAccountId,
                        domainId, reqId, reqTrackingId);

        // Step - 4: Asserting response
        Assert.assertNotNull(updateFamLinkageStatusV1Response.body());
        UpdateFamLinkageStatusV1Response response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>) updateFamLinkageStatusV1Response.body().getPayload()),
                UpdateFamLinkageStatusV1Response.class);

        Assert.assertNotNull(response);
        String dependentCustomerAccountIdFromResponse = response.getDependent().getCustomerAccountId();
        Assert.assertNotNull(dependentCustomerAccountIdFromResponse);
        Assert.assertEquals(dependentCustomerAccountIdFromResponse, dependentCustomerAccountId);
    }
}
