package accountentity.fam;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.familyIds;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.famErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.getFamilyResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getFamRequestWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.updateFamRequestWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.Objects;

public class getFamRequestTests {

    getFamRequestWrapper famWrapper = new getFamRequestWrapper();
    CommonUtils utility  = new CommonUtils();

    @Test(
            priority = 1, description = "Get data for caregiver and dependent if Account consent is pending",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "getFamRequest")
    public void dependAndCareValid (Map<String, String> inputData){

        String dependentId = utility.nullStringValidation(inputData.get("dependentId"));
        String caregiverId = utility.nullStringValidation(inputData.get("caregiverId"));
        String addInfoOne = utility.nullStringValidation(inputData.get("addInfoOne"));
        String addInfoTwo = utility.nullStringValidation(inputData.get("addInfoTwo"));
        String type = utility.nullStringValidation(inputData.get("type"));
        String status = utility.nullStringValidation(inputData.get("status"));
        String validDependentId = utility.nullStringValidation(inputData.get("validDependentId"));
        String validCaregiverId = utility.nullStringValidation(inputData.get("validCaregiverId"));
        String errorCode = utility.nullStringValidation(inputData.get("errorCode"));
        String errorMessage = utility.nullStringValidation(inputData.get("errorMessage"));



        //updating to ensure data is correct
        if (Integer.parseInt(status)==200){
            updateFamRequestWrapper updateWrapper = new updateFamRequestWrapper();
            ServiceResponse updateFam = updateWrapper.updateFamRequestFunction(validCaregiverId, validDependentId, type, addInfoOne,addInfoTwo);

        }
        ServiceResponse getFam = famWrapper.getFamRequestFunction(caregiverId, dependentId, type);

        if (getFam.getStatusCode()==200) {
            getFamilyResponse getFamResponse = getFam.getDataResponse(getFamilyResponse.class);
            //System.out.println(getFamResponse.toString());
            familyIds familyId = getFamResponse.getPayload().get(0);
            Assert.assertEquals(validDependentId, familyId.getDependentId());
            Assert.assertEquals(validCaregiverId, familyId.getCaregiverId());
            Assert.assertEquals(Integer.parseInt(status), getFam.getStatusCode());

            //Validations for different response depending on type
            if (Objects.equals(type, "PENDING_ACCOUNT_CREATION")) {
                Assert.assertEquals(familyId.getAdditionalInfo().getStoreNbr(), addInfoOne);
                Assert.assertEquals( familyId.getAdditionalInfo().getPatientId(), addInfoTwo);
            }
            else {
                Assert.assertEquals(addInfoOne, familyId.getAdditionalInfo().getEmailSentCounter());

            }
        }
        else {
            Assert.assertEquals(Integer.parseInt(status), getFam.getStatusCode());
            famErrorResponse errorResponse = getFam.getDataResponse(famErrorResponse.class);
            Assert.assertEquals(errorResponse.getError().getCode(), errorCode);
            Assert.assertEquals(errorResponse.getError().getMessage(), errorMessage);
        }//end of if/else statement


    }


}
