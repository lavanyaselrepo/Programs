package accountentity.fam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.Status;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.FamDelinkAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityFamDelinkAccountServiceTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String dependentCustomerAccountId = null;
  private String caregiverCustomerAccountId = null;
  private String commonOnlineAccountId = null;
  private String commonDobDPFormat = null;
  private List<String> dependentCustomerAccountIdList = null;
  private List<String> caregiverCustomerAccountIdList = null;

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    dependentCustomerAccountId = CommonUtil.randomUUID();
    caregiverCustomerAccountId = CommonUtil.randomUUID();
    commonOnlineAccountId = CommonUtil.randomUUID();
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    dependentCustomerAccountIdList = new ArrayList<>();
    caregiverCustomerAccountIdList = new ArrayList<>();
    createSaveFamLink(dependentCustomerAccountId);
  }

  /**
   * Save/inserts the fam links for a given dependent in the db
   *
   * @throws IOException
   */
  public void createSaveFamLink(String dependentCustomerAccountId) throws IOException {
    SaveFamLinksRequest saveFamLinksRequest = getSaveFamLinksV1Request(dependentCustomerAccountId);
    Response<ServiceResponse> response = null;

    // This will try to create a fam link in Account Entity, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response =
          accountEntityServiceRetrofit.saveFamLinksV1(
              saveFamLinksRequest, commonOnlineAccountId, domainId, reqIdString, reqTrackingString);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && !response.isSuccessful()) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "Account Entity save fam links creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  /**
   * Builds accEntity save fam links request
   *
   * @return
   */
  private SaveFamLinksRequest getSaveFamLinksV1Request(String dependentCustomerAccountId) {
    SaveFamLinksRequest saveFamLinksRequest = new SaveFamLinksRequest();
    List<DependentInfos> dependentsInfo = new ArrayList<>();
    DependentInfos dependentsInfoItem = new DependentInfos();
    dependentsInfo.add(
        dependentsInfoItem.customerAccountId(dependentCustomerAccountId).dob(commonDobDPFormat));
    return saveFamLinksRequest.dependentsInfo(dependentsInfo);
  }

  /**
   * Builds accEntity delink fam links request
   *
   * @return
   */
  private FamDelinkAccountRequest getFamDelinkAccountV1Request(
      List<String> dependentCustomerAccountIdList, List<String> caregiverCustomerAccountIdList) {
    FamDelinkAccountRequest famDelinkAccountRequest = new FamDelinkAccountRequest();
    List<DependentInfo> dependentsInfo = new ArrayList<>();
    List<CaregiverInfo> caregiversInfo = new ArrayList<>();

    dependentCustomerAccountIdList.forEach(
        dependentAccountId ->
            dependentsInfo.add(new DependentInfo().customerAccountId(dependentAccountId)));

    caregiverCustomerAccountIdList.forEach(
        caregiverAccountId ->
            caregiversInfo.add(new CaregiverInfo().customerAccountId(caregiverAccountId)));

    return famDelinkAccountRequest.dependentsInfo(dependentsInfo).caregiversInfo(caregiversInfo);
  }

  @Test(priority = 0, description = "Get fam delink account success case")
  public void getFamDelinkAccountV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step 2: Building the famDelinkAccountV1 request
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    caregiverCustomerAccountIdList.add(caregiverCustomerAccountId);

    FamDelinkAccountRequest famDelinkAccountRequest =
        getFamDelinkAccountV1Request(
            dependentCustomerAccountIdList, caregiverCustomerAccountIdList);

    // Step - 3: Calling famDelinkAccountV1 with a valid famDelinkAccountRequest ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.famDelinkAccountV1(
            famDelinkAccountRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Parsing the response to the FamDelinkAccountResponse class so that we can assert
    // famDelinkAccountV1
    FamDelinkAccountResponse getFamDelinkAccountResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            FamDelinkAccountResponse.class);

    // Step - 6: Asserting response
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);
    Assert.assertNotNull(apiResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getCustomerAccountId(),
        dependentCustomerAccountId);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getCaregivers().get(0).getCustomerAccountId(),
        caregiverCustomerAccountId);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getStatus(), Status.DELETED);
  }

  @Test(
      priority = 1,
      description = "Get fam delink account success case for dependent id not found")
  public void getFamDelinkAccountV1SuccessForDependentIdNotFound() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String dependentCustomerAccountIdForNotFoundCase = CommonUtil.randomUUID();
    logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Building the famDelinkAccountV1 request with dependentCustomerAccountId not present
    // in db
    dependentCustomerAccountIdList = new ArrayList<>();
    caregiverCustomerAccountIdList = new ArrayList<>();
    dependentCustomerAccountIdList.add(dependentCustomerAccountIdForNotFoundCase);
    caregiverCustomerAccountIdList.add(caregiverCustomerAccountId);

    FamDelinkAccountRequest famDelinkAccountRequest =
        getFamDelinkAccountV1Request(
            dependentCustomerAccountIdList, caregiverCustomerAccountIdList);

    // Step - 3: Calling famDelinkAccountV1 with a valid famDelinkAccountRequest ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.famDelinkAccountV1(
            famDelinkAccountRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Parsing the response to the FamDelinkAccountResponse class so that we can assert
    // famDelinkAccountV1
    FamDelinkAccountResponse getFamDelinkAccountResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            FamDelinkAccountResponse.class);

    // Step - 6: Asserting response
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);
    Assert.assertNotNull(apiResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getCustomerAccountId(),
        dependentCustomerAccountIdForNotFoundCase);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getCaregivers().get(0).getCustomerAccountId(),
        caregiverCustomerAccountId);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getStatus(), Status.NOT_FOUND);
  }

  @Test(
      priority = 2,
      description =
          "Get fam delink account success case for a list in which one dependent id is not found and one dependent id exists in the db ")
  public void getFamDelinkAccountV1SuccessForDependentIdNotFoundAndDependentIdExists()
      throws IOException {

    // Step - 1 : Creating a fam link and adding it in dependentCustomerAccountIdList
    dependentCustomerAccountIdList = new ArrayList<>();
    caregiverCustomerAccountIdList = new ArrayList<>();
    String dependentCustomerAccountIdForFoundCase = CommonUtil.randomUUID();
    createSaveFamLink(dependentCustomerAccountIdForFoundCase);
    dependentCustomerAccountIdList.add(dependentCustomerAccountIdForFoundCase);
    caregiverCustomerAccountIdList.add(caregiverCustomerAccountId);

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Generating a new dependentCustomerAccountId which doesn't exists in db and adding
    // it in the dependentCustomerAccountIdList
    String dependentCustomerAccountIdForNotFoundCase = CommonUtil.randomUUID();
    dependentCustomerAccountIdList.add(dependentCustomerAccountIdForNotFoundCase);

    // Step - 4: Building the famDelinkAccountV1 request with dependentCustomerAccountId not present
    // in db
    FamDelinkAccountRequest famDelinkAccountRequest =
        getFamDelinkAccountV1Request(
            dependentCustomerAccountIdList, caregiverCustomerAccountIdList);

    // Step - 5: Calling famDelinkAccountV1 with a valid famDelinkAccountRequest ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.famDelinkAccountV1(
            famDelinkAccountRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 6: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7: Parsing the response to the FamDelinkAccountResponse class so that we can assert
    // famDelinkAccountV1
    FamDelinkAccountResponse getFamDelinkAccountResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            FamDelinkAccountResponse.class);

    // Step - 8: Asserting response
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);
    Assert.assertNotNull(apiResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getCustomerAccountId(),
        dependentCustomerAccountIdForFoundCase);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getCaregivers().get(0).getCustomerAccountId(),
        caregiverCustomerAccountId);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(0).getStatus(), Status.DELETED);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(1).getCustomerAccountId(),
        dependentCustomerAccountIdForNotFoundCase);
    Assert.assertEquals(
        getFamDelinkAccountResponse.getDependents().get(1).getStatus(), Status.NOT_FOUND);
  }

  @Test(
      priority = 3,
      description = "Get fam delink account failure due to invalid domain id already exists")
  public void getFamDelinkAccountV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMA";
    logFlowIdentifiers(commonOnlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step 2: Building the famDelinkAccountV1 request
    dependentCustomerAccountIdList = new ArrayList<>();
    caregiverCustomerAccountIdList = new ArrayList<>();
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    caregiverCustomerAccountIdList.add(caregiverCustomerAccountId);

    FamDelinkAccountRequest famDelinkAccountRequest =
        getFamDelinkAccountV1Request(
            dependentCustomerAccountIdList, caregiverCustomerAccountIdList);

    // Step - 3: Calling famDelinkAccountV1 with a valid famDelinkAccountRequest ,invalid domainId
    // and
    // valid onlineAccountId
    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.famDelinkAccountV1(
            famDelinkAccountRequest, commonOnlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "Invalid input request. Invalid input request. domainId WM-PHARMA is invalid");
  }

  private static void logFlowIdentifiers(
      String commonOnlineAccountId, String domainId, String reqId, String reqTrackingId) {
    Reporter.logJSON("onlineAccountId", commonOnlineAccountId);
    Reporter.logJSON("domainId", domainId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
