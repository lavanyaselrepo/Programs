package accountentity.fam;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.familyIds;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.famErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.getFamilyResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getFamRequestWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.updateFamRequestWrapper;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.Objects;

public class updateFamRequestTests {

    updateFamRequestWrapper updateWrapper = new updateFamRequestWrapper();
    CommonUtils utility = new CommonUtils();


    @Test(priority = 1, description = "Testing update API for caregiver and dependent HIPAA and ACCOUNT consent",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "updateFamRequest")
    public void updateDependAndCare (Map<String, String> inputData){
        String dependentId = utility.nullStringValidation(inputData.get("dependentId"));
        String caregiverId = utility.nullStringValidation(inputData.get("caregiverId"));
        String addInfoOne = utility.nullStringValidation(inputData.get("addInfoOne"));
        String addInfoTwo = utility.nullStringValidation(inputData.get("addInfoTwo"));
        String type = utility.nullStringValidation(inputData.get("type"));
        String status = utility.nullStringValidation(inputData.get("status"));
        String errorCode = utility.nullStringValidation(inputData.get("errorCode"));
        String errorMessage = utility.nullStringValidation(inputData.get("errorMessage"));

        ServiceResponse updateFam = updateWrapper.updateFamRequestFunction(caregiverId, dependentId, type, addInfoOne,addInfoTwo);

        if (updateFam.getStatusCode() == 200) {
            getFamilyResponse getFamResponse = updateFam.getDataResponse(getFamilyResponse.class);
            familyIds familyId = getFamResponse.getPayload().get(0);

            Assert.assertEquals(Integer.parseInt(status), updateFam.getStatusCode());
            Assert.assertEquals(familyId.getDependentId(), dependentId);
            Assert.assertEquals(familyId.getCaregiverId(), caregiverId);

            //calling get to check database was updated correctly
            getFamRequestWrapper getFamWrapper = new getFamRequestWrapper();
            ServiceResponse getFam = getFamWrapper.getFamRequestFunction(caregiverId, dependentId, type);
            getFamilyResponse getFamilyResponseTwo = getFam.getDataResponse(getFamilyResponse.class);
            familyIds familyIdTwo = getFamilyResponseTwo.getPayload().get(0);
            Assert.assertEquals(familyIdTwo.getDependentId(), dependentId);
            Assert.assertEquals(familyIdTwo.getCaregiverId(), caregiverId);


            //for different response types
            if (Objects.equals(type, "PENDING_ACCOUNT_CREATION")) {
                Assert.assertEquals(addInfoOne, familyIdTwo.getAdditionalInfo().getStoreNbr());
                Assert.assertEquals(addInfoTwo, familyIdTwo.getAdditionalInfo().getPatientId());
            }
            else {
                Assert.assertEquals(addInfoOne, familyIdTwo.getAdditionalInfo().getEmailSentCounter());

            }
        }
        else {
            Assert.assertEquals(Integer.parseInt(status), updateFam.getStatusCode());
            Reporter.log("Status Code ===" + updateFam.getStatusCode());
            famErrorResponse errorResponse = updateFam.getDataResponse(famErrorResponse.class);
            Assert.assertEquals(errorResponse.getError().getCode(), errorCode);
            Assert.assertEquals(errorResponse.getError().getMessage(), errorMessage);
        }
    }


}
