package accountentity.fam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.SaveFamLinksResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntitySaveFamLinksAccountServiceTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String dependentCustomerAccountId = null;
  private String commonOnlineAccountId = null;
  private String commonDobDPFormat = null;
  private List<String> dependentCustomerAccountIdList = null;

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    dependentCustomerAccountId = CommonUtil.randomUUID();
    commonOnlineAccountId = CommonUtil.randomUUID();
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    dependentCustomerAccountIdList = new ArrayList<>();
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
  }

  /**
   * Builds accEntity save fam links request
   *
   * @return
   */
  private SaveFamLinksRequest getSaveFamLinksV1Request(
      List<String> dependentCustomerAccountIdList) {
    SaveFamLinksRequest saveFamLinksRequest = new SaveFamLinksRequest();
    List<DependentInfos> dependentsInfo = new ArrayList<>();
    dependentCustomerAccountIdList.forEach(
        dependentAccountId ->
            dependentsInfo.add(
                new DependentInfos().customerAccountId(dependentAccountId).dob(commonDobDPFormat)));
    return saveFamLinksRequest.dependentsInfo(dependentsInfo);
  }

  @Test(priority = 0, description = "Save Fam links success case")
  public void saveFamLinksV1SuccessCase() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step 2: Building     saveFamLinksV1Request
    SaveFamLinksRequest saveFamLinksRequest =
        getSaveFamLinksV1Request(dependentCustomerAccountIdList);

    // Step - 3: Calling saveFamLinksV1 with a valid saveFamLinksRequest ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> saveFamLinksResponse =
        accountEntityServiceRetrofit.saveFamLinksV1(
            saveFamLinksRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, saveFamLinksResponse);

    // Step - 5: Parsing the response to the SaveFamLinksResponse class so that we can assert
    // saveFamLinkV1
    SaveFamLinksResponse getSaveFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveFamLinksResponse.body().getPayload()),
            SaveFamLinksResponse.class);
    // Step - 6: Asserting response
    Assert.assertEquals(saveFamLinksResponse.code(), 200, errorMessage);
    Assert.assertNotNull(saveFamLinksResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getSaveFamLinksResponse.getDependents().get(0).getCustomerAccountId(),
        dependentCustomerAccountId);
  }

  @Test(priority = 1, description = "Save Fam links dependent already exists case")
  public void saveFamLinksV1DependentAlreadyExists() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    dependentCustomerAccountIdList = new ArrayList<>();
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step 2: Building saveFamLinksV1Request
    SaveFamLinksRequest saveFamLinksRequest =
        getSaveFamLinksV1Request(dependentCustomerAccountIdList);

    // Step - 3: Calling saveFamLinksV1 with saveFamLinksRequest in which dependent already exists
    // ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> saveFamLinksResponse =
        accountEntityServiceRetrofit.saveFamLinksV1(
            saveFamLinksRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, saveFamLinksResponse);

    // Step - 5: Parsing the response to the SaveFamLinksResponse class so that we can assert
    // saveFamLinkV1
    SaveFamLinksResponse getSaveFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveFamLinksResponse.body().getPayload()),
            SaveFamLinksResponse.class);

    // Step - 6: Asserting response
    Assert.assertEquals(saveFamLinksResponse.code(), 200, errorMessage);
    Assert.assertNotNull(saveFamLinksResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getSaveFamLinksResponse.getDependents().size(),
        dependentCustomerAccountIdList.size(),
        "Mismatch in Dependent List size");
  }

  @Test(priority = 2, description = "Save Fam links one among 2 dependents exist")
  public void saveFamLinksV1OneOfTheDependentExists() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    dependentCustomerAccountIdList = new ArrayList<>();
    String dependentCustomerAccountIdNotExists = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step -2 : Building SaveFamLinksV1Request(add one existing dependentAccountId and one which is
    // not existing)
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    dependentCustomerAccountIdList.add(dependentCustomerAccountIdNotExists);
    SaveFamLinksRequest saveFamLinksRequest =
        getSaveFamLinksV1Request(dependentCustomerAccountIdList);

    // Step - 3: Calling saveFamLinksV1 with saveFamLinksRequest in which one of the dependent
    // already exists ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> saveFamLinksResponse =
        accountEntityServiceRetrofit.saveFamLinksV1(
            saveFamLinksRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, saveFamLinksResponse);

    // Step - 5: Parsing the response to the SaveFamLinksResponse class so that we can assert
    // saveFamLinkV1
    SaveFamLinksResponse getSaveFamLinksResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) saveFamLinksResponse.body().getPayload()),
            SaveFamLinksResponse.class);

    // Step - 6: Asserting response
    Assert.assertEquals(saveFamLinksResponse.code(), 200, errorMessage);
    Assert.assertNotNull(saveFamLinksResponse.body().getPayload(), "Payload is null");
    Assert.assertEquals(
        getSaveFamLinksResponse.getDependents().size(), dependentCustomerAccountIdList.size());
  }

  @Test(priority = 3, description = "Save Fam links Invalid domainId")
  public void saveFamLinksV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String invalidDomainId = "WM-PHARMAC";
    dependentCustomerAccountIdList = new ArrayList<>();
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step 2: Building the saveFamLinksV1Request
    SaveFamLinksRequest saveFamLinksRequest =
        getSaveFamLinksV1Request(dependentCustomerAccountIdList);

    // Step - 3: Calling saveFamLinksV1 with valid saveFamLinksRequest ,Invalid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> saveFamLinksResponse =
        accountEntityServiceRetrofit.saveFamLinksV1(
            saveFamLinksRequest, commonOnlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveFamLinksResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(saveFamLinksResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "Invalid input request. Invalid input request. domainId WM-PHARMAC is invalid");
  }

  @Test(priority = 4, description = "Save Fam links empty dependent info case")
  public void saveFamLinksV1DependentInfoEmpty() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    dependentCustomerAccountIdList = new ArrayList<>();
    dependentCustomerAccountIdList.add(dependentCustomerAccountId);
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step 2: Building saveFamLinksV1Request
    SaveFamLinksRequest saveFamLinksRequest =
        getSaveFamLinksV1Request(dependentCustomerAccountIdList);
    saveFamLinksRequest.setDependentsInfo(new ArrayList<>());

    // Step - 3: Calling saveFamLinksV1 with Invalid saveFamLinksRequest ,valid domainId and
    // valid onlineAccountId
    Response<ServiceResponse> saveFamLinksResponse =
        accountEntityServiceRetrofit.saveFamLinksV1(
            saveFamLinksRequest, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage and errorResponse in case the Assert for response fails
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, saveFamLinksResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(saveFamLinksResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "Invalid input request. DependentInfo List cannot be empty/null");
  }
}
