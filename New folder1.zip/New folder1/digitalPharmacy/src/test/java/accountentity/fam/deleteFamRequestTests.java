package accountentity.fam;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.deletePayloadResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.deleteResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.famErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.deleteFamRequestWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getFamRequestWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.updateFamRequestWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class deleteFamRequestTests {

    deleteFamRequestWrapper deleteWrapper = new deleteFamRequestWrapper();
    CommonUtils utility = new CommonUtils();

    @Test(priority = 1, description = "Testing delete API for caregiver and dependent HIPAA and ACCOUNT consent",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "deleteFamRequest")
    public void deleteDependAndCare (Map<String, String> inputData){
        String dependentId = utility.nullStringValidation(inputData.get("dependentId"));
        String caregiverId = utility.nullStringValidation(inputData.get("caregiverId"));
        String type = utility.nullStringValidation(inputData.get("type"));
        String deleteNum = utility.nullStringValidation(inputData.get("delete"));
        String status = utility.nullStringValidation(inputData.get("status"));
        String addInfoOne = utility.nullStringValidation(inputData.get("addInfoOne"));
        String addInfoTwo = utility.nullStringValidation(inputData.get("addInfoTwo"));
        String validDependentId = utility.nullStringValidation(inputData.get("validDependentId"));
        String validCaregiverId = utility.nullStringValidation(inputData.get("validCaregiverId"));
        String errorCode = utility.nullStringValidation(inputData.get("errorCode"));
        String errorMessage = utility.nullStringValidation(inputData.get("errorMessage"));

        if(Integer.parseInt(status) == 200){
            updateFamRequestWrapper updateWrapper = new updateFamRequestWrapper();
            ServiceResponse updateFam = updateWrapper.updateFamRequestFunction(validCaregiverId, validDependentId, type, addInfoOne,addInfoTwo);
        }
        ServiceResponse deleteFam = deleteWrapper.deleteFamRequestFunction(caregiverId, dependentId, type);



        if(deleteFam.getStatusCode() == 200){
            deletePayloadResponse deletePayloadResponse = deleteFam.getDataResponse(deletePayloadResponse.class);
            deleteResponse deleteResponse = deletePayloadResponse.getPayload().get(0);
            Assert.assertEquals(caregiverId, deleteResponse.getCaregiverId());
            Assert.assertEquals(dependentId, deleteResponse.getDependentId());
            Assert.assertEquals(deleteNum, deleteResponse.getDeletedRecordCount());

            //calling get to validate record deleted
            getFamRequestWrapper getFamWrapper = new getFamRequestWrapper();
            ServiceResponse getFam = getFamWrapper.getFamRequestFunction(caregiverId, dependentId, type);
            Assert.assertEquals(getFam.getStatusCode(), 204);
        }
        else{
            Assert.assertEquals(Integer.parseInt(status), deleteFam.getStatusCode());
            famErrorResponse errorResponse = deleteFam.getDataResponse(famErrorResponse.class);
            Assert.assertEquals(errorResponse.getError().getCode(), errorCode);
            Assert.assertEquals(errorResponse.getError().getMessage(), errorMessage);
        }

    }

}
