package accountentity.pet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityServicePetTestFlow {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String commonPatientId = null;
  private String commonOnlineAccountId = null;
  private String commonStoreNbr = null;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
  }

  @Test(
      priority = 0,
      description = "Create pet account success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting unique commonPatientId, commonOnlineAccountId and commonStoreNbr
    commonPatientId = CommonUtil.generateRandomNumber(7);
    commonOnlineAccountId = CommonUtil.randomUUID();
    commonStoreNbr = CommonUtil.generateRandomNumber(4);

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 3:Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 4: Setting Customer Info where commonPatientId will be created in this test and will
    // be also used in subsequent tests
    createPetAccountV1Request.getCustomerInfo().setPatientId(commonPatientId);
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);

    // Step - 5: calling the createPetAccountV1 entity API to create an account with the above
    // made request and the commonOnlineAccountId will also be created which will be also used in
    // subsequent tests
    Response<ServiceResponse> createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, createPetAccountV1Response);

    // Step - 7: Asserting response
    Assert.assertEquals(createPetAccountV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to PetAccountActionResponse class so that we can assert
    // onlineAccountId
    PetAccountActionResponse petAccountActionResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) createPetAccountV1Response.body().getPayload()),
            PetAccountActionResponse.class);

    Assert.assertEquals(petAccountActionResponse.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(
      priority = 1,
      description = "Create pet account 400 error due to invalid request",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1InvalidPayload(String payload) throws IOException {

    // Step - I: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, reqId, reqTrackingId);

    // Step - II: Preparing the request payload by mapping the JSON payload to
    // the CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // CASE 1: storeNbr null
    // Step - 1: Setting storeNbr as null
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(null);

    // Step - 2: Calling createPetAccountV1 API for CASE - 2
    Response<ServiceResponse> createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, createPetAccountV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");

    // CASE 2: patientId null
    // Step - 1: Resetting the storeNbr as we are using the previous payload and setting patientId
    // as null
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    createPetAccountV1Request.getCustomerInfo().setPatientId(null);

    // Step - 2: Calling createPetAccountV1 API for CASE - 3
    createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, createPetAccountV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 2,
      description = "Create pet account Invalid response due to already existing online account id",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestExistingOnlineAccountId(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 3: Setting patientId as unique random number string in the request payload
    createPetAccountV1Request.getCustomerInfo().setPatientId(CommonUtil.generateRandomNumber(7));

    // Step - 4: Calling createPetAccountV1 with already existing commonOnlineAccountId and unique
    // patientId
    Response<ServiceResponse> createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, createPetAccountV1Response);

    // Step - 6: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1007");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 4,
      description =
          "Create pet account Invalid response because patient type in CPR does not match",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "createPetAccountV1Request")
  public void createPetAccountV1RequestInvalidPatientType(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String onlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - 3: Setting patientId to a record which does not correspond to a PET patient type in
    // the request payload
    createPetAccountV1Request.getCustomerInfo().setStoreNbr("5572");
    createPetAccountV1Request.getCustomerInfo().setPatientId("123198");

    // Step - 4: Calling createPetAccountV1 with a unique onlineAccountId
    Response<ServiceResponse> createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, onlineAccountId, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, createPetAccountV1Response);

    // Step - 6: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(createPetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1006");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(priority = 5, description = "Get pet online Identity success case")
  public void getPetOnlineIdentityV1RequestSuccess() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String onlineAccountId = "e3523b47-ca49-4aac-aca3-c3e08c239";
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2: Calling getPetOnlineIdentityV1 with a onlineAccountId record which is present in
    // CPR
    Response<ServiceResponse> getPetOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPetOnlineIdentityV1(onlineAccountId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getPetOnlineIdentityV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getPetOnlineIdentityV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the PetOnlineIdentityV1Response class so that we can assert
    // patientInfo and patientLinks
    PetOnlineIdentityV1Response petOnlineIdentityV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getPetOnlineIdentityV1Response.body().getPayload()),
            PetOnlineIdentityV1Response.class);

    Assert.assertNotNull(petOnlineIdentityV1Response.getStoreNbr(), "storeNbr found null");
    Assert.assertNotNull(petOnlineIdentityV1Response.getPatientId(), "patientId found null");
  }

  @Test(
      priority = 6,
      description =
          "get pet online identity API call 204 No Content case where 204 is returned from entity service for not existing onlineAccountId")
  public void getPetOnlineIdentityV1Request204FromEntity() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String onlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2: Calling getPetOnlineIdentityV1 with a random onlineAccountId which is not created
    // in entity
    Response<ServiceResponse> getPetOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPetOnlineIdentityV1(onlineAccountId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getPetOnlineIdentityV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getPetOnlineIdentityV1Response.code(), 204, errorMessage);
  }

  @Test(
      priority = 7,
      description = "Update pet account success case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 2: We will update PatientId for the account created with commonOnlineAccountId
    String patientId = CommonUtil.generateRandomNumber(7);

    // Step - 3: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 4: Setting Customer Info in the updatePetAccountV1Request
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    updatePetAccountV1Request.getCustomerInfo().setPatientId(patientId);

    // Step - 5: calling the updatePetAccountV1 entity API to update the account with the
    // above made request and using commonOnlineAccountId
    Response<ServiceResponse> updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 6: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updatePetAccountV1Response);

    // Step - 7:Asserting response
    Assert.assertEquals(updatePetAccountV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to PetAccountActionResponse class so that we can assert
    // onlineAccountId
    PetAccountActionResponse petAccountActionResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) updatePetAccountV1Response.body().getPayload()),
            PetAccountActionResponse.class);

    Assert.assertEquals(petAccountActionResponse.getOnlineAccountId(), commonOnlineAccountId);

    // Step - 9: Setting commonPatientId to the new updated PatientId
    commonPatientId = patientId;
  }

  @Test(
      priority = 8,
      description = "Update pet account 400 error due to invalid request",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1InvalidPayload(String payload) throws IOException {

    // Step - I: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // CASE 1: storeNbr null
    // Step - 1: Setting storeNbr as null
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(null);

    // Step - 2: Calling updatePetAccountV1 API for CASE - 2
    Response<ServiceResponse> updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updatePetAccountV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");

    // CASE 2: patientId null
    // Step - 1: Resetting the storeNbr as we are using the previous payload and setting patientId
    // as null
    updatePetAccountV1Request.getCustomerInfo().setPatientId(null);
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);

    // Step - 2: Calling updatePetAccountV1 API for CASE - 2
    updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, commonOnlineAccountId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, updatePetAccountV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 9,
      description = "Update pet account Invalid response due to not existing online account id",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestNotExistingOnlineAccountId(String payload)
      throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String onlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 3: Calling updatePetAccountV1 API for CASE - 1
    Response<ServiceResponse> updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, onlineAccountId, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updatePetAccountV1Response);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1014");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 10,
      description =
          "Update pet account Invalid response due to already associated storeNbr and patientId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1RequestExistingStoreNbrAndPatientId(String payload)
      throws IOException {

    // Step - 1: Setting onlineAccountId
    String onlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2:
    // *********************Creating a new account for this test***************************
    // Step - a: Creating a new account with online account id as random onlineAccountId
    // the payload of update and create account are same so mapping it with the
    // CreatePetAccountV1Request class
    CreatePetAccountV1Request createPetAccountV1Request =
        mapper.readValue(payload, CreatePetAccountV1Request.class);

    // Step - b: Setting a random PatientId
    createPetAccountV1Request.getCustomerInfo().setPatientId(CommonUtil.generateRandomNumber(7));
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);

    // Step - c: Calling the createPetAccountV1 API with the createPetAccountV1Request and random
    // onlineAccountId
    Response<ServiceResponse> createPetAccountV1Response =
        accountEntityServiceRetrofit.createPetAccountV1(
            createPetAccountV1Request, onlineAccountId, reqId, reqTrackingId);

    // Step - d:: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, createPetAccountV1Response);

    // Step - e: Asserting create account response
    Assert.assertEquals(createPetAccountV1Response.code(), 200, errorMessage);

    // ***************************************END*******************************************

    // Step - 3: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 4: Setting already existing commonPatientId as the patientId in the request payload
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr(commonStoreNbr);
    updatePetAccountV1Request.getCustomerInfo().setPatientId(commonPatientId);

    // Step - 5: Calling updatePetAccountV1 API for CASE - 1
    Response<ServiceResponse> updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, onlineAccountId, reqId, reqTrackingId);

    // Step - 6: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updatePetAccountV1Response);

    // Step - 7: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 8: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1013");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 11,
      description =
          "Update pet account Invalid response because patient type in CPR does not match",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updatePetAccountV1Request")
  public void updatePetAccountV1InvalidPatientType(String payload) throws IOException {

    // Step - 1: Setting onlineAccountId
    String onlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, reqId, reqTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload to the
    // UpdatePetAccountV1Request class
    UpdatePetAccountV1Request updatePetAccountV1Request =
        mapper.readValue(payload, UpdatePetAccountV1Request.class);

    // Step - 3: Setting patientId to a record which does not correspond to a PET patient type in
    // the request payload
    updatePetAccountV1Request.getCustomerInfo().setPatientId("123198");
    updatePetAccountV1Request.getCustomerInfo().setStoreNbr("5572");

    // Step - 4: Calling updatePetAccountV1 API for CASE - 1
    Response<ServiceResponse> updatePetAccountV1Response =
        accountEntityServiceRetrofit.updatePetAccountV1(
            updatePetAccountV1Request, onlineAccountId, reqId, reqTrackingId);

    // Step - 5: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updatePetAccountV1Response);

    // Step - 6: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7: Asserting desired responses
    Assert.assertEquals(updatePetAccountV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1006");
    Assert.assertNotNull(errorResponse.getMessage(), "Message found null");
  }

  @Test(
      priority = 12,
      description = "Successfully Updates Merged profile when there is an existing account in OCP",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(reqId, reqTrackingId);

    // Step -2: Setting Unique survivingPatientId
    String survivingPatientId = CommonUtil.generateRandomNumber(5);

    // Step - 3:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 4: Setting already existing commonPatientId and commonStoreNbr and uniquely generated
    // survivingpatientId
    mergedProfileV1Request.getMergedInfo().setMergedPatientId(commonPatientId);
    mergedProfileV1Request.getMergedInfo().setStoreNbr(commonStoreNbr);
    mergedProfileV1Request.getMergedInfo().setSurvivingPatientId(survivingPatientId);

    // Step - 5: Calling updateMergedProfileV1 with a unique commonPatientId and commonStoreNbr and
    // SurvivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 6: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 7: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7:Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to the MergedProfileV1Response class so that we can assert
    // status
    MergedProfileV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);
    // Step - 9: Asserting desired responses
    Assert.assertEquals(response.getStatus(), "ACCOUNT_UPDATED_IN_OCP");
  }

  @Test(
      priority = 13,
      description = "Fails to Update Merged Profile due to No Account Found",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileV1RequestAccountNotFound(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(reqId, reqTrackingId);

    // Step - 2:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 3: Calling updateMergedProfileV1 with patientId, storeNbr and survivingPatientId from
    // payload
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6:Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);

    // Step - 7: Parsing the response to the MergedProfileV1Response class so that we can assert
    // status
    MergedProfileV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 8: Asserting desired responses
    Assert.assertEquals(response.getStatus(), "NO_MATCHING_ACCOUNT_FOUND");
  }

  @Test(
      priority = 14,
      description = "Invalid Request due to null fields in the payload",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileInvalidRequest(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(reqId, reqTrackingId);

    // Step - 2:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 3: Calling updateMergedProfileV1 with patientId, storeNbr and survivingPatientId as
    // null
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "Invalid input request. Unable to convert the given null into Integer");
  }

  //TODO: Enable CCM flag "is.pet.rx.deletion.enabled" in accountEntity to be true for this test to pass
  @Test(
          priority = 15,
          description = "Create pet account when patient link already exists and PET RX Deletion is enabled",
          dataProviderClass = DataProvider.class,
          dataProvider = "getDataByEnv")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
          sheetName = "createPetAccountV1Request")
  public void createPetAccountV1_PatientLinkAlreadyExistsFlagTrue(String payload) throws IOException {

    // Step 1: Setup unique identifiers for this test run
    String testPatientId = CommonUtil.generateRandomNumber(7);
    String testOnlineAccountId = CommonUtil.randomUUID();
    String testStoreNbr = CommonUtil.generateRandomNumber(4);
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(testOnlineAccountId, reqId, reqTrackingId);

    // Step 2: Prepare request payload
    CreatePetAccountV1Request createPetAccountV1Request =
            mapper.readValue(payload, CreatePetAccountV1Request.class);

    createPetAccountV1Request.getCustomerInfo().setPatientId(testPatientId);
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(testStoreNbr);

    // Step 3: PRECONDITION - Create a link in DB for the given patient (simulate "already exists")
    // 3a: Create a pet account to simulate the existing link
    Response<ServiceResponse> preCreateResponse =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, testOnlineAccountId, reqId, reqTrackingId);

    // 3b: Assert that precondition creation succeeded
    String preCreateError = CommonUtil.buildEntityServiceErrorMessage(gson, preCreateResponse);
    Assert.assertEquals(preCreateResponse.code(), 200, preCreateError);

    // Step 4: Now, call createPetAccountV1 again with the same identifiers (should trigger PET RX deletion logic)
    String newOnlineAccountId = CommonUtil.randomUUID(); // Simulate new account creation, but same patient
    CommonUtil.logFlowIdentifiers(newOnlineAccountId, reqId, reqTrackingId);

    Response<ServiceResponse> createResponse =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, newOnlineAccountId, reqId, reqTrackingId);

    // Step 5: Build error message for assertion
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, createResponse);

    // Step 6: Assert expected response - should be 200 (assuming PET RX deletion allows recreation)
    Assert.assertEquals(createResponse.code(), 200, errorMessage);

    // Step 7: Parse and assert the onlineAccountId in response matches newOnlineAccountId
    PetAccountActionResponse actionResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) createResponse.body().getPayload()),
                    PetAccountActionResponse.class);

    Assert.assertEquals(actionResponse.getOnlineAccountId(), newOnlineAccountId);

    // Step 8: Optionally verify via another API (getPetOnlineIdentityV1) that only one link exists for patient
    Response<ServiceResponse> getIdResponse =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(newOnlineAccountId, reqId, reqTrackingId);
    Assert.assertEquals(getIdResponse.code(), 200, "Failed to retrieve online identity for the recreated account");
    PetOnlineIdentityV1Response identityResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getIdResponse.body().getPayload()),
                    PetOnlineIdentityV1Response.class);
    Assert.assertEquals(identityResponse.getPatientId(), testPatientId);
    Assert.assertEquals(identityResponse.getStoreNbr(), testStoreNbr);
  }

  //TODO: Enable CCM flag "is.pet.rx.deletion.enabled" in accountEntity to be true for this test to pass
  @Test(
          priority = 17,
          description = "When multiple profiles are associated to one ID and PET RX Deletion is enabled, all deletions occur and new account is created",
          dataProviderClass = DataProvider.class,
          dataProvider = "getDataByEnv")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
          sheetName = "createPetAccountV1Request")
  public void createPetAccountV1_MultipleProfilesAllDeletedAndCreated(String payload) throws IOException {

    // Step 1: Setup unique identifiers for this test run
    String patientId = CommonUtil.generateRandomNumber(7);
    String storeNbr = CommonUtil.generateRandomNumber(4);

    // Simulate two existing onlineAccountIds for the same patient/store
    String existingOnlineAccountId1 = CommonUtil.randomUUID();
    String existingOnlineAccountId2 = CommonUtil.randomUUID();
    String newOnlineAccountId = CommonUtil.randomUUID();

    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step 2: Prepare request payload
    CreatePetAccountV1Request createPetAccountV1Request =
            mapper.readValue(payload, CreatePetAccountV1Request.class);
    createPetAccountV1Request.getCustomerInfo().setPatientId(patientId);
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(storeNbr);

    // Step 3: PRECONDITION - Create two accounts for the same patient/store (simulate two links exist)
    CommonUtil.logFlowIdentifiers(existingOnlineAccountId1, reqId, reqTrackingId);
    Response<ServiceResponse> preCreateResponse1 =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, existingOnlineAccountId1, reqId, reqTrackingId);
    Assert.assertEquals(preCreateResponse1.code(), 200,
            CommonUtil.buildEntityServiceErrorMessage(gson, preCreateResponse1));

    CommonUtil.logFlowIdentifiers(existingOnlineAccountId2, reqId, reqTrackingId);
    Response<ServiceResponse> preCreateResponse2 =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, existingOnlineAccountId2, reqId, reqTrackingId);
    Assert.assertEquals(preCreateResponse2.code(), 200,
            CommonUtil.buildEntityServiceErrorMessage(gson, preCreateResponse2));

    // Step 4: Now, trigger the creation again with a new onlineAccountId (should cause deletion of old and creation of new)
    CommonUtil.logFlowIdentifiers(newOnlineAccountId, reqId, reqTrackingId);
    Response<ServiceResponse> createResponse =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, newOnlineAccountId, reqId, reqTrackingId);

    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, createResponse);

    // Step 5: Assert that operation succeeded (200)
    Assert.assertEquals(createResponse.code(), 200, errorMessage);

    // Step 6: Assert response onlineAccountId is the new one
    PetAccountActionResponse actionResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) createResponse.body().getPayload()),
                    PetAccountActionResponse.class);
    Assert.assertEquals(actionResponse.getOnlineAccountId(), newOnlineAccountId);

    // Step 7: Assert that the old onlineAccountIds are no longer linked (should return 204/404)
    Response<ServiceResponse> getOld1 =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(existingOnlineAccountId1, reqId, reqTrackingId);
    Assert.assertTrue(getOld1.code() == 204 || getOld1.code() == 404,
            "Old onlineAccountId1 should not return patient info after deletion");

    Response<ServiceResponse> getOld2 =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(existingOnlineAccountId2, reqId, reqTrackingId);
    Assert.assertTrue(getOld2.code() == 204 || getOld2.code() == 404,
            "Old onlineAccountId2 should not return patient info after deletion");

    // Step 8: Verify the new account is linked
    Response<ServiceResponse> getNew =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(newOnlineAccountId, reqId, reqTrackingId);
    Assert.assertEquals(getNew.code(), 200, "New onlineAccountId should return patient info");
    PetOnlineIdentityV1Response identityResponse =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) getNew.body().getPayload()),
                    PetOnlineIdentityV1Response.class);
    Assert.assertEquals(identityResponse.getPatientId(), patientId);
    Assert.assertEquals(identityResponse.getStoreNbr(), storeNbr);
  }

  //TODO: Enable CCM flag "is.pet.rx.deletion.enabled" in accountEntity to be true for this test to pass
  @Test(
          priority = 18,
          description = "Verify transactional behavior during account creation with existing links",
          dataProviderClass = DataProvider.class,
          dataProvider = "getDataByEnv"
  )
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
          sheetName = "createPetAccountV1Request"
  )
  public void createPetAccountV1_VerifyTransactionalBehavior(String payload) throws IOException {

    // Test the happy path of deletion + creation in a transaction
    String patientId = CommonUtil.generateRandomNumber(7);
    String storeNbr = CommonUtil.generateRandomNumber(4);
    String existingOnlineAccountId = CommonUtil.randomUUID();
    String newOnlineAccountId = CommonUtil.randomUUID();
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    CreatePetAccountV1Request createPetAccountV1Request =
            mapper.readValue(payload, CreatePetAccountV1Request.class);
    createPetAccountV1Request.getCustomerInfo().setPatientId(patientId);
    createPetAccountV1Request.getCustomerInfo().setStoreNbr(storeNbr);

    // Create existing account
    Response<ServiceResponse> preCreateResponse =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, existingOnlineAccountId, reqId, reqTrackingId);
    Assert.assertEquals(preCreateResponse.code(), 200);

    // Create new account (should delete old and create new)
    Response<ServiceResponse> createResponse =
            accountEntityServiceRetrofit.createPetAccountV1(
                    createPetAccountV1Request, newOnlineAccountId, reqId, reqTrackingId);

    // Verify transaction completed successfully
    Assert.assertEquals(createResponse.code(), 200,
            "Transaction should complete successfully");

    // Verify old account is gone
    Response<ServiceResponse> checkOld =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(existingOnlineAccountId, reqId, reqTrackingId);
    Assert.assertTrue(checkOld.code() == 204 || checkOld.code() == 404,
            "Old account should be deleted");

    // Verify new account exists
    Response<ServiceResponse> checkNew =
            accountEntityServiceRetrofit.getPetOnlineIdentityV1(newOnlineAccountId, reqId, reqTrackingId);
    Assert.assertEquals(checkNew.code(), 200,
            "New account should exist");
  }
}
