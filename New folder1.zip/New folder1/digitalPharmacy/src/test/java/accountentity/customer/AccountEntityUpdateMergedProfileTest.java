package accountentity.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import java.io.IOException;
import java.security.GeneralSecurityException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityUpdateMergedProfileTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private String onlineAccountId1 = null;
  private String onlineAccountId2 = null;
  private String emailId1 = null;
  private String emailId2 = null;
  private String storeNbr = null;
  private String mergedPatientId = null;
  private IDatabaseContext accountDbContext;
  private String ACCOUNT_UPDATED_IN_OCP = "ACCOUNT_UPDATED_IN_OCP";
  private String ACCOUNT_UPDATED_IN_FAM = "ACCOUNT_UPDATED_IN_FAM";
  private String ACCOUNT_UPDATED_IN_OCP_IN_FAM = "ACCOUNT_UPDATED_IN_OCP_IN_FAM";
  private String NO_MATCHING_ACCOUNT_FOUND = "NO_MATCHING_ACCOUNT_FOUND";
  private String ACCOUNT_UPDATED_IN_OCP_IN_ISAC_IN_FAM = "ACCOUNT_UPDATED_IN_OCP_IN_ISAC_IN_FAM";
  private String ACCOUNT_UPDATED_IN_OCP_IN_ISAC = "ACCOUNT_UPDATED_IN_OCP_IN_ISAC";
  private String ACCOUNT_UPDATED_IN_ISAC_IN_FAM = "ACCOUNT_UPDATED_IN_ISAC_IN_FAM";
  private String ACCOUNT_UPDATED_IN_ISAC = "ACCOUNT_UPDATED_IN_ISAC";
  private String survivingPatientId = null;
  private String domainId = "WM-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String type = "PENDING_ACCOUNT_CREATION";
  private String wmPharmacyStore = "9928";

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
  }

  /**
   * Builds acc entity Update Merged Profile Request
   *
   * @param storeNbr
   * @param mergedPatientId
   * @param survivingPatientId
   * @return
   */
  private MergedProfileV1Request updateMergedProfileRequest(
      String storeNbr, String mergedPatientId, String survivingPatientId) {
    MergedInfo mergedInfo = new MergedInfo();
    mergedInfo.setMergedPatientId(mergedPatientId);
    mergedInfo.setSurvivingPatientId(survivingPatientId);
    mergedInfo.setStoreNbr(storeNbr);
    return new MergedProfileV1Request().mergedInfo(mergedInfo);
  }

  @Test(
      priority = 0,
      description =
          "Update Merged Profile success case when account updated in fam, ocp and isac table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInFamInOCPInISAC()
      throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);
    String caregiverId = CommonUtil.randomUUID();

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into OCP
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            mergedPatientId,
            onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            survivingPatientId,
            onlineAccountId2));

    // inserting into FAM
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId1, wmPharmacyStore, storeNbr, mergedPatientId, type));
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId2, wmPharmacyStore, storeNbr, survivingPatientId, type));

    // inserting into ISAC
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(wmPharmacyStore, storeNbr, mergedPatientId, emailId1, onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(
            wmPharmacyStore, storeNbr, survivingPatientId, emailId2, onlineAccountId2));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_OCP_IN_ISAC_IN_FAM);
  }

  @Test(
      priority = 1,
      description = "Update Merged Profile success case when account updated in ocp table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInOCP()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into OCP
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            mergedPatientId,
            onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            survivingPatientId,
            onlineAccountId2));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_OCP);
  }

  @Test(
      priority = 2,
      description = "Update Merged Profile success case when account updated in fam table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInFAM()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);
    String caregiverId = CommonUtil.randomUUID();

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into FAM
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId1, wmPharmacyStore, storeNbr, mergedPatientId, type));
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId2, wmPharmacyStore, storeNbr, survivingPatientId, type));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_FAM);
  }

  @Test(
      priority = 3,
      description = "Update Merged Profile success case when account updated in isac table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInISAC()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into ISAC
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(wmPharmacyStore, storeNbr, mergedPatientId, emailId1, onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(
            wmPharmacyStore, storeNbr, survivingPatientId, emailId2, onlineAccountId2));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_ISAC);
  }

  @Test(
      priority = 4,
      description = "Update Merged Profile success case when account updated in ocp and fam table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInOCPAndFAM()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);
    String caregiverId = CommonUtil.randomUUID();

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into OCP
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            mergedPatientId,
            onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            survivingPatientId,
            onlineAccountId2));

    // inserting into FAM
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId1, wmPharmacyStore, storeNbr, mergedPatientId, type));
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId2, wmPharmacyStore, storeNbr, survivingPatientId, type));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_OCP_IN_FAM);
  }

  @Test(
      priority = 5,
      description = "Update Merged Profile success case when account updated in ocp and isac table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInOCPAndISAC()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into OCP
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            mergedPatientId,
            onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            survivingPatientId,
            onlineAccountId2));

    // inserting into ISAC
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(wmPharmacyStore, storeNbr, mergedPatientId, emailId1, onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(
            wmPharmacyStore, storeNbr, survivingPatientId, emailId2, onlineAccountId2));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_OCP_IN_ISAC);
  }

  @Test(
      priority = 6,
      description = "Update Merged Profile success case when account updated in isac and fam table")
  public void updateMergedProfileSuccessCaseWhenAccountUpdatedInISACAndFAM()
      throws IOException, GeneralSecurityException {
    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);
    onlineAccountId1 = CommonUtil.randomUUID();
    onlineAccountId2 = CommonUtil.randomUUID();
    emailId1 = CommonUtil.generateRandomEmailId(10);
    emailId2 = CommonUtil.generateRandomEmailId(10);
    String caregiverId = CommonUtil.randomUUID();

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // inserting into FAM
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId1, wmPharmacyStore, storeNbr, mergedPatientId, type));
    accountDbContext.executeInsertQuery(
        getInsertFAMQuery(
            caregiverId, onlineAccountId2, wmPharmacyStore, storeNbr, survivingPatientId, type));

    // inserting into ISAC
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(wmPharmacyStore, storeNbr, mergedPatientId, emailId1, onlineAccountId1));
    accountDbContext.executeInsertQuery(
        getInsertISACQuery(
            wmPharmacyStore, storeNbr, survivingPatientId, emailId2, onlineAccountId2));

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), ACCOUNT_UPDATED_IN_ISAC_IN_FAM);
  }

  @Test(priority = 7, description = "Update Merged Profile account not found case")
  public void updateMergedProfileSuccessCaseWhenAccountNotFound()
      throws IOException, GeneralSecurityException {

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with storeNbr,mergedPatientId and survivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Parsing the response to the MergedProfileV1Response class so that we can
    // assert
    // mergedProfileV1Response
    MergedProfileV1Response apiResponse =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 5: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);
    Assert.assertNotNull(mergedProfileV1Response.body().getPayload(), "Payload is null");
    Assert.assertEquals(apiResponse.getStatus(), NO_MATCHING_ACCOUNT_FOUND);
  }

  @Test(priority = 8, description = "Update Merged Profile invalid cases")
  public void updateMergedProfileInvalidCases() throws IOException, GeneralSecurityException {

    // *****  CASE 1 - DomainId is invalid *****

    // Step - 1a: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Step - 1b: Creating test accounts
    String mergedPatientId = CommonUtil.generateRandomNumber(9);
    String survivingPatientId = CommonUtil.generateRandomNumber(9);

    // CASE 1 - StoreNbr is null
    String storeNbr = null;

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // Step - 2a: Creating updateMergedProfileV1Request
    MergedProfileV1Request mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with invalid request parameters
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);

    // *****  CASE 2 - mergedPatientId is null *****

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = null;
    survivingPatientId = CommonUtil.generateRandomNumber(9);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // Step - 2a: Creating updateMergedProfileV1Request
    mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with invalid request parameters
    mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);

    // *****  CASE 3 - survivingPatientId is null *****

    // Step - 1b: Creating test accounts
    storeNbr = CommonUtil.generateRandomNumber(6);
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = null;

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // Step - 2a: Creating updateMergedProfileV1Request
    mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with invalid request parameters
    mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);

    // *****  CASE 4 - storeNbr is non-integer *****

    // Step - 1b: Creating test accounts
    storeNbr = "xyz";
    mergedPatientId = CommonUtil.generateRandomNumber(9);
    survivingPatientId = CommonUtil.generateRandomNumber(9);

    logAccountDetails(
        domainId,
        storeNbr,
        mergedPatientId,
        survivingPatientId,
        onlineAccountId1,
        onlineAccountId2,
        reqId,
        reqTrackingId);

    // Step - 2a: Creating updateMergedProfileV1Request
    mergedProfileV1Request =
        updateMergedProfileRequest(storeNbr, mergedPatientId, survivingPatientId);

    // Step - 2b: Calling updateMergedProfileV1 with invalid request parameters
    mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(gson, mergedProfileV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);
  }

  private static String getInsertFAMQuery(
      String caregiverId,
      String dependentId,
      String onlineStoreNbr,
      String storeNbr,
      String patientId,
      String type) {
    return String.format(
        "INSERT INTO pharmacydb.FAM_REQUEST(CAREGIVER_ID, DEPENDENT_ID, REQUEST_TYPE, ONLINE_STORE_NBR, ADDITIONAL_INFORMATION, CREATE_TS, UPDATE_TS) VALUES ('%s', '%s', '%s', '%s', '{\n"
            + "    \"storeNbr\": %s,\n"
            + "    \"patientId\": %s\n"
            + "}', '2024-01-01', '2024-01-01')",
        caregiverId, dependentId, type, onlineStoreNbr, storeNbr, patientId);
  }

  private static String getInsertISACQuery(
      String onlineStore,
      String storeNbr,
      String patientId,
      String emailId,
      String onlineAccountId) {
    return String.format(
        "INSERT INTO pharmacydb.ISAC_ID_VERIFICATION(STAGE_ID, ONLINE_STORE_NBR, PATIENT_ID, STORE_NBR, EXPIRED, ACCOUNT_CREATED, ID_VERIFIED, ID_VERIFICATION_INFORMATION, DOB_RETRIES, EMAIL_ID, EMAIL_SENT_COUNTER, LAST_EMAIL_SENT_TS, CREATE_TS, UPDATE_TS) VALUES('%s', %s, %s,%s, 0, 0, 1, '{\"photoId\": null}', 0, '%s', 1, '2024-01-01', '2024-01-01', '2024-01-01')",
        onlineAccountId, onlineStore, patientId, storeNbr, emailId);
  }

  private static String getInsertOcidQuery(
      String onlineCustId,
      String onlineStore,
      String authStoreNbr,
      String authPatientId,
      String onlineAccountId) {
    return String.format(
        "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, 'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01','%s', '%s', 'smsOtpVerification')",
        onlineCustId, onlineStore, authStoreNbr, authPatientId, onlineAccountId, onlineAccountId);
  }

  private void logAccountDetails(
      String domainId,
      String storeNumber,
      String mergedPatientId,
      String survivingPatientId,
      String customerAccountId1,
      String customerAccountId2,
      String reqId,
      String reqTrackingId) {
    Reporter.logJSON("domain Id", domainId);
    Reporter.logJSON("Store nbr", storeNumber);
    Reporter.logJSON("Merged Patient Id", mergedPatientId);
    Reporter.logJSON("Surviving Patient Id", survivingPatientId);
    Reporter.logJSON("Customer Account Id 1", customerAccountId1);
    Reporter.logJSON("Customer Account Id 2", customerAccountId2);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
