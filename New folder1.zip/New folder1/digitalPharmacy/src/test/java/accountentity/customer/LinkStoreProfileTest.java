package accountentity.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.LinkStoreProfileV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.LinkStoreProfileV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LinkStoreProfileTest {

    public static final Gson gson = new Gson();
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private final ObjectMapper mapper = new ObjectMapper();
    private final IDatabaseContext accountDbContext =
            AutomationManager.getInstance().getDPAccountDBContext();
    private String domainId = "WM-PHARMACY";
    private String wmPharmacyStore = "9928";

    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";

    private List<String> cleanOCPcidsList = new ArrayList<>();
    private List<ValidationServiceRequest> cleanCPRProfilesList = new ArrayList<>();
    @BeforeClass
    void setContext() throws IOException {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    }

    @AfterClass
    void cleanUp() {
        cleanCPRProfilesList.stream().filter(Objects::nonNull).forEach(this::deleteCPR);
        cleanOCPcidsList.stream().filter(Objects::nonNull).forEach(this::deleteOCPRecord);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Success")
    public void importRxLinkStoreProfileSuccess() throws IOException, InterruptedException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
        String lastName = CommonUtil.generateRandomLastName(5);
        String dob = "2000-01-01";

        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        createCPRAccount(wmPharmacyStore, walmartPatientId, lastName, dob);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, wmPharmacyStore, walmartPatientId, onlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Thread.sleep(10000);
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> linkStoreProfileV1Response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(linkStoreProfileV1Response.code(), 200);

        Map<String, Object> authInfo = getAuthInfo(onlineAccountId);
        Assert.assertEquals(authInfo.get("AUTH_PATIENT_ID").toString(), patientId);
        Assert.assertEquals(authInfo.get("AUTH_STORE_NBR").toString(), storeNbr);


        // And the second try should throw ineligible error
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);
        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1024");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Conflict")
    public void importRxLinkStoreProfileConflict() throws IOException, InterruptedException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String conflictOnlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
       // String lastName = CommonUtil.generateRandomLastName(5);
        String lastName = "test";
        String dob = "2000-01-01";
        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        ValidationServiceRequest authCPRRequest = createCPRAccount(wmPharmacyStore, walmartPatientId, lastName, dob);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, wmPharmacyStore, walmartPatientId, onlineAccountId));

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, storeNbr, patientId, conflictOnlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 409);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        LinkStoreProfileV1Response linkStoreProfileV1Response = ResponseUtil.parseResponse(
                gson,
                ((LinkedTreeMap<String, Object>)
                        entityServiceResponseHolder.getPayload()),
                LinkStoreProfileV1Response.class);

        Assert.assertEquals(linkStoreProfileV1Response.getExistingOnlineAccountId(), conflictOnlineAccountId);
        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1013");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
        cleanOCPcidsList.add(conflictOnlineAccountId);
        cleanCPRProfilesList.add(authCPRRequest);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Invalid DOB")
    public void importRxLinkStoreProfileInvalidDob() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
        String lastName = CommonUtil.generateRandomLastName(5);
        String dob = "1997-11-11";
        String dob2 = "1998-11-11";

        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        ValidationServiceRequest authCPRRequest = createCPRAccount(wmPharmacyStore, walmartPatientId, lastName, dob2);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, wmPharmacyStore, walmartPatientId, onlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1025");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
        cleanCPRProfilesList.add(authCPRRequest);
    }


    @Test(priority = 1, description = "Import Rx Link Store Profile Invalid LastName")
    public void importRxLinkStoreProfileInvalidLastName() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
        String lastName = CommonUtil.generateRandomLastName(5);
        String lastName2 = CommonUtil.generateRandomLastName(5);
        String dob = "1997-11-11";

        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        ValidationServiceRequest authCPRRequest = createCPRAccount(wmPharmacyStore, walmartPatientId, lastName2, dob);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, wmPharmacyStore, walmartPatientId, onlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1023");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
        cleanCPRProfilesList.add(authCPRRequest);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Invalid LastName And Dob")
    public void importRxLinkStoreProfileInvalidLastNameAndDob() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
        String lastName = CommonUtil.generateRandomLastName(5);
        String lastName2 = CommonUtil.generateRandomLastName(5);
        String dob = "1997-11-11";
        String dob2 = "1998-11-11";

        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        ValidationServiceRequest authCPRRequest = createCPRAccount(wmPharmacyStore, walmartPatientId, lastName2, dob2);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, wmPharmacyStore, walmartPatientId, onlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1026");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
        cleanCPRProfilesList.add(authCPRRequest);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Auth Store Nbr is not Digital")
    public void importRxLinkStoreProfileAuthStoreNbrIsNotDigital() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);
        String walmartPatientId = CommonUtil.generateRandomNumber(9);
        String lastName = CommonUtil.generateRandomLastName(5);
        String dob = "1997-11-11";

        ValidationServiceRequest cprRequest = createCPRAccount(storeNbr, patientId, lastName, dob);
        ValidationServiceRequest authCPRRequest = createCPRAccount(storeNbr, walmartPatientId, lastName, dob);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), wmPharmacyStore, storeNbr, walmartPatientId, onlineAccountId));

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1024");

        //clean data
        cleanOCPcidsList.add(onlineAccountId);
        cleanCPRProfilesList.add(cprRequest);
        cleanCPRProfilesList.add(authCPRRequest);
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile No Pharmacy Account")
    public void importRxLinkStoreProfileNoPharmacyAccount() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(9);

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(patientId).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1014");
    }

    @Test(priority = 1, description = "Import Rx Link Store Profile Invalid Request")
    public void importRxLinkStoreProfileInvalidRequest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        String onlineAccountId = CommonUtil.randomUUID();
        String storeNbr = CommonUtil.generateRandomNumber(6);

        LinkStoreProfileV1Request linkStoreProfileV1Request = LinkStoreProfileV1Request.builder().authStoreNbr(storeNbr).authPatientId(null).build();
        Response<ServiceResponseHolder<LinkStoreProfileV1Response>> response = accountEntityServiceRetrofit.linkStoreProfileV1(onlineAccountId, domainId, linkStoreProfileV1Request, reqId, reqTrackingId);

        Assert.assertEquals(response.code(), 400);
        ServiceResponseHolder<?> entityServiceResponseHolder = CommonUtil.getEntityServiceResponseHolder(gson, response);

        Assert.assertEquals(entityServiceResponseHolder.getError().getCode(), "DPR-DPACCENSR-1001");
    }

    /**
     * Create CPR Account before running create a pharmacy account
     *
     * @return
     * @throws IOException
     */
    public ValidationServiceRequest createCPRAccount(String storeNbr, String patientId, String lastName, String dob) throws IOException {
        ValidationServiceRequest cprPatientRequest =
                mapper.readValue(
                        new File(
                                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
                        ValidationServiceRequest.class);

        cprPatientRequest.setStoreNbr(Integer.parseInt(storeNbr));
        cprPatientRequest.setPatientId(Integer.parseInt(patientId));
        cprPatientRequest.getPatientInfo().setBirthDate(dob);
        cprPatientRequest.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5));
        cprPatientRequest.getPatientInfo().setLastName(lastName);

        // This will try to create an account in CPR. Will retry thrice if account creation fails
        for (int i = 0; i < 3; i++) {
            Response<ValidationServiceResponse> response =
                    cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CPR Account creation failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }

        /**
         * This is needed because CPR account creation is async, and it usually takes a couple of
         * seconds to reflect account creation
         */
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return cprPatientRequest;
    }

    private static String getInsertOcidQuery(
            String onlineCustId,
            String onlineStore,
            String authStore,
            String authPatientId,
            String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, onlineStore, authStore, authPatientId, uuid, uuid);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery = String.format(
                "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_STORE_NBR = %s AND ONLINE_ACCOUNT_ID = '%s'",
                wmPharmacyStore, uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    private Map<String, Object> getAuthInfo(String onlineAccountId) {

        String getAuthInfo = String.format("SELECT AUTH_PATIENT_ID,AUTH_STORE_NBR FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s' AND ONLINE_STORE_NBR = %s",
                onlineAccountId,
                wmPharmacyStore);

         return accountDbContext.executeQuery(getAuthInfo);
    }

    private void deleteCPR(ValidationServiceRequest request)  {
        try {
            CPRServiceHelper.deleteCprAccount(cprPatientUpdateRetrofit, request);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
