package accountentity.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CACreatePersonResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.models.createOnlineAccount.PharmaCreateOnlineAccountRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.models.createOnlineAccount.PharmaCreateOnlineAccountResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.restapi.PharmaRetrofitQa2;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.GetISACStatusV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.GetISACStatusV1Response;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityServiceInStoreAccountServiceTestFlow {

  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private PharmaRetrofitQa2 pharmaRetrofitQa2;
  private CARetrofit caRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";
  private String commonCustomerEmailId = null;
  private String commonCustomerAccountId = null;

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    pharmaRetrofitQa2 = new PharmaRetrofitQa2();
    caRetrofit = new CARetrofit();
    commonCustomerEmailId = CommonUtil.generateRandomEmailId(10);
  }

  /**
   * creates an online account through pyxis
   *
   * @throws IOException
   */
  public void pharmaCreateOnlineAccount() throws IOException {
    PharmaCreateOnlineAccountRequest pharmaCreateOnlineAccountRequest =
        getPharmaCreateOnlineAccountRequest();
    Response<PharmaCreateOnlineAccountResponse> response = null;

    // This will try to create an account in pharma, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = pharmaRetrofitQa2.createOnlineAccount(pharmaCreateOnlineAccountRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && response.body().getStatus() != "OK") {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "Pharma online Account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  public void caCreatePerson() throws IOException {
    CACreatePersonRequest caCreatePersonRequest = getCACreatePersonRequest();
    Response<CACreatePersonResponse> response = null;

    // This will try to create a person account in CA, 3 times if account creation fails
    for (int i = 0; i < 3; i++) {
      response = caRetrofit.createPerson(caCreatePersonRequest);
      if (!(response.code() == 200
              && response.body() != null
              && response.body().getPayload() != null)
          && response.body().getStatus() != "OK") {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CA person account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
    commonCustomerAccountId = response.body().getPayload().getPerson().getCustomerAccountId();
  }

  private PharmaCreateOnlineAccountRequest getPharmaCreateOnlineAccountRequest()
      throws IOException {
    PharmaCreateOnlineAccountRequest pharmaCreateOnlineAccountRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/pharma/createOnlineAccount/createOnlineAccountRequest.json"),
            PharmaCreateOnlineAccountRequest.class);
    pharmaCreateOnlineAccountRequest.getPayload().setCustomerEmailId(commonCustomerEmailId);
    pharmaCreateOnlineAccountRequest
        .getPayload()
        .setFirstName(RandomStringUtils.randomAlphabetic(5));
    pharmaCreateOnlineAccountRequest
        .getPayload()
        .setLastName(RandomStringUtils.randomAlphabetic(5));
    pharmaCreateOnlineAccountRequest.getPayload().getStoreNumber().setUSStoreId("5544");
    return pharmaCreateOnlineAccountRequest;
  }

  private CACreatePersonRequest getCACreatePersonRequest() {
    List<CACreatePersonRequest.Accounts> accountsList = new ArrayList<>();
    accountsList.add(
        CACreatePersonRequest.Accounts.builder()
            .accountType("INDIVIDUAL")
            .emailAddress(commonCustomerEmailId)
            .build());
    return CACreatePersonRequest.builder()
        .payload(
            CACreatePersonRequest.CreatePersonRequestPayload.builder()
                .person(CACreatePersonRequest.Person.builder().accounts(accountsList).build())
                .build())
        .build();
  }

  @Test(
      priority = 0,
      description =
          "Get ISAC status success case in which pharma account is created first then in CA")
  public void getISACStatusV1SuccessPharmaCA() throws IOException {

    // Step - 1: calling pharmaCreateOnlineAccount and then caCreatePerson to create an account in
    // respective services
    pharmaCreateOnlineAccount();
    caCreatePerson();

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);
    Reporter.logJSON("CustomerEmailId", commonCustomerEmailId);

    // Step - 3: Creating GetISACStatusV1Request for the API call
    GetISACStatusV1Request getISACStatusV1Request = new GetISACStatusV1Request();
    getISACStatusV1Request.setEmailId(commonCustomerEmailId);

    // Step - 4: Calling the getISACStatusV1 in account entity service to fetch the ISAC status
    Response<ServiceResponse> getISACStatusV1APIResponse =
        accountEntityServiceRetrofit.getISACStatusV1(
            getISACStatusV1Request, commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getISACStatusV1APIResponse);

    // Step - 6: Asserting response of API
    Assert.assertEquals(getISACStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 7: Parsing the API response to GetISACStatusV1Response class
    GetISACStatusV1Response getISACStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getISACStatusV1APIResponse.body().getPayload()),
            GetISACStatusV1Response.class);

    // Step - 8: Asserting parsed response of API
    Assert.assertTrue(getISACStatusV1Response.isIdVerified(), "IdVerified expected to be true");
    Assert.assertFalse(getISACStatusV1Response.isLinkExpired(), "LinkExpired expected to be false");
    Assert.assertFalse(
        getISACStatusV1Response.isDobRetiresExhausted(),
        "DobRetiresExhausted expected to be false");
  }

  @Test(
      priority = 1,
      description =
          "Get ISAC status success case in which CA account is created first then in Pharma")
  public void getISACStatusV1SuccessCAPharma() throws IOException {

    // Step - 1: calling caCreatePerson and then pharmaCreateOnlineAccount to create an account in
    // respective services
    caCreatePerson();
    pharmaCreateOnlineAccount();

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);
    Reporter.logJSON("CustomerEmailId", commonCustomerEmailId);

    // Step - 3: Creating GetISACStatusV1Request for the API call
    GetISACStatusV1Request getISACStatusV1Request = new GetISACStatusV1Request();
    getISACStatusV1Request.setEmailId(commonCustomerEmailId);

    // Step - 4: Calling the getISACStatusV1 in account entity service to fetch the ISAC status
    Response<ServiceResponse> getISACStatusV1APIResponse =
        accountEntityServiceRetrofit.getISACStatusV1(
            getISACStatusV1Request, commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 5: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getISACStatusV1APIResponse);

    // Step - 6: Asserting response of API
    Assert.assertEquals(getISACStatusV1APIResponse.code(), 200, errorMessage);

    // Step - 7: Parsing the API response to GetISACStatusV1Response class
    GetISACStatusV1Response getISACStatusV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getISACStatusV1APIResponse.body().getPayload()),
            GetISACStatusV1Response.class);

    // Step - 8: Asserting parsed response of API
    Assert.assertTrue(getISACStatusV1Response.isIdVerified(), "IdVerified expected to be true");
    Assert.assertFalse(getISACStatusV1Response.isLinkExpired(), "LinkExpired expected to be false");
    Assert.assertFalse(
        getISACStatusV1Response.isDobRetiresExhausted(),
        "DobRetiresExhausted expected to be false");
  }

  @Test(priority = 2, description = "Get ISAC status Invalid domain id case")
  public void getISACStatusV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String domainId = "WM-PHARMAC";
    String commonCustomerAccountId= UUID.randomUUID().toString();
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);
    Reporter.logJSON("CustomerEmailId", commonCustomerEmailId);

    // Step - 2: Creating GetISACStatusV1Request for the API call
    GetISACStatusV1Request getISACStatusV1Request = new GetISACStatusV1Request();
    getISACStatusV1Request.setEmailId(commonCustomerEmailId);

    // Step - 3: Calling the getISACStatusV1 in account entity service to fetch the ISAC status
    Response<ServiceResponse> getISACStatusV1APIResponse =
        accountEntityServiceRetrofit.getISACStatusV1(
            getISACStatusV1Request, commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorResponse and errorMessage
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getISACStatusV1APIResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response of API
    Assert.assertEquals(getISACStatusV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Invalid input request. only [WM-PHARMACY, SAMS-PHARMACY] are permitted as domainId");
  }

  @Test(priority = 3, description = "Get ISAC status Account not found case")
  public void getISACStatusV1AccountNotFound() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String CustomerEmailId = CommonUtil.generateRandomEmailId(10);
    CommonUtil.logFlowIdentifiers(commonCustomerAccountId, domainId, reqId, reqTrackingId);
    Reporter.logJSON("CustomerEmailId", CustomerEmailId);

    // Step - 2: Creating GetISACStatusV1Request for the API call
    GetISACStatusV1Request getISACStatusV1Request = new GetISACStatusV1Request();
    getISACStatusV1Request.setEmailId(CustomerEmailId);

    // Step - 3: Calling the getISACStatusV1 in account entity service to fetch the ISAC status
    Response<ServiceResponse> getISACStatusV1APIResponse =
        accountEntityServiceRetrofit.getISACStatusV1(
            getISACStatusV1Request, commonCustomerAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getISACStatusV1APIResponse);

    // Step - 5: Asserting response of API
    Assert.assertEquals(getISACStatusV1APIResponse.code(), 204, errorMessage);
  }
}
