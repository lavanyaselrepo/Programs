package accountentity.customer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.CustomerConsentValue;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpdateCustomerConsentV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.UpdateCustomerConsentV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AccountEntityServiceCustomerConsentTest {

    private static final String PET_DEPENDENT = "PET_DEPENDENT";
    private final int domainCode = 9928;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private IDatabaseContext accountDbContext;
    private String commonOnlineAccountId;
    private final Gson gson = new GsonBuilder().create();
    List<CustomerConsentValue> customerConsents;
    Map<String, CustomerConsentValue> consentValueMap;
    String dependent1 = CommonUtil.randomUUID();
    String dependent2 = CommonUtil.randomUUID();
    String dependent3 = CommonUtil.randomUUID();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeClass
    void setContext() {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        commonOnlineAccountId = CommonUtil.randomUUID();
        accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
    }


    @Test(priority = 0, description = "Update Customer Consents V1 Invalid Consent Type")
    public void updateCustomerConsentV1APIInvalidConsentType() throws IOException, SQLException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String dependent1 = CommonUtil.randomUUID();

        CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request1 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent1).type("randomValue").value("true").build()))
                .build();

        Response<ServiceResponse> apiResponse =
                accountEntityServiceRetrofit.updateCustomerConsentV1(
                        updateCustomerConsentV1Request1, commonOnlineAccountId, domainId, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        Assert.assertEquals(apiResponse.code(), 400, errorMessage);
        assert errorResponse != null;
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Consent Type is not valid");
    }

    @Test(priority = 1, description = "Update Customer Consents V1 invalid Consent Value")
    public void updateCustomerConsentV1APIInvalidConsentValue() throws IOException, SQLException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        String dependent1 = CommonUtil.randomUUID();

        CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request1 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent1).type(PET_DEPENDENT).value("random").build()))
                .build();

        Response<ServiceResponse> apiResponse =
                accountEntityServiceRetrofit.updateCustomerConsentV1(
                        updateCustomerConsentV1Request1, commonOnlineAccountId, domainId, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        Assert.assertEquals(apiResponse.code(), 400, errorMessage);
        assert errorResponse != null;
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(errorResponse.getMessage(), "Invalid input request. Consent Value is not valid");
    }

    @Test(priority = 2, description = "Update Customer Consents V1")
    public void updateCustomerConsentV1APISuccessAdd1() throws IOException, SQLException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;


        CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request1 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent1).type(PET_DEPENDENT).value("TRUE").build()))
                .build();

        callUpdateConsentV1AndValidateResponse(updateCustomerConsentV1Request1, reqId, reqTrackingId);

        customerConsents = readCustomerConsents(commonOnlineAccountId);
        Assert.assertEquals(customerConsents.size(), 1);
        Assert.assertEquals(customerConsents.get(0).getId(), dependent1);
        Assert.assertEquals(customerConsents.get(0).getValue(),"true");

    }

    @Test(priority = 3, description = "Update Customer Consents V1")
    public void updateCustomerConsentV1APISuccessAdd2Both1And2Present() throws IOException, SQLException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request2 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent2).type(PET_DEPENDENT).value("TRUE").build()))
                .build();

        callUpdateConsentV1AndValidateResponse(updateCustomerConsentV1Request2, reqId, reqTrackingId);

        customerConsents = readCustomerConsents(commonOnlineAccountId);
        consentValueMap = customerConsents.stream().collect(Collectors.toMap(CustomerConsentValue::getId, x -> x));
        Assert.assertEquals(customerConsents.size(), 2);
        Assert.assertEquals(consentValueMap.get(dependent1).getId(), dependent1);
        Assert.assertEquals(consentValueMap.get(dependent1).getValue(),"true");
        Assert.assertEquals(consentValueMap.get(dependent2).getId(),dependent2);
        Assert.assertEquals(consentValueMap.get(dependent2).getValue(),"true");

    }

    @Test(priority = 4, description = "Update Customer Consents V1")
    public void updateCustomerConsentV1APISuccessRemove1Add3Only2And3Present() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request3 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent1).type(PET_DEPENDENT).value("FALSE").build(),
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent3).type(PET_DEPENDENT).value("TRUE").build()))
                .build();

        callUpdateConsentV1AndValidateResponse(updateCustomerConsentV1Request3, reqId, reqTrackingId);

        customerConsents = readCustomerConsents(commonOnlineAccountId);
        consentValueMap = customerConsents.stream().collect(Collectors.toMap(CustomerConsentValue::getId, x -> x));
        Assert.assertEquals(customerConsents.size(), 2);
        Assert.assertNull(consentValueMap.get(dependent1));
        Assert.assertEquals(consentValueMap.get(dependent2).getId(),dependent2);
        Assert.assertEquals(consentValueMap.get(dependent2).getValue(),"true");
        Assert.assertEquals(consentValueMap.get(dependent3).getId(), dependent3);
        Assert.assertEquals(consentValueMap.get(dependent3).getValue(),"true");

    }

    @Test(priority = 5, description = "Update Customer Consents V1")
    public void updateCustomerConsentV1APISuccessRemove2ndOnly3rdPresent() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request4 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent2).type(PET_DEPENDENT).value("FALSE").build()))
                .build();

        callUpdateConsentV1AndValidateResponse(updateCustomerConsentV1Request4, reqId, reqTrackingId);

        customerConsents = readCustomerConsents(commonOnlineAccountId);
        consentValueMap = customerConsents.stream().collect(Collectors.toMap(CustomerConsentValue::getId, x -> x));
        Assert.assertEquals(customerConsents.size(), 1);
        Assert.assertNull(consentValueMap.get(dependent1));
        Assert.assertNull(consentValueMap.get(dependent2));
        Assert.assertEquals(consentValueMap.get(dependent3).getId(), dependent3);
        Assert.assertEquals(consentValueMap.get(dependent3).getValue(),"true");

    }

    @Test(priority = 6, description = "Update Customer Consents V1")
    public void updateCustomerConsentV1APISuccessNoConsentsPresent() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        UpdateCustomerConsentV1Request updateCustomerConsentV1Request5 = UpdateCustomerConsentV1Request.builder()
                .consent(org.openjdk.tools.javac.util.List.of(
                        UpdateCustomerConsentV1Request.Consent.builder().id(dependent3).type(PET_DEPENDENT).value("FALSE").build()))
                .build();

        callUpdateConsentV1AndValidateResponse(updateCustomerConsentV1Request5, reqId, reqTrackingId);

        customerConsents = readCustomerConsents(commonOnlineAccountId);
        consentValueMap = customerConsents.stream().collect(Collectors.toMap(CustomerConsentValue::getId, x -> x));
        Assert.assertEquals(customerConsents.size(), 0);
        Assert.assertNull(consentValueMap.get(dependent1));
        Assert.assertNull(consentValueMap.get(dependent2));
        Assert.assertNull(consentValueMap.get(dependent3));
    }



    private void callUpdateConsentV1AndValidateResponse(UpdateCustomerConsentV1Request updateCustomerConsentV1Request1, String reqId, String reqTrackingId) throws IOException {
        Response<ServiceResponse> apiResponse =
                accountEntityServiceRetrofit.updateCustomerConsentV1(
                        updateCustomerConsentV1Request1, commonOnlineAccountId, domainId, reqId, reqTrackingId);

        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

        UpdateCustomerConsentV1Response updateCustomerConsentV1Response =
                ResponseUtil.parseResponse(
                        gson,
                        ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
                        UpdateCustomerConsentV1Response.class);
        Assert.assertEquals(apiResponse.code(), 200, errorMessage);
        Assert.assertEquals(updateCustomerConsentV1Response.getOnlineAccountId(), commonOnlineAccountId);
    }

    private List<CustomerConsentValue> readCustomerConsents(String onlineAccountId) throws IOException {

        String getConsentValuesQuery = String.format("SELECT CONSENT_VALUE FROM pharmacydb.CUSTOMER_CONSENT WHERE ONLINE_ACCOUNT_ID = '%s' AND ONLINE_STORE_NBR = %d AND CONSENT_TYPE =  '%s'",
                onlineAccountId,
                domainCode,
                PET_DEPENDENT.toLowerCase());

        Map<String, Object> stringObjectMap = accountDbContext.executeQuery(getConsentValuesQuery);


        if (stringObjectMap != null) {
            return objectMapper.readValue(stringObjectMap.get("CONSENT_VALUE").toString(),
                    new TypeReference<List<CustomerConsentValue>>() {
                    });
        } else {
            return new ArrayList<>();
        }
    }
}
