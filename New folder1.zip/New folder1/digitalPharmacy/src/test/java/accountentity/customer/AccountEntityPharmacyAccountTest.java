package accountentity.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.GetOnlineAccountIdByPatientLinkV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.PharmacyOnlineAccountIdByPatientLinksV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.CreatePharmacyAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.GetOnlineAccountIdByPatientLinkV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceRequest;
import com.walmart.pharmacy.dp.centralpatient.restclient.model.ValidationServiceResponse;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityPharmacyAccountTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private final IDatabaseContext accountDbContext =
      AutomationManager.getInstance().getDPAccountDBContext();
  private final Gson gson = new GsonBuilder().create();
  private String commonOnlineAccountId = null;
  private String samsOnlineAccountId = null;

  private String commonStoreNbr = null;
  private String commonPatientId = null;
  private String commonSurvivingPatientId = null;
  private String commonDobCPRFormat = null;
  private String commonDobDPFormat = null;
  private String accountCreationSource = "smsOtpVerification";
  private String domainId = "WM-PHARMACY";
  private String wmPharmacyStore = "9928";

  private String domainIdSamsPharmacy = "SAMS-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private final ObjectMapper objectMapper = new ObjectMapper();

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    commonOnlineAccountId = CommonUtil.randomUUID();
    commonStoreNbr = CommonUtil.generateRandomNumber(6);
    commonPatientId = CommonUtil.generateRandomNumber(9);
    samsOnlineAccountId = CommonUtil.generateRandomNumber(10);

    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

    createCPRAccount();

    /**
     * This is needed because CPR account creation is async, and it usually takes a couple of
     * seconds to reflect account creation
     */
    try {
      Thread.sleep(10000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Create CPR Account before running create a pharmacy account
   *
   * @throws IOException
   */
  public void createCPRAccount() throws IOException {
    ValidationServiceRequest cprPatientRequest =
        mapper.readValue(
            new File(
                "src/test/resources/testdata/digitalpharmacy/cpr.patientupdate/ValidationServiceRequest.json"),
            ValidationServiceRequest.class);

    cprPatientRequest.setStoreNbr(Integer.parseInt(commonStoreNbr));
    cprPatientRequest.setPatientId(Integer.parseInt(commonPatientId));
    cprPatientRequest.getPatientInfo().setBirthDate(commonDobCPRFormat);
    cprPatientRequest.getPatientInfo().setFirstName(RandomStringUtils.randomAlphabetic(5));
    cprPatientRequest.getPatientInfo().setLastName(RandomStringUtils.randomAlphabetic(5));

    // This will try to create an account in CPR. Will retry thrice if account creation fails
    for (int i = 0; i < 3; i++) {
      Response<ValidationServiceResponse> response =
          cprPatientUpdateRetrofit.validateProfile(cprPatientRequest);
      if (!(response.code() == 202
          && response.body() != null
          && response.body().getErrors().isEmpty())) {
        Reporter.logJSON("Exception", response.errorBody().toString());
        if (i == 2) {
          throw new RuntimeException(
              "CPR Account creation failed. HttpStatusCode : " + response.code());
        }
      } else break;
    }
  }

  @Test(priority = 1, description = "create pharmacy account V1 API success")
  public void createPharmacyAccountV1APISuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);
    logAccountDetails();

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            commonOnlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    CreatePharmacyAccountV1Response createPharmacyAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            CreatePharmacyAccountV1Response.class);

    Assert.assertEquals(
        createPharmacyAccountV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(priority = 2, description = "create pharmacy account V1 API for Sams Pharmacy success")
  public void createPharmacyAccountV1APISuccessSAMS() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(samsOnlineAccountId, domainId, reqId, reqTrackingId);
    logAccountDetails();

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            samsOnlineAccountId,
            domainIdSamsPharmacy,
            createPharmacyAccountV1Request,
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    CreatePharmacyAccountV1Response createPharmacyAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            CreatePharmacyAccountV1Response.class);

    Assert.assertEquals(createPharmacyAccountV1Response.getOnlineAccountId(), samsOnlineAccountId);
  }

  @Test(
      priority = 3,
      description =
          "create pharmacy account V1 API failure due to DOB mismatch between input request and CPR")
  public void createPharmacyAccountV1APIDobMismatchBetweenRequestAndCPRFailure()
      throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    createPharmacyAccountV1Request.getCustomerInfo().setDob("01011990");

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            onlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1027");
  }

  @Test(
      priority = 4,
      description =
          "create pharmacy account V1 API failure due to online account Id already exists")
  public void createPharmacyAccountV1APIOnlineAccountIdAlreadyExistsFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            commonOnlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1007");
    Assert.assertEquals(errorResponse.getMessage(), "Online account id already exists.");
  }

  @Test(
      priority = 5,
      description = "create pharmacy account V1 API failure due to patient link already exists")
  public void createPharmacyAccountV1APIPatientLinkAlreadyExistsFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            onlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1013");
    Assert.assertEquals(
        errorResponse.getMessage(),
        "Store number and patient id already linked with some other online account id.");
  }

  @Test(
      priority = 6,
      description =
          "create pharmacy account V1 API failure due to input request patient data not found in CPR")
  public void createPharmacyAccountV1APIPatientDataNotFoundInCPRFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    createPharmacyAccountV1Request
        .getCustomerInfo()
        .setStoreNbr(CommonUtil.generateRandomNumber(2));
    createPharmacyAccountV1Request
        .getCustomerInfo()
        .setPatientId(CommonUtil.generateRandomNumber(2));

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            onlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-6004");
    Assert.assertTrue(errorMessage.contains("No data found in CPR for patientId"));
  }

  @Test(
      priority = 7,
      description = "create pharmacy account V1 API failure due to invalid account creation source")
  public void createPharmacyAccountV1APIInvalidAccountCreationSourceFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    createPharmacyAccountV1Request.setAccountCreationSource("");

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            onlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
  }

  /*@Test(priority = 8, description = "create pharmacy account V1 API success for vuc")
  public void createPharmacyAccountV1APISuccessForVUC() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String domainId = "WM-PHARMACY";
    String commonOnlineAccountId= UUID.randomUUID().toString();
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);
    logAccountDetails();

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request();

    createPharmacyAccountV1Request.setAccountCreationSource("virtualUrgentCare");
    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            commonOnlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    CreatePharmacyAccountV1Response createPharmacyAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            CreatePharmacyAccountV1Response.class);

    Assert.assertEquals(
        createPharmacyAccountV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }
*/
  @Test(priority = 9, description = "get online account Id by patient link V1 success")
  public void getOnlineAccountIdByPatientLinkV1APISuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    GetOnlineAccountIdByPatientLinkV1Request getOnlineAccountIdByPatientLinkV1Request =
        getOnlineAccountIdByPatientLinkV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getOnlineAccountIdByPatientLinkV1(
            domainId, getOnlineAccountIdByPatientLinkV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            GetOnlineAccountIdByPatientLinkV1Response.class);

    Assert.assertEquals(
        getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(
      priority = 10,
      description = "get online account Id by patient link V1 failure due to no content found")
  public void getOnlineAccountIdByPatientLinkV1APINoContentFoundFailure() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    GetOnlineAccountIdByPatientLinkV1Request getOnlineAccountIdByPatientLinkV1Request =
        getOnlineAccountIdByPatientLinkV1Request();

    getOnlineAccountIdByPatientLinkV1Request
        .getCustomerInfo()
        .setStoreNbr(CommonUtil.generateRandomNumber(2));
    getOnlineAccountIdByPatientLinkV1Request
        .getCustomerInfo()
        .setPatientId(CommonUtil.generateRandomNumber(2));

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getOnlineAccountIdByPatientLinkV1(
            domainId, getOnlineAccountIdByPatientLinkV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 204, errorMessage);
  }

  @Test(priority = 11, description = "get Pharmacy online account Id by patient links V1 success")
  public void getPharmacyOnlineAccountIdByPatientLinksV1APISuccessSingleLink() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        getPharmacyOnlineAccountIdByPatientLinksV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainId, pharmacyOnlineAccountIdByPatientLinksV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            GetOnlineAccountIdByPatientLinkV1Response.class);

    Assert.assertEquals(
        getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(priority = 12, description = "get Pharmacy online account Id by patient links V1 success")
  public void getPharmacyOnlineAccountIdByPatientLinksV1APISuccessMultipleLinks()
      throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    List<PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink> patientLinks =
        new ArrayList<>();

    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(commonStoreNbr)
            .patientId(commonPatientId)
            .build());
    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(CommonUtil.generateRandomNumber(5))
            .patientId(CommonUtil.generateRandomNumber(6))
            .build());
    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(CommonUtil.generateRandomNumber(5))
            .patientId(CommonUtil.generateRandomNumber(6))
            .build());

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        PharmacyOnlineAccountIdByPatientLinksV1Request.builder().patientLinks(patientLinks).build();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainId, pharmacyOnlineAccountIdByPatientLinksV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            GetOnlineAccountIdByPatientLinkV1Response.class);

    Assert.assertEquals(
        getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(priority = 13, description = "get Pharmacy online account Id by patient links V1 success")
  public void getSamsPharmacyOnlineAccountIdByPatientLinksV1APISuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainIdSamsPharmacy, reqId, reqTrackingId);

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        getPharmacyOnlineAccountIdByPatientLinksV1Request();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainIdSamsPharmacy,
            pharmacyOnlineAccountIdByPatientLinksV1Request,
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            GetOnlineAccountIdByPatientLinkV1Response.class);

    Assert.assertEquals(
        getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(), samsOnlineAccountId);
  }

  @Test(
      priority = 14,
      description =
          "get Pharmacy online account Id by patient links V1 failure due to no online customer id found")
  public void getPharmacyOnlineAccountIdByPatientLinksV1APINoContentFoundFailure()
      throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        getPharmacyOnlineAccountIdByPatientLinksV1Request();

    pharmacyOnlineAccountIdByPatientLinksV1Request
        .getPatientLinks()
        .forEach(request -> request.setStoreNbr(CommonUtil.generateRandomNumber(5)));

    pharmacyOnlineAccountIdByPatientLinksV1Request
        .getPatientLinks()
        .forEach(request -> request.setPatientId(CommonUtil.generateRandomNumber(6)));

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainId, pharmacyOnlineAccountIdByPatientLinksV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(apiResponse.code(), 204, errorMessage);
  }

  @Test(
      priority = 15,
      description =
          "get Pharmacy online account Id by patient links V1 Multiple Customer ProfileFoundIn OCP, return the latest activated timestamp record")
  public void getPharmacyOnlineAccountIdByPatientLinksV1APISuccessWhichReturnLatestActivatedTimestampRecord() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    List<PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink> patientLinks =
        new ArrayList<>();
    String store1 = CommonUtil.generateRandomNumber(5);
    String patientId1 = CommonUtil.generateRandomNumber(8);
    String store2 = CommonUtil.generateRandomNumber(5);
    String patientId2 = CommonUtil.generateRandomNumber(8);
    String onlineId1 = CommonUtil.randomUUID();
    String onlineId2 = CommonUtil.randomUUID();
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9), wmPharmacyStore, store1, patientId1, onlineId1));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9), wmPharmacyStore, store2, patientId2, onlineId2));

    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(store1)
            .patientId(patientId1)
            .build());
    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(store2)
            .patientId(patientId2)
            .build());

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        PharmacyOnlineAccountIdByPatientLinksV1Request.builder().patientLinks(patientLinks).build();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainId, pharmacyOnlineAccountIdByPatientLinksV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
                    GetOnlineAccountIdByPatientLinkV1Response.class);

    accountDbContext.executeUpdateQuery(getDeleteOcidQuery(wmPharmacyStore, onlineId1));
    accountDbContext.executeUpdateQuery(getDeleteOcidQuery(wmPharmacyStore, onlineId2));
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);
    Assert.assertEquals(getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(),onlineId2);
  }

  @Test(
      priority = 16,
      description =
          "get Pharmacy online account Id by patient links V1 success with same patientLinks multiple times")
  public void getPharmacyOnlineAccountIdByPatientLinksV1APISuccessWithSamePatientLinks()
      throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    List<PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink> patientLinks =
        new ArrayList<>();
    String store1 = CommonUtil.generateRandomNumber(5);
    String patientId1 = CommonUtil.generateRandomNumber(8);
    String store2 = CommonUtil.generateRandomNumber(5);
    String patientId2 = CommonUtil.generateRandomNumber(8);
    String onlineId = CommonUtil.randomUUID();
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9), wmPharmacyStore, store1, patientId1, onlineId));
    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9), wmPharmacyStore, store2, patientId2, onlineId));
    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(store1)
            .patientId(patientId1)
            .build());
    patientLinks.add(
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(store2)
            .patientId(patientId2)
            .build());

    PharmacyOnlineAccountIdByPatientLinksV1Request pharmacyOnlineAccountIdByPatientLinksV1Request =
        PharmacyOnlineAccountIdByPatientLinksV1Request.builder().patientLinks(patientLinks).build();

    Response<ServiceResponse> apiResponse =
        accountEntityServiceRetrofit.getPharmacyOnlineAccountIdByPatientLinksV1(
            domainId, pharmacyOnlineAccountIdByPatientLinksV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, apiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    accountDbContext.executeUpdateQuery(getDeleteOcidQuery(wmPharmacyStore, onlineId));
    Assert.assertEquals(apiResponse.code(), 200, errorMessage);

    GetOnlineAccountIdByPatientLinkV1Response getOnlineAccountIdByPatientLinkV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) apiResponse.body().getPayload()),
            GetOnlineAccountIdByPatientLinkV1Response.class);

    Assert.assertEquals(getOnlineAccountIdByPatientLinkV1Response.getOnlineAccountId(), onlineId);
  }

  private static String getInsertOcidQuery(
      String onlineCustId,
      String onlineStore,
      String authStore,
      String authPatientId,
      String uuid) {
    return String.format(
        "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', current_timestamp, NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
        onlineCustId, onlineStore, authStore, authPatientId, uuid, uuid);
  }

  private static String getDeleteOcidQuery(String onlineStore, String uuid) {
    return String.format(
        "DELETE TOP(2) FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_STORE_NBR = %s AND ONLINE_ACCOUNT_ID = '%s'",
        onlineStore, uuid);
  }

  @Test(priority = 17, description = "GetPharmacyOnlineIdentityV1 success")
  public void getPharmacyOnlineIdentityV1Success() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getPharmacyOnlineIdentityV1 with an onlineAccountId and domainId
    Response<ServiceResponse> getPharmacyOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
            commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getPharmacyOnlineIdentityV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getPharmacyOnlineIdentityV1Response.code(), 200, errorMessage);

    // Step - 5: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert class responses
    PharmacyOnlineIdentityV1Response pharmacyOnlineIdentityV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                getPharmacyOnlineIdentityV1Response.body().getPayload()),
            PharmacyOnlineIdentityV1Response.class);

    Assert.assertEquals(pharmacyOnlineIdentityV1Response.getAuthStoreNbr(), commonStoreNbr);
    Assert.assertEquals(pharmacyOnlineIdentityV1Response.getAuthPatientId(), commonPatientId);
    Assert.assertEquals(
        pharmacyOnlineIdentityV1Response.getAccountCreationSource(), "smsOtpVerification");
  }

  @Test(priority = 18, description = "GetPharmacyOnlineIdentityV1 account not found")
  public void getPharmacyOnlineIdentityV1204Error() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getPharmacyOnlineIdentityV1 with an onlineAccountId and domainId
    Response<ServiceResponse> getPharmacyOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
            onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getPharmacyOnlineIdentityV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getPharmacyOnlineIdentityV1Response.code(), 204, errorMessage);
  }

  @Test(priority = 19, description = "GetPharmacyOnlineIdentityV1 Invalid domainId")
  public void getPharmacyOnlineIdentityV1InvalidDomainId() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String domainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getPharmacyOnlineIdentityV1 with an onlineAccountId and domainId
    Response<ServiceResponse> getPharmacyOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
            commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getPharmacyOnlineIdentityV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getPharmacyOnlineIdentityV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
      Assert.assertEquals(
              "Invalid input request. only [WM-PHARMACY, SAMS-PHARMACY] are permitted as domainId", errorResponse.getMessage());
  }

  @Test(
      priority = 20,
      description = "Successfully Updates Merged profile when there is an existing account in OCP",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileV1RequestSuccess(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step -2: Setting Unique survivingPatientId
    commonSurvivingPatientId = CommonUtil.generateRandomNumber(5);

    // Step - 3:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 4: Setting already existing commonPatientId and commonStoreNbr and uniquely generated
    // survivingpatientId
    mergedProfileV1Request.getMergedInfo().setMergedPatientId(commonPatientId);
    mergedProfileV1Request.getMergedInfo().setStoreNbr(commonStoreNbr);
    mergedProfileV1Request.getMergedInfo().setSurvivingPatientId(commonSurvivingPatientId);

    // Step - 5: Calling updateMergedProfileV1 with a unique commonPatientId and commonStoreNbr and
    // SurvivingPatientId
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 6: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 7: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 7:Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);

    // Step - 8: Parsing the response to the MergedProfileV1Response class so that we can assert
    // status
    MergedProfileV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);
    // Step - 9: Asserting desired responses
    Assert.assertEquals(response.getStatus(), "ACCOUNT_UPDATED_IN_OCP");
  }

  @Test(
      priority = 21,
      description = "Fails to Update Merged Profile due to No Account Found",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileV1RequestAccountNotFound(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String domainId = "WM-HEALTH";
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 3: Calling updateMergedProfileV1 with patientId, storeNbr and survivingPatientId from
    // payload
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6:Asserting response
    Assert.assertEquals(mergedProfileV1Response.code(), 200, errorMessage);

    // Step - 7: Parsing the response to the MergedProfileV1Response class so that we can assert
    // status
    MergedProfileV1Response response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) mergedProfileV1Response.body().getPayload()),
            MergedProfileV1Response.class);

    // Step - 8: Asserting desired responses
    Assert.assertEquals(response.getStatus(), "NO_MATCHING_ACCOUNT_FOUND");
  }

  @Test(
      priority = 22,
      description = "Invalid Request due to null fields in the payload",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServicePetData.xlsx",
      sheetName = "updateMergedProfileV1Request")
  public void UpdateMergedProfileInvalidRequest(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2:Preparing the request payload by mapping the JSON payload to the
    // MergedProfileV1Request class
    MergedProfileV1Request mergedProfileV1Request =
        mapper.readValue(payload, MergedProfileV1Request.class);

    // Step - 3: Calling updateMergedProfileV1 with patientId, storeNbr and survivingPatientId as
    // null
    Response<ServiceResponse> mergedProfileV1Response =
        accountEntityServiceRetrofit.updateMergedProfileV1(
            mergedProfileV1Request, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, mergedProfileV1Response);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting desired responses
    Assert.assertEquals(mergedProfileV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(),
        "Invalid input request. Unable to convert the given null into Integer");
  }

  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request() {
    return CreatePharmacyAccountV1Request.builder()
        .accountCreationSource(accountCreationSource)
        .customerInfo(
            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                .storeNbr(commonStoreNbr)
                .patientId(commonPatientId)
                .dob(commonDobDPFormat)
                .build())
        .build();
  }

  private GetOnlineAccountIdByPatientLinkV1Request getOnlineAccountIdByPatientLinkV1Request() {
    return GetOnlineAccountIdByPatientLinkV1Request.builder()
        .customerInfo(
            GetOnlineAccountIdByPatientLinkV1Request.CustomerInfo.builder()
                .storeNbr(commonStoreNbr)
                .patientId(commonPatientId)
                .build())
        .build();
  }

  private PharmacyOnlineAccountIdByPatientLinksV1Request
      getPharmacyOnlineAccountIdByPatientLinksV1Request() {

    PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink patientLink =
        PharmacyOnlineAccountIdByPatientLinksV1Request.PatientLink.builder()
            .storeNbr(commonStoreNbr)
            .patientId(commonPatientId)
            .build();

    return PharmacyOnlineAccountIdByPatientLinksV1Request.builder()
        .patientLinks(Collections.singletonList(patientLink))
        .build();
  }

  private void logAccountDetails() {
    Reporter.logJSON("Store nbr", commonStoreNbr);
    Reporter.logJSON("Patient Id", commonPatientId);
    Reporter.logJSON("Dob", commonDobDPFormat);
  }
}
