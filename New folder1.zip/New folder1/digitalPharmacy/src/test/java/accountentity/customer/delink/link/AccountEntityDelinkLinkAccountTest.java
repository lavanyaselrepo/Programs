package accountentity.customer.delink.link;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.DelinkAndLinkAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DelinkAndLinkAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.EntityServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.PharmacyOnlineIdentityV1Response;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityDelinkLinkAccountTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private String existingCustomerAccountId;
  private String newCustomerAccountId;
  private String storeNbr;
  private String patientId;
  private String dobCPRFormat;
  private String dobDPFormat;

  private static final String DOMAIN = "WM-PHARMACY";

  @BeforeClass
  void setContext() throws IOException, InterruptedException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();

    existingCustomerAccountId = CommonUtil.randomUUID();
    newCustomerAccountId = CommonUtil.randomUUID();
    storeNbr = CommonUtil.generateRandomNumber(6);
    patientId = CommonUtil.generateRandomNumber(9);
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    dobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
    dobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);

    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit,
        storeNbr,
        patientId,
        dobCPRFormat,
        RandomStringUtils.randomAlphabetic(5),
        RandomStringUtils.randomAlphabetic(5));

    Thread.sleep(10000);

    EntityServiceHelper.createPharmacyAccount(
        accountEntityServiceRetrofit,
        existingCustomerAccountId,
        DOMAIN,
        EntityServiceHelper.buildCreatePharmacyAccountV1Request(
            storeNbr, patientId, dobDPFormat, "smsOtpVerification"));

    Reporter.logJSON("existingCustomerAccountId", existingCustomerAccountId);
    Reporter.logJSON("newCustomerAccountId", newCustomerAccountId);
    Reporter.logJSON("storeNbr", storeNbr);
    Reporter.logJSON("patientId", patientId);
  }

  @Test(priority = 1, description = "Delink link account invalid domain")
  public void delinkAndLinkAccountV1InvalidDomain() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountEntityServiceRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId,
            "dummy",
            getDelinkAndLinkAccountV1Request(),
            reqId,
            reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertTrue(errorResponse.getMessage().contains("are permitted as domainId"));
  }

  @Test(priority = 2, description = "Delink link account invalid existing online account id")
  public void delinkAndLinkAccountV1InvalidExistingOnlineAccountId() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        getDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setExistingOnlineAccountId(null);

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountEntityServiceRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertTrue(
        errorResponse.getMessage().contains("Existing online account Id cannot be null"));
  }

  @Test(priority = 3, description = "Delink link account not found error")
  public void delinkAndLinkAccountV1AccountNotFoundError() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        getDelinkAndLinkAccountV1Request();
    delinkAndLinkAccountV1Request.setExistingOnlineAccountId(CommonUtil.randomUUID());

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountEntityServiceRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1014");
    Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }

  @Test(priority = 4, description = "Delink link account already exists error")
  public void delinkAndLinkAccountV1AccountAlreadyExistsError() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        getDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountEntityServiceRetrofit.delinkAndLinkAccountV1(
            existingCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1007");
    Assert.assertTrue(errorResponse.getMessage().contains("Online account id already exists"));
  }

  @Test(priority = 5, description = "Delink link account success")
  public void delinkAndLinkAccountV1Success() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    DelinkAndLinkAccountV1Request delinkAndLinkAccountV1Request =
        getDelinkAndLinkAccountV1Request();

    Response<ServiceResponse> delinkLinkAccountResponse =
        accountEntityServiceRetrofit.delinkAndLinkAccountV1(
            newCustomerAccountId, DOMAIN, delinkAndLinkAccountV1Request, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, delinkLinkAccountResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(delinkLinkAccountResponse.code(), 200, errorMessage);

    DelinkAndLinkAccountV1Response delinkAndLinkAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) delinkLinkAccountResponse.body().getPayload()),
            DelinkAndLinkAccountV1Response.class);

    Assert.assertEquals(delinkAndLinkAccountV1Response.getOnlineAccountId(), newCustomerAccountId);
    Assert.assertEquals(delinkAndLinkAccountV1Response.getAuthStoreNbr(), storeNbr);
    Assert.assertEquals(delinkAndLinkAccountV1Response.getAuthPatientId(), patientId);
  }

  @Test(
      priority = 6,
      description =
          "Delink link account, verify new cid has auth store nbr and auth patient id present after API success")
  public void delinkAndLinkAccountNewCIDHasStoreProfilePresent() throws IOException {

    Response<ServiceResponse>
        serviceResponse =
            EntityServiceHelper.getPharmacyOnlineIdentityV1(
                accountEntityServiceRetrofit, newCustomerAccountId, DOMAIN);

    PharmacyOnlineIdentityV1Response pharmacyOnlineIdentityV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) serviceResponse.body().getPayload()),
            PharmacyOnlineIdentityV1Response.class);

    Assert.assertEquals(storeNbr, pharmacyOnlineIdentityV1Response.getAuthStoreNbr());
    Assert.assertEquals(patientId, pharmacyOnlineIdentityV1Response.getAuthPatientId());
  }

  @Test(
      priority = 7,
      description =
          "Delink link account, verify existing cid has no auth store nbr and auth patient id present after API success")
  public void delinkAndLinkAccountExistingCIDHasNoStoreProfilePresent() throws IOException {

    Response<ServiceResponse>
        serviceResponse =
            EntityServiceHelper.getPharmacyOnlineIdentityV1(
                accountEntityServiceRetrofit, existingCustomerAccountId, DOMAIN);

    Assert.assertEquals(204, serviceResponse.code());
  }

  private DelinkAndLinkAccountV1Request getDelinkAndLinkAccountV1Request() {
    return DelinkAndLinkAccountV1Request.builder()
        .existingOnlineAccountId(existingCustomerAccountId)
        .build();
  }
}
