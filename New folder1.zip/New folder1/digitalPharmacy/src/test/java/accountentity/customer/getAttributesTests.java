package accountentity.customer;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.getAttributesPayload;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getAttributesWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.updateAttributesWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;


public class getAttributesTests {
    getAttributesWrapper attributesWrapper = new getAttributesWrapper();

    @Test(
            priority = 1, description = "Get data for online customer attributes",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "getAttributes")
    public void getCustomerAttributes(Map<String, String> inputData){
        String customerId = nullStringValidation(inputData.get("customerId"));
        String type = nullStringValidation(inputData.get("type"));
        String attribute = nullStringValidation(inputData.get("attribute"));
        String status = nullStringValidation(inputData.get("status"));
        String name = nullStringValidation(inputData.get("name"));
        String value = nullStringValidation(inputData.get("value"));

        //for putting values for get
        if(Integer.parseInt(status) == 200){
            updateAttributesWrapper updateWrapper = new updateAttributesWrapper();
            ServiceResponse updateAttribute = updateWrapper.updateAttributesFunction(name, value, customerId, type);
        }
        ServiceResponse getAttribute = attributesWrapper.getAtrributesFunction(customerId, attribute, type);




        if (getAttribute.getStatusCode() ==200) {

            getAttributesPayload attributesPayload = getAttribute.getDataResponse(getAttributesPayload.class);
            System.out.println(attributesPayload.toString());
            Assert.assertEquals(getAttribute.getStatusCode(), Integer.parseInt(status));
            Assert.assertEquals(attributesPayload.getPayload().getAttributes().get(0).getName(), name);
            if(value !=null) {
                Assert.assertEquals(attributesPayload.getPayload().getAttributes().get(0).getValue(), value.toLowerCase());
            }

        }
        else {
            Assert.assertEquals(getAttribute.getStatusCode(), Integer.parseInt(status));
        }

    }

    public String nullStringValidation(String inputData){
        String val = inputData;
        if((inputData.equals("null"))) {
            val = null;
        }
        return val;
    }
}

