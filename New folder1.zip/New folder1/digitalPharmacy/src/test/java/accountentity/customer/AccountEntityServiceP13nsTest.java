package accountentity.customer;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.Error;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreateP13nsRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.DeleteP13nsRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.GetCustomerP13nResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


public class AccountEntityServiceP13nsTest {

    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    private final Gson gson = new Gson();
    private P13nDao p13nDao;

    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private static final String ALL = "ALL";

    @BeforeClass
    void setContext() throws IOException {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        p13nDao = new P13nDao();
    }


    @Test(description = "Create p13n api success")
    public void createP13nsV1APISuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> apiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(apiResponse.code(), 200, errorMessage);

        // verify p13ns are created.
        List<P13nDocument> p13nDocuments = p13nDao.getP13nDocuments(onlineAccountId);
        Assert.assertEquals(p13nDocuments.get(0).getOnlineAccountId(), onlineAccountId);
        assertP13nsInRequestAndDBIsSame(createP13nsRequest.getP13ns(), p13nDocuments);

        //cleanup, delete p13ns
        p13nDao.deleteP13nDocuments(onlineAccountId, p13nDocuments.stream()
                .map(P13nDocument::getId).collect(Collectors.toList()));
    }

    @Test(description = "Create p13n api failure, mandatory fields absent")
    public void createP13nsV1APIError1() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(null, null, 2));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> apiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 400);
        Assert.assertEquals(error.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertTrue(error.getMessage().contains("type can't be null"));
        Assert.assertTrue(error.getMessage().contains("entity can't be null"));
    }

    @Test(description = "Create p13n api failure, invalid values of enums")
    public void createP13nsV1APIError2() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns("INVALID", "INVALID", 2));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> apiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, apiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(apiResponse.code(), 400);
        Assert.assertEquals(error.getCode(), "DPR-DPACCENSR-1002");
        Assert.assertTrue(error.getMessage().contains("not one of the values accepted for Enum class"));
    }

    @Test(description = "Delete p13n success by cosmos Ids")
    public void deleteP13nsSuccessByCosmosIds() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first
        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);

        //Get ids of cosmos documents to delete.
        List<P13nDocument> p13nDocuments = p13nDao.getP13nDocuments(onlineAccountId);
        List<String> cosmosIds = new ArrayList<>();

        //Adding because delete operation should be no op, if document doesn't exist it will be ignored.
        cosmosIds.add("RANDOM_ID");
        cosmosIds.addAll(p13nDocuments.stream().map(P13nDocument::getId).collect(Collectors.toList()));


        //Delete P13ns API Call
        DeleteP13nsRequest deleteP13nsRequest = DeleteP13nsRequest.builder().documentIds(cosmosIds).build();
        Response<ServiceResponseHolder<Void>> deletApiResponse =
         accountEntityServiceRetrofit
                .deleteP13nsV1(onlineAccountId, deleteP13nsRequest, domainId, false, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, deletApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(deletApiResponse.code(), 200, errorMessage);

        //verify documents got deleted.
        List<P13nDocument> p13nDocumentsAfterDeletion = p13nDao.getP13nDocuments(onlineAccountId);
        Assert.assertTrue(p13nDocumentsAfterDeletion.isEmpty());

    }

    @Test(description = "Delete p13n success, deleteAll=true")
    public void deleteP13nsSuccessDeleteAllTrue() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first
        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> apiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(apiResponse.code(), 200);

        //Get ids of cosmos documents to delete.
        List<P13nDocument> p13nDocuments = p13nDao.getP13nDocuments(onlineAccountId);
        List<String> cosmosIds = p13nDocuments.stream().map(P13nDocument::getId).collect(Collectors.toList());

        //Delete P13ns API Call
        DeleteP13nsRequest deleteP13nsRequest = DeleteP13nsRequest.builder().documentIds(cosmosIds).build();
        Response<ServiceResponseHolder<Void>> deletApiResponse =
                accountEntityServiceRetrofit
                        .deleteP13nsV1(onlineAccountId, deleteP13nsRequest, domainId, false, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, deletApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(deletApiResponse.code(), 200, errorMessage);

        //verify documents got deleted.
        List<P13nDocument> p13nDocumentsAfterDeletion = p13nDao.getP13nDocuments(onlineAccountId);
        Assert.assertTrue(p13nDocumentsAfterDeletion.isEmpty());

    }


    @Test(description = "Delete p13n error, ids passed and deleteAll=true")
    public void deleteP13nsError1() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);


        // Delete P13ns API Call
        // Pass any random Ids as well for deletion, since deletion should be no-op.
        // Even if an id doesn't exist, we shall simply ignore it.
        List<String> cosmosIds = new ArrayList<>();
        cosmosIds.add(UUID.randomUUID().toString());
        DeleteP13nsRequest deleteP13nsRequest = DeleteP13nsRequest.builder()
                .documentIds(cosmosIds).build();
        Response<ServiceResponseHolder<Void>> deletApiResponse =
                accountEntityServiceRetrofit
                        .deleteP13nsV1(onlineAccountId, deleteP13nsRequest, domainId, true, reqId, reqTrackingId);
        Assert.assertEquals(deletApiResponse.code(), 400);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, deletApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(error.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertTrue(error.getMessage().contains("Ids must be present if deleteAll=false, absent if deleteAll=true"));
    }

    @Test(description = "Delete p13n error, ids empty and deleteAll=false")
    public void deleteP13nsError2() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Get ids of cosmos documents to delete.
        List<P13nDocument> p13nDocuments = p13nDao.getP13nDocuments(onlineAccountId);
        List<String> cosmosIds = p13nDocuments.stream().map(P13nDocument::getId).collect(Collectors.toList());

        //Delete P13ns API Call
        Response<ServiceResponseHolder<Void>> deletApiResponse =
                accountEntityServiceRetrofit
                        .deleteP13nsV1(onlineAccountId, new DeleteP13nsRequest(), domainId, false, reqId, reqTrackingId);
        Assert.assertEquals(deletApiResponse.code(), 400);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, deletApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);

        Assert.assertEquals(error.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertTrue(error.getMessage().contains("Ids must be present if deleteAll=false, absent if deleteAll=true"));
    }

    @Test(description = "Get P13Ns success, without any query params, default to ALL")
    public void getP13NsSuccessWithoutPassingQueryParams() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first
        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);


        //Get P13ns API Call
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, null, null, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 200, errorMessage);

        //verify response
        GetCustomerP13nResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertEquals(getCustomerP13nResponse.getOnlineAccountId(), onlineAccountId);
        assertP13nsInRequestAndResponseIsSame(createP13nsRequest.getP13ns(), getCustomerP13nResponse.getP13ns());

        // cleanup, delete p13ns.
        p13nDao.deleteP13nDocuments(onlineAccountId, getCustomerP13nResponse.getP13ns().stream()
                .map(GetCustomerP13nResponse.P13n::getId).collect(Collectors.toList()));

    }

    @Test(description = "Get P13Ns success, entity=All and type=ALL")
    public void getP13NsSuccessALL() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first
        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.IMPORT_RX_NUDGE.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);


        //Get P13ns API Call
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, ALL, ALL, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 200, errorMessage);

        //verify response
        GetCustomerP13nResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertEquals(getCustomerP13nResponse.getOnlineAccountId(), onlineAccountId);
        assertP13nsInRequestAndResponseIsSame(createP13nsRequest.getP13ns(), getCustomerP13nResponse.getP13ns());

        // cleanup, delete p13ns.
        p13nDao.deleteP13nDocuments(onlineAccountId, getCustomerP13nResponse.getP13ns().stream()
                .map(GetCustomerP13nResponse.P13n::getId).collect(Collectors.toList()));

    }

    @Test(description = "Get P13Ns success, passing entity and type as well")
    public void getP13NsSuccessSpecificEntityAndType() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Create P13ns first
        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));

        CreateP13nsRequest.P13n importRxP13ns
                = buildP13ns(P13nEntity.IMPORT_RX_NUDGE.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3);
        p13nList.add(importRxP13ns);
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);


        //Get P13ns API Call
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, P13nEntity.IMPORT_RX_NUDGE.getValue(),
                                P13nType.CARD_DISMISSAL.getValue(), reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 200, errorMessage);

        //verify response
        GetCustomerP13nResponse getCustomerP13nResponse = getApiResponse.body().getPayload();
        Assert.assertEquals(getCustomerP13nResponse.getOnlineAccountId(), onlineAccountId);
        assertP13nsInRequestAndResponseIsSame(Collections.singletonList(importRxP13ns), getCustomerP13nResponse.getP13ns());

        // cleanup, delete p13ns.
        p13nDao.deleteP13nDocuments(onlineAccountId, getCustomerP13nResponse.getP13ns().stream()
                .map(GetCustomerP13nResponse.P13n::getId).collect(Collectors.toList()));

    }

    @Test(description = "Get P13Ns success, no content")
    public void getP13NsSuccessNoContent() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Get P13ns API Call
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, null, null, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(error);
        Assert.assertEquals(getApiResponse.code(), 204, errorMessage);

    }

    @Test(description = "Get P13Ns, entity=RX and type=ARCHIVE")
    public void getP13NsTypeNotNullAndEntityIsAllSuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);

        //Get P13ns API Call
        final String entity = P13nEntity.RX.name();
        final String type = P13nType.ARCHIVE.getValue();
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Assert.assertNotNull(getApiResponse);
        Assert.assertNotNull(getApiResponse.body());
        Assert.assertNotNull(getApiResponse.body().getPayload());
        Assert.assertEquals(getApiResponse.code(), 200);
        Assert.assertEquals(2, getApiResponse.body().getPayload().getP13ns().size());
    }

    @Test(description = "Get P13Ns,  entity=RX and type=ARCHIVE")
    public void getP13NsEntityNotNullAndTypeIsAllSuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);

        //Get P13ns API Call
        final String entity = P13nEntity.RX.name();
        final String type = P13nType.ARCHIVE.name();
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Assert.assertNotNull(getApiResponse);
        Assert.assertNotNull(getApiResponse.body());
        Assert.assertNotNull(getApiResponse.body().getPayload());
        Assert.assertEquals(getApiResponse.code(), 200);
        Assert.assertEquals(2, getApiResponse.body().getPayload().getP13ns().size());
    }

    @Test(description = "Get P13Ns,  entity=ALL and type=ALL")
    public void getP13NsEntityAndTypeAreAllSuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns(P13nEntity.RX.getValue(), P13nType.ARCHIVE.getValue(), 2));
        p13nList.add(buildP13ns(P13nEntity.CT_TRACKER_CARD.getValue(), P13nType.CARD_DISMISSAL.getValue(), 3));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);

        //Get P13ns API Call
        final String entity = ALL;
        final String type = ALL;
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Assert.assertNotNull(getApiResponse);
        Assert.assertNotNull(getApiResponse.body());
        Assert.assertNotNull(getApiResponse.body().getPayload());
        Assert.assertEquals(getApiResponse.code(), 200);
        Assert.assertEquals(5, getApiResponse.body().getPayload().getP13ns().size());
    }

    @Test(description = "Get P13Ns error, entity=RXS and type=ALL")
    public void getP13NsErrorInvalidEnumValue() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Get P13ns API Call
        final String entity = "RXS";
        final String type = ALL;
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        Assert.assertEquals(getApiResponse.code(), 400);
        Assert.assertTrue(error.getMessage()
                .contains(String.format("Invalid P13n type or entity. Entity: %s, Type: %s", entity, type)));
        Assert.assertEquals(error.getCode(), "DPR-DPACCENSR-1001");
    }

    @Test(description = "Get P13Ns error, entity=AUTO_RECOMMEND_DEPENDENT and type=CARD_DISMISSAL")
    public void createAndGetP13NsForAutoRecommendDependentSuccess() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        List<CreateP13nsRequest.P13n> p13nList = new ArrayList<CreateP13nsRequest.P13n>();
        p13nList.add(buildP13ns("AUTO_RECOMMEND_DEPENDENT", P13nType.CARD_DISMISSAL.getValue(), 1));
        CreateP13nsRequest createP13nsRequest = CreateP13nsRequest.builder().p13ns(p13nList).build();

        Response<ServiceResponseHolder<Void>> createApiResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createP13nsRequest, domainId, reqId, reqTrackingId);
        Assert.assertEquals(createApiResponse.code(), 200);


        //Get P13ns API Call
        final String entity = "AUTO_RECOMMEND_DEPENDENT";
        final String type = P13nType.CARD_DISMISSAL.name();
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Assert.assertNotNull(getApiResponse);
        Assert.assertNotNull(getApiResponse.body());
        Assert.assertNotNull(getApiResponse.body().getPayload());
        Assert.assertEquals(getApiResponse.code(), 200);
        Assert.assertEquals(1, getApiResponse.body().getPayload().getP13ns().size());
    }

    @Test(description = "Get P13Ns error, entity=AUTO_RECOMMEND_DEPENDENT and type=CARD_DISMISSAL")
    public void createAndGetP13NsForAutoRecommendDependent204() throws IOException {

        final String onlineAccountId = UUID.randomUUID().toString();

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        //Get P13ns API Call
        final String entity = "AUTO_RECOMMEND_DEPENDENT";
        final String type = P13nType.CARD_DISMISSAL.name();
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getApiResponse =
                accountEntityServiceRetrofit
                        .getP13nsV1(onlineAccountId, domainId, entity, type, reqId, reqTrackingId);

        Error error = Optional.ofNullable(CommonUtil.getEntityServiceResponseHolder(gson, getApiResponse))
                .map(ServiceResponseHolder::getError).orElse(null);
        Assert.assertEquals(getApiResponse.code(), 204);
    }

    private CreateP13nsRequest.P13n buildP13ns(String entity, String type, int count) {

        List<JsonElement> identifiers = IntStream.range(0, count).mapToObj(ignore -> {
            return new JsonObject();
        }).collect(Collectors.toList());

        return CreateP13nsRequest.P13n.builder()
                .entity(entity)
                .type(type)
                .identifiers(identifiers)
                .build();
    }

    /* Asserting that created p13ns were returned back successfully in the response.
    *  We assert the fields like entity, type and also number of documents for each entity/type created.
    * */
    private void assertP13nsInRequestAndResponseIsSame(List<CreateP13nsRequest.P13n> requestP13ns,
                                                       List<GetCustomerP13nResponse.P13n> responseP13ns) {

        Map<String, CreateP13nsRequest.P13n> requestP13nsMap = requestP13ns.stream()
                .collect(Collectors.toMap(p13n -> p13n.getEntity() + "-" + p13n.getType(), Function.identity()));

        Map<String, List<GetCustomerP13nResponse.P13n>> responseP13nsMap = responseP13ns.stream()
                .collect(Collectors.groupingBy(p13n -> p13n.getEntity() + "-" + p13n.getType()));


        Assert.assertEquals(responseP13nsMap.size(), requestP13nsMap.size());
        requestP13nsMap.forEach((key, requestP13n) -> {
            Assert.assertTrue(responseP13nsMap.containsKey(key));
            Assert.assertEquals(responseP13nsMap.get(key).size(), requestP13n.getIdentifiers().size());
        });
    }

    /* Asserting that created p13ns were created successfully in DB.
     * We assert the fields like entity, type and also number of documents for each entity/type created.
     * */
    private void assertP13nsInRequestAndDBIsSame(List<CreateP13nsRequest.P13n> requestP13ns,
                                                  List<P13nDocument> p13nDocuments) {

        Map<String, CreateP13nsRequest.P13n> requestP13nsMap = requestP13ns.stream()
                .collect(Collectors.toMap(p13n -> p13n.getEntity() + "-" + p13n.getType(), Function.identity()));

        Map<String, List<P13nDocument>> responseP13nsMap = p13nDocuments.stream()
                .collect(Collectors.groupingBy(p13n -> p13n.getEntity() + "-" + p13n.getType()));


        Assert.assertEquals(responseP13nsMap.size(), requestP13nsMap.size());
        requestP13nsMap.forEach((key, requestP13n) -> {
            Assert.assertTrue(responseP13nsMap.containsKey(key));
            Assert.assertEquals(responseP13nsMap.get(key).size(), requestP13n.getIdentifiers().size());
        });
    }

}
