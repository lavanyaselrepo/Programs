package accountentity.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataTable;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreatePharmacyAccountV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.DeleteAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.DataBaseQueryHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.helpers.CPRServiceHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityServiceDeleteAccountTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private AccountOrchestratorRetrofit accountOrchestratorRetrofit;
  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;

  private final IDatabaseContext accountDpDbContext =
      AutomationManager.getInstance().getDPAccountDBContext();
  private final IDatabaseContext accountDpDbSchedulerContext =
      AutomationManager.getInstance().getDPAccountSchedulerDBContext();

  private final Gson gson = new GsonBuilder().create();
  private String onlineAccountId = null;
  private String samsOnlineAccountId = null;
  private String storeNbr = null;
  private String patientId = null;
  private String commonDobDPFormat = null;
  private String commonDobCPRFormat = null;
  ;
  private String accountCreationSource = "smsOtpVerification";
  private String domainId = "WM-PHARMACY";
  private String samsDomainId = "SAMS-PHARMACY";
  private String wmPharmacyStore = "9928";
  private String samsPharmacyStore = "7108";
  private String PENDING_HIPPA_AUTH_TYPE = "pending_hipaa_auth";
  private String domainIdSamsPharmacy = "SAMS-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() throws IOException {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();

    onlineAccountId = CommonUtil.randomUUID();
    storeNbr = CommonUtil.generateRandomNumber(6);
    patientId = CommonUtil.generateRandomNumber(9);
    samsOnlineAccountId = CommonUtil.randomUUID();

    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);

    commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);
  }

  @Test(priority = 0, description = "Delete account V1 API failure due to invalid domain id")
  public void deleteAccountV1APIFailureInvalidDomainId() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Invalid domainId
    String invalidDomainId = "DUMMY";
    CommonUtil.logFlowIdentifiers(onlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Calling deleteAccountV1 with a onlineAccountId present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
        accountEntityServiceRetrofit.deleteAccountV1(
            onlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountApiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Asserting response
    Assert.assertEquals(deleteAccountApiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(errorResponse.getMessage());
    Assert.assertTrue(errorResponse.getMessage().contains("Invalid input request"));
    Assert.assertTrue(errorResponse.getMessage().contains("permitted as domainId"));
  }

  @Test(
      priority = 1,
      description = "Delete account V1 API failure due to online account not present in DB")
  public void deleteAccountV1APIFailureOnlineAccountIdDoesNotExist() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Calling deleteAccountV1 with a onlineAccountId not present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
        accountEntityServiceRetrofit.deleteAccountV1(
            onlineAccountId, domainId, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountApiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Asserting response
    Assert.assertEquals(deleteAccountApiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1014");
    Assert.assertNotNull(errorResponse.getMessage());
    Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }

  @Test(priority = 2, description = "Delete account for sams account V1 API success")
  public void deleteAccountV1APISuccessForSAMS() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    String commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    String commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);

    CommonUtil.logFlowIdentifiers(samsOnlineAccountId, domainIdSamsPharmacy, reqId, reqTrackingId);

    // Creating account in CPR
    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit,
        storeNbr,
        patientId,
        commonDobCPRFormat,
        RandomStringUtils.randomAlphabetic(5),
        RandomStringUtils.randomAlphabetic(5));

    /**
     * This is needed because CPR account creation is async, and it usually takes a couple of
     * seconds to reflect account creation
     */
    try {
      Thread.sleep(10000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    // Creating account in OCP
    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request(storeNbr, patientId, commonDobDPFormat);

    Response<ServiceResponse> createAccountApiResponse =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            samsOnlineAccountId,
            domainIdSamsPharmacy,
            createPharmacyAccountV1Request,
            reqId,
            reqTrackingId);

    // Asserting response
    Assert.assertEquals(createAccountApiResponse.code(), 200);

    // Calling deleteAccountV1 with a onlineAccountId present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
        accountEntityServiceRetrofit.deleteAccountV1(
            samsOnlineAccountId, domainIdSamsPharmacy, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountApiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(deleteAccountApiResponse.code(), 200, errorMessage);

    // Parsing the response to the deleteAccountV1Response class so that we can assert
    // deleteAccountV1
    DeleteAccountV1Response deleteAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountApiResponse.body().getPayload()),
            DeleteAccountV1Response.class);

    // Asserting response
    Assert.assertEquals(deleteAccountV1Response.getOnlineAccountId(), samsOnlineAccountId);
    Assert.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), storeNbr);
  }

  @Test(priority = 3, description = "Delete account success when CPR 9928 returning 204")
  public void deleteAccountV1SuccessWhenCPRGivesNoContent() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String onlineAccountId = CommonUtil.randomUUID();
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);

    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Inserting into OCP directly, no 9928 profile will  be created in CPR
    accountDpDbContext.executeInsertQuery(
        DataBaseQueryHelper.insertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            wmPharmacyStore,
            storeNbr,
            patientId,
            onlineAccountId));

    // Verifying the data in OCP table for cid
    DataTable ocpTableEntry =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(1, ocpTableEntry.getRowCount());

    // Calling deleteAccountV1 with a onlineAccountId present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
        accountEntityServiceRetrofit.deleteAccountV1(
            onlineAccountId, domainId, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    DeleteAccountV1Response deleteAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountApiResponse.body().getPayload()),
            DeleteAccountV1Response.class);

    // Verifying ocp table data got deleted
    DataTable ocpDataDeletionEntry =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(0, ocpDataDeletionEntry.getRowCount());

    // Asserting response
    Assert.assertEquals(deleteAccountV1Response.getOnlineAccountId(), onlineAccountId);
    Assert.assertEquals(deleteAccountV1Response.getAuthPatientId(), patientId);
    Assert.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), storeNbr);
  }

  @Test(priority = 4, description = "Delete account V1 API success")
  public void deleteAccountV1APISuccess() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String onlineAccountId = CommonUtil.randomUUID();
    String storeNbr = CommonUtil.generateRandomNumber(6);
    String patientId = CommonUtil.generateRandomNumber(9);
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    String commonDobDPFormat = new SimpleDateFormat("MMddyyyy").format(date);
    String commonDobCPRFormat = new SimpleDateFormat("yyyy-MM-dd").format(date);

    CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

    CreatePharmacyAccountV1Request createPharmacyAccountV1Request =
        getCreatePharmacyAccountV1Request(storeNbr, patientId, commonDobDPFormat);

    // Creating cpr account
    CPRServiceHelper.createAccountInCPR(
        cprPatientUpdateRetrofit,
        storeNbr,
        patientId,
        commonDobCPRFormat,
        RandomStringUtils.randomAlphabetic(5),
        RandomStringUtils.randomAlphabetic(5));
    /**
     * This is needed because CPR account creation is async, and it usually takes a couple of
     * seconds to reflect account creation
     */
    try {
      Thread.sleep(10000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    // Calling createPharmacyAccountV1 to create Online Central Patient table data and customer
    // attribute table data and CPR 9928 profile
    Response<ServiceResponse> apiResponseCreateAccount =
        accountEntityServiceRetrofit.createPharmacyAccountV1(
            onlineAccountId, domainId, createPharmacyAccountV1Request, reqId, reqTrackingId);
    Assert.assertEquals(apiResponseCreateAccount.code(), 200);

    // Insert into FAM table, customer verification table, customer email reminder

    // Insert into FAM table as dependentId
    accountDpDbContext.executeInsertQuery(
        DataBaseQueryHelper.insertFAMQuery(
            CommonUtil.randomUUID(),
            onlineAccountId,
            wmPharmacyStore,
            storeNbr,
            patientId,
            PENDING_HIPPA_AUTH_TYPE));

    // Insert into FAM table as caregiverId
    accountDpDbContext.executeInsertQuery(
        DataBaseQueryHelper.insertFAMQuery(
            onlineAccountId,
            CommonUtil.randomUUID(),
            wmPharmacyStore,
            storeNbr,
            patientId,
            PENDING_HIPPA_AUTH_TYPE));

    // Insert in customer verification table
    accountDpDbContext.executeInsertQuery(
        DataBaseQueryHelper.insertCustomerVerificationQuery(onlineAccountId));

    // Insert in customer email reminder
    String id = generateRandomHex(16);
    accountDpDbSchedulerContext.executeInsertQuery(
        DataBaseQueryHelper.insertCustomerEmailReminderQuery(id, onlineAccountId));

    // Verifying the data present in all DB involved

    // OCP table
    DataTable ocpTableEntry =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(1, ocpTableEntry.getRowCount());

    // FAM table
    DataTable famRequestTableEntry =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getFAMRowQuery(onlineAccountId));
    Assert.assertEquals(2, famRequestTableEntry.getRowCount());

    // CustomerVerification table
    DataTable customerAttributeEntry =
        accountDpDbContext.getDataTable(
            DataBaseQueryHelper.getCustomerVerificationRowQuery(onlineAccountId));
    Assert.assertEquals(1, customerAttributeEntry.getRowCount());

    // Customer email reminder table
    DataTable customerEmailReminderEntry =
        accountDpDbSchedulerContext.getDataTable(
            DataBaseQueryHelper.getCustomerEmailReminderRowQuery(onlineAccountId));
    Assert.assertEquals(1, customerEmailReminderEntry.getRowCount());

    Response<ServiceResponse> deleteAccountApiResponse =
        accountEntityServiceRetrofit.deleteAccountV1(
            onlineAccountId, domainId, reqId, reqTrackingId);

    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountApiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(deleteAccountApiResponse.code(), 200, errorMessage);

    DeleteAccountV1Response deleteAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) deleteAccountApiResponse.body().getPayload()),
            DeleteAccountV1Response.class);

    // Response verification

    // CPR  9928 profile got deleted
    Response<com.walmart.pharmacy.dp.account.orchestrator.restclient.model.ServiceResponse>
        getCustomerInfoV2Response1 =
            accountOrchestratorRetrofit.getCustomerInfoV2(
                onlineAccountId, domainId, false, false, null, false, false, false, false, false);
    Assert.assertEquals(getCustomerInfoV2Response1.code(), 204);

    // OCP table data deleted
    DataTable dtOCPDeletion =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(0, dtOCPDeletion.getRowCount());

    // CustomerAttributeTable data deleted
    DataTable deleteCustomerVerification =
        accountDpDbContext.getDataTable(
            DataBaseQueryHelper.getCustomerVerificationRowQuery(onlineAccountId));
    Assert.assertEquals(0, deleteCustomerVerification.getRowCount());

    // FAM table
    DataTable dtFAMDeletion =
        accountDpDbContext.getDataTable(DataBaseQueryHelper.getFAMRowQuery(onlineAccountId));
    Assert.assertEquals(0, dtFAMDeletion.getRowCount());

    /**
     * This is needed because Customer email reminder deletion is async, and it usually takes a
     * couple of seconds to reflect
     */
    try {
      Thread.sleep(20000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    // Customer Email Reminder table
    DataTable dtEmailReminderDeletion =
        accountDpDbSchedulerContext.getDataTable(
            DataBaseQueryHelper.getCustomerEmailReminderRowQuery(onlineAccountId));
    Assert.assertEquals(0, dtEmailReminderDeletion.getRowCount());

    Assert.assertEquals(deleteAccountV1Response.getOnlineAccountId(), onlineAccountId);
    Assert.assertEquals(deleteAccountV1Response.getAuthPatientId(), patientId);
    Assert.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), storeNbr);
  }

  @Test(
          priority = 5,
          description = "Delete account V1 API failure due to online account not present in DB")
  public void deleteAccountV1APIFailureOnlineAccountIdDoesNotExistForSamsDomain() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, samsDomainId, reqId, reqTrackingId);

    // Calling deleteAccountV1 with a onlineAccountId not present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
            accountEntityServiceRetrofit.deleteAccountV1(
                    onlineAccountId, samsDomainId, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error errorResponse =
            CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountApiResponse);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Asserting response
    Assert.assertEquals(deleteAccountApiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1014");
    Assert.assertNotNull(errorResponse.getMessage());
    Assert.assertTrue(errorResponse.getMessage().contains("No customer profile found in OCP"));
  }

  @Test(priority = 6, description = "Delete account success when CPR 7108 returning 204")
  public void deleteAccountV1SuccessWhenCPRGivesNoContentForSamsDomain() throws IOException {

    // Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    // Test data creation
    String onlineAccountId = CommonUtil.randomUUID();
    String storeNbr = "5596";
    String patientId = CommonUtil.generateRandomNumber(9);

    CommonUtil.logFlowIdentifiers(onlineAccountId, samsDomainId, reqId, reqTrackingId);

    // Inserting into OCP directly, no 7108 profile will  be created in CPR
    accountDpDbContext.executeInsertQuery(
            DataBaseQueryHelper.insertOcidQuery(
                    CommonUtil.generateRandomNumber(9),
                    samsPharmacyStore,
                    storeNbr,
                    patientId,
                    onlineAccountId));

    // Verifying the data in OCP table for cid
    DataTable ocpTableEntry =
            accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(1, ocpTableEntry.getRowCount());

    // Calling deleteAccountV1 with a onlineAccountId present in DB
    Response<ServiceResponse> deleteAccountApiResponse =
            accountEntityServiceRetrofit.deleteAccountV1(
                    onlineAccountId, samsDomainId, reqId, reqTrackingId);

    // Building errorMessage in case the Assert for response fails
    DeleteAccountV1Response deleteAccountV1Response =
            ResponseUtil.parseResponse(
                    gson,
                    ((LinkedTreeMap<String, Object>) deleteAccountApiResponse.body().getPayload()),
                    DeleteAccountV1Response.class);

    // Verifying ocp table data got deleted
    DataTable ocpDataDeletionEntry =
            accountDpDbContext.getDataTable(DataBaseQueryHelper.getOcidRowQuery(onlineAccountId));
    Assert.assertEquals(0, ocpDataDeletionEntry.getRowCount());

    // Asserting response
    Assert.assertEquals(deleteAccountV1Response.getOnlineAccountId(), onlineAccountId);
    Assert.assertEquals(deleteAccountV1Response.getAuthPatientId(), patientId);
    Assert.assertEquals(deleteAccountV1Response.getAuthStoreNbr(), storeNbr);
  }

  private CreatePharmacyAccountV1Request getCreatePharmacyAccountV1Request(
      String storeNbr, String patientId, String commonDobDPFormat) {
    return CreatePharmacyAccountV1Request.builder()
        .accountCreationSource(accountCreationSource)
        .customerInfo(
            CreatePharmacyAccountV1Request.CustomerInfo.builder()
                .storeNbr(storeNbr)
                .patientId(patientId)
                .dob(commonDobDPFormat)
                .build())
        .build();
  }

  private String generateRandomHex(int length) {
    Random random = new Random();
    StringBuilder sb = new StringBuilder("0x");
    String hexChars = "0123456789ABCDEF";

    for (int i = 0; i < length; i++) {
      sb.append(hexChars.charAt(random.nextInt(hexChars.length())));
    }
    return sb.toString();
  }
}
