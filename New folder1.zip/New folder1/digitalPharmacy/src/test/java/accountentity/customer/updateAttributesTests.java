package accountentity.customer;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.getAttributesPayload;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.updateAttributePayloadResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getAttributesWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.updateAttributesWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class updateAttributesTests {
    updateAttributesWrapper updateWrapper = new updateAttributesWrapper();


    @Test(
            priority = 1, description = "Update data for online customer attributes",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "updateAttributes")
    public void updateAttributesConsumer (Map<String, String> inputData){
        String customerId = nullStringValidation(inputData.get("customerId"));
        String name =  nullStringValidation(inputData.get("name"));
        String value = nullStringValidation(inputData.get("value"));
        String type = nullStringValidation(inputData.get("type"));
        String status = nullStringValidation(inputData.get("status"));

        ServiceResponse updateAttributes = updateWrapper.updateAttributesFunction(name, value, customerId, type);



        if (updateAttributes.getStatusCode() == 200) {
            updateAttributePayloadResponse updatePayloads = updateAttributes.getDataResponse(updateAttributePayloadResponse.class);
            //System.out.println(updatePayloads.toString());
            Assert.assertEquals(updateAttributes.getStatusCode(), Integer.parseInt(status));
            Assert.assertEquals(updatePayloads.getPayload().getOnlineAccountId(), customerId);
            getAttributesWrapper getWrapper = new getAttributesWrapper();

            //calling getAttribute to check database updated
            ServiceResponse getAttribute = getWrapper.getAtrributesFunction(customerId, name, type);
            getAttributesPayload attributesPayload = getAttribute.getDataResponse(getAttributesPayload.class);
            Assert.assertEquals(getAttribute.getStatusCode(), Integer.parseInt(status));
            Assert.assertEquals(attributesPayload.getPayload().getAttributes().get(0).getName(), name);
            if(value !=null) {
                Assert.assertEquals(attributesPayload.getPayload().getAttributes().get(0).getValue(), value.toLowerCase());
            }
        }
        else{
            Assert.assertEquals(updateAttributes.getStatusCode(), Integer.parseInt(status));
        }

    }
    public String nullStringValidation(String inputData){
        String val = inputData;
        if((inputData.equals("null"))) {
            val = null;
        }
        return val;
    }
}
