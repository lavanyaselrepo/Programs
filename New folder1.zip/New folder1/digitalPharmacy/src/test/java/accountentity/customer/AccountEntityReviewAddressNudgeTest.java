package accountentity.customer;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nAuditDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nAuditDocument;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDao;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.dao.P13nDocument;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.enums.P13nType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.CreateP13nsRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.GetCustomerP13nResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.common.ServiceResponseHolder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import test.java.accountorchestrator.utils.P13nTestUtil;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Test class for Review and Update Address Nudge functionality in Account Entity Service
 * This test verifies the CRUD operations for P13N records
 */
public class AccountEntityReviewAddressNudgeTest {

    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private final Gson gson = new Gson();
    private P13nDao p13nDao;
    private P13nAuditDao p13nAuditDao;

    private final String domainId = "WM-PHARMACY";
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";

    // Random account ID for all tests (does not need to be a valid test patient for entity-level tests)
    private String onlineAccountId;

    @BeforeClass
    void setContext() throws IOException {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        p13nDao = new P13nDao();
        p13nAuditDao = new P13nAuditDao();

        // Generate random UUID for this test run
        onlineAccountId = CommonUtil.randomUUID();
    }

    /**
     * Clean up method to delete all REVIEW_AND_UPDATE_ADDRESS_NUDGE records
     * from both main container and audit after each test
     */
    @AfterMethod
    void cleanupAfterTest() {
        cleanupReviewAddressNudgeRecords();
    }

    /**
     * Helper method to clean up all REVIEW_AND_UPDATE_ADDRESS_NUDGE records
     * from both main P13N container and audit container
     */
    private void cleanupReviewAddressNudgeRecords() {
        P13nTestUtil.cleanupP13nRecords(
                onlineAccountId,
                P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE,
                p13nDao,
                p13nAuditDao);
    }

    /**
     * Test to verify creating a card dismissal record via Account Entity Service
     *
     * Test Scenario:
     * - Create a card dismissal record
     * - Verify the record exists in the database
     * - Verify getP13NsV1 returns the dismissal
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify creating card dismissal via Account Entity Service")
    public void testCreateCardDismissal() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create card dismissal record
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "dismiss");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> createResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(createResponse.code(), 200, "Expected 200 OK from createP13nsV1");

        // Step 2: Verify the record exists in database
        List<P13nDocument> p13nDocuments = p13nDao.getP13nDocuments(onlineAccountId);
        P13nDocument dismissal = p13nDocuments.stream()
                .filter(doc -> doc.getEntity() == P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE
                        && doc.getType() == P13nType.CARD_DISMISSAL)
                .findFirst()
                .orElse(null);

        Assert.assertNotNull(dismissal, "Dismissal record should exist in database");
        Assert.assertEquals(dismissal.getEntity(), P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE);
        Assert.assertEquals(dismissal.getType(), P13nType.CARD_DISMISSAL);

        // Step 3: Verify getP13NsV1 returns the dismissal
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getResponse =
                accountEntityServiceRetrofit.getP13nsV1(
                        onlineAccountId, domainId,
                        P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name(),
                        P13nType.CARD_DISMISSAL.name(),
                        reqId, reqTrackingId);

        Assert.assertEquals(getResponse.code(), 200, "Should return 200 for dismissal");

        GetCustomerP13nResponse response = getResponse.body().getPayload();
        Assert.assertNotNull(response);
        Assert.assertNotNull(response.getP13ns());
        Assert.assertFalse(response.getP13ns().isEmpty(), "Should return the dismissal record");
        Assert.assertEquals(response.getP13ns().get(0).getType(), P13nType.CARD_DISMISSAL);
    }

    /**
     * Test to verify querying P13N records by entity and type
     *
     * Test Scenario:
     * - Create a CARD_DISMISSAL record
     * - Query by entity and type for CARD_DISMISSAL
     * - Query by entity and type for SHOW (should be empty)
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify querying P13N records by entity and type")
    public void testQueryP13NByEntityAndType() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create a card dismissal
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "dismiss");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> createResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(createResponse.code(), 200, "Expected 200 OK from createP13nsV1");

        // Step 2: Query for CARD_DISMISSAL type
        Response<ServiceResponseHolder<GetCustomerP13nResponse>> getResponse =
                accountEntityServiceRetrofit.getP13nsV1(
                        onlineAccountId, domainId,
                        P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name(),
                        P13nType.CARD_DISMISSAL.name(),
                        reqId, reqTrackingId);

        Assert.assertEquals(getResponse.code(), 200, "Should return 200");

        GetCustomerP13nResponse response = getResponse.body().getPayload();
        Assert.assertNotNull(response);
        Assert.assertNotNull(response.getP13ns());
        Assert.assertEquals(response.getP13ns().size(), 1, "Should return exactly 1 dismissal");
        Assert.assertEquals(response.getP13ns().get(0).getEntity(), P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE);
        Assert.assertEquals(response.getP13ns().get(0).getType(), P13nType.CARD_DISMISSAL);
    }

    /**
     * Test to verify bottomsheet_confirm action creates audit record
     *
     * Test Scenario:
     * - Create a P13N with action="bottomsheet_confirm"
     * - Verify audit record exists in the database
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify bottomsheet_confirm action creates audit record")
    public void testBottomsheetConfirmCreatesAuditRecord() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create P13N with bottomsheet_confirm action
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "bottomsheet_confirm");
        metadata.addProperty("address", "hashedaddress123");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> createResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(createResponse.code(), 200, "Expected 200 OK from createP13nsV1");
    }

    /**
     * Test to verify bottomsheet_update action creates audit record
     *
     * Test Scenario:
     * - Create a P13N with action="bottomsheet_update"
     * - Verify audit record exists in the database
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify bottomsheet_update action creates audit record")
    public void testBottomsheetUpdateCreatesAuditRecord() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create P13N with bottomsheet_update action
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "bottomsheet_update");
        metadata.addProperty("address", "hashedaddress456");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> createResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(createResponse.code(), 200, "Expected 200 OK from createP13nsV1");
    }

    /**
     * Test to verify update action creates audit record
     *
     * Test Scenario:
     * - Create a P13N with action="update"
     * - Verify audit record exists in the database
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify update action creates audit record")
    public void testUpdateActionCreatesAuditRecord() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create P13N with update action
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "update");
        metadata.addProperty("address", "hashedaddress789");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> createResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(createResponse.code(), 200, "Expected 200 OK from createP13nsV1");
    }

    /**
     * Test to verify that multiple dismiss calls increment the dismissal count and timestamps
     *
     * Test Scenario:
     * - Create initial dismissal with action="dismiss"
     * - Verify audit record exists and check initial count and timestamps
     * - Create another dismissal with action="dismiss"
     * - Verify dismissal count and timestamp list have increased in audit record
     *
     * @throws IOException if API call fails
     */
    @Test(description = "Verify multiple dismissals increment count and timestamps")
    public void testMultipleDismissalsIncrementCountAndTimestamps() throws IOException {

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

        // Step 1: Create first dismissal
        JsonObject metadata = new JsonObject();
        metadata.addProperty("action", "dismiss");

        JsonObject identifier = new JsonObject();
        identifier.add("metadata", metadata);

        List<JsonElement> identifiers = new ArrayList<>();
        identifiers.add(identifier);

        CreateP13nsRequest.P13n p13n = CreateP13nsRequest.P13n.builder()
                .entity(P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE.name())
                .type(P13nType.CARD_DISMISSAL.name())
                .identifiers(identifiers)
                .build();

        CreateP13nsRequest createRequest = CreateP13nsRequest.builder()
                .p13ns(Collections.singletonList(p13n))
                .build();

        Response<ServiceResponseHolder<Void>> firstDismissalResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(firstDismissalResponse.code(), 200, "Expected 200 OK from createP13nsV1");

        // Step 2: Retrieve the audit record and check initial count and timestamps
        List<P13nAuditDocument> auditDocuments = p13nAuditDao.getP13nAuditDocuments(
                onlineAccountId, P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE);

        Assert.assertFalse(auditDocuments.isEmpty(), "Audit record should exist after first dismissal");

        P13nAuditDocument firstAuditDoc = auditDocuments.get(0);
        com.fasterxml.jackson.databind.JsonNode firstMetadata = firstAuditDoc.getMetadata();
        Assert.assertNotNull(firstMetadata, "Metadata should exist");

        int initialCount = firstMetadata.has("dismissalCount") ? firstMetadata.get("dismissalCount").asInt() : 0;
        int initialTimestampsSize = firstMetadata.has("dismissalTimestamps") && firstMetadata.get("dismissalTimestamps").isArray()
                ? firstMetadata.get("dismissalTimestamps").size() : 0;;

        Assert.assertTrue(initialCount >= 1, "Initial count should be at least 1");
        Assert.assertTrue(initialTimestampsSize >= 1, "Initial timestamps should have at least 1 entry");

        // Step 3: Create second dismissal
        Response<ServiceResponseHolder<Void>> secondDismissalResponse =
                accountEntityServiceRetrofit.createP13nsV1(
                        onlineAccountId, createRequest, domainId, reqId, reqTrackingId);

        Assert.assertEquals(secondDismissalResponse.code(), 200, "Expected 200 OK from createP13nsV1");

        // Step 4: Retrieve audit record again and verify count increased
        auditDocuments = p13nAuditDao.getP13nAuditDocuments(
                onlineAccountId, P13nEntity.REVIEW_AND_UPDATE_ADDRESS_NUDGE);

        Assert.assertFalse(auditDocuments.isEmpty(), "Audit record should exist after second dismissal");

        P13nAuditDocument secondAuditDoc = auditDocuments.get(0);
        com.fasterxml.jackson.databind.JsonNode secondMetadata = secondAuditDoc.getMetadata();
        Assert.assertNotNull(secondMetadata, "Metadata should exist");

        int updatedCount = secondMetadata.has("dismissalCount") ? secondMetadata.get("dismissalCount").asInt() : 0;
        int updatedTimestampsSize = secondMetadata.has("dismissalTimestamps") && secondMetadata.get("dismissalTimestamps").isArray()
                ? secondMetadata.get("dismissalTimestamps").size() : 0;

        Assert.assertEquals(updatedCount, initialCount + 1,
                "Dismissal count should increase by 1 after second dismiss. Initial: " + initialCount + ", Updated: " + updatedCount);
        Assert.assertEquals(updatedTimestampsSize, initialTimestampsSize + 1,
                "Timestamps list size should increase by 1 after second dismiss. Initial: " + initialTimestampsSize + ", Updated: " + updatedTimestampsSize);
    }

}
