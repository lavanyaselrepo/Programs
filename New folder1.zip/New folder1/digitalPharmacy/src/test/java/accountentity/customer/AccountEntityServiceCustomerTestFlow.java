package accountentity.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityServiceCustomerTestFlow {

  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String reqIdString = "req-id-";
  private static final String ACCOUNT = "ACCOUNT";
  private String reqTrackingString = "req-tracking-";
  private String commonOnlineAccountId = null;

  @BeforeClass
  void setContext() {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
  }

  @Test(
      priority = 0,
      description = "UpdateCustomerAttributesV1 success for non existing onlineAccountId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesV1NonExistingOnlineAccountIdSuccess(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    commonOnlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to the UpdateCustomerAttributesV1Response class so that we can
    // assert class responses
    UpdateCustomerAttributesV1Response updateCustomerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateCustomerAttributesV1APIResponse.body().getPayload()),
            UpdateCustomerAttributesV1Response.class);

    Assert.assertEquals(
        updateCustomerAttributesV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(
      priority = 1,
      description =
          "Get customer attributes success case which will fetch the attributes which was set for commonOnlineAccountId in the above test case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesV1RequestNonExistingOnlineAccountIdSuccess(
      String onlineAccountId, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("ID_VERIFIED", "two_fa_setup_status", "LAST_VERIFICATION_SOURCE");
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and attribute
    // list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            commonOnlineAccountId, domainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getCustomerAttributesV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 200, errorMessage);

    // Step - 5: Converting all the elements of the attribute list to lowercase to assert the
    // response
    attribute.replaceAll(String::toLowerCase);

    // Step - 6: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert attributeName
    GetCustomerAttributesV1Response customerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerAttributesV1Response.body().getPayload()),
            GetCustomerAttributesV1Response.class);

    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(0).getName(), attribute.get(0));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(0).getValue(), "true");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(1).getName(), attribute.get(1));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(1).getValue(), "active");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(2).getName(), attribute.get(2));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(2).getValue(), "experian");
  }

  @Test(
      priority = 2,
      description = "UpdateCustomerAttributesV1 success for existing onlineAccountId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesV1ExistingOnlineAccountIdSuccess(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to the UpdateCustomerAttributesV1Response class so that we can
    // assert class responses
    UpdateCustomerAttributesV1Response updateCustomerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateCustomerAttributesV1APIResponse.body().getPayload()),
            UpdateCustomerAttributesV1Response.class);

    Assert.assertEquals(
        updateCustomerAttributesV1Response.getOnlineAccountId(), commonOnlineAccountId);
  }

  @Test(
      priority = 3,
      description =
          "Get customer attributes success case which will fetch the attributes which was set for commonOnlineAccountId in the above test case",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesV1RequestExistingOnlineAccountIdSuccess(
      String onlineAccountId, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("ID_VERIFIED", "two_fa_setup_status", "LAST_VERIFICATION_SOURCE");
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and attribute
    // list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            commonOnlineAccountId, domainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getCustomerAttributesV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 200, errorMessage);

    // Step - 5: Converting all the elements of the attribute list to lowercase to assert the
    // response
    attribute.replaceAll(String::toLowerCase);

    // Step - 6: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert attributeName
    GetCustomerAttributesV1Response customerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerAttributesV1Response.body().getPayload()),
            GetCustomerAttributesV1Response.class);

    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(0).getName(), attribute.get(0));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(0).getValue(), "false");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(1).getName(), attribute.get(1));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(1).getValue(), "active");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(2).getName(), attribute.get(2));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(2).getValue(), "store");
  }

  @Test(
      priority = 4,
      description = "Get customer attributes invalid request case due to invalid domainId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesV1InvalidRequestForInvalidDomainId(
      String onlineAccountId, String invalidDomainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("ID_VERIFIED", "two_fa_setup_status", "LAST_VERIFICATION_SOURCE");
    CommonUtil.logFlowIdentifiers(onlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, invalid domainId and
    // attribute list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, invalidDomainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id is not valid");

    // *****  CASE 2 - DomainId is in lowercase *****
    String invalidDomainType = "wm-pharmacy";
    CommonUtil.logFlowIdentifiers(onlineAccountId, invalidDomainType, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with a onlineAccountId, invalid domainId and
    // attribute list
    getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, invalidDomainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id is not valid");
  }

  @Test(
      priority = 5,
      description = "Get customer attributes invalid request case due to invalid attribute list",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesV1InvalidRequestForInvalidAttribute(
      String onlineAccountId, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("ID_VERIFIED", "two_fa_setup_status", "LAST_VERIFICATION_SOURC");
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and
    // invalid attribute list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, domainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Name is not valid");
  }

  @Test(
      priority = 6,
      description = "UpdateCustomerAttributesV1 invalid request case due to invalid domainId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesV1InvalidDomainId(String payload) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String domainId = "WM-PHARMAC";
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id cannot be empty/null");
  }

  @Test(
      priority = 7,
      description = "UpdateCustomerAttributesV1 invalid request case due to invalid domainId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesV1InvalidRequest(String payload, String domainId)
      throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // CASE - 1: Attribute list is empty in the payload

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        new UpdateCustomerAttributesV1Request();

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attributes List cannot be empty");

    // CASE - 2: Attribute name is null in the Attribute list

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setName(null);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Name cannot be empty/null");

    // CASE - 3: Attribute name is not valid

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setName("ID_VERIFIE");

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Name is not valid");

    // CASE - 4: Attribute value is null

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setValue(null);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Value cannot be empty/null");

    // CASE - 5: Attribute value is not valid

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setValue("TRU");

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            commonOnlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Value is not valid");
  }
}
