package accountentity.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.CreateVirtualAccountV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.*;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityServiceCreateVirtualAccountTestFlow {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private final Gson gson = new GsonBuilder().create();
  private String domainId = "WM-PHARMACY";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonOnlineAccountId = null;
  private String accountCreationSource = "ID_VERIFICATION_WITHOUT_RX";

  @BeforeClass
  void setContext() {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    commonOnlineAccountId = CommonUtil.randomUUID();
  }

  @Test(priority = 0, description = "create virtual account V1 API success")
  public void createVirtualAccountV1Success() throws IOException {
    // Step - 1: Setting and logging tracking ID's
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating the request
    CreateVirtualAccountV1Request createVirtualAccountV1Request =
        getCreateVirtualAccountV1Request();

    // Step - 3: calling the API
    Response<ServiceResponse> createVirtualAccountV1ApiResponse =
        accountEntityServiceRetrofit.createVirtualAccountV1(
            createVirtualAccountV1Request, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, createVirtualAccountV1ApiResponse);

    // Step - 5: Asserting API response code
    Assert.assertEquals(createVirtualAccountV1ApiResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response
    CreateVirtualAccountV1Response createVirtualAccountV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) createVirtualAccountV1ApiResponse.body().getPayload()),
            CreateVirtualAccountV1Response.class);

    // Step - 7: Asserting API response body
    Assert.assertEquals(createVirtualAccountV1Response.getOnlineAccountId(), commonOnlineAccountId);

    // Step - 8: making a get call to validate the created account
    Response<ServiceResponse> getPharmacyOnlineIdentityV1Response =
        accountEntityServiceRetrofit.getPharmacyOnlineIdentityV1(
            commonOnlineAccountId, domainId, reqId, reqTrackingId);
    errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getPharmacyOnlineIdentityV1Response);

    // Step - 9: Asserting API response code
    Assert.assertEquals(getPharmacyOnlineIdentityV1Response.code(), 200, errorMessage);

    // Step - 10: Parsing the response
    PharmacyOnlineIdentityV1Response pharmacyOnlineIdentityV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                getPharmacyOnlineIdentityV1Response.body().getPayload()),
            PharmacyOnlineIdentityV1Response.class);

    // Step - 11: Asserting API response body
    Assert.assertEquals(pharmacyOnlineIdentityV1Response.getAuthStoreNbr(), "9928");
    Assert.assertEquals(
        pharmacyOnlineIdentityV1Response.getAccountCreationSource(), "idVerificationWithoutRx");
  }

  @Test(priority = 1, description = "Online account id already exists")
  public void createVirtualAccountV1AccountAlreadyExists() throws IOException {
    // Step - 1: Setting and logging tracking ID's
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating the request
    CreateVirtualAccountV1Request createVirtualAccountV1Request =
        getCreateVirtualAccountV1Request();

    // Step - 3: calling the API
    Response<ServiceResponse> createVirtualAccountV1ApiResponse =
        accountEntityServiceRetrofit.createVirtualAccountV1(
            createVirtualAccountV1Request, commonOnlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, createVirtualAccountV1ApiResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(createVirtualAccountV1ApiResponse.code(), 409, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1007");
  }

  @Test(priority = 2, description = "Invalid request")
  public void createVirtualAccountV1InvalidRequest() throws IOException {
    // Step - 1: Setting and logging tracking ID's
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating the request
    CreateVirtualAccountV1Request createVirtualAccountV1Request =
        new CreateVirtualAccountV1Request();

    // Step - 3: calling the API
    Response<ServiceResponse> createVirtualAccountV1ApiResponse =
        accountEntityServiceRetrofit.createVirtualAccountV1(
            createVirtualAccountV1Request, onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, createVirtualAccountV1ApiResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    Assert.assertEquals(createVirtualAccountV1ApiResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
  }

  @Test(priority = 3, description = "Invalid Address fields test")
  public void createVirtualAccountV1InvalidAddress() throws IOException {
    // Step - 1: Setting and logging tracking ID's
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    String onlineAccountId = CommonUtil.randomUUID();
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating the List of requests for different conditions
    List<CreateVirtualAccountV1Request> createVirtualAccountV1RequestList = new ArrayList<>();

    CreateVirtualAccountV1Request createVirtualAccountV1Request =
        getCreateVirtualAccountV1Request();
    // as of 20/11/2023 the limit of characters in addressLine is 35
    char[] addressLine = new char[36];
    Arrays.fill(addressLine, 'a');
    createVirtualAccountV1Request
        .getCustomerInfo()
        .getAddress()
        .setAddressLine1(new String(addressLine));
    createVirtualAccountV1RequestList.add(createVirtualAccountV1Request);

    createVirtualAccountV1Request = getCreateVirtualAccountV1Request();
    // as of 20/11/2023, the limit of characters in city is 25
    char[] city = new char[26];
    Arrays.fill(city, 'a');
    createVirtualAccountV1Request.getCustomerInfo().getAddress().setCity(new String(city));
    createVirtualAccountV1RequestList.add(createVirtualAccountV1Request);

    createVirtualAccountV1Request = getCreateVirtualAccountV1Request();
    // as of 20/11/2023, the limit of characters in state is 2
    createVirtualAccountV1Request.getCustomerInfo().getAddress().setState("ABC");
    createVirtualAccountV1RequestList.add(createVirtualAccountV1Request);

    createVirtualAccountV1Request = getCreateVirtualAccountV1Request();
    // as of 20/11/2023, the limit of characters in country is 2
    createVirtualAccountV1Request.getCustomerInfo().getAddress().setCountry("ABC");
    createVirtualAccountV1RequestList.add(createVirtualAccountV1Request);

    for (CreateVirtualAccountV1Request request : createVirtualAccountV1RequestList) {
      // Step - 3: calling the API
      Response<ServiceResponse> createVirtualAccountV1ApiResponse =
          accountEntityServiceRetrofit.createVirtualAccountV1(
              request, onlineAccountId, domainId, reqId, reqTrackingId);

      // Step - 4: Parsing errorResponse from the errorBody of received response
      Error errorResponse =
          CommonUtil.getEntityServiceErrorResponse(gson, createVirtualAccountV1ApiResponse);

      // Step - 5: Generating errorMessage in case the Assert for response fails
      String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

      Assert.assertEquals(createVirtualAccountV1ApiResponse.code(), 400, errorMessage);
      Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-6002");
    }
  }

  private CreateVirtualAccountV1Request getCreateVirtualAccountV1Request() {
    CreateVirtualAccountV1Request createVirtualAccountV1Request =
        new CreateVirtualAccountV1Request();
    CreateVirtualAccountV1RequestCustomerInfo customerInfo =
        new CreateVirtualAccountV1RequestCustomerInfo();
    CreateVirtualAccountV1RequestCustomerInfoAddress address =
        new CreateVirtualAccountV1RequestCustomerInfoAddress();

    address.setAddressLine1("3576 AIRPORT WAY");
    address.setZipCode("99709");
    address.setCity("FAIRBANKS");
    address.setState("AK");
    address.setCountry("US");

    customerInfo.setFirstName(RandomStringUtils.randomAlphabetic(5));
    customerInfo.setLastName(RandomStringUtils.randomAlphabetic(5));
    customerInfo.setDob("10101970");
    customerInfo.setPhoneNumber(CommonUtil.generateRandomNumber(10));
    customerInfo.setGender("M");
    customerInfo.setType("ADULT");
    customerInfo.setTAndCPolicyLanguage("EN");
    customerInfo.setAddress(address);

    createVirtualAccountV1Request.setCustomerInfo(customerInfo);
    createVirtualAccountV1Request.setAccountCreationSource(accountCreationSource);

    return createVirtualAccountV1Request;
  }
}
