package accountentity.customer;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.response.onlineIdentityResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.wrapper.getOnlineIdentityWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class getOnlineIdentityTests {
    getOnlineIdentityWrapper onlineWrapper = new getOnlineIdentityWrapper();


    @Test(
            priority = 1, description = "Get information for online Identities",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap"
    )
    @DataProviderArguments(filePath = "testdata/RxpdData/RxPDDP/FAMTestData.xlsx", sheetName = "onlineIdentity")
    public void onlineIdentity(Map<String, String> inputData){
        String accountId = nullStringValidation(inputData.get("accountId"));
        String status = nullStringValidation(inputData.get("status"));
        String authStoreNbr = nullStringValidation(inputData.get("authStoreNbr"));
        String authPatientId = nullStringValidation(inputData.get("authPatientId"));
        String cprProfile = nullStringValidation(inputData.get("cprProfile"));
        String onlineCustId = nullStringValidation(inputData.get("onlineCustId"));
        String onlineStoreNbr = nullStringValidation(inputData.get("onlineStoreNbr"));
        String accountCreation = nullStringValidation(inputData.get("accountCreation"));

        ServiceResponse getIdentity = onlineWrapper.onlineIdentityFunction(accountId);
        if (getIdentity.getStatusCode() == 200) {

            onlineIdentityResponse onlineIdentity = getIdentity.getDataResponse(onlineIdentityResponse.class);
            Assert.assertEquals(getIdentity.getStatusCode(), Integer.parseInt(status));
            Assert.assertEquals(onlineIdentity.getAuthStoreNbr(), authStoreNbr);
            Assert.assertEquals(onlineIdentity.getAuthPatientId(), authPatientId);
            Assert.assertEquals(onlineIdentity.getCprDigitalProfileSync(), cprProfile);
            Assert.assertEquals(onlineIdentity.getOnlineCustId(), onlineCustId);
            Assert.assertEquals(onlineIdentity.getOnlineStoreNbr(), onlineStoreNbr);
            Assert.assertEquals(onlineIdentity.getAccountCreationSource(), accountCreation);
        }else{
            Assert.assertEquals(getIdentity.getStatusCode(), Integer.parseInt(status));
        }

    }

    public String nullStringValidation(String inputData){
        String val = inputData;
        if((inputData.equals("null"))) {
            val = null;
        }
        return val;
    }
}
