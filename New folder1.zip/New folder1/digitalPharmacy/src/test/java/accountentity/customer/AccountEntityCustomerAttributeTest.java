package accountentity.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.GetCustomerAttributesV1Response;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpdateCustomerAttributesV1Request;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.UpdateCustomerAttributesV1Response;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class AccountEntityCustomerAttributeTest {
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
  private ObjectMapper mapper = new ObjectMapper();
  private Gson gson = new GsonBuilder().create();
  private String NOTIFICATION = "NOTIFICATION";
  private String ACCOUNT = "ACCOUNT";
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String commonOnlineAccountId = null;
  private String onlineAccountId = CommonUtil.randomUUID();

  @BeforeClass
  void setContext() {
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
  }

  @Test(
      priority = 0,
      description = "UpdateCustomerAttributesV1 success for notification preferences",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesNotificationPreferencesV1Success(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            NOTIFICATION);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to the UpdateCustomerAttributesV1Response class so that we can
    // assert class responses
    UpdateCustomerAttributesV1Response updateCustomerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateCustomerAttributesV1APIResponse.body().getPayload()),
            UpdateCustomerAttributesV1Response.class);

    Assert.assertEquals(
        updateCustomerAttributesV1Response.getOnlineAccountId(), onlineAccountId);
  }

  @Test(
      priority = 1,
      description =
          "Get customer attributes success for notification preferences, output is based on priority = 0 test",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesNotificationPreferencesV1Success(
      String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("IS_EXPIRY", "IS_LATE_PICKUP");
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and attribute
    // list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, domainId, attribute, reqId, reqTrackingId, NOTIFICATION);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getCustomerAttributesV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 200, errorMessage);

    // Step - 5: Converting all the elements of the attribute list to lowercase to assert the
    // response
    attribute.replaceAll(String::toLowerCase);

    // Step - 6: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert attributeName
    GetCustomerAttributesV1Response customerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerAttributesV1Response.body().getPayload()),
            GetCustomerAttributesV1Response.class);

    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(0).getName(), attribute.get(0));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(0).getValue(), "false");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(1).getName(), attribute.get(1));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(1).getValue(), "false");
  }

  @Test(
      priority = 2,
      description = "UpdateCustomerAttributesV1 success for manage insurance nudge preferences",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesManageInsuranceNudgePreferencesV1Success(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to the UpdateCustomerAttributesV1Response class so that we can
    // assert class responses
    UpdateCustomerAttributesV1Response updateCustomerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateCustomerAttributesV1APIResponse.body().getPayload()),
            UpdateCustomerAttributesV1Response.class);

    Assert.assertEquals(
        updateCustomerAttributesV1Response.getOnlineAccountId(), onlineAccountId);
  }

  @Test(
      priority = 3,
      description =
          "Get customer attributes success for the manage insurance card nudge preferences, output is based on priority = 2 test",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesManageInsuranceNudgePreferencesV1Success(
      String domainId) throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("MANAGE_INSURANCE_CARD_NUDGE", "ADD_INSURANCE_CARD_NUDGE");
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and attribute
    // list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, domainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getCustomerAttributesV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 200, errorMessage);

    // Step - 5: Converting all the elements of the attribute list to lowercase to assert the
    // response
    attribute.replaceAll(String::toLowerCase);

    // Step - 6: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert attributeName
    GetCustomerAttributesV1Response customerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerAttributesV1Response.body().getPayload()),
            GetCustomerAttributesV1Response.class);

    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(0).getName(), attribute.get(0));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(0).getValue(), "false");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(1).getName(), attribute.get(1));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(1).getValue(), null);
  }

  @Test(
      priority = 4,
      description = "UpdateCustomerAttributesV1 success for add insurance card nudge preferences",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesAddInsuranceNudgePreferencesV1Success(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;

    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 200, errorMessage);

    // Step - 6: Parsing the response to the UpdateCustomerAttributesV1Response class so that we can
    // assert class responses
    UpdateCustomerAttributesV1Response updateCustomerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>)
                updateCustomerAttributesV1APIResponse.body().getPayload()),
            UpdateCustomerAttributesV1Response.class);

    Assert.assertEquals(
        updateCustomerAttributesV1Response.getOnlineAccountId(), onlineAccountId);
  }

  @Test(
      priority = 5,
      description =
          "Get customer attributes success for add insurance card preferences, output is based on priority = 4",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesAddInsuranceNudgePreferencesV1Success(
      String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("MANAGE_INSURANCE_CARD_NUDGE", "ADD_INSURANCE_CARD_NUDGE");
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and attribute
    // list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, domainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Building errorMessage in case the Assert for response fails
    String errorMessage =
        CommonUtil.buildEntityServiceErrorMessage(gson, getCustomerAttributesV1Response);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 200, errorMessage);

    // Step - 5: Converting all the elements of the attribute list to lowercase to assert the
    // response
    attribute.replaceAll(String::toLowerCase);

    // Step - 6: Parsing the response to the GetCustomerAttributesV1Response class so that we can
    // assert attributeName
    GetCustomerAttributesV1Response customerAttributesV1Response =
        ResponseUtil.parseResponse(
            gson,
            ((LinkedTreeMap<String, Object>) getCustomerAttributesV1Response.body().getPayload()),
            GetCustomerAttributesV1Response.class);

    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(0).getName(), attribute.get(0));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(0).getValue(), "false");
    Assert.assertEquals(
        customerAttributesV1Response.getAttributes().get(1).getName(), attribute.get(1));
    Assert.assertEquals(customerAttributesV1Response.getAttributes().get(1).getValue(), "false");
  }

  @Test(
      priority = 6,
      description = "Get customer attributes invalid request case due to invalid domainId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesAddInsuranceNudgePreferencesV1InvalidDomainId(
      String onlineAccountId, String invalidDomainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute =
        Arrays.asList("ID_VERIFIED", "two_fa_setup_status", "LAST_VERIFICATION_SOURCE");
    CommonUtil.logFlowIdentifiers(onlineAccountId, invalidDomainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, invalid domainId and
    // attribute list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, invalidDomainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id is not valid");

    // *****  CASE 2 - DomainId is in lowercase *****
    String invalidDomainType = "wm-pharmacy";
    CommonUtil.logFlowIdentifiers(onlineAccountId, invalidDomainType, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with a onlineAccountId, invalid domainId and
    // attribute list
    getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, invalidDomainId, attribute, reqId, reqTrackingId, ACCOUNT);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 5: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id is not valid");
  }

  @Test(
      priority = 7,
      description = "Get customer attributes invalid request case due to invalid attribute list",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "getCustomerAttributesV1")
  public void getCustomerAttributesNotificationPreferencesV1InvalidAttribute(
      String onlineAccountId, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    List<String> attribute = Arrays.asList("IS_EXPIRY", "IS_LATE_PICK");
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: Calling getCustomerAttributesV1 with an onlineAccountId, domainId and
    // invalid attribute list
    Response<ServiceResponse> getCustomerAttributesV1Response =
        accountEntityServiceRetrofit.getCustomerAttributesV1(
            onlineAccountId, domainId, attribute, reqId, reqTrackingId, NOTIFICATION);

    // Step - 3: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, getCustomerAttributesV1Response);

    // Step - 4: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 4: Asserting response
    Assert.assertEquals(getCustomerAttributesV1Response.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Name is not valid");
  }

  @Test(
      priority = 8,
      description = "UpdateCustomerAttributesV1 invalid request case due to invalid domainId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesNotificationPreferencesV1InvalidDomainId(
      String payload, String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            NOTIFICATION);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Domain Id cannot be empty/null");
  }

  @Test(
      priority = 9,
      description = "UpdateCustomerAttributesV1 invalid request case due to invalid domainId for manage insurance card nudge",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesManageInsuranceNudgePreferencesV1InvalidRequest
      (String domainId) throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);

    // CASE - 1: Attribute list is empty in the payload

    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        new UpdateCustomerAttributesV1Request();

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attributes List cannot be empty");
  }
  @Test(
      priority = 10,
      description = "UpdateCustomerAttributesV1 invalid attribute name for manage insurance",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesManageInsuranceNudgePreferencesV1InvalidAttributeName(
      String payload, String domainId) throws IOException {
    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);
    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        new UpdateCustomerAttributesV1Request();
    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service
    updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setName("MANAGE_INSURANCE_CARD_N");

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Name is not valid");

  }

  @Test(
      priority = 11,
      description = "UpdateCustomerAttributesV1 Attribute value is null for Add insurance",
      dataProviderClass = DataProvider.class,
      dataProvider = "getDataByEnv")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/accountentity/accountEntityServiceCustomerData.xlsx",
      sheetName = "updateCustomerAttributesV1")
  public void updateCustomerAttributesAddInsuranceNudgePreferencesV1NullAttributeValue(
      String payload, String domainId) throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    CommonUtil.logFlowIdentifiers(onlineAccountId, domainId, reqId, reqTrackingId);
    // Step - 2: creating UpdateCustomerAttributesV1Request to call updateCustomerAttributesV1 API
    // of entity service and Attribute name is null in the Attribute list
    UpdateCustomerAttributesV1Request updateCustomerAttributesV1Request =
        mapper.readValue(payload, UpdateCustomerAttributesV1Request.class);
    updateCustomerAttributesV1Request.getAttributes().get(0).setValue("TRU");

    // Step - 3: Calling updateCustomerAttributesV1 of the entity service with required fields
    Response<ServiceResponse> updateCustomerAttributesV1APIResponse =
        accountEntityServiceRetrofit.updateCustomerAttributesV1(
            updateCustomerAttributesV1Request,
            onlineAccountId,
            domainId,
            reqId,
            reqTrackingId,
            ACCOUNT);

    // Step - 4: Parsing errorResponse from the errorBody of received response
    Error errorResponse =
        CommonUtil.getEntityServiceErrorResponse(gson, updateCustomerAttributesV1APIResponse);

    // Step - 5: Generating errorMessage in case the Assert for response fails
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);

    // Step - 6: Asserting response
    Assert.assertEquals(updateCustomerAttributesV1APIResponse.code(), 400, errorMessage);
    Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
    Assert.assertNotNull(
        errorResponse.getMessage(), "Invalid input request. Attribute Value is not valid");
  }
}
