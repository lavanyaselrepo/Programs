package accountentity.accountverification;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpsertAccountVerificationV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountVerificationHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import static org.junit.jupiter.api.Assertions.*;

public class GetAccountVerificationV1Test {
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String invalidDomainId = "WM-PHARMACY-INVALID";
    private Gson gson;
    private String customerAccountId;
    private AccountVerificationHelper accountVerificationHelper;

    @BeforeClass
    void setContext() {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        gson = new Gson();
        customerAccountId = CommonUtil.randomUUID();
        accountVerificationHelper = new AccountVerificationHelper();
    }

    @Test(priority = 0, description = "invalid DomainId for getAccountVerificationV1")
    public void invalidDomainIdForGetIsacIdVerificationV1Error() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, invalidDomainId, reqId, reqTrackingId);

        // Calling Get Account Verification
        Response<ServiceResponse> getAccountVerificationV1Response =
            accountEntityServiceRetrofit.getAccountVerificationV1(
                customerAccountId, invalidDomainId, reqId, reqTrackingId, true);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. only [WM-PHARMACY, SAMS-PHARMACY] are permitted as domainId", errorResponse.getMessage()); }

    @Test(priority = 2, description = "getAccountVerificationV1 No Content Found Scenario with data = true")
    public void getAccountVerificationV1NoContentFoundScenarioIfDataIsTrue() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers("86a9126d-69ad-4907-a2de-adbea3e0db9", domainId, reqId, reqTrackingId);

        // Calling Get Account Verification
        Response<ServiceResponse> getAccountVerificationV1ServiceResponse =
            accountEntityServiceRetrofit.getAccountVerificationV1(
                "86a9126d-69ad-4907-a2de-adbea3e0db9", domainId, reqId, reqTrackingId, true);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1ServiceResponse);

        // Asserting response
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
        Assert.assertEquals(getAccountVerificationV1ServiceResponse.code(), 204, errorMessage);
    }

    @Test(priority = 3, description = "getAccountVerificationV1 No Content Found Scenario with data = false")
    public void getAccountVerificationV1NoContentFoundScenarioIfDataIsFalse() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers("86a9126d-69ad-4907-a2de-adbea3e0db9", domainId, reqId, reqTrackingId);

        // Calling Get Account Verification
        Response<ServiceResponse> getAccountVerificationV1ServiceResponse =
            accountEntityServiceRetrofit.getAccountVerificationV1(
                "86a9126d-69ad-4907-a2de-adbea3e0db9", domainId, reqId, reqTrackingId, false);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1ServiceResponse);

        // Asserting response
        String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
        Assert.assertEquals(getAccountVerificationV1ServiceResponse.code(), 204, errorMessage);
    }

    @Test(priority = 4, description = "getAccountVerificationV1 success response with data = false")
    public void getAccountVerificationIfDataIsFalseSuccess() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // insert customer verification
        // Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
            accountVerificationHelper.buildInsertAccountVerificationV1Request();

        //Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
            accountEntityServiceRetrofit.upsertAccountVerificationV1(
                customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, "INSERT");


        // Calling Get Account Verification
        Response<ServiceResponse> getAccountVerificationV1ServiceResponse =
            accountEntityServiceRetrofit.getAccountVerificationV1(
                customerAccountId, domainId, reqId, reqTrackingId, false);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1ServiceResponse);

        // Asserting response
        Assert.assertNotNull(getAccountVerificationV1ServiceResponse.body());
        LinkedTreeMap<String, Object> payload = (LinkedTreeMap<String, Object>) getAccountVerificationV1ServiceResponse.body().getPayload();
        LinkedTreeMap<String, Object> idVerifiedPayload = (LinkedTreeMap<String, Object>) payload.get("idVerified");
        LinkedTreeMap<String, Object> twoFASetUpPayload = (LinkedTreeMap<String, Object>) payload.get("twoFASetUp");

        assertNotNull(getAccountVerificationV1ServiceResponse);
        assertNotNull(idVerifiedPayload);
        assertNotNull(idVerifiedPayload);
        assertEquals("EXPERIAN", idVerifiedPayload.get("verificationSource"));
        assertEquals("ACTIVE", twoFASetUpPayload.get("status"));
        assertNull(idVerifiedPayload.get("data"));
        assertNull(twoFASetUpPayload.get("data"));
    }

    @Test(priority = 5, description = "getAccountVerificationV1 success response with data = true")
    public void getAccountVerificationIfDataIsTrueSuccess() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerAccountId, domainId, reqId, reqTrackingId);

        // generate account id

        // Calling Get Account Verification
        Response<ServiceResponse> getAccountVerificationV1ServiceResponse =
            accountEntityServiceRetrofit.getAccountVerificationV1(
                customerAccountId, domainId, reqId, reqTrackingId, true);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, getAccountVerificationV1ServiceResponse);

        // Asserting response
        Assert.assertNotNull(getAccountVerificationV1ServiceResponse.body());
        LinkedTreeMap<String, Object> payload = (LinkedTreeMap<String, Object>) getAccountVerificationV1ServiceResponse.body().getPayload();
        LinkedTreeMap<String, Object> idVerifiedPayload = (LinkedTreeMap<String, Object>) payload.get("idVerified");
        LinkedTreeMap<String, Object> twoFASetUpPayload = (LinkedTreeMap<String, Object>) payload.get("twoFASetUp");


        assertNotNull(getAccountVerificationV1ServiceResponse);
        assertNotNull(idVerifiedPayload);
        assertNotNull(idVerifiedPayload);
        assertEquals("EXPERIAN", idVerifiedPayload.get("verificationSource"));
        assertEquals("ACTIVE", twoFASetUpPayload.get("status"));
        assertNotNull(idVerifiedPayload.get("data"));
        assertNotNull(twoFASetUpPayload.get("data"));
    }

    private static void logFlowIdentifiers(
        String onlineAccountId, String domainId, String reqId, String reqTrackingId) {
        Reporter.logJSON("onlineAccountId", onlineAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }
}
