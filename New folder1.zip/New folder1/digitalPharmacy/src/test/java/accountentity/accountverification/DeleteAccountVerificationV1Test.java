package accountentity.accountverification;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpsertAccountVerificationV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountVerificationHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CACreatePersonRequestByCustomerType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CACreatePersonByCustomerTypeResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class DeleteAccountVerificationV1Test {
    private CARetrofit caRetrofit;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private AccountVerificationHelper accountVerificationHelper;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String invalidDomainId = "WM-PHARMACY-INVALID";
    private Gson gson;
    private String accountType = "INDIVIDUAL";
    private String customerType = "INDIVIDUAL";
    private String customerOnlineAccountIdWithNoCustomerVerification = null;

    private String customerOnlineAccountId = null;
    private String adult1EmailId = null;
    private String insertOperationType = "INSERT";

    @BeforeClass
    void setContext() throws IOException {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        caRetrofit = new CARetrofit();
        accountVerificationHelper = new AccountVerificationHelper();
        customerOnlineAccountIdWithNoCustomerVerification = CommonUtil.randomUUID();

        adult1EmailId = CommonUtil.generateRandomEmailId(10);
        customerOnlineAccountId = caCreatePerson(adult1EmailId);

        gson = new Gson();
    }

    /**
     * Create CA account for dependent using email id and customerType
     *
     * @throws IOException
     */
    public String caCreatePerson(String customerEmailId) throws IOException {
        CACreatePersonRequestByCustomerType caCreatePersonRequest =
                getCACreatePersonRequest(customerEmailId);
        Response<CACreatePersonByCustomerTypeResponse> response = null;

        // This will try to create a person account in CA, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = caRetrofit.createPersonByCustomerType(caCreatePersonRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && response.body().getStatus() != "OK") {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CA person account creation failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
        return response.body().getPayload().getPerson().getCustomerAccountId();
    }

    /**
     * Build ca create person request
     *
     * @return
     */
    private CACreatePersonRequestByCustomerType getCACreatePersonRequest(
            String customerEmailId) {
        List<CACreatePersonRequestByCustomerType.Accounts> accountsList = new ArrayList<>();
        accountsList.add(
                CACreatePersonRequestByCustomerType.Accounts.builder()
                        .accountType(accountType)
                        .emailAddress(customerEmailId)
                        .build());
        return CACreatePersonRequestByCustomerType.builder()
                .payload(
                        CACreatePersonRequestByCustomerType.CreatePersonRequestPayload.builder()
                                .person(
                                        CACreatePersonRequestByCustomerType.Person.builder()
                                                .accounts(accountsList)
                                                .customerType(customerType)
                                                .build())
                                .build())
                .build();
    }

    @Test(priority = 0, description = "invalid DomainId for deleteAccountVerificationV1")
    public void invalidDomainIdForDeleteAccountVerificationV1Error() throws IOException {

        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerOnlineAccountIdWithNoCustomerVerification, invalidDomainId, reqId, reqTrackingId);

        // Calling Delete Account Verification
        Response<ServiceResponse> deleteAccountVerificationV1Response =
                accountEntityServiceRetrofit.deleteAccountVerificationV1(
                        customerOnlineAccountIdWithNoCustomerVerification, invalidDomainId, reqId, reqTrackingId);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountVerificationV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals( "DPR-DPACCENSR-1001", errorResponse.getCode());
        Assert.assertEquals(
                "Invalid input request. only [WM-PHARMACY, SAMS-PHARMACY] are permitted as domainId", errorResponse.getMessage()); }

    @Test(priority = 1, description = "customerVerification is already deleted for onlineAccountId for deleteAccountVerificationV1")
    public void customerVerificationIsAlreadyDeletedForOnlineAccountIdError() throws IOException {
        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerOnlineAccountIdWithNoCustomerVerification, domainId, reqId, reqTrackingId);

        // Calling Delete Account Verification
        Response<ServiceResponse> deleteAccountVerificationV1Response =
                accountEntityServiceRetrofit.deleteAccountVerificationV1(
                        customerOnlineAccountIdWithNoCustomerVerification, domainId, reqId, reqTrackingId);

        // Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, deleteAccountVerificationV1Response);
        Assert.assertNotNull(errorResponse);
        Assert.assertEquals(deleteAccountVerificationV1Response.code(), 410);
        Assert.assertEquals( "DPR-DPACCENSR-1039", errorResponse.getCode());
        Assert.assertEquals(
                String.format("Account Verification is already deleted for given onlineAccountId: %s", customerOnlineAccountIdWithNoCustomerVerification), errorResponse.getMessage());
    }

    @Test(priority = 2, description = "Delete account verification success")
    public void deleteAccountVerificationSuccess() throws IOException {
        // Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logFlowIdentifiers(customerOnlineAccountId, domainId, reqId, reqTrackingId);

        // Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                accountVerificationHelper.buildInsertAccountVerificationV1Request();

        //Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerOnlineAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Calling Delete Account Verification
        Response<ServiceResponse> deleteAccountVerificationV1Response =
                accountEntityServiceRetrofit.deleteAccountVerificationV1(
                        customerOnlineAccountId, domainId, reqId, reqTrackingId);

        Assert.assertNotNull(deleteAccountVerificationV1Response.body());
        LinkedTreeMap<String, Object> payload = (LinkedTreeMap<String, Object>) deleteAccountVerificationV1Response.body().getPayload();

        assertNotNull(deleteAccountVerificationV1Response);
        assertNotNull(payload.get("onlineAccountId"));
        assertEquals(payload.get("onlineAccountId"), customerOnlineAccountId);
    }

    private static void logFlowIdentifiers(
            String onlineAccountId, String domainId, String reqId, String reqTrackingId) {
        Reporter.logJSON("onlineAccountId", onlineAccountId);
        Reporter.logJSON("domainId", domainId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
    }
}
