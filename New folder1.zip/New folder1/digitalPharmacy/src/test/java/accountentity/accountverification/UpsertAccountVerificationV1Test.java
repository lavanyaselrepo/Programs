package accountentity.accountverification;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.model.request.UpsertAccountVerificationV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.Error;
import com.walmart.pharmacy.dp.account.entity.service.restclient.model.ServiceResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;
import java.io.IOException;

public class UpsertAccountVerificationV1Test {
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String domainId = "WM-PHARMACY";
    private String insertOperationType = "INSERT";
    private String updateOperationType = "UPDATE";
    private Gson gson;

    @BeforeClass
    void setContext() {
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        gson = new Gson();
    }

    @Test(priority = 0, description = "successful insertion of account verification")
    public void testUpsertAccountVerificationSuccess() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response for insert operation
        Assert.assertEquals(200, insertAccountVerificationV1Response.code());

        // Step 5: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request updateAccountVerificationV1Request =
                buildUpdateAccountVerificationV1Request();

        // Step 6: Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> upsertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, updateAccountVerificationV1Request, reqId, reqTrackingId, updateOperationType);

        // Step 7: Asserting response for update operation
        Assert.assertEquals(200, upsertAccountVerificationV1Response.code());
    }

    @Test(priority = 1, description = "Invalid Operation Type for account verification")
    public void testInvalidOperationTypeForAccountVerificationError() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, "Invalid Type");

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. Invalid Account Verification Operation Type provided. Allowed operation types are INSERT/UPDATE"));
    }

    @Test(priority = 2, description = "Invalid Id Verified for update account verification")
    public void testIdVerifiedIsNullForUpdateForAccountVerificationError() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, updateOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. IdVerified should be null for update Account Verification Operation"));
    }

    @Test(priority = 3, description = "CustomerInfo Is Not Null For Id Verified for Insert account verification")
    public void testCustomerInfoIsNotNullForIdVerifiedForSourceExperianForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().getData().setCustomerInfo(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. CustomerInfo cannot be null/empty if verification Source is Experian"));
    }

    @Test(priority = 4, description = "PhotoId Is Not Null For Id Verified for Insert account verification")
    public void testPhotoIdIsNotNullForIdVerifiedForSourceStoreForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setVerificationSource("RX_STORE");
        insertAccountVerificationV1Request.getIdVerified().getData().setPhotoId(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. PhotoId cannot be null/empty if verification Source is RX_STORE"));
    }

    @Test(priority = 5, description = "CustomerInfo Is Not Null For Id Verified Source Experian for Insert account verification")
    public void testCustomerInfoIsNotNullForTwoFASetUpForSourceExperianForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getTwoFASetUp().getData().setCustomerInfo(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. CustomerInfo cannot be null/empty if verification Source is Experian"));
    }

    @Test(priority = 6, description = "PhotoId Is Not Null For TwoFASetUp Source Store for Insert account verification")
    public void testPhotoIdIsNotNullForTwoFASetUpForSourceStoreForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setVerificationSource("RX_STORE");
        insertAccountVerificationV1Request.getTwoFASetUp().getData().setPhotoId(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. PhotoId cannot be null/empty if verification Source is RX_STORE"));
    }

    @Test(priority = 7, description = "Status Is Not Null For TwoFASetUp for Update account verification")
    public void testStatusIsNotNullForTwoFASetUpForUpdate() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request updateAccountVerificationV1Request =
                buildUpdateAccountVerificationV1Request();
        updateAccountVerificationV1Request.getTwoFASetUp().setStatus(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, updateAccountVerificationV1Request, reqId, reqTrackingId, updateOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. TwoFASetUp Status should not be null for update Account Verification Operation"));
    }

    @Test(priority = 8, description = "Status Is Not Null For IdVerified for insert account verification")
    public void testStatusIsNotNullForIdVerifiedForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setStatus(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. IdVerified Status cannot be null/empty"));
    }

    @Test(priority = 9, description = "VerificationSource Is Not Null For IdVerified for Insert account verification")
    public void testVerificationSourceIsNotNullForIdVerifiedForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setVerificationSource(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. IdVerified Verification Source cannot be null/empty"));
    }

    @Test(priority = 10, description = "VerificationSource Is valid For TwoFASetUp for Insert account verification")
    public void testVerificationSourceIsValidForIdVerifiedForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setVerificationSource("INVALID_VALUE");

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. Invalid IdVerified Account Verification Source provided. Allowed Sources are EXPERIAN/RX_STORE"));
    }

    @Test(priority = 11, description = "Data Is Not Null For IdVerified for Insert account verification")
    public void testDataIsNotNullForIdVerifiedForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setData(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. IdVerified Data cannot be null/empty"));
    }

    @Test(priority = 12, description = "Status Is valid For TwoFASetUp for Insert account verification")
    public void testStatusIsNotNullForTwoFASetUpForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getTwoFASetUp().setStatus(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. TwoFASetUp Status cannot be null/empty"));
    }

    @Test(priority = 13, description = "Status Is valid For TwoFASetUp for Insert account verification")
    public void testStatusIsInvalidForTwoFASetUpForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getTwoFASetUp().setStatus("Invalid_value");

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. Invalid TwoFASetUp Status provided. Allowed status value is ACTIVE"));
    }

    @Test(priority = 14, description = "Data Is not null For TwoFASetUp for Insert account verification")
    public void testDataIsNotNullForTwoFASetUpForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getTwoFASetUp().setData(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. TwoFASetUp Data cannot be null/empty"));
    }

    @Test(priority = 15, description = "First Name Is not null For customerInfo for Insert account verification")
    public void testFirstNameIsNotNullForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request
                .getIdVerified()
                .getData()
                .getCustomerInfo()
                .setFirstName(null);

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. CustomerInfo FirstName cannot be null/empty"));
    }

    @Test(priority = 16, description = "Dob format validation for Insert account verification")
    public void testDobFormatForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request
                .getIdVerified()
                .getData()
                .getCustomerInfo()
                .setDob("22011990");

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. Dob Date should be in MMddyyyy format"));
    }

    @Test(priority = 17, description = "PhotoId ExpirationDate format validation for Insert account verification")
    public void testPhotoIdExpirationDateFormatForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();

        insertAccountVerificationV1Request
                .getIdVerified()
                .getData()
                .getPhotoId()
                .setExpirationDate("22011990");

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. PhotoId Expiration Date should be in MM-dd-yyyy format"));
    }

    @Test(priority = 18, description = "Invalid IdVerified Account Verification Source provided for Insert account verification")
    public void testInvalidVerificationSourceErrorForIdVerifiedForInsert() throws IOException {

        String customerAccountId = CommonUtil.randomUUID();

        // Step 1: Setting and logging tracking ID's to make the respective calls
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        CommonUtil.logFlowIdentifiers(domainId, reqId, reqTrackingId);

        // Step 2: Building the UpsertAccountVerificationV1Request
        UpsertAccountVerificationV1Request insertAccountVerificationV1Request =
                buildInsertAccountVerificationV1Request();
        insertAccountVerificationV1Request.getIdVerified().setVerificationSource("INVALID VALUE");

        // Step 3: Calling upsertAccountVerificationV1
        Response<ServiceResponse> insertAccountVerificationV1Response =
                accountEntityServiceRetrofit.upsertAccountVerificationV1(
                        customerAccountId, domainId, insertAccountVerificationV1Request, reqId, reqTrackingId, insertOperationType);

        // Step 4: Asserting response
        Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, insertAccountVerificationV1Response);
        Assert.assertEquals(insertAccountVerificationV1Response.code(), 400);
        Assert.assertEquals(errorResponse.getCode(), "DPR-DPACCENSR-1001");
        Assert.assertEquals(
                errorResponse.getMessage(),
                String.format("Invalid input request. Invalid IdVerified Account Verification Source provided. Allowed Sources are EXPERIAN/RX_STORE"));
    }

    private UpsertAccountVerificationV1Request buildInsertAccountVerificationV1Request() {

        UpsertAccountVerificationV1Request.Address address =
            UpsertAccountVerificationV1Request.Address.builder()
                .addressLine1("859 Innovation Lab")
                .city("Bentonville")
                .state("AR")
                .country("US")
                .zipCode("72712")
                .build();

        UpsertAccountVerificationV1Request.CustomerInfo customerInfo =
                UpsertAccountVerificationV1Request.CustomerInfo.builder()
                        .firstName("Will")
                        .lastName("Smith")
                        .dob("01011990")
                        .phoneNumber("1234567890")
                        .address(address)
                        .build();

        UpsertAccountVerificationV1Request.PhotoId photoId =
                UpsertAccountVerificationV1Request.PhotoId.builder()
                        .type("License")
                        .number("123456")
                        .state("AR")
                        .country("US")
                        .expirationDate("06-22-2030")
                        .build();

        UpsertAccountVerificationV1Request.AccountVerificationData accountVerificationData =
                UpsertAccountVerificationV1Request.AccountVerificationData.builder()
                        .customerInfo(customerInfo)
                        .photoId(photoId)
                        .build();

        UpsertAccountVerificationV1Request.IdVerified idVerified =
                UpsertAccountVerificationV1Request.IdVerified.builder()
                        .status(Boolean.TRUE)
                        .verificationSource("EXPERIAN")
                        .data(accountVerificationData)
                        .build();

        UpsertAccountVerificationV1Request.TwoFASetUp twoFASetUp =
                UpsertAccountVerificationV1Request.TwoFASetUp.builder()
                        .status("ACTIVE")
                        .data(accountVerificationData)
                        .build();

        return UpsertAccountVerificationV1Request.builder().idVerified(idVerified).twoFASetUp(twoFASetUp).build();
    }

    private UpsertAccountVerificationV1Request buildUpdateAccountVerificationV1Request() {

        UpsertAccountVerificationV1Request.TwoFASetUp twoFASetUp =
                UpsertAccountVerificationV1Request.TwoFASetUp.builder()
                        .status("INACTIVE")
                        .build();

        return UpsertAccountVerificationV1Request.builder().twoFASetUp(twoFASetUp).build();
    }
}
