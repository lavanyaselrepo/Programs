package storeintegrationsvc.petrx;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.dior.entityservice.restapi.EntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.dior.utils.JDBCConnectionUtils;
import com.walmart.hwqe.commons.serviceapi.dior.utils.ResponseExclusionStrategy;
import com.walmart.hwqe.commons.serviceapi.dior.utils.Utils;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dior.entity.service.restclient.model.OrderDto;
import com.walmart.pharmacy.dior.entity.service.restclient.model.OrderLineDto;
import com.walmart.pharmacy.dior.entity.service.restclient.model.ServiceResponse;
import com.walmart.pharmacy.dior.entity.service.restclient.model.UpdateOrderRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.CancelRxOrderRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.NewOrRefillRxRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.ResponseStatus;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.RxOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.restapi.StoreIntegrationServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

/**
 * Covering all Scenarios related to Refill PetRx Order Creation and Cancellation
 * TODO: Add multiple order line test cases
 *
 */
public class StoreIntegrationPetRxRefillOrderTests {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().setExclusionStrategies(new ResponseExclusionStrategy()).create();
    private StoreIntegrationServiceRetrofit storeIntegrationServiceRetrofit;

    private EntityServiceRetrofit entityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";

    private static final String REFILL_RX = "RefillRx";

    private String omsOrderId = Utils.generateTestOmsOrderId();;
    private String orderPayload = null;
    private String dpOrderId = UUID.randomUUID().toString().replaceAll("-", "");
    private String purchaseOrderId = Utils.generateTestOmsOrderId();

    @BeforeClass
    void setContext() {
        storeIntegrationServiceRetrofit = new StoreIntegrationServiceRetrofit();
        entityServiceRetrofit = new EntityServiceRetrofit(null);
    }

    /**
     * Creating an order in cosmos using entity service, same order id will be used to create and cancel Order in Store
     * @param payload
     * @throws IOException
     */

    @Test(priority = 0, description = "Create an order in cosmos using entity service", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx", sheetName = "refillPetRxOrder")
    public void createOrderInCosmos(String payload) throws IOException {

        // prepare an order to be created in cosmos
        OrderDto orderDto = objectMapper.readValue(payload, OrderDto.class);
        orderPayload = payload;

        // this same orderId will be used across different tests of actions orchestrator
        orderDto.setOmsOrderId(omsOrderId);
        /** generate dpOrderId and set it in payload, same dpOrderId will be used in cancel request,
         hence setting it globally and will use it in cancel request later **/
        orderDto.getOrderLines().get(0).setDpOrderId(dpOrderId);
        orderDto.getOrderLines().get(0).setPurchaseOrderId(purchaseOrderId);

        String trackingId = Utils.generateUUID();
        Utils.logOMSOrderIdAndTrackingId(omsOrderId, trackingId);

        Response<ServiceResponse> createOrderResponse = entityServiceRetrofit
                .createOrder(orderDto, trackingId, trackingId, trackingId);
        Assert.assertEquals(createOrderResponse.code(),200,"entity service create order response: " + ((createOrderResponse.errorBody() != null) ? createOrderResponse.errorBody().string() : ""));

        OrderDto responseOrderDto = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) createOrderResponse.body().getPayload()), OrderDto.class);

        Assert.assertEquals(responseOrderDto.getOrderLines().size(), 1);
    }

    /**
     * Update order state to a particular state in cosmos. For an action to execute in actions orchestrator, it has to be
     * in a particular state, so setting state of the order in cosmos with this method
     * @param orderAction
     * @param status
     * @return
     * @throws IOException
     */
    private boolean updateOrderInCosmos(OrderLineDto.ActionEnum orderAction, OrderLineDto.StatusEnum status) throws IOException {
        // prepare update order request to update the initial order in the exact state needed for any given action to be done
        UpdateOrderRequest updateOrderRequest = objectMapper.readValue(orderPayload, UpdateOrderRequest.class);
        updateOrderRequest.setOmsOrderId(omsOrderId);

        updateOrderRequest.getOrderLines().stream().forEach(orderLineDto -> {
            orderLineDto.setAction(orderAction);
            orderLineDto.setStatus(status);
            orderLineDto.setActionStatus(OrderLineDto.ActionStatusEnum.PENDING);
        });

        String trackingId = Utils.generateUUID();
        Response<ServiceResponse> response =
                entityServiceRetrofit.updateOrder(omsOrderId, updateOrderRequest, "true", trackingId, trackingId, trackingId);

        return response.code() == HttpStatus.OK.value();
    }


    /** This test covers refill PetRx order success case */
    @Test(
            priority = 1,
            description = "Place Refill PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void placeRefillPetRxOrderSuccess(String payload, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);
        request.setOmsOrderId(omsOrderId);
        request.setDpOrderId(dpOrderId);

        // Set PO Line Id and purchaseOrderId for single line order line no and purchase order line no
        request.getRxDetails().getRefillLineInfoList().get(0).setPoLineId(TestUtils.getPoLineId(omsOrderId,1,1));
        request.setPurchaseOrderId(purchaseOrderId);

        // Step - 3 querying the cosmos through entity service for the status
        Response<ServiceResponse> getOrderResponse = entityServiceRetrofit.getOrder(omsOrderId, new ArrayList<>(), "parent-"+requestTrackingId, "req-track-"+requestTrackingId, "req-id-"+requestId);
        Assert.assertEquals(getOrderResponse.code(),200,"entity service get order response: " + ((getOrderResponse.errorBody() != null) ? getOrderResponse.errorBody().string() : ""));

        OrderDto orderResponseModel = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) getOrderResponse.body().getPayload()), OrderDto.class);

        // Step 4-  Update remaining_qty and fill_qty of rx for given patient
        Long rxNbr = orderResponseModel.getOrderLines().get(0).getRefillInfo().getRxNbr();
        Long storePatientId = orderResponseModel.getOrderLines().get(0).getRefillInfo().getStorePatientId();

        //Make connection to informix through JDBC
        // this is under the try_with_resources block so that it could automatically close the connection after the execution
        try (Connection connection = JDBCConnectionUtils.getConnection()) {
            try {
                Statement statement = connection.createStatement();
                // executing SQL query on the DB to get the current values of remaining_qty and fill_qty
                ResultSet rs= statement.executeQuery("select remaining_qty,fill_qty from informix.rx where rx_nbr =" + rxNbr +" and patient_id = "+ storePatientId);
                Double remaining_qty = null;
                Double fill_qty = null;
                while (rs.next()){
                    remaining_qty=rs.getDouble("remaining_qty");
                    fill_qty=rs.getDouble("fill_qty");
                }
                //Update remaining_qty and fill_qty of rx for given patient
                statement.executeUpdate("update rx21c:informix.rx set remaining_qty ="+ (remaining_qty+fill_qty) +" where rx_nbr =" + rxNbr +" and patient_id = "+ storePatientId+";");
            } catch (Exception e) {
                Reporter.logJSON("ERROR","Exception:\n" + e);
            }
        }catch (SQLException sqlException){
            Reporter.logJSON("ERROR",String.format("query execution failed, Exception: %s, Error stackTrace: %s", sqlException, ExceptionUtils.getStackTrace(sqlException)));
        }
        catch (Exception e) {
            Reporter.logJSON("ERROR",String.format("Exception: %s, Error stackTrace: %s ",e, ExceptionUtils.getStackTrace(e)));
        }


        // Step - 5: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder(REFILL_RX, request, requestId, requestTrackingId);

        // Step - 6: Building errorMessage in case to Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 7: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(response.body().getOmsOrderId(), request.getOmsOrderId());
        Assert.assertEquals(response.body().getDpOrderId(), request.getDpOrderId());
        Assert.assertEquals(response.body().getCustomerId(), request.getCustomerId());

        // set order state to SEND_ORDER_TO_STORE and in PENDING state
        updateOrderInCosmos(OrderLineDto.ActionEnum.SEND_REFILL_ORDER_TO_STORE, OrderLineDto.StatusEnum.PO_CREATED);
    }

    /** This test covers Refill PetRx order Bad Request case*/
    @Test(
            priority = 2,
            description = "Try Placing Refill PetRx Order with null dpOrderId in request or unknown orderType",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void placeRefillPetRxOrderBadRequest(String payload, String statusCode)
            throws IOException {

        // *****  CASE 1 - Unknown orderType passed in the request *****
        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);


        // Step - 3: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder("UnknownType", request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case the Assert for response fails
        ResponseStatus error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 5: Building errorMessage in case the Assert for response fails
        String errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(),Integer.valueOf(statusCode));

        // *****  CASE 1 - Empty request passed in the request *****
        // Step - 1: Calling the placePetRxOrder API to get pet prescription information with null Order Type
        request.setDpOrderId(null);
        response =
                storeIntegrationServiceRetrofit.placeRxOrder(REFILL_RX, request, requestId, requestTrackingId);

        // Step - 2: Building errorMessage in case the Assert for response fails
        error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 3: Building errorMessage in case to Assert for response fails
        errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(), Integer.valueOf(statusCode));
    }

    /** This test covers Refill PetRx duplicate order case*/
    @Test(
            priority = 3,
            description = "Place Refill PetRx Duplicate Order",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void placeRefillPetRxDuplicateOrder(String payload, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);
        request.setOmsOrderId(omsOrderId);
        request.setDpOrderId(dpOrderId);

        // Set PO Line Id and purchaseOrderId for single line order line no and purchase order line no
        request.getRxDetails().getRefillLineInfoList().get(0).setPoLineId(TestUtils.getPoLineId(omsOrderId,1,1));
        request.setPurchaseOrderId(purchaseOrderId);


        // Step - 3: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder(REFILL_RX, request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case the Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 5: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    }



    /** This test covers cancel order success case */
    @Test(
            priority = 4,
            description = "Cancel New PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void cancelRefillPetRxOrder(String payload, String statusCode)
            throws IOException {

        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignore) {}

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2 querying the cosmos through entity service for the status
        Response<ServiceResponse> getOrderResponse = entityServiceRetrofit.getOrder(omsOrderId, new ArrayList<>(), "parent-"+requestTrackingId, "req-track-"+requestTrackingId, "req-id-"+requestId);
        Assert.assertEquals(getOrderResponse.code(),200,"entity service get order response: " + ((getOrderResponse.errorBody() != null) ? getOrderResponse.errorBody().string() : ""));

        OrderDto orderResponseModel = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) getOrderResponse.body().getPayload()), OrderDto.class);

        // Step - 3: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting dp order Id and PoLineIdList and requestUniqueId
        OrderLineDto orderLineDto = orderResponseModel.getOrderLines().get(0);
        request.getCancellationDetails().setDpOrderId(dpOrderId);
        request.getCancellationDetails().setPoLineIdList(Collections.singletonList(TestUtils.getPoLineId(omsOrderId,orderLineDto.getOrderLineNo(),orderLineDto.getPurchaseOrderLineNo())));
        request.setRequestUniqueId(Utils.generateTestOmsOrderId());

        // Step - 4: Calling the Cancel PetRx Order API to get pet prescription information
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertNotNull(response.body());
        Assert.assertEquals(response.body().getDpOrderId(),request.getCancellationDetails().getDpOrderId());

    }

    /** This test covers cancel duplicate order case */
    @Test(
            priority = 5,
            description = "Cancel Duplicate Refill PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void cancelRefillPetRxDuplicateOrder(String payload, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2 querying the cosmos through entity service for the status
        Response<ServiceResponse> getOrderResponse = entityServiceRetrofit.getOrder(omsOrderId, new ArrayList<>(), "parent-"+requestTrackingId, "req-track-"+requestTrackingId, "req-id-"+requestId);
        Assert.assertEquals(getOrderResponse.code(),200,"entity service get order response: " + ((getOrderResponse.errorBody() != null) ? getOrderResponse.errorBody().string() : ""));

        OrderDto orderResponseModel = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) getOrderResponse.body().getPayload()), OrderDto.class);

        // Step - 3: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting dp order Id and PoLineIdList and requestUniqueId
        OrderLineDto orderLineDto = orderResponseModel.getOrderLines().get(0);
        request.getCancellationDetails().setDpOrderId(dpOrderId);
        request.getCancellationDetails().setPoLineIdList(Collections.singletonList(TestUtils.getPoLineId(omsOrderId,orderLineDto.getOrderLineNo(),orderLineDto.getPurchaseOrderLineNo())));


        // Step - 4: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);

    }

    /** This test covers cancel order Bad Request case */
    @Test(
            priority = 6,
            description = "Cancel Refill PetRx Order in store with null dpOrderId or poLineIdList",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "refillPetRxOrder")
    public void cancelRefillPetRxOrderBadRequest(String payload, String statusCode)
            throws IOException {

        // *****  CASE 1 - Null DPOrderId passed in the request *****
        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);


        // Step - 2: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting null DPOrderId and unique for RequestUniqueId
        request.getCancellationDetails().setDpOrderId(null);
        request.setRequestUniqueId(Utils.generateTestOmsOrderId());


        // Step - 3: Calling the Cancel PetRx API to get pet prescription information
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case to Assert for response fails
        ResponseStatus error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(),Integer.valueOf(statusCode));

    }

}
