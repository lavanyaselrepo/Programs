package storeintegrationsvc.petrx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.hwqe.commons.serviceapi.dior.entityservice.restapi.EntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.dior.utils.ResponseExclusionStrategy;
import com.walmart.hwqe.commons.serviceapi.dior.utils.Utils;
import com.walmart.pharmacy.dior.entity.service.restclient.model.OrderDto;
import com.walmart.pharmacy.dior.entity.service.restclient.model.OrderLineDto;
import com.walmart.pharmacy.dior.entity.service.restclient.model.UpdateOrderRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.CancelRxOrderRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.NewOrRefillRxRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.ResponseStatus;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.RxOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.restapi.StoreIntegrationServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

/**
 * Covering all Scenarios related to New PetRx Order Creation and Cancellation
 * TODO: Add multiple order line test cases
 */

public class StoreIntegrationPetRxNewOrderTests {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Gson gson = new GsonBuilder().setExclusionStrategies(new ResponseExclusionStrategy()).create();
    private StoreIntegrationServiceRetrofit storeIntegrationServiceRetrofit;

    private EntityServiceRetrofit entityServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";

    private static final String NEW_RX = "NewRx";

    private String omsOrderId = Utils.generateTestOmsOrderId();;
    private String orderPayload = null;
    private String dpOrderId = UUID.randomUUID().toString().replaceAll("-", "");
    private String purchaseOrderId = Utils.generateTestOmsOrderId();

    @BeforeClass
    void setContext() {
        storeIntegrationServiceRetrofit = new StoreIntegrationServiceRetrofit();
        entityServiceRetrofit = new EntityServiceRetrofit(null);
    }

    /**
     * Creating an order in cosmos using entity service, same order id will be used to create and cancel Order in Store
     * @param payload
     * @throws IOException
     */

    @Test(priority = 0, description = "Create an order in cosmos using entity service", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx", sheetName = "newPetRxOrder")
    public void createOrderInCosmos(String payload) throws IOException {

        // prepare an order to be created in cosmos
        OrderDto orderDto = objectMapper.readValue(payload, OrderDto.class);
        orderPayload = payload;

        // this same orderId will be used across different tests of actions orchestrator
        orderDto.setOmsOrderId(omsOrderId);
        /** generate dpOrderId and set it in payload, same dpOrderId will be used in cancel request,
         hence setting it globally and will use it in cancel request later **/
        orderDto.getOrderLines().get(0).setDpOrderId(dpOrderId);
        orderDto.getOrderLines().get(0).setPurchaseOrderId(purchaseOrderId);

        String trackingId = Utils.generateUUID();
        Utils.logOMSOrderIdAndTrackingId(omsOrderId, trackingId);

        Response<com.walmart.pharmacy.dior.entity.service.restclient.model.ServiceResponse> createOrderResponse = entityServiceRetrofit
                .createOrder(orderDto, trackingId, trackingId, trackingId);
        Assert.assertEquals(createOrderResponse.code(),200,"entity service create order response: " + ((createOrderResponse.errorBody() != null) ? createOrderResponse.errorBody().string() : ""));

        OrderDto responseOrderDto = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) createOrderResponse.body().getPayload()), OrderDto.class);

        Assert.assertEquals(responseOrderDto.getOrderLines().size(), 1);
    }

    /**
     * Update order state to a particular state in cosmos. For an action to execute in actions orchestrator, it has to be
     * in a particular state, so setting state of the order in cosmos with this method
     * @param orderAction
     * @param status
     * @return
     * @throws IOException
     */
    private boolean updateOrderInCosmos(OrderLineDto.ActionEnum orderAction, OrderLineDto.StatusEnum status) throws IOException {
        // prepare update order request to update the initial order in the exact state needed for any given action to be done
        UpdateOrderRequest updateOrderRequest = objectMapper.readValue(orderPayload, UpdateOrderRequest.class);
        updateOrderRequest.setOmsOrderId(omsOrderId);

        updateOrderRequest.getOrderLines().stream().forEach(orderLineDto -> {
            orderLineDto.setAction(orderAction);
            orderLineDto.setStatus(status);
            orderLineDto.setActionStatus(OrderLineDto.ActionStatusEnum.PENDING);
        });

        String trackingId = Utils.generateUUID();
        Response<com.walmart.pharmacy.dior.entity.service.restclient.model.ServiceResponse> response =
                entityServiceRetrofit.updateOrder(omsOrderId, updateOrderRequest, "true", trackingId, trackingId, trackingId);

        return response.code() == HttpStatus.OK.value();
    }


    /** This test covers new PetRx order success case */
    @Test(
            priority = 1,
            description = "Place New PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void placeNewPetRxOrderSuccess(String payload, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);
        request.setOmsOrderId(omsOrderId);
        request.setDpOrderId(dpOrderId);

        // Set PO Line Id and purchaseOrderId for single line order line no and purchase order line no
        request.getPatientList().getPatientDetailsList().get(0).getRxInfoList().getLineInfoList().get(0).setPoLineId(TestUtils.getPoLineId(omsOrderId,1,1));
        request.setPurchaseOrderId(purchaseOrderId);


        // Step - 3: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder(NEW_RX, request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case the Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 5: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(response.body().getOmsOrderId(), request.getOmsOrderId());
        Assert.assertEquals(response.body().getDpOrderId(), request.getDpOrderId());
        Assert.assertEquals(response.body().getCustomerId(), request.getCustomerId());

        // set order state to SEND_ORDER_TO_STORE and in PENDING state
        updateOrderInCosmos(OrderLineDto.ActionEnum.SEND_ORDER_TO_STORE, OrderLineDto.StatusEnum.PO_CREATED);
    }

    /** This test covers new PetRx order Bad Request case*/
    @Test(
            priority = 2,
            description = "Try Placing New PetRx Order with null dpOrderId in request or unknown orderType",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void placeNewPetRxOrderBadRequest(String payload, String statusCode)
            throws IOException {

        // *****  CASE 1 - Unknown orderType passed in the request *****
        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);


        // Step - 3: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder("UnknownType", request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case the Assert for response fails
        ResponseStatus error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 5: Building errorMessage in case the Assert for response fails
        String errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(),Integer.valueOf(statusCode));

        // *****  CASE 1 - Empty request passed in the request *****
        // Step - 1: Calling the placePetRxOrder API to get pet prescription information with null Order Type
        request.setDpOrderId(null);
        response =
                storeIntegrationServiceRetrofit.placeRxOrder(NEW_RX, request, requestId, requestTrackingId);

        // Step - 2: Building errorMessage in case the Assert for response fails
        error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 3: Building errorMessage in case to Assert for response fails
        errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(), Integer.valueOf(statusCode));
    }

    /** This test covers new PetRx duplicate order case*/
    @Test(
            priority = 3,
            description = "Place New PetRx Duplicate Order",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void placeNewPetRxDuplicateOrder(String payload, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        NewOrRefillRxRequest request =
                objectMapper.readValue(payload, NewOrRefillRxRequest.class);
        request.setOmsOrderId(omsOrderId);
        request.setDpOrderId(dpOrderId);

        // Set PO Line Id and purchaseOrderId for single line order line no and purchase order line no
        request.getPatientList().getPatientDetailsList().get(0).getRxInfoList().getLineInfoList().get(0).setPoLineId(TestUtils.getPoLineId(omsOrderId,1,1));
        request.setPurchaseOrderId(purchaseOrderId);


        // Step - 3: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.placeRxOrder(NEW_RX, request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case the Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 5: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
    }



    /** This test covers cancel order success case */
    @Test(
            priority = 4,
            description = "Cancel New PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void cancelNewPetRxOrder(String payload, String statusCode)
            throws IOException {

        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignore) {}

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2 querying the cosmos through entity service for the status
        Response<com.walmart.pharmacy.dior.entity.service.restclient.model.ServiceResponse> getOrderResponse = entityServiceRetrofit.getOrder(omsOrderId, new ArrayList<>(), "parent-"+requestTrackingId, "req-track-"+requestTrackingId, "req-id-"+requestId);
        Assert.assertEquals(getOrderResponse.code(),200,"entity service get order response: " + ((getOrderResponse.errorBody() != null) ? getOrderResponse.errorBody().string() : ""));

        OrderDto orderResponseModel = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) getOrderResponse.body().getPayload()), OrderDto.class);

        // Step - 3: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting dp order Id and PoLineIdList and requestUniqueId
        OrderLineDto orderLineDto = orderResponseModel.getOrderLines().get(0);
        request.getCancellationDetails().setDpOrderId(dpOrderId);
        request.getCancellationDetails().setPoLineIdList(Collections.singletonList(TestUtils.getPoLineId(omsOrderId,orderLineDto.getOrderLineNo(),orderLineDto.getPurchaseOrderLineNo())));
        request.setRequestUniqueId(Utils.generateTestOmsOrderId());

        // Step - 4: Calling the Cancel PetRx Order API to get pet prescription information
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertNotNull(response.body());
        Assert.assertEquals(response.body().getDpOrderId(),request.getCancellationDetails().getDpOrderId());

    }

    /** This test covers cancel duplicate order case */
    @Test(
            priority = 5,
            description = "Cancel Duplicate New PetRx Order in store",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void cancelNewPetRxDuplicateOrder(String payload, String statusCode)
            throws IOException {

        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignore) {}

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2 querying the cosmos through entity service for the status
        Response<com.walmart.pharmacy.dior.entity.service.restclient.model.ServiceResponse> getOrderResponse = entityServiceRetrofit.getOrder(omsOrderId, new ArrayList<>(), "parent-"+requestTrackingId, "req-track-"+requestTrackingId, "req-id-"+requestId);
        Assert.assertEquals(getOrderResponse.code(),200,"entity service get order response: " + ((getOrderResponse.errorBody() != null) ? getOrderResponse.errorBody().string() : ""));

        OrderDto orderResponseModel = ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) getOrderResponse.body().getPayload()), OrderDto.class);

        // Step - 3: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting dp order Id and PoLineIdList and requestUniqueId
        OrderLineDto orderLineDto = orderResponseModel.getOrderLines().get(0);
        request.getCancellationDetails().setDpOrderId(dpOrderId);
        request.getCancellationDetails().setPoLineIdList(Collections.singletonList(TestUtils.getPoLineId(omsOrderId,orderLineDto.getOrderLineNo(),orderLineDto.getPurchaseOrderLineNo())));


        // Step - 4: Calling the placePetRxOrder API to send order to store
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage =
                TestUtils.buildErrorMessageFromRxOrderResponse(gson, response);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);

    }

    /** This test covers cancel order Bad Request case */
    @Test(
            priority = 6,
            description = "Cancel New PetRx Order in store with null dpOrderId or poLineIdList",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "newPetRxOrder")
    public void cancelNewPetRxOrderBadRequest(String payload, String statusCode)
            throws IOException {

        // *****  CASE 1 - Null DPOrderId passed in the request *****
        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);


        // Step - 2: Preparing the request payload by mapping the JSON payload
        CancelRxOrderRequest request =
                objectMapper.readValue(payload, CancelRxOrderRequest.class);

        // setting null DPOrderId and unique for RequestUniqueId
        request.getCancellationDetails().setDpOrderId(null);
        request.setRequestUniqueId(Utils.generateTestOmsOrderId());


        // Step - 3: Calling the Cancel PetRx API to get pet prescription information
        Response<RxOrderResponse> response =
                storeIntegrationServiceRetrofit.cancelRxOrder(request, requestId, requestTrackingId);

        // Step - 4: Building errorMessage in case to Assert for response fails
        ResponseStatus error = TestUtils.getRxOrderErrorResponse(gson, response);

        // Step - 5: Building errorMessage in case to Assert for response fails
        String errorMessage = TestUtils.buildCustomErrorMessage(error);

        // Step - 6: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(statusCode), errorMessage);
        Assert.assertEquals(error.getStatusCode(),Integer.valueOf(statusCode));

    }


}
