package storeintegrationsvc.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.EasyRefillOrder;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.RefillOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.restapi.StoreIntegrationServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class StoreIntegrationEasyRefillOrderTests {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private StoreIntegrationServiceRetrofit storeIntegrationServiceRetrofit;
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private String dateTime = TestUtils.getDateTime();

    @BeforeClass
    void setContext() {
        storeIntegrationServiceRetrofit = new StoreIntegrationServiceRetrofit();
    }

    @Test(
            priority = 0,
            description = "EasyRefillOrder - Success",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderSuccess(String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);
        easyRefillOrderRequest.getPickUpInfoInput().setPickUpTime(dateTime);

        // Step - 3: Calling the EasyRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 0,
            description = "EasyRefillOrder Two Refill Order Same Store - Success",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderTwoRefillSameStore(String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);
        easyRefillOrderRequest.getPickUpInfoInput().setPickUpTime(dateTime);

        // Step - 3: Calling the EasyRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 0,
            description = "EasyRefillOrder Two Refill Order Different Store And Different Pick Up Store - Success",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderTwoRefillDifferentStoreAndPickUpStoreDifferent(String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);
        easyRefillOrderRequest.getPickUpInfoInput().setPickUpTime(dateTime);

        // Step - 3: Calling the EasyRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 1,
            description = "EasyRefillOrder - Invalid request - Invalid type",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestInvalidType(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the EasyRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 2,
            description = "EasyRefillOrder - Invalid request - Invalid subType",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestInvalidSubType(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the EasyRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 3,
            description = "EasyRefillOrder - Invalid request - Invalid deliveryMethod",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestInvalidDeliveryMethod(
            String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 4,
            description = "EasyRefillOrder - Invalid request - Missing Patient Input",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMissingPatientInput(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 5,
            description = "EasyRefillOrder - Invalid request - Missing Pick up Info",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMissingPickupInfo(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 6,
            description = "EasyRefillOrder - Invalid request - Missing Pickup Store Nbr",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMissingPickUpStoreNum(
            String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 7,
            description = "EasyRefillOrder - Invalid request - Missing RxNo",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMissingRxNo(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 8,
            description = "EasyRefillOrder - Invalid request - Missing Shipping Info For Delivery Order",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMissingShippingInfoForDeliveryOrder(String payload, String httpCode, String statusCode)
            throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyInRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyInRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    }

    @Test(
            priority = 9,
            description =
                    "EasyRefillOrder - Invalid request - Mismatch Pickup Store Id for Non Transfer Order",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestMismatchStoreIdForNonTransferOrder(
            String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
        Assert.assertNotEquals(
                easyRefillOrderRequest.getPickUpInfoInput().getPickUpStoreNum(),
                easyRefillOrderRequest.getPrescriptionListInput().get(0).getStoreNumber());
    }

    @Test(
            priority = 10,
            description =
                    "EasyRefillOrder - Invalid request - Same Pickup Store Id for STS Order",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData")
    @DataProviderArguments(
            filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
            sheetName = "easyRefillOrder")
    public void easyRefillOrderInvalidRequestSameStoreIdForTransferOrder(
            String payload, String httpCode, String statusCode) throws IOException {

        // Step - 1: Setting and logging tracking IDs to make the respective calls
        String randomUUID = CommonUtil.randomUUID();
        String requestId = reqIdString + randomUUID;
        String requestTrackingId = reqTrackingString + randomUUID;
        CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

        // Step - 2: Preparing the request payload by mapping the JSON payload
        EasyRefillOrder easyRefillOrderRequest =
                objectMapper.readValue(payload, EasyRefillOrder.class);

        // Step - 3: Calling the LoggedInRefillOrder API to place refill order
        Response<RefillOrderResponse> response =
                storeIntegrationServiceRetrofit.placeEasyRefillOrder(
                        easyRefillOrderRequest, requestId, requestTrackingId);

        // Step - 4: Asserting response
        Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
        Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
        Assert.assertEquals(
                easyRefillOrderRequest.getPickUpInfoInput().getPickUpStoreNum(),
                easyRefillOrderRequest.getPrescriptionListInput().get(0).getStoreNumber());
    }

}
