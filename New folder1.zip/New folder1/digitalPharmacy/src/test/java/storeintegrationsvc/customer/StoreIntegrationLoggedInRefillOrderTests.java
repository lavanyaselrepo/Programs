package storeintegrationsvc.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.LoggedInRefillOrder;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.RefillOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.restapi.StoreIntegrationServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.utils.TestUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class StoreIntegrationLoggedInRefillOrderTests {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private StoreIntegrationServiceRetrofit storeIntegrationServiceRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    storeIntegrationServiceRetrofit = new StoreIntegrationServiceRetrofit();
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Success",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderSuccess(String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);
    loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().setDesiredPickupTime(TestUtils.getDateTime());

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder Two Refill Same Store - Success",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderTwoRefillSameStore(String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);
    loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().setDesiredPickupTime(TestUtils.getDateTime());

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder Two Refill Different Store - Success",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderTwoRefillDifferentStore(String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);
    loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().setDesiredPickupTime(TestUtils.getDateTime());

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Invalid requester",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestInvalidRequester(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Invalid type",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestInvalidType(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Invalid subType",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestInvalidSubType(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Invalid deliveryMethod",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestInvalidDeliveryMethod(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Missing type",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestMissingType(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Missing subType",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestMissingSubType(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Missing deliveryMethod",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestMissingDeliveryMethod(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Missing billingInfo",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestMissingBillingInfo(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description = "LoggedInRefillOrder - Invalid request - Missing orderInfo",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestMissingOrderInfo(String payload, String httpCode, String statusCode)
          throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description =
                  "LoggedInRefillOrder - Invalid request - Mismatching siteId and destinationStoreId",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderInvalidRequestSiteIdAndStoreIdMismatch(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
    Assert.assertNotEquals(
            loggedInRefillOrderRequest.getSiteID(),
            loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().getDestinationStoreId());
  }

  @Test(
          priority = 0,
          description =
                  "LoggedInRefillOrder - null SignatureReferenceId and requester is not walmart.com",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderSigRefIdIsNullRequesterIsNotWmStore(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description =
                  "LoggedInRefillOrder - null signatureReferenceId and requester is walmart.com",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderSigRefIdIsNullRequesterIsWmStore(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description =
                  "LoggedInRefillOrder - passing signatureReferenceId and requester is not walmart.com",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderSigRefIdIsPassedRequesterIsNotWmStore(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
          priority = 0,
          description =
                  "LoggedInRefillOrder - passing signatureReferenceId and requester is walmart.com",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderSigRefIdIsPassedRequesterIsWmStore(
          String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
            objectMapper.readValue(payload, LoggedInRefillOrder.class);

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
            storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
                    loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
      priority = 0,
      description = "LoggedInRefillOrder with InsuranceInfo - Success",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
      sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderWithInsuranceInfo(
      String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
        objectMapper.readValue(payload, LoggedInRefillOrder.class);
    loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().setDesiredPickupTime(TestUtils.getDateTime());

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
        storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
            loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }

  @Test(
      priority = 0,
      description = "LoggedInRefillOrder - Invalid request - InsuranceInfo missing planId",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
      sheetName = "loggedInRefillOrder")
  public void loggedInRefillOrderWithInsuranceInfoMissingPlanId(
      String payload, String httpCode, String statusCode) throws IOException {

    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    CommonUtil.logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    LoggedInRefillOrder loggedInRefillOrderRequest =
        objectMapper.readValue(payload, LoggedInRefillOrder.class);
    loggedInRefillOrderRequest.getPharmacyDotCom().getOrderInfo().setDesiredPickupTime(TestUtils.getDateTime());

    // Step - 3: Calling the LoggedInRefillOrder API to place refill order
    Response<RefillOrderResponse> response =
        storeIntegrationServiceRetrofit.placeLoggedInRefillOrder(
            loggedInRefillOrderRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(httpCode));
    Assert.assertEquals(response.body().getStatus().getStatusCode(), Integer.valueOf(statusCode));
  }
}