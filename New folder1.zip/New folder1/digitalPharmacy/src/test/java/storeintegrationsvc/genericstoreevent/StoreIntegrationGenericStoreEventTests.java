package storeintegrationsvc.genericstoreevent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.GenericStoreEventRequest;
import com.walmart.pharmacy.dp.store.integration.service.restclient.model.GenericStoreEventResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.storeintegrationsvc.restapi.StoreIntegrationServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class StoreIntegrationGenericStoreEventTests {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private StoreIntegrationServiceRetrofit storeIntegrationServiceRetrofit;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    storeIntegrationServiceRetrofit = new StoreIntegrationServiceRetrofit();
  }

  @Test(
      priority = 0,
      description = "GenericStoreEvent - Success",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
      sheetName = "genericStoreEvent")
  public void genericStoreEventSuccess(String payload, String statusCode) throws IOException {
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    GenericStoreEventRequest genericStoreEventRequest =
        objectMapper.readValue(payload, GenericStoreEventRequest.class);

    // Step - 3: Calling the GenericStoreEvent API to process the event
    Response<GenericStoreEventResponse> response =
        storeIntegrationServiceRetrofit.genericStoreEvent(
            genericStoreEventRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode));
  }

  @Test(
       priority = 0,
       description = "GenericStoreEvent - Success",
       dataProviderClass = DataProvider.class,
       dataProvider = "getData")
  @DataProviderArguments(
       filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
       sheetName = "genericStoreEvent")
  public void genericStoreEventSuccessWithApiInfo(String payload, String statusCode) throws IOException {
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    GenericStoreEventRequest genericStoreEventRequest =
            objectMapper.readValue(payload, GenericStoreEventRequest.class);

    // Step - 3: Calling the GenericStoreEvent API to process the event
    Response<GenericStoreEventResponse> response =
            storeIntegrationServiceRetrofit.genericStoreEvent(
                    genericStoreEventRequest, requestId, requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), Integer.parseInt(statusCode));
  }

  @Test(
      priority = 0,
      description = "GenericStoreEvent - Failure",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData")
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
      sheetName = "genericStoreEvent")
  public void genericStoreEventFailure(String payload, String statusCode) throws IOException {
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    GenericStoreEventRequest genericStoreEventRequestWithNullStoreRequest =
        objectMapper.readValue(payload, GenericStoreEventRequest.class).request(null);
    GenericStoreEventRequest genericStoreEventRequestWithNullStoreId =
        objectMapper.readValue(payload, GenericStoreEventRequest.class).storeId(null);
    GenericStoreEventRequest genericStoreEventRequestWithNullFlowName =
        objectMapper.readValue(payload, GenericStoreEventRequest.class).flowName(null);
    GenericStoreEventRequest genericStoreEventRequest =
        objectMapper.readValue(payload, GenericStoreEventRequest.class);

    // Step - 3: Calling the GenericStoreEvent API to process the event
    Response<GenericStoreEventResponse> responseForNullStoreRequest =
        storeIntegrationServiceRetrofit.genericStoreEvent(
            genericStoreEventRequestWithNullStoreRequest, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullStoreId =
        storeIntegrationServiceRetrofit.genericStoreEvent(
            genericStoreEventRequestWithNullStoreId, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullFlowName =
        storeIntegrationServiceRetrofit.genericStoreEvent(
            genericStoreEventRequestWithNullFlowName, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullTrackingId =
        storeIntegrationServiceRetrofit.genericStoreEvent(
            genericStoreEventRequest, requestId, null);

    // Step - 4: Asserting response
    Assert.assertEquals(responseForNullStoreRequest.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullStoreId.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullFlowName.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullTrackingId.code(), Integer.parseInt(statusCode));
  }

  @Test(
          priority = 0,
          description = "GenericStoreEvent - Failure",
          dataProviderClass = DataProvider.class,
          dataProvider = "getData")
  @DataProviderArguments(
          filePath = "testdata/digitalpharmacy/storeintegrationsvc/storeIntegrationSvcData.xlsx",
          sheetName = "genericStoreEvent")
  public void genericStoreEventFailureWithApiInfo(String payload, String statusCode) throws IOException {
    // Step - 1: Setting and logging tracking IDs to make the respective calls
    String randomUUID = CommonUtil.randomUUID();
    String requestId = reqIdString + randomUUID;
    String requestTrackingId = reqTrackingString + randomUUID;
    logFlowIdentifiers(requestId, requestTrackingId);

    // Step - 2: Preparing the request payload by mapping the JSON payload
    GenericStoreEventRequest genericStoreEventRequestWithNullStoreRequest =
            objectMapper.readValue(payload, GenericStoreEventRequest.class).request(null);
    GenericStoreEventRequest genericStoreEventRequestWithNullStoreId =
            objectMapper.readValue(payload, GenericStoreEventRequest.class).storeId(null);
    GenericStoreEventRequest genericStoreEventRequestWithNullFlowName =
            objectMapper.readValue(payload, GenericStoreEventRequest.class).flowName(null);
    GenericStoreEventRequest genericStoreEventRequest =
            objectMapper.readValue(payload, GenericStoreEventRequest.class);

    // Step - 3: Calling the GenericStoreEvent API to process the event
    Response<GenericStoreEventResponse> responseForNullStoreRequest =
            storeIntegrationServiceRetrofit.genericStoreEvent(
                    genericStoreEventRequestWithNullStoreRequest, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullStoreId =
            storeIntegrationServiceRetrofit.genericStoreEvent(
                    genericStoreEventRequestWithNullStoreId, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullFlowName =
            storeIntegrationServiceRetrofit.genericStoreEvent(
                    genericStoreEventRequestWithNullFlowName, requestId, requestTrackingId);
    Response<GenericStoreEventResponse> responseForNullTrackingId =
            storeIntegrationServiceRetrofit.genericStoreEvent(
                    genericStoreEventRequest, requestId, null);

    // Step - 4: Asserting response
    Assert.assertEquals(responseForNullStoreRequest.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullStoreId.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullFlowName.code(), Integer.parseInt(statusCode));
    Assert.assertEquals(responseForNullTrackingId.code(), Integer.parseInt(statusCode));
  }

  private void logFlowIdentifiers(String reqId, String reqTrackingId) {
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);
  }
}
