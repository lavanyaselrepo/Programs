package dynamicdatacreation;

import com.google.gson.Gson;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dynamicdatacreationutils.CosmosDocumentConfig;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dynamicdatacreationutils.DynamicDataCreation;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dynamicdatacreationutils.DynamicDataVerification;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dynamicdatacreationutils.PatientRxTestCaseData;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.dynamicdatacreationutils.dataModels.CosmosCreatedTestData;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DynamicTestDataCreationTest {
    private DynamicDataCreation dynamicDataCreation;
    private DynamicDataVerification dynamicDataVerification;
    private String rxDataCreated;
    private int totalTestCasesRequested = 0;

    AutomationManager am = AutomationManager.getInstance();

    String suiteName;

    @BeforeSuite
    public void initDynamicTestDataCreationTest(ITestContext context) {
        dynamicDataCreation = new DynamicDataCreation();
        dynamicDataVerification = new DynamicDataVerification();
        
        // Get job name from looper config (or fallback to determining it)
        String jobName = System.getProperty("jobName");
        
        if (jobName == null || jobName.isEmpty()) {
            // Fallback: Determine from cosmosDocumentId/platform if not passed from looper
            String cosmosDocId = System.getProperty("cosmosDocumentId");
            String platform = System.getProperty("platform");
            jobName = determineJobIdentifier(cosmosDocId, platform);
        }
        
        // Log job name prominently for reports and Slack notifications
        Reporter.log("==========================================================");
        Reporter.log("🚀 JOB: " + jobName);
        Reporter.log("==========================================================");
        System.out.println("==========================================================");
        System.out.println("🚀 JOB EXECUTING: " + jobName);
        System.out.println("==========================================================");
        
        // suiteName is kept for legacy compatibility (still used in some logging)
        // getCreatedTestData() now uses cosmosDocumentId directly
        suiteName = context.getSuite().getName();
        Reporter.log("TestNG suite name: " + suiteName);
    }
    
    /**
     * Determines a user-friendly job identifier for logging and Slack notifications
     */
    private String determineJobIdentifier(String cosmosDocId, String platform) {
        if (cosmosDocId != null && !cosmosDocId.isEmpty()) {
            switch (cosmosDocId.toLowerCase()) {
                case "dp_web_test_data":
                    return "DP Web Regression Test Data Creation";
                case "dp_cnx_regression_test_data":
                    return "DP Connexus Regression Test Data Creation";
                case "golden_suite_latest":
                    return "Golden Suite Test Data Creation";
                case "dm_regression_latest":
                    return "DM Regression Test Data Creation";
                case "dom_regression_test_data":
                    return "DOM Regression Test Data Creation";
                default:
                    return "Test Data Creation (" + cosmosDocId + ")";
            }
        } else if (platform != null && !platform.isEmpty()) {
            return "Test Data Creation (Platform: " + platform + ")";
        } else {
            return "Dynamic Test Data Creation";
        }
    }

    @Test(priority = 1, description = "Create Rx Test Data for Input Json")
    public void createTestData() {
        // Track total test cases requested from input JSON
        String inputJson = System.getProperty("JsonInputForTestDataCreation");
        if (inputJson != null && !inputJson.trim().isEmpty()) {
            try {
                JSONObject jsonObject = new JSONObject(inputJson);
                totalTestCasesRequested = jsonObject.length();
                Reporter.log("Total test cases requested in input JSON: " + totalTestCasesRequested);
            } catch (Exception e) {
                Reporter.log("Could not parse input JSON to count test cases: " + e.getMessage());
            }
        }
        
        rxDataCreated = dynamicDataCreation.createTestData();
        
        // Check if this is a cron job (no input JSON provided)
        boolean isCronJob = (inputJson == null || inputJson.trim().isEmpty());
        
        Reporter.log("==========================================================");
        Reporter.log("POST-CREATION CHECK:");
        Reporter.log("Is Cron Job: " + isCronJob);
        // Initialize finalTestDataJson
        Map<String, PatientRxTestCaseData> finalTestDataJson = new java.util.LinkedHashMap<>();
        
        // Parse created data if available
        if (rxDataCreated != null && rxDataCreated.length() > 2 && !rxDataCreated.trim().equals("{}")) {
            try {
                finalTestDataJson = dynamicDataVerification.getCreatedTestData(rxDataCreated, suiteName);
                Reporter.log("✓ Parsed " + finalTestDataJson.size() + " test cases");
            } catch (Exception e) {
                Reporter.log("✗ ERROR parsing test data: " + e.getMessage());
                e.printStackTrace();
                
                if (!isCronJob) {
                    Assert.fail("Failed to parse created test data: " + e.getMessage());
                } else {
                    Reporter.log("WARNING: Cron job - Failed to parse data, will proceed with existing Cosmos data");
                }
            }
        } else {
            if (isCronJob) {
                Reporter.log("WARNING: Cron job - No new Rx data created, will preserve existing Cosmos data");
            } else {
                Reporter.log("✗ No test data was created successfully");
                Assert.fail("Data Creation Failed - No test cases succeeded, Please Report");
            }
        }
        
        if (finalTestDataJson.isEmpty() && !isCronJob) {
            Reporter.log("✗ No valid test data to save to Cosmos DB");
            Assert.fail("Data Creation Failed - No valid test cases, Please Report");
        } else {
            Reporter.log("No successfully created test cases to process (will preserve existing Cosmos data for cron jobs)");
        }

        for (Map.Entry<String, PatientRxTestCaseData> entry : finalTestDataJson.entrySet()) {
            if (entry.getValue() == null) {
                throw new IllegalArgumentException("Invalid data for test case: " + entry.getKey());
            }

            // Ensure non-null fields in PatientRxTestCaseData
            PatientRxTestCaseData testCaseData = entry.getValue();

            if (testCaseData.getAdultDependents() == null) {
                testCaseData.setAdultDependents(new ArrayList<>());
            }
            if (testCaseData.getPetDependents() == null) {
                testCaseData.setPetDependents(new ArrayList<>());
            }

            if (testCaseData.getMinorDependents() == null) {
                testCaseData.setMinorDependents(new ArrayList<>());
            }

            if (testCaseData.getRxData() == null) {
                testCaseData.setRxData(new PatientRxTestCaseData.RxData());
            }
            if (testCaseData.getRxData().getCreatedRxListRFP() == null) {
                testCaseData.getRxData().setCreatedRxListRFP(new ArrayList<>());
            }
            if (testCaseData.getRxData().getCreatedRxListEOD() == null) {
                testCaseData.getRxData().setCreatedRxListEOD(new ArrayList<>());
            }
            if (testCaseData.getRxData().getCreatedRxListFilling() == null) {
                testCaseData.getRxData().setCreatedRxListFilling(new ArrayList<>());
            }
        }

        // Check if we should skip Cosmos DB push FIRST (useful for dev/QE testing)
        String skipCosmosPush = System.getProperty("skipCosmosPush");
        if (skipCosmosPush != null && skipCosmosPush.equalsIgnoreCase("true")) {
            Reporter.log("==========================================================");
            Reporter.log("SKIPPING COSMOS DB PUSH (skipCosmosPush=true)");
            
            int successfulCount = finalTestDataJson.size();
            int failedCount = totalTestCasesRequested - successfulCount;
            
            // Report detailed status
            Reporter.log("TEST DATA CREATION SUMMARY:");
            Reporter.log("Total test cases requested: " + totalTestCasesRequested);
            Reporter.log("Successfully created: " + successfulCount);
            Reporter.log("Failed to create: " + failedCount);
            
            // Check if any data was actually created successfully
            if (finalTestDataJson.isEmpty()) {
                Reporter.log("❌ RESULT: ALL TEST CASES FAILED");
                Reporter.log("==========================================================");
                System.out.println("❌ Test data creation FAILED - No test cases were created successfully");
                Assert.fail("Test data creation failed - All " + totalTestCasesRequested + " test case(s) failed. Check logs for errors.");
            } else if (successfulCount < totalTestCasesRequested) {
                // Partial success - some passed, some failed
                Reporter.log("⚠️  RESULT: PARTIAL SUCCESS");
                Reporter.log("\n✅ Successfully created test cases:");
                for (String testCaseKey : finalTestDataJson.keySet()) {
                    Reporter.log("  ✅ " + testCaseKey);
                }
                Reporter.log("\n❌ Failed test cases: " + failedCount + " (Check logs above for specific errors)");
                Reporter.log("==========================================================");
                System.out.println("⚠️  Test data creation PARTIAL SUCCESS");
                System.out.println("Created: " + successfulCount + "/" + totalTestCasesRequested + " test cases");
                System.out.println("Failed: " + failedCount + " test cases");
                
                // Decide whether to fail the test or not for partial success
                // For now, we'll report warning but NOT fail (data was created, just not all)
                Reporter.log("WARNING: Not all test cases were created successfully, but proceeding with partial data");
            } else {
                // Complete success
                Reporter.log("✅ RESULT: ALL TEST CASES CREATED SUCCESSFULLY");
                Reporter.log("\nCreated test cases:");
                for (String testCaseKey : finalTestDataJson.keySet()) {
                    Reporter.log("  ✅ " + testCaseKey);
                }
                Reporter.log("==========================================================");
                System.out.println("✅ Test data created successfully (Cosmos DB push skipped)");
                System.out.println("All " + successfulCount + " test cases created successfully");
            }
            
            return; // Exit early, no need to proceed with Cosmos operations
        }

        // Determine container, document ID, and suite name based on the flow type
        String containerName = "regression_test_data";
        
        // Use enum to determine configuration (Priority: cosmosDocumentId > platform > suiteName)
        CosmosDocumentConfig config = CosmosDocumentConfig.determineConfig(suiteName);
        String documentId = config.getDocumentId();
        String suiteNameValue = config.getSuiteName();
        
        Reporter.log("Using Cosmos document configuration: " + config.name() + 
                     " (Document ID: " + documentId + ", Suite: " + suiteNameValue + ")");
        
        // Read existing test data from Cosmos DB for this document ID
        String queryToFetchExistingData = String.format("SELECT * FROM c WHERE c.id = '%s'", documentId);
        Reporter.log("==========================================================");
        Reporter.log("FETCHING EXISTING DATA FROM COSMOS DB");
        Reporter.log("Query: " + queryToFetchExistingData);
        Reporter.log("Container: " + containerName);
        Reporter.log("==========================================================");
        
        CosmosCreatedTestData existingCosmosData = null;
        try {
            existingCosmosData = am.getCosmosContext().executeQuery(
                containerName, queryToFetchExistingData, CosmosCreatedTestData.class);
            
            Reporter.log("✓ Cosmos query executed successfully");
            
            if (existingCosmosData != null) {
                Reporter.log("✓ existingCosmosData object is NOT null");
                Reporter.log("  - Document ID from Cosmos: " + existingCosmosData.getId());
                Reporter.log("  - Suite Name from Cosmos: " + existingCosmosData.getSuiteName());
                
                if (existingCosmosData.getTestCases() != null) {
                    Reporter.log("  - testCases map is NOT null");
                    Reporter.log("  - testCases size: " + existingCosmosData.getTestCases().size());
                } else {
                    Reporter.log("  ✗ WARNING: testCases map is NULL!");
                }
            } else {
                Reporter.log("✗ WARNING: existingCosmosData object is NULL - document not found or query failed");
            }
        } catch (Exception e) {
            Reporter.log("✗ ERROR: Exception during Cosmos query: " + e.getMessage());
            Reporter.log("Exception type: " + e.getClass().getName());
            e.printStackTrace();
        }
        Reporter.log("==========================================================");
        
        CosmosCreatedTestData cosmosCreatedTestData = new CosmosCreatedTestData();
        cosmosCreatedTestData.setId(documentId);
        cosmosCreatedTestData.setSuiteName(suiteNameValue);
        
        // Merge test cases: keep existing ones and update/add from input JSON
        Map<String, PatientRxTestCaseData> mergedTestCases = new java.util.LinkedHashMap<>();
        
        // First, add all existing test cases from Cosmos (if document exists)
        if (existingCosmosData != null && existingCosmosData.getTestCases() != null) {
            Reporter.log("Found existing document in Cosmos with " + existingCosmosData.getTestCases().size() + " test cases");
            mergedTestCases.putAll(existingCosmosData.getTestCases());
        } else {
            if (existingCosmosData == null) {
                Reporter.log("WARNING: Cosmos query returned null - document may not exist");
            } else if (existingCosmosData.getTestCases() == null) {
                Reporter.log("WARNING: Document exists but testCases field is null");
            }
            Reporter.log("No existing document found in Cosmos, creating new document");
        }
        
        // Then, update/add test cases from the input JSON (if any were successfully created)
        if (!finalTestDataJson.isEmpty()) {
            int updatedCount = 0;
            int addedCount = 0;
            
            for (Map.Entry<String, PatientRxTestCaseData> entry : finalTestDataJson.entrySet()) {
                String testCaseKey = entry.getKey();
                PatientRxTestCaseData newTestCaseData = entry.getValue();
                
                if (mergedTestCases.containsKey(testCaseKey)) {
                    updatedCount++;
                } else {
                    addedCount++;
                }
                
                // Update or add the test case
                mergedTestCases.put(testCaseKey, newTestCaseData);
            }
            
            Reporter.log("✓ Merge complete: " + updatedCount + " test cases updated, " + addedCount + " new test cases added");
        } else if (isCronJob) {
            Reporter.log("Cron job - No new data created, preserving existing " + mergedTestCases.size() + " test cases");
        }
        
        // For cron jobs with no successful creations, ensure we still have data to save
        if (mergedTestCases.isEmpty()) {
            Reporter.log("ERROR: No test cases available to save (neither existing nor newly created)");
            Reporter.log("DEBUG INFO:");
            Reporter.log("  - isCronJob: " + isCronJob);
            Reporter.log("  - finalTestDataJson.size(): " + finalTestDataJson.size());
            Reporter.log("  - existingCosmosData was null: " + (existingCosmosData == null));
            Reporter.log("  - Document ID attempted: " + documentId);
            Reporter.log("  - Container: " + containerName);
            
            if (isCronJob) {
                Reporter.log("CRON JOB CRITICAL ERROR: Unable to fetch existing data from Cosmos and no new data was created");
                Reporter.log("This indicates either:");
                Reporter.log("  1. The Cosmos document doesn't exist yet (first run)");
                Reporter.log("  2. Cosmos DB connection/query failed");
                Reporter.log("  3. All data creation attempts failed");
            }
            
            Assert.fail("No test data available to save to Cosmos DB - See detailed debug info above");
        }
        
        cosmosCreatedTestData.setTestCases(mergedTestCases);

        // Serialize and recheck document size after modifications
        String serializedDocument = new Gson().toJson(cosmosCreatedTestData);
        if (serializedDocument.getBytes().length > 2 * 1024 * 1024) {
            throw new IllegalArgumentException("Document size exceeds 2 MB limit.");
        }

        // Upsert the document into Cosmos DB using the determined container
        Reporter.log("==========================================================");
        Reporter.log("ATTEMPTING COSMOS DB SAVE");
        Reporter.log("Container: " + containerName);
        Reporter.log("Document ID: " + documentId);
        Reporter.log("Suite Name: " + suiteNameValue);
        Reporter.log("Total test cases to save: " + mergedTestCases.size());
        Reporter.log("Test cases from input/creation: " + finalTestDataJson.size());
        Reporter.log("Test cases from existing Cosmos: " + (existingCosmosData != null && existingCosmosData.getTestCases() != null ? existingCosmosData.getTestCases().size() : 0));
        Reporter.log("==========================================================");
        
        boolean saveSuccess = false;
        try {
            saveSuccess = am.getCosmosContext().upsertDocument(containerName, cosmosCreatedTestData);
            Reporter.log("Cosmos upsert returned: " + saveSuccess);
        } catch (Exception e) {
            Reporter.log("ERROR: Exception during Cosmos upsert: " + e.getMessage());
            e.printStackTrace();
        }
        
        if (saveSuccess) {
            String jobName = System.getProperty("jobName");
            
            System.out.println("success");
            Reporter.log("✓ Successfully saved " + mergedTestCases.size() + " test cases to Cosmos DB");
            if (jobName != null && !jobName.isEmpty()) {
                Reporter.log("✅ " + jobName + " completed successfully!");
            }
                
            // Analyze and report on test case statuses
            int fullyCreatedCount = 0;
            int partiallyCreatedCount = 0;
            List<String> fullyCreatedCases = new ArrayList<>();
            List<String> partiallyCreatedCases = new ArrayList<>();
            
            for (Map.Entry<String, PatientRxTestCaseData> entry : finalTestDataJson.entrySet()) {
                String testCaseKey = entry.getKey();
                PatientRxTestCaseData data = entry.getValue();
                
                // Check if Rx data was actually created (has prescriptions)
                boolean hasRxData = data.getRxData() != null && (
                    (data.getRxData().getCreatedRxListRFP() != null && !data.getRxData().getCreatedRxListRFP().isEmpty()) ||
                    (data.getRxData().getCreatedRxListEOD() != null && !data.getRxData().getCreatedRxListEOD().isEmpty()) ||
                    (data.getRxData().getCreatedRxListFilling() != null && !data.getRxData().getCreatedRxListFilling().isEmpty())
                );
                
                if (hasRxData) {
                    fullyCreatedCount++;
                    fullyCreatedCases.add(testCaseKey);
                } else {
                    partiallyCreatedCount++;
                    partiallyCreatedCases.add(testCaseKey);
                }
            }
            
            // Report detailed summary
            Reporter.log("==========================================================");
            Reporter.log("Cosmos DB Save Summary:");
            Reporter.log("Total test cases saved: " + mergedTestCases.size());
            Reporter.log("  ✓ Fully created (with Rx data): " + fullyCreatedCount);
            Reporter.log("  ⚠ Partially created (config only): " + partiallyCreatedCount);
            
            if (fullyCreatedCount > 0) {
                Reporter.log("\nFully created test cases:");
                for (String testCaseKey : fullyCreatedCases) {
                    Reporter.log("  ✓ " + testCaseKey);
                }
            }
            
            if (partiallyCreatedCount > 0) {
                Reporter.log("\nPartially created test cases (retry recommended):");
                for (String testCaseKey : partiallyCreatedCases) {
                    Reporter.log("  ⚠ " + testCaseKey + " - Configuration saved, Rx creation failed");
                }
            }
            Reporter.log("==========================================================");
            
        } else {
            String jobName = System.getProperty("jobName");
            
            System.out.println("failed");
            Reporter.log("✗ ERROR: Failed to save test data to Cosmos DB");
            if (jobName != null && !jobName.isEmpty()) {
                Reporter.log("❌ " + jobName + " failed to save to Cosmos!");
            }
            Reporter.log("Cosmos upsertDocument returned false");
            Reporter.log("Please check:");
            Reporter.log("  1. Cosmos DB connection and credentials");
            Reporter.log("  2. Container name and document ID are correct");
            Reporter.log("  3. Document size is within limits (< 2 MB)");
            Reporter.log("  4. Network connectivity to Cosmos DB");
            
            if (isCronJob) {
                Reporter.log("WARNING: Cron job - Cosmos save failed, but data was created in the system");
            } else {
                Assert.fail("Failed to save test data to Cosmos DB - upsertDocument returned false");
            }
        }
    }

   @Test(dependsOnMethods = {"createTestData"}, description = "Verify Created Rx Test Data")
    public void verifyCreatedTestData() throws InterruptedException {
        // Wait 5 Mins before Verifying Data for Syncup of Rx Data From Connexus -> TDC -> Rx Orchestrator
        Thread.sleep(360000);
        Boolean verificationStatus = dynamicDataVerification.verifyCreatedTestData(rxDataCreated);
        Reporter.log("Final Data Verification Status: " + verificationStatus);
        
        // For cron jobs, log verification status but don't fail the build if verification fails
        String inputJson = System.getProperty("JsonInputForTestDataCreation");
        boolean isCronJob = (inputJson == null || inputJson.trim().isEmpty());
        
        if (!verificationStatus && isCronJob) {
            Reporter.log("WARNING: Cron job - Verification failed but data was saved to Cosmos DB");
            Reporter.log("This is expected for cron jobs as they recreate existing data");
            // Don't fail the build for cron jobs - data recreation is the goal
        } else {
            Assert.assertEquals(verificationStatus, true, "Creation or Verification of Test Data Failed");
        }
    }
}
