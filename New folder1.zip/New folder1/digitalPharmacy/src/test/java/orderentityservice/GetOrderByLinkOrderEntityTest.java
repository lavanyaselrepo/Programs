package orderentityservice;

import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.GetOrdersByLinkRequestV2;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.GetOrdersByLinkResponseV2;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.OrderLookupByV2;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.PatientLink;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.IdGeneratorUtils;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;

@Slf4j
public class GetOrderByLinkOrderEntityTest {

  public static final String commonOrderId = "W00230e49525ba44ec796473415nithishs";
  public static final Long commonPatientId = 120238L;
  public static final Integer commonStoreId = 5597;
  private static final String commonBuyerId = "5c5b6897-b853-43d8-8473-aac3f2fb3838";
  private OrderEntityServiceRetrofit orderEntityRetrofit;
  private PropertyReader propertyReader;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  @BeforeClass
  void setContext() {
    propertyReader = PropertyReader.getInstance();
    orderEntityRetrofit = new OrderEntityServiceRetrofit(propertyReader);
  }

  @Test(
          priority = 0,
          description = "Get Order By Link V2")
  public void getOrderByLinkApiV2() throws IOException {

    String trackID = IdGeneratorUtils.generateUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    GetOrdersByLinkRequestV2 getOrdersByLinkRequestV2 = new GetOrdersByLinkRequestV2().orderLookupBy(Arrays.asList(new OrderLookupByV2().orderId(commonOrderId).patientLink(new PatientLink().patientId(commonPatientId).storeId(commonStoreId))));
    Response<GetOrdersByLinkResponseV2> response = orderEntityRetrofit.getOrderByLinkApiV2(getOrdersByLinkRequestV2,reqId,reqTrackingId,null,null,null);
    Assert.assertEquals(response.code(),200);
    assert response.body() != null;
    Assert.assertEquals(commonBuyerId, response.body().getOrders().get(0).getBuyer().getOnlineCustomerId());
    Assert.assertEquals(commonOrderId,response.body().getOrders().get(0).getOrderId());
    Assert.assertEquals(commonStoreId, response.body().getOrders().get(0).getStoreId());
    Assert.assertEquals(commonPatientId,response.body().getOrders().get(0).getPatient().getPatientLinks().get(0).getPatientId());
  }
}
