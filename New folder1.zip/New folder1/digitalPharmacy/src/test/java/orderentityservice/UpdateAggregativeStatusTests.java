package orderentityservice;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.CreateOrderEntityHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.IdGeneratorUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DeleteOrderHelper;
import org.junit.jupiter.api.Assertions;
import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class UpdateAggregativeStatusTests {
    private OrderEntityServiceRetrofit orderEntityRetrofit;
    private AutomationManager automationManager;
    private CosmosContext cosmosDbContext;
    private String containerName;
    private PropertyReader propertyReader;
    private CosmosDocumentMapper documentMapper;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private CreateOrderEntityHelper createOrderEntityHelper;
    private DeleteOrderHelper deleteOrderHelper;
    private PlacedOrderRequestV2 orderRequestV2;
    private PlacedOrderLinkRequestV2 orderLinkRequestV2;
    public static final int FILL_ID = 124312;
    public static final long RX_NBR = 3253211l;

    @BeforeClass
    void setContext() throws IOException {
        propertyReader = PropertyReader.getInstance();
        orderEntityRetrofit = new OrderEntityServiceRetrofit(propertyReader);
        automationManager = AutomationManager.getInstance();
        cosmosDbContext = automationManager.getDpOrderCosmos();
        containerName = propertyReader.getProperty("dpOrderCosmos.db_container");
        documentMapper = new CosmosDocumentMapper(cosmosDbContext, containerName);
        createOrderEntityHelper = new CreateOrderEntityHelper(documentMapper, orderEntityRetrofit);
        deleteOrderHelper = new DeleteOrderHelper(documentMapper);

        //Creating new order requests.
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        orderLinkRequestV2 = objectMapper
                .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createBuyerLink.json"),
                        PlacedOrderLinkRequestV2.class);

        orderRequestV2 = objectMapper
                .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createOrder.json"),
                        PlacedOrderRequestV2.class);
    }


    @Test(
            priority = 0,
            description = "Aggregative Status V1 update test")
    public void updateAggregativeStatusV1() throws IOException {

        //Create order
        createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);

        String trackID = IdGeneratorUtils.generateUUID();
        Reporter.logJSON("request tracking Id","req-track-"+trackID);
        Reporter.logJSON("request Id","req-id-"+trackID);

        //Updating Aggregative Status in the order.
        UpdateOrderAggregativeStatusRequest.AggregativeStatusEnum updatedStatus
                = UpdateOrderAggregativeStatusRequest.AggregativeStatusEnum.CANCELLED;
        UpdateOrderAggregativeStatusRequest aggregativeStatusRequest
                = new UpdateOrderAggregativeStatusRequest();
        aggregativeStatusRequest.setAggregativeStatus(updatedStatus);
        PatientId patientId = new PatientId();
        patientId.setPatientId(orderLinkRequestV2.getPatientLink().getPatientId());
        patientId.setStoreId(orderRequestV2.getStoreId());
        aggregativeStatusRequest.setPatientId(patientId);
        final String orderId = orderRequestV2.getOrderId();
        Response<Void> response = orderEntityRetrofit.updateV1AggregativeStatus(aggregativeStatusRequest, orderId,
                "req-id-"+trackID,
                "req-track-"+trackID);
        Assertions.assertEquals(HttpStatus.NO_CONTENT.value(), response.code(), "Response code not as expected");


        //Assert that the order status was updated.
        JsonNode jsonNode = documentMapper.getOrder(orderId);
        String aggStatusV1 = jsonNode.get("aggregativeStatus").asText();
        Assertions.assertEquals(updatedStatus.getValue(), aggStatusV1, "Agg Status value not as expected");
        List<String> updates =
                objectMapper.readValue(jsonNode.get("aggregativeStatusUpdates").toString(),
                        new TypeReference<List<String>>(){});
        Assertions.assertEquals(1, updates.size());
        Assertions.assertEquals(updatedStatus.getValue(), updates.get(0));

        //Deleting the order.
        deleteOrderHelper.deleteOrder(orderId, orderRequestV2.getStoreId()
                + "-" + orderLinkRequestV2.getPatientLink().getPatientId());
        deleteOrderHelper.deleteOrderLink(orderId, orderLinkRequestV2.getBuyerOnlineCustomerId());
    }

    @Test(
            priority = 1,
            description = "Aggregative Status V1 update, order doesn't exist")
    public void updateAggregativeStatusV1Failure() throws IOException {

        //Create order
        String trackID = IdGeneratorUtils.generateUUID();
        Reporter.logJSON("request tracking Id","req-track-"+trackID);
        Reporter.logJSON("request Id","req-id-"+trackID);

        //Updating Aggregative Status in the order.
        UpdateOrderAggregativeStatusRequest.AggregativeStatusEnum updatedStatus
                = UpdateOrderAggregativeStatusRequest.AggregativeStatusEnum.CANCELLED;
        UpdateOrderAggregativeStatusRequest aggregativeStatusRequest
                = new UpdateOrderAggregativeStatusRequest();
        aggregativeStatusRequest.setAggregativeStatus(updatedStatus);
        PatientId patientId = new PatientId();
        patientId.setPatientId(orderLinkRequestV2.getPatientLink().getPatientId());
        patientId.setStoreId(orderRequestV2.getStoreId());
        aggregativeStatusRequest.setPatientId(patientId);
        Response<Void> response = orderEntityRetrofit.updateV1AggregativeStatus(aggregativeStatusRequest,
                UUID.randomUUID().toString(),
                "req-id-"+trackID,
                "req-track-"+trackID);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST.value(), response.code(), "Response code not as expected");
    }

    @Test(
            priority = 2,
            description = "Aggregative Status V2 and fill update test")
    public void updateAggStatusV2AndOrder() throws IOException {

        //Create order
        createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);

        String trackID = IdGeneratorUtils.generateUUID();
        Reporter.logJSON("request tracking Id","req-track-"+trackID);
        Reporter.logJSON("request Id","req-id-"+trackID);

        AppendFillsRequest appendFillsRequest = new AppendFillsRequest();
        Fill newFill = new Fill();
        newFill.setFillId(-1);
        newFill.setRxNbr(RX_NBR);
        newFill.setFillStatus(Fill.FillStatusEnum.BUILD);
        newFill.setEstimatedPrice(23523d);
        appendFillsRequest.setFills(Arrays.asList(newFill));
        appendFillsRequest.setPatientLink(orderLinkRequestV2.getPatientLink());

        Response<Object> response = orderEntityRetrofit.appendFills(orderRequestV2.getOrderId(), appendFillsRequest,"req-id-"+trackID,
                "req-track-"+trackID);
        Assert.assertEquals(response.code(), 204);

        //Updating Aggregative Status in the order.
        final String orderId = orderRequestV2.getOrderId();
        UpdateOrderWithStoreDataRequest orderWithStoreDataRequest = new UpdateOrderWithStoreDataRequest();
        updateAggStatusV2AndFill(orderWithStoreDataRequest, trackID, orderId, FILL_ID);

        //TODO: Later we should map the JsonNode to orderV3 directly.

        //Assert that the order status was updated.
        JsonNode jsonNode = documentMapper.getOrder(orderId);
        String aggStatusV2 = jsonNode.get("aggregativeStatusV2").asText();
        Assertions.assertEquals(orderWithStoreDataRequest.getAggregativeStatusV2().getValue(), aggStatusV2,
                "Agg Status value not as expected");
        List<String> updates =
                objectMapper.readValue(jsonNode.get("aggregativeStatusV2Updates").toString(),
                        new TypeReference<List<String>>(){});
        Assertions.assertEquals(1, updates.size());
        Assertions.assertEquals(orderWithStoreDataRequest.getAggregativeStatusV2().getValue(), updates.get(0));

        //Assert that fill object was updated.
        List<Fill> fills =
                objectMapper.readValue(jsonNode.get("fills").toString(), new TypeReference<List<Fill>>(){});
        Assertions.assertEquals(1, fills.size());
        Assertions.assertEquals(FILL_ID, fills.get(0).getFillId());
        Assertions.assertEquals(Fill.FillStatusEnum.ACTIVE, fills.get(0).getFillStatus());

        //Deleting the order.
        deleteOrderHelper.deleteOrder(orderId, orderRequestV2.getStoreId()
                + "-" + orderLinkRequestV2.getPatientLink().getPatientId());
        deleteOrderHelper.deleteOrderLink(orderId, orderLinkRequestV2.getBuyerOnlineCustomerId());
    }

    @Test(
            priority = 3,
            description = "Aggregative Status V2 and updating fillId of -1")
    public void updateAggStatusV2AndOrder2() throws IOException {

        //Create order
        createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);

        String trackID = IdGeneratorUtils.generateUUID();
        Reporter.logJSON("request tracking Id","req-track-"+trackID);
        Reporter.logJSON("request Id","req-id-"+trackID);

        //Setting fill with -1 id in Fill object.
        final String orderId = orderRequestV2.getOrderId();
        UpdateOrderWithStoreDataRequest orderWithStoreDataRequest = new UpdateOrderWithStoreDataRequest();
        updateAggStatusV2AndFill(orderWithStoreDataRequest, trackID, orderId, -1);

        //Updating the fill with the same rxNbr
        updateAggStatusV2AndFill(orderWithStoreDataRequest, trackID, orderId, FILL_ID);

        //TODO: Later we should map the JsonNode to orderV3 directly.

        //Assert that the order status was updated.
        JsonNode jsonNode = documentMapper.getOrder(orderId);
        String aggStatusV2 = jsonNode.get("aggregativeStatusV2").asText();
        Assertions.assertEquals(orderWithStoreDataRequest.getAggregativeStatusV2().getValue(),
                aggStatusV2, "Agg Status value not as expected");
        List<String> updates =
                objectMapper.readValue(jsonNode.get("aggregativeStatusV2Updates").toString(),
                        new TypeReference<List<String>>(){});
        Assertions.assertEquals(1, updates.size());
        Assertions.assertEquals(orderWithStoreDataRequest.getAggregativeStatusV2().getValue(), updates.get(0));

        //Assert that fill object was updated.
        List<Fill> fills =
                objectMapper.readValue(jsonNode.get("fills").toString(), new TypeReference<List<Fill>>(){});
        Assertions.assertEquals(1, fills.size());
        Assertions.assertEquals(FILL_ID, fills.get(0).getFillId());
        Assertions.assertEquals(RX_NBR, fills.get(0).getRxNbr());
        Assertions.assertEquals(Fill.FillStatusEnum.ACTIVE, fills.get(0).getFillStatus());

        //Deleting the order.
        deleteOrderHelper.deleteOrder(orderId, orderRequestV2.getStoreId()
                + "-" + orderLinkRequestV2.getPatientLink().getPatientId());
        deleteOrderHelper.deleteOrderLink(orderId, orderLinkRequestV2.getBuyerOnlineCustomerId());
    }

    @Test(
            priority = 5,
            description = "Aggregative Status V2, order status")
    public void updateAggStatusV2AndOrderFailure() throws IOException {

        //Create order
        createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);

        String trackID = IdGeneratorUtils.generateUUID();
        Reporter.logJSON("request tracking Id","req-track-"+trackID);
        Reporter.logJSON("request Id","req-id-"+trackID);

        //Updating Aggregative Status in the order.
        UpdateOrderWithStoreDataRequest.AggregativeStatusV2Enum updatedStatus
                = UpdateOrderWithStoreDataRequest.AggregativeStatusV2Enum.CANCELLED;
        UpdateOrderWithStoreDataRequest orderWithStoreDataRequest
                = new UpdateOrderWithStoreDataRequest();
        orderWithStoreDataRequest.setAggregativeStatusV2(updatedStatus);
        orderWithStoreDataRequest.setPatientId(orderLinkRequestV2.getPatientLink().getPatientId());
        orderWithStoreDataRequest.setStoreId(orderRequestV2.getStoreId());
        orderWithStoreDataRequest.setFillId(FILL_ID);
        orderWithStoreDataRequest.setFillStatus(UpdateOrderWithStoreDataRequest.FillStatusEnum.ACTIVE);
        Response<Void> response = orderEntityRetrofit.updateV2AggregativeStatusAndStoreData(orderWithStoreDataRequest,
                UUID.randomUUID().toString(),
                "req-id-"+trackID,
                "req-track-"+trackID);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST.value(), response.code(), "Response code not as expected");

    }

    private void updateAggStatusV2AndFill(UpdateOrderWithStoreDataRequest orderWithStoreDataRequest,
                                          String trackID,
                                          String orderId,
                                          int fillId)
            throws IOException {
        orderWithStoreDataRequest.setAggregativeStatusV2(UpdateOrderWithStoreDataRequest.AggregativeStatusV2Enum.CANCELLED);
        orderWithStoreDataRequest.setPatientId(orderLinkRequestV2.getPatientLink().getPatientId());
        orderWithStoreDataRequest.setStoreId(orderRequestV2.getStoreId());
        orderWithStoreDataRequest.setFillId(fillId);
        orderWithStoreDataRequest.setRxNbr(RX_NBR);
        orderWithStoreDataRequest.setFillStatus(UpdateOrderWithStoreDataRequest.FillStatusEnum.ACTIVE);
        Response<Void> response = orderEntityRetrofit.updateV2AggregativeStatusAndStoreData(orderWithStoreDataRequest,
                orderId,
                "req-id-"+ trackID,
                "req-track-"+ trackID);
        Assertions.assertEquals(HttpStatus.NO_CONTENT.value(), response.code(), "Response code not as expected");
    }

}
