package orderentityservice;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.GetLinksByBuyerResponseV2;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.IdGeneratorUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.CreateOrderHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DeleteOrderHelper;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.reporters.Files;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;

@Slf4j
public class GetLinksByBuyerTest {
  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
  private OrderEntityServiceRetrofit orderEntityRetrofit;
  private AutomationManager automationManager;
  private CosmosContext cosmosDbContext;
  private String containerName;
  private PropertyReader propertyReader;
  private CosmosDocumentMapper documentMapper;
  private final ObjectMapper objectMapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonPatientId = null;
  private String commonPetId = null;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private static String storeNbr = "5572";
  private final int STATUS_CODE_204 = 204;
  private final int STATUS_CODE_200 = 200;
  private final int STATUS_CODE_500 = 500;
  private String ORDER_ID = "W005a9921c42ede48b59cea83b91c4bd1f7";
  private String STORE_NBR_PATIENT_ID = "5548-140026";
  private Long PATIENT_ID = 140026L;
  private Integer STORE_NBR = 5548;
  private String CUSTOMER_ACCOUNT_ID = "536f6a2a-5dd2-487f-952c-2a4b4e31975d";
  private String FROM_DATE = "2022-01-01";
  private String TO_DATE = "2023-01-01";
  private CreateOrderHelper createOrderHelper;
  private DeleteOrderHelper deleteOrderHelper;

  @BeforeClass
  void setContext() {
    propertyReader = PropertyReader.getInstance();
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    orderEntityRetrofit = new OrderEntityServiceRetrofit(propertyReader);
    automationManager = AutomationManager.getInstance();
    cosmosDbContext = automationManager.getDpOrderCosmos();
    containerName = propertyReader.getProperty("dpOrderCosmos.db_container");
    documentMapper = new CosmosDocumentMapper(cosmosDbContext, containerName);
    createOrderHelper = new CreateOrderHelper(documentMapper, orderOrchestratorRetrofit, objectMapper);
    deleteOrderHelper = new DeleteOrderHelper(documentMapper);
  }

  @Test(
          priority = 0,
          description = "Get order links by buyer id success case - Empty response")
  public void getLinksByBuyerSuccess1() throws IOException {
    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    Response<GetLinksByBuyerResponseV2> response = orderEntityRetrofit.getLinksByBuyer(CUSTOMER_ACCOUNT_ID,FROM_DATE, TO_DATE,"req-id-"+trackID,"req-track-"+trackID);
    Assert.assertEquals(response.code(), STATUS_CODE_200);
    Assert.assertNotNull(response.body());
  }
  @Test(
          priority = 1,
          description = "Get order links by buyer id success case - Response with order links")
  public void getLinksByBuyerSuccess2() throws IOException {
    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    createOrderHelper.createOrderV3(ORDER_ID, Files.readFile(new File("src/test/resources/testdata/digitalpharmacy/orderorchestrator/createorder/createOrderSuccess.json")));

    Response<GetLinksByBuyerResponseV2> response = orderEntityRetrofit.getLinksByBuyer(CUSTOMER_ACCOUNT_ID,null, null,"req-id-"+trackID,"req-track-"+trackID);
    Assert.assertEquals(response.code(), STATUS_CODE_200);
    Assert.assertNotNull(response.body());
    Assert.assertEquals(response.body().getOrderLinks().get(0).getPatientLink().getPatientId(),PATIENT_ID);
    Assert.assertEquals(response.body().getOrderLinks().get(0).getPatientLink().getStoreId(),STORE_NBR);

    deleteOrderHelper.deleteOrder(ORDER_ID, STORE_NBR_PATIENT_ID);
    deleteOrderHelper.deleteOrderLink(ORDER_ID, CUSTOMER_ACCOUNT_ID);
  }
}
