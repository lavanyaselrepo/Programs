package orderentityservice;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.AppendFillsRequest;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.OrderInfoByFillIdRequest;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.OrderInfoByFillIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.IdGeneratorUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.CreateOrderHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DeleteOrderHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.reporters.Files;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;

public class GetOrderInfoByFillId {
  private OrderEntityServiceRetrofit orderEntityRetrofit;
  private AutomationManager automationManager;
  private CosmosContext cosmosDbContext;
  private String containerName;
  private PropertyReader propertyReader;
  private CosmosDocumentMapper documentMapper;
  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
  private CreateOrderHelper createOrderHelper;
  private DeleteOrderHelper deleteCosmosDocumentHelper;

  private final ObjectMapper objectMapper = new ObjectMapper();
  private final Gson gson = new GsonBuilder().create();
  private String commonPatientId = null;
  private String commonPetId = null;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String ORDER_ID = "W005a9921c42ede48b59cea83b91c4bd1f7";
  private String STORE_NBR_PATIENT_ID = "5548-140026";
  private String CUSTOMER_ID = "536f6a2a-5dd2-487f-952c-2a4b4e31975d";

  @BeforeClass
  void setContext() {
    propertyReader = PropertyReader.getInstance();
    orderEntityRetrofit = new OrderEntityServiceRetrofit(propertyReader);
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    automationManager = AutomationManager.getInstance();
    cosmosDbContext = automationManager.getDpOrderCosmos();
    containerName = propertyReader.getProperty("dpOrderCosmos.db_container");
    documentMapper = new CosmosDocumentMapper(cosmosDbContext, containerName);
    createOrderHelper = new CreateOrderHelper(documentMapper, orderOrchestratorRetrofit, objectMapper);
    deleteCosmosDocumentHelper = new DeleteOrderHelper(documentMapper);
  }

  @Test(priority = 0, description = "Order Info By Fill Id return 200")
  public void orderInfoByFillIdSuccess() throws IOException {

    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    //create Order in Db
    createOrderHelper.createOrderV3(ORDER_ID, Files.readFile(new File("src/test/resources/testdata/digitalpharmacy/orderorchestrator/createorder/createOrderSuccess.json")));
    String payload= Files.readFile(
        new File("src/test/resources/testdata/digitalpharmacy/orderentity/GetOrderInfoByFillId/orderInfoByFillIdSuccess.json"));

    OrderInfoByFillIdRequest request = objectMapper.readValue(payload,OrderInfoByFillIdRequest.class);
    AppendFillsRequest request1 = objectMapper.readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/appendfills/AppendFillsSuccess.json"), AppendFillsRequest.class);

    //added the fillId
    orderEntityRetrofit.appendFills(ORDER_ID, request1,"req-id-"+trackID,"req-track-"+trackID);

    Response<OrderInfoByFillIdResponse> response = orderEntityRetrofit.getOrderInfoByFillId(request,"req-id-"+trackID,"req-track-"+trackID);

    Assert.assertEquals(response.code(),200);
    Assert.assertEquals(response.body().getOrderId(),ORDER_ID);
    Assert.assertEquals(response.body().getOnlineCustomerId(),CUSTOMER_ID);

    //clean up the Db
    deleteCosmosDocumentHelper.deleteOrder(ORDER_ID,STORE_NBR_PATIENT_ID);
    deleteCosmosDocumentHelper.deleteOrderLink(ORDER_ID,CUSTOMER_ID);
  }


  @Test(priority = 1, description = "Order Info By Fill Id return 204")
  public void orderInfoByFillIdNoContent() throws IOException {

    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    //create order
    createOrderHelper.createOrderV3(ORDER_ID, Files.readFile(new File("src/test/resources/testdata/digitalpharmacy/orderorchestrator/createorder/createOrderSuccess.json")));

    String payload= Files.readFile(
        new File("src/test/resources/testdata/digitalpharmacy/orderentity/GetOrderInfoByFillId/orderInfoByFillIdNoContent.json"));
    OrderInfoByFillIdRequest request = objectMapper.readValue(payload,OrderInfoByFillIdRequest.class);

    Response<OrderInfoByFillIdResponse> response = orderEntityRetrofit.getOrderInfoByFillId(request,"req-id-"+trackID,"req-track-"+trackID);
    Assert.assertEquals(response.code(),204);

    deleteCosmosDocumentHelper.deleteOrder(ORDER_ID,STORE_NBR_PATIENT_ID);
    deleteCosmosDocumentHelper.deleteOrderLink(ORDER_ID,CUSTOMER_ID);
  }
}