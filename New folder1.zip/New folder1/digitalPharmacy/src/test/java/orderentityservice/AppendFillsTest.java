package orderentityservice;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.AppendFillsRequest;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.Fill;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.PlacedOrderLinkRequestV2;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.PlacedOrderRequestV2;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.FailureResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.CreateOrderEntityHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.IdGeneratorUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.CreateOrderHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DeleteOrderHelper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Slf4j
public class AppendFillsTest {
  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
  private OrderEntityServiceRetrofit orderEntityRetrofit;
  private AutomationManager automationManager;
  private CosmosContext cosmosDbContext;
  private String containerName;
  private PropertyReader propertyReader;
  private CosmosDocumentMapper documentMapper;
  private final ObjectMapper objectMapper = new ObjectMapper();
  private final int STATUS_CODE_204 = 204;
  private final int STATUS_CODE_500 = 500;
  private String ORDER_ID = "W0000a12345b12345c12345d12345e12345";
  private String STORE_NBR_PATIENT_ID = "5597-120238";
  private String CUSTOMER_ACCOUNT_ID = "5c5b6897-b853-43d8-8473-aac3f2fb3838";
  private final long RX_NBR = 13423531l;
  private final double EST_PRICE = 967565418d;
  private final int FILL_ID = 123456;
  private CreateOrderHelper createOrderHelper;
  private CreateOrderEntityHelper createOrderEntityHelper;
  private DeleteOrderHelper deleteOrderHelper;

  PlacedOrderLinkRequestV2 orderLinkRequestV2;

  PlacedOrderRequestV2 orderRequestV2;

  @BeforeClass
  void setContext() throws IOException {
    propertyReader = PropertyReader.getInstance();
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    orderEntityRetrofit = new OrderEntityServiceRetrofit(propertyReader);
    automationManager = AutomationManager.getInstance();
    cosmosDbContext = automationManager.getDpOrderCosmos();
    containerName = propertyReader.getProperty("dpOrderCosmos.db_container");
    documentMapper = new CosmosDocumentMapper(cosmosDbContext, containerName);
    createOrderHelper = new CreateOrderHelper(documentMapper, orderOrchestratorRetrofit, objectMapper);
    createOrderEntityHelper = new CreateOrderEntityHelper(documentMapper, orderEntityRetrofit);
    deleteOrderHelper = new DeleteOrderHelper(documentMapper);

    orderLinkRequestV2 = objectMapper
            .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createBuyerLink.json"),
                    PlacedOrderLinkRequestV2.class);

    orderRequestV2 = objectMapper
            .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createOrder.json"),
                    PlacedOrderRequestV2.class);
  }

  @Test(
          priority = 0,
          description = "Append fills success case")
  public void appendFillsSuccess() throws IOException {
    AppendFillsRequest appendFillsRequest = new AppendFillsRequest();
    Fill newFill = getFill(FILL_ID + 1, RX_NBR + 1, Fill.FillStatusEnum.BUILD, Fill.NextWorkQueEnum.FILLING);
    appendFillsRequest.setFills(Collections.singletonList(newFill));
    appendFillsRequest.setPatientLink(orderLinkRequestV2.getPatientLink());

    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);
    final String orderId = orderRequestV2.getOrderId();

    Response<Object> response
            = orderEntityRetrofit.appendFills(orderId, appendFillsRequest,"req-id-"+trackID,"req-track-"+trackID);
    Assert.assertEquals(response.code(), STATUS_CODE_204);
    deleteOrderHelper.deleteOrder(orderId, orderRequestV2.getStoreId()
            + "-" + orderLinkRequestV2.getPatientLink().getPatientId());
    deleteOrderHelper.deleteOrderLink(orderId, orderLinkRequestV2.getBuyerOnlineCustomerId());
  }
  @Test(
          priority  = 1,
          description = "Append fills success case, existing fill with -1")
  public void appendFillsSuccess2() throws IOException {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    //Adding a fill with fillId as -1.
    Fill.FillStatusEnum fillStatus = Fill.FillStatusEnum.ACTIVE;
    Fill.NextWorkQueEnum nextWorkQueEnum = Fill.NextWorkQueEnum.FILLING;
    Fill negativeFill = getFill(-1, RX_NBR, fillStatus, nextWorkQueEnum);
    Fill negativeFill2 = getFill(-2, RX_NBR + 1, fillStatus, nextWorkQueEnum);
    orderRequestV2.setFills(Arrays.asList(negativeFill, negativeFill2));

    createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);

    //Assert fill is present with -1 entry.
    final String orderId = orderRequestV2.getOrderId();
    JsonNode jsonNode = documentMapper.getOrder(orderId);
    List<Fill> fills = objectMapper.readValue(jsonNode.get("fills").toString(), new TypeReference<List<Fill>>() {});
    Assert.assertTrue(fills.stream().anyMatch(fill -> fill.getFillId() == -1));


    //Call Append Fills API
    AppendFillsRequest appendFillsRequest = new AppendFillsRequest();
    Fill newFill = getFill(FILL_ID + 1, RX_NBR + 1, fillStatus, nextWorkQueEnum);
    negativeFill.setFillId(FILL_ID);
    appendFillsRequest.setFills(Arrays.asList(negativeFill, newFill));
    appendFillsRequest.setPatientLink(orderLinkRequestV2.getPatientLink());

    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    Response<Object> response = orderEntityRetrofit.appendFills(orderId, appendFillsRequest,"req-id-"+trackID,
            "req-track-"+trackID);
    Assert.assertEquals(response.code(), STATUS_CODE_204);


    //Assert that -1 fill was replaced.
    JsonNode jsonNodeUpdated = documentMapper.getOrder(orderId);
    List<Fill> updatedFills = objectMapper.readValue(jsonNodeUpdated.get("fills").toString(), new TypeReference<List<Fill>>() {});
    Fill oldRxFill = updatedFills.stream().filter(fill -> fill.getRxNbr().equals(RX_NBR)).findAny().get();
    Assertions.assertEquals(FILL_ID, oldRxFill.getFillId());
    Assertions.assertEquals(2, updatedFills.size());
    Assertions.assertEquals(EST_PRICE, oldRxFill.getEstimatedPrice());
    Assertions.assertTrue(updatedFills.stream().anyMatch(fill -> fill.getFillId().equals(FILL_ID+1)));

    deleteOrderHelper.deleteOrder(orderId, orderRequestV2.getStoreId()
            + "-" + orderLinkRequestV2.getPatientLink().getPatientId());
    deleteOrderHelper.deleteOrderLink(orderId, orderLinkRequestV2.getBuyerOnlineCustomerId());
  }


  @Test(
          priority = 2,
          description = "Append fills error case, order doesn't exist")
  public void appendFillsError1() throws IOException {
    AppendFillsRequest request = objectMapper.readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/appendfills/AppendFillsError1.json"), AppendFillsRequest.class);

    String trackID = IdGeneratorUtils.generateUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);

    Response<Object> response = orderEntityRetrofit.appendFills("INVALID_ORDER_ID", request,"req-id-"+trackID,"req-track-"+trackID);
    Assert.assertEquals(response.code(), 400, "Response status code not as expected");
    FailureResponse failureResponse
            = objectMapper.readValue(new String(response.errorBody().bytes()), FailureResponse.class);
    Assertions.assertEquals("CHPR-DPOESR-4004", failureResponse.getErrorCode());
  }

  private Fill getFill(Integer fillId,
                       Long rxNbr,
                       Fill.FillStatusEnum fillStatus,
                       Fill.NextWorkQueEnum nextWorkQueEnum) {
    Fill fill = new Fill();
    fill.setFillId(fillId);
    fill.setRxNbr(rxNbr);
    fill.setFillStatus(fillStatus);
    fill.setNextWorkQue(nextWorkQueEnum);
    fill.setEstimatedPrice(EST_PRICE);
    return fill;
  }
}
