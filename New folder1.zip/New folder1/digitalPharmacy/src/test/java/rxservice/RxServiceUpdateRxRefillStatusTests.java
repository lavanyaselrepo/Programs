package rxservice;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxservice.RxServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.rx.service.restclient.model.CreateRefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RefillReminderResponse;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RequestEntityRefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RxStatusUpdateRequestV2;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RxStatusUpdateResponse;
import com.walmart.pharmacy.dp.rx.service.restclient.model.ServiceResponseObject;
import java.io.IOException;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxServiceUpdateRxRefillStatusTests {

  private static final String STORE_NUMBER = "5524";
  private static final String REQUEST_TRACKING_PREFIX = "req-tracking-";
  private static final String DEFAULT_DRUG_NAME = "ARIPIPRAZOLE 30MG";

  private RxServiceRetrofit rxServiceRetrofit;

  @BeforeClass
  void setContext() {
    rxServiceRetrofit = new RxServiceRetrofit();
  }

  @DataProvider(name = "updateRxStatusSuccessData")
  public Object[][] updateRxStatusSuccessData() {
    // Columns: initialStatus | targetStatus | fetchBeforeUpdate | updateApiResponse | fetchAfterUpdate
    return new Object[][] {
      // PENDING → COMPLETE: active reminder becomes inactive
      {
        CreateRefillReminderRequest.StatusEnum.PENDING,
        RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE,
        200,
        200,
        204
      },
      // PENDING → PARTIAL: active reminder becomes inactive
      {
        CreateRefillReminderRequest.StatusEnum.PENDING,
        RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL,
        200,
        200,
        204
      },
      // COMPLETE → PENDING: inactive reminder remains inactive
      {
        CreateRefillReminderRequest.StatusEnum.COMPLETE,
        RxStatusUpdateRequestV2.RefillStatusEnum.PENDING,
        204,
        204,
        204
      },
      // PENDING → COMPLETE: active reminder becomes inactive
      {
        CreateRefillReminderRequest.StatusEnum.PENDING,
        RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE,
        200,
        200,
        204
      },
      // COMPLETE → COMPLETE: inactive reminder remains inactive
      {
        CreateRefillReminderRequest.StatusEnum.COMPLETE,
        RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE,
        204,
        204,
        204
      }
    };
  }

  @DataProvider(name = "updateRxStatusInvalidData")
  public Object[][] updateRxStatusInvalidData() {
    long sourceActivityTs = System.currentTimeMillis();
    return new Object[][] {
      {null, STORE_NUMBER, "6636631", sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PENDING},
      {"6636631", null, "6636631", sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PENDING},
      {"6636631", STORE_NUMBER, null, sourceActivityTs, RxStatusUpdateRequestV2.RefillStatusEnum.PENDING},
      {"6636631", STORE_NUMBER, "6636631", sourceActivityTs, null}
    };
  }

  /** This test covers UpdateRxRefillStatus success cases using the same seed-and-verify style as create tests. */
  @Test(description = "UpdateRxRefillStatus - Success", dataProvider = "updateRxStatusSuccessData")
  public void updateRxRefillStatusSuccess(
      CreateRefillReminderRequest.StatusEnum initialStatus,
      RxStatusUpdateRequestV2.RefillStatusEnum targetStatus,
      int expectedStatusForFetchBeforeUpdate,
      int expectedStatusAfterRxUpdate,
      int expectedStatusForFetchAfterUpdate)
      throws IOException {

    // Step - 1: Prepare an isolated refill reminder record for this test case
    TestRxContext context = buildUniqueTestRxContext();
    Response<ServiceResponseObject> createResponse =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    context.rxNumber(),
                    context.patientId(),
                    context.sourceActivityTs(),
                    initialStatus,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse.code(), 204);

    // Step - 2: Verify the record's visibility before the update
    Response<RefillReminderResponse> beforeUpdateResponse =
        fetchRefillReminders(List.of(context.customerId()));
    assertRefillReminderResponse(
        beforeUpdateResponse,
        context.customerId(),
        context.rxNumber(),
        expectedStatusForFetchBeforeUpdate);

    // Step - 3: Update the refill status
    Response<RxStatusUpdateResponse> updateResponse =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                context.rxNumber(),
                context.patientId(),
                STORE_NUMBER,
                context.sourceActivityTs() + 60000L,
                targetStatus));

    // Step - 4: Assert update response
    Assert.assertEquals(updateResponse.code(), expectedStatusAfterRxUpdate);
    if(expectedStatusAfterRxUpdate == 200) {
      Assert.assertNotNull(updateResponse.body(), "Response body must not be null for 200");
      Assert.assertEquals(updateResponse.body().getStatus(), "OK");
    }

    // Step - 5: Verify the record's visibility after the update
    Response<RefillReminderResponse> afterUpdateResponse =
        fetchRefillReminders(List.of(context.customerId()));
    assertRefillReminderResponse(
        afterUpdateResponse,
        context.customerId(),
        context.rxNumber(),
        expectedStatusForFetchAfterUpdate);
  }

  /** This test covers UpdateRxRefillStatus invalid request failure cases. */
  @Test(
      description = "UpdateRxRefillStatus - Invalid request failure",
      dataProvider = "updateRxStatusInvalidData")
  public void updateRxRefillStatusInvalidRequestFailure(
      String rxNumber,
      String storeId,
      String patientId,
      Long sourceActivityTs,
      RxStatusUpdateRequestV2.RefillStatusEnum refillStatus)
      throws IOException {

    // Step - 1: Build request payload with one missing mandatory field
    RxStatusUpdateRequestV2 request =
        buildRxStatusUpdateRequestV2(rxNumber, patientId, storeId, sourceActivityTs, refillStatus);

    // Step - 2: Call update refill status API
    Response<RxStatusUpdateResponse> response = rxServiceRetrofit.updateRxStatus(request);

    // Step - 3: Assert validation failure
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * Verifies that updating a refill status when no Cosmos record exists returns 204.
   */
  @Test(description = "UpdateRxRefillStatus - No existing Cosmos record returns 204")
  public void updateRxRefillStatusWhenNoRecordExists() throws IOException {
    // Deliberately skip creating a reminder record to simulate a missing Cosmos document
    TestRxContext context = buildUniqueTestRxContext();

    // Attempt to update a prescription that has never been created
    Response<RxStatusUpdateResponse> response =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                context.rxNumber(),
                context.patientId(),
                STORE_NUMBER,
                context.sourceActivityTs(),
                RxStatusUpdateRequestV2.RefillStatusEnum.PENDING));

    Assert.assertEquals(response.code(), 204,
        "Expected 204 when updating refill status for a non-existent Cosmos record");
  }

  /**
   * Verifies that an update carrying a sourceActivityTs older than the record's own timestamp
   * is silently ignored — the reminder state must remain unchanged.
   */
  @Test(description = "UpdateRxRefillStatus - Stale sourceActivityTs is ignored, state unchanged")
  public void updateRxRefillStatusWithStaleTimestampIsIgnored() throws IOException {
    // Step - 1: Create a PENDING record
    TestRxContext context = buildUniqueTestRxContext();
    Response<ServiceResponseObject> createResponse =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    context.rxNumber(),
                    context.patientId(),
                    context.sourceActivityTs(),
                    CreateRefillReminderRequest.StatusEnum.PENDING,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse.code(), 204);

    // Step - 2: Attempt update with a timestamp 1 hour BEFORE the record was created
    long staleTimestamp = context.sourceActivityTs() - 3_600_000L;
    Response<RxStatusUpdateResponse> rxStatusUpdateResponseResponse = rxServiceRetrofit.updateRxStatus(
        buildRxStatusUpdateRequestV2(
            context.rxNumber(),
            context.patientId(),
            STORE_NUMBER,
            staleTimestamp,
            RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE));
    Assert.assertEquals(rxStatusUpdateResponseResponse.code(), 200);

    // Step - 3: Reminder must still be active — stale update must not change the state
    assertRefillReminderResponse(
        fetchRefillReminders(List.of(context.customerId())),
        context.customerId(),
        context.rxNumber(),
        200);
  }

  /**
   * Verifies the PARTIAL initial state scenario via a two-step transition:
   *   Create (PENDING) → Update to PARTIAL → Update to PENDING → reminder reactivated.
   * Gap covered: "PARTIAL as initial status" (not in KB — unlocks the missing PARTIAL→PENDING path)
   */
  @Test(description = "UpdateRxRefillStatus - PARTIAL initial state, update to PENDING reactivates reminder")
  public void updateRxRefillStatusFromPartialInitialState() throws IOException {
    // Step - 1: Create a PENDING record (create API does not accept PARTIAL directly)
    TestRxContext context = buildUniqueTestRxContext();
    Response<ServiceResponseObject> createResponse =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    context.rxNumber(),
                    context.patientId(),
                    context.sourceActivityTs(),
                    CreateRefillReminderRequest.StatusEnum.PENDING,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse.code(), 204);

    // Step - 2: Transition to PARTIAL — this establishes PARTIAL as the current state
    Response<RxStatusUpdateResponse> toPartialResponse =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                context.rxNumber(),
                context.patientId(),
                STORE_NUMBER,
                context.sourceActivityTs() + 30_000L,
                RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL));
    Assert.assertEquals(toPartialResponse.code(), 200, "Transition to PARTIAL must succeed with 200");
    Assert.assertNotNull(toPartialResponse.body());
    Assert.assertEquals(toPartialResponse.body().getStatus(), "OK");

    // Step - 3: Verify reminder is inactive while in PARTIAL state
    assertRefillReminderResponse(
        fetchRefillReminders(List.of(context.customerId())),
        context.customerId(),
        context.rxNumber(),
        204);

    // Step - 4: Update from PARTIAL → PENDING — reminder must reactivate
    Response<RxStatusUpdateResponse> toPendingResponse =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                context.rxNumber(),
                context.patientId(),
                STORE_NUMBER,
                context.sourceActivityTs() + 60_000L,
                RxStatusUpdateRequestV2.RefillStatusEnum.PENDING));
    Assert.assertEquals(toPendingResponse.code(), 200, "Transition from PARTIAL to PENDING must succeed");
    Assert.assertNotNull(toPendingResponse.body());
    Assert.assertEquals(toPendingResponse.body().getStatus(), "OK");

    // Step - 5: Reminder must be active again after going back to PENDING
    assertRefillReminderResponse(
        fetchRefillReminders(List.of(context.customerId())),
        context.customerId(),
        context.rxNumber(),
        200);
  }

  /**
   * Verifies that multiple prescriptions for the same customer are updated independently.
   * Updating one Rx to COMPLETE must not suppress a different Rx that is still PENDING.
   * Gap covered: "Multiple rxDetails entries not tested" (KB Section 11 — Medium)
   * Note: V2 API processes one Rx per call; this test validates independent state management
   * per-prescription for the same customer, which is the effective multi-rx contract.
   */
  @Test(description = "UpdateRxRefillStatus - Multiple prescriptions for same customer are updated independently")
  public void updateRxRefillStatusMultiplePrescriptionsForSameCustomer() throws IOException {
    // Step - 1: Create two PENDING reminders sharing the same customerId
    TestRxContext ctx1 = buildUniqueTestRxContext();
    TestRxContext ctx2 = buildUniqueTestRxContextForCustomer(ctx1.customerId());

    Response<ServiceResponseObject> create1 =
        rxServiceRetrofit.createRefillReminder(
            ctx1.customerId(),
            List.of(buildCreateRefillReminderRequest(
                ctx1.rxNumber(), ctx1.patientId(), ctx1.sourceActivityTs(),
                CreateRefillReminderRequest.StatusEnum.PENDING, ctx1.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(create1.code(), 204, "First prescription create must return 204");

    Response<ServiceResponseObject> create2 =
        rxServiceRetrofit.createRefillReminder(
            ctx2.customerId(),
            List.of(buildCreateRefillReminderRequest(
                ctx2.rxNumber(), ctx2.patientId(), ctx2.sourceActivityTs(),
                CreateRefillReminderRequest.StatusEnum.PENDING, ctx2.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(create2.code(), 204, "Second prescription create must return 204");

    // Step - 2: Update only the first prescription to COMPLETE
    Response<RxStatusUpdateResponse> updateRx1 =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                ctx1.rxNumber(), ctx1.patientId(), STORE_NUMBER,
                ctx1.sourceActivityTs() + 60_000L,
                RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE));
    Assert.assertEquals(updateRx1.code(), 200, "Update first prescription to COMPLETE must return 200");

    // Step - 3: Reminder should still be 200 because the second prescription is still PENDING
    Response<RefillReminderResponse> afterFirstUpdate =
        fetchRefillReminders(List.of(ctx1.customerId()));
    Assert.assertEquals(afterFirstUpdate.code(), 200,
        "Reminder must still return 200 — second prescription is still PENDING");

    Assert.assertNotNull(afterFirstUpdate.body());
    var customerEntry = afterFirstUpdate.body().getPayload().getCustomerRefillsInfo().stream()
            .filter(c -> ctx1.customerId().equals(c.getCustomerInfo().getCustomerAccountId()))
            .findFirst()
            .orElse(null);
    Assert.assertNotNull(customerEntry, "Customer entry must be present in the response");
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream().noneMatch(r -> ctx1.rxNumber().equals(r.getRxNumber())),
        "First rx (now COMPLETE) must NOT appear in refillsDue");
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream().anyMatch(r -> ctx2.rxNumber().equals(r.getRxNumber())),
        "Second rx (still PENDING) must still appear in refillsDue");

    // Step - 4: Now update the second prescription to COMPLETE as well
    Response<RxStatusUpdateResponse> updateRx2 =
        rxServiceRetrofit.updateRxStatus(
            buildRxStatusUpdateRequestV2(
                ctx2.rxNumber(), ctx2.patientId(), STORE_NUMBER,
                ctx2.sourceActivityTs() + 60_000L,
                RxStatusUpdateRequestV2.RefillStatusEnum.COMPLETE));
    Assert.assertEquals(updateRx2.code(), 200, "Update second prescription to COMPLETE must return 200");

    // Step - 5: Both prescriptions are COMPLETE — reminder returns 204 for the customer
    assertRefillReminderResponse(
        fetchRefillReminders(List.of(ctx1.customerId())),
        ctx1.customerId(),
        ctx1.rxNumber(),
        204);
  }

  private Response<RefillReminderResponse> fetchRefillReminders(List<String> customerAccountIds)
      throws IOException {
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(customerAccountIds);
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);
    return rxServiceRetrofit.getRefillReminders(request);
  }

  private void assertRefillReminderResponse(
      Response<RefillReminderResponse> response,
      String customerId,
      String rxNumber,
      int expectedStatusCode) {
    Assert.assertEquals(response.code(), expectedStatusCode);
    if (expectedStatusCode == 204) {
      Assert.assertNull(response.body(), "Response body must be null for 204");
      return;
    }

    Assert.assertNotNull(response.body(), "Response body must not be null for 200");
    Assert.assertNotNull(response.body().getPayload(), "Payload must not be null");
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(customer -> customerId.equals(customer.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry, "Customer entry must be present in the response");
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream().anyMatch(refill -> rxNumber.equals(refill.getRxNumber())),
        "Expected rxNumber must be present in refillsDue");
  }

  private CreateRefillReminderRequest buildCreateRefillReminderRequest(
      String rxNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName) {

    CreateRefillReminderRequest request = new CreateRefillReminderRequest();
    request.setRxNumber(rxNumber);
    request.setStoreNumber(STORE_NUMBER);
    request.setPatientId(patientId);
    request.setSourceActivityTs(sourceActivityTs);
    request.setStatus(status);
    request.setDrugName(drugName);
    return request;
  }

  private RxStatusUpdateRequestV2 buildRxStatusUpdateRequestV2(
      String rxNumber,
      String patientId,
      String storeId,
      Long sourceActivityTs,
      RxStatusUpdateRequestV2.RefillStatusEnum refillStatus) {

    RxStatusUpdateRequestV2 request = new RxStatusUpdateRequestV2();
    request.setRxNumber(rxNumber);
    request.setPatientId(patientId);
    request.setStoreId(storeId);
    request.setSourceActivityTs(sourceActivityTs);
    request.setRefillStatus(refillStatus);
    return request;
  }

  private TestRxContext buildUniqueTestRxContext() {
    return buildUniqueTestRxContextForCustomer(CommonUtil.randomUUID());
  }

  /**
   * Builds a unique TestRxContext that shares the given customerId.
   * Used in multi-prescription tests where two prescriptions must belong to the same customer.
   */
  private TestRxContext buildUniqueTestRxContextForCustomer(String customerId) {
    long seed = System.nanoTime();
    String rxNumber = String.format("%07d", Math.floorMod(seed, 10_000_000L));
    String patientId = String.format("%07d", Math.floorMod(seed / 10L, 10_000_000L));

    if (rxNumber.equals(patientId)) {
      patientId = String.format("%07d", (Long.parseLong(patientId) + 1) % 10_000_000L);
    }

    return new TestRxContext(
        customerId,
        rxNumber,
        patientId,
        DEFAULT_DRUG_NAME,
        System.currentTimeMillis());
  }

  private record TestRxContext(
      String customerId,
      String rxNumber,
      String patientId,
      String drugName,
      long sourceActivityTs) {}
}
