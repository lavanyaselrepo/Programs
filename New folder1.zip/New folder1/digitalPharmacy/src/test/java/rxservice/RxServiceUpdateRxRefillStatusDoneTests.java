package rxservice;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxservice.RxServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.rx.service.restclient.model.*;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxServiceUpdateRxRefillStatusDoneTests {

  private static final String STORE_NUMBER = "5524";
  private static final String REQUEST_TRACKING_PREFIX = "req-tracking-";
  private static final String DEFAULT_DRUG_NAME = "ARIPIPRAZOLE 30MG";

  private RxServiceRetrofit rxServiceRetrofit;

  @BeforeClass
  void setContext() {
    rxServiceRetrofit = new RxServiceRetrofit();
  }

  @DataProvider(name = "updateRxRefillStatusDoneSuccessData")
  public Object[][] updateRxRefillStatusDoneSuccessData() {
    return new Object[][] {
      {
        CreateRefillReminderRequest.StatusEnum.PENDING,
        "Complete",  // explicit refillStatus query param
        200,         // expected HTTP code for fetch before update (PENDING visible)
        200,         // expected HTTP code for update response
        204          // expected HTTP code for fetch after update (COMPLETE hidden)
      },
      {
        CreateRefillReminderRequest.StatusEnum.PENDING,
        null,        // default refillStatus = Partial
        200,         // expected HTTP code for fetch before update (PENDING visible)
        200,         // expected HTTP code for update response
        204          // expected HTTP code for fetch after update (fresh PARTIAL hidden by 24h gate)
      },
      {
        CreateRefillReminderRequest.StatusEnum.COMPLETE,
        "Pending",   // explicit refillStatus query param
        204,         // expected HTTP code for fetch before update (COMPLETE hidden)
        200,         // expected HTTP code for update response
        200          // expected HTTP code for fetch after update (PENDING visible)
      },
      {
        CreateRefillReminderRequest.StatusEnum.COMPLETE,
        "Complete",  // same target status as current record state — idempotent re-done
        204,         // expected HTTP code for fetch before update (COMPLETE already hidden)
        200,         // expected HTTP code for update response (idempotent — still 200)
        204          // expected HTTP code for fetch after update (still hidden)
      }
    };
  }

  @DataProvider(name = "updateRxRefillStatusDoneInvalidData")
  public Object[][] updateRxRefillStatusDoneInvalidData() {
    return new Object[][] {
      {null},                          // null refilledPrescriptionList → 400
      {Collections.emptyList()}        // empty refilledPrescriptionList → 400
    };
  }

  /** This test covers UpdateRxRefillStatus Done success cases using the V1 (done) endpoint. */
  @Test(description = "UpdateRxRefillStatus Done - Success", dataProvider = "updateRxRefillStatusDoneSuccessData")
  public void updateRxRefillStatusDoneSuccess(
      CreateRefillReminderRequest.StatusEnum initialStatus,
      String targetRefillStatus,
      int expectedStatusForFetchBeforeUpdate,
      int expectedStatusAfterRxUpdate,
      int expectedStatusForFetchAfterUpdate)
      throws IOException {

    // Step 1: Prepare an isolated refill reminder record for this test case
    TestRxContext context = buildUniqueTestRxContext();
    Response<ServiceResponseObject> createResponse =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    context.rxNumber(),
                    context.patientId(),
                    context.sourceActivityTs(),
                    initialStatus,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse.code(), 204);

    // Step 2: Verify the record's visibility before the update
    Response<RefillReminderResponse> beforeUpdateResponse =
        fetchRefillReminders(List.of(context.customerId()));
    assertRefillReminderResponse(
        beforeUpdateResponse,
        context.customerId(),
        context.rxNumber(),
        expectedStatusForFetchBeforeUpdate);

    // Step 3: Call V1 (done) endpoint to update the refill status
    RxStatusUpdateRequest v1Request =
        buildRxStatusUpdateRequest(context.customerId(), context.rxNumber());
    Response<com.walmart.pharmacy.dp.rx.service.restclient.model.Response> updateResponse =
        rxServiceRetrofit.updateRxRefillStatusPartial(v1Request, null, targetRefillStatus);

    // Step 4: Assert update response
    Assert.assertEquals(updateResponse.code(), expectedStatusAfterRxUpdate);
    if (expectedStatusAfterRxUpdate == 200) {
      Assert.assertNotNull(updateResponse.body(), "Response body must not be null for 200");
      Assert.assertTrue(
          updateResponse.body().getStatus() == com.walmart.pharmacy.dp.rx.service.restclient.model.Response.StatusEnum.OK,
          "Response body must contain 'OK' for a successful update");
    }

    // Step 5: Verify the record's visibility after the update
    Response<RefillReminderResponse> afterUpdateResponse =
        fetchRefillReminders(List.of(context.customerId()));
    assertRefillReminderResponse(
        afterUpdateResponse,
        context.customerId(),
        context.rxNumber(),
        expectedStatusForFetchAfterUpdate);
  }

  /** This test covers UpdateRxRefillStatus Done invalid request failure cases. */
  @Test(
      description = "UpdateRxRefillStatus Done - Invalid request failure",
      dataProvider = "updateRxRefillStatusDoneInvalidData")
  public void updateRxRefillStatusDoneInvalidRequestFailure(
      List<RefillDuePrescriptionUpdate> prescriptionList) throws IOException {

    // Step 1: Build request payload with null or empty refilledPrescriptionList
    RxStatusUpdateRequest request = new RxStatusUpdateRequest();
    request.setRefilledPrescriptionList(prescriptionList);

    // Step 2: Call V1 (done) update API
    Response<com.walmart.pharmacy.dp.rx.service.restclient.model.Response> response = rxServiceRetrofit.updateRxRefillStatusPartial(request, null, null);

    // Step 3: Assert validation failure
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * Verifies the API is idempotent when no Cosmos record exists for the given Rx.
   * Equivalent to Test_case_4 in the KB: calling the done endpoint without any prior refill record
   * must still return 200 — the service must not return 404 for missing records.
   */
  @Test(description = "UpdateRxRefillStatus Done - Idempotent when no Cosmos record exists")
  public void updateRxRefillStatusDoneIdempotentNoRecord() throws IOException {

    // Step 1: Use a unique context — deliberately skip createRefillReminder so no record exists
    TestRxContext context = buildUniqueTestRxContext();

    // Step 2: Call the done endpoint with no pre-existing Cosmos document
    RxStatusUpdateRequest request = buildRxStatusUpdateRequest(context.customerId(), context.rxNumber());
    Response<com.walmart.pharmacy.dp.rx.service.restclient.model.Response> response =
        rxServiceRetrofit.updateRxRefillStatusPartial(request, null, "Complete");

    // Step 3: Assert 200 — idempotent; the service must not return 404 for a missing record
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body(), "Response body must not be null for 200");
    Assert.assertTrue(
        response.body().getStatus() == com.walmart.pharmacy.dp.rx.service.restclient.model.Response.StatusEnum.OK,
        "Response body status must be OK even when no prior Cosmos record existed");
  }

  /**
   * Verifies that multiple prescriptions can be marked done in a single request.
   * A single RefillDuePrescriptionUpdate entry carries multiple PrescriptionDetails entries
   * for the same customer; both must be removed from the refill reminder queue after the call.
   */
  @Test(description = "UpdateRxRefillStatus Done - Multiple prescriptions in one request")
  public void updateRxRefillStatusDoneMultiplePrescriptions() throws IOException {

    // Step 1: Build two unique rx numbers for the same customer
    TestRxContext context = buildUniqueTestRxContext();
    String rxNumber2 =
        String.format("%07d", (Long.parseLong(context.rxNumber()) + 1) % 10_000_000L);

    // Step 2: Create two separate PENDING refill reminder records for the same customer
    Response<ServiceResponseObject> createResponse1 =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    context.rxNumber(),
                    context.patientId(),
                    context.sourceActivityTs(),
                    CreateRefillReminderRequest.StatusEnum.PENDING,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse1.code(), 204, "First createRefillReminder must return 204");

    Response<ServiceResponseObject> createResponse2 =
        rxServiceRetrofit.createRefillReminder(
            context.customerId(),
            List.of(
                buildCreateRefillReminderRequest(
                    rxNumber2,
                    context.patientId(),
                    context.sourceActivityTs(),
                    CreateRefillReminderRequest.StatusEnum.PENDING,
                    context.drugName())),
            REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    Assert.assertEquals(createResponse2.code(), 204, "Second createRefillReminder must return 204");

    // Step 3: Verify both prescriptions are visible in the reminder queue before the done call
    Response<RefillReminderResponse> beforeResponse =
        fetchRefillReminders(List.of(context.customerId()));
    Assert.assertEquals(beforeResponse.code(), 200, "Both PENDING Rx must be visible before done");
    Assert.assertNotNull(beforeResponse.body());
    var refillsDue =
        beforeResponse.body().getPayload().getCustomerRefillsInfo().stream()
            .filter(c -> context.customerId().equals(c.getCustomerInfo().getCustomerAccountId()))
            .findFirst()
            .map(CustomerRefillInfo::getRefillsDue)
            .orElse(List.of());
    Assert.assertTrue(
        refillsDue.stream().anyMatch(r -> context.rxNumber().equals(r.getRxNumber())),
        "First rxNumber must be in refillsDue before done");
    Assert.assertTrue(
        refillsDue.stream().anyMatch(r -> rxNumber2.equals(r.getRxNumber())),
        "Second rxNumber must be in refillsDue before done");

    // Step 4: Call done with both prescriptions in a single refilledPrescriptionList entry
    RxStatusUpdateRequest multiRequest =
        buildRxStatusUpdateRequestWithMultiplePrescriptions(
            context.customerId(), List.of(context.rxNumber(), rxNumber2));
    Response<com.walmart.pharmacy.dp.rx.service.restclient.model.Response> updateResponse =
        rxServiceRetrofit.updateRxRefillStatusPartial(multiRequest, null, "Complete");

    // Step 5: Assert update succeeded
    Assert.assertEquals(updateResponse.code(), 200);
    Assert.assertNotNull(updateResponse.body(), "Response body must not be null for 200");
    Assert.assertSame(updateResponse.body().getStatus(), com.walmart.pharmacy.dp.rx.service.restclient.model.Response.StatusEnum.OK, "Response body status must be OK");

    // Step 6: Verify both prescriptions are no longer in the reminder queue
    Response<RefillReminderResponse> afterResponse =
        fetchRefillReminders(List.of(context.customerId()));
    Assert.assertEquals(
        afterResponse.code(),
        204,
        "No reminders must remain for customer after both Rx are marked done");
  }

  private Response<RefillReminderResponse> fetchRefillReminders(List<String> customerAccountIds)
      throws IOException {
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(customerAccountIds);
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);
    return rxServiceRetrofit.getRefillReminders(request);
  }

  private void assertRefillReminderResponse(
      Response<RefillReminderResponse> response,
      String customerId,
      String rxNumber,
      int expectedStatusCode) {
    Assert.assertEquals(response.code(), expectedStatusCode);
    if (expectedStatusCode == 204) {
      Assert.assertNull(response.body(), "Response body must be null for 204");
      return;
    }

    Assert.assertNotNull(response.body(), "Response body must not be null for 200");
    Assert.assertNotNull(response.body().getPayload(), "Payload must not be null");
    var customerEntry =
        response.body().getPayload().getCustomerRefillsInfo().stream()
            .filter(
                customer -> customerId.equals(customer.getCustomerInfo().getCustomerAccountId()))
            .findFirst()
            .orElse(null);
    Assert.assertNotNull(customerEntry, "Customer entry must be present in the response");
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream()
            .anyMatch(refill -> rxNumber.equals(refill.getRxNumber())),
        "Expected rxNumber must be present in refillsDue");
  }

  private CreateRefillReminderRequest buildCreateRefillReminderRequest(
      String rxNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName) {

    CreateRefillReminderRequest request = new CreateRefillReminderRequest();
    request.setRxNumber(rxNumber);
    request.setStoreNumber(STORE_NUMBER);
    request.setPatientId(patientId);
    request.setSourceActivityTs(sourceActivityTs);
    request.setStatus(status);
    request.setDrugName(drugName);
    return request;
  }

  private RxStatusUpdateRequest buildRxStatusUpdateRequest(String customerId, String rxNumber) {
    StoreNumber storeNumber = new StoreNumber();
    storeNumber.setStoreId(STORE_NUMBER);

    PrescriptionDetails prescriptionDetails = new PrescriptionDetails();
    prescriptionDetails.setRxNumber(rxNumber);
    prescriptionDetails.setStoreNumber(storeNumber);

    CustomerInfo customerInfo = new CustomerInfo();
    customerInfo.setCustomerAccountId(customerId);

    RefillDuePrescriptionUpdate prescriptionUpdate = new RefillDuePrescriptionUpdate();
    prescriptionUpdate.setCustomerInfo(customerInfo);
    prescriptionUpdate.setPrescriptionDetails(List.of(prescriptionDetails));

    RxStatusUpdateRequest request = new RxStatusUpdateRequest();
    request.setCustomerAccountId(customerId);
    request.setRefilledPrescriptionList(List.of(prescriptionUpdate));
    return request;
  }

  /**
   * Builds a done request where a single RefillDuePrescriptionUpdate entry contains multiple
   * PrescriptionDetails entries — all under the same customer and same store.
   */
  private RxStatusUpdateRequest buildRxStatusUpdateRequestWithMultiplePrescriptions(
      String customerId, List<String> rxNumbers) {
    List<PrescriptionDetails> prescriptionDetailsList =
        rxNumbers.stream()
            .map(
                rxNumber -> {
                  StoreNumber storeNumber = new StoreNumber();
                  storeNumber.setStoreId(STORE_NUMBER);

                  PrescriptionDetails details = new PrescriptionDetails();
                  details.setRxNumber(rxNumber);
                  details.setStoreNumber(storeNumber);
                  return details;
                })
            .toList();

    CustomerInfo customerInfo = new CustomerInfo();
    customerInfo.setCustomerAccountId(customerId);

    RefillDuePrescriptionUpdate prescriptionUpdate = new RefillDuePrescriptionUpdate();
    prescriptionUpdate.setCustomerInfo(customerInfo);
    prescriptionUpdate.setPrescriptionDetails(prescriptionDetailsList);

    RxStatusUpdateRequest request = new RxStatusUpdateRequest();
    request.setCustomerAccountId(customerId);
    request.setRefilledPrescriptionList(List.of(prescriptionUpdate));
    return request;
  }

  private TestRxContext buildUniqueTestRxContext() {
    long seed = System.nanoTime();
    String rxNumber = String.format("%07d", Math.floorMod(seed, 10_000_000L));
    String patientId = String.format("%07d", Math.floorMod(seed / 10L, 10_000_000L));

    if (rxNumber.equals(patientId)) {
      patientId = String.format("%07d", (Long.parseLong(patientId) + 1) % 10_000_000L);
    }

    return new TestRxContext(
        CommonUtil.randomUUID(),
        rxNumber,
        patientId,
        DEFAULT_DRUG_NAME,
        System.currentTimeMillis());
  }

  private record TestRxContext(
      String customerId,
      String rxNumber,
      String patientId,
      String drugName,
      long sourceActivityTs) {}
}

