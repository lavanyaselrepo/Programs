package rxservice;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxservice.RxServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.rx.service.restclient.model.CreateRefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.ServiceResponseObject;
import java.io.IOException;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxServiceCreateRefillReminderTests {

  private static final String CUSTOMER_ID = "072aca09-2e70-4fa3-b94c-6f7b299e3914";
  private static final String REQUEST_TRACKING_PREFIX = "req-tracking-";
  private RxServiceRetrofit rxServiceRetrofit;

  @BeforeClass
  void setContext() {
    rxServiceRetrofit = new RxServiceRetrofit();
  }

  @DataProvider(name = "createRefillReminderSuccessData")
  public Object[][] createRefillReminderSuccessData() {
    return new Object[][] {
      {"6636631", "5524", "6636631", 1714000000000L, CreateRefillReminderRequest.StatusEnum.PENDING, "ARIPIPRAZOLE 30MG", "204"},
      {"6636632", "5524", "6636631", 1714000000001L, CreateRefillReminderRequest.StatusEnum.COMPLETE, "ASPIRIN 30MG", "204"}
    };
  }

  @DataProvider(name = "createRefillReminderInvalidData")
  public Object[][] createRefillReminderInvalidData() {
    return new Object[][] {
      {"", "5524", "6636631", 1714000000000L, CreateRefillReminderRequest.StatusEnum.PENDING, "ARIPIPRAZOLE 30MG"},
      {"6636631", "", "6636631", 1714000000000L, CreateRefillReminderRequest.StatusEnum.PENDING, "ARIPIPRAZOLE 30MG"},
      {"6636631", "5524", "", 1714000000000L, CreateRefillReminderRequest.StatusEnum.PENDING, "ARIPIPRAZOLE 30MG"},
      {"6636631", "5524", "6636631", null, CreateRefillReminderRequest.StatusEnum.PENDING, "ARIPIPRAZOLE 30MG"},
      {"6636631", "5524", "6636631", 1714000000000L, CreateRefillReminderRequest.StatusEnum.PENDING, ""}
    };
  }

  /** This test covers CreateRefillReminder success cases */
  @Test(
      description = "CreateRefillReminder - Success",
      dataProvider = "createRefillReminderSuccessData")
  public void createRefillReminderSuccess(
      String rxNumber,
      String storeNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName,
      String statusCode)
      throws IOException {

    // Step - 1: Setting request tracking id for this call
    String requestTrackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();

    // Step - 2: Preparing request payload
    CreateRefillReminderRequest request =
        buildCreateRefillReminderRequest(
            rxNumber, storeNumber, patientId, sourceActivityTs, status, drugName);

    // Step - 3: Calling create refill reminder API
    Response<ServiceResponseObject> response =
        rxServiceRetrofit.createRefillReminder(CUSTOMER_ID, List.of(request), requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), 204);
  }

  /** This test covers CreateRefillReminder when status is omitted and defaults on server */
  @Test( description = "CreateRefillReminder - Success with omitted status")
  public void createRefillReminderSuccessWithOmittedStatus() throws IOException {

    // Step - 1: Setting request tracking id for this call
    String requestTrackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();

    // Step - 2: Preparing request payload without status
    CreateRefillReminderRequest request =
        buildCreateRefillReminderRequest(
            "6636633", "5524", "6636631", 1714000000002L, null, "ARIPIPRAZOLE 10MG");

    // Step - 3: Calling create refill reminder API
    Response<ServiceResponseObject> response =
        rxServiceRetrofit.createRefillReminder(CUSTOMER_ID, List.of(request), requestTrackingId);

    // Step - 4: Asserting response
    Assert.assertEquals(response.code(), 204);
  }

  /** This test covers CreateRefillReminder invalid request failure cases */
  @Test(
      description = "CreateRefillReminder - Invalid request failure",
      dataProvider = "createRefillReminderInvalidData")
  public void createRefillReminderInvalidRequestFailure(
      String rxNumber,
      String storeNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName)
      throws IOException {

    // Step - 1: Setting request tracking id for this call
    String requestTrackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();

    // Step - 2: Preparing request payload with invalid field
    CreateRefillReminderRequest request =
        buildCreateRefillReminderRequest(
            rxNumber, storeNumber, patientId, sourceActivityTs, status, drugName);

    // Step - 3: Calling create refill reminder API
    Response<ServiceResponseObject> response =
        rxServiceRetrofit.createRefillReminder(CUSTOMER_ID, List.of(request), requestTrackingId);

    Assert.assertEquals(response.code(), 400);
  }

  private CreateRefillReminderRequest buildCreateRefillReminderRequest(
      String rxNumber,
      String storeNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName) {

    CreateRefillReminderRequest request = new CreateRefillReminderRequest();
    request.setRxNumber(rxNumber);
    request.setStoreNumber(storeNumber);
    request.setPatientId(patientId);
    request.setSourceActivityTs(sourceActivityTs);
    request.setStatus(status);
    request.setDrugName(drugName);
    return request;
  }
}
