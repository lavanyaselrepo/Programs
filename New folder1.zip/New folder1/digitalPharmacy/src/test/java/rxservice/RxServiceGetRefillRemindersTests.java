package rxservice;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxservice.RxServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.pharmacy.dp.rx.service.restclient.model.CreateRefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RefillReminderResponse;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RequestEntityRefillReminderRequest;
import com.walmart.pharmacy.dp.rx.service.restclient.model.RxStatusUpdateRequestV2;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class RxServiceGetRefillRemindersTests {

  private static final Logger logger =
      LoggerFactory.getLogger(RxServiceGetRefillRemindersTests.class);

  private static final String STORE_NUMBER = "5524";
  private static final String DRUG_NAME_1 = "ARIPIPRAZOLE 30MG";
  private static final String DRUG_NAME_2 = "ASPRIN 30MG";
  private static final long SOURCE_ACTIVITY_TS = 1714000000000L;
  private static final String REQUEST_TRACKING_PREFIX = "req-tracking-";

  private RxServiceRetrofit rxServiceRetrofit;

  @BeforeClass
  void setContext() {
    rxServiceRetrofit = new RxServiceRetrofit();
  }

  // =========================================================================
  // Happy Path Tests (200 OK)
  // =========================================================================

  /**
   * TC-1.1: Single customer with one Pending RX returns 200 with correct RX details.
   */
  @Test(description = "GetRefillReminders - TC-1.1: Single customer with one Pending RX")
  public void getRefillRemindersSingleCustomerOnePendingRx() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    String requestTrackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();
    logger.info("[TC-1.1] Test data — customerId: {}, rxNumber: {}, trackingId: {}",
        customerId, rxNumber, requestTrackingId);

    // Step 1 - Set up one Pending record
    CreateRefillReminderRequest createRequest =
        buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1);
    rxServiceRetrofit.createRefillReminder(customerId, List.of(createRequest), requestTrackingId);

    // Step 2 - Call Get Refill Reminders API
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert response status and payload
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body(), "Response body must not be null for 200");
    Assert.assertNotNull(response.body().getPayload(), "Payload must not be null");

    // Step 4 - Assert customer entry exists with correct accountId and at least one RX
    var customerRefillsInfo = response.body().getPayload().getCustomerRefillsInfo();
    Assert.assertFalse(customerRefillsInfo.isEmpty(), "customerRefillsInfo must not be empty");
    var customerEntry = customerRefillsInfo.stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry, "Customer entry must be present");
    Assert.assertFalse(customerEntry.getRefillsDue().isEmpty(), "refillsDue must not be empty");
    Assert.assertEquals(customerEntry.getRefillsDue().getFirst().getRxNumber(), rxNumber);
  }

  /**
   * TC-1.2: Single customer with multiple Pending RXs returns 200 with all RXs.
   */
  @Test(description = "GetRefillReminders - TC-1.2: Single customer with multiple Pending RXs")
  public void getRefillRemindersSingleCustomerMultiplePendingRxs() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber1 = CommonUtil.generateRandomNumber(7);
    String rxNumber2 = CommonUtil.generateRandomNumber(7);
    String trackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();
    logger.info("[TC-1.2] Test data — customerId: {}, rxNumber1: {}, rxNumber2: {}, trackingId: {}",
        customerId, rxNumber1, rxNumber2, trackingId);

    // Step 1 - Set up two Pending records
    CreateRefillReminderRequest createRequest1 =
        buildCreateRequest(
            rxNumber1, STORE_NUMBER, rxNumber1,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1);
    CreateRefillReminderRequest createRequest2 =
        buildCreateRequest(
            rxNumber2, STORE_NUMBER, rxNumber1,
            SOURCE_ACTIVITY_TS + 1, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_2);
    rxServiceRetrofit.createRefillReminder(
        customerId, List.of(createRequest1, createRequest2), trackingId);

    // Step 2 - Call Get Refill Reminders API
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert 200 and two refills for the customer
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry, "Customer entry must be present");
    Assert.assertTrue(
        customerEntry.getRefillsDue().size() >= 2,
        "refillsDue must contain at least 2 RXs");
  }

  /**
   * TC-1.3: Multiple customers all with Pending RXs returns 200 with separate entries per customer.
   */
  @Test(description = "GetRefillReminders - TC-1.3: Multiple customers with Pending RXs")
  public void getRefillRemindersMultipleCustomers() throws IOException {

    // Generate distinct test data for this test case
    String primaryCustomerId = CommonUtil.randomUUID();
    String secondaryCustomerId = CommonUtil.randomUUID();
    String rxNumber1 = CommonUtil.generateRandomNumber(7);
    String rxNumber2 = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.3] Test data — primaryCustomerId: {}, secondaryCustomerId: {}, "
            + "rxNumber1: {}, rxNumber2: {}",
        primaryCustomerId, secondaryCustomerId, rxNumber1, rxNumber2);

    // Step 1 - Create one Pending record for each customer
    rxServiceRetrofit.createRefillReminder(
        primaryCustomerId,
        List.of(buildCreateRequest(
            rxNumber1, STORE_NUMBER, rxNumber1,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    rxServiceRetrofit.createRefillReminder(
        secondaryCustomerId,
        List.of(buildCreateRequest(
            rxNumber2, STORE_NUMBER, rxNumber2,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_2)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders for both customers
    Response<RefillReminderResponse> response =
        fetchRefillReminders(List.of(primaryCustomerId, secondaryCustomerId));

    // Step 3 - Assert 200 and two customer entries
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var infos = response.body().getPayload().getCustomerRefillsInfo();
    Assert.assertTrue(infos.size() >= 2, "Response must contain entries for both customers");
    Assert.assertTrue(
        infos.stream().anyMatch(c -> primaryCustomerId.equals(c.getCustomerInfo().getCustomerAccountId())),
        "primaryCustomerId must be in the response");
    Assert.assertTrue(
        infos.stream().anyMatch(c -> secondaryCustomerId.equals(c.getCustomerInfo().getCustomerAccountId())),
        "secondaryCustomerId must be in the response");
  }

  /**
   * TC-1.4: Multiple customers where only one has Pending RXs — only that customer appears in response.
   */
  @Test(description = "GetRefillReminders - TC-1.4: Only customer with Pending RXs appears in response")
  public void getRefillRemindersOnlyCustomerWithPendingRxAppears() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String emptyCustomerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.4] Test data — customerId: {}, emptyCustomerId: {}, rxNumber: {}",
        customerId, emptyCustomerId, rxNumber);

    // Step 1 - Create one Pending record for customerId
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders for both (emptyCustomerId has no Cosmos data)
    Response<RefillReminderResponse> response =
        fetchRefillReminders(List.of(customerId, emptyCustomerId));

    // Step 3 - Assert 200 and only customerId entry is present
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var infos = response.body().getPayload().getCustomerRefillsInfo();
    Assert.assertTrue(
        infos.stream().anyMatch(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId())),
        "customerId must appear in the response");
    Assert.assertTrue(
        infos.stream().noneMatch(c -> emptyCustomerId.equals(c.getCustomerInfo().getCustomerAccountId())),
        "Customer with no records must NOT appear in the response");
  }

  /**
   * TC-1.5: Mixed status (Pending + Complete) — only Pending RX appears in 200 response.
   */
  @Test(description = "GetRefillReminders - TC-1.5: Complete RX is excluded, only Pending RX returned")
  public void getRefillRemindersMixedStatusOnlyPendingReturned() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String pendingRxNumber = CommonUtil.generateRandomNumber(7);
    String completeRxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.5] Test data — customerId: {}, pendingRxNumber: {}, completeRxNumber: {}",
        customerId, pendingRxNumber, completeRxNumber);

    // Step 1 - Create one Pending and one Complete record
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(
            buildCreateRequest(
                pendingRxNumber, STORE_NUMBER, pendingRxNumber,
                SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1),
            buildCreateRequest(
                completeRxNumber, STORE_NUMBER, pendingRxNumber,
                SOURCE_ACTIVITY_TS + 1, CreateRefillReminderRequest.StatusEnum.COMPLETE, DRUG_NAME_2)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert 200 and only the Pending RX is present
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry);
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream().anyMatch(r -> pendingRxNumber.equals(r.getRxNumber())),
        "Pending RX must be in refillsDue");
    Assert.assertTrue(
        customerEntry.getRefillsDue().stream().noneMatch(r -> completeRxNumber.equals(r.getRxNumber())),
        "Complete RX must NOT be in refillsDue");
  }

  // =========================================================================
  // No Content Tests (204)
  // =========================================================================

  /**
   * TC-1.6: No Cosmos documents for the customer ID returns 204 with no response body.
   */
  @Test(description = "GetRefillReminders - TC-1.6: No documents for customer returns 204")
  public void getRefillRemindersNoDocumentsReturns204() throws IOException {

    // Generate distinct test data for this test case
    String unknownCustomerId = CommonUtil.randomUUID();
    logger.info("[TC-1.6] Test data — unknownCustomerId: {}", unknownCustomerId);

    // Step 1 - Call Get Refill Reminders for a brand-new UUID with no Cosmos documents
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(unknownCustomerId));

    // Step 2 - Assert 204 and no response body
    Assert.assertEquals(response.code(), 204);
    Assert.assertNull(response.body(), "Response body must be null for 204");
  }

  /**
   * TC-1.7: All RXs have Complete status returns 204.
   */
  @Test(description = "GetRefillReminders - TC-1.7: All RXs Complete returns 204")
  public void getRefillRemindersAllCompleteReturns204() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.7] Test data — customerId: {}, rxNumber: {}", customerId, rxNumber);

    // Step 1 - Create Complete records only
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.COMPLETE, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert 204
    Assert.assertEquals(response.code(), 204);
    Assert.assertNull(response.body(), "Response body must be null for 204");
  }

  /**
   * TC-1.8: Partial RX with partialSuccessTs within the last 24 hours returns 204.
   */
  @Test(description = "GetRefillReminders - TC-1.8: Recent Partial RX (< 24h) returns 204")
  public void getRefillRemindersRecentPartialRxReturns204() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.8] Test data — customerId: {}, rxNumber: {}", customerId, rxNumber);

    // Step 1 - Create a Pending record.
    //          The update API resolves the customer via {patientId}-{storeId} patient-link document,
    //          so patientId must equal rxNumber and storeNumber must be STORE_NUMBER.
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Update status to Partial via POST /v1/rx/refill/action/update.
    //          The service sets partialSuccessTs = System.currentTimeMillis() when refillStatus == Partial,
    //          guaranteeing the timestamp is fresh (< 24h) so the 24-hour gate will exclude this record.
    RxStatusUpdateRequestV2 updateRequest = new RxStatusUpdateRequestV2();
    updateRequest.setRxNumber(rxNumber);
    updateRequest.setPatientId(rxNumber);
    updateRequest.setStoreId(STORE_NUMBER);
    updateRequest.setSourceActivityTs(SOURCE_ACTIVITY_TS + 60000L);
    updateRequest.setRefillStatus(RxStatusUpdateRequestV2.RefillStatusEnum.PARTIAL);
    rxServiceRetrofit.updateRxStatus(updateRequest);

    // Step 3 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 4 - Assert 204 (fresh partialSuccessTs < 24h excludes the record)
    Assert.assertEquals(response.code(), 204);
    Assert.assertNull(response.body(), "Response body must be null for 204");
  }

  // =========================================================================
  // Validation Error Tests (400)
  // =========================================================================

  /**
   * TC-1.9: payload key is absent returns 400 with "Payload is mandatory".
   */
  @Test(description = "GetRefillReminders - TC-1.9: Absent payload returns 400")
  public void getRefillRemindersAbsentPayloadReturns400() throws IOException {

    // Step 1 - Build request with no payload set (payload defaults to null)
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = rxServiceRetrofit.getRefillReminders(request);

    // Step 3 - Assert 400
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * TC-1.10: payload value is null returns 400 with "Payload is mandatory".
   */
  @Test(description = "GetRefillReminders - TC-1.10: Null payload returns 400")
  public void getRefillRemindersNullPayloadReturns400() throws IOException {

    // Step 1 - Build request with explicitly null payload
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(null);

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = rxServiceRetrofit.getRefillReminders(request);

    // Step 3 - Assert 400
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * TC-1.11: customerAccountIds is null returns 400 with "customerAccountIds list is null".
   */
  @Test(description = "GetRefillReminders - TC-1.11: Null customerAccountIds returns 400")
  public void getRefillRemindersNullCustomerAccountIdsReturns400() throws IOException {

    // Step 1 - Build request with null customerAccountIds
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(null);
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = rxServiceRetrofit.getRefillReminders(request);

    // Step 3 - Assert 400
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * TC-1.12: customerAccountIds is empty returns 400 with "customerAccountIds list is empty".
   */
  @Test(description = "GetRefillReminders - TC-1.12: Empty customerAccountIds returns 400")
  public void getRefillRemindersEmptyCustomerAccountIdsReturns400() throws IOException {

    // Step 1 - Build request with empty customerAccountIds list
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(Collections.emptyList());
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = rxServiceRetrofit.getRefillReminders(request);

    // Step 3 - Assert 400
    Assert.assertEquals(response.code(), 400);
  }

  /**
   * TC-1.13: {@code customerAccountIds} list containing a {@code null} element returns 204.
   */
  @Test(description = "GetRefillReminders - TC-1.13: customerAccountIds with null element returns 204")
  public void getRefillRemindersNullElementInCustomerAccountIdsReturns400() throws IOException {

    // Step 1 - Build a request where customerAccountIds contains a single null element
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(Collections.singletonList(null));
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = rxServiceRetrofit.getRefillReminders(request);

    // Step 3 - Assert 204: a null element within the list must be rejected
    Assert.assertEquals(response.code(), 204,
        "customerAccountIds list containing a null element must return 204");
  }

  // =========================================================================
  // Edge Case Tests
  // =========================================================================

  /**
   * TC-1.14: Creating a refill reminder with null sourceActivityTs is rejected with 400.
   * The Create API enforces {@code @NotNull} on {@code sourceActivityTs}; no Cosmos document
   * is written, so a subsequent GET Refill Reminders must return 204 (no content).
   *
   * <p>NOTE: The "sourceActivityTs falls back to createTs" scenario cannot be exercised via the
   * standard API flow because the Create API never accepts a null sourceActivityTs. That
   * fallback path would only be reachable through a direct Cosmos write.
   */
  @Test(description = "GetRefillReminders - TC-1.14: Create with null sourceActivityTs returns 400; no document written")
  public void getRefillRemindersCreateWithNullSourceActivityTsReturns400() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    String requestTrackingId = REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID();
    logger.info("[TC-1.14] Test data — customerId: {}, rxNumber: {}, trackingId: {}",
        customerId, rxNumber, requestTrackingId);

    // Step 1 - Attempt to create a refill reminder with null sourceActivityTs.
    //          The @NotNull constraint on sourceActivityTs must reject the request.
    var createResponse = rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            null, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        requestTrackingId);

    // Step 2 - Assert 400: "sourceActivityTs can't be null"
    Assert.assertEquals(createResponse.code(), 400,
        "Create with null sourceActivityTs must return 400 — 'sourceActivityTs can''t be null'");

    // Step 3 - Confirm no document was written: GET must return 204
    Response<RefillReminderResponse> getResponse = fetchRefillReminders(List.of(customerId));
    Assert.assertEquals(getResponse.code(), 204,
        "No Cosmos document should exist after a rejected create; GET must return 204");
    Assert.assertNull(getResponse.body(), "Response body must be null for 204");
  }

  /**
   * TC-1.15: Non-null sourceActivityTs is returned directly in the response.
   */
  @Test(description = "GetRefillReminders - TC-1.15: Non-null sourceActivityTs is returned as-is")
  public void getRefillRemindersNonNullSourceActivityTsReturnedDirectly() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.15] Test data — customerId: {}, rxNumber: {}, sourceActivityTs: {}",
        customerId, rxNumber, SOURCE_ACTIVITY_TS);

    // Step 1 - Create a Pending record with a known sourceActivityTs
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert 200 and sourceActivityTs matches the stored value
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry);
    Assert.assertFalse(customerEntry.getRefillsDue().isEmpty());
    Assert.assertEquals(
        customerEntry.getRefillsDue().getFirst().getSourceActivityTs(),
        SOURCE_ACTIVITY_TS,
        "sourceActivityTs must equal the stored value");
  }

  /**
   * TC-1.16: storeNumber fields are correctly mapped (storeId as String, USStoreId as Integer,
   * onlineStoreFront = false).
   */
  @Test(description = "GetRefillReminders - TC-1.16: StoreNumber fields are correctly mapped")
  public void getRefillRemindersStoreNumberFieldsMappedCorrectly() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.16] Test data — customerId: {}, rxNumber: {}, storeNumber: {}",
        customerId, rxNumber, STORE_NUMBER);

    // Step 1 - Create a Pending record with store number "5524"
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert storeId, USStoreId and onlineStoreFront
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry);
    Assert.assertFalse(customerEntry.getRefillsDue().isEmpty());
    var storeNumber = customerEntry.getRefillsDue().getFirst().getStoreNumber();
    Assert.assertNotNull(storeNumber, "storeNumber must not be null");
    Assert.assertEquals(storeNumber.getStoreId(), STORE_NUMBER, "storeId must be the string '5524'");
    Assert.assertEquals(
        storeNumber.getUsStoreId(), Integer.parseInt(STORE_NUMBER),
        "USStoreId must be the integer 5524");
    // onlineStoreFront is always false per API contract; assert via the response JSON if the
    // generated model does not expose a getter for this field.
  }

  /**
   * TC-1.17: Results are correctly grouped by customerAccountId.
   * cid-1 has 2 RXs; cid-2 has 1 RX → response contains two separate entries.
   */
  @Test(description = "GetRefillReminders - TC-1.17: Results grouped by customerAccountId")
  public void getRefillRemindersResultsGroupedByCustomerAccountId() throws IOException {

    // Generate distinct test data for this test case
    String primaryCustomerId = CommonUtil.randomUUID();
    String secondaryCustomerId = CommonUtil.randomUUID();
    String rxNumber1 = CommonUtil.generateRandomNumber(7);
    String rxNumber2 = CommonUtil.generateRandomNumber(7);
    String rxNumber3 = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.17] Test data — primaryCustomerId: {}, secondaryCustomerId: {}, "
            + "rxNumber1: {}, rxNumber2: {}, rxNumber3: {}",
        primaryCustomerId, secondaryCustomerId, rxNumber1, rxNumber2, rxNumber3);

    // Step 1 - Create 2 Pending records for primaryCustomerId and 1 for secondaryCustomerId
    rxServiceRetrofit.createRefillReminder(
        primaryCustomerId,
        List.of(
            buildCreateRequest(
                rxNumber1, STORE_NUMBER, rxNumber1,
                SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1),
            buildCreateRequest(
                rxNumber2, STORE_NUMBER, rxNumber1,
                SOURCE_ACTIVITY_TS + 1, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_2)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());
    rxServiceRetrofit.createRefillReminder(
        secondaryCustomerId,
        List.of(buildCreateRequest(
            rxNumber3, STORE_NUMBER, rxNumber3,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_2)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders for both customers
    Response<RefillReminderResponse> response =
        fetchRefillReminders(List.of(primaryCustomerId, secondaryCustomerId));

    // Step 3 - Assert correct grouping: primary has >= 2 RXs, secondary has >= 1 RX
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var infos = response.body().getPayload().getCustomerRefillsInfo();

    var primaryEntry = infos.stream()
        .filter(c -> primaryCustomerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst().orElse(null);
    var secondaryEntry = infos.stream()
        .filter(c -> secondaryCustomerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst().orElse(null);

    Assert.assertNotNull(primaryEntry, "primaryCustomerId entry must exist");
    Assert.assertNotNull(secondaryEntry, "secondaryCustomerId entry must exist");
    Assert.assertTrue(primaryEntry.getRefillsDue().size() >= 2,
        "primaryCustomerId must have at least 2 refillsDue");
    Assert.assertFalse(secondaryEntry.getRefillsDue().isEmpty(),
        "secondaryCustomerId must have at least 1 refillDue");
  }

  /**
   * TC-1.18: Drug name in the response is raw/unmasked.
   */
  @Test(description = "GetRefillReminders - TC-1.18: Drug name is raw (not masked) in response")
  public void getRefillRemindersDrugNameIsNotMasked() throws IOException {

    // Generate distinct test data for this test case
    String customerId = CommonUtil.randomUUID();
    String rxNumber = CommonUtil.generateRandomNumber(7);
    logger.info("[TC-1.18] Test data — customerId: {}, rxNumber: {}, drugName: {}",
        customerId, rxNumber, DRUG_NAME_1);

    // Step 1 - Create a Pending record with a known drug name
    rxServiceRetrofit.createRefillReminder(
        customerId,
        List.of(buildCreateRequest(
            rxNumber, STORE_NUMBER, rxNumber,
            SOURCE_ACTIVITY_TS, CreateRefillReminderRequest.StatusEnum.PENDING, DRUG_NAME_1)),
        REQUEST_TRACKING_PREFIX + CommonUtil.randomUUID());

    // Step 2 - Call Get Refill Reminders
    Response<RefillReminderResponse> response = fetchRefillReminders(List.of(customerId));

    // Step 3 - Assert drug name is the exact (unmasked) value
    Assert.assertEquals(response.code(), 200);
    Assert.assertNotNull(response.body());
    var customerEntry = response.body().getPayload().getCustomerRefillsInfo().stream()
        .filter(c -> customerId.equals(c.getCustomerInfo().getCustomerAccountId()))
        .findFirst()
        .orElse(null);
    Assert.assertNotNull(customerEntry);
    Assert.assertFalse(customerEntry.getRefillsDue().isEmpty());
    var drug = customerEntry.getRefillsDue().getFirst().getDrug();
    Assert.assertNotNull(drug, "Drug list must not be null");
    Assert.assertFalse(drug.isEmpty(), "Drug list must not be empty");
    Assert.assertEquals(drug.getFirst().getDrugName(), DRUG_NAME_1,
        "Drug name must be raw/unmasked in the response");
  }

  // =========================================================================
  // Helper Methods
  // =========================================================================

  /**
   * Builds a {@link RequestEntityRefillReminderRequest} for the given customer IDs and calls
   * {@code getRefillReminders}.
   */
  private Response<RefillReminderResponse> fetchRefillReminders(List<String> customerAccountIds)
      throws IOException {
    RefillReminderRequest innerRequest = new RefillReminderRequest();
    innerRequest.setCustomerAccountIds(customerAccountIds);
    RequestEntityRefillReminderRequest request = new RequestEntityRefillReminderRequest();
    request.setPayload(innerRequest);
    return rxServiceRetrofit.getRefillReminders(request);
  }

  /**
   * Builds a {@link CreateRefillReminderRequest} from the supplied field values.
   */
  private CreateRefillReminderRequest buildCreateRequest(
      String rxNumber,
      String storeNumber,
      String patientId,
      Long sourceActivityTs,
      CreateRefillReminderRequest.StatusEnum status,
      String drugName) {
    CreateRefillReminderRequest request = new CreateRefillReminderRequest();
    request.setRxNumber(rxNumber);
    request.setStoreNumber(storeNumber);
    request.setPatientId(patientId);
    request.setSourceActivityTs(sourceActivityTs);
    request.setStatus(status);
    request.setDrugName(drugName);
    return request;
  }
}

