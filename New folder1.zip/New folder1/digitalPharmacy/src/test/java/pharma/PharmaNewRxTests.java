package pharma;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.models.createStoreOrder.PharmaCreateStoreOrderRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.models.createStoreOrder.PharmaCreateStoreOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.pharma.restapi.PharmaRetrofit;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class PharmaNewRxTests {

    private PharmaRetrofit pharmaRetrofit;
    private final ObjectMapper mapper = new ObjectMapper();

    private String commonBuyerId = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";

    @BeforeClass
    void setContext() {
        pharmaRetrofit = new PharmaRetrofit();
    }

    @Test(
            priority = 0,
            description = "Create New Rx Order")
    private void createNewRxStoreOrder()
            throws IOException {
        PharmaCreateStoreOrderRequest pharmaCreateStoreOrderRequest = mapper.readValue(
                new File(
                        "src/test/resources/testdata/digitalpharmacy/pharma/createStoreOrder/createNewRxStoreOrder.json"),
                PharmaCreateStoreOrderRequest.class);

        pharmaCreateStoreOrderRequest.getPayload().getPrescriptionDetails().get(0).getPatientInfo().setPatientCustomerAccountId(UUID.fromString(commonBuyerId));

        Date tomorrow = new Date(new Date().getTime() + 86400000);
        String pickupDate = new SimpleDateFormat("MMddyyyy").format(tomorrow);
        pharmaCreateStoreOrderRequest.getPayload().getPickupOrderDetails().getPickupDateTime().setPickupDate(pickupDate);

        Response<PharmaCreateStoreOrderResponse> pharmaCreateStoreOrderResponse = null;
        for (int i = 0; i < 3; i++) {
            pharmaCreateStoreOrderResponse = pharmaRetrofit.createStoreOrder(pharmaCreateStoreOrderRequest);
            if (!(pharmaCreateStoreOrderResponse.code() == 200
                    && pharmaCreateStoreOrderResponse.body() != null
                    && pharmaCreateStoreOrderResponse.body().getPayload() != null)
                    && pharmaCreateStoreOrderResponse.body().getStatus() != "OK") {
                Reporter.logJSON("Exception", pharmaCreateStoreOrderResponse.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "Pharma create Store Order failed. HttpStatusCode : " + pharmaCreateStoreOrderResponse.code());
                }
            } else break;
        }

        PharmaCreateStoreOrderResponse body = pharmaCreateStoreOrderResponse.body();
        Assert.assertEquals(body.getStatus(),"OK");
        assert body.getPayload().getOrderNo() != null;
    }
}
