package insuranceorchestrator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Gender;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.BomTestDataSetupRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetinsuranceByPatientInfo.GetInsuranceDetailsByPatientInfoRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetinsuranceByPatientInfo.GetInsuranceDetailsByPatientInfoV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetInsuranceDetailsByPatientInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.fetchAndValidateIToken.InsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
public class GetInsuranceDetailsByPatientInfoV1Tests {
    private InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private ObjectMapper objectMapper;

    private String firstName = CommonUtil.generateRandomFirstName(8);
    private String lastName = CommonUtil.generateRandomFirstName(8);
    private String zipCode = "33411";
    private String city = "Royal Palm Beach";
    private String addressLineOne = "178 Paradise Crescent";
    private String stateOrProvinceCode = "FL";
    private String dobyyyyMMdd = "19960101";
    private String gender = "M";
    private String storeId = "9989";
    private String groupId = "YJSS0";
    private String customerId ;

    @BeforeClass
    public void setContext() throws IOException {
        objectMapper = new ObjectMapper();
        BomTestDataSetupRequest bomTestDataSetupRequest = getBomTestDataSetupRequest(firstName, lastName, dobyyyyMMdd, gender, addressLineOne, city, zipCode, stateOrProvinceCode, storeId, "US", CARDHOLDER_ID, groupId, BIN_NUMBER, PCN);

        String bomTestDataSetupRequestJson = objectMapper.writeValueAsString(bomTestDataSetupRequest);
        insuranceWrapper.setupBomTestData(bomTestDataSetupRequestJson);

        customerId = CommonUtil.generateRandomFirstName(36);


    }
    @Test
    public void getInsuranceByPatientInfoV1ValidTest() throws IOException{
        GetInsuranceDetailsByPatientInfoV1Request getInsuranceByPatientInfoV1Request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String getInsuranceByPatientInfoV1RequestJson = objectMapper.writeValueAsString(getInsuranceByPatientInfoV1Request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, getInsuranceByPatientInfoV1RequestJson);
        Assert.assertNotNull(serviceResponse);
        GetInsuranceDetailsByPatientInfoV1Response getInsuranceByPatientInfoV1Response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);

        String validationToken = getInsuranceByPatientInfoV1Response.getInsuranceInfo().get(0).getValidationToken();
        Assert.assertNotNull(getInsuranceByPatientInfoV1Response);
        Assert.assertEquals(200, serviceResponse.getStatusCode());

        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        JsonNode root = objectMapper.readTree(decryptTokenServiceResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull(insuranceInfo);
        Assert.assertEquals(insuranceInfo.getCustomerId(),customerId);
        Assert.assertEquals(insuranceInfo.getCardHolderId(), CARDHOLDER_ID);
        Assert.assertEquals(insuranceInfo.getCustomerId(),customerId);
        Assert.assertEquals(insuranceInfo.getPersonCode(), "1");
        Assert.assertEquals(insuranceInfo.getRxGroup(),groupId);
        Assert.assertEquals(insuranceInfo.getRxBin(), BIN_NUMBER);
        Assert.assertEquals(insuranceInfo.getRxPCN(), PCN);
    }
    @Test
    public void getInsuranceByPatientInfoV1customerIdMismatchTest() throws IOException{
        GetInsuranceDetailsByPatientInfoV1Request getInsuranceByPatientInfoV1Request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String getInsuranceByPatientInfoV1RequestJson = objectMapper.writeValueAsString(getInsuranceByPatientInfoV1Request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, getInsuranceByPatientInfoV1RequestJson);
        Assert.assertNotNull(serviceResponse);
        GetInsuranceDetailsByPatientInfoV1Response getInsuranceByPatientInfoV1Response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        String validationToken = getInsuranceByPatientInfoV1Response.getInsuranceInfo().get(0).getValidationToken();
        Assert.assertNotNull(getInsuranceByPatientInfoV1Response);
        Assert.assertEquals(200, serviceResponse.getStatusCode());
        String randomCustomerId = CommonUtil.generateRandomFirstName(36);
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(randomCustomerId, validationToken);
        Assert.assertEquals(400, decryptTokenServiceResponse.getStatusCode());
    }

    @Test
    public void getInsuranceByPatientInfoV1invalidTokenTest() throws IOException{
        GetInsuranceDetailsByPatientInfoV1Request getInsuranceByPatientInfoV1Request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String getInsuranceByPatientInfoV1RequestJson = objectMapper.writeValueAsString(getInsuranceByPatientInfoV1Request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, getInsuranceByPatientInfoV1RequestJson);
        Assert.assertNotNull(serviceResponse);
        GetInsuranceDetailsByPatientInfoV1Response getInsuranceByPatientInfoV1Response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        String validationToken = getInsuranceByPatientInfoV1Response.getInsuranceInfo().get(0).getValidationToken();
        Assert.assertNotNull(getInsuranceByPatientInfoV1Response);
        Assert.assertEquals(200, serviceResponse.getStatusCode());
        validationToken+='d';
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals(500, decryptTokenServiceResponse.getStatusCode());
    }

    @Test
    public void getInsuranceByPatientInfoV1NullTokenTest() throws IOException{
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, "");
        Assert.assertEquals(400, decryptTokenServiceResponse.getStatusCode());
    }

    // ========================================================================
    // NEW TESTS — Input Validation, Response Verification, Edge Cases
    // ========================================================================

    // ========================
    // V1 RESPONSE FIELD VERIFICATION
    // ========================

    @Test(description = "V1: verify response contains validationToken, masked cardHolderId, processorName, isWalmartEligible")
    public void getInsuranceByPatientInfoV1ResponseFieldsTest() throws IOException {
        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String requestJson = objectMapper.writeValueAsString(request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, requestJson);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceDetailsByPatientInfoV1Response response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertFalse("Should have at least one insurance", response.getInsuranceInfo().isEmpty());

        GetInsuranceDetailsByPatientInfoV1Response.InsuranceInfo info = response.getInsuranceInfo().get(0);
        Assert.assertNotNull("ValidationToken must be present", info.getValidationToken());
        Assert.assertNotNull("CardHolderId must be present", info.getCardHolderId());
        Assert.assertNotNull("ProcessorName must be present", info.getProcessorName());
        Assert.assertNotNull("IsWalmartEligible must be present", info.getIsWalmartEligible());
    }

    @Test(description = "V1: verify cardHolderId is masked with asterisks and differs from original")
    public void getInsuranceByPatientInfoV1CardHolderIdMaskedTest() throws IOException {
        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String requestJson = objectMapper.writeValueAsString(request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, requestJson);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceDetailsByPatientInfoV1Response response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        String maskedCardHolderId = response.getInsuranceInfo().get(0).getCardHolderId();
        Assert.assertNotNull("CardHolderId should not be null", maskedCardHolderId);
        Assert.assertTrue("CardHolderId should be masked with asterisks", maskedCardHolderId.contains("*"));
        Assert.assertNotEquals("Masked cardHolderId should differ from original", CARDHOLDER_ID, maskedCardHolderId);
    }

    // ========================
    // RDM CROSS-VALIDATION
    // ========================

    @Test(description = "V1: cross-validate decrypted token processorName with RDM lookup")
    public void getInsuranceByPatientInfoV1CrossValidateRDMTest() throws IOException {
        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String requestJson = objectMapper.writeValueAsString(request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, requestJson);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceDetailsByPatientInfoV1Response response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        String validationToken = response.getInsuranceInfo().get(0).getValidationToken();

        // Decrypt token
        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals("Expected HTTP 200 for token decryption", 200, decryptResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(decryptResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);

        // Cross-validate with RDM directly
        ServiceResponse rdmResponse = insuranceWrapper.getRDM(BIN_NUMBER, PCN);
        Assert.assertEquals("RDM should return 200", 200, rdmResponse.getStatusCode());

        JsonNode rdmRoot = objectMapper.readTree(rdmResponse.getDataResponse());
        Assert.assertEquals("ProcessorName should match RDM",
                rdmRoot.get("processorName").asText(), insuranceInfo.getProcessorName());
    }

    // ========================
    // INPUT VALIDATION TESTS (400 errors)
    // ========================

    @Test(description = "V1: Verify 400 when customerInfo is null")
    public void getInsuranceByPatientInfoV1MissingCustomerInfoTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing customerInfo", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when firstName is missing")
    public void getInsuranceByPatientInfoV1MissingFirstNameTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing firstName", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when lastName is missing")
    public void getInsuranceByPatientInfoV1MissingLastNameTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing lastName", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when birthdate is missing")
    public void getInsuranceByPatientInfoV1MissingBirthdateTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing birthdate", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when gender is missing")
    public void getInsuranceByPatientInfoV1MissingGenderTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing gender", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when address is missing")
    public void getInsuranceByPatientInfoV1MissingAddressTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing address", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when addressLineOne is missing")
    public void getInsuranceByPatientInfoV1MissingAddressLineOneTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing addressLineOne", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when city is missing")
    public void getInsuranceByPatientInfoV1MissingCityTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing city", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when stateOrProvinceCode is missing")
    public void getInsuranceByPatientInfoV1MissingStateTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("zipCode", zipCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing stateOrProvinceCode", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify 400 when zipCode is missing")
    public void getInsuranceByPatientInfoV1MissingZipCodeTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing zipCode", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // EDGE CASES
    // ========================

    @Test(description = "V1: Verify 500 when customerId is empty - Spring routing error")
    public void getInsuranceByPatientInfoV1EmptyCustomerIdTest() throws IOException {
        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                firstName, lastName, Integer.parseInt(dobyyyyMMdd), gender, addressLineOne, city, zipCode, stateOrProvinceCode, Integer.parseInt(storeId));
        String requestJson = objectMapper.writeValueAsString(request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1("", requestJson);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // Empty customerId causes Spring NoResourceFoundException (URL becomes /v1/customer/insurance/action/...)
        Assert.assertEquals("Expected HTTP 500 for empty customerId", 500, serviceResponse.getStatusCode());
    }

    @Test(description = "V1: Verify lookup succeeds with storeNumber=null - uses default store from CCM")
    public void getInsuranceByPatientInfoV1NullStoreNumberTest() throws IOException {
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", firstName);
                put("lastName", lastName);
                put("birthdate", Integer.parseInt(dobyyyyMMdd));
                put("gender", gender);
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", addressLineOne);
                    put("city", city);
                    put("stateOrProvinceCode", stateOrProvinceCode);
                    put("zipCode", zipCode);
                }});
            }});
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(customerId, payload);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // storeNumber is optional, service uses default store from CCM
        Assert.assertTrue("Expected HTTP 200 or 204",
                serviceResponse.getStatusCode() == 200 || serviceResponse.getStatusCode() == 204);
    }

    @Test(description = "V1: Verify error response for non-existent patient without BOM seeding")
    public void getInsuranceByPatientInfoV1NonExistentPatientTest() throws IOException {
        String randomFirstName = CommonUtil.generateRandomFirstName(8);
        String randomLastName = CommonUtil.generateRandomFirstName(8);
        String randomCustomerId = CommonUtil.generateRandomFirstName(36);

        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                randomFirstName, randomLastName, 19750101, "F", "999 Nonexistent Street", "Nowhere", "00000", "TX", 9989);
        String requestJson = objectMapper.writeValueAsString(request);

        // No BOM setup for this patient — BOM should return "subscriber not found"
        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(randomCustomerId, requestJson);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertTrue("Expected error for non-existent patient (204 or 400 or 500)",
                serviceResponse.getStatusCode() != 200);
    }

    // ========================
    // MULTIPLE PAYER TEST
    // ========================

    @Test(description = "V1: Verify multiple insurance records when BOM setup has numberOfPayer > 1")
    public void getInsuranceByPatientInfoV1MultiplePayersTest() throws IOException {
        String multiPayerFirstName = CommonUtil.generateRandomFirstName(8);
        String multiPayerLastName = CommonUtil.generateRandomFirstName(8);
        String multiPayerCustomerId = CommonUtil.generateRandomFirstName(36);

        BomTestDataSetupRequest singlePayerRequest = getBomTestDataSetupRequest(
                multiPayerFirstName, multiPayerLastName, "19880515", "F",
                "456 Oak Avenue", "Tampa", "33602", "FL",
                storeId, "US", CARDHOLDER_ID, groupId, BIN_NUMBER, PCN);

        // Override numberOfPayer to 2
        BomTestDataSetupRequest multiPayerRequest = BomTestDataSetupRequest.builder()
                .request(singlePayerRequest.getRequest())
                .numberOfPayer(2)
                .cardholderId(Arrays.asList(CARDHOLDER_ID, "348201800"))
                .groupId(Arrays.asList(groupId, groupId))
                .iin(Arrays.asList(BIN_NUMBER, BIN_NUMBER))
                .pcn(Arrays.asList(PCN, PCN))
                .build();

        String bomJson = objectMapper.writeValueAsString(multiPayerRequest);
        insuranceWrapper.setupBomTestData(bomJson);

        GetInsuranceDetailsByPatientInfoV1Request request = buildGetInsuranceDetailsByPatientInfoV1Request(
                multiPayerFirstName, multiPayerLastName, 19880515, "F",
                "456 Oak Avenue", "Tampa", "33602", "FL", Integer.parseInt(storeId));
        String requestJson = objectMapper.writeValueAsString(request);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV1(multiPayerCustomerId, requestJson);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceDetailsByPatientInfoV1Response response = serviceResponse.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertTrue("Should have multiple insurance records for multiple payers",
                response.getInsuranceInfo().size() >= 2);

        // Verify each record has all V1 fields
        for (GetInsuranceDetailsByPatientInfoV1Response.InsuranceInfo info : response.getInsuranceInfo()) {
            Assert.assertNotNull("ValidationToken should not be null for any record", info.getValidationToken());
            Assert.assertNotNull("CardHolderId should not be null for any record", info.getCardHolderId());
            Assert.assertTrue("CardHolderId should be masked", info.getCardHolderId().contains("*"));
        }
    }

        private static BomTestDataSetupRequest getBomTestDataSetupRequest(
            String firstName,
            String lastName,
            String dob,
            String gender,
            String addressLine1,
            String city,
            String postalCode,
            String state,
            String storeNbr,
            String storeCountryCode,
            String cardholderId,
            String groupId,
            String iin,
            String pcn
    ){
        BomTestDataSetupRequest.Address address = BomTestDataSetupRequest.Address.builder()
                .addressLine1(addressLine1)
                .city(city)
                .postalCode(postalCode)
                .state(state)
                .build();
        BomTestDataSetupRequest.Patient patient = BomTestDataSetupRequest.Patient.builder()
                .lastName(lastName)
                .firstName(firstName)
                .birthdate(dob)
                .gender(gender)
                .address(address)
                .build();

        BomTestDataSetupRequest.Request request = BomTestDataSetupRequest.Request.builder()
                .patient(patient)
                .storeNbr(storeNbr)
                .storeCountryCode(storeCountryCode)
                .build();

        return BomTestDataSetupRequest.builder()
                .request(request)
                .numberOfPayer(1)
                .cardholderId(Collections.singletonList(cardholderId))
                .groupId(Collections.singletonList(groupId))
                .iin(Collections.singletonList(iin))
                .pcn(Collections.singletonList(pcn))
                .build();
    }
    private static GetInsuranceDetailsByPatientInfoV1Request buildGetInsuranceDetailsByPatientInfoV1Request(
            String firstName,
            String lastName,
            Integer birthdate,
            String gender,
            String addressLineOne,
            String city,
            String zipCode,
            String stateOrProvinceCode,
            Integer storeNumber
    ) {
        GetInsuranceDetailsByPatientInfoRequest.Address address = GetInsuranceDetailsByPatientInfoRequest.Address.builder()
                .addressLineOne(addressLineOne)
                .city(city)
                .zipCode(zipCode)
                .stateOrProvinceCode(stateOrProvinceCode)
                .build();

        GetInsuranceDetailsByPatientInfoRequest.CustomerInfo customerInfo = GetInsuranceDetailsByPatientInfoRequest.CustomerInfo.builder()
                .firstName(firstName)
                .lastName(lastName)
                .birthdate(birthdate)
                .gender(Gender.valueOf(gender))
                .address(address)
                .build();

        return GetInsuranceDetailsByPatientInfoV1Request.builder()
                .customerInfo(customerInfo)
                .storeNumber(storeNumber)
                .build();
    }

}
