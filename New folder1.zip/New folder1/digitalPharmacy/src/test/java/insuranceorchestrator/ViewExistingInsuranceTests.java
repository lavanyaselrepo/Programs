package insuranceorchestrator;

import accountorchestrator.utils.CommonAccountHelper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.ReplaceInsurance.ReplaceInsuranceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.RDMResponse.RDMGetPlanByCarrierIdPlanIdResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.CustomerInsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.InsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.ViewExistingInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.ViewExistingInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.annotations.BeforeClass;
import java.util.*;

import static org.junit.Assert.*;


public class ViewExistingInsuranceTests {

    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();

    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private CARetrofit caRetrofit;
    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private static final Integer CARRIER_ID = 100426;
    private static final Integer PLAN_ID = 171;
    private static final Integer CATEGORY = 1006;

    private static final String BIN_NUMBER_2 = "601574";
    private static final String PCN_2 = null;
    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;


    private static final String CARDHOLDER_ID_3 = "33653564542";
    private static final Integer CARRIER_ID_3 = 123495;
    private static final Integer PLAN_ID_3 = 127;
    private static final Integer CATEGORY_3 = 1006;

    private static final String CARDHOLDER_ID_4 = "WMTINS12390";
    private static final Integer CARRIER_ID_4 = 121312;
    private static final Integer PLAN_ID_4 = 127;
    private static final Integer CATEGORY_4 = 1000;

    private static final String DISCOUNT_BIN_NUMBER = "808412";
    private static final String DISCOUNT_PCN = "45370";
    private static final String DISCOUNT_CARDHOLDER_ID = "12331892332";
    private static final Integer DISCOUNT_CARRIER_ID = 116135;
    private static final Integer DISCOUNT_PLAN_ID = 179;
    private static final Integer DISCOUNT_CATEGORY = 1005;

    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private ObjectMapper objectMapper;

    @BeforeClass
    void setContext() throws IOException {
        accountDbContext =
                AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        caRetrofit =  new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();
    }

    @Test(description = "View existing insurance with non null lastAdjudicatedTs", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithNonNullLastAdjudicatedTs(String customerId, String addInsurancePayload, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsurance) {
        Reporter.logJSON("Customer Account Id", customerId);

        ServiceResponse serviceResponse = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
        assertEquals(serviceResponse.getStatusCode(), statusCode);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse = serviceResponse.getDataResponse(ViewExistingInsuranceResponse.class);
        assertFalse(viewExistingInsuranceResponse.getCustomerInsuranceInfo().isEmpty());

        for(CustomerInsuranceInfo customerInsuranceInfo: viewExistingInsuranceResponse.getCustomerInsuranceInfo()) {
            assertFalse(customerInsuranceInfo.getInsuranceInfo().isEmpty());
            for(InsuranceInfo insuranceInfo: customerInsuranceInfo.getInsuranceInfo()) {
                Assert.assertNotNull(insuranceInfo.getBillingSeqNbr());
                Assert.assertNotNull(insuranceInfo.getLastChangeTs());
                assertFalse(insuranceInfo.getIRefIds().isEmpty());
            }
        }

    }

    @Test(description = "viewExistingInsurance with valid CID and with lookUpCID of adult dependent and without getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithLookUpCID_1(String customerId, String addInsurancePayload, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsurance) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.updateInsurance(updateInsurance, customerId);
        //Thread.sleep(10000);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAdd = insuranceWrapper.addInsurance(addInsurancePayload, customerId);
        assertEquals(serResAdd.getStatusCode(), 200);

        //Thread.sleep(10000);
        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            assertEquals(serRes.getStatusCode(), statusCode);

            // Step - 5: Validate response body of ViewExistingInsurance API
            validateAddedInsurance(lookUpCID, addInsurancePayload, viewExistingInsuranceResponse);

        } finally {
            ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurance, customerId);
            assertEquals(serResUpdate.getStatusCode(),200);
        }
    }

    private void validateAddedInsurance(
            String customerAccountId,
            String addedInsuranceJsonStr,
            ViewExistingInsuranceResponse viewExistingInsuranceResponse
    ) {
        DocumentContext jsonToParse = JsonPath.parse(addedInsuranceJsonStr);
        int i = 0;

        Optional<CustomerInsuranceInfo> customerInsuranceInfoOptional = viewExistingInsuranceResponse.getCustomerInsuranceInfo().stream().filter(cii -> cii.getCustomerId().equalsIgnoreCase(customerAccountId)).findAny();
        Assert.assertTrue(customerInsuranceInfoOptional.isPresent());

        Optional<com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.InsuranceInfo> insuranceResOptional = customerInsuranceInfoOptional.get().getInsuranceInfo().stream().filter(insuranceInfo -> insuranceInfo.getCardholderId().equalsIgnoreCase(jsonToParse.read("$.insuranceInfo[" + i + "].cardholderId"))).findAny();
        Assert.assertTrue(insuranceResOptional.isPresent());
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.InsuranceInfo insuranceView = insuranceResOptional.get();

        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].cardholderId"), insuranceView.getCardholderId());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].cardholderFirstName"), insuranceView.getCardholderFirstName());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].cardholderLastName"), insuranceView.getCardholderLastName());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].relation"), insuranceView.getRelation());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].rxBin"), insuranceView.getRxBin());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].rxPCN"), insuranceView.getRxPCN());
        assertEquals(jsonToParse.read("$.insuranceInfo[" + i + "].rxGroup"), insuranceView.getRxGroup());
        Assert.assertNotNull(insuranceView.getBillingSeqNbr());
        Assert.assertNotNull(insuranceView.getLastChangeTs());
        Assert.assertNull(insuranceView.getLastAdjudicationTs());
        assertFalse(insuranceView.getIRefIds().isEmpty());

        ServiceResponse serResRDM = insuranceWrapper.getRDMInsuranceByCarrierIdAndPlanId(jsonToParse.read("$.insuranceInfo[" + i + "].carrierId"), jsonToParse.read("$.insuranceInfo[" + i + "].planId"));
        RDMGetPlanByCarrierIdPlanIdResponse rdmResponse = serResRDM.getDataResponse(RDMGetPlanByCarrierIdPlanIdResponse.class);

        String expectedProcessorName = null;
        if(rdmResponse.getClaimFormat() != null)
            expectedProcessorName = rdmResponse.getClaimFormat().getProcessorName();

        assertEquals(expectedProcessorName, insuranceView.getProcessorName());
        assertEquals(rdmResponse.getBasicInformation().getPharmaceuticalCompanyName().trim(), insuranceView.getCarrierName());
        assertEquals(rdmResponse.getBasicInformation().getInsuranceCarrierPlanName().trim(), insuranceView.getPlanName());
        assertEquals(rdmResponse.getBasicInformation().getPaddedBinNbr(), insuranceView.getRxBin());
        assertEquals(rdmResponse.getBasicInformation().getProcessorControlNumber(), insuranceView.getRxPCN());

        assertEquals(insuranceView.getCoverageInd(), "Y");
    }

    @Test(description = "viewExistingInsurance with valid CID and with lookUpCID of minor dependent and without getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithLookUpCID_2(String customerId, String addInsurancePayload, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsurance) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.updateInsurance(updateInsurance, customerId);
        //Thread.sleep(10000);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAdd = insuranceWrapper.addInsurance(addInsurancePayload, customerId);
        assertEquals(serResAdd.getStatusCode(), 200);
        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            Assert.assertTrue(serRes.getStatusCode() == statusCode);

            validateAddedInsurance(lookUpCID, addInsurancePayload, viewExistingInsuranceResponse);
        } finally {
            ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurance, customerId);
            assertEquals(serResUpdate.getStatusCode(),200);
        }
    }

    @Test(description = "viewExistingInsurance with valid CID and with lookUpCID of caregiver and with  getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithLookUpCIDandGetForDependents_1(String customerId, String addInsurancePayloadCaregiver, String addInsurancePayloadAdultDependent, String addInsurancePayloadMinorDependent, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsuranceCaregiver, String updateInsuranceAdultDependent, String updateInsuranceMinorDependent) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
        //Thread.sleep(10000);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAddCaregiver = insuranceWrapper.addInsurance(addInsurancePayloadCaregiver, customerId);
        assertEquals(serResAddCaregiver.getStatusCode(), 200);
        ServiceResponse serResAddAdultDependent = insuranceWrapper.addInsurance(addInsurancePayloadAdultDependent, customerId);
        assertEquals(serResAddAdultDependent.getStatusCode(), 200);
        ServiceResponse serResAddMinorDependent = insuranceWrapper.addInsurance(addInsurancePayloadMinorDependent, customerId);
        assertEquals(serResAddMinorDependent.getStatusCode(), 200);

        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            assertEquals(statusCode, serRes.getStatusCode());

            // Step - 5: Validate response body of ViewExistingInsurance API
            int noOfCustomers = viewExistingInsuranceResponse.getCustomerInsuranceInfo().size();

            for (int i = 0; i < noOfCustomers; i++) {
                String firstName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getFirstName();
                String middleName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getMiddleName();
                String lastName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getLastName();
                String customerType = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType();

                Assert.assertTrue(customerNames.contains(firstName + " " + middleName + " " + lastName + " - " + customerType));
                if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadAdultDependent,
                            viewExistingInsuranceResponse
                            );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && !viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadCaregiver,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("MINOR")) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadMinorDependent,
                            viewExistingInsuranceResponse
                    );
                }
            }
        } finally {
            //Thread.sleep(5000);
            ServiceResponse serResUpdateCaregiver = insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
            assertEquals(serResUpdateCaregiver.getStatusCode(),200);
            ServiceResponse serResUpdateAdultDependent = insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
            assertEquals(serResUpdateAdultDependent.getStatusCode(),200);
            ServiceResponse serResUpdateMinorDependent = insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
            assertEquals(serResUpdateMinorDependent.getStatusCode(),200);
        }
    }

    @Test(description = "viewExistingInsurance with valid CID and with lookUpCID of MINOR DEPENDENT and with  getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithLookUpCIDandGetForDependents_2(String customerId, String addInsurancePayloadCaregiver, String addInsurancePayloadAdultDependent, String addInsurancePayloadMinorDependent, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsuranceCaregiver, String updateInsuranceAdultDependent, String updateInsuranceMinorDependent) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
        //Thread.sleep(10000);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAddCaregiver = insuranceWrapper.addInsurance(addInsurancePayloadCaregiver, customerId);
        ServiceResponse serResAddAdultDependent = insuranceWrapper.addInsurance(addInsurancePayloadAdultDependent, customerId);
        ServiceResponse serResAddMinorDependent = insuranceWrapper.addInsurance(addInsurancePayloadMinorDependent, customerId);

        assertEquals(serResAddCaregiver.getStatusCode(), 200);
        assertEquals(serResAddAdultDependent.getStatusCode(), 200);
        assertEquals(serResAddMinorDependent.getStatusCode(), 200);

        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            assertEquals(statusCode, serRes.getStatusCode());

            // Step - 5: Validate response body of ViewExistingInsurance API
            int noOfCustomers = viewExistingInsuranceResponse.getCustomerInsuranceInfo().size();


            for (int i = 0; i < noOfCustomers; i++) {
                String firstName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getFirstName();
                String middleName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getMiddleName();
                String lastName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getLastName();
                String customerType = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType();
                Assert.assertTrue(customerNames.contains(firstName + " " + middleName + " " + lastName + " - " + customerType));
                if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadAdultDependent,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && !viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadCaregiver,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("MINOR")) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadMinorDependent,
                            viewExistingInsuranceResponse
                    );
                }
            }
        } finally {
            //Thread.sleep(5000);
            ServiceResponse serResUpdateCaregiver = insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
            assertEquals(serResUpdateCaregiver.getStatusCode(),200);
            ServiceResponse serResUpdateAdultDependent = insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
            assertEquals(serResUpdateAdultDependent.getStatusCode(),200);
            ServiceResponse serResUpdateMinorDependent = insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
            assertEquals(serResUpdateMinorDependent.getStatusCode(),200);
        }
    }

    @Test(description = "viewExistingInsurance with valid CID and with lookUpCID of ADULT DEPENDENT and with  getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithLookUpCIDandGetForDependents_3(String customerId, String addInsurancePayloadCaregiver, String addInsurancePayloadAdultDependent, String addInsurancePayloadMinorDependent, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsuranceCaregiver, String updateInsuranceAdultDependent, String updateInsuranceMinorDependent) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
        insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
        //Thread.sleep(10000);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAddCaregiver = insuranceWrapper.addInsurance(addInsurancePayloadCaregiver, customerId);
        ServiceResponse serResAddAdultDependent = insuranceWrapper.addInsurance(addInsurancePayloadAdultDependent, customerId);
        ServiceResponse serResAddMinorDependent = insuranceWrapper.addInsurance(addInsurancePayloadMinorDependent, customerId);

        assertEquals(serResAddCaregiver.getStatusCode(), 200);
        assertEquals(serResAddAdultDependent.getStatusCode(), 200);
        assertEquals(serResAddMinorDependent.getStatusCode(), 200);

        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            Assert.assertTrue(serRes.getStatusCode() == statusCode);

            // Step - 5: Validate response body of ViewExistingInsurance API
            int noOfCustomers = viewExistingInsuranceResponse.getCustomerInsuranceInfo().size();


            for (int i = 0; i < noOfCustomers; i++) {
                String firstName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getFirstName();
                String middleName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getMiddleName();
                String lastName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getLastName();
                String customerType = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType();
                Assert.assertTrue(customerNames.contains(firstName + " " + middleName + " " + lastName + " - " + customerType));
                if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadAdultDependent,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && !viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadCaregiver,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("MINOR")) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadMinorDependent,
                            viewExistingInsuranceResponse
                    );
                }
            }
        } finally {
            //Thread.sleep(5000);
            ServiceResponse serResUpdateCaregiver = insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
            assertEquals(serResUpdateCaregiver.getStatusCode(),200);
            ServiceResponse serResUpdateAdultDependent = insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
            assertEquals(serResUpdateAdultDependent.getStatusCode(),200);
            ServiceResponse serResUpdateMinorDependent = insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
            assertEquals(serResUpdateMinorDependent.getStatusCode(),200);
        }
    }

    @Test(description = "viewExistingInsurance with valid CID and without lookUpCID and with  getForDependents", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceValidTestWithoutLookUpCIDandGetForDependents(String customerId, String addInsurancePayloadCaregiver, String addInsurancePayloadAdultDependent, String addInsurancePayloadMinorDependent, int statusCode, String customerNames, String lookUpCID, boolean getForDependents, String updateInsuranceCaregiver, String updateInsuranceAdultDependent, String updateInsuranceMinorDependent) throws IOException, InterruptedException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Adding Insurance for the CID
        ServiceResponse serResAddCaregiver = insuranceWrapper.addInsurance(addInsurancePayloadCaregiver, customerId);
        ServiceResponse serResAddAdultDependent = insuranceWrapper.addInsurance(addInsurancePayloadAdultDependent, customerId);
        ServiceResponse serResAddMinorDependent = insuranceWrapper.addInsurance(addInsurancePayloadMinorDependent, customerId);

        assertEquals(serResAddCaregiver.getStatusCode(), 200);
        assertEquals(serResAddAdultDependent.getStatusCode(), 200);
        assertEquals(serResAddMinorDependent.getStatusCode(), 200);

        try {

            // Step - 3: Calling viewExistingInsurance API
            ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
            ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);

            // Step - 4: Validate status code
            Assert.assertTrue(serRes.getStatusCode() == statusCode);

            // Step - 5: Validate response body of ViewExistingInsurance API
            int noOfCustomers = viewExistingInsuranceResponse.getCustomerInsuranceInfo().size();


            for (int i = 0; i < noOfCustomers; i++) {

                int noOfInsurance = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getInsuranceInfo().size();

                // Assert.assertEquals(viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(), lookUpCID);
                String firstName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getFirstName();
                String middleName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getMiddleName();
                String lastName = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerName().getLastName();
                String customerType = viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType();
                DocumentContext jsonToParse = null;
                Assert.assertTrue(customerNames.contains(firstName + " " + middleName + " " + lastName + " - " + customerType));
                if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadAdultDependent,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("ADULT") && !viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).isDependent()) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadCaregiver,
                            viewExistingInsuranceResponse
                    );
                } else if (viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerType().equals("MINOR")) {
                    validateAddedInsurance(
                            viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(i).getCustomerId(),
                            addInsurancePayloadMinorDependent,
                            viewExistingInsuranceResponse
                    );
                }
            }
        } finally {
            //Thread.sleep(5000);
            ServiceResponse serResUpdateCaregiver = insuranceWrapper.updateInsurance(updateInsuranceCaregiver, customerId);
            assertEquals(serResUpdateCaregiver.getStatusCode(),200);
            ServiceResponse serResUpdateAdultDependent = insuranceWrapper.updateInsurance(updateInsuranceAdultDependent, customerId);
            assertEquals(serResUpdateAdultDependent.getStatusCode(),200);
            ServiceResponse serResUpdateMinorDependent = insuranceWrapper.updateInsurance(updateInsuranceMinorDependent, customerId);
            assertEquals(serResUpdateMinorDependent.getStatusCode(),200);
        }
    }

    @Test(description = "viewExistingInsurance with valid CID without digital account of caregiver", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceInvalidTest_1(String customerId, int statusCode, String errorCode, String lookUpCID, boolean getForDependents) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling viewExistingInsurance API
        ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
        ViewExistingInsuranceErrorResponse viewExistingInsuranceErrorResponse = serRes.getDataResponse(ViewExistingInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response body of ViewExistingInsurance API
        Assert.assertTrue(viewExistingInsuranceErrorResponse.getError().getCode().equals(errorCode));

    }

    @Test(description = "viewExistingInsurance with valid CID with lookupcid who is not a valid dependent", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewExistingInsurance")
    public void viewExistingInsuranceInvalidTest_2(String customerId, int statusCode, String errorCode, String lookUpCID, boolean getForDependents) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling viewExistingInsurance API
        ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, lookUpCID, getForDependents);
        ViewExistingInsuranceErrorResponse viewExistingInsuranceErrorResponse = serRes.getDataResponse(ViewExistingInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate response body of ViewExistingInsurance API
        Assert.assertTrue(viewExistingInsuranceErrorResponse.getError().getCode().equals(errorCode));

    }

    @Test(description = "Insurance with RDMInsuranceCategory Medicaid should be primaryEligible if the nonMedicaid insurance count is zero " +
            "and should not be primaryEligible if the nonMedicaid insurance count is greater than zero")
    void testViewExistingInsuranceWithDifferentMedicaidScenario() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with insurance category 1000 (MEDICAID)
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_4,
                CARRIER_ID_4,
                PLAN_ID_4,
                CATEGORY_4,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(5000);

        // Validating viewExistingInsuranceResponse status code and when only Medicaid insurance exists, it is marked as primary eligible in the viewExistingInsurance response
        ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse = serRes.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());
        assertEquals(viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getCategory(), "1000");
        assertEquals(viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIsPrimaryEligible(), true);
        assertEquals(viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIsPrimary(), true);
        assertFalse(viewExistingInsuranceResponse.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIRefIds().isEmpty());

        // Adding insurance with category 1006 and validating addInsurance response
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, CARDHOLDER_ID, BIN_NUMBER, PCN);
        ServiceResponse serRes1 = insuranceWrapper.addInsurance(payload, customerId);
        assertEquals("Status code is not matching", 200, serRes1.getStatusCode());

        // Validating viewExistingInsuranceResponse status code and after adding a non-Medicaid insurance to a customer who already has a Medicaid insurance
        ServiceResponse serRes2 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes2.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes2.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 2);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getCategory(), "1006");
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIsPrimaryEligible(), true);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIsPrimary(), true);
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIRefIds().isEmpty());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getCategory(), "1000");
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIsPrimaryEligible(), false);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIsPrimary(), false);
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIRefIds().isEmpty());
    }

    @Test(description = "Insurance with RDMInsuranceCategory {DISCOUNT_CARD, COUPON_OR_TRAIL_CARD} should be filtered out from final response")
    void testViewExistingInsuranceWithRDMInsuranceCategoryShouldBeFilteredOut() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with insurance category 1005 (DISCOUNT_CARD)
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                DISCOUNT_CARDHOLDER_ID,
                DISCOUNT_CARRIER_ID,
                DISCOUNT_PLAN_ID,
                DISCOUNT_CATEGORY,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(5000);

        // Adding insurance with category 1006 and validating addInsurance response
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, CARDHOLDER_ID, BIN_NUMBER, PCN);
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        // Validating viewExistingInsuranceResponse status code and no insurance with category 1005 (DISCOUNT_CARD) in response
        ServiceResponse serRes1 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes1.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes1.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 1);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getCategory(), "1006");
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIRefIds().isEmpty());
    }

    @Test(description = "testViewExistingInsurance replace insurance test success")
    void testViewExistingInsuranceWithReplaceInsurance() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with insurance category 1004
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(5000);

        // Adding insurance with category 1006 and validating addInsurance response
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, CARDHOLDER_ID, BIN_NUMBER, PCN);
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        // Replacing primary insurance
        String replaceInsurancePayload = buildReplaceInsuranceReq(customerId, CARDHOLDER_ID_2, String.valueOf(CARRIER_ID_2), String.valueOf(PLAN_ID_2), CARDHOLDER_ID, String.valueOf(CARRIER_ID), String.valueOf(PLAN_ID));
        ServiceResponse serRes1 = insuranceWrapper.replaceInsurance(replaceInsurancePayload, customerId);
        assertEquals("Status code is not matching", 200, serRes1.getStatusCode());

        // Validating viewExistingInsuranceResponse status code and insuranceInfo.replacedByInsurance for replaced insurance
        ServiceResponse serRes2 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes2.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes2.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 2);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIsInsuranceReplaced(), true);
        assertNotNull(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getReplacedByInsurance());
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIRefIds().isEmpty());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(0)
                .getIRefIds(),
                viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getReplacedByInsurance().getIRefIds());
    }

    @Test(description = "testViewExistingInsurance with reOrder logic success test")
    void testViewExistingInsuranceWithReorderLogicSuccessTest() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with insurance category 1004
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(5000);

        // Adding insurance with category 1006 and validating addInsurance response
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, CARDHOLDER_ID, BIN_NUMBER, PCN);
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        // Adding insurance with category 1000 and validating addInsurance response
        String payload2 = buildCPRAddInsuranceReqForInsurance(customerId, "27001", "004303", "WIMCD");
        ServiceResponse serRes1 = insuranceWrapper.addInsurance(payload2, customerId);
        assertEquals("Status code is not matching", 200, serRes1.getStatusCode());

        // Adding insurance with category 1000 and validating addInsurance response
        String payload4 = buildCPRAddInsuranceReqForInsurance(customerId, "27003", "004303", "WIMCD");
        ServiceResponse serRes3 = insuranceWrapper.addInsurance(payload4, customerId);
        assertEquals("Status code is not matching", 200, serRes3.getStatusCode());

        // Validating viewExistingInsuranceResponse status code and reorder insurance logic
        ServiceResponse serRes4 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes4.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes4.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 4);
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(2)
                .getCategory(), "1000");
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(2)
                .getIRefIds().isEmpty());

        // Adding insurance with category 1006 and validating addInsurance response
        String payload3 = buildCPRAddInsuranceReqForInsurance(customerId, "27002", "610502", "00670000");
        ServiceResponse serRes2 = insuranceWrapper.addInsurance(payload3, customerId);
        assertEquals("Status code is not matching", 200, serRes2.getStatusCode());

        // Validating viewExistingInsuranceResponse status code and insurance with category 1006 should be added to 3rd position
        ServiceResponse serRes5 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse2 = serRes5.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes4.getStatusCode());
        assertEquals(viewExistingInsuranceResponse2.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 5);
        assertEquals(viewExistingInsuranceResponse2.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(2)
                .getCategory(), "1006");
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(2)
                .getIRefIds().isEmpty());
    }

    @Test(description = "testViewExistingInsurance with dedup logic success test")
    void testViewExistingInsuranceWithDedupLogicSuccessTest() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID, CARRIER_ID, "INS123", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS1", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo4 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "S12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo5 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "NS1234", CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3, patientInsuranceInfo4, patientInsuranceInfo5);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        //Thread.sleep(5000);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(5000);

        // Validating viewExistingInsuranceResponse status code and dedup insurance logic
        ServiceResponse serRes = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 4);
    }

    @Test(description = "testViewExistingInsurance replaced insurance is removed by dedup insurance logic test success")
    void testViewExistingInsuranceWithReplaceDInsuranceIsRemovedByDedupInsuranceLogicSuccess() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID, CARRIER_ID, "820170", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);

        Thread.sleep(20000);
        // Adding insurance and validating addInsurance response
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, CARDHOLDER_ID_2, BIN_NUMBER_2, PCN_2);
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        // Replacing primary insurance with one of the duplicate insurances
        String replaceInsurancePayload = buildReplaceInsuranceReq(customerId, CARDHOLDER_ID_2, String.valueOf(CARRIER_ID_2), String.valueOf(PLAN_ID_2), CARDHOLDER_ID, String.valueOf(CARRIER_ID), String.valueOf(PLAN_ID));
        ServiceResponse serRes1 = insuranceWrapper.replaceInsurance(replaceInsurancePayload, customerId);
        assertEquals("Status code is not matching", 200, serRes1.getStatusCode());
        //Thread.sleep(5000);

        // Validating viewExistingInsuranceResponse status code and replaced insurance is removed by dedup logic
        ServiceResponse serRes3 = insuranceWrapper.viewExistingInsurance(customerId, "null", Boolean.FALSE);
        ViewExistingInsuranceResponse viewExistingInsuranceResponse1 = serRes3.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Status code is not matching", 200, serRes3.getStatusCode());
        assertEquals(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().size(), 2);
        assertFalse(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getIsInsuranceReplaced());
        assertNull(viewExistingInsuranceResponse1.getCustomerInsuranceInfo().get(0)
                .getInsuranceInfo().get(1)
                .getReplacedByInsurance());
    }

    private static String getInsertOcidQuery(
            String onlineCustId,
            String authStore,
            String authPatientId,
            String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private String buildCPRAddInsuranceReqForInsurance(String customerId, String cardholderId, String binNumber, String pcn) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(cardholderId)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .relation("CardHolder")
                                .rxBin(binNumber)
                                .rxPCN(pcn)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildReplaceInsuranceReq(String customerId, String existingInsuranceCardholderId, String existingInsuranceCarrierId, String existingInsurancePlanId,
                                            String replacedWithInsuranceCardholderId, String replacedWithInsuranceCarrierId, String replacedWithInsurancePlanId) throws JsonProcessingException {
        ReplaceInsuranceRequest request = ReplaceInsuranceRequest.builder()
                .insuranceInfo(Collections.singletonList(
                        ReplaceInsuranceRequest.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .insurances(Collections.singletonList(
                                        ReplaceInsuranceRequest.Insurance.builder()
                                                .existingInsurance(ReplaceInsuranceRequest.ExistingInsurance.builder()
                                                        .cardholderId(existingInsuranceCardholderId)
                                                        .carrierId(existingInsuranceCarrierId)
                                                        .planId(existingInsurancePlanId)
                                                        .build())
                                                .replacedWithInsurance(ReplaceInsuranceRequest.ReplacedWithInsurance.builder()
                                                        .cardholderId(replacedWithInsuranceCardholderId)
                                                        .carrierId(replacedWithInsuranceCarrierId)
                                                        .planId(replacedWithInsurancePlanId)
                                                        .build())
                                                .build()))
                                .build()))
                .build();
        return objectMapper.writeValueAsString(request);
    }
}
