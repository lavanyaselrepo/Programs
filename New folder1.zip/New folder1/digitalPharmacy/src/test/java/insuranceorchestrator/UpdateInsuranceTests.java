package insuranceorchestrator;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.UpdateInsurance.UpdateInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.UpdateInsurance.UpdateInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewExistingInsurance.ViewExistingInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;


public class UpdateInsuranceTests {

    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();

    private CARetrofit caRetrofit;
    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private static final Integer CARRIER_ID = 100426;
    private static final Integer PLAN_ID = 171;
    private static final Integer CATEGORY = 1006;

    private static final String BIN_NUMBER_2 = "601574";
    private static final String PCN_2 = null;
    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;


    private static final String CARDHOLDER_ID_3 = "33653564542";
    private static final Integer CARRIER_ID_3 = 123495;
    private static final Integer PLAN_ID_3 = 127;
    private static final Integer CATEGORY_3 = 1006;

    private static final String CARRIER_ID_M3P = "121312";
    private static final String PLAN_ID_M3P = "165";
    private static final String CATEGORY_M3P = "1009";
    private static final String BIN_NUMBER_M3P = "11610";
    private static final String BIN_NUMBER_PCN = "MPPP2";

    private static final String CARRIER_ID_MEDICAID = "104444";
    private static final String PLAN_ID_MEDICAID = "119";
    private static final String CATEGORY_MEDICAID = "104444";
    private static final String BIN_NUMBER_MEDICAID = "004303";
    private static final String BIN_NUMBER_PCN_MEDICAID = "WIMCD";

    private static final Integer PLAN_ID_INVALID = 1711;

    private static final String DISCOUNT_BIN_NUMBER = "808412";
    private static final String DISCOUNT_PCN = "45370";
    private static final String DISCOUNT_CARDHOLDER_ID = "12331892332";
    private static final Integer DISCOUNT_CARRIER_ID = 116135;
    private static final Integer DISCOUNT_PLAN_ID = 179;
    private static final Integer DISCOUNT_CATEGORY = 1005;

    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private ObjectMapper objectMapper;

    @BeforeClass
    public  void setContext() throws IOException {
        accountDbContext =
                AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        caRetrofit =  new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();
    }


    @Test(description = "Validate updateInsurance API for valid request")
    public void updateInsuranceValidTest() throws Exception, InterruptedException {

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);

        // Building the Request payload
        String payload = buildAddInsuranceReqForInsurance(customerId);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);
        //Thread.sleep(10000);

        // Validate status code
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        java.util.List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());

        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)) &&
                                patientInsuranceViewInfo.getCardholderId().equalsIgnoreCase(CARDHOLDER_ID))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        assertEquals("Not Added at expected position", Integer.valueOf(2), billSeqNumber);

        //Step - 4: Calling updateInsurance API
        String updateInsurancePayload = buildUpdateInsurancePayload(customerId);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);

        //Step - 5: Validate status code of UpdateInsurance API
        assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);
        //Thread.sleep(10000);

        // Step - 4: Validate updated object by calling viewExistingInsurance API
        ServiceResponse currViewResponse = insuranceWrapper.viewExistingInsurance(customerId, "null",false);
        Assert.assertTrue(currViewResponse.getStatusCode() == 200);
        ViewExistingInsuranceResponse currInsurances = currViewResponse.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Insurance info size after update ", currInsurances.getCustomerInsuranceInfo().get(0).getInsuranceInfo().size(), 1);

        // Additional asserts: verify coverageInd of updated insurance changes
        // Get insurance info after update from CPR
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);
        java.util.List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());

        // Find the updated insurance in before list
        PatientInsuranceViewInfo beforeInsurance = beforeList.stream()
                .filter(info -> String.valueOf(CARRIER_ID).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID).equalsIgnoreCase(info.getInsurancePlanId()) && CARDHOLDER_ID.equalsIgnoreCase(info.getCardholderId()))
                .findFirst().orElse(null);
        Assert.assertNotNull("Updated insurance not found in before list", beforeInsurance);
        // After update, insurance with coverageInd N should not be present in afterList
        boolean updatedInsurancePresentAfter = afterList.stream()
                .anyMatch(info -> String.valueOf(CARRIER_ID).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID).equalsIgnoreCase(info.getInsurancePlanId()) && CARDHOLDER_ID.equalsIgnoreCase(info.getCardholderId()));
        Assert.assertTrue("Updated insurance should also be present in after list but with coverageInd is N", updatedInsurancePresentAfter);
        Assert.assertTrue("Coverage Ind should be N", afterList.stream()
                .anyMatch(info -> String.valueOf(CARRIER_ID).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID).equalsIgnoreCase(info.getInsurancePlanId())
                        && CARDHOLDER_ID.equalsIgnoreCase(info.getCardholderId())
                        && "N".equalsIgnoreCase(info.getCoverageInd())));
        // For all other insurances,  coverageInd remain unchanged and billingSeq for this particular use case remains same as the insurance deleted is the last one
        for (PatientInsuranceViewInfo beforeInfo : beforeList) {
            if (!(String.valueOf(CARRIER_ID).equalsIgnoreCase(beforeInfo.getInsuranceCarrierId())
                    && String.valueOf(PLAN_ID).equalsIgnoreCase(beforeInfo.getInsurancePlanId())
                    && CARDHOLDER_ID.equalsIgnoreCase(beforeInfo.getCardholderId()))) {
                PatientInsuranceViewInfo afterInfo = afterList.stream()
                        .filter(info -> beforeInfo.getBillingSeqNbr().equals(info.getBillingSeqNbr()))
                        .findFirst().orElse(null);
                Assert.assertNotNull("Other insurance with billingSeqNbr " + beforeInfo.getBillingSeqNbr() + " not found after update", afterInfo);
                assertEquals("BillingSeqNbr should remain the same for other insurances", beforeInfo.getBillingSeqNbr(), afterInfo.getBillingSeqNbr());
                assertEquals("CoverageInd should remain unchanged for other insurances", beforeInfo.getCoverageInd(), afterInfo.getCoverageInd());
            }
        }
    }

    @Test(description = "Validate updateInsurance API for valid request")
    public void updateInsuranceValidTestForPrimaryInsurance() throws Exception, InterruptedException {

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        Thread.sleep(20000);
        // Building the Request payload
        String payload = buildAddInsuranceReqForInsurance(customerId);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);
        // Validate status code
        assertEquals("Status code is not matching", 200, serRes.getStatusCode());
        //Thread.sleep(10000);

        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        java.util.List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());

        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)) &&
                                patientInsuranceViewInfo.getCardholderId().equalsIgnoreCase(CARDHOLDER_ID))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        assertEquals("Not Added at expected position", Integer.valueOf(2), billSeqNumber);

        //Step - 4: Calling updateInsurance API
        String updateInsurancePayload = buildUpdateInsurancePayload2(customerId);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        //Thread.sleep(10000);

        //Step - 5: Validate status code of UpdateInsurance API
        assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);

        // Step - 4: Validate updated object by calling viewGlobalInsurance API
        ServiceResponse currViewResponse = insuranceWrapper.viewExistingInsurance(customerId, "null",false);
        Assert.assertTrue(currViewResponse.getStatusCode() == 200);
        ViewExistingInsuranceResponse currInsurances = currViewResponse.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals("Insurance info size after update ", currInsurances.getCustomerInsuranceInfo().get(0).getInsuranceInfo().size(), 1);

        // Additional asserts: verify only coverageInd of updated insurance changes and billingSeqNbr updates according to reordering logic
        // Get insurance info after update from CPR
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);
        java.util.List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());

        // Find the updated insurance in before list
        PatientInsuranceViewInfo beforeInsurance = beforeList.stream()
                .filter(info -> String.valueOf(CARRIER_ID_2).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID_2).equalsIgnoreCase(info.getInsurancePlanId()) && CARDHOLDER_ID_2.equalsIgnoreCase(info.getCardholderId()))
                .findFirst().orElse(null);
        PatientInsuranceViewInfo afterInsurance = afterList.stream()
                .filter(info -> String.valueOf(CARRIER_ID_2).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID_2).equalsIgnoreCase(info.getInsurancePlanId()) && CARDHOLDER_ID_2.equalsIgnoreCase(info.getCardholderId()))
                .findFirst().orElse(null);
        Assert.assertNotNull("Updated insurance not found in before list", beforeInsurance);
        Assert.assertNotNull("Updated insurance not found in after list", afterInsurance);
        // After update, insurance with coverageInd N should not be present in afterList
        boolean updatedInsurancePresentAfter = afterList.stream()
                .anyMatch(info -> String.valueOf(CARRIER_ID_2).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID_2).equalsIgnoreCase(info.getInsurancePlanId()) && CARDHOLDER_ID_2.equalsIgnoreCase(info.getCardholderId()));
        Assert.assertTrue("Updated insurance should also be present in after list but with coverageInd is N", updatedInsurancePresentAfter);
        Assert.assertTrue("Coverage Ind should be N", afterList.stream()
                .anyMatch(info -> String.valueOf(CARRIER_ID_2).equalsIgnoreCase(info.getInsuranceCarrierId())
                        && String.valueOf(PLAN_ID_2).equalsIgnoreCase(info.getInsurancePlanId())
                        && CARDHOLDER_ID_2.equalsIgnoreCase(info.getCardholderId())
                        && "N".equalsIgnoreCase(info.getCoverageInd())));
        assertEquals("BillingSeqNbr would be at the end i.e = 2", Integer.valueOf(2), afterInsurance.getBillingSeqNbr());
        // For all other insurances, billingSeqNbr and coverageInd remain unchanged
        for (PatientInsuranceViewInfo beforeInfo : beforeList) {
            if (!(String.valueOf(CARRIER_ID_2).equalsIgnoreCase(beforeInfo.getInsuranceCarrierId())
                    && String.valueOf(PLAN_ID_2).equalsIgnoreCase(beforeInfo.getInsurancePlanId())
                    && CARDHOLDER_ID_2.equalsIgnoreCase(beforeInfo.getCardholderId()))) {
                PatientInsuranceViewInfo afterInfo = afterList.stream()
                        .filter(info -> beforeInfo.getBillingSeqNbr() - 1 == info.getBillingSeqNbr())
                        .findFirst().orElse(null);
                Assert.assertNotNull("Other insurance with billingSeqNbr " + beforeInfo.getBillingSeqNbr() + " not found after update", afterInfo);
                assertEquals("BillingSeqNbr should remain the same for other insurances", Integer.valueOf(beforeInfo.getBillingSeqNbr() - 1) , afterInfo.getBillingSeqNbr());
                assertEquals("CoverageInd should remain unchanged for other insurances", beforeInfo.getCoverageInd(), afterInfo.getCoverageInd());
            }
        }
    }

    @Test(description = "Validate updateInsurance API for valid request with coverageInd=N")
    public void updateInsuranceValidTestWithCoverageIndAsNo() throws Exception, InterruptedException {

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        String updateInsurancePayload = buildUpdateInsurancePayload2(customerId);

        insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        //Thread.sleep(10000);

        ServiceResponse prevViewResponse = insuranceWrapper.viewExistingInsurance(customerId, "null",false);

        Assert.assertTrue(prevViewResponse.getStatusCode() == 200);
        ViewExistingInsuranceResponse prevInsurances = prevViewResponse.getDataResponse(ViewExistingInsuranceResponse.class);
        assertEquals(prevInsurances.getCustomerInsuranceInfo().get(0).getInsuranceInfo().size(), 0);
        // Step - 2: Calling addInsurance API
        String addInsurancePayload = buildAddInsuranceReqForInsurance2(customerId);
        ServiceResponse serResAdd = insuranceWrapper.addInsurance(addInsurancePayload, customerId);

        // Step - 3: Validate status code of AddInsurance API
        assertEquals(serResAdd.getStatusCode(), 200);

        //Step - 4: Calling updateInsurance API
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);

        //Thread.sleep(10000);

        //Step - 5: Validate status code of UpdateInsurance API
        assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);

        // Step - 4: Validate updated object by calling viewGlobalInsurance API
        ServiceResponse currViewResponse = insuranceWrapper.viewExistingInsurance(customerId, "null",false);
        Assert.assertTrue(currViewResponse.getStatusCode() == 200);
        ViewExistingInsuranceResponse currInsurances = currViewResponse.getDataResponse(ViewExistingInsuranceResponse.class);

        assertEquals(prevInsurances.getCustomerInsuranceInfo().size(), currInsurances.getCustomerInsuranceInfo().size());
    }

    @Test(description = "Update Insurance with invalid payload - invalid input request", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx" , sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_1(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());
    }

    @Test(description = "Update Insurance with invalid payload - Insurance does not exist on patient profile", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx" , sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_2(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Update Insurance with invalid payload - Customer Digital Account not present", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx" , sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_3(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Update Insurance with invalid payload - Insurance customer is not a valid Dependent of the logged in customer", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx" , sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_4(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Invalid Request error from Account Orchestrator", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_5(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Update Insurance with invalid payload - ILogged in customerId is not same as insurance customerId if isDependent is false\t", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments( filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx" , sheetName = "UpdateInsurance")
    public void updateInsuranceInvalidTest_6(String updateInsurancePayload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling UpdateInsurance API
        ServiceResponse serRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        UpdateInsuranceErrorResponse updateInsuranceErrorResponse = serRes.getDataResponse(UpdateInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        assertEquals(updateInsuranceErrorResponse.getError().getCode(),errorCode);
        Reporter.logJSON("Error message", updateInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Add Insurance with valid payload from cpr  and then update insurance with valid payload- store should be 9928")
    public void updateInsuranceValidTest_2() throws Exception, InterruptedException {


        //Step - 1: Calling addInsurance and update CPR api and viewInsurance of cpr

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);

        // Building the Request payload
        String addInsurancePayload = buildCPRAddUpdateInsuranceRequest2(customerId,9928,patientId);
        String updateInsurancePayload = buildUpdateInsurancePayload2(customerId);
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        String cardHolderId = CARDHOLDER_ID_2;
        String carriedId = CARRIER_ID_2.toString();
        String planId = PLAN_ID_2.toString();

        insuranceWrapper.addNupdateInsuranceCPR1(addInsurancePayload,updateInsurancePayload,customerId,viewCPRPayload,cardHolderId,carriedId,planId);

    }

    @Test(description = "Validate billingSeqNbr remains same and coverageInd changes to N after updateInsurance (CPR)")
    public void updateInsuranceBillingSeqNbrAndCoverageIndValidation() throws Exception, InterruptedException {

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);

        String addInsurancePayload = buildAddInsuranceReqForInsurance(customerId);
        // Step 1: Add insurance via CPR
        ServiceResponse addRes = insuranceWrapper.addInsurance(addInsurancePayload,customerId);
        assertEquals(200, addRes.getStatusCode());
        //Thread.sleep(10000);

        String addInsurancePayload3 = buildAddInsuranceReqForInsurance3(customerId);
        ServiceResponse addRes3 = insuranceWrapper.addInsurance(addInsurancePayload3,customerId);
        assertEquals(addRes3.getStatusCode(), 200);
        //Thread.sleep(10000);

        // Step 2: Get CPR insurance info before update
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        ServiceResponse viewBeforeRes = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        assertEquals(viewBeforeRes.getStatusCode(), 200);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse before = viewBeforeRes.getDataResponse(com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse.class);
        Assert.assertFalse(before.getPatientInsuranceViewInfo().isEmpty());

        String updateInsurancePayload = buildUpdateInsurancePayload2(customerId);

        // Step 3: Update insurance (should set coverageInd to N)
        ServiceResponse updateRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        assertEquals(updateRes.getStatusCode(), 200);
        //Thread.sleep(10000);

        // Step 4: Get CPR insurance info after update
        ServiceResponse viewAfterRes = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        assertEquals(viewAfterRes.getStatusCode(), 200);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse after = viewAfterRes.getDataResponse(com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse.class);
        Assert.assertFalse(after.getPatientInsuranceViewInfo().isEmpty());



        String cardholderId = CARDHOLDER_ID_2;
        String carrierId = CARRIER_ID_2.toString();
        String planId = PLAN_ID_2.toString();

        // Find the insurance to be updated in 'before' and 'after' lists using the 3 indicators
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo beforeInsurance = before.getPatientInsuranceViewInfo().stream()
                .filter(info ->  cardholderId.equalsIgnoreCase(info.getCardholderId())
                        && carrierId.equalsIgnoreCase(info.getInsuranceCarrierId())
                        && planId.equalsIgnoreCase(info.getInsurancePlanId()))
                .findFirst().orElse(null);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo afterInsurance = after.getPatientInsuranceViewInfo().stream()
                .filter(info ->  cardholderId.equalsIgnoreCase(info.getCardholderId())
                        && carrierId.equalsIgnoreCase(info.getInsuranceCarrierId())
                        && planId.equalsIgnoreCase(info.getInsurancePlanId()))
                .findFirst().orElse(null);

        Assert.assertNotNull("Insurance to be updated not found in before list", beforeInsurance);
        Assert.assertNotNull("Insurance to be updated not found in after list", afterInsurance);

        // Assert billingSeqNbr remains the same and coverageInd changes to N for the updated insurance
        assertEquals("BillingSeqNbr would be set to 1 before", Integer.valueOf(1), beforeInsurance.getBillingSeqNbr());
        assertEquals("BillingSeqNbr would be updated to 3", Integer.valueOf(3), afterInsurance.getBillingSeqNbr());
        Assert.assertNotEquals("CoverageInd should change", beforeInsurance.getCoverageInd(), afterInsurance.getCoverageInd());
        assertEquals("CoverageInd should be N after update", "N", afterInsurance.getCoverageInd());

        // For all other insurances with storeNbr 9928, assert billingSeqNbr and coverageInd - coverageInd remain unchanged and billingSeqNbr is reduced by 1(reordering logic)
        for (com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo beforeInfo : before.getPatientInsuranceViewInfo()) {
            if (!(cardholderId.equalsIgnoreCase(beforeInfo.getCardholderId())
                    && carrierId.equalsIgnoreCase(beforeInfo.getInsuranceCarrierId())
                    && planId.equalsIgnoreCase(beforeInfo.getInsurancePlanId()))) {
                com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo afterInfo = after.getPatientInsuranceViewInfo().stream()
                        .filter(info -> beforeInfo.getBillingSeqNbr() - 1 == info.getBillingSeqNbr())
                        .findFirst().orElse(null);
                Assert.assertNotNull("Other insurance with billingSeqNbr " + (beforeInfo.getBillingSeqNbr() - 1) + " not found after update", afterInfo);
                assertEquals("BillingSeqNbr should be reduced by 1 for other insurances", Integer.valueOf(beforeInfo.getBillingSeqNbr() - 1), afterInfo.getBillingSeqNbr());
                assertEquals("CoverageInd should remain unchanged for other insurances", beforeInfo.getCoverageInd(), afterInfo.getCoverageInd());
            }
        }
    }

    @Test(description = "Validate billingSeqNbr and coverageInd after updateInsurance when medicaid , commercial and m3p insurances are added")
    public void updateInsuranceSortingValidation() throws Exception, InterruptedException {

        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", patientId, firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID,
                CARRIER_ID,
                PLAN_ID,
                CATEGORY,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);

        String addInsurancePayload = buildAddInsuranceReqForInsurance2(customerId);
        // Step 1: Add insurance via CPR
        ServiceResponse addRes = insuranceWrapper.addInsurance(addInsurancePayload,customerId);
        assertEquals(200, addRes.getStatusCode());
        //Thread.sleep(10000);

        String addInsuranceM3PPayload = buildAddInsuranceReqForM3P(customerId);
        // Step 1: Add insurance via CPR
        ServiceResponse addM3PRes = insuranceWrapper.addInsurance(addInsuranceM3PPayload,customerId);
        assertEquals(200, addRes.getStatusCode());
        //Thread.sleep(10000);

        String addInsuranceMedicaidPayload = buildAddInsuranceReqForMedicaid(customerId);
        // Step 1: Add insurance via CPR
        ServiceResponse addMedicaidRes = insuranceWrapper.addInsurance(addInsuranceMedicaidPayload,customerId);
        assertEquals(200, addRes.getStatusCode());
        //Thread.sleep(10000);

        String addInsurancePayload3 = buildAddInsuranceReqForInsurance3(customerId);
        ServiceResponse addRes3 = insuranceWrapper.addInsurance(addInsurancePayload3,customerId);
        assertEquals(addRes3.getStatusCode(), 200);
        //Thread.sleep(10000);

        // Step 2: Get CPR insurance info before update
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        ServiceResponse viewBeforeRes = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        assertEquals(viewBeforeRes.getStatusCode(), 200);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse before = viewBeforeRes.getDataResponse(com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse.class);
        Assert.assertFalse(before.getPatientInsuranceViewInfo().isEmpty());

        String updateInsurancePayload = buildUpdateInsuranceMedicaid(customerId);

        // Step 3: Update insurance (should set coverageInd to N)
        ServiceResponse updateRes = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        assertEquals(updateRes.getStatusCode(), 200);
        //Thread.sleep(10000);

        // Step 4: Get CPR insurance info after update
        ServiceResponse viewAfterRes = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        assertEquals(viewAfterRes.getStatusCode(), 200);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse after = viewAfterRes.getDataResponse(com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse.class);
        Assert.assertFalse(after.getPatientInsuranceViewInfo().isEmpty());



        String cardholderId = CARRIER_ID_MEDICAID;
        String carrierId = CARRIER_ID_MEDICAID;
        String planId = PLAN_ID_MEDICAID;

        // Find the insurance to be updated in 'before' and 'after' lists using the 3 indicators
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo beforeInsurance = before.getPatientInsuranceViewInfo().stream()
                .filter(info ->  cardholderId.equalsIgnoreCase(info.getCardholderId())
                        && carrierId.equalsIgnoreCase(info.getInsuranceCarrierId())
                        && planId.equalsIgnoreCase(info.getInsurancePlanId()))
                .findFirst().orElse(null);
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo afterInsurance = after.getPatientInsuranceViewInfo().stream()
                .filter(info ->  cardholderId.equalsIgnoreCase(info.getCardholderId())
                        && carrierId.equalsIgnoreCase(info.getInsuranceCarrierId())
                        && planId.equalsIgnoreCase(info.getInsurancePlanId()))
                .findFirst().orElse(null);

        Assert.assertNotNull("Insurance to be updated not found in before list", beforeInsurance);
        Assert.assertNotNull("Insurance to be updated not found in after list", afterInsurance);

        // Assert coverageInd changes to N for the updated insurance
        assertEquals("BillingSeqNbr would be set to 4 before", Integer.valueOf(4), beforeInsurance.getBillingSeqNbr());
        assertEquals("BillingSeqNbr would be updated to 5", Integer.valueOf(5), afterInsurance.getBillingSeqNbr());
        Assert.assertNotEquals("CoverageInd should change", beforeInsurance.getCoverageInd(), afterInsurance.getCoverageInd());
        assertEquals("CoverageInd should be N after update", "N", afterInsurance.getCoverageInd());

    }

    @Test(description = "testUpdateInsurance with dedup logic failure test: no matching insurance found")
    void testUpdateInsuranceWithDedupLogicFailureTest() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID, CARRIER_ID, "INS123", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        3, PLAN_ID, CARRIER_ID, "WMTINS1", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo4 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        4, PLAN_ID, CARRIER_ID, "S12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo5 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        5, PLAN_ID, CARRIER_ID, "NS1234", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo6 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        6, PLAN_ID, CARRIER_ID, "INS123456", CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3, patientInsuranceInfo4, patientInsuranceInfo5,patientInsuranceInfo6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        //Thread.sleep(10000);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(10000);

        // Validate view Insurance response from CPR
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances before deduplication, but found ", 6, beforeList.size());

        // Step - 2: Calling updateInsurance API
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId("NSI234")
                                .cardholderFirstName(firstName)
                                .cardholderLastName(lastName)
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();

        String updateInsurancePayload = objectMapper.writeValueAsString(request);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        //Thread.sleep(10000);

        Assert.assertEquals("Status code did not match", serResUpdate.getStatusCode(), 400);
        Assert.assertEquals("Error code did not match", "DPR-DPINSOR-1008", serResUpdate.getDataResponse(UpdateInsuranceErrorResponse.class).getError().getCode());

        // Validate view Insurance response from CPR
        String viewCPRPayloadAfter = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayloadAfter);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances after update, but found ", 6, afterList.size());

        // Count the number of insurances with coverageInd 'N' in the after list
        long countCoverageIndN = afterList.stream()
                .filter(info -> "N".equalsIgnoreCase(info.getCoverageInd()))
                .count();
        Assert.assertEquals("Expected 3 insurance with coverageInd 'N' after update, but found " + countCoverageIndN, 0, countCoverageIndN);


    }


    @Test(description = "testUpdateInsurance with dedup logic success")
    void testUpdateInsuranceWithDedupLogicSuccessTest() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID, CARRIER_ID, "INS123", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        3, PLAN_ID, CARRIER_ID, "WMTINS1", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo4 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        4, PLAN_ID, CARRIER_ID, "S12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo5 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        5, PLAN_ID, CARRIER_ID, "NS1234", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo6 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        6, PLAN_ID, CARRIER_ID, "INS123456", CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3, patientInsuranceInfo4, patientInsuranceInfo5,patientInsuranceInfo6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        //Thread.sleep(10000);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        Thread.sleep(10000);

        // Validate view Insurance response from CPR
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances before deduplication, but found ", 6, beforeList.size());

        // Step - 2: Calling updateInsurance API
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId("INS123")
                                .cardholderFirstName(firstName)
                                .cardholderLastName(lastName)
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();

        String updateInsurancePayload = objectMapper.writeValueAsString(request);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        //Thread.sleep(10000);

        Assert.assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);

        // Validate view Insurance response from CPR
        String viewCPRPayloadAfter = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayloadAfter);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances after update, but found ", 6, afterList.size());

        // Count the number of insurances with coverageInd 'N' in the after list
        long countCoverageIndN = afterList.stream()
                .filter(info -> "N".equalsIgnoreCase(info.getCoverageInd()))
                .count();
        Assert.assertEquals("Expected 3 insurance with coverageInd 'N' after update, but found " + countCoverageIndN, 3, countCoverageIndN);


    }


    @Test(description = "testUpdateInsurance with dedup logic success")
    void testUpdateInsuranceWithDedupLogicSuccessTestWhenRDMFailsForTargetInsurance() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID_INVALID, CARRIER_ID, "INS123", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        3, PLAN_ID, CARRIER_ID, "WMTINS1", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo4 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        4, PLAN_ID, CARRIER_ID, "S12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo5 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        5, PLAN_ID, CARRIER_ID, "NS1234", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo6 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        6, PLAN_ID, CARRIER_ID, "INS123456", CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3, patientInsuranceInfo4, patientInsuranceInfo5,patientInsuranceInfo6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        //Thread.sleep(10000);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(10000);

        // Validate view Insurance response from CPR
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances before deduplication, but found ", 6, beforeList.size());

        // Step - 2: Calling updateInsurance API
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId("INS123")
                                .cardholderFirstName(firstName)
                                .cardholderLastName(lastName)
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID_INVALID))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();

        String updateInsurancePayload = objectMapper.writeValueAsString(request);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        //Thread.sleep(10000);

        Assert.assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);

        // Validate view Insurance response from CPR
        String viewCPRPayloadAfter = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayloadAfter);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances after update, but found ", 6, afterList.size());

        // Count the number of insurances with coverageInd 'N' in the after list
        long countCoverageIndN = afterList.stream()
                .filter(info -> "N".equalsIgnoreCase(info.getCoverageInd()))
                .count();
        Assert.assertEquals("Expected 1 insurance with coverageInd 'N' after update, but found " + countCoverageIndN, 1, countCoverageIndN);


    }

    @Test(description = "testUpdateInsurance with dedup logic success")
    void testUpdateInsuranceWithDedupLogicSuccessTestWhenRDMFailsForCPRViewInsurance01() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Creating CPR account with duplicate insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        1, PLAN_ID, CARRIER_ID, "INS123", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        2, PLAN_ID, CARRIER_ID, "WMTINS12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        3, PLAN_ID_INVALID, CARRIER_ID, "WMTINS1", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo4 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        4, PLAN_ID_INVALID, CARRIER_ID, "S12345", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo5 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        5, PLAN_ID_INVALID, CARRIER_ID, "NS1234", CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo6 =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        6, PLAN_ID, CARRIER_ID, "INS123456", CATEGORY, "Y");
        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3, patientInsuranceInfo4, patientInsuranceInfo5,patientInsuranceInfo6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "9928",
                        CommonUtil.generateRandomNumber(6),
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        //Thread.sleep(10000);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(10000);

        // Validate view Insurance response from CPR
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> beforeList = new java.util.ArrayList<>(viewInsuranceResponse.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances before deduplication, but found ", 6, beforeList.size());

        // Step - 2: Calling updateInsurance API
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId("INS123")
                                .cardholderFirstName(firstName)
                                .cardholderLastName(lastName)
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();

        String updateInsurancePayload = objectMapper.writeValueAsString(request);
        ServiceResponse serResUpdate = insuranceWrapper.updateInsurance(updateInsurancePayload, customerId);
        ////Thread.sleep(10000);

        Assert.assertEquals("Status code did not match", serResUpdate.getStatusCode(), 200);

        // Validate view Insurance response from CPR
        String viewCPRPayloadAfter = String.format("{\"storeNbr\":9928,\"patientId\":%s}", cprUpdatePatientRequest.getPatientId());
        ServiceResponse serResViewAfter = insuranceWrapper.viewInsuranceCPR(viewCPRPayloadAfter);
        ViewInsuranceResponse viewInsuranceResponseAfter = serResViewAfter.getDataResponse(ViewInsuranceResponse.class);

        // Capture insurance info before update
        List<PatientInsuranceViewInfo> afterList = new java.util.ArrayList<>(viewInsuranceResponseAfter.getPatientInsuranceViewInfo());
        Assert.assertEquals("Expected 6 insurances after update, but found ", 6, afterList.size());

        // Count the number of insurances with coverageInd 'N' in the after list
        long countCoverageIndN = afterList.stream()
                .filter(info -> "N".equalsIgnoreCase(info.getCoverageInd()))
                .count();
        Assert.assertEquals("Expected 3 insurance with coverageInd 'N' after update, but found " + countCoverageIndN, 3, countCoverageIndN);


    }

    private static String getInsertOcidQuery(
            String onlineCustId,
            String authStore,
            String authPatientId,
            String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery = String.format(
                "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    private String buildAddInsuranceReqForInsurance(String customerId) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER)
                                .rxPCN(PCN)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildAddInsuranceReqForInsurance3(String customerId) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID_3)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID_3))
                                .planId(String.valueOf(PLAN_ID_3))
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER)
                                .rxPCN(PCN)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildAddInsuranceReqForM3P(String customerId) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARRIER_ID_M3P)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(CARRIER_ID_M3P)
                                .planId(PLAN_ID_M3P)
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER_M3P)
                                .rxPCN(BIN_NUMBER_PCN)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildAddInsuranceReqForMedicaid(String customerId) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARRIER_ID_MEDICAID)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(CARRIER_ID_MEDICAID)
                                .planId(PLAN_ID_MEDICAID)
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER_MEDICAID)
                                .rxPCN(BIN_NUMBER_PCN_MEDICAID)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildAddInsuranceReqForInsurance2(String customerId) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID_2)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID_2))
                                .planId(String.valueOf(PLAN_ID_2))
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER_2)
                                .rxPCN(PCN_2)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildUpdateInsurancePayload(String customerId ) throws JsonProcessingException {
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildUpdateInsurancePayload2(String customerId ) throws JsonProcessingException {
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID_2)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID_2))
                                .planId(String.valueOf(PLAN_ID_2))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildUpdateInsurancePayload3(String customerId ) throws JsonProcessingException {
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID_3)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID_3))
                                .planId(String.valueOf(PLAN_ID_3))
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildUpdateInsuranceMedicaid(String customerId ) throws JsonProcessingException {
        UpdateInsuranceV1Request request = UpdateInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        UpdateInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARRIER_ID_MEDICAID)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(CARRIER_ID_MEDICAID)
                                .planId(PLAN_ID_MEDICAID)
                                .relation("CardHolder")
                                .coverageInd("N") // Setting coverageInd to N for the update
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildCPRAddUpdateInsuranceRequest3(String customerId, Integer storeNbr, String patientId) throws JsonProcessingException {

        CPRUpdatePatientRequest.PatientInsuranceInfo insuranceInfo = CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingGroupNbr("1626281726")
                .billingSeqNbr(3)
                .cardholderFirstName("GREEN")
                .cardholderId(CARDHOLDER_ID_3)
                .cardholderLastName("BLUE")
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(1004)
                .insuranceCarrierId(CARRIER_ID_3)
                .insurancePlanId(PLAN_ID_3)
                .lastChangeTs("2021-03-02T16:40:41.800Z")
                .lastChangeUserId("USer")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd("Y")
                .build();

        CPRUpdatePatientRequest request = CPRUpdatePatientRequest.builder()
                .storeNbr(storeNbr)
                .patientId(Integer.valueOf(patientId))
                .patientInsuranceInfo(Collections.singletonList(insuranceInfo))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildCPRAddUpdateInsuranceRequest(String customerId, Integer storeNbr, String patientId) throws JsonProcessingException {

        CPRUpdatePatientRequest.PatientInsuranceInfo insuranceInfo = CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingGroupNbr("1626281726")
                .billingSeqNbr(2)
                .cardholderFirstName("GREEN")
                .cardholderId(CARDHOLDER_ID)
                .cardholderLastName("BLUE")
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(1004)
                .insuranceCarrierId(CARRIER_ID)
                .insurancePlanId(PLAN_ID)
                .lastChangeTs("2021-03-02T16:40:41.800Z")
                .lastChangeUserId("USer")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd("Y")
                .build();

        CPRUpdatePatientRequest request = CPRUpdatePatientRequest.builder()
                .storeNbr(storeNbr)
                .patientId(Integer.valueOf(patientId))
                .patientInsuranceInfo(Collections.singletonList(insuranceInfo))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private String buildCPRAddUpdateInsuranceRequest2(String customerId, Integer storeNbr, String patientId) throws JsonProcessingException {

        CPRUpdatePatientRequest.PatientInsuranceInfo insuranceInfo = CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingGroupNbr("1626281726")
                .billingSeqNbr(2)
                .cardholderFirstName("GREEN")
                .cardholderId(CARDHOLDER_ID_2)
                .cardholderLastName("BLUE")
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(1004)
                .insuranceCarrierId(CARRIER_ID_2)
                .insurancePlanId(PLAN_ID_2)
                .lastChangeTs("2021-03-02T16:40:41.800Z")
                .lastChangeUserId("USer")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd("Y")
                .build();

        CPRUpdatePatientRequest request = CPRUpdatePatientRequest.builder()
                .storeNbr(storeNbr)
                .patientId(Integer.valueOf(patientId))
                .patientInsuranceInfo(Collections.singletonList(insuranceInfo))
                .build();
        return objectMapper.writeValueAsString(request);
    }


    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterTest
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted
                .forEach(this::deleteOCPRecord);
    }



}
