package insuranceorchestrator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.BomTestDataSetupRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetInsuranceDetailsByPatientInfoV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.fetchAndValidateIToken.InsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Collections;

public class validateTokenAndGetInsuranceDetailsV1Tests {
    private InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper = new ObjectMapper();

    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private static final String GROUP_ID = "YJSS0";
    private static final String STORE_ID = "9989";

    private String dynamicFirstName;
    private String dynamicLastName;
    private String dynamicCustomerId;
    private String validToken;

    @BeforeClass
    public void setContext() throws IOException {
        dynamicFirstName = CommonUtil.generateRandomFirstName(8);
        dynamicLastName = CommonUtil.generateRandomFirstName(8);
        dynamicCustomerId = CommonUtil.generateRandomFirstName(36);

        // Seed BOM with test patient data
        BomTestDataSetupRequest bomRequest = buildBomTestDataSetupRequest(
                dynamicFirstName, dynamicLastName, "19960101", "M",
                "178 Paradise Crescent", "Royal Palm Beach", "33411", "FL",
                STORE_ID, "US", CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN);
        String bomJson = objectMapper.writeValueAsString(bomRequest);
        insuranceWrapper.setupBomTestData(bomJson);

        // Get a valid token from PatientInfo V1 endpoint
        String v1Payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
        }});

        ServiceResponse v1Response = insuranceWrapper.getInsuranceByPatientInfoV1(dynamicCustomerId, v1Payload);
        Assert.assertEquals("BeforeClass: expected 200 from PatientInfo V1", 200, v1Response.getStatusCode());

        GetInsuranceDetailsByPatientInfoV1Response response = v1Response.getDataResponse(GetInsuranceDetailsByPatientInfoV1Response.class);
        Assert.assertNotNull("BeforeClass: InsuranceInfo should not be null", response.getInsuranceInfo());
        Assert.assertFalse("BeforeClass: should have at least one insurance", response.getInsuranceInfo().isEmpty());

        validToken = response.getInsuranceInfo().get(0).getValidationToken();
        Assert.assertNotNull("BeforeClass: validToken should not be null", validToken);
    }

    // ========================
    // HAPPY PATH TESTS
    // ========================

    @Test(description = "ValidateToken: Happy path - decrypt valid token and verify 200 with all InsuranceInfo fields")
    public void validateTokenHappyPathAllFieldsTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validToken);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(serviceResponse.getDataResponse());
        InsuranceInfo info = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull("InsuranceInfo should not be null", info);

        // Verify all core fields are populated
        Assert.assertEquals("CustomerId should match", dynamicCustomerId, info.getCustomerId());
        Assert.assertEquals("CardHolderId should match (unmasked in token)", CARDHOLDER_ID, info.getCardHolderId());
        Assert.assertEquals("RxBin should match", BIN_NUMBER, info.getRxBin());
        Assert.assertEquals("RxPCN should match", PCN, info.getRxPCN());
        Assert.assertEquals("RxGroup should match", GROUP_ID, info.getRxGroup());
        Assert.assertNotNull("ProcessorName should not be null", info.getProcessorName());
        Assert.assertNotNull("CarrierId should not be null", info.getCarrierId());
        Assert.assertNotNull("PlanId should not be null", info.getPlanId());
        Assert.assertNotNull("IsWalmartEligible should not be null", info.getIsWalmartEligible());
        Assert.assertTrue("IsWalmartEligible should be true", info.getIsWalmartEligible());
        Assert.assertNotNull("PersonCode should not be null", info.getPersonCode());
    }

    @Test(description = "ValidateToken: Verify category, carrierAbbr, planRefCode fields from decrypted token")
    public void validateTokenRDMEnrichedFieldsTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validToken);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(serviceResponse.getDataResponse());
        InsuranceInfo info = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull("InsuranceInfo should not be null", info);

        // These fields come from RDM enrichment during token creation
        Assert.assertNotNull("Category should not be null", info.getCategory());
        Assert.assertNotNull("CarrierAbbr should not be null", info.getCarrierAbbr());
        Assert.assertNotNull("PlanRefCode should not be null", info.getPlanRefCode());
    }

    @Test(description = "ValidateToken: Cross-validate decrypted token fields with RDM lookup")
    public void validateTokenCrossValidateWithRDMTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validToken);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(serviceResponse.getDataResponse());
        InsuranceInfo info = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);

        // Cross-validate with RDM directly
        ServiceResponse rdmResponse = insuranceWrapper.getRDM(BIN_NUMBER, PCN);
        Assert.assertEquals("RDM should return 200", 200, rdmResponse.getStatusCode());

        JsonNode rdmRoot = objectMapper.readTree(rdmResponse.getDataResponse());
        Assert.assertEquals("ProcessorName should match RDM",
                rdmRoot.get("processorName").asText(), info.getProcessorName());
        Assert.assertEquals("CarrierId should match RDM",
                String.valueOf(rdmRoot.get("insuranceCarrierCompanyId").asInt()), info.getCarrierId());
        Assert.assertEquals("PlanId should match RDM",
                String.valueOf(rdmRoot.get("insuranceCarrierPlanId").asInt()), info.getPlanId());
    }

    @Test(description = "ValidateToken: Idempotency - same token can be validated multiple times with same result")
    public void validateTokenIdempotencyTest() throws IOException {
        // First call
        ServiceResponse firstResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validToken);
        Assert.assertEquals("First call should return 200", 200, firstResponse.getStatusCode());

        JsonNode root1 = objectMapper.readTree(firstResponse.getDataResponse());
        InsuranceInfo info1 = objectMapper.treeToValue(root1.get("insuranceInfo"), InsuranceInfo.class);

        // Second call with same token
        ServiceResponse secondResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validToken);
        Assert.assertEquals("Second call should return 200", 200, secondResponse.getStatusCode());

        JsonNode root2 = objectMapper.readTree(secondResponse.getDataResponse());
        InsuranceInfo info2 = objectMapper.treeToValue(root2.get("insuranceInfo"), InsuranceInfo.class);

        // Results should be identical
        Assert.assertEquals("CustomerId should match across calls", info1.getCustomerId(), info2.getCustomerId());
        Assert.assertEquals("CardHolderId should match across calls", info1.getCardHolderId(), info2.getCardHolderId());
        Assert.assertEquals("RxBin should match across calls", info1.getRxBin(), info2.getRxBin());
        Assert.assertEquals("RxPCN should match across calls", info1.getRxPCN(), info2.getRxPCN());
        Assert.assertEquals("ProcessorName should match across calls", info1.getProcessorName(), info2.getProcessorName());
    }

    // ========================
    // CROSS-SOURCE TOKEN VALIDATION (Token from RxBin endpoint)
    // ========================

    @Test(description = "ValidateToken: Validate token generated from RxBin endpoint - cross-source verification")
    public void validateTokenFromRxBinEndpointTest() throws IOException {
        // Get token from the RxBin endpoint (different source than PatientInfo V1)
        ServiceResponse rxBinResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                dynamicCustomerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, null);
        Assert.assertEquals("RxBin endpoint should return 200", 200, rxBinResponse.getStatusCode());

        JsonNode rxBinRoot = objectMapper.readTree(rxBinResponse.getDataResponse());
        String rxBinToken = rxBinRoot.get("insuranceInfo").get("validationToken").asText();
        Assert.assertNotNull("Token from RxBin should not be null", rxBinToken);

        // Validate the RxBin-generated token via validate-and-fetch endpoint
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, rxBinToken);
        Assert.assertEquals("Expected HTTP 200 for RxBin token", 200, serviceResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(serviceResponse.getDataResponse());
        InsuranceInfo info = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull("InsuranceInfo should not be null", info);
        Assert.assertEquals("CustomerId should match", dynamicCustomerId, info.getCustomerId());
        Assert.assertEquals("CardHolderId should match", CARDHOLDER_ID, info.getCardHolderId());
        Assert.assertEquals("RxBin should match", BIN_NUMBER, info.getRxBin());
        Assert.assertEquals("RxPCN should match", PCN, info.getRxPCN());
    }

    // ========================
    // INPUT VALIDATION TESTS (400 errors)
    // ========================

    @Test(description = "ValidateToken: Verify 400 when validationToken is empty string")
    public void validateTokenEmptyTokenTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, "");
        Assert.assertEquals("Expected HTTP 400 for empty token", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "ValidateToken: Verify 400 when validationToken is whitespace only")
    public void validateTokenWhitespaceTokenTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, "   ");
        Assert.assertEquals("Expected HTTP 400 for whitespace-only token", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "ValidateToken: Verify 400 when customerId in token does not match request customerId")
    public void validateTokenCustomerIdMismatchTest() throws IOException {
        String wrongCustomerId = CommonUtil.generateRandomFirstName(36);
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(wrongCustomerId, validToken);
        Assert.assertEquals("Expected HTTP 400 for customerId mismatch", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // INVALID TOKEN TESTS (500 errors - decryption failure)
    // ========================

    @Test(description = "ValidateToken: Verify 500 when token is tampered - appended character")
    public void validateTokenTamperedAppendCharTest() throws IOException {
        String tamperedToken = validToken + "d";
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, tamperedToken);
        Assert.assertEquals("Expected HTTP 500 for tampered token (appended char)", 500, serviceResponse.getStatusCode());
    }

    @Test(description = "ValidateToken: Verify 500 when token is completely random garbage string")
    public void validateTokenRandomGarbageTest() throws IOException {
        String garbageToken = CommonUtil.generateRandomFirstName(64);
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, garbageToken);
        Assert.assertEquals("Expected HTTP 500 for random garbage token", 500, serviceResponse.getStatusCode());
    }

    @Test(description = "ValidateToken: Verify 500 when token is valid base64 but not AES-encrypted data")
    public void validateTokenInvalidBase64ContentTest() throws IOException {
        // Valid base64 string but not AES-encrypted InsuranceInfo
        String fakeBase64Token = java.util.Base64.getEncoder().encodeToString("this-is-not-encrypted-data-at-all".getBytes());
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, fakeBase64Token);
        Assert.assertEquals("Expected HTTP 500 for invalid base64 content", 500, serviceResponse.getStatusCode());
    }

    @Test(description = "ValidateToken: Verify 500 when token has truncated characters from valid token")
    public void validateTokenTruncatedTest() throws IOException {
        // Take only first half of valid token — will fail AES decryption
        String truncatedToken = validToken.substring(0, validToken.length() / 2);
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, truncatedToken);
        Assert.assertEquals("Expected HTTP 500 for truncated token", 500, serviceResponse.getStatusCode());
    }

    // ========================
    // EDGE CASES
    // ========================

    @Test(description = "ValidateToken: Verify 500 when customerId is empty - Spring routing error")
    public void validateTokenEmptyCustomerIdTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.validateAndFetchInsuranceToken("", validToken);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // Empty customerId causes Spring NoResourceFoundException (URL becomes /v1/customer/insurance/action/validate-and-fetch without customerId)
        Assert.assertEquals("Expected HTTP 500 for empty customerId", 500, serviceResponse.getStatusCode());
    }

    // ========================
    // HELPER METHODS
    // ========================

    private static BomTestDataSetupRequest buildBomTestDataSetupRequest(
            String firstName, String lastName, String dob, String gender,
            String addressLine1, String city, String postalCode, String state,
            String storeNbr, String storeCountryCode,
            String cardholderId, String groupId, String iin, String pcn) {

        BomTestDataSetupRequest.Address address = BomTestDataSetupRequest.Address.builder()
                .addressLine1(addressLine1).city(city).postalCode(postalCode).state(state).build();
        BomTestDataSetupRequest.Patient patient = BomTestDataSetupRequest.Patient.builder()
                .lastName(lastName).firstName(firstName).birthdate(dob).gender(gender)
                .address(address).build();
        BomTestDataSetupRequest.Request request = BomTestDataSetupRequest.Request.builder()
                .patient(patient).storeNbr(storeNbr).storeCountryCode(storeCountryCode).build();

        return BomTestDataSetupRequest.builder()
                .request(request)
                .numberOfPayer(1)
                .cardholderId(Collections.singletonList(cardholderId))
                .groupId(Collections.singletonList(groupId))
                .iin(Collections.singletonList(iin))
                .pcn(Collections.singletonList(pcn))
                .build();
    }
}
