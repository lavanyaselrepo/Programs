package insuranceorchestrator;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.ReplaceInsurance.ReplaceInsuranceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.fetchInsurance.CprViewInsuranceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ReplaceInsurance.ReplaceInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatInsReplacementInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.*;

public class ReplaceInsuranceTests {

  InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
  Gson gson = new Gson();
  Random rand = new Random();

  private CARetrofit caRetrofit;
  private static final String CARDHOLDER_ID = "248201700";
  private static final Integer CARRIER_ID = 100426;
  private static final Integer PLAN_ID = 171;
  private static final Integer CATEGORY = 1006;

  private static final String CARDHOLDER_ID_2 = "72939293";
  private static final Integer CARRIER_ID_2 = 116653;
  private static final Integer PLAN_ID_2 = 100;

  private static final String CARDHOLDER_ID_3 = "33653564542";
  private static final Integer CARRIER_ID_3 = 123495;
  private static final Integer PLAN_ID_3 = 127;

  private static final String CARDHOLDER_ID_4 = "33653564543";
  private static final Integer CARRIER_ID_4 = 121312;
  private static final Integer PLAN_ID_4 = 127;
  private static final Integer CATEGORY_4 = 1000;

  private static final String DISCOUNT_CARDHOLDER_ID = "12331892332";
  private static final Integer DISCOUNT_CARRIER_ID = 116135;
  private static final Integer DISCOUNT_PLAN_ID = 179;
  private static final Integer DISCOUNT_CATEGORY = 1005;

  private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
  private IDatabaseContext accountDbContext;
  private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

  private List<String> pharmacyAccountToBeDeleted;
  private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
  private ObjectMapper objectMapper;

  @BeforeClass
  void setContext() throws IOException {
    accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
    cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    caRetrofit = new CARetrofit();
    pharmacyAccountToBeDeleted = new ArrayList<>();
    cprProfilesToBeDeletedList = new ArrayList<>();
    objectMapper = new ObjectMapper();
  }

  @Test(priority = 0, description = "replace insurance success case")
  void testReplaceInsuranceSuccess() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "Y");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_2,
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replace Insurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);

    // Validate status code
    Assert.assertEquals("Status code is not matching", 200, serRes.getStatusCode());

    CprViewInsuranceRequest cprViewInsuranceRequest =
        CprViewInsuranceRequest.builder()
            .storeNbr(cprUpdatePatientRequest.getStoreNbr())
            .patientId(cprUpdatePatientRequest.getPatientId())
            .build();
    String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
    ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
    ViewInsuranceResponse viewInsuranceResponse =
        serResView.getDataResponse(ViewInsuranceResponse.class);

    Integer billSeqNumber =
        viewInsuranceResponse.getPatientInsuranceViewInfo().stream()
            .filter(
                patientInsuranceViewInfo ->
                    patientInsuranceViewInfo
                            .getInsuranceCarrierId()
                            .equalsIgnoreCase(String.valueOf(CARRIER_ID_2))
                        && patientInsuranceViewInfo
                            .getInsurancePlanId()
                            .equalsIgnoreCase(String.valueOf(PLAN_ID_2)))
            .findAny()
            .map(PatientInsuranceViewInfo::getBillingSeqNbr)
            .orElse(null);

    Assert.assertEquals("Not Added at expected position", Integer.valueOf(1), billSeqNumber);
    Assert.assertEquals(
        "PatInsReplacementInfo size is not as expected",
        viewInsuranceResponse.getPatInsReplacementInfo().size(),
        1);
    Assert.assertEquals(
        viewInsuranceResponse.getPatInsReplacementInfo().get(0).getCardholderId(), CARDHOLDER_ID_2);
  }

  @Test(priority = 1, description = "replace insurance when insurance is already replaced")
  void testReplaceInsuranceWithAlreadyReplacedInsurance() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "Y");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_2,
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replaceInsurance API
    ServiceResponse serRes1 = insuranceWrapper.replaceInsurance(payload, customerId);
    Assert.assertEquals("Status code is not matching", 200, serRes1.getStatusCode());

    // Calling replaceInsurance API again with same payload
    ServiceResponse serRes2 = insuranceWrapper.replaceInsurance(payload, customerId);
    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes2.getDataResponse(ReplaceInsuranceErrorResponse.class);

    // Step - 3: Validate status code
    Assert.assertEquals("Status code is not matching", 400, serRes2.getStatusCode());

    // Step - 4: Validate Error Code
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1006");
  }

  @Test(priority = 2, description = "replace insurance when cid does not have pharmacy account")
  void testReplaceInsuranceWithInvalidCid() throws IOException, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);

    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "N");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    SharedUtils.createCPRAccountWithInsurance(
        "9928",
        CommonUtil.generateRandomNumber(6),
        firstName,
        lastName,
        "M",
        "1996-01-01",
        CommonUtil.generateRandomNumber(10),
        zipCode,
        patientInsuranceInfoList,
        cprPatientUpdateRetrofit);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_2,
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replaceInsurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);
    Assert.assertEquals("Status code is not matching", 400, serRes.getStatusCode());

    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes.getDataResponse(ReplaceInsuranceErrorResponse.class);

    // Validate Error Code
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1009");
  }

  @Test(priority = 3, description = "replace insurance when existing insurance is not found in cpr")
  void testReplaceInsuranceExistingInsuranceNotFoundInCPR() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "N");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            "INVALID_CARD_HOLDER_ID",
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_2,
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replace Insurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);
    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes.getDataResponse(ReplaceInsuranceErrorResponse.class);
    // Validate status code
    Assert.assertEquals("Status code is not matching", 400, serRes.getStatusCode());
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1006");
  }

  @Test(
      priority = 4,
      description = "replace insurance when replaced with insurance is not found in cpr")
  void testReplaceInsuranceReplacedWithInsuranceNotFoundInCPR() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "N");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(20000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            "INVALID_CARD_HOLDER_ID",
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replace Insurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);
    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes.getDataResponse(ReplaceInsuranceErrorResponse.class);
    // Validate status code
    Assert.assertEquals("Status code is not matching", 400, serRes.getStatusCode());
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1006");
  }

  @Test(priority = 5, description = "replace insurance when replacedWithInsurance is not primary Eligible")
  void testReplaceInsuranceWhenReplaceWithInsuranceIsNotPrimaryEligible() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2,
                PLAN_ID_4,
            CARRIER_ID_4,
            CARDHOLDER_ID_4,
            CATEGORY_4,
            "Y");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);


    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_4,
            CARRIER_ID_4,
            PLAN_ID_4);

    // Calling replace Insurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);
    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes.getDataResponse(ReplaceInsuranceErrorResponse.class);
    // Validate status code
    Assert.assertEquals("Status code is not matching", 400, serRes.getStatusCode());
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1022");
  }

  @Test(priority = 6, description = "replace insurance when cardHolder Id is null")
  void testReplaceInsuranceInvalidRequest() throws IOException, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
    String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);

    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "N");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId, CARDHOLDER_ID, CARRIER_ID, PLAN_ID, null, CARRIER_ID_2, PLAN_ID_2);

    // Calling replace Insurance API
    ServiceResponse serRes = insuranceWrapper.replaceInsurance(payload, customerId);
    ReplaceInsuranceErrorResponse replaceInsuranceErrorResponse =
        serRes.getDataResponse(ReplaceInsuranceErrorResponse.class);
    // Validate status code
    Assert.assertEquals("Status code is not matching", 400, serRes.getStatusCode());
    Assert.assertEquals(replaceInsuranceErrorResponse.getError().getCode(), "DPR-DPINSOR-1006");
  }

  @Test(priority = 7, description = "replace insurance test replacement logic")
  void testReplaceInsuranceReplacementLogic() throws Exception, InterruptedException {
    // Setting up Test Data
    String emailAddress = SharedUtils.getRandomEmailAddress();
   // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
      String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
    String firstName = CommonUtil.generateRandomFirstName(8);
    String lastName = CommonUtil.generateRandomFirstName(8);
    String zipCode = CommonUtil.generateRandomNumber(6);

    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            1, PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            2, PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY, "Y");
    CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
        new CPRUpdatePatientRequest.PatientInsuranceInfo(
            3, PLAN_ID_3, CARRIER_ID_3, CARDHOLDER_ID_3, CATEGORY, "Y");
    List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
        Arrays.asList(patientInsuranceInfo1, patientInsuranceInfo2, patientInsuranceInfo3);

    CPRUpdatePatientRequest cprUpdatePatientRequest =
        SharedUtils.createCPRAccountWithInsurance(
            "9928",
            CommonUtil.generateRandomNumber(6),
            firstName,
            lastName,
            "M",
            "1996-01-01",
            CommonUtil.generateRandomNumber(10),
            zipCode,
            patientInsuranceInfoList,
            cprPatientUpdateRetrofit);
    cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

    accountDbContext.executeInsertQuery(
        getInsertOcidQuery(
            CommonUtil.generateRandomNumber(9),
            String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
            String.valueOf(cprUpdatePatientRequest.getPatientId()),
            customerId));
    pharmacyAccountToBeDeleted.add(customerId);
    Thread.sleep(5000);

    // Building the Request payload
    String payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID,
            CARRIER_ID,
            PLAN_ID,
            CARDHOLDER_ID_3,
            CARRIER_ID_3,
            PLAN_ID_3);

    // Calling replace Insurance API
    ServiceResponse serRes1 = insuranceWrapper.replaceInsurance(payload, customerId);

    // Validate status code
    Assert.assertEquals("Status code is not matching", 200, serRes1.getStatusCode());

    CprViewInsuranceRequest cprViewInsuranceRequest1 =
        CprViewInsuranceRequest.builder()
            .storeNbr(cprUpdatePatientRequest.getStoreNbr())
            .patientId(cprUpdatePatientRequest.getPatientId())
            .build();
    String viewInsuranceCPRPayload1 = objectMapper.writeValueAsString(cprViewInsuranceRequest1);
    ServiceResponse serResView1 = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload1);
    ViewInsuranceResponse viewInsuranceResponse1 =
        serResView1.getDataResponse(ViewInsuranceResponse.class);

    // Call replace Insurance API Again with different Insurance
    payload =
        buildReplaceInsuranceRequest(
            customerId,
            CARDHOLDER_ID_3,
            CARRIER_ID_3,
            PLAN_ID_3,
            CARDHOLDER_ID_2,
            CARRIER_ID_2,
            PLAN_ID_2);

    // Calling replace Insurance API
    ServiceResponse serRes2 = insuranceWrapper.replaceInsurance(payload, customerId);

    // Validate status code
    Assert.assertEquals("Status code is not matching", 200, serRes2.getStatusCode());

    CprViewInsuranceRequest cprViewInsuranceRequest =
        CprViewInsuranceRequest.builder()
            .storeNbr(cprUpdatePatientRequest.getStoreNbr())
            .patientId(cprUpdatePatientRequest.getPatientId())
            .build();
    String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
    ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
    ViewInsuranceResponse viewInsuranceResponse =
        serResView.getDataResponse(ViewInsuranceResponse.class);

    Integer billSeqNumber =
        viewInsuranceResponse.getPatientInsuranceViewInfo().stream()
            .filter(
                patientInsuranceViewInfo ->
                    patientInsuranceViewInfo
                            .getInsuranceCarrierId()
                            .equalsIgnoreCase(String.valueOf(CARRIER_ID_2))
                        && patientInsuranceViewInfo
                            .getInsurancePlanId()
                            .equalsIgnoreCase(String.valueOf(PLAN_ID_2)))
            .findAny()
            .map(PatientInsuranceViewInfo::getBillingSeqNbr)
            .orElse(null);
    String activeInd =
        viewInsuranceResponse.getPatInsReplacementInfo().stream()
            .filter(
                patInsReplacementInfo ->
                    patInsReplacementInfo.getCardholderId().equalsIgnoreCase(CARDHOLDER_ID_2))
            .findAny()
            .map(PatInsReplacementInfo::getActiveInd)
            .orElse(null);

    Assert.assertEquals("Not Added at expected position", Integer.valueOf(1), billSeqNumber);
    Assert.assertEquals("Active Ind is not matching", activeInd, "Y");
  }

  private static String getInsertOcidQuery(
      String onlineCustId, String authStore, String authPatientId, String uuid) {
    return String.format(
        "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
        onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
  }

  private String buildReplaceInsuranceRequest(
      String customerId,
      String existingCardHolderId,
      Integer existingCarrierId,
      Integer existingPlanId,
      String replacedWithCardHolderId,
      Integer replacedWithCarrierId,
      Integer replacedWithPlanId)
      throws JsonProcessingException {
    ReplaceInsuranceRequest request =
        ReplaceInsuranceRequest.builder()
            .insuranceInfo(
                Collections.singletonList(
                    ReplaceInsuranceRequest.InsuranceInfo.builder()
                        .customerId(customerId)
                        .isDependent(false)
                        .insurances(
                            Collections.singletonList(
                                ReplaceInsuranceRequest.Insurance.builder()
                                    .existingInsurance(
                                        ReplaceInsuranceRequest.ExistingInsurance.builder()
                                            .cardholderId(existingCardHolderId)
                                            .carrierId(String.valueOf(existingCarrierId))
                                            .planId(String.valueOf(existingPlanId))
                                            .build())
                                    .replacedWithInsurance(
                                        ReplaceInsuranceRequest.ReplacedWithInsurance.builder()
                                            .cardholderId(replacedWithCardHolderId)
                                            .carrierId(String.valueOf(replacedWithCarrierId))
                                            .planId(String.valueOf(replacedWithPlanId))
                                            .build())
                                    .build()))
                        .build()))
            .build();
    return objectMapper.writeValueAsString(request);
  }

  /**
   * Clean up for all created accounts
   *
   * @throws IOException
   */
  @AfterTest
  void cleanUp() throws IOException {
    cprProfilesToBeDeletedList.forEach(
        request -> {
          request.getPatientInfo().setPatientStatusCode(20708);
          try {
            Response<CPRUpdatePatientResponse> response =
                cprPatientUpdateRetrofit.createOrUpdatePatient(request);
            if (!(response.code() == 202
                    && response.body() != null
                    && response.body().getErrors().isEmpty())
                && response.code() != 406) {
              throw new RuntimeException(
                  "CPR Account failed to update with status code 20708 for PatientId :"
                      + request.getPatientId()
                      + " StoreNbr :"
                      + request.getStoreNbr()
                      + " . HttpStatusCode : "
                      + response.code());
            }
          } catch (IOException e) {
          }
        });

    pharmacyAccountToBeDeleted.forEach(this::deleteOCPRecord);
  }

  private void deleteOCPRecord(String uuid) {
    String deleteQuery =
        String.format(
            "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
    accountDbContext.executeQuery(deleteQuery);
  }
}
