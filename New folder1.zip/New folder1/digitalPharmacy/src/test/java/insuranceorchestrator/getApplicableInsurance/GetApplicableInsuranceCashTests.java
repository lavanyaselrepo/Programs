package insuranceorchestrator.getApplicableInsurance;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetApplicableInsurance.GetApplicableInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.ApplicablePaymentType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.GetApplicableInsuranceV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GetApplicableInsuranceCashTests {
    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper;
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private CARetrofit caRetrofit;
    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private String customerAccountId = null;
    private static final String CASH = "CASH";
    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;

    @BeforeClass
    void setContext() throws Exception {
        accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        caRetrofit = new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();

        // test data
        String emailAddress = SharedUtils.getRandomEmailAddress();
         customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
      //  customerAccountId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        null,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerAccountId));
        pharmacyAccountToBeDeleted.add(customerAccountId);
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response =
                                cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted.forEach(this::deleteOCPRecord);
    }

    @Test(priority = 0, description = "Cash case when primary insurance is present and active, ApplicablePaymentType= COVERAGE_MODIFIED_TO_DEFAULT")
    public void testCashCaseWhenPrimaryInsuranceIsPresentAndActive() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, firstName, lastName, CATEGORY_2);

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Collections.singletonList(patientInsuranceInfo);
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Spouse",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRelation());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getProcessorName());
        Assert.assertEquals(
                "1004",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCategory());
        Assert.assertEquals(
                "601574",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxBin());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxPCN());
        Assert.assertEquals(
                "1626281726",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxGroup());
    }

    @Test(priority = 1, description = "Cash case when primary insurance is present and inactive, ApplicablePaymentType= CASH_NOT_MODIFIED")
    public void testCashCaseWhenPrimaryInsuranceIsPresentAndInActive() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
      //  String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY_2, "N");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Collections.singletonList(patientInsuranceInfo);
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances());
        Assert.assertEquals(
                ApplicablePaymentType.CASH_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(priority = 2, description = "Cash case when primary insurance is not present, ApplicablePaymentType= CASH_NOT_MODIFIED")
    public void testCashCaseWhenPrimaryInsuranceIsNotPresent() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);
        
        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances());
        Assert.assertEquals(
                ApplicablePaymentType.CASH_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(priority = 3, description = "Cash case when primary insurance is present and discount card, ApplicablePaymentType= CASH_NOT_MODIFIED")
    public void testCashCaseWhenPrimaryInsuranceIsPresentAndDiscountCard() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, 1005, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Collections.singletonList(patientInsuranceInfo);
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances());
        Assert.assertEquals(
                ApplicablePaymentType.CASH_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(priority = 4, description = "Cash case when primary insurance is present and active but last Adjudicated or last Change timestamp is greater than 18months, ApplicablePaymentType= CASH_NOT_MODIFIED")
    public void testCashCaseWhenPrimaryInsuranceIsPresentAndActiveButlastAdjudicatedOrLastChangeTsIsGreaterThan18Months() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String patientId = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo =
                new CPRUpdatePatientRequest.PatientInsuranceInfo(
                        PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, firstName, lastName, CATEGORY_2);

        patientInsuranceInfo.setLastChangeTs(LocalDateTime.now().minusMonths(19).toString());

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList =
                Collections.singletonList(patientInsuranceInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances());
        Assert.assertEquals(
                ApplicablePaymentType.CASH_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    private String buildGetApplicableInsuranceRequest(
            List<GetApplicableInsuranceV1Request.PaymentInfo> customerPaymentInfo)
            throws JsonProcessingException {
        GetApplicableInsuranceV1Request request =
                GetApplicableInsuranceV1Request.builder().paymentInfo(customerPaymentInfo).build();
        return objectMapper.writeValueAsString(request);
    }

    private static String getInsertOCidQuery(
            String onlineCustId, String authStore, String authPatientId, String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void logAccountDetails(
            String customerAccountId, String reqId, String reqTrackingId, String trackID) {
        Reporter.logJSON("Customer Account Id", customerAccountId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("tracking Id", trackID);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery =
                String.format(
                        "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }
}
