package insuranceorchestrator.getApplicableInsurance;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.GroupType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.request.CAAddDependentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.model.response.CAAddDependentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetApplicableInsurance.GetApplicableInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.GetApplicableInsuranceV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GetApplicableInsuranceWhenMultiplePaymentInfoPresentTests {
    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper;
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private CARetrofit caRetrofit;
    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private static final String COVERAGE = "COVERAGE";

    private static final String CARDHOLDER_ID = "248201700";
    private static final Integer CARRIER_ID = 121312;
    private static final Integer PLAN_ID = 120;
    private static final Integer CATEGORY = 1002;

    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;

    @BeforeClass
    void setContext() throws IOException {
        accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        caRetrofit = new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response =
                                cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted.forEach(this::deleteOCPRecord);
    }

    @Test(priority = 0, description = "When more than 2 customer payment info present")
    public void testGetApplicableInsuranceSuccessCaseWhenMoreThanTwoPaymentInfoPresent()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String emailAddress1 = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        //String customerAccountId1 = SharedUtils.createCAIndividualAccount(emailAddress1, caRetrofit);
        String customerAccountId1 =CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress1);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String firstName1 = CommonUtil.generateRandomFirstName(8);
        String lastName1 = CommonUtil.generateRandomFirstName(8);
        String storeNbr1 = CommonUtil.generateRandomNumber(5);
        String patientId1 = CommonUtil.generateRandomNumber(6);
        String zipCode1 = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName1, CARDHOLDER_ID_2, lastName1, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList1 =
                new ArrayList<>();
        patientInsuranceInfoList1.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);

        CPRUpdatePatientRequest cprUpdatePatientRequest1 =
                createCPRProfileWithInsurance(
                        storeNbr1,
                        patientId1,
                        firstName1,
                        lastName1,
                        zipCode1,
                        patientInsuranceInfoList1,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest1, customerAccountId1);

        caAddDependent(
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.APPROVED,
                customerAccountId1,
                customerAccountId);

        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        List<GetApplicableInsuranceV1Request.PaymentInfo> paymentInfoList = new ArrayList<>();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj1 =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId1)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("2")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        paymentInfoList.add(paymentInfoObj);
        paymentInfoList.add(paymentInfoObj1);
        String payload = buildGetApplicableInsuranceRequest(paymentInfoList);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Optional<GetApplicableInsuranceV1Response.CustomerPaymentInfo> firstCustomer =
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().stream()
                        .filter(info -> customerAccountId.equals(info.getCustomerId()))
                        .findFirst();

        Assert.assertTrue("First customer not found", firstCustomer.isPresent());
        Assert.assertEquals("1", firstCustomer.get().getPaymentInfo().getFirst().getId());
        Assert.assertEquals(
                CARDHOLDER_ID,
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCardholderId());
        Assert.assertEquals(
                CARRIER_ID.toString(),
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCarrierId());
        Assert.assertEquals(
                PLAN_ID.toString(),
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getPlanId());
        Assert.assertEquals(
                firstName,
                firstCustomer
                        .get()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCardholderLastName());
        Assert.assertEquals(
                "Spouse", firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRelation());
        Assert.assertNotNull(
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getProcessorName());
        Assert.assertEquals(
                "1002", firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCategory());
        Assert.assertEquals(
                "011610", firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxBin());
        Assert.assertEquals(
                "WMARTECL2", firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxPCN());
        Assert.assertEquals(
                "1626281726",
                firstCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxGroup());

        // Validate the second customer
        Optional<GetApplicableInsuranceV1Response.CustomerPaymentInfo> secondCustomer =
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().stream()
                        .filter(info -> customerAccountId1.equals(info.getCustomerId()))
                        .findFirst();

        Assert.assertTrue("Second customer not found", secondCustomer.isPresent());
        Assert.assertEquals("2", secondCustomer.get().getPaymentInfo().getFirst().getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getPlanId());
        Assert.assertEquals(
                firstName1,
                secondCustomer
                        .get()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName1,
                secondCustomer
                        .get()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Spouse",
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRelation());
        Assert.assertNotNull(
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getProcessorName());
        Assert.assertEquals(
                "1004", secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getCategory());
        Assert.assertEquals(
                "601574", secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxBin());
        Assert.assertNull(
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxPCN());
        Assert.assertEquals(
                "1626281726",
                secondCustomer.get().getPaymentInfo().getFirst().getInsurances().getFirst().getRxGroup());
    }

    private String buildGetApplicableInsuranceRequest(
            List<GetApplicableInsuranceV1Request.PaymentInfo> customerPaymentInfo)
            throws JsonProcessingException {
        GetApplicableInsuranceV1Request request =
                GetApplicableInsuranceV1Request.builder().paymentInfo(customerPaymentInfo).build();
        return objectMapper.writeValueAsString(request);
    }

    private static String getInsertOCidQuery(
            String onlineCustId, String authStore, String authPatientId, String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void logAccountDetails(
            String customerAccountId, String reqId, String reqTrackingId, String trackID) {
        Reporter.logJSON("Customer Account Id", customerAccountId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("tracking Id", trackID);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery =
                String.format(
                        "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    private CPRUpdatePatientRequest.PatientInsuranceInfo buildCPRInsuranceInfo(
            Integer billingSeqNbr,
            String cardholderFirstName,
            String cardholderId,
            String cardholderLastName,
            Integer insPlanTypeCode,
            Integer insuranceCarrierId,
            Integer insurancePlanId,
            String coverageInd) {
        return CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingSeqNbr(billingSeqNbr)
                .billingGroupNbr("1626281726")
                .cardholderFirstName(cardholderFirstName)
                .cardholderId(cardholderId)
                .cardholderLastName(cardholderLastName)
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(insPlanTypeCode)
                .insuranceCarrierId(insuranceCarrierId)
                .insurancePlanId(insurancePlanId)
                .lastChangeTs(LocalDateTime.now().toString())
                .lastChangeUserId("COMACCTCRE")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd(coverageInd)
                .build();
    }

    private void createPharmacyAccount(
            CPRUpdatePatientRequest cprUpdatePatientRequest, String customerAccountId) {
        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerAccountId));
        pharmacyAccountToBeDeleted.add(customerAccountId);
    }

    private CPRUpdatePatientRequest createCPRProfileWithInsurance(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String zipCode,
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList,
            CprPatientUpdateRetrofit cprPatientUpdateRetrofit)
            throws IOException {
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        return cprUpdatePatientRequest;
    }

    private void caAddDependent(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId)
            throws IOException {
        CAAddDependentRequest caAddDependentRequest =
                getCAAddDependentRequest(type, status, dependentAccountId, caregiverAccountId);
        Response<CAAddDependentResponse> response = null;

        // This will try to create a person account in CA, 3 times if account creation fails
        for (int i = 0; i < 3; i++) {
            response = caRetrofit.addDependent(caAddDependentRequest);
            if (!(response.code() == 200
                    && response.body() != null
                    && response.body().getPayload() != null)
                    && !response.isSuccessful()) {
                Reporter.logJSON("Exception", response.errorBody().toString());
                if (i == 2) {
                    throw new RuntimeException(
                            "CA add dependent failed. HttpStatusCode : " + response.code());
                }
            } else break;
        }
    }

    private CAAddDependentRequest getCAAddDependentRequest(
            DependentInfo.TypeEnum type,
            DependentInfo.LinkageStatusEnum status,
            String dependentAccountId,
            String caregiverAccountId) {
        return CAAddDependentRequest.builder()
                .payload(
                        CAAddDependentRequest.Payload.builder()
                                .dependent(
                                        CAAddDependentRequest.Dependent.builder()
                                                .groupType(GroupType.FAM)
                                                .memberId(
                                                        CAAddDependentRequest.Identifier.builder()
                                                                .id(dependentAccountId)
                                                                .build())
                                                .membershipStatus(status)
                                                .memberType(type)
                                                .ownerId(
                                                        CAAddDependentRequest.Identifier.builder()
                                                                .id(caregiverAccountId)
                                                                .build())
                                                .build())
                                .build())
                .build();
    }
}
