package insuranceorchestrator.getApplicableInsurance;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetApplicableInsurance.GetApplicableInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.ApplicablePaymentType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.GetApplicableInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.GetApplicableInsuranceV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class GetApplicableInsuranceValidationTests {
    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper;
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private CARetrofit caRetrofit;
    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private String customerAccountId = null;
    private final String patientId = CommonUtil.generateRandomNumber(6);
    private static final String COVERAGE = "COVERAGE";
    private static final String CASH = "CASH";

    private static final String CARDHOLDER_ID = "248201700";
    private static final Integer CARRIER_ID = 121312;
    private static final Integer PLAN_ID = 120;
    private static final Integer CATEGORY = 1002;

    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;

    private static final String CARDHOLDER_ID_3 = "33653564542";
    private static final Integer CARRIER_ID_3 = 121312;
    private static final Integer PLAN_ID_3 = 121;

    @BeforeClass
    void setContext() throws Exception {
        accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        caRetrofit = new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();

        // test data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // customerAccountId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        customerAccountId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        "5572",
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        null,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerAccountId));
        pharmacyAccountToBeDeleted.add(customerAccountId);
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response =
                                cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted.forEach(this::deleteOCPRecord);
    }

    @Test(priority = 0, description = "When Payment Info Is null in Request")
    public void testWhenPaymentInfoIsNullInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        String payload = buildGetApplicableInsuranceRequest(null);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 1, description = "When Payment Info Is empty in Request")
    public void testWhenPaymentInfoIsEmptyInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        String payload = buildGetApplicableInsuranceRequest(new ArrayList<>());

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 2, description = "When Customer Id Is null in Request")
    public void testWhenCustomerIdIsNullInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder().customerId(null).build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 3, description = "When Customer Id Is empty in Request")
    public void testWhenCustomerIdIsEmptyInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder().customerId("").build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 4, description = "When PaymentList Is null in Request")
    public void testWhenPaymentListIsNullInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(null)
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 5, description = "When PaymentList Is empty in Request")
    public void testWhenPaymentListIsEmptyInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(new ArrayList<>())
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 6, description = "When Id is Null in Request")
    public void testWhenIdIsNullInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder().id(null).build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 7, description = "When Id is Empty in Request")
    public void testWhenIdIsEmptyInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder().id("").build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 8,
            description = "When Payment Type Is COVERAGE And empty Insurance list in Request")
    public void testWhenPaymentTypeIsNotCASHOrCOVERAGEInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(new ArrayList<>())
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 9,
            description = "When Payment Type Is COVERAGE And null Insurance list in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndNullInsuranceInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(null)
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 10,
            description = "When Payment Type Is COVERAGE And empty Insurance list in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndEmptyInsuranceInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(new ArrayList<>())
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 11,
            description = "When Payment Type Is COVERAGE And cardholderId is Null in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndNullCardHolderIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(null)
                                                                        .carrierId("12345")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 12,
            description = "When Payment Type Is COVERAGE And cardholderId is Empty in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndEmptyCardHolderIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("")
                                                                        .carrierId("12345")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 13,
            description = "When Payment Type Is COVERAGE And carrier id is null in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndNullCarriedIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId(null)
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 14,
            description = "When Payment Type Is COVERAGE And carrier id is empty in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndEmptyCarriedIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 15, description = "When Payment Type Is COVERAGE And plan id is null in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndNullPlanIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("12345")
                                                                        .planId(null)
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 16,
            description = "When Payment Type Is COVERAGE And plan id is empty in Request")
    public void testWhenPaymentTypeIsCOVERAGEAndEmptyPlanIdInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 17,
            description = "When Payment Type Is CASH And insurance is present in Request")
    public void testWhenPaymentTypeIsCASHAndInsurancePresentInRequest() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 18, description = "When 204 from CustomerInfoV2 as both CID is same")
    public void testWhen204FromCustomerInfoV2() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code (204 from v2 is mapped to 400 in insurance orchestrator)
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1009", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 19, description = "When 404 from CustomerInfoV2 as both CID are different")
    public void testWhen404FromCustomerInfoV2() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String customerId = CommonUtil.randomUUID();
        logAccountDetails(customerId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(CommonUtil.randomUUID())
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse = insuranceWrapper.getApplicableInsurance(payload, customerId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 404, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-3004", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 20, description = "When dependent not present in dependent list")
    public void test400FromCustomerInfoV2WhenDependentNotPresentInDependentList() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(CommonUtil.randomUUID())
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-3006", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(
            priority = 21,
            description = "When customerId present in request is neither a self or dependent")
    public void test400FromCustomerInfoV2WhenCustomerIdPresentInRequestIsNeitherASelfOrDependent()
            throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        List<GetApplicableInsuranceV1Request.PaymentInfo> paymentInfoList = new ArrayList<>();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(CommonUtil.randomUUID())
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("1234")
                                                                        .planId("123")
                                                                        .build()))
                                                .build()))
                        .build();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj1 =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(CommonUtil.randomUUID())
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("2")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("DEF")
                                                                        .carrierId("5678")
                                                                        .planId("172")
                                                                        .build()))
                                                .build()))
                        .build();
        paymentInfoList.add(paymentInfoObj);
        paymentInfoList.add(paymentInfoObj1);
        String payload = buildGetApplicableInsuranceRequest(paymentInfoList);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceErrorResponse getApplicableInsuranceErrorResponse =
                serviceResponse.getDataResponse(GetApplicableInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());

        // Step - 4: Validate Error Code
        Assert.assertEquals(
                "DPR-DPINSOR-1021", getApplicableInsuranceErrorResponse.getError().getCode());
    }

    @Test(priority = 22, description = "When 204 from cpr view insurance")
    public void test200FromGetApplicableInsuranceWhen204FromCPRViewInsurance() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        List<GetApplicableInsuranceV1Request.PaymentInfo> paymentInfoList = new ArrayList<>();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId("121312")
                                                                        .planId("120")
                                                                        .build()))
                                                .build()))
                        .build();
        paymentInfoList.add(paymentInfoObj);
        String payload = buildGetApplicableInsuranceRequest(paymentInfoList);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        // Calling view cpr insurance API
        String viewCPRPayload = String.format("{\"storeNbr\":9928,\"patientId\":%s}", patientId);
        ServiceResponse cprResponse = insuranceWrapper.viewInsuranceCPR(viewCPRPayload);

        // Validate status code
        Assert.assertEquals(204, cprResponse.getStatusCode());
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
    }

    @Test(priority = 25, description = "When 204 from RDM")
    public void test400FromGetApplicableInsuranceWhen204FromRDMRxBinNullForLastApplied() throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String carrierId = "1234";
        String planId = "123";
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        List<GetApplicableInsuranceV1Request.PaymentInfo> paymentInfoList = new ArrayList<>();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("ABC")
                                                                        .carrierId(carrierId)
                                                                        .planId(planId)
                                                                        .build()))
                                                .build()))
                        .build();
        paymentInfoList.add(paymentInfoObj);
        String payload = buildGetApplicableInsuranceRequest(paymentInfoList);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        // Calling rdm get by plan id API
        ServiceResponse rdmResponse =
                insuranceWrapper.getRDMInsuranceByCarrierIdAndPlanId(carrierId, planId);

        // Validate status code
        Assert.assertEquals(204, rdmResponse.getStatusCode());
        Assert.assertEquals(serviceResponse.getDataResponse(), 400, serviceResponse.getStatusCode());
    }

    @Test(priority = 26, description = "When All 3 types of insurance are present in the request")
    public void test200FromGetApplicableInsuranceWhenAll3TypeOfInsuranceIsPresent()
            throws IOException {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        List<GetApplicableInsuranceV1Request.PaymentInfo> paymentInfoList = new ArrayList<>();
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(CASH)
                                                .build(),
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("WBR347")
                                                                        .carrierId("116135")
                                                                        .planId("172")
                                                                        .build()))
                                                .build(),
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("WBR146")
                                                                        .carrierId("123495")
                                                                        .planId("127")
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId("WBR348")
                                                                        .carrierId("120103")
                                                                        .planId("105")
                                                                        .build()))
                                                .build()))
                        .build();
        paymentInfoList.add(paymentInfoObj);
        String payload = buildGetApplicableInsuranceRequest(paymentInfoList);

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
    }


    @Test(
            priority = 27,
            description = "When relation is present in cpr but null so fallback to default not specified case")
    public void testWhenRelationIsPresentInCPRButNull() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");
        patientInsuranceInfo1.setRelationshipCode(null);

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Not Specified",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRelation());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Not Specified",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRelation());
    }

    @Test(
            priority = 28,
            description = "When last applied insurance is deduped and Primary = present in cpr")
    public void testWhenLastAppliedInsuranceIsDedupedPrimaryPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, "AB72939293CD", lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        patientInsuranceInfo3.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Spouse",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRelation());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 28,
            description = "When last applied insurance is deduped and Primary = not present in cpr")
    public void testWhenLastAppliedInsuranceIsDedupedPrimaryNotPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, "AB72939293CD", lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Spouse",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRelation());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_CASH,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 29,
            description =
                    "When replacement = A → B (Active) , Replaced insurance = B is active , last applied = inactive/active , Primary = present")
    public void testWhenReplacedInsuranceIsDedupedPrimaryPresentInCPR()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String storeNbr = CommonUtil.generateRandomNumber(5);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");
        patientInsuranceInfo.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");
        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(19).toString());


        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");
        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());


        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        4, firstName, "12A72939293BC", lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");
        patientInsuranceInfo3.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo);
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList =
                new ArrayList<>();
        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo =
                buildCPRReplacementInfo(
                        CARDHOLDER_ID_2,
                        CARRIER_ID_2,
                        PLAN_ID_2,
                        CARDHOLDER_ID,
                        CARRIER_ID,
                        PLAN_ID,
                        "Y",
                        storeNbr,
                        patientId);
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getProcessorName());
        Assert.assertEquals(
                "1004",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCategory());
        Assert.assertEquals(
                "601574",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxBin());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxPCN());
        Assert.assertEquals(
                "1626281726",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxGroup());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 30,
            description =
                    "When replacement = A → B (Active) , Replaced insurance = B is active , last applied = inactive/active , Primary = not present")
    public void testWhenReplacedInsuranceIsDedupedPrimaryNotPresentInCPR()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);
        String storeNbr = CommonUtil.generateRandomNumber(5);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");
        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(19).toString());


        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");
        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());


        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        4, firstName, "12A72939293BC", lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");
        patientInsuranceInfo3.setLastChangeTs(LocalDateTime.now().minusMonths(1).toString());


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList =
                new ArrayList<>();
        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo =
                buildCPRReplacementInfo(
                        CARDHOLDER_ID_2,
                        CARRIER_ID_2,
                        PLAN_ID_2,
                        CARDHOLDER_ID,
                        CARRIER_ID,
                        PLAN_ID,
                        "Y",
                        storeNbr,
                        patientId);
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getProcessorName());
        Assert.assertEquals(
                "1004",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCategory());
        Assert.assertEquals(
                "601574",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxBin());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxPCN());
        Assert.assertEquals(
                "1626281726",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getRxGroup());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_CASH,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(
            priority = 31,
            description = "When replacement = null , last applied = active , Primary = any, ApplicablePaymentType= COVERAGE_NOT_MODIFIED and iref id is non-null")
    public void testWhenReplacementIsNullAndLastAppliedIsActiveAndIrefIdIsNonNull() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getIRefIds());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getIRefIds());
    }

    @Test(
            priority = 32,
            description = "When replacement = null , last applied = active , Primary = any, ApplicablePaymentType= COVERAGE_NOT_MODIFIED and iref id is non-null and size comparision")
    public void testWhenReplacementIsNullAndLastAppliedIsActiveAndIrefIdIsNonNullAndSizeComparision() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(3,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getIRefIds().size());
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertEquals(
                CARDHOLDER_ID_2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_2.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(3,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances()
                        .getFirst()
                        .getIRefIds().size());
    }

    private String buildGetApplicableInsuranceRequest(
            List<GetApplicableInsuranceV1Request.PaymentInfo> customerPaymentInfo)
            throws JsonProcessingException {
        GetApplicableInsuranceV1Request request =
                GetApplicableInsuranceV1Request.builder().paymentInfo(customerPaymentInfo).build();
        return objectMapper.writeValueAsString(request);
    }

    private static String getInsertOCidQuery(
            String onlineCustId, String authStore, String authPatientId, String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void logAccountDetails(
            String customerAccountId, String reqId, String reqTrackingId, String trackID) {
        Reporter.logJSON("Customer Account Id", customerAccountId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("tracking Id", trackID);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery =
                String.format(
                        "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    private CPRUpdatePatientRequest.PatientInsuranceInfo buildCPRInsuranceInfo(
            Integer billingSeqNbr,
            String cardholderFirstName,
            String cardholderId,
            String cardholderLastName,
            Integer insPlanTypeCode,
            Integer insuranceCarrierId,
            Integer insurancePlanId,
            String coverageInd) {
        return CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingSeqNbr(billingSeqNbr)
                .billingGroupNbr("1626281726")
                .cardholderFirstName(cardholderFirstName)
                .cardholderId(cardholderId)
                .cardholderLastName(cardholderLastName)
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(insPlanTypeCode)
                .insuranceCarrierId(insuranceCarrierId)
                .insurancePlanId(insurancePlanId)
                .lastChangeTs(LocalDateTime.now().toString())
                .lastChangeUserId("COMACCTCRE")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd(coverageInd)
                .build();
    }

    private void createPharmacyAccount(
            CPRUpdatePatientRequest cprUpdatePatientRequest, String customerAccountId) {
        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerAccountId));
        pharmacyAccountToBeDeleted.add(customerAccountId);
    }

    private CPRUpdatePatientRequest createCPRProfileWithInsurance(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String zipCode,
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList,
            CprPatientUpdateRetrofit cprPatientUpdateRetrofit)
            throws IOException {
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        return cprUpdatePatientRequest;
    }

    private CPRUpdatePatientRequest createCPRProfileWithInsuranceAndReplacement(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String zipCode,
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList,
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList,
            CprPatientUpdateRetrofit cprPatientUpdateRetrofit)
            throws IOException {
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        return cprUpdatePatientRequest;
    }

    private CPRUpdatePatientRequest.PatInsReplacementInfo buildCPRReplacementInfo(
            String replacedCardholderId,
            Integer replacedInsuranceCarrierId,
            Integer replacedInsurancePlanId,
            String cardholderId,
            Integer insuranceCarrierId,
            Integer insurancePlanId,
            String activeInd,
            String storeNbr,
            String patientId) {
        return CPRUpdatePatientRequest.PatInsReplacementInfo.builder()
                .replacedCardholderId(replacedCardholderId)
                .replacedInsuranceCarrierId(replacedInsuranceCarrierId)
                .replacedInsurancePlanId(replacedInsurancePlanId)
                .cardholderId(cardholderId)
                .insuranceCarrierId(insuranceCarrierId)
                .insurancePlanId(insurancePlanId)
                .lastChangeTs(LocalDateTime.now().toString())
                .createTs(LocalDateTime.now().toString())
                .lastChangeUserId("COMACCTCRE")
                .activeInd(activeInd)
                .storeNbr(Integer.parseInt(storeNbr))
                .patientId(Integer.parseInt(patientId))
                .build();
    }
}
