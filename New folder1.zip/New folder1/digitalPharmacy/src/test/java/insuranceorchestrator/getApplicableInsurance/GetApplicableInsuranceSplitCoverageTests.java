package insuranceorchestrator.getApplicableInsurance;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.GetApplicableInsurance.GetApplicableInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.ApplicablePaymentType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetApplicableInsurance.GetApplicableInsuranceV1Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class GetApplicableInsuranceSplitCoverageTests {
    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper;
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private CARetrofit caRetrofit;
    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private static final String COVERAGE = "COVERAGE";

    private static final String CARDHOLDER_ID = "248201700";
    private static final Integer CARRIER_ID = 121312;
    private static final Integer PLAN_ID = 120;
    private static final Integer CATEGORY = 1002;

    private static final String CARDHOLDER_ID_2 = "72939293";
    private static final Integer CARRIER_ID_2 = 116653;
    private static final Integer PLAN_ID_2 = 100;
    private static final Integer CATEGORY_2 = 1004;

    private static final String CARDHOLDER_ID_3 = "33653564542";
    private static final Integer CARRIER_ID_3 = 121312;
    private static final Integer PLAN_ID_3 = 121;

    @BeforeClass
    void setContext() throws IOException {
        accountDbContext = AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        caRetrofit = new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();
    }

    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterClass
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response =
                                cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted.forEach(this::deleteOCPRecord);
    }

    @Test(
            priority = 0,
            description =
                    "When split bill has 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED_TO_CASH")
    public void testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIED_TO_CASHInTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_CASH,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(
            priority = 1,
            description =
                    "When split bill has 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED_TO_DEFAULT")
    public void testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIED_TO_DEFAULTInTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        Assert.assertEquals(
                CARDHOLDER_ID_3,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderId());
        Assert.assertEquals(
                CARRIER_ID_3.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCarrierId());
        Assert.assertEquals(
                PLAN_ID_3.toString(),
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getPlanId());
        Assert.assertEquals(
                firstName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderFirstName());
        Assert.assertEquals(
                lastName,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCardholderLastName());
        Assert.assertEquals(
                "Spouse",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRelation());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getProcessorName());
        Assert.assertEquals(
                "1002",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getCategory());
        Assert.assertEquals(
                "011610",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxBin());
        Assert.assertEquals(
                "WALMART18",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxPCN());
        Assert.assertEquals(
                "1626281726",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .getFirst()
                        .getRxGroup());
    }

    @Test(
            priority = 2,
            description =
                    "When split bill has 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED")
    public void testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIEDInTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        4, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList =
                new ArrayList<>();
        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo =
                buildCPRReplacementInfo(
                        CARDHOLDER_ID_2,
                        CARRIER_ID_2,
                        PLAN_ID_2,
                        CARDHOLDER_ID_3,
                        CARRIER_ID_3,
                        PLAN_ID_3,
                        "Y",
                        storeNbr,
                        patientId);
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());

        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_3.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_3.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_3.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WALMART18")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
    }

    @Test(
            priority = 3,
            description =
                    "When split bill has 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_NOT_MODIFIED")
    public void testWhenPaymentTypeIsCOVERAGE_NOT_MODIFIEDInTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
    }

    @Test(
            priority = 4,
            description =
                    "When split bill has more than 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED_TO_CASH")
    public void
    testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIED_TO_CASHInMoreThanTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        4, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_3)
                                                                        .carrierId(CARRIER_ID_3.toString())
                                                                        .planId(PLAN_ID_3.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_3.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_3.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_3.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WALMART18")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_CASH,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
    }

    @Test(
            priority = 5,
            description =
                    "When split bill has more than 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED_TO_DEFAULT")
    public void
    testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIED_TO_DEFAULTInMoreThanTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "N");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        Assert.assertEquals(
                1,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .size());
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> CARRIER_ID_3.toString().equals(insurance.getCarrierId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> PLAN_ID_3.toString().equals(insurance.getPlanId())));
    }

    @Test(
            priority = 6,
            description =
                    "When split bill has more than 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_MODIFIED")
    public void testWhenOneOfTheApplicablePaymentTypeIsCOVERAGE_MODIFIEDInMoreThanTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        4, firstName, CARDHOLDER_ID_3, lastName, CATEGORY, CARRIER_ID_3, PLAN_ID_3, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList =
                new ArrayList<>();
        CPRUpdatePatientRequest.PatInsReplacementInfo patInsReplacementInfo =
                buildCPRReplacementInfo(
                        CARDHOLDER_ID_2,
                        CARRIER_ID_2,
                        PLAN_ID_2,
                        CARDHOLDER_ID_3,
                        CARRIER_ID_3,
                        PLAN_ID_3,
                        "Y",
                        storeNbr,
                        patientId);
        patInsReplacementInfoList.add(patInsReplacementInfo);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());

        Assert.assertEquals(
                2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .size());

        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_3.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_3.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_3.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WALMART18")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_3.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
    }

    @Test(
            priority = 7,
            description =
                    "When split bill has more than 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_NOT_MODIFIED")
    public void testWhenPaymentTypeIsCOVERAGE_NOT_MODIFIEDInMoreThanTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                insurances.stream().anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                insurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        Assert.assertEquals(
                2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .size());
        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> firstName.equals(insurance.getCardholderFirstName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> lastName.equals(insurance.getCardholderLastName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(insurance -> "Spouse".equals(insurance.getRelation())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.nonNull(insurance.getProcessorName())));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1002")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getCategory(), "1004")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "011610")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxBin(), "601574")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxPCN(), "WMARTECL2")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> insurance.getRxPCN() == null));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
        Assert.assertTrue(
                applicableInsurances.stream()
                        .filter(insurance -> CARDHOLDER_ID_2.equals(insurance.getCardholderId()))
                        .allMatch(insurance -> Objects.equals(insurance.getRxGroup(), "1626281726")));
    }

    @Test(
            priority = 8,
            description =
                    "When split bill has 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_NOT_MODIFIED_NO_DATA or default case when not present in CPR")
    public void
    testWhenPaymentTypeIsCOVERAGE_NOT_MODIFIEDOrDefaultCaseInMoreThanTwoInsuranceWhenNotPresentInCPR()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED_NO_DATA,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        Assert.assertEquals(
                2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .size());
        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
    }

    @Test(
            priority = 9,
            description =
                    "When split bill has more than 2 insurance and any of the insurance has Applicable Payment Type as COVERAGE_NOT_MODIFIED_NO_DATA")
    public void testWhenPaymentTypeIsCOVERAGE_NOT_MODIFIED_NO_DATAInMoreThanTwoInsurance()
            throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID)
                                                                        .carrierId(CARRIER_ID.toString())
                                                                        .planId(PLAN_ID.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                "1",
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getId());
        List<GetApplicableInsuranceV1Response.Insurance> insurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getInsurances();

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                insurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED_NO_DATA,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
        Assert.assertNotNull(
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances());
        Assert.assertEquals(
                2,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances()
                        .size());
        List<GetApplicableInsuranceV1Response.ApplicableInsurance> applicableInsurances =
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicableInsurances();

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARDHOLDER_ID.equals(insurance.getCardholderId())
                                                || CARDHOLDER_ID_2.equals(insurance.getCardholderId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        CARRIER_ID.toString().equals(insurance.getCarrierId())
                                                || CARRIER_ID_2.toString().equals(insurance.getCarrierId())));

        Assert.assertTrue(
                applicableInsurances.stream()
                        .anyMatch(
                                insurance ->
                                        PLAN_ID.toString().equals(insurance.getPlanId())
                                                || PLAN_ID_2.toString().equals(insurance.getPlanId())));
    }

    @Test(
            priority = 10,
            description = "When last applied insurance is duplicate in split bill and present in cpr and primary present in cpr")
    public void testWhenLastAppliedInsuranceIsDuplicateInSplitBillPresentInCPRAndPrimaryPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());

        String duplicateCardHolderId = "AB72939293CD";

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, duplicateCardHolderId, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        patientInsuranceInfo3.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(duplicateCardHolderId)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_DEFAULT,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 11,
            description = "When last applied insurance is duplicate in split bill present in cpr and primary not present in cpr")
    public void testWhenLastAppliedInsuranceIsDuplicateInSplitBillPresentInCPRAndPrimaryNotPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo1 =
                buildCPRInsuranceInfo(
                        2, firstName, CARDHOLDER_ID_2, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo1.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());

        String duplicateCardHolderId = "AB72939293CD";

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 =
                buildCPRInsuranceInfo(
                        3, firstName, duplicateCardHolderId, lastName, CATEGORY_2, CARRIER_ID_2, PLAN_ID_2, "Y");

        patientInsuranceInfo2.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo1);
        patientInsuranceInfoList.add(patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(duplicateCardHolderId)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_MODIFIED_TO_CASH,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 12,
            description = "When last applied insurance is duplicate in split bill and not present in cpr and primary present in cpr")
    public void testWhenLastAppliedInsuranceIsDuplicateInSplitBillNotPresentInCPRAndPrimaryPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);


        String duplicateCardHolderId = "AB72939293CD";

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 =
                buildCPRInsuranceInfo(
                        1, firstName, CARDHOLDER_ID, lastName, CATEGORY, CARRIER_ID, PLAN_ID, "Y");

        patientInsuranceInfo3.setLastChangeTs(LocalDateTime.now().minusMonths(2).toString());


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();
        patientInsuranceInfoList.add(patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(duplicateCardHolderId)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED_NO_DATA,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }

    @Test(
            priority = 13,
            description = "When last applied insurance is duplicate in split bill not present in cpr and primary not present in cpr")
    public void testWhenLastAppliedInsuranceIsDuplicateInSplitBillNotPresentInCPRAndPrimaryNotPresentInCPR() throws Exception {

        // Test data
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerAccountId= CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String storeNbr = CommonUtil.generateRandomNumber(5);
        String patientId = CommonUtil.generateRandomNumber(6);
        String zipCode = CommonUtil.generateRandomNumber(6);

        String duplicateCardHolderId = "AB72939293CD";


        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = new ArrayList<>();

        CPRUpdatePatientRequest cprUpdatePatientRequest =
                createCPRProfileWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        createPharmacyAccount(cprUpdatePatientRequest, customerAccountId);
        logAccountDetails(customerAccountId, reqId, reqTrackingId, trackID);

        // Building the Request payload
        GetApplicableInsuranceV1Request.PaymentInfo paymentInfoObj =
                GetApplicableInsuranceV1Request.PaymentInfo.builder()
                        .customerId(customerAccountId)
                        .paymentList(
                                org.openjdk.tools.javac.util.List.of(
                                        GetApplicableInsuranceV1Request.Payment.builder()
                                                .id("1")
                                                .paymentType(COVERAGE)
                                                .insurances(
                                                        org.openjdk.tools.javac.util.List.of(
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(duplicateCardHolderId)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build(),
                                                                GetApplicableInsuranceV1Request.Insurance.builder()
                                                                        .cardholderId(CARDHOLDER_ID_2)
                                                                        .carrierId(CARRIER_ID_2.toString())
                                                                        .planId(PLAN_ID_2.toString())
                                                                        .build()))
                                                .build()))
                        .build();
        String payload =
                buildGetApplicableInsuranceRequest(org.openjdk.tools.javac.util.List.of(paymentInfoObj));

        // Calling get applicable Insurance API
        ServiceResponse serviceResponse =
                insuranceWrapper.getApplicableInsurance(payload, customerAccountId);

        GetApplicableInsuranceV1Response getApplicableInsuranceV1Response =
                serviceResponse.getDataResponse(GetApplicableInsuranceV1Response.class);

        // Validate status code
        Assert.assertEquals(serviceResponse.getDataResponse(), 200, serviceResponse.getStatusCode());
        Assert.assertEquals(
                getApplicableInsuranceV1Response.getCustomerPaymentInfo().getFirst().getCustomerId(),
                customerAccountId);
        Assert.assertEquals(
                ApplicablePaymentType.COVERAGE_NOT_MODIFIED_NO_DATA,
                getApplicableInsuranceV1Response
                        .getCustomerPaymentInfo()
                        .getFirst()
                        .getPaymentInfo()
                        .getFirst()
                        .getApplicablePaymentType());
    }


    private String buildGetApplicableInsuranceRequest(
            List<GetApplicableInsuranceV1Request.PaymentInfo> customerPaymentInfo)
            throws JsonProcessingException {
        GetApplicableInsuranceV1Request request =
                GetApplicableInsuranceV1Request.builder().paymentInfo(customerPaymentInfo).build();
        return objectMapper.writeValueAsString(request);
    }

    private static String getInsertOCidQuery(
            String onlineCustId, String authStore, String authPatientId, String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void logAccountDetails(
            String customerAccountId, String reqId, String reqTrackingId, String trackID) {
        Reporter.logJSON("Customer Account Id", customerAccountId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Reporter.logJSON("tracking Id", trackID);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery =
                String.format(
                        "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }

    private CPRUpdatePatientRequest.PatientInsuranceInfo buildCPRInsuranceInfo(
            Integer billingSeqNbr,
            String cardholderFirstName,
            String cardholderId,
            String cardholderLastName,
            Integer insPlanTypeCode,
            Integer insuranceCarrierId,
            Integer insurancePlanId,
            String coverageInd) {
        return CPRUpdatePatientRequest.PatientInsuranceInfo.builder()
                .billingSeqNbr(billingSeqNbr)
                .billingGroupNbr("1626281726")
                .cardholderFirstName(cardholderFirstName)
                .cardholderId(cardholderId)
                .cardholderLastName(cardholderLastName)
                .insCarrierAbbr("AIA")
                .insPlanRefCode("comp")
                .insPlanTypeCode(insPlanTypeCode)
                .insuranceCarrierId(insuranceCarrierId)
                .insurancePlanId(insurancePlanId)
                .lastChangeTs(LocalDateTime.now().toString())
                .lastChangeUserId("COMACCTCRE")
                .relationshipCode(3202)
                .splitBillInd("N")
                .coverageInd(coverageInd)
                .build();
    }

    private CPRUpdatePatientRequest.PatInsReplacementInfo buildCPRReplacementInfo(
            String replacedCardholderId,
            Integer replacedInsuranceCarrierId,
            Integer replacedInsurancePlanId,
            String cardholderId,
            Integer insuranceCarrierId,
            Integer insurancePlanId,
            String activeInd,
            String storeNbr,
            String patientId) {
        return CPRUpdatePatientRequest.PatInsReplacementInfo.builder()
                .replacedCardholderId(replacedCardholderId)
                .replacedInsuranceCarrierId(replacedInsuranceCarrierId)
                .replacedInsurancePlanId(replacedInsurancePlanId)
                .cardholderId(cardholderId)
                .insuranceCarrierId(insuranceCarrierId)
                .insurancePlanId(insurancePlanId)
                .lastChangeTs(LocalDateTime.now().toString())
                .createTs(LocalDateTime.now().toString())
                .lastChangeUserId("COMACCTCRE")
                .activeInd(activeInd)
                .storeNbr(Integer.parseInt(storeNbr))
                .patientId(Integer.parseInt(patientId))
                .build();
    }

    private void createPharmacyAccount(
            CPRUpdatePatientRequest cprUpdatePatientRequest, String customerAccountId) {
        accountDbContext.executeInsertQuery(
                getInsertOCidQuery(
                        CommonUtil.generateRandomNumber(9),
                        String.valueOf(cprUpdatePatientRequest.getStoreNbr()),
                        String.valueOf(cprUpdatePatientRequest.getPatientId()),
                        customerAccountId));
        pharmacyAccountToBeDeleted.add(customerAccountId);
    }

    private CPRUpdatePatientRequest createCPRProfileWithInsurance(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String zipCode,
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList,
            CprPatientUpdateRetrofit cprPatientUpdateRetrofit)
            throws IOException {
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsurance(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        return cprUpdatePatientRequest;
    }

    private CPRUpdatePatientRequest createCPRProfileWithInsuranceAndReplacement(
            String storeNbr,
            String patientId,
            String firstName,
            String lastName,
            String zipCode,
            List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList,
            List<CPRUpdatePatientRequest.PatInsReplacementInfo> patInsReplacementInfoList,
            CprPatientUpdateRetrofit cprPatientUpdateRetrofit)
            throws IOException {
        CPRUpdatePatientRequest cprUpdatePatientRequest =
                SharedUtils.createCPRAccountWithInsuranceAndReplacement(
                        storeNbr,
                        patientId,
                        firstName,
                        lastName,
                        "M",
                        "1996-01-01",
                        CommonUtil.generateRandomNumber(10),
                        zipCode,
                        patientInsuranceInfoList,
                        patInsReplacementInfoList,
                        cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);
        return cprUpdatePatientRequest;
    }
}
