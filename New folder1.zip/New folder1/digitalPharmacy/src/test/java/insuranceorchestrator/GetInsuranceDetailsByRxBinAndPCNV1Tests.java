package insuranceorchestrator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.fetchInsurance.FetchInsuranceByBinAndPcnResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.fetchAndValidateIToken.InsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;

public class GetInsuranceDetailsByRxBinAndPCNV1Tests {
    private InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    private ObjectMapper objectMapper;

    // Valid BIN/PCN combination (Commercial category 1006 - allowed)
    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private static final String GROUP_ID = "YJSS0";
    private static final String PROCESSOR_NAME = null;

    // Discount Card BIN/PCN (category 1005 - blocked)
    private static final String DISCOUNT_BIN_NUMBER = "808412";
    private static final String DISCOUNT_PCN = "45370";
    private static final String DISCOUNT_GROUP_ID = null;

    // Coupon/Trial Card BIN/PCN (category 1007 - blocked)
    // Note: If no known Coupon Card BIN/PCN exists in RDM, this test will be skipped
    // To find one, query RDM for categoryCode=1007 plans
    private static final String COUPON_BIN_NUMBER = "610097";
    private static final String COUPON_PCN = "00000000";

    private String customerId;

    @BeforeClass
    public void setContext() {
        objectMapper = new ObjectMapper();
        customerId = CommonUtil.generateRandomFirstName(36);
    }

    // ========================
    // HAPPY PATH TESTS
    // ========================

    @Test(description = "Verify valid BIN/PCN lookup returns 200 with insurance info containing validationToken, masked cardHolderId, processorName and isWalmartEligible")
    public void getInsuranceDetailsByRxBinAndPCNV1ValidTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 200 for valid BIN/PCN lookup", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        Assert.assertNotNull("Response body should not be null", response);
        Assert.assertNotNull("InsuranceInfo should not be null", response.getInsuranceInfo());
        Assert.assertNotNull("ValidationToken should not be null", response.getInsuranceInfo().getValidationToken());
        Assert.assertNotNull("CardHolderId should not be null", response.getInsuranceInfo().getCardHolderId());
        Assert.assertNotNull("ProcessorName should not be null", response.getInsuranceInfo().getProcessorName());
        Assert.assertTrue("IsWalmartEligible should be true", response.getInsuranceInfo().getIsWalmartEligible());
    }

    @Test(description = "Verify cardHolderId is masked in response - only last N characters visible in plain text")
    public void getInsuranceDetailsByRxBinAndPCNV1CardHolderIdMaskedTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String maskedCardHolderId = response.getInsuranceInfo().getCardHolderId();
        Assert.assertNotNull("Masked cardHolderId should not be null", maskedCardHolderId);
        Assert.assertTrue("CardHolderId should be masked with asterisks", maskedCardHolderId.contains("*"));
        Assert.assertNotEquals("Masked cardHolderId should differ from original", CARDHOLDER_ID, maskedCardHolderId);
    }

    @Test(description = "Verify valid BIN/PCN lookup with only required fields - rxPCN and rxGroup as null")
    public void getInsuranceDetailsByRxBinAndPCNV1WithOnlyRequiredFieldsTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, null, BIN_NUMBER, null, null);

        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // rxPCN is optional, so this should still succeed if BIN alone matches in RDM
        // If RDM returns 204 for BIN-only lookup, 400 is also acceptable
        Assert.assertTrue("Expected HTTP 200 or 400",
                serviceResponse.getStatusCode() == 200 || serviceResponse.getStatusCode() == 400);
    }

    // ========================
    // VALIDATION TOKEN FLOW TESTS
    // ========================

    @Test(description = "Verify validationToken from BIN/PCN lookup can be successfully decrypted via validate-and-fetch endpoint")
    public void getInsuranceDetailsByRxBinAndPCNV1ValidateTokenTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Expected HTTP 200 for valid lookup", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String validationToken = response.getInsuranceInfo().getValidationToken();
        Assert.assertNotNull("ValidationToken should not be null", validationToken);

        // Validate and decrypt the token
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals("Expected HTTP 200 for valid token decryption", 200, decryptTokenServiceResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(decryptTokenServiceResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull("Decrypted InsuranceInfo should not be null", insuranceInfo);
        Assert.assertEquals("CustomerId should match", customerId, insuranceInfo.getCustomerId());
        Assert.assertEquals("CardHolderId should match original (unmasked)", CARDHOLDER_ID, insuranceInfo.getCardHolderId());
        Assert.assertEquals("RxBin should match", BIN_NUMBER, insuranceInfo.getRxBin());
        Assert.assertEquals("RxPCN should match", PCN, insuranceInfo.getRxPCN());
        Assert.assertEquals("RxGroup should match", GROUP_ID, insuranceInfo.getRxGroup());
        Assert.assertTrue("IsWalmartEligible should be true", insuranceInfo.getIsWalmartEligible());
        Assert.assertNotNull("CarrierId should not be null (from RDM)", insuranceInfo.getCarrierId());
        Assert.assertNotNull("PlanId should not be null (from RDM)", insuranceInfo.getPlanId());
    }

    @Test(description = "Verify token validation fails with customer ID mismatch - expects 400")
    public void getInsuranceDetailsByRxBinAndPCNV1CustomerIdMismatchTokenTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Expected HTTP 200 for valid lookup", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String validationToken = response.getInsuranceInfo().getValidationToken();

        // Use a different customerId for token validation
        String randomCustomerId = CommonUtil.generateRandomFirstName(36);
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(randomCustomerId, validationToken);
        Assert.assertEquals("Expected HTTP 400 for customerId mismatch", 400, decryptTokenServiceResponse.getStatusCode());
    }

    @Test(description = "Verify token validation fails with tampered/invalid token - expects 500")
    public void getInsuranceDetailsByRxBinAndPCNV1InvalidTokenTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Expected HTTP 200 for valid lookup", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String validationToken = response.getInsuranceInfo().getValidationToken();

        // Tamper the token by appending a character
        validationToken += 'd';
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals("Expected HTTP 500 for tampered token", 500, decryptTokenServiceResponse.getStatusCode());
    }

    @Test(description = "Verify token validation fails with empty token - expects 400")
    public void getInsuranceDetailsByRxBinAndPCNV1EmptyTokenTest() {
        ServiceResponse decryptTokenServiceResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, "");
        Assert.assertEquals("Expected HTTP 400 for empty token", 400, decryptTokenServiceResponse.getStatusCode());
    }

    // ========================
    // RDM CROSS-VALIDATION TESTS
    // ========================

    @Test(description = "Verify response fields match RDM data - processorName from BIN/PCN lookup should match RDM reference data")
    public void getInsuranceDetailsByRxBinAndPCNV1CrossValidateWithRDMTest() throws IOException {
        // Get insurance details via the API
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);

        // Cross-validate with RDM directly
        ServiceResponse rdmResponse = insuranceWrapper.getRDM(BIN_NUMBER, PCN);
        Assert.assertEquals("RDM should return 200", 200, rdmResponse.getStatusCode());

        JsonNode rdmRoot = objectMapper.readTree(rdmResponse.getDataResponse());
        String rdmProcessorName = rdmRoot.get("processorName").asText();
        Assert.assertEquals("ProcessorName should match RDM data", rdmProcessorName, response.getInsuranceInfo().getProcessorName());
    }

    @Test(description = "Verify decrypted token carrierId and planId match RDM data")
    public void getInsuranceDetailsByRxBinAndPCNV1TokenFieldsMatchRDMTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String validationToken = response.getInsuranceInfo().getValidationToken();

        // Decrypt token
        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals("Expected HTTP 200", 200, decryptResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(decryptResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);

        // Cross-validate with RDM
        ServiceResponse rdmResponse = insuranceWrapper.getRDM(BIN_NUMBER, PCN);
        JsonNode rdmRoot = objectMapper.readTree(rdmResponse.getDataResponse());

        String rdmCarrierId = rdmRoot.get("insuranceCarrierCompanyId").asText();
        String rdmPlanId = rdmRoot.get("insuranceCarrierPlanId").asText();
        Assert.assertEquals("CarrierId should match RDM", rdmCarrierId, insuranceInfo.getCarrierId());
        Assert.assertEquals("PlanId should match RDM", rdmPlanId, insuranceInfo.getPlanId());
    }

    // ========================
    // INPUT VALIDATION TESTS (400 errors)
    // ========================

    @Test(description = "Verify 500 returned when customerId is Empty")
    public void getInsuranceDetailsByRxBinAndPCNV1EmptyCustomerIdTest() {
        //"message":"Service resulted in error","errorMessage":"Exception class: class org.springframework.web.servlet.resource.NoResourceFoundException, Exception message: No static resource v1/customer/insurance/action/lookup."},"level":"ERROR","thread":"","logger":"dp-insurance-orchestrator","@timestamp":"2026-03-22T16:34:05.884Z"}
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                "", CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 500 for empty customerId", 500, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when cardHolderId is null/empty")
    public void getInsuranceDetailsByRxBinAndPCNV1NullCardHolderIdTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, null, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for null cardHolderId", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when cardHolderId is empty string")
    public void getInsuranceDetailsByRxBinAndPCNV1EmptyCardHolderIdTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, "", GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for empty cardHolderId", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when rxBin is null/empty")
    public void getInsuranceDetailsByRxBinAndPCNV1NullRxBinTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, null, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for null rxBin", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when rxBin is empty string")
    public void getInsuranceDetailsByRxBinAndPCNV1EmptyRxBinTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, "", PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for empty rxBin", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when cardHolderId is whitespace only")
    public void getInsuranceDetailsByRxBinAndPCNV1WhitespaceCardHolderIdTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, "   ", GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for whitespace-only cardHolderId", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when rxBin is whitespace only")
    public void getInsuranceDetailsByRxBinAndPCNV1WhitespaceRxBinTest() {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, "   ", PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for whitespace-only rxBin", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // INVALID BIN/PCN TESTS (RDM returns 204)
    // ========================

    @Test(description = "Verify 400 returned for non-existent BIN number - RDM returns 204 No Content")
    public void getInsuranceDetailsByRxBinAndPCNV1InvalidBinTest() {
        String invalidBin = "999999";
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, invalidBin, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for invalid BIN (RDM 204)", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned for non-existent PCN with valid BIN - RDM returns 204 No Content")
    public void getInsuranceDetailsByRxBinAndPCNV1InvalidPcnTest() {
        String invalidPcn = "ZZZZZ999";
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, invalidPcn, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for invalid PCN (RDM 204)", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned for both invalid BIN and PCN")
    public void getInsuranceDetailsByRxBinAndPCNV1InvalidBinAndPcnTest() {
        String invalidBin = "000000";
        String invalidPcn = "INVALID00";
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, invalidBin, invalidPcn, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for invalid BIN and PCN", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // CATEGORY BLOCKING TESTS (Discount Card / Coupon)
    // ========================

    @Test(description = "Verify 400 returned when BIN/PCN maps to Discount Card category (1005) - category not allowed")
    public void getInsuranceDetailsByRxBinAndPCNV1DiscountCardBlockedTest() {
        String dynamicCardHolderId = CommonUtil.generateRandomNumber(11);
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, dynamicCardHolderId, DISCOUNT_GROUP_ID, DISCOUNT_BIN_NUMBER, DISCOUNT_PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for Discount Card category (blocked)", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "Verify 400 returned when BIN/PCN maps to Coupon/Trial Card category (1007) - category not allowed")
    public void getInsuranceDetailsByRxBinAndPCNV1CouponCardBlockedTest() {
        // Category 1007 (Coupon/Trial Card) is in the CCM blocked list [1005, 1007]
        // Note: If COUPON_BIN_NUMBER/COUPON_PCN don't map to category 1007 in RDM,
        // update these constants with a valid Coupon Card BIN/PCN from RDM
        String dynamicCardHolderId = CommonUtil.generateRandomNumber(9);
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, dynamicCardHolderId, null, COUPON_BIN_NUMBER, COUPON_PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 400 for Coupon/Trial Card category (blocked)", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // EDGE CASE TESTS
    // ========================

    @Test(description = "Verify lookup with very long cardHolderId is handled gracefully")
    public void getInsuranceDetailsByRxBinAndPCNV1LongCardHolderIdTest() {
        String longCardHolderId = CommonUtil.generateRandomFirstName(100);
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, longCardHolderId, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // Should succeed with 200 (cardHolderId is passed through) or fail gracefully
        Assert.assertTrue("Expected HTTP 200 or 400",
                serviceResponse.getStatusCode() == 200 || serviceResponse.getStatusCode() == 400);
    }

    @Test(description = "Verify lookup with special characters in cardHolderId")
    public void getInsuranceDetailsByRxBinAndPCNV1SpecialCharCardHolderIdTest() {
        String specialCharCardHolderId = "ARP-DB245!@#";
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, specialCharCardHolderId, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // Should return 200 as cardHolderId is not validated for format
        Assert.assertTrue("Expected valid response",
                serviceResponse.getStatusCode() == 200 || serviceResponse.getStatusCode() == 400);
    }

    @Test(description = "Verify multiple sequential lookups with same BIN/PCN return consistent results")
    public void getInsuranceDetailsByRxBinAndPCNV1ConsistentResponseTest() {
        ServiceResponse firstResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        ServiceResponse secondResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Both calls should return same status", firstResponse.getStatusCode(), secondResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse first = firstResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        FetchInsuranceByBinAndPcnResponse second = secondResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);

        Assert.assertEquals("ProcessorName should be consistent",
                first.getInsuranceInfo().getProcessorName(), second.getInsuranceInfo().getProcessorName());
        Assert.assertEquals("IsWalmartEligible should be consistent",
                first.getInsuranceInfo().getIsWalmartEligible(), second.getInsuranceInfo().getIsWalmartEligible());
        Assert.assertEquals("Masked cardHolderId should be consistent",
                first.getInsuranceInfo().getCardHolderId(), second.getInsuranceInfo().getCardHolderId());
    }

    @Test(description = "Verify valid lookup with dynamically generated cardHolderId returns 200")
    public void getInsuranceDetailsByRxBinAndPCNV1DynamicCardHolderIdTest() {
        // CardHolderId is passed through without DB validation, so any non-blank value works
        String dynamicCardHolderId = CommonUtil.generateRandomNumber(9);
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, dynamicCardHolderId, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        Assert.assertEquals("Expected HTTP 200 with dynamic cardHolderId", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        Assert.assertNotNull("InsuranceInfo should not be null", response.getInsuranceInfo());
        Assert.assertNotNull("ValidationToken should not be null", response.getInsuranceInfo().getValidationToken());
        // Verify masked cardHolderId preserves last 6 chars of dynamic input
        String masked = response.getInsuranceInfo().getCardHolderId();
        Assert.assertTrue("Masked cardHolderId should end with last 6 chars of input",
                masked.endsWith(dynamicCardHolderId.substring(dynamicCardHolderId.length() - 6)));
    }

    @Test(description = "Verify decrypted token contains complete RDM fields: category, carrierAbbr, planRefCode")
    public void getInsuranceDetailsByRxBinAndPCNV1TokenContainsAllRDMFieldsTest() throws IOException {
        ServiceResponse serviceResponse = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        FetchInsuranceByBinAndPcnResponse response = serviceResponse.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        String validationToken = response.getInsuranceInfo().getValidationToken();

        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(customerId, validationToken);
        Assert.assertEquals("Expected HTTP 200", 200, decryptResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(decryptResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);

        // Verify all fields set by buildInsuranceInfo() from RDM response
        Assert.assertNotNull("Category should not be null (from RDM categoryCode)", insuranceInfo.getCategory());
        Assert.assertNotNull("ProcessorName should not be null (from RDM)", insuranceInfo.getProcessorName());
        Assert.assertTrue("IsWalmartEligible should be true (hardcoded)", insuranceInfo.getIsWalmartEligible());
        // isDependent, cardHolderFirstName, cardHolderLastName, relation, personCode should be null in this flow
        Assert.assertNull("IsDependent should be null (not set in BIN/PCN flow)", insuranceInfo.getIsDependent());
        Assert.assertNull("PersonCode should be null (not set in BIN/PCN flow)", insuranceInfo.getPersonCode());
    }

    @Test(description = "Verify different customerIds with same BIN/PCN generate different validation tokens")
    public void getInsuranceDetailsByRxBinAndPCNV1DifferentCustomerIdDifferentTokenTest() {
        String customerId1 = CommonUtil.generateRandomFirstName(36);
        String customerId2 = CommonUtil.generateRandomFirstName(36);

        ServiceResponse response1 = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId1, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);
        ServiceResponse response2 = insuranceWrapper.fetchInsuranceTokenByBinAndPcn(
                customerId2, CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN, PROCESSOR_NAME);

        Assert.assertEquals("Both should return 200", 200, response1.getStatusCode());
        Assert.assertEquals("Both should return 200", 200, response2.getStatusCode());

        FetchInsuranceByBinAndPcnResponse resp1 = response1.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);
        FetchInsuranceByBinAndPcnResponse resp2 = response2.getDataResponse(FetchInsuranceByBinAndPcnResponse.class);

        Assert.assertNotEquals("Tokens should differ for different customerIds",
                resp1.getInsuranceInfo().getValidationToken(), resp2.getInsuranceInfo().getValidationToken());
    }
}
