package insuranceorchestrator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.BomTestDataSetupRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.GetInsuranceByPatientInfoV2Response;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.fetchAndValidateIToken.InsuranceInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

public class GetInsuranceByPatientInfoTest {
    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();

    @Test(description = "Get insurance by patient info v2 with encryption disabled", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "GetInsuranceByPatientInfoV2")
    public void getInsuranceByPatientInfoV2ValidTestWithEncryptionDisabled(String customerId, String requestPayload, int expectedStatusCode, String bomTestData) {
        Reporter.logJSON("Customer Account Id", customerId);
        insuranceWrapper.setupBomTestData(bomTestData);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(customerId, requestPayload);
        Assert.assertNotNull(serviceResponse);
        Assert.assertEquals(expectedStatusCode, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull(response.getInsuranceInfo());
        Assert.assertFalse("There should be at least one insurance", response.getInsuranceInfo().isEmpty());
        for(GetInsuranceByPatientInfoV2Response.InsuranceInfo insuranceInfo: response.getInsuranceInfo()) {
            Assert.assertNull(insuranceInfo.getValidationToken());
            Assert.assertNotNull(insuranceInfo.getCardHolderId());
        }
    }

    @Test(description = "Get insurance by patient info v2 with encryption enabled", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "GetInsuranceByPatientInfoV2")
    public void getInsuranceByPatientInfoV2ValidTestWithEncryptionEnabled(String customerId, String requestPayload, int expectedStatusCode, String bomTestData) {
        Reporter.logJSON("Customer Account Id", customerId);
        insuranceWrapper.setupBomTestData(bomTestData);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(customerId, requestPayload);
        Assert.assertNotNull(serviceResponse);
        Assert.assertEquals(expectedStatusCode, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull(response.getInsuranceInfo());
        Assert.assertFalse("There should be at least one insurance", response.getInsuranceInfo().isEmpty());
        for(GetInsuranceByPatientInfoV2Response.InsuranceInfo insuranceInfo: response.getInsuranceInfo()) {
            Assert.assertNotNull(insuranceInfo.getValidationToken());
            Assert.assertNotNull(insuranceInfo.getCardHolderId());
            Assert.assertNull(insuranceInfo.getRxBin());
            Assert.assertNull(insuranceInfo.getRxPCN());
            Assert.assertNull(insuranceInfo.getRxGroup());
            Assert.assertNull(insuranceInfo.getPlanId());
            Assert.assertNull(insuranceInfo.getCarrierId());
        }
    }

    @Test(description = "Get insurance by patient info v2 with non existent patient", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "GetInsuranceByPatientInfoV2")
    public void getInsuranceByPatientInfoV2InvalidTestWithNonExistPatient(String customerId, String requestPayload, int expectedStatusCode, String bomTestData) {
        Reporter.logJSON("Customer Account Id", customerId);
        insuranceWrapper.setupBomTestData(bomTestData);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(customerId, requestPayload);
        Assert.assertNotNull(serviceResponse);
        Assert.assertEquals(expectedStatusCode, serviceResponse.getStatusCode());
    }

    // ========================================================================
    // NEW TESTS - Programmatic BOM setup with dynamic data
    // ========================================================================

    private static final String BIN_NUMBER = "610502";
    private static final String PCN = "00670000";
    private static final String CARDHOLDER_ID = "248201700";
    private static final String GROUP_ID = "YJSS0";
    private static final String STORE_ID = "9989";

    private String dynamicFirstName = CommonUtil.generateRandomFirstName(8);
    private String dynamicLastName = CommonUtil.generateRandomFirstName(8);
    private String dynamicCustomerId = CommonUtil.generateRandomFirstName(36);
    private ObjectMapper objectMapper = new ObjectMapper();
    private boolean bomSetupDone = false;

    private void ensureBomSetup() throws IOException {
        if (!bomSetupDone) {
            BomTestDataSetupRequest bomRequest = buildBomTestDataSetupRequest(
                    dynamicFirstName, dynamicLastName, "19960101", "M",
                    "178 Paradise Crescent", "Royal Palm Beach", "33411", "FL",
                    STORE_ID, "US", CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN);
            String bomJson = objectMapper.writeValueAsString(bomRequest);
            insuranceWrapper.setupBomTestData(bomJson);
            bomSetupDone = true;
        }
    }

    private String buildV2RequestPayload(Boolean dataEncryption) throws IOException {
        String json = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            if (dataEncryption != null) {
                put("dataEncryption", dataEncryption);
            }
        }});
        return json;
    }

    // ========================
    // ENCRYPTED MODE TESTS (dataEncryption=true)
    // ========================

    @Test(description = "V2 encrypted mode: verify validationToken can be decrypted via validate-and-fetch and all InsuranceInfo fields match")
    public void getInsuranceByPatientInfoV2EncryptedModeTokenValidationTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(true);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertFalse("Should have at least one insurance", response.getInsuranceInfo().isEmpty());

        String validationToken = response.getInsuranceInfo().get(0).getValidationToken();
        Assert.assertNotNull("ValidationToken should not be null in encrypted mode", validationToken);

        // Decrypt token via validate-and-fetch endpoint
        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validationToken);
        Assert.assertEquals("Expected HTTP 200 for token decryption", 200, decryptResponse.getStatusCode());

        JsonNode root = objectMapper.readTree(decryptResponse.getDataResponse());
        InsuranceInfo insuranceInfo = objectMapper.treeToValue(root.get("insuranceInfo"), InsuranceInfo.class);
        Assert.assertNotNull("Decrypted InsuranceInfo should not be null", insuranceInfo);
        Assert.assertEquals("CustomerId should match", dynamicCustomerId, insuranceInfo.getCustomerId());
        Assert.assertEquals("CardHolderId should match (unmasked in token)", CARDHOLDER_ID, insuranceInfo.getCardHolderId());
        Assert.assertEquals("RxBin should match", BIN_NUMBER, insuranceInfo.getRxBin());
        Assert.assertEquals("RxPCN should match", PCN, insuranceInfo.getRxPCN());
        Assert.assertEquals("RxGroup should match", GROUP_ID, insuranceInfo.getRxGroup());
        Assert.assertTrue("IsWalmartEligible should be true", insuranceInfo.getIsWalmartEligible());
    }

    @Test(description = "V2 encrypted mode: verify cardHolderId is masked with asterisks in response")
    public void getInsuranceByPatientInfoV2EncryptedModeCardHolderIdMaskedTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(true);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        String maskedCardHolderId = response.getInsuranceInfo().get(0).getCardHolderId();
        Assert.assertNotNull("CardHolderId should not be null", maskedCardHolderId);
        Assert.assertTrue("CardHolderId should be masked with asterisks in encrypted mode", maskedCardHolderId.contains("*"));
        Assert.assertNotEquals("Masked cardHolderId should differ from original", CARDHOLDER_ID, maskedCardHolderId);
    }

    // ========================
    // PLAINTEXT MODE TESTS (dataEncryption=false)
    // ========================

    @Test(description = "V2 plaintext mode: verify all insurance fields populated - rxBin, rxPCN, rxGroup, carrierId, planId, processorName, isWalmartEligible")
    public void getInsuranceByPatientInfoV2PlaintextModeAllFieldsTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(false);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertFalse("Should have at least one insurance", response.getInsuranceInfo().isEmpty());

        GetInsuranceByPatientInfoV2Response.InsuranceInfo info = response.getInsuranceInfo().get(0);
        Assert.assertNull("ValidationToken should be null in plaintext mode", info.getValidationToken());
        Assert.assertNotNull("CardHolderId should not be null", info.getCardHolderId());
        Assert.assertNotNull("ProcessorName should not be null", info.getProcessorName());
        Assert.assertNotNull("IsWalmartEligible should not be null", info.getIsWalmartEligible());
        Assert.assertNotNull("RxBin should not be null in plaintext mode", info.getRxBin());
        Assert.assertNotNull("RxPCN should not be null in plaintext mode", info.getRxPCN());
        Assert.assertNotNull("CarrierId should not be null in plaintext mode", info.getCarrierId());
        Assert.assertNotNull("PlanId should not be null in plaintext mode", info.getPlanId());
    }

    @Test(description = "V2 plaintext mode: verify cardHolderId is NOT masked - full unmasked value returned")
    public void getInsuranceByPatientInfoV2PlaintextModeCardHolderIdUnmaskedTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(false);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        String cardHolderId = response.getInsuranceInfo().get(0).getCardHolderId();
        Assert.assertNotNull("CardHolderId should not be null", cardHolderId);
        Assert.assertFalse("CardHolderId should NOT be masked in plaintext mode", cardHolderId.contains("*"));
    }

    @Test(description = "V2 plaintext mode: cross-validate response fields with RDM - processorName, carrierId, planId")
    public void getInsuranceByPatientInfoV2PlaintextModeCrossValidateRDMTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(false);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        GetInsuranceByPatientInfoV2Response.InsuranceInfo info = response.getInsuranceInfo().get(0);

        // Cross-validate with RDM directly
        ServiceResponse rdmResponse = insuranceWrapper.getRDM(BIN_NUMBER, PCN);
        Assert.assertEquals("RDM should return 200", 200, rdmResponse.getStatusCode());

        JsonNode rdmRoot = objectMapper.readTree(rdmResponse.getDataResponse());
        Assert.assertEquals("ProcessorName should match RDM",
                rdmRoot.get("processorName").asText(), info.getProcessorName());
        Assert.assertEquals("CarrierId should match RDM",
                String.valueOf(rdmRoot.get("insuranceCarrierCompanyId").asInt()), info.getCarrierId());
        Assert.assertEquals("PlanId should match RDM",
                String.valueOf(rdmRoot.get("insuranceCarrierPlanId").asInt()), info.getPlanId());
    }

    // ========================
    // DEFAULT ENCRYPTION MODE (dataEncryption=null)
    // ========================

    @Test(description = "V2 with dataEncryption=null: should behave same as encrypted mode (default)")
    public void getInsuranceByPatientInfoV2NullEncryptionDefaultsToEncryptedTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(null);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertFalse("Should have at least one insurance", response.getInsuranceInfo().isEmpty());

        GetInsuranceByPatientInfoV2Response.InsuranceInfo info = response.getInsuranceInfo().get(0);
        Assert.assertNotNull("ValidationToken should not be null (default = encrypted)", info.getValidationToken());
        Assert.assertNotNull("CardHolderId should not be null", info.getCardHolderId());
        Assert.assertTrue("CardHolderId should be masked (default = encrypted)", info.getCardHolderId().contains("*"));
        Assert.assertNull("RxBin should be null in encrypted mode", info.getRxBin());
        Assert.assertNull("CarrierId should be null in encrypted mode", info.getCarrierId());
        Assert.assertNull("PlanId should be null in encrypted mode", info.getPlanId());
    }

    // ========================
    // TOKEN VALIDATION FLOW TESTS
    // ========================

    @Test(description = "V2 encrypted mode: token validation fails with customerId mismatch - expects 400")
    public void getInsuranceByPatientInfoV2CustomerIdMismatchTokenTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(true);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        String validationToken = response.getInsuranceInfo().get(0).getValidationToken();

        String wrongCustomerId = CommonUtil.generateRandomFirstName(36);
        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(wrongCustomerId, validationToken);
        Assert.assertEquals("Expected HTTP 400 for customerId mismatch", 400, decryptResponse.getStatusCode());
    }

    @Test(description = "V2 encrypted mode: token validation fails with tampered token - expects 500")
    public void getInsuranceByPatientInfoV2TamperedTokenTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(true);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        String validationToken = response.getInsuranceInfo().get(0).getValidationToken();

        validationToken += 'd';
        ServiceResponse decryptResponse = insuranceWrapper.validateAndFetchInsuranceToken(dynamicCustomerId, validationToken);
        Assert.assertEquals("Expected HTTP 500 for tampered token", 500, decryptResponse.getStatusCode());
    }

    // ========================
    // INPUT VALIDATION TESTS (400 errors)
    // ========================

    @Test(description = "V2: Verify 400 when firstName is missing")
    public void getInsuranceByPatientInfoV2MissingFirstNameTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing firstName", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when lastName is missing")
    public void getInsuranceByPatientInfoV2MissingLastNameTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing lastName", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when birthdate is missing")
    public void getInsuranceByPatientInfoV2MissingBirthdateTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing birthdate", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when gender is missing")
    public void getInsuranceByPatientInfoV2MissingGenderTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing gender", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when address is missing")
    public void getInsuranceByPatientInfoV2MissingAddressTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing address", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when zipCode is missing from address")
    public void getInsuranceByPatientInfoV2MissingZipCodeTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing zipCode", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 500 when customerId is empty - Spring routing error")
    public void getInsuranceByPatientInfoV2EmptyCustomerIdTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(false);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2("", payload);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // Empty customerId causes Spring NoResourceFoundException (URL becomes /v2/customer/insurance/action/...)
        Assert.assertEquals("Expected HTTP 500 for empty customerId", 500, serviceResponse.getStatusCode());
    }

    // ========================
    // ADDITIONAL INPUT VALIDATION TESTS (400 errors)
    // ========================

    @Test(description = "V2: Verify 400 when customerInfo is null - entire customerInfo block missing")
    public void getInsuranceByPatientInfoV2MissingCustomerInfoTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing customerInfo", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when addressLineOne is missing from address")
    public void getInsuranceByPatientInfoV2MissingAddressLineOneTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing addressLineOne", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when city is missing from address")
    public void getInsuranceByPatientInfoV2MissingCityTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing city", 400, serviceResponse.getStatusCode());
    }

    @Test(description = "V2: Verify 400 when stateOrProvinceCode is missing from address")
    public void getInsuranceByPatientInfoV2MissingStateTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("zipCode", "33411");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 400 for missing stateOrProvinceCode", 400, serviceResponse.getStatusCode());
    }

    // ========================
    // STORE NUMBER TESTS
    // ========================

    @Test(description = "V2: Verify lookup succeeds with storeNumber=null - uses default store (100)")
    public void getInsuranceByPatientInfoV2NullStoreNumberTest() throws IOException {
        ensureBomSetup();
        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", dynamicFirstName);
                put("lastName", dynamicLastName);
                put("birthdate", 19960101);
                put("gender", "M");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "178 Paradise Crescent");
                    put("city", "Royal Palm Beach");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33411");
                }});
            }});
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertNotNull("Service response should not be null", serviceResponse);
        // storeNumber is optional, service uses default store 100 from CCM
        Assert.assertTrue("Expected HTTP 200 or 204",
                serviceResponse.getStatusCode() == 200 || serviceResponse.getStatusCode() == 204);
    }

    // ========================
    // MULTIPLE PAYER TEST
    // ========================

    @Test(description = "V2 plaintext mode: verify multiple payers returned when BOM setup has numberOfPayer > 1")
    public void getInsuranceByPatientInfoV2MultiplePayers() throws IOException {
        String multiPayerFirstName = CommonUtil.generateRandomFirstName(8);
        String multiPayerLastName = CommonUtil.generateRandomFirstName(8);
        String multiPayerCustomerId = CommonUtil.generateRandomFirstName(36);

        BomTestDataSetupRequest bomRequest = buildBomTestDataSetupRequest(
                multiPayerFirstName, multiPayerLastName, "19880515", "F",
                "456 Oak Avenue", "Tampa", "33602", "FL",
                STORE_ID, "US", CARDHOLDER_ID, GROUP_ID, BIN_NUMBER, PCN);

        // Override numberOfPayer to 2 for multi-payer test
        BomTestDataSetupRequest multiPayerRequest = BomTestDataSetupRequest.builder()
                .request(bomRequest.getRequest())
                .numberOfPayer(2)
                .cardholderId(Arrays.asList(CARDHOLDER_ID, "348201800"))
                .groupId(Arrays.asList(GROUP_ID, GROUP_ID))
                .iin(Arrays.asList(BIN_NUMBER, BIN_NUMBER))
                .pcn(Arrays.asList(PCN, PCN))
                .build();

        String bomJson = objectMapper.writeValueAsString(multiPayerRequest);
        insuranceWrapper.setupBomTestData(bomJson);

        String payload = objectMapper.writeValueAsString(new java.util.LinkedHashMap<String, Object>() {{
            put("customerInfo", new java.util.LinkedHashMap<String, Object>() {{
                put("firstName", multiPayerFirstName);
                put("lastName", multiPayerLastName);
                put("birthdate", 19880515);
                put("gender", "F");
                put("address", new java.util.LinkedHashMap<String, Object>() {{
                    put("addressLineOne", "456 Oak Avenue");
                    put("city", "Tampa");
                    put("stateOrProvinceCode", "FL");
                    put("zipCode", "33602");
                }});
            }});
            put("storeNumber", 9989);
            put("dataEncryption", false);
        }});

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(multiPayerCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertTrue("Should have multiple insurance records for multiple payers",
                response.getInsuranceInfo().size() >= 2);

        // Verify each record has distinct cardHolderId
        for (GetInsuranceByPatientInfoV2Response.InsuranceInfo info : response.getInsuranceInfo()) {
            Assert.assertNotNull("CardHolderId should not be null for any record", info.getCardHolderId());
            Assert.assertNotNull("RxBin should not be null in plaintext mode", info.getRxBin());
        }
    }

    // ========================
    // ENCRYPTED MODE FIELD FILTER TEST
    // ========================

    @Test(description = "V2 encrypted mode: verify encrypted response fields are restricted - no rxBin, rxPCN, rxGroup, carrierId, planId")
    public void getInsuranceByPatientInfoV2EncryptedModeFieldsRestrictedTest() throws IOException {
        ensureBomSetup();
        String payload = buildV2RequestPayload(true);

        ServiceResponse serviceResponse = insuranceWrapper.getInsuranceByPatientInfoV2(dynamicCustomerId, payload);
        Assert.assertEquals("Expected HTTP 200", 200, serviceResponse.getStatusCode());

        GetInsuranceByPatientInfoV2Response response = serviceResponse.getDataResponse(GetInsuranceByPatientInfoV2Response.class);
        Assert.assertNotNull("InsuranceInfo list should not be null", response.getInsuranceInfo());
        Assert.assertFalse("Should have at least one insurance", response.getInsuranceInfo().isEmpty());

        for (GetInsuranceByPatientInfoV2Response.InsuranceInfo info : response.getInsuranceInfo()) {
            // Encrypted mode: only validationToken, masked cardHolderId, processorName, isWalmartEligible
            Assert.assertNotNull("ValidationToken must be present in encrypted mode", info.getValidationToken());
            Assert.assertNotNull("CardHolderId must be present", info.getCardHolderId());
            Assert.assertTrue("CardHolderId must be masked", info.getCardHolderId().contains("*"));
            Assert.assertNotNull("ProcessorName must be present", info.getProcessorName());
            Assert.assertNotNull("IsWalmartEligible must be present", info.getIsWalmartEligible());

            // These fields MUST be null in encrypted mode
            Assert.assertNull("RxBin must be null in encrypted mode", info.getRxBin());
            Assert.assertNull("RxPCN must be null in encrypted mode", info.getRxPCN());
            Assert.assertNull("RxGroup must be null in encrypted mode", info.getRxGroup());
            Assert.assertNull("CarrierId must be null in encrypted mode", info.getCarrierId());
            Assert.assertNull("PlanId must be null in encrypted mode", info.getPlanId());
        }
    }

    // ========================
    // HELPER METHODS
    // ========================

    private static BomTestDataSetupRequest buildBomTestDataSetupRequest(
            String firstName, String lastName, String dob, String gender,
            String addressLine1, String city, String postalCode, String state,
            String storeNbr, String storeCountryCode,
            String cardholderId, String groupId, String iin, String pcn) {

        BomTestDataSetupRequest.Address address = BomTestDataSetupRequest.Address.builder()
                .addressLine1(addressLine1).city(city).postalCode(postalCode).state(state).build();
        BomTestDataSetupRequest.Patient patient = BomTestDataSetupRequest.Patient.builder()
                .lastName(lastName).firstName(firstName).birthdate(dob).gender(gender)
                .address(address).build();
        BomTestDataSetupRequest.Request request = BomTestDataSetupRequest.Request.builder()
                .patient(patient).storeNbr(storeNbr).storeCountryCode(storeCountryCode).build();

        return BomTestDataSetupRequest.builder()
                .request(request)
                .numberOfPayer(1)
                .cardholderId(Collections.singletonList(cardholderId))
                .groupId(Collections.singletonList(groupId))
                .iin(Collections.singletonList(iin))
                .pcn(Collections.singletonList(pcn))
                .build();
    }
}
