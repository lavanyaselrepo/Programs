package insuranceorchestrator;

import accountorchestrator.utils.CommonAccountHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.utils.SharedUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.request.CPRUpdatePatientRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.model.response.CPRUpdatePatientResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.request.fetchInsurance.CprViewInsuranceRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.AddInsurance.AddInsuranceV1Request;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.PatientInsuranceViewInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewInsuranceCPRResponse.ViewInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.*;


public class AddInsuranceTests {

    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();
    Gson gson = new Gson();
    Random rand = new Random();

    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    private CARetrofit caRetrofit;
    public static final String BIN_NUMBER = "610502";
    public static final String PCN = "00670000";
    public static final String CARDHOLDER_ID = "248201700";
    public static final Integer CARRIER_ID = 100426;
    public static final Integer PLAN_ID = 171;
    public static final Integer CATEGORY = 1006;

    public static final String BIN_NUMBER_2 = "601574";
    public static final String PCN_2 = null;
    public static final String CARDHOLDER_ID_2 = "72939293";
    public static final Integer CARRIER_ID_2 = 116653;
    public static final Integer PLAN_ID_2 = 100;
    public static final Integer CATEGORY_2 = 1004;


    public static final String CARDHOLDER_ID_3 = "33653564542";
    public static final Integer CARRIER_ID_3 = 123495;
    public static final Integer PLAN_ID_3 = 127;
    public static final Integer CATEGORY_3 = 1006;

    public static final String DISCOUNT_BIN_NUMBER = "808412";
    public static final String DISCOUNT_PCN = "45370";
    public static final String DISCOUNT_CARDHOLDER_ID = "12331892332";
    public static final Integer DISCOUNT_CARRIER_ID = 116135;
    public static final Integer DISCOUNT_PLAN_ID = 179;
    public static final Integer DISCOUNT_CATEGORY = 1005;

    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit;
    private IDatabaseContext accountDbContext;
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit;

    private List<String> pharmacyAccountToBeDeleted;
    private List<CPRUpdatePatientRequest> cprProfilesToBeDeletedList;
    private ObjectMapper objectMapper;

    @BeforeClass
    void setContext() throws IOException {
        accountDbContext =
                AutomationManager.getInstance().getDPAccountDBContext();
        cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
        accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
        caRetrofit =  new CARetrofit();
        pharmacyAccountToBeDeleted = new ArrayList<>();
        cprProfilesToBeDeletedList = new ArrayList<>();
        objectMapper = new ObjectMapper();
    }

    @Test(description = "Add Insurance with invalid payload - Valid insurance not present in RDM for the given bin", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "AddInsurance")
    public void addInsuranceInvalidTest_3(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code is not matching", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(addInsuranceErrorResponse.getError().getCode().trim(), errorCode.trim());
        Reporter.logJSON("Error message", addInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Add Insurance with invalid payload - Valid insurance not present in RDM for the given pcn", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "AddInsurance")
    public void addInsuranceInvalidTest_4(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code is not matching", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(addInsuranceErrorResponse.getError().getCode().trim(), errorCode.trim());
        Reporter.logJSON("Error message", addInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Add Insurance with invalid payload - Logged in customerId not same as insurance customerId if isDependent is false", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "AddInsurance")
    public void addInsuranceInvalidTest_6(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code is not matching", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(addInsuranceErrorResponse.getError().getCode().trim(), errorCode.trim());
        Reporter.logJSON("Error message", addInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Add Insurance with invalid payload - invalid input request , customerId not present", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "AddInsurance")
    public void addInsuranceInvalidTest_8(String payload, String customerId, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code is not matching", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(addInsuranceErrorResponse.getError().getCode().trim(), errorCode.trim());
        Reporter.logJSON("Error message", addInsuranceErrorResponse.getError().getMessage());


    }

    @Test(description = "Coverage At billSeqNum 1 is Insurance then should be added at the active+1 position")
    void testAddInsuranceWithExistingOneAddedAtTheEndSuccess() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                CARDHOLDER_ID_2,
                CARRIER_ID_2,
                PLAN_ID_2,
                CATEGORY_2,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, false);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);
        // Validate status code
        Assert.assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        Assert.assertEquals("Not Added at expected position", Integer.valueOf(2), billSeqNumber);
    }

    @Test(description = "Coverage At billSeqNum 1 is Discount and inactive then should be added at the start of the list")
    void testAddInsuranceWithExistingOneAddedAtTheStartSuccess() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoDiscount = new CPRUpdatePatientRequest.PatientInsuranceInfo(DISCOUNT_PLAN_ID, DISCOUNT_CARRIER_ID, DISCOUNT_CARDHOLDER_ID, DISCOUNT_CATEGORY,"N");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = Arrays.asList(patientInsuranceInfoDiscount);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                patientInsuranceInfoList,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);


        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, false);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);

        // Validate status code
        Assert.assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        Assert.assertEquals("Not Added at expected position", Integer.valueOf(1), billSeqNumber);
    }


    @Test(description = "Coverage At billSeqNum 1 is Discount and the other insurance is inactive then should be added at the second of the list")
    void testAddInsuranceWithExistingOneAddedAtTheStartWithNoActiveSuccess() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
       // String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoDiscount = new CPRUpdatePatientRequest.PatientInsuranceInfo(DISCOUNT_PLAN_ID, DISCOUNT_CARRIER_ID, DISCOUNT_CARDHOLDER_ID, DISCOUNT_CATEGORY,"Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY,"N");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = Arrays.asList(patientInsuranceInfoDiscount, patientInsuranceInfo2);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                patientInsuranceInfoList,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        Thread.sleep(20000);
        // Building the Request payload
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, false);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);

        // Validate status code
        Assert.assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);


        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        Assert.assertEquals("Not Added at expected position", Integer.valueOf(2), billSeqNumber);
    }


    @Test(description = "Coverage At billSeqNum 1 is Discount and the other insurance is inactive then should be added at the start of the list")
    void testAddInsuranceWithExistingOneAddedAtTheMiddleWithoneActiveInMiddleSuccess() throws Exception, InterruptedException {
        // Setting up Test Data
       // String customerId = SharedUtils.createCAIndividualAccount(SharedUtils.getRandomEmailAddress(), caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(SharedUtils.getRandomEmailAddress());
        String randomCustomerId = SharedUtils.createCAIndividualAccount(SharedUtils.getRandomEmailAddress(), caRetrofit);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfoDiscount = new CPRUpdatePatientRequest.PatientInsuranceInfo(DISCOUNT_PLAN_ID, DISCOUNT_CARRIER_ID, DISCOUNT_CARDHOLDER_ID, DISCOUNT_CATEGORY,"Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo2 = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY,"Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo patientInsuranceInfo3 = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID_3, CARRIER_ID_3, CARDHOLDER_ID_3, CATEGORY,"N");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = Arrays.asList(patientInsuranceInfoDiscount, patientInsuranceInfo2, patientInsuranceInfo3);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", CommonUtil.generateRandomNumber(10), zipCode,
                patientInsuranceInfoList,
                cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
                getInsertOcidQuery(
                        CommonUtil.generateRandomNumber(9), String.valueOf(cprUpdatePatientRequest.getStoreNbr()), String.valueOf(cprUpdatePatientRequest.getPatientId()), customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload
        String payload = buildCPRAddInsuranceReqForInsurance(customerId, false);

        // Calling addInsurance API
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);

        // Validate status code
        Assert.assertEquals("Status code is not matching", 200, serRes.getStatusCode());

        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);

        Integer billSeqNumber = viewInsuranceResponse.getPatientInsuranceViewInfo().stream().filter(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)))
                .findAny()
                .map(PatientInsuranceViewInfo::getBillingSeqNbr)
                .orElse(null);

        Assert.assertEquals("Not Added at expected position", Integer.valueOf(3), billSeqNumber);


        // Building the Request payload for randomCID
        String randomCustomerPayload = buildCPRAddInsuranceReqForInsurance(randomCustomerId, true);
        ServiceResponse serResTwo = insuranceWrapper.addInsurance(randomCustomerPayload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serResTwo.getDataResponse(AddInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code is not matching", 400, serResTwo.getStatusCode());

        // Step - 4: Validate random CID is not a valid dependent
        Assert.assertEquals("DPR-DPINSOR-3006", addInsuranceErrorResponse.getError().getCode().trim());
    }

    @Test(description = "Test 1: Same as existing insurance (same cardholder id, carrier id, plan id, rxbin) - should return 400")
    void testAddSameAsExistingInsurance() throws IOException, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Create account with an insurance
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", 
            CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", 
            CommonUtil.generateRandomNumber(10), zipCode,
            CARDHOLDER_ID, CARRIER_ID, PLAN_ID, CATEGORY, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
            getInsertOcidQuery(
                CommonUtil.generateRandomNumber(9), 
                String.valueOf(cprUpdatePatientRequest.getStoreNbr()), 
                String.valueOf(cprUpdatePatientRequest.getPatientId()), 
                customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload with EXACT same insurance details
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID) // Same cardholder ID
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID)) // Same carrier ID
                                .planId(String.valueOf(PLAN_ID)) // Same plan ID
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER) // Same RX BIN
                                .rxPCN(PCN) // Same PCN
                                .build()
                ))
                .build();
        Thread.sleep(2000);
        String payload = objectMapper.writeValueAsString(request);

        // Calling addInsurance API - should fail due to exact same insurance
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals("Status code should be 400 for same insurance", 400, serRes.getStatusCode());
        Assert.assertNotNull("Error response should not be null", addInsuranceErrorResponse.getError());
        Reporter.logJSON("Same insurance validation", "Test passed - returned 400 as expected");
    }

    @Test(description = "Test 2: Similar insurance (matching 6 character substring of cardholder id, carrier id, plan id, rxbin) - should return 400")
    void testAddSimilarInsurance() throws IOException, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Create account with existing insurance using CARDHOLDER_ID = "248201700"
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", 
            CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", 
            CommonUtil.generateRandomNumber(10), zipCode,
            CARDHOLDER_ID, CARRIER_ID, PLAN_ID, CATEGORY, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
            getInsertOcidQuery(
                CommonUtil.generateRandomNumber(9), 
                String.valueOf(cprUpdatePatientRequest.getStoreNbr()), 
                String.valueOf(cprUpdatePatientRequest.getPatientId()), 
                customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload with similar insurance (same 6-char substring "248201")
        String similarCardholderID = "248201999"; // Same first 6 characters as "248201700"
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(similarCardholderID) // Similar cardholder ID (same 6-char substring)
                                .cardholderFirstName("SimilarFirstName")
                                .cardholderLastName("SimilarLastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID)) // Same carrier ID
                                .planId(String.valueOf(PLAN_ID)) // Same plan ID
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER) // Same RX BIN
                                .rxPCN(PCN) // Same PCN
                                .build()
                ))
                .build();
        String payload = objectMapper.writeValueAsString(request);

        // Calling addInsurance API - should fail due to similar insurance
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals("Status code should be 400 for similar insurance", 400, serRes.getStatusCode());
        Assert.assertNotNull("Error response should not be null", addInsuranceErrorResponse.getError());
        Reporter.logJSON("Similar insurance validation", "Test passed - returned 400 as expected");
    }

    @Test(description = "Test 3: Adding same and similar as existing insurance - should return 400")
    void testAddSameAndSimilarAsExisting() throws IOException, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);

        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Create account with multiple existing insurances
        CPRUpdatePatientRequest.PatientInsuranceInfo primaryInsurance = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "Y");
        CPRUpdatePatientRequest.PatientInsuranceInfo secondaryInsurance = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY_2, "Y");

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = Arrays.asList(primaryInsurance, secondaryInsurance);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", 
            CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", 
            CommonUtil.generateRandomNumber(10), zipCode,
            patientInsuranceInfoList, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
            getInsertOcidQuery(
                CommonUtil.generateRandomNumber(9), 
                String.valueOf(cprUpdatePatientRequest.getStoreNbr()), 
                String.valueOf(cprUpdatePatientRequest.getPatientId()), 
                customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload that matches one of the existing insurances (secondary)
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID_2) // Same as secondary insurance
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID_2)) // Same carrier as secondary
                                .planId(String.valueOf(PLAN_ID_2)) // Same plan as secondary
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER_2) // Same BIN as secondary
                                .rxPCN(PCN_2) // Same PCN as secondary
                                .build()
                ))
                .build();
        String payload = objectMapper.writeValueAsString(request);

        // Calling addInsurance API - should fail as it matches existing insurance
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceErrorResponse addInsuranceErrorResponse = serRes.getDataResponse(AddInsuranceErrorResponse.class);

        // Validate status code
        Assert.assertEquals("Status code should be 400 for same/similar insurance", 400, serRes.getStatusCode());
        Assert.assertNotNull("Error response should not be null", addInsuranceErrorResponse.getError());
        Reporter.logJSON("Same and similar insurance validation", "Test passed - returned 400 as expected");
    }

    @Test(description = "Test 4: Add same insurance as existing inactive insurance - should be successful and return 200")
    void testAddSameAsInactiveInsurance() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);

        // Create account with inactive insurance and one active insurance
        CPRUpdatePatientRequest.PatientInsuranceInfo inactiveInsurance = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID, CARRIER_ID, CARDHOLDER_ID, CATEGORY, "N"); // Inactive
        CPRUpdatePatientRequest.PatientInsuranceInfo activeInsurance = new CPRUpdatePatientRequest.PatientInsuranceInfo(PLAN_ID_2, CARRIER_ID_2, CARDHOLDER_ID_2, CATEGORY_2, "Y"); // Active

        List<CPRUpdatePatientRequest.PatientInsuranceInfo> patientInsuranceInfoList = Arrays.asList(inactiveInsurance, activeInsurance);

        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", 
            CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", 
            CommonUtil.generateRandomNumber(10), zipCode,
            patientInsuranceInfoList, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
            getInsertOcidQuery(
                CommonUtil.generateRandomNumber(9), 
                String.valueOf(cprUpdatePatientRequest.getStoreNbr()), 
                String.valueOf(cprUpdatePatientRequest.getPatientId()), 
                customerId));
        pharmacyAccountToBeDeleted.add(customerId);
        //Thread.sleep(20000);
        // Building the Request payload with same details as inactive insurance
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(CARDHOLDER_ID) // Same as inactive insurance
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID)) // Same carrier as inactive
                                .planId(String.valueOf(PLAN_ID)) // Same plan as inactive
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER) // Same BIN as inactive
                                .rxPCN(PCN) // Same PCN as inactive
                                .build()
                ))
                .build();
        Thread.sleep(2000);
        String payload = objectMapper.writeValueAsString(request);

        // Calling addInsurance API - should succeed for inactive insurance
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);

        // Validate status code
        Assert.assertEquals("Status code should be 200 for same as inactive insurance", 200, serRes.getStatusCode());
        
        // Verify insurance is present in CPR
        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);
        
        // Verify the insurance was added successfully
        boolean insuranceFound = viewInsuranceResponse.getPatientInsuranceViewInfo().stream()
                .anyMatch(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)));
        
        Assert.assertTrue("Insurance should be present in CPR after successful addition", insuranceFound);
        Reporter.logJSON("Same as inactive insurance validation", "Test passed - returned 200 and insurance verified in CPR");
    }

    @Test(description = "Test 5: Same carrier id, plan id, rxbin but different cardholder id - should return 200")
    void testAddDifferentCardholderSameCarrierPlanRxBin() throws Exception, InterruptedException {
        // Setting up Test Data
        String emailAddress = SharedUtils.getRandomEmailAddress();
        //String customerId = SharedUtils.createCAIndividualAccount(emailAddress, caRetrofit);
        String customerId = CommonAccountHelper.createDotComAccountAndGetCidOfAstroFromWIAPWithRandomName(emailAddress);
        String firstName = CommonUtil.generateRandomFirstName(8);
        String lastName = CommonUtil.generateRandomFirstName(8);
        String zipCode = CommonUtil.generateRandomNumber(6);
        // Create account with existing insurance
        CPRUpdatePatientRequest cprUpdatePatientRequest = SharedUtils.createCPRAccountWithInsurance("9928", 
            CommonUtil.generateRandomNumber(6), firstName, lastName, "M", "1996-01-01", 
            CommonUtil.generateRandomNumber(10), zipCode,
            CARDHOLDER_ID, CARRIER_ID, PLAN_ID, CATEGORY, cprPatientUpdateRetrofit);
        cprProfilesToBeDeletedList.add(cprUpdatePatientRequest);

        accountDbContext.executeInsertQuery(
            getInsertOcidQuery(
                CommonUtil.generateRandomNumber(9),
                String.valueOf(cprUpdatePatientRequest.getStoreNbr()), 
                String.valueOf(cprUpdatePatientRequest.getPatientId()), 
                customerId));
        pharmacyAccountToBeDeleted.add(customerId);
       // //Thread.sleep(20000);
        // Building the Request payload with different cardholder ID but same carrier, plan, rxbin
        String differentCardholderID = "999888777"; // Completely different cardholder ID (different 6-char substring)
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(false)
                                .cardholderId(differentCardholderID) // Different cardholder ID
                                .cardholderFirstName("DifferentFirstName")
                                .cardholderLastName("DifferentLastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID)) // Same carrier ID
                                .planId(String.valueOf(PLAN_ID)) // Same plan ID
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER) // Same RX BIN
                                .rxPCN(PCN) // Same PCN
                                .build()
                ))
                .build();
        String payload = objectMapper.writeValueAsString(request);

        // Calling addInsurance API - should succeed with different cardholder ID
        ServiceResponse serRes = insuranceWrapper.addInsurance(payload, customerId);
        AddInsuranceResponse addInsuranceResponse = serRes.getDataResponse(AddInsuranceResponse.class);

        // Validate status code
        Assert.assertEquals("Status code should be 200 for different cardholder ID", 200, serRes.getStatusCode());
        Assert.assertNotNull("Response should not be null for successful addition", addInsuranceResponse);
        
        // Verify insurance is present in CPR
        CprViewInsuranceRequest cprViewInsuranceRequest = CprViewInsuranceRequest.builder().storeNbr(cprUpdatePatientRequest.getStoreNbr()).patientId(cprUpdatePatientRequest.getPatientId()).build();
        String viewInsuranceCPRPayload = objectMapper.writeValueAsString(cprViewInsuranceRequest);
        ServiceResponse serResView = insuranceWrapper.viewInsuranceCPR(viewInsuranceCPRPayload);
        ViewInsuranceResponse viewInsuranceResponse = serResView.getDataResponse(ViewInsuranceResponse.class);
        
        // Verify the insurance was added successfully with the different cardholder ID
        boolean insuranceFound = viewInsuranceResponse.getPatientInsuranceViewInfo().stream()
                .anyMatch(patientInsuranceViewInfo ->
                        patientInsuranceViewInfo.getInsuranceCarrierId().equalsIgnoreCase(String.valueOf(CARRIER_ID)) &&
                                patientInsuranceViewInfo.getInsurancePlanId().equalsIgnoreCase(String.valueOf(PLAN_ID)) &&
                                patientInsuranceViewInfo.getCardholderId().equalsIgnoreCase(differentCardholderID));
        
        Assert.assertTrue("Insurance with different cardholder ID should be present in CPR after successful addition", insuranceFound);
        Reporter.logJSON("Different cardholder ID validation", "Test passed - returned 200 and insurance verified in CPR");
    }

    private String buildCPRAddInsuranceReqForInsurance(String customerId, Boolean isDependent) throws JsonProcessingException {
        AddInsuranceV1Request request = AddInsuranceV1Request.builder()
                .insuranceInfo(Collections.singletonList(
                        AddInsuranceV1Request.InsuranceInfo.builder()
                                .customerId(customerId)
                                .isDependent(isDependent)
                                .cardholderId(CARDHOLDER_ID)
                                .cardholderFirstName("FirstName")
                                .cardholderLastName("LastName")
                                .carrierAbbr("abr")
                                .planRefCode("234")
                                .carrierId(String.valueOf(CARRIER_ID))
                                .planId(String.valueOf(PLAN_ID))
                                .relation("CardHolder")
                                .rxBin(BIN_NUMBER)
                                .rxPCN(PCN)
                                .build()
                ))
                .build();
        return objectMapper.writeValueAsString(request);
    }

    private static String getInsertOcidQuery(
            String onlineCustId,
            String authStore,
            String authPatientId,
            String uuid) {
        return String.format(
                "INSERT INTO pharmacydb.ONLN_CENTRAL_PTNT(ONLINE_CUST_ID, ONLINE_STORE_NBR, ONLINE_ACTIVE_IND, ACTIVATED_TS, INACTIVATED_TS, AUTH_STORE_NBR, AUTH_PATIENT_ID, DATA_LOAD_TS, CENTRAL_LAST_CHANGE_TS, ECOMM_CUST_NBR, ONLINE_ACCOUNT_ID, ACCOUNT_CREATION_SOURCE)VALUES(%s, %s, N'Y', '2024-01-01', NULL, %s, %s, '2024-01-01', '2024-01-01', N'%s', N'%s', N'smsOtpVerification')",
                onlineCustId, "9928", authStore, authPatientId, uuid, uuid);
    }

    private void deleteOCPRecord(String uuid) {
        String deleteQuery = String.format(
                "DELETE FROM pharmacydb.ONLN_CENTRAL_PTNT WHERE ONLINE_ACCOUNT_ID = '%s'", uuid);
        accountDbContext.executeQuery(deleteQuery);
    }


    /**
     * Clean up for all created accounts
     *
     * @throws IOException
     */
    @AfterTest
    void cleanUp() throws IOException {
        cprProfilesToBeDeletedList.forEach(
                request -> {
                    request.getPatientInfo().setPatientStatusCode(20708);
                    try {
                        Response<CPRUpdatePatientResponse> response = cprPatientUpdateRetrofit.createOrUpdatePatient(request);
                        if (!(response.code() == 202
                                && response.body() != null
                                && response.body().getErrors().isEmpty())
                                && response.code() != 406) {
                            throw new RuntimeException(
                                    "CPR Account failed to update with status code 20708 for PatientId :"
                                            + request.getPatientId()
                                            + " StoreNbr :"
                                            + request.getStoreNbr()
                                            + " . HttpStatusCode : "
                                            + response.code());
                        }
                    } catch (IOException e) {
                    }
                });

        pharmacyAccountToBeDeleted
                .forEach(this::deleteOCPRecord);
    }
}

