package insuranceorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.RDMResponse.RDMResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewGlobalInsurance.ViewGlobalInsuranceErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.datamodels.response.ViewGlobalInsurance.ViewGlobalInsuranceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.insuranceorchestrator.restapi.InsuranceWrapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.junit.Assert;
import org.testng.annotations.Test;
import java.io.IOException;


public class ViewGlobalInsuranceTests {

    InsuranceWrapper insuranceWrapper = new InsuranceWrapper();

    @Test(description = "Validate viewGlobalInsurance API for valid request without lookUpCID", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceValidTest(String customerId, int statusCode,String lookUpCID, String cardHolderId, String planDetails, String bomSetup) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.setupBomTestData(bomSetup);

        // Step - 2: Calling viewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceResponse viewGlobalInsuranceResponse = serRes.getDataResponse(ViewGlobalInsuranceResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals(statusCode, serRes.getStatusCode());

        // Step - 4: Validate response body of ViewInsurance API
        int noOfInsurance = viewGlobalInsuranceResponse.getInsuranceInfo().size();

        for (int i = 0; i < noOfInsurance; i++) {

            Assert.assertEquals(customerId, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCustomerId());
            Assert.assertEquals(false, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsDependent());
            Assert.assertTrue(cardHolderId.contains(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCardholderId()));
            Assert.assertFalse(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIRefIds().isEmpty());
            String rxGroup= viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxGroup();
            String isWalmartEligible= String.valueOf(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsWalmartEligible());


            ServiceResponse serResRDM = insuranceWrapper.getRDM(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxBin(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxPCN());
            RDMResponse rdmResponse = serResRDM.getDataResponse(RDMResponse.class);

            Assert.assertEquals(rdmResponse.getProcessorName(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getProcessorName());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierCompanyId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierId());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierPlanId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanId());
            Assert.assertEquals(rdmResponse.getInsCarrierAbbr(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierAbbr());
            Assert.assertEquals(rdmResponse.getInsPlanRefCode(),viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanRefCode());

            Assert.assertTrue(planDetails.contains(rxGroup+" "+isWalmartEligible));

        }
    }

    @Test(description = "Validate viewGlobalInsurance API for valid request with lookUpCID", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceValidTestWithLookUPCID(String customerId, String lookUpCID, int statusCode, String cardHolderId, String planDetails, String bomSetup) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.setupBomTestData(bomSetup);

        // Step - 2: Calling viewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceResponse viewGlobalInsuranceResponse = serRes.getDataResponse(ViewGlobalInsuranceResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals(statusCode, serRes.getStatusCode());

        // Step - 4: Validate response body of ViewInsurance API
        int noOfInsurance = viewGlobalInsuranceResponse.getInsuranceInfo().size();

        for (int i = 0; i < noOfInsurance; i++) {

            Assert.assertEquals(lookUpCID, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCustomerId());
            Assert.assertEquals(true, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsDependent());
            Assert.assertTrue(cardHolderId.contains(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCardholderId()));
            Assert.assertFalse(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIRefIds().isEmpty());
            String rxGroup = viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxGroup();
            String isWalmartEligible = String.valueOf(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsWalmartEligible());


            ServiceResponse serResRDM = insuranceWrapper.getRDM(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxBin(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxPCN());
            RDMResponse rdmResponse = serResRDM.getDataResponse(RDMResponse.class);

            Assert.assertEquals(rdmResponse.getProcessorName(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getProcessorName());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierCompanyId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierId());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierPlanId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanId());
            Assert.assertEquals(rdmResponse.getInsCarrierAbbr(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierAbbr());
            Assert.assertEquals(rdmResponse.getInsPlanRefCode(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanRefCode());

            Assert.assertTrue(planDetails.contains(rxGroup + " " + isWalmartEligible));

        }
    }

    @Test(description = "Customer Digital Account not present", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceInvalidTest_1(String customerId, String lookUpCID, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling ViewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceErrorResponse viewGlobalInsuranceErrorResponse = serRes.getDataResponse(ViewGlobalInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(errorCode, viewGlobalInsuranceErrorResponse.getError().getCode());
        Reporter.logJSON("Error message", viewGlobalInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Insurance customer is not a valid Dependent of the logged in customer", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceInvalidTest_2(String customerId, String lookUpCID, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling ViewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceErrorResponse viewGlobalInsuranceErrorResponse = serRes.getDataResponse(ViewGlobalInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error Code
        Assert.assertTrue(viewGlobalInsuranceErrorResponse.getError().getCode().equals(errorCode));
        Reporter.logJSON("Error message", viewGlobalInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "invalid lookupcid and cid", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceInvalidTest_3(String customerId, String lookUpCID, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling ViewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceErrorResponse viewGlobalInsuranceErrorResponse = serRes.getDataResponse(ViewGlobalInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(errorCode,viewGlobalInsuranceErrorResponse.getError().getCode());
        Reporter.logJSON("Error message", viewGlobalInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "Validate whether error code 500 is received when there is a System error for viewGlobalInsurance API", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceInvalidTest_4(String customerId, String lookUpCID, int statusCode, String errorCode) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        // Step - 2: Calling ViewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(null, lookUpCID);
        ViewGlobalInsuranceErrorResponse viewGlobalInsuranceErrorResponse = serRes.getDataResponse(ViewGlobalInsuranceErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertTrue(serRes.getStatusCode() == statusCode);

        // Step - 4: Validate Error Code
        Assert.assertEquals(errorCode,viewGlobalInsuranceErrorResponse.getError().getCode());
        Reporter.logJSON("Error message", viewGlobalInsuranceErrorResponse.getError().getMessage());

    }

    @Test(description = "verify insurance info of only the customer is returned in the response payload when lookupCID is not passed in the endpoint", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceValidTest_3(String customerId, int statusCode,String lookUpCID, String cardHolderId, String planDetails, String bomSetup) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.setupBomTestData(bomSetup);

        // Step - 2: Calling viewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceResponse viewGlobalInsuranceResponse = serRes.getDataResponse(ViewGlobalInsuranceResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals(statusCode, serRes.getStatusCode());

        // Step - 4: Validate response body of ViewInsurance API
        int noOfInsurance = viewGlobalInsuranceResponse.getInsuranceInfo().size();

        for (int i = 0; i < noOfInsurance; i++) {

            Assert.assertEquals(customerId, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCustomerId());
            Assert.assertEquals(false, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsDependent());
            Assert.assertTrue(cardHolderId.contains(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCardholderId()));
            Assert.assertFalse(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIRefIds().isEmpty());
            String rxGroup= viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxGroup();
            String isWalmartEligible= String.valueOf(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsWalmartEligible());


            ServiceResponse serResRDM = insuranceWrapper.getRDM(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxBin(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxPCN());
            RDMResponse rdmResponse = serResRDM.getDataResponse(RDMResponse.class);
if(i!=1) {
    Assert.assertEquals(rdmResponse.getProcessorName(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getProcessorName());
    Assert.assertEquals(rdmResponse.getInsuranceCarrierCompanyId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierId());
    Assert.assertEquals(rdmResponse.getInsuranceCarrierPlanId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanId());
    Assert.assertEquals(rdmResponse.getInsCarrierAbbr(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierAbbr());
    Assert.assertEquals(rdmResponse.getInsPlanRefCode(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanRefCode());
}
if(i==1)
{
    Assert.assertEquals("false",isWalmartEligible);
}
        Assert.assertTrue(planDetails.contains(rxGroup+" "+isWalmartEligible));

        }
    }

    @Test(description = "verify when lookUpCid is present only insurance of lookUpcid is returned", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceValidTest_4(String customerId, int statusCode,String lookUpCID, String cardHolderId, String planDetails, String bomSetup) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.setupBomTestData(bomSetup);

        // Step - 2: Calling viewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceResponse viewGlobalInsuranceResponse = serRes.getDataResponse(ViewGlobalInsuranceResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals(statusCode, serRes.getStatusCode());

        // Step - 4: Validate response body of ViewInsurance API
        int noOfInsurance = viewGlobalInsuranceResponse.getInsuranceInfo().size();

        for (int i = 0; i < noOfInsurance; i++) {

            Assert.assertEquals(lookUpCID, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCustomerId());
            Assert.assertEquals(true, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsDependent());
            Assert.assertTrue(cardHolderId.contains(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCardholderId()));
            Assert.assertFalse(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIRefIds().isEmpty());
            String rxGroup= viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxGroup();
            String isWalmartEligible= String.valueOf(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsWalmartEligible());


            ServiceResponse serResRDM = insuranceWrapper.getRDM(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxBin(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxPCN());
            RDMResponse rdmResponse = serResRDM.getDataResponse(RDMResponse.class);

            Assert.assertEquals(rdmResponse.getProcessorName(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getProcessorName());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierCompanyId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierId());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierPlanId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanId());
            Assert.assertEquals(rdmResponse.getInsCarrierAbbr(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierAbbr());
            Assert.assertEquals(rdmResponse.getInsPlanRefCode(),viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanRefCode());

            Assert.assertTrue(planDetails.contains(rxGroup+" "+isWalmartEligible));

        }
    }




    @Test(description = "viewGlobalInsurance with valid CID of dependent and without lookUpCID", dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/insuranceOrchestrator/insuranceOrchestratorTestData.xlsx", sheetName = "ViewGlobalInsurance")
    public void viewGlobalInsuranceValidTest_2(String customerId, int statusCode,String lookUpCID, String cardHolderId, String planDetails, String bomSetup) throws IOException {

        // Step - 1: Setting and logging customer ID to make the respective calls
        Reporter.logJSON("Customer Account Id", customerId);

        insuranceWrapper.setupBomTestData(bomSetup);

        // Step - 2: Calling viewGlobalInsurance API
        ServiceResponse serRes = insuranceWrapper.viewGlobalInsurance(customerId, lookUpCID);
        ViewGlobalInsuranceResponse viewGlobalInsuranceResponse = serRes.getDataResponse(ViewGlobalInsuranceResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals(statusCode, serRes.getStatusCode());

        // Step - 4: Validate response body of ViewInsurance API
        int noOfInsurance = viewGlobalInsuranceResponse.getInsuranceInfo().size();

        for (int i = 0; i < noOfInsurance; i++) {

            Assert.assertEquals(customerId, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCustomerId());
            Assert.assertEquals(false, viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsDependent());
            Assert.assertTrue(cardHolderId.contains(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCardholderId()));
            Assert.assertFalse(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIRefIds().isEmpty());
            String rxGroup= viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxGroup();
            String isWalmartEligible= String.valueOf(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getIsWalmartEligible());


            ServiceResponse serResRDM = insuranceWrapper.getRDM(viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxBin(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getRxPCN());
            RDMResponse rdmResponse = serResRDM.getDataResponse(RDMResponse.class);

            Assert.assertEquals(rdmResponse.getProcessorName(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getProcessorName());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierCompanyId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierId());
            Assert.assertEquals(rdmResponse.getInsuranceCarrierPlanId(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanId());
            Assert.assertEquals(rdmResponse.getInsCarrierAbbr(), viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getCarrierAbbr());
            Assert.assertEquals(rdmResponse.getInsPlanRefCode(),viewGlobalInsuranceResponse.getInsuranceInfo().get(i).getPlanRefCode());

            Assert.assertTrue(planDetails.contains(rxGroup+" "+isWalmartEligible));

        }
    }

    }
