package WellnessUserAttribute;

import WellnessUserAttribute.dataModels.response.IsWellnessRegisteredResponse;
import WellnessUserAttribute.restapi.WellnessUserAttributeRetrofit;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

/**
 * Automation Test Class for dp-profile-service — Wellness User Attribute API
 *
 * Endpoint: GET /v1/customer/{customerAccountId}/attributes/wellness_user
 */
public class GetWellnessUserAttributeTests {

    private WellnessUserAttributeRetrofit wellnessUserAttributeRetrofit;

    // ---------------------------------------------------------------------------
    // Property keys for test data — values live in DragonLibrary config files
    // (config/digitalPharmacy/{env}.properties)
    // ---------------------------------------------------------------------------
    private static final String PROP_VALID_CUSTOMER_ACCOUNT_ID       = "dp.profile.service.test.valid.customer.account.id";
    private static final String PROP_NONEXISTENT_CUSTOMER_ACCOUNT_ID = "dp.profile.service.test.nonexistent.customer.account.id";
    private static final String PROP_INVALID_CUSTOMER_ACCOUNT_ID     = "dp.profile.service.test.invalid.customer.account.id";

    // ---------------------------------------------------------------------------
    // Test data — populated from PropertyReader in @BeforeClass
    // ---------------------------------------------------------------------------
    private String validCustomerAccountId;
    private String nonExistentCustomerAccountId;
    private String invalidCustomerAccountId;

    @BeforeClass
    public void setUpRetrofitClient() {
        wellnessUserAttributeRetrofit = new WellnessUserAttributeRetrofit();

        PropertyReader props = PropertyReader.getInstance();
        validCustomerAccountId       = props.getProperty(PROP_VALID_CUSTOMER_ACCOUNT_ID);
        nonExistentCustomerAccountId = props.getProperty(PROP_NONEXISTENT_CUSTOMER_ACCOUNT_ID);
        invalidCustomerAccountId     = props.getProperty(PROP_INVALID_CUSTOMER_ACCOUNT_ID);
    }

    // ---------------------------------------------------------------------------
    // Helper
    // ---------------------------------------------------------------------------

    /**
     * Reads the error body string safely.
     * errorBody() is a one-shot stream — always call this only once per response.
     */
    private String readErrorBody(Response<?> response) throws IOException {
        return response.errorBody() != null ? response.errorBody().string() : "";
    }

    // ---------------------------------------------------------------------------
    // TC-01 : Valid UUID — registered customer
    // ---------------------------------------------------------------------------

    /**
     * TC-01: A well-formed UUID belonging to an existing customer should return HTTP 200.
     * The response body must contain the {@code isWellnessRegistered} boolean field.
     *
     * NOTE: The service is a stub — it always returns isWellnessRegistered = false regardless
     *       of actual registration state. We assert the field is non-null (present in response).
     */
    @Test(priority = 1, description = "TC-01 | Valid customer UUID returns 200 with isWellnessRegistered field")
    public void isWellnessRegistered_validCustomerId_returns200() throws IOException {
        Reporter.logJSON("customerAccountId", validCustomerAccountId);

        Response<IsWellnessRegisteredResponse> response =
                wellnessUserAttributeRetrofit.isWellnessRegistered(validCustomerAccountId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 200,
                "Expected HTTP 200 for a valid customer UUID: " + validCustomerAccountId);
        Assert.assertNotNull(response.body(),
                "Response body should not be null for a valid UUID request");
        Assert.assertNotNull(response.body().getIsWellnessRegistered(),
                "isWellnessRegistered field should be present (non-null) in the response body");

        Reporter.logJSON("isWellnessRegistered", String.valueOf(response.body().getIsWellnessRegistered()));
    }

    // ---------------------------------------------------------------------------
    // TC-02 : Invalid UUID format → 400
    // ---------------------------------------------------------------------------

    /**
     * TC-02: A path variable that is not a valid UUID format should return HTTP 400.
     * The Spring controller declares {@code @PathVariable UUID customerAccountId} — the framework
     * rejects non-UUID values with a 400 Bad Request before the handler method is invoked.
     */
    @Test(priority = 2, description = "TC-02 | Invalid UUID format returns 400 Bad Request")
    public void isWellnessRegistered_invalidUuidFormat_returns400() throws IOException {
        Reporter.logJSON("customerAccountId", invalidCustomerAccountId);

        Response<IsWellnessRegisteredResponse> response =
                wellnessUserAttributeRetrofit.isWellnessRegistered(invalidCustomerAccountId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 for an invalid UUID format: " + invalidCustomerAccountId);

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    // ---------------------------------------------------------------------------
    // TC-03 : Valid UUID format, non-existent customer → 200 with isWellnessRegistered = false
    // ---------------------------------------------------------------------------

    /**
     * TC-03: A well-formed UUID that does not correspond to any existing customer.
     * Because the GET endpoint is a stub, it returns 200 with isWellnessRegistered = false
     * for any valid UUID — no database lookup is performed.
     */
    @Test(priority = 3, description = "TC-03 | Non-existent but valid UUID returns 200 with isWellnessRegistered = false")
    public void isWellnessRegistered_nonExistentCustomerId_returns200WithFalse() throws IOException {
        Reporter.logJSON("customerAccountId", nonExistentCustomerAccountId);

        Response<IsWellnessRegisteredResponse> response =
                wellnessUserAttributeRetrofit.isWellnessRegistered(nonExistentCustomerAccountId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 200,
                "Expected HTTP 200 for a non-existent but valid UUID: " + nonExistentCustomerAccountId);
        Assert.assertNotNull(response.body(),
                "Response body should not be null for a valid-format UUID");
        Assert.assertNotNull(response.body().getIsWellnessRegistered(),
                "isWellnessRegistered field should be present in the response body");
        Assert.assertFalse(response.body().getIsWellnessRegistered(),
                "isWellnessRegistered should be false for a non-existent customer (stub always returns false)");

        Reporter.logJSON("isWellnessRegistered", String.valueOf(response.body().getIsWellnessRegistered()));
    }
}
