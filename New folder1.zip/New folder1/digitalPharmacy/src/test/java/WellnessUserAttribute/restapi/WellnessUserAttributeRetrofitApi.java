package WellnessUserAttribute.restapi;

import WellnessUserAttribute.dataModels.response.IsWellnessRegisteredResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.Path;

import java.util.Map;

/**
 * Retrofit interface for the Wellness User Attribute endpoints of dp-profile-service.
 *
 * Endpoint: GET /v1/customer/{customerAccountId}/attributes/wellness_user
 */
public interface WellnessUserAttributeRetrofitApi {

    /**
     * GET endpoint to check whether the customer is registered as a Wellness+ user.
     *
     * NOTE: The service currently returns {"isWellnessRegistered": false} for all inputs
     *       (stub implementation — UUID validation happens before business logic).
     *
     * @param customerAccountId customer UUID path variable (typed as String to allow invalid-format testing)
     * @param headers           Map of required auth headers
     * @return Call wrapping IsWellnessRegisteredResponse
     */
    @GET("v1/customer/{customerAccountId}/attributes/wellness_user")
    Call<IsWellnessRegisteredResponse> isWellnessRegistered(
            @Path("customerAccountId") String customerAccountId,
            @HeaderMap Map<String, String> headers
    );
}
