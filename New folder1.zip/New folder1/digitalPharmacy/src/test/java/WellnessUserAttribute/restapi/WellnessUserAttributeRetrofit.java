package WellnessUserAttribute.restapi;

import WellnessUserAttribute.dataModels.response.IsWellnessRegisteredResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.SSLUtils;
import com.walmart.hwqe.commons.signaturegenerator.SignatureGenerator;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Retrofit client wrapper for the Wellness User Attribute endpoints of dp-profile-service.
 *
 * Reuses the same dp.profile.service.* PropertyReader keys as RxOnlineProfileServiceRetrofit
 * since both APIs belong to the same microservice.
 *
 * All configuration is loaded from DragonLibrary PropertyReader (no hardcoded values).
 */
public class WellnessUserAttributeRetrofit {

    // ── Property keys (keys only — values come from DragonLibrary config files) ─
    private static final String PROP_BASE_URL    = "dp.profile.service.base.url";
    private static final String PROP_CONSUMER_ID = "dp.profile.service.consumer.id";
    private static final String PROP_SVC_NAME    = "dp.profile.service.name";
    private static final String PROP_SVC_ENV     = "dp.profile.service.env";
    private static final String PROP_KEY_VERSION = "dp.profile.service.key.version";
    private static final String PROP_PRIVATE_KEY = "dp.account.orchestrator.service.private.key";
    // ───────────────────────────────────────────────────────────────────────────

    private final WellnessUserAttributeRetrofitApi retrofitApi;
    private final String consumerId;
    private final String svcName;
    private final String svcEnv;
    private final String keyVersion;

    public WellnessUserAttributeRetrofit() {
        PropertyReader props = PropertyReader.getInstance();

        consumerId = props.getProperty(PROP_CONSUMER_ID);
        svcName    = props.getProperty(PROP_SVC_NAME);
        svcEnv     = props.getProperty(PROP_SVC_ENV);
        keyVersion = props.getProperty(PROP_KEY_VERSION);

        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(props.getProperty(PROP_BASE_URL))
                .addConverterFactory(JacksonConverterFactory.create(objectMapper))
                .client(SSLUtils.getUnsafeOkHttpClient())
                .build();

        retrofitApi = retrofit.create(WellnessUserAttributeRetrofitApi.class);
    }

    /**
     * Builds the standard set of Walmart auth headers required by dp-profile-service,
     * including a freshly computed WM_SEC.AUTH_SIGNATURE per request.
     *
     * @return Map of header key-value pairs
     */
    private Map<String, String> buildHeaders() {
        String timestamp  = Long.toString(Instant.now().toEpochMilli());
        String privateKey = PropertyReader.getInstance().getProperty(PROP_PRIVATE_KEY);
        String authSig    = SignatureGenerator.generateSig(privateKey, consumerId, keyVersion, timestamp);

        Map<String, String> headers = new HashMap<>();
        headers.put("WM_CONSUMER.ID",          consumerId);
        headers.put("WM_SVC.NAME",             svcName);
        headers.put("WM_SVC.ENV",              svcEnv);
        headers.put("WM_SEC.KEY_VERSION",      keyVersion);
        headers.put("WM_CONSUMER.INTIMESTAMP", timestamp);
        headers.put("WM_SEC.AUTH_SIGNATURE",   authSig);
        headers.put("Content-Type",            "application/json");
        return headers;
    }

    /**
     * Calls GET /v1/customer/{customerAccountId}/attributes/wellness_user
     *
     * @param customerAccountId customer UUID (passed as String to allow invalid-format testing)
     * @return Retrofit Response wrapping IsWellnessRegisteredResponse
     * @throws IOException if a network error occurs
     */
    public Response<IsWellnessRegisteredResponse> isWellnessRegistered(
            String customerAccountId) throws IOException {
        return retrofitApi.isWellnessRegistered(customerAccountId, buildHeaders())
                .execute();
    }
}
