package WellnessUserAttribute.dataModels.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Response model for GET /v1/customer/{customerAccountId}/attributes/wellness_user
 *
 * Maps the JSON response:
 * {
 *   "isWellnessRegistered": false
 * }
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IsWellnessRegisteredResponse {

    /**
     * Indicates whether the customer is registered as a Wellness+ user.
     * The service currently always returns false (stub implementation).
     */
    @JsonProperty("isWellnessRegistered")
    private Boolean isWellnessRegistered;
}
