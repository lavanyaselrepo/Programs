package orderorchestrator.competitiveTransferTests;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTBuyerInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTTestInputInfo;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class OrdersUserActionTests {
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();
    CTBuyerInfo buyerInfo;
    Map<String, CTTestInputInfo> ctOrders = new HashMap<>();
    String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/competitiveTransfersData.json";

    @Test(alwaysRun = true)
    public void dataSetup() throws InterruptedException {
        buyerInfo = competitiveTransferWrapper.createDotcomAccount("07071988");
        Thread.sleep(3000);
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, "defaultTestData", buyerInfo, null);
    }
    @Test(description = "'Orders User Action' verification with invalid CId")
    public void verifyCTOrderUserActionForInvalidCid() {
        ServiceResponse resp = competitiveTransferWrapper.ordersUserAction(ctOrders.get("defaultTestData").getOrderId(), "53d910f9-3250-4c9e-8249-1",201);
        AssertUtil.assertTrue(resp.getDataResponse().isEmpty(), "Response data should be empty");
    }

    @Test(description = "'Orders User Action' verification with invalid CId and invalid OrderId")
    public void verifyCTOrderUserActionForInvalidCidAndOrderId() {
        ServiceResponse resp = competitiveTransferWrapper.ordersUserAction("W00af922954dd7341c8916f6", "53d910f9-3250-4c9e-8249-1",201);
        AssertUtil.assertTrue(resp.getDataResponse().isEmpty(), "Response data should be empty");
    }

    @Test(description = "'Orders User Action' verification with invalid OrderId")
    public void verifyCTOrderUserActionForInvalidOrderId() {
        ServiceResponse resp = competitiveTransferWrapper.ordersUserAction("W00af922954dd7341c8916f6", buyerInfo.getBuyerCid(),201);
        AssertUtil.assertTrue(resp.getDataResponse().isEmpty(), "Response data should be empty");
    }

    @Test(description = "'Orders User Action' verification for CId which is not belongs to OrderId")
    public void verifyCTOrderUserActionWithEmptyHeaders() {
        ServiceResponse resp = competitiveTransferWrapper.ordersUserAction(new HashMap<>(),ctOrders.get("defaultTestData").getOrderId(), buyerInfo.getBuyerCid());
        AssertUtil.assertEquals(resp.getStatusCode(), 400);
        String errorDescription = "Mandatory routing headers must be present: WM_CONSUMER.ID, WM_SVC.NAME, WM_SVC.ENV";
        AssertUtil.assertEquals(resp.getDataResponse(), errorDescription);
    }

}
