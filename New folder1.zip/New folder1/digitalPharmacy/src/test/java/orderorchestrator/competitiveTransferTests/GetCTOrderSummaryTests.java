package orderorchestrator.competitiveTransferTests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.Order;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.request.competitiveTransfer.SubmitCTOrderRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.GetCTOrdersSummaryNonHIPAAResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.SubmitCTOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Set;
import java.util.stream.Collectors;

public class GetCTOrderSummaryTests {

    ObjectMapper objectMapper = new ObjectMapper();
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();

    @Test(description = "Get CT order summary non hipaa successful response")
    public void getCTOrderSummaryNonHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestNonConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);
        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        Thread.sleep(5000);
        String cid = request.getCustomerAccountId();
        GetCTOrdersSummaryNonHIPAAResponse orderSummaryRes = competitiveTransferWrapper.getCTOrdersSummaryNonHIPAA(cid, 200);
        Set<String> orderIds = orderSummaryRes.getOrders().stream().map(Order::getOrderId).collect(Collectors.toSet());
        Assert.assertTrue(orderIds.contains(orderId));
    }

    @Test(description = "Get CT order summary for self hipaa successful response")
    public void getCTOrderSummaryForSelfHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);
        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        Thread.sleep(5000);
        String cid = request.getCustomerAccountId();
        res = competitiveTransferWrapper.getCTOrdersSummaryHIPAA(cid);
        GetCTOrdersSummaryNonHIPAAResponse orderSummaryRes = res.getDataResponse(GetCTOrdersSummaryNonHIPAAResponse.class);
        Set<String> orderIds = orderSummaryRes.getOrders().stream().map(Order::getOrderId).collect(Collectors.toSet());
        Assert.assertTrue(orderIds.contains(orderId));
    }

    @Test(description = "Get CT order summary for dependent hipaa successful response")
    public void getCTOrderSummaryForDependentHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForDependent.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);

        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        Thread.sleep(5000);
        String cid = request.getCustomerAccountId();
        res = competitiveTransferWrapper.getCTOrdersSummaryHIPAA(cid);
        GetCTOrdersSummaryNonHIPAAResponse orderSummaryRes = res.getDataResponse(GetCTOrdersSummaryNonHIPAAResponse.class);
        Set<String> orderIds = orderSummaryRes.getOrders().stream().map(Order::getOrderId).collect(Collectors.toSet());
        Assert.assertTrue(orderIds.contains(orderId));
    }

    @Test(description = "Get CT order summary for other hipaa successful response")
    public void getCTOrderSummaryForOtherHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        request.setRequestedFor("OTHERS");
        request.getPatientInfo().setFirstName("TEST");
        request.getPatientInfo().setLastName("XYZ");
        request.getPatientInfo().setRxOwnerCustomerAccountId("");
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);

        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        Thread.sleep(5000);
        String cid = request.getCustomerAccountId();
        res = competitiveTransferWrapper.getCTOrdersSummaryHIPAA(cid);
        GetCTOrdersSummaryNonHIPAAResponse orderSummaryRes = res.getDataResponse(GetCTOrdersSummaryNonHIPAAResponse.class);
        Set<String> orderIds = orderSummaryRes.getOrders().stream().map(Order::getOrderId).collect(Collectors.toSet());
        Assert.assertTrue(orderIds.contains(orderId));
    }

}
