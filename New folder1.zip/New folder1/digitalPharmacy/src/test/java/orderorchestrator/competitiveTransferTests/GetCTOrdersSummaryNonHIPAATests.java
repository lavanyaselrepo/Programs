package orderorchestrator.competitiveTransferTests;

import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import org.testng.annotations.Test;

public class GetCTOrdersSummaryNonHIPAATests {
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();

    @Test(description = "CTOrder Summary verification for invalid CId")
    public void verifyCTOrderSummaryForInvalidCid() {
        ServiceResponse resp = competitiveTransferWrapper.getCTOrdersSummaryNonHIPAA("5aaa10f9-3250-aaaa-aaa123-9e25a8c4dc0f");
        AssertUtil.assertEquals(resp.getStatusCode(), 204);
        AssertUtil.assertNull(resp.getDataResponse(), "Response data should be empty");
    }

    @Test(description = "CTOrder summary verification for CId which is not belongs to OrderId")
    public void verifyCTOrderSummaryWithEmptyHeaders() {
        ServiceResponse resp = competitiveTransferWrapper.getCTOrdersSummaryNonHIPAAWithoutHeaders("de8ab7a3-3111111-4e4d-9453-8ac2c77c8e0d");
        AssertUtil.assertEquals(resp.getStatusCode(), 400);
        String errorDescription = "Mandatory routing headers must be present: WM_CONSUMER.ID, WM_SVC.NAME, WM_SVC.ENV";
        AssertUtil.assertEquals(resp.getDataResponse(), errorDescription);
    }

}
