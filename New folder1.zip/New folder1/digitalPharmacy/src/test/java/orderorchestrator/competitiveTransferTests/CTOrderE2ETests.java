package orderorchestrator.competitiveTransferTests;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.Order;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.Phone;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.GetCTOrderDetailsNonHIPAAResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTBuyerInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTCommonData;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.constants.CTTestInputInfo;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CTOrderE2ETests {
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();
    Map<String, CTTestInputInfo> ctOrders = new HashMap<>();
    CTBuyerInfo buyerInfo;
    String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/competitiveTransfersData.json";

    @BeforeClass(alwaysRun = true)
    public void dataSetup() {
        buyerInfo = competitiveTransferWrapper.createDotcomAccount("07071988");
    }

    @Test(description = "Submit CT order verification for self without insurance and non-connected user")
    public void submitCTOrder_WithoutInsurance_Self_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }


    @Test(description = "CT Order details verification for self without insurance and non-connected user", dependsOnMethods = "submitCTOrder_WithoutInsurance_Self_NonConnectedUser")
    public void verifyOrderDetails_WithoutInsurance_Self_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("submitCTOrder_WithoutInsurance_Self_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list  for self without insurance and non-connected user", dependsOnMethods = "submitCTOrder_WithoutInsurance_Self_NonConnectedUser")
    public void verifyOrdersSummary_WithoutInsurance_Self_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("submitCTOrder_WithoutInsurance_Self_NonConnectedUser"));
    }

    @Test(description = "Submit CT order verification for self with insurance and non-connected user")
    public void CTOrder_WithInsurance_Self_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for self with insurance and non-connected user", dependsOnMethods = "CTOrder_WithInsurance_Self_NonConnectedUser")
    public void verifyOrderDetails_WithInsurance_Self_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_WithInsurance_Self_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for self with insurance and non-connected user", dependsOnMethods = "CTOrder_WithInsurance_Self_NonConnectedUser")
    public void verifyOrdersSummary_WithInsurance_Self_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_WithInsurance_Self_NonConnectedUser"));
    }

    @Test(description = "Submit CT order verification for Multi RX & self with insurance and non-connected user")
    public void CTOrder_Self_MultiRx_WithInsurance_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for Multi RX & self with insurance and non-connected user", dependsOnMethods = "CTOrder_Self_MultiRx_WithInsurance_NonConnectedUser")
    public void verifyOrderDetails_Self_MultiRx_WithInsurance_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_Self_MultiRx_WithInsurance_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for Multi RX & self with insurance and non-connected user", dependsOnMethods = "CTOrder_Self_MultiRx_WithInsurance_NonConnectedUser")
    public void verifyOrdersSummary_Self_MultiRx_WithInsurance_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_Self_MultiRx_WithInsurance_NonConnectedUser"));
    }


    @Test(description = "Submit CT order verification for Others with insurance and non-connected user")
    public void CTOrder_Others_WithInsurance_RelationOTHERS_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for Others with insurance and non-connected user", dependsOnMethods = "CTOrder_Others_WithInsurance_RelationOTHERS_NonConnectedUser")
    public void verifyOrderDetails_Others_WithInsurance_RelationOTHERS_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_Others_WithInsurance_RelationOTHERS_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for Others with insurance and non-connected user", dependsOnMethods = "CTOrder_Others_WithInsurance_RelationOTHERS_NonConnectedUser")
    public void verifyOrdersSummary_Others_WithInsurance_RelationOTHERS_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_Others_WithInsurance_RelationOTHERS_NonConnectedUser"));
    }


    @Test(description = "Submit CT order verification for Others without insurance and non-connected user")
    public void CTOrder_Others_WithOutInsurance_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for Others without insurance and non-connected user", dependsOnMethods = "CTOrder_Others_WithOutInsurance_NonConnectedUser")
    public void verifyOrderDetails_CTOrder_Others_WithOutInsurance_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_Others_WithOutInsurance_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for Others without insurance and non-connected user", dependsOnMethods = "CTOrder_Others_WithOutInsurance_NonConnectedUser")
    public void verifyOrdersSummary_CTOrder_Others_WithOutInsurance_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_Others_WithOutInsurance_NonConnectedUser"));
    }

    @Test(description = "Submit CT order verification for Child with insurance and non-connected user")
    public void CTOrder_Minor_WithInsurance_RelationChild_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for Child with insurance and non-connected user", dependsOnMethods = "CTOrder_Minor_WithInsurance_RelationChild_NonConnectedUser")
    public void verifyOrderDetails_Minor_WithInsurance_RelationChild_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_Minor_WithInsurance_RelationChild_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for Child with insurance and non-connected user", dependsOnMethods = "CTOrder_Minor_WithInsurance_RelationChild_NonConnectedUser")
    public void verifyOrdersSummary_Minor_WithInsurance_RelationChild_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_Minor_WithInsurance_RelationChild_NonConnectedUser"));
    }

    @Test(description = "Submit CT order verification for Spouse with insurance and non-connected user")
    public void CTOrder_Adult_WithInsurance_RelationSpouse_NonConnectedUser(Method method) {
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, null);
    }

    @Test(description = "CT Order details verification for Spouse with insurance and non-connected user", dependsOnMethods = "CTOrder_Adult_WithInsurance_RelationSpouse_NonConnectedUser")
    public void verifyOrderDetailsCTOrder_WithInsurance_RelationSpouse_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderDetailsNonHIPAA(ctOrders.get("CTOrder_Adult_WithInsurance_RelationSpouse_NonConnectedUser"));
    }

    @Test(description = "CT Order details verification in Order summary list for Spouse with insurance and non-connected user", dependsOnMethods = "CTOrder_Adult_WithInsurance_RelationSpouse_NonConnectedUser")
    public void verifyOrdersSummaryCTOrder_WithInsurance_RelationSpouse_NonConnectedUser() {
        competitiveTransferWrapper.verifyCTOrderSummaryNonHIPAA(ctOrders.get("CTOrder_Adult_WithInsurance_RelationSpouse_NonConnectedUser"));
    }

    @Test(description = "Submit CT order verification for valid RX owner id and connected user")
    public void CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser(Method method) {

        CTBuyerInfo buyerInfo = new CTBuyerInfo();
        buyerInfo.setBuyerCid("b345c2a0-3b3c-4598-b62c-b448ac1694a7");
        buyerInfo.setBuyerFN("SCARLETT");
        buyerInfo.setBuyerLN("ESTEVEZ");
        buyerInfo.setBuyerEmailId("11111@gmail.com");
        buyerInfo.setBuyerPhone("631-456-8907");
        CTTestInputInfo inputData = CTTestInputInfo.inputInfo(jsonPath, method.getName(), buyerInfo.getBuyerCid(), buyerInfo);
        inputData.setStoreNumber(5597);
        AutomationManager.getInstance().performSleep(7);
        ctOrders = competitiveTransferWrapper.submitCTOrderRequest(jsonPath, ctOrders, method.getName(), buyerInfo, buyerInfo.getBuyerCid());
        inputData = ctOrders.get(method.getName());
        CTCommonData.CommonData commonData = inputData.getCommonData();
        // Set order data to commonData as per the provided ord
        commonData.setTransferType("INDIVIDUAL");
        commonData.setPatAddressLineOne("241 kenmore ave");
        commonData.setPatAddressLineTwo("FL 1");
        commonData.setPatCity("Buffalo");
        commonData.setPatZipCode("14223");
        commonData.setPatStateCode("NY");
        commonData.setPatCountryCode("US");
        inputData.setHasPatientInfo(true);
        inputData.getPatientInfo().setFirstName("SCARLETT");
        inputData.getPatientInfo().setLastName("ESTEVEZ");
        inputData.getPatientInfo().setDob("03131989");
        inputData.setHasPatientInfo(true);
        inputData.getPatientInfo().setPhone(new Phone("1111111111"));
        ctOrders.put(method.getName(), inputData);
    }

    @Test(description = "CT Order details verification for for valid RX owner id and connected user", dependsOnMethods = "CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser")
    public void verifyOrderDetailsCTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser() {
        CTTestInputInfo inputData = ctOrders.get("CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser");
        Assert.assertNotNull(ctOrders.get("CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser").getOrderId(), "Order Id is incorrect to validate CTOrderDetails.");
        GetCTOrderDetailsNonHIPAAResponse getCTOrderDetailsNonHIPAAResponse
                = competitiveTransferWrapper.getCTOrderDetailsNonHIPAA(inputData.getBuyerInfo().getBuyerCid(), inputData.getOrderId(), 200);
        Order.verifyOrderDetailsInfo(getCTOrderDetailsNonHIPAAResponse.getOrder(), inputData);
    }

    @Test(description = "CT Order details verification in Order summary list for valid RX owner id and connected user", dependsOnMethods = "CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser")
    public void verifyOrdersSummaryCTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser() {
        CTTestInputInfo inputData = ctOrders.get("CTOrder_PatientInfoNull_RxOwnerValidCustId_ConnectedUser");
        Assert.assertNotNull(inputData.getOrderId(), "Order Id is incorrect to validate CTOrderDetails.");
        List<Order> ordersResp = competitiveTransferWrapper.getCTOrdersSummaryNonHIPAA(inputData.getBuyerInfo().getBuyerCid(), 200).getOrders();
        Order.verifyOrderDetailsInfoInOrdersSummary(ordersResp, inputData);
    }

}