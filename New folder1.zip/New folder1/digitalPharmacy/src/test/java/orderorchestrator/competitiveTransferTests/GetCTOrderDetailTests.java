package orderorchestrator.competitiveTransferTests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.Prescription;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.request.competitiveTransfer.SubmitCTOrderRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.GetCTOrderDetailsNonHIPAAResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.competitiveTransfer.SubmitCTOrderResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.tdc.CustomerOrderWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.response.tdc.CustomerOrderWrapper.*;

public class GetCTOrderDetailTests {

    ObjectMapper objectMapper = new ObjectMapper();
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();

    @Test(description = "Get CT order detail non hipaa successful response")
    public void getCTOrderDetailNonHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestNonConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);
        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        res = competitiveTransferWrapper.getCTOrderDetailsNonHIPAA(orderId, request.getCustomerAccountId());
        Assert.assertEquals(res.getStatusCode(), 200);
        GetCTOrderDetailsNonHIPAAResponse orderDetailResponse = res.getDataResponse(GetCTOrderDetailsNonHIPAAResponse.class);
        Assert.assertNotNull(orderDetailResponse);
    }

    private void validateAgainstTdcResponse(String orderId, GetCTOrderDetailsNonHIPAAResponse orderDetailResponse) throws Exception {
        ServiceResponse res = competitiveTransferWrapper.getTDCOrderByOnlineId(orderId, orderDetailResponse.getOrder().getTransferInfo().getToPharmacy().getStoreNbr().toString());
        Assert.assertEquals(res.getStatusCode(), 200);

        JsonNode orderNode = objectMapper.readTree(res.getDataResponse()).at("/data/byOnlineOrderV2");
        if (!(orderNode instanceof MissingNode)) {
            CustomerOrderWrapper[] resp = objectMapper.treeToValue(orderNode, CustomerOrderWrapper[].class);
            List<CustomerOrder> orders = Arrays.stream(resp).map(CustomerOrderWrapper::getCustomerOrder).filter(ord -> ord != null).collect(Collectors.toList());
            Map<Integer, OrderDetail> orderDetailMap = orders.stream().map(CustomerOrder::getOrderDtl).flatMap(Collection::stream).filter(orderDetail -> orderDetail.getOrderSeqNbr() != null).collect(Collectors.toMap(OrderDetail::getOrderSeqNbr, orderDetail -> orderDetail));
            for(Prescription prescription: orderDetailResponse.getOrder().getPrescriptionList()) {
                if(orderDetailMap.containsKey(prescription.getSeqNumber())) {
                    OrderDetail orderDetail = orderDetailMap.get(prescription.getSeqNumber());
                    String shortName = orderDetail.getOrderRx().getDrugProduct().getShortName();
                    if(shortName != null)
                        Assert.assertEquals(prescription.getDrugName(), shortName);
                    else {
                        EltncRxRespDrug drug = orderDetail.getRawElecRxResponse().getEltncRxRespDrug().get(0);
                        Assert.assertEquals(prescription.getDrugName(), drug.getDrugDesc());
                    }

                    if(orderDetail.getOrderRx().getRxNbr() != null)
                        Assert.assertEquals(prescription.getRxNumber(), orderDetail.getOrderRx().getRxNbr().toString());
                }
            }
        }
    }


    @Test(description = "Get CT order detail for self hipaa successful response")
    public void getCTOrderDetailForSelfHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);
        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        res = competitiveTransferWrapper.getCTOrderDetailsHipaa(orderId, request.getCustomerAccountId());
        Assert.assertEquals(res.getStatusCode(), 200);
        GetCTOrderDetailsNonHIPAAResponse orderDetailResponse = res.getDataResponse(GetCTOrderDetailsNonHIPAAResponse.class);
        Assert.assertNotNull(orderDetailResponse);

        Thread.sleep(10000);
        validateAgainstTdcResponse(orderId, orderDetailResponse);
    }

    @Test(description = "Get CT order detail for dependent hipaa successful response")
    public void getCTOrderDetailForDependentHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForDependent.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);

        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        res = competitiveTransferWrapper.getCTOrderDetailsHipaa(orderId, request.getCustomerAccountId());
        Assert.assertEquals(res.getStatusCode(), 200);
        GetCTOrderDetailsNonHIPAAResponse orderDetailResponse = res.getDataResponse(GetCTOrderDetailsNonHIPAAResponse.class);
        Assert.assertNotNull(orderDetailResponse);

        Thread.sleep(10000);
        validateAgainstTdcResponse(orderId, orderDetailResponse);
    }

    @Test(description = "Get CT order detail for other hipaa successful response")
    public void getCTOrderDetailForOtherHipaaSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        request.setRequestedFor("OTHERS");
        request.getPatientInfo().setFirstName("TEST");
        request.getPatientInfo().setLastName("XYZ");
        request.getPatientInfo().setRxOwnerCustomerAccountId("");
        ServiceResponse res = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(res.getStatusCode(), 201);

        SubmitCTOrderResponse response = res.getDataResponse(SubmitCTOrderResponse.class);
        String orderId = response.getOrderId();
        Assert.assertNotNull(orderId);

        res = competitiveTransferWrapper.getCTOrderDetailsHipaa(orderId, request.getCustomerAccountId());
        Assert.assertEquals(res.getStatusCode(), 200);
        GetCTOrderDetailsNonHIPAAResponse orderDetailResponse = res.getDataResponse(GetCTOrderDetailsNonHIPAAResponse.class);
        Assert.assertNotNull(orderDetailResponse);
    }
}
