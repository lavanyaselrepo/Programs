package orderorchestrator.competitiveTransferTests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.request.competitiveTransfer.SubmitCTOrderRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.CompetitiveTransferWrapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;

public class SubmitCTOrderTests {
    ObjectMapper objectMapper = new ObjectMapper();
    CompetitiveTransferWrapper competitiveTransferWrapper = new CompetitiveTransferWrapper();

    @Test(description = "Submit CT order with invalid relations validation failure")
    public void submitCTOrderWithInvalidRelationsValidationFailure() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestNonConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        request.getPatientInfo().setRxOwnerCustomerAccountId("not_matching");
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 400);
    }

    @Test(description = "Submit CT order with missing insurance validation failure")
    public void submitCTOrderWithMissingInsuranceValidationFailure() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestNonConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        request.getPatientInfo().getInsuranceInfo().setCardHolderId(null);
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 400);
    }

    @Test(description = "Submit CT order with non-connected for self successful response")
    public void submitCTOrderWithNonConnectedForSelfSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestNonConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 201);
    }

    @Test(description = "Submit CT order with connected for self successful response")
    public void submitCTOrderWithConnectedForSelfSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 201);
    }

    @Test(description = "Submit CT order with connected for dependent successful response")
    public void submitCTOrderWithConnectedForDependentSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForDependent.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 201);
    }

    @Test(description = "Submit CT order with connected for other successful response")
    public void submitCTOrderWithConnectedForOtherSuccessfulResponse() throws Exception {
        String jsonPath = "src/test/resources/testdata/digitalpharmacy/orderorchestrator/submitCTOrderRequestConnectedForSelf.json";
        SubmitCTOrderRequest request = objectMapper.readValue(new File(jsonPath), SubmitCTOrderRequest.class);
        request.setRequestedFor("OTHERS");
        request.getPatientInfo().setFirstName("TEST");
        request.getPatientInfo().setLastName("XYZ");
        request.getPatientInfo().setRxOwnerCustomerAccountId("");
        ServiceResponse response = competitiveTransferWrapper.submitCTOrderRequest(request);
        Assert.assertEquals(response.getStatusCode(), 201);
    }

}
