package orderorchestrator.refill;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.walmart.hwqe.commons.mqcontext.KafkaConsumer;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.refill.dm.DmKafkaPayloadTemplate;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.refill.dm.RefillConfirmationEmailKafkaPayload;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DateTimeUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Properties;

public class SendRefillEmailsTest {

    private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
    private  ObjectMapper objectMapper;
    private final PropertyReader propertyReader = PropertyReader.getInstance();
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private final int DESTINATION_STORE = 32517;
    private final String BUYER_CID = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";
    private final String PATIENT_CID = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";
    private final long INPROCESS_RXNBR = 1L;
    private final int INPROCESS_STORE_NBR = 32517;
    private final String INPROCESS_DRUGNAME = "test-inprocess-drug-name";
    private final Double INPROCESS_PATIENT_DUE_AMT = 1.0;
    private final long PENDING_RXNBR = 2L;
    private final int PENDING_STORE_NBR = 5597;
    private final String PENDING_DRUGNAME = "test-pending-drug-name";
    private final Double PENDING_PATIENT_DUE_AMT = 2.0;
    private final PendingRx.PendingReasonEnum PENDING_REASON = PendingRx.PendingReasonEnum.OUTOFREFILLS;


    @BeforeClass
    void setContext() throws IOException {
        orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    @Test(description = "sendRefillEmails api success")
    public void sendRefillEmailsTest1() throws IOException{

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ZonedDateTime inprocessPickupTimeZdt = ZonedDateTime.now(ZoneId.of("UTC")).plusHours(2);
        String inprocessPickupTime = DateTimeUtil.convertZonedDatetTimeToString(inprocessPickupTimeZdt, "yyyy-MM-dd'T'HH:mm:ssZ");

        SendRefillConfirmationEmailRequest sendRefillConfirmationEmailRequest = new SendRefillConfirmationEmailRequest().destinationStore(DESTINATION_STORE).buyerInfo(new BuyerInfoForRefillEmailsFlow().customerAccountId(BUYER_CID)).addPatientsInfoItem(new PatientInfoForRefillEmailsFlow().customerAccountId(PATIENT_CID).rxInfo(new RxInfoForRefillEmailsFlow().addInprocessItem(new InprocessRx().rxNbr(INPROCESS_RXNBR).storeNbr(INPROCESS_STORE_NBR).drugName(INPROCESS_DRUGNAME).patientDueAmt(INPROCESS_PATIENT_DUE_AMT).pickupDateTime(inprocessPickupTime)).addPendingItem(new PendingRx().rxNbr(PENDING_RXNBR).storeNbr(PENDING_STORE_NBR).drugName(PENDING_DRUGNAME).patientDueAmt(PENDING_PATIENT_DUE_AMT).pendingReason(PENDING_REASON))));

        Response<Void> response = orderOrchestratorRetrofit.sendRefillConfirmationEmails(BUYER_CID, sendRefillConfirmationEmailRequest, reqId, reqTrackingId);

        Assert.assertEquals(response.code(),200, "Response code not as expected");

        Properties kafkaConsumerProps = new Properties();
        kafkaConsumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, propertyReader.getProperty("dp.order.orchestrator.kafka.servers"));
        kafkaConsumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        kafkaConsumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        kafkaConsumerProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "ssl");

        kafkaConsumerProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, System.getProperty("order.orch.kafka.keystore.jks"));
        kafkaConsumerProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, System.getProperty("order.orch.kafka.keystore.password"));

        kafkaConsumerProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, System.getProperty("order.orch.kafka.truststore.jks"));
        kafkaConsumerProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, System.getProperty("order.orch.kafka.truststore.password"));
        kafkaConsumerProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        kafkaConsumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        kafkaConsumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, propertyReader.getProperty("dp.order.orchestrator.kafka.consumer.group"));

        KafkaConsumer kafkaConsumer = new KafkaConsumer(kafkaConsumerProps);

        List<String> messages =  kafkaConsumer.readMessages(propertyReader.getProperty("dp.order.orchestrator.kafka.refill.emails.topic"), 10);

        DmKafkaPayloadTemplate<RefillConfirmationEmailKafkaPayload> dmKafkaPayloadTemplate = objectMapper.readValue(messages.get(0), new TypeReference<DmKafkaPayloadTemplate<RefillConfirmationEmailKafkaPayload>>(){});

        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getStoreNbr(), DESTINATION_STORE, "destination store in kafka payload not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getBuyerInfo().getCustomerAccountId(), BUYER_CID, "buyerCid not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().size(), 1, "patientInfos size not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getCustomerAccountId(), PATIENT_CID, "patientCid not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getInprocessRxs().get(0).getDrugName(), INPROCESS_DRUGNAME, "inProcessDrugName not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getInprocessRxs().get(0).getStoreNbr(), INPROCESS_STORE_NBR, "inProcessStoreNbr not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getInprocessRxs().get(0).getPatientDueAmount(), INPROCESS_PATIENT_DUE_AMT, "inProcessPatientDueAmt not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getInprocessRxs().get(0).getRxNbr(), INPROCESS_RXNBR, "inProcessRxNbr not as expected");

        Assert.assertEquals(DateTimeUtil.convertZonedDatetTimeToString(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getInprocessRxs().get(0).getPickupDateTime(), "yyyy-MM-dd'T'HH:mm:ssZ"), inprocessPickupTime, "inProcessPickupTime not as expected");

        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getPendingRxs().get(0).getDrugName(), PENDING_DRUGNAME, "pendingDrugName not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getPendingRxs().get(0).getRxNbr(), PENDING_RXNBR, "pendingRxNbr not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getPendingRxs().get(0).getStoreNbr(), PENDING_STORE_NBR, "pendingStoreNbr not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getPendingRxs().get(0).getPatientDueAmount(), PENDING_PATIENT_DUE_AMT, "pendingPatientDueAmt not as expected");
        Assert.assertEquals(dmKafkaPayloadTemplate.getPayload().getPatientInfos().get(0).getRxInfo().getPendingRxs().get(0).getPendingReason().getValue(), PENDING_REASON.getValue(), "pendingReason not as expected");


    }

    @Test(description = "sendRefillEmails api - bad request")
    public void sendRefillEmailsTest2() throws IOException{

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        ZonedDateTime inprocessPickupTimeZdt = ZonedDateTime.now(ZoneId.of("UTC")).plusHours(2);
        String inprocessPickupTime = DateTimeUtil.convertZonedDatetTimeToString(inprocessPickupTimeZdt, "yyyy-MM-dd'T'HH:mm:ssZ");

        SendRefillConfirmationEmailRequest sendRefillConfirmationEmailRequest = new SendRefillConfirmationEmailRequest().destinationStore(DESTINATION_STORE).buyerInfo(new BuyerInfoForRefillEmailsFlow().customerAccountId(BUYER_CID)).addPatientsInfoItem(new PatientInfoForRefillEmailsFlow().customerAccountId(PATIENT_CID).rxInfo(new RxInfoForRefillEmailsFlow().addInprocessItem(new InprocessRx().rxNbr(null).storeNbr(INPROCESS_STORE_NBR).drugName(INPROCESS_DRUGNAME).patientDueAmt(INPROCESS_PATIENT_DUE_AMT).pickupDateTime(inprocessPickupTime)).addPendingItem(new PendingRx().rxNbr(PENDING_RXNBR).storeNbr(PENDING_STORE_NBR).drugName(PENDING_DRUGNAME).patientDueAmt(PENDING_PATIENT_DUE_AMT).pendingReason(PENDING_REASON))));

        Response<Void> response = orderOrchestratorRetrofit.sendRefillConfirmationEmails(BUYER_CID, sendRefillConfirmationEmailRequest, reqId, reqTrackingId);

        Assert.assertEquals(response.code(),400, "Response code not as expected");

    }

}
