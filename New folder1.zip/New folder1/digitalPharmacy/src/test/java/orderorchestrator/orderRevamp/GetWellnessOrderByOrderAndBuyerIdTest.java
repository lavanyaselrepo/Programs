package orderorchestrator.orderRevamp;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.WellnessCustomerOrder;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;


public class GetWellnessOrderByOrderAndBuyerIdTest {
  private ObjectMapper objectMapper ;
  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;

  private AutomationManager automationManager;
  private CosmosContext cosmosDbContext;
  private PropertyReader propertyReader;
  private String ORDER_ID = "W009449b01817f5467fb8b6be3ccf722556";
  private String ORDER_ID_1 = "W00e02d5026de644f759dcff44883f98566";

  private String ORDER_ID_2 = "W00ca627a9285c44a3abaaa007a98ad0d7a";
  private String BUYER_ID = "5c5b6897-b853-43d8-8473-aac3f2fb3838";

  private String BUYER_ID_1 = "58e62c3c-aff7-4879-ab0b-d115edb35b99";


  @BeforeClass
  void setContext() {
    propertyReader = PropertyReader.getInstance();
    automationManager = AutomationManager.getInstance();
    cosmosDbContext = automationManager.getDpOrderCosmos();
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    propertyReader.getProperty("dpOrderCosmos.db_container");
    objectMapper = new ObjectMapper();
  }

  @Test(priority = 0, description = "Get wellness order by orderId and buyerId success")
  public void getWellnessOrderByOrderAndBuyerId() throws JsonParseException, JsonMappingException, IOException {
    String trackID = CommonUtil.randomUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    Response<WellnessCustomerOrder> response = orderOrchestratorRetrofit.getWellnessOrderByOrderAndBuyerId(BUYER_ID_1,ORDER_ID_2,"req-track-"+trackID,"req-id-"+trackID);
    Assert.assertEquals(response.code(),200);
    Assert.assertNotNull(response.body());
    Assert.assertEquals(ORDER_ID_2,response.body().getOrderNo());
    Assert.assertEquals(BUYER_ID_1,response.body().getCustomerAccountId());
    Assert.assertNotNull(response.body().getPrescriptionList().get(0).getFillId());
  }

  @Test(priority = 1, description = "Bad Request - Cancelled Order")
  public void getWellnessOrderByOrderAndBuyerId1() throws JsonParseException, JsonMappingException, IOException {
    String trackID = CommonUtil.randomUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    Response<WellnessCustomerOrder> response = orderOrchestratorRetrofit.getWellnessOrderByOrderAndBuyerId(BUYER_ID,ORDER_ID,"req-track-"+trackID,"req-id-"+trackID);
    Assert.assertEquals(response.code(),400);
  }

  @Test(priority = 2, description = "No order found Default response")
  public void getWellnessOrderByOrderAndBuyerId2() throws JsonParseException, JsonMappingException, IOException {
    String trackID = CommonUtil.randomUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    Response<WellnessCustomerOrder> response = orderOrchestratorRetrofit.getWellnessOrderByOrderAndBuyerId(BUYER_ID,ORDER_ID_1,"req-track-"+trackID,"req-id-"+trackID);
    Assert.assertEquals(response.code(),200);
    Assert.assertNotNull(response.body());
    Assert.assertEquals(ORDER_ID_1,response.body().getOrderNo());
    Assert.assertEquals(BUYER_ID,response.body().getCustomerAccountId());
    Assert.assertTrue(response.body().getPrescriptionList().isEmpty());
  }
}