package orderorchestrator.orderRevamp;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.WellnessCustomerOrdersResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DateTimeUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class GetWellnessOrderByBuyerIdTest {
  private ObjectMapper objectMapper ;
  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;

  private AutomationManager automationManager;
  private CosmosContext cosmosDbContext;
  private PropertyReader propertyReader;
  private String BUYER_ID = "58e62c3c-aff7-4879-ab0b-d115edb35b99";
  private String BUYER_ID_1 = "8bf76a73-eb2c-4f21-b3c2-e8ea19de7f77";

  private String toDate = DateTimeUtil.getToDate();
  private String fromDate = DateTimeUtil.getFromDate();

  @BeforeClass
  void setContext() {
    propertyReader = PropertyReader.getInstance();
    automationManager = AutomationManager.getInstance();
    cosmosDbContext = automationManager.getDpOrderCosmos();
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    propertyReader.getProperty("dpOrderCosmos.db_container");
    objectMapper = new ObjectMapper();
  }

  @Test(priority = 0, description = "Get wellness order by orderId success")
  public void getWellnessOrderByBuyerId() throws JsonParseException, JsonMappingException, IOException {
    Date tomorrow = new Date(new Date().getTime() + 86400000);
    String pickupDate = new SimpleDateFormat("MMddyyyy").format(tomorrow);
    String trackID = CommonUtil.randomUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    Response<WellnessCustomerOrdersResponse> response = orderOrchestratorRetrofit.getWellnessOrderByBuyerId(BUYER_ID,"req-track-"+trackID,"req-id-"+trackID,fromDate,toDate);
    Assert.assertEquals(response.code(),200);
    Assert.assertTrue(!response.body().getOrders().isEmpty());
    Assert.assertEquals(response.body().getOrders().get(0).getCustomerAccountId(),BUYER_ID);
  }


  @Test(priority = 1, description = "Get wellness order by orderId Default Response")
  public void getWellnessOrderByBuyerId1() throws JsonParseException, JsonMappingException, IOException {
    String trackID = CommonUtil.randomUUID();
    Reporter.logJSON("request tracking Id","req-track-"+trackID);
    Reporter.logJSON("request Id","req-id-"+trackID);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    Response<WellnessCustomerOrdersResponse> response = orderOrchestratorRetrofit.getWellnessOrderByBuyerId(BUYER_ID_1,"req-track-"+trackID,"req-id-"+trackID,fromDate,toDate);
    Assert.assertEquals(response.code(),200);
    Assert.assertTrue(response.body().getOrders().isEmpty());
  }
}