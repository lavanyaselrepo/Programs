package orderorchestrator.newrx;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.PlacedOrderLinkRequestV2;
import com.walmart.pharmacy.dp.order.entity.service.restclient.model.PlacedOrderRequestV2;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.restapi.OrderEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.utils.CreateOrderEntityHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.DeleteOrderHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.jupiter.api.Assertions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class OrderOrchestratorNewRxTests {

  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
  private OrderEntityServiceRetrofit orderEntityRetrofit;
  private final ObjectMapper objectMapper = new ObjectMapper();
  private CreateOrderEntityHelper createOrderEntityHelper;
  private PropertyReader propertyReader = PropertyReader.getInstance();
  private CosmosDocumentMapper documentMapper;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private String commonOrderId = "W00c57fa71ac4704733929168f429951793";
  private String commonBuyerId = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";
  public Long commonPatientId = 126279L;
  public static final long commonRxNbr = 8814677L;
  private Integer commonStoreId = 5597;
  private Integer commonFillId = 1243741;
  private PlacedOrderRequestV2 orderRequestV2;
  private PlacedOrderLinkRequestV2 orderLinkRequestV2;
  private Random random;
  private DeleteOrderHelper deleteOrderHelper;

  @BeforeClass
  void setContext() throws IOException {
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    orderEntityRetrofit = new OrderEntityServiceRetrofit(PropertyReader.getInstance());
    String containerName = PropertyReader.getInstance().getProperty("dpOrderCosmos.db_container");
    CosmosContext cosmosDbContext = AutomationManager.getInstance().getDpOrderCosmos();
    documentMapper = new CosmosDocumentMapper(cosmosDbContext, containerName);
    createOrderEntityHelper = new CreateOrderEntityHelper(documentMapper, orderEntityRetrofit);
    deleteOrderHelper = new DeleteOrderHelper(documentMapper);

    //Creating new order requests.
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    orderLinkRequestV2 = objectMapper
            .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createBuyerLink.json"),
                    PlacedOrderLinkRequestV2.class);

    orderRequestV2 = objectMapper
            .readValue(new File("src/test/resources/testdata/digitalpharmacy/orderentity/createorder/createOrder.json"),
                    PlacedOrderRequestV2.class);
    random = new Random();
  }


  @Test(
          priority = 2,
          description = "Get Order Details using OrderId And Patient Link")
  public void getOrderByOrderIdAndLinkV2() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("orderId", commonOrderId);
    Reporter.logJSON("buyerId", commonBuyerId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);

    // prepare Payload
    GetOrdersByLinkRequestV2 getOrdersByLinkRequestV2 = new GetOrdersByLinkRequestV2().orderLookupBy(Collections.singletonList(new OrderLookupByV2().orderId(commonOrderId).patientLink(new PatientLink().patientId(commonPatientId).storeId(commonStoreId))));
    // call Order Orchestrator
    Response<GetOrderEntityServiceSuccessResponseV2> orderByOrderIdAndLinkV2 = orderOrchestratorRetrofit.getOrderByOrderIdAndLinkV2(getOrdersByLinkRequestV2, reqId, reqTrackingId);
    // validate the response
    assert orderByOrderIdAndLinkV2.body() != null;
    GetOrderEntityServiceSuccessResponseV2 orderResponse = orderByOrderIdAndLinkV2.body();
    Assert.assertEquals(commonBuyerId, orderResponse.getOrders().get(0).getBuyer().getOnlineCustomerId());
    Assert.assertEquals(commonOrderId,orderResponse.getOrders().get(0).getOrderId());
    Assert.assertEquals(commonPatientId,orderResponse.getOrders().get(0).getPatient().getPatientLinks().get(0).getPatientId());
    Assert.assertEquals(commonStoreId,orderResponse.getOrders().get(0).getStoreId());
  }

  @Test(
          priority = 3,
          description = "Get Order Details using OrderId And BuyerId")
  public void getOrderByOrderIdAndBuyerIdV2() throws IOException {

    // Step - 1: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("orderId", commonOrderId);
    Reporter.logJSON("buyerId", commonBuyerId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);

    // call Order Orchestrator
    Response<DpOrderV2> orderByOrderIdAndBuyerIdV2 = orderOrchestratorRetrofit.getOrderByOrderIdAndBuyerIdV2(commonOrderId, commonBuyerId, reqId, reqTrackingId);
    // validate the response
    assert orderByOrderIdAndBuyerIdV2.body() != null;
    DpOrderV2 orderResponse = orderByOrderIdAndBuyerIdV2.body();
    Assert.assertEquals(commonBuyerId, orderResponse.getBuyer().getOnlineCustomerId());
    Assert.assertEquals(commonOrderId,orderResponse.getOrderId());
    Assert.assertEquals(commonPatientId,orderResponse.getPatient().getPatientLinks().get(0).getPatientId());
    Assert.assertEquals(commonStoreId,orderResponse.getStoreId());
  }

  @Test(
          priority = 5,
          description = "Updating/Appending fills to the existing fills Success")
  public void appendFillsTest() throws IOException {

    // Step - 1: Create order
    createOrderEntityHelper.createOrderAndBuyerLink(orderLinkRequestV2, orderRequestV2);
    final String ORDER_ID = orderRequestV2.getOrderId();
    final PatientLink patientLink = mapToPatientLink(orderRequestV2.getPatient().getPatientLinks().get(0));
    final String orderDocPartitonKey = patientLink.getStoreId() + "-" + patientLink.getPatientId();

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("orderId", commonOrderId);
    Reporter.logJSON("buyerId", commonBuyerId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);

    String prescriberFirstName = RandomStringUtils.randomAlphabetic(5);
    String prescriberLastName = RandomStringUtils.randomAlphabetic(5);
    Integer fillId = random.nextInt(1000000) + 100000;
    Long rxNbr = (long) (random.nextInt(1000000) + 100000);

    List<FillV2> fills = new ArrayList<>();
    fills.add(new FillV2()
            .fillId(fillId)
            .rxNbr(rxNbr)
            .prescriber(new Prescriber()
                    .contactInformation(new ContactInformation()
                            .name(new Name()
                                    .firstName(prescriberFirstName)
                                    .lastName(prescriberLastName)))));

    AppendFillsRequest appendFillsRequest
            = new AppendFillsRequest()
            .fills(fills)
            .patientLink(patientLink);

    // Step - 3: Calling appendFills API with orderId, buyerId for NewRx Order Confirmation.
    Response<Void> appendFillsResponse = orderOrchestratorRetrofit.appendFills(ORDER_ID, appendFillsRequest, reqId, reqTrackingId);
    Assert.assertEquals(appendFillsResponse.code(),204, "Response code not as expected");

    // Step = 4: Assert that fill has been created
    JsonNode jsonNode = documentMapper.getOrder(ORDER_ID, orderDocPartitonKey);
    List<FillV2> actualFills = objectMapper.convertValue(jsonNode.get("fills"), new TypeReference<List<FillV2>>() {});
    FillV2 actualFill = actualFills.get(0);
    FillV2 expectedFill = appendFillsRequest.getFills().get(0);

    Assertions.assertEquals(actualFill.getFillId(), expectedFill.getFillId());
    Assertions.assertEquals(actualFill.getRxNbr(), expectedFill.getRxNbr());

    // Step = 5: Deleting the order.
    deleteOrderHelper.deleteOrder(ORDER_ID, orderDocPartitonKey);
    deleteOrderHelper.deleteOrderLink(ORDER_ID, orderLinkRequestV2.getBuyerOnlineCustomerId());
  }

  @Test(
          priority = 6,
          description = "Order does not exist")
  public void appendFillsTest2() throws IOException {

    final String ORDER_ID = RandomStringUtils.randomAlphanumeric(15);
    final PatientLink patientLink = mapToPatientLink(orderRequestV2.getPatient().getPatientLinks().get(0));

    // Step - 2: Setting and logging tracking ID's to make the respective calls
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("orderId", commonOrderId);
    Reporter.logJSON("buyerId", commonBuyerId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);

    String prescriberFirstName = RandomStringUtils.randomAlphabetic(5);
    String prescriberLastName = RandomStringUtils.randomAlphabetic(5);
    Integer fillId = random.nextInt(1000000) + 100000;
    Long rxNbr = (long) (random.nextInt(1000000) + 100000);

    List<FillV2> fills = new ArrayList<>();
    fills.add(new FillV2()
            .fillId(fillId)
            .rxNbr(rxNbr)
            .prescriber(new Prescriber()
                    .contactInformation(new ContactInformation()
                            .name(new Name()
                                    .firstName(prescriberFirstName)
                                    .lastName(prescriberLastName)))));

    AppendFillsRequest appendFillsRequest
            = new AppendFillsRequest()
            .fills(fills)
            .patientLink(patientLink);

    // Step - 3: Calling appendFills API with orderId, buyerId for NewRx Order Confirmation.
    Response<Void> appendFillsResponse = orderOrchestratorRetrofit.appendFills(ORDER_ID, appendFillsRequest, reqId, reqTrackingId);
    Assert.assertEquals(appendFillsResponse.code(),400, "Response code not as expected");
    FailureResponse failureResponse
            = objectMapper.readValue(new String(appendFillsResponse.errorBody().bytes()), FailureResponse.class);
    Assertions.assertEquals("2036", failureResponse.getErrorCode());

  }

  private PatientLink mapToPatientLink(com.walmart.pharmacy.dp.order.entity.service.restclient.model.PatientLink patientLink) {
    return new PatientLink().patientId(patientLink.getPatientId()).storeId(patientLink.getStoreId());
  }
}
