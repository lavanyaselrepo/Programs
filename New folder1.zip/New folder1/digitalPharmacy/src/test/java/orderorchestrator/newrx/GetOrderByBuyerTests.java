package orderorchestrator.newrx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.GetOrderEntityServiceSuccessResponseV2;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

/**
 * @author s0k08d0
 */
public class GetOrderByBuyerTests {

    private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
    private final ObjectMapper mapper = new ObjectMapper();
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";

    private String commonOrderId = "W00e29e3658e6e44d03844a4c37a52951b5";
    private String commonBuyerId = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";

    @BeforeClass
    void setContext() {
        orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
    }


    @Test(
            priority = 0,
            description = "Get order by buyer")
    public void getOrderByBuyerTest() throws IOException {
        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;
        Reporter.logJSON("orderId", commonOrderId);
        Reporter.logJSON("buyerId", commonBuyerId);
        Reporter.logJSON("request Id", reqId);
        Reporter.logJSON("request tracking Id", reqTrackingId);
        Response<GetOrderEntityServiceSuccessResponseV2> getOrderEntityServiceSuccessResponseV2=orderOrchestratorRetrofit.getOrderByBuyerV2(commonBuyerId,reqId,reqTrackingId);
        assert getOrderEntityServiceSuccessResponseV2.body() != null;
        assert getOrderEntityServiceSuccessResponseV2.isSuccessful();
    }

}
