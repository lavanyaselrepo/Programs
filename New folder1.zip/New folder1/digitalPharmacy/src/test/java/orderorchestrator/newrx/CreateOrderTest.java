package orderorchestrator.newrx;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.cosmos.datacontext.CosmosContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderentityservice.dao.CosmosDocumentMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.util.CreateOrderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.reporters.Files;

import java.io.File;
import java.io.IOException;

public class CreateOrderTest {

	private ObjectMapper objectMapper;
	private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
	private CosmosDocumentMapper cosmosDocumentMapper;
	private AutomationManager automationManager;
	private CosmosContext cosmosDbContext;
	private PropertyReader propertyReader;
	private CreateOrderHelper createOrderHelper;
	private String ORDER_ID = "W005a9921c42ede48b59cea83b91c4bd1f5";

	@BeforeClass
	void setContext() {
		propertyReader = PropertyReader.getInstance();
		automationManager = AutomationManager.getInstance();
		cosmosDbContext = automationManager.getDpOrderCosmos();
		orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
		cosmosDocumentMapper = new CosmosDocumentMapper(cosmosDbContext,
				propertyReader.getProperty("dpOrderCosmos.db_container"));
		objectMapper = new ObjectMapper();
		createOrderHelper = new CreateOrderHelper(cosmosDocumentMapper, orderOrchestratorRetrofit, objectMapper);
	}

	@Test(priority = 0, description = "Create Order Success")
	public void createOrderTest1() throws JsonParseException, JsonMappingException, IOException {

		createOrderHelper.createOrderV3(ORDER_ID, Files.readFile(
				new File("src/test/resources/testdata/digitalpharmacy/orderorchestrator/createorder/createOrderSuccess.json")));
	}

}
