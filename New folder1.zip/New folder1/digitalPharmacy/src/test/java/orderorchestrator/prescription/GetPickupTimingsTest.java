package orderorchestrator.prescription;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.serviceapi.locationServicesContext.restApi.LocationServiceOrchestratorWrapper;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.PickupTiming;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.PickupTimingsRequest;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.PickupTimingsResponse;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.PrescriptionForPickupTimingsApi;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.pickuptimings.bo.StoreInfoBO;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.pickuptimings.dto.StoresInfoDTO;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.mapper.LocationPlatformServiceOmninodeFormatGetStoresInfoMapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.service.PriorityRequestTimeCalculator;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.service.StandardDisplayTimeCalculator;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.service.StandardRequestTimeCalculator;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.service.impl.PriorityPickupTimingsHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.service.impl.StandardPickupTimingsHelper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class GetPickupTimingsTest {

    private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
    private ObjectMapper objectMapper;
    private LocationServiceOrchestratorWrapper locationServiceOrchestratorWrapper;
    private final String reqIdString = "req-id-";
    private final String reqTrackingString = "req-tracking-";
    private final String BUYER_ID1 = "BUYER1";
    private LocationPlatformServiceOmninodeFormatGetStoresInfoMapper locationPlatformServiceOmninodeFormatGetStoresInfoMapper;
    private StandardPickupTimingsHelper standardPickupTimingsHelper;
    private PriorityPickupTimingsHelper priorityPickupTimingsHelper;
    private StandardRequestTimeCalculator standardRequestTimeCalculator;
    private StandardDisplayTimeCalculator standardDisplayTimeCalculator;
    private PriorityRequestTimeCalculator priorityRequestTimeCalculator;

    @BeforeClass
    void setContext(){
        orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
        objectMapper = new ObjectMapper();
        objectMapper
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new JavaTimeModule());
        locationServiceOrchestratorWrapper = new LocationServiceOrchestratorWrapper();
        locationPlatformServiceOmninodeFormatGetStoresInfoMapper = new LocationPlatformServiceOmninodeFormatGetStoresInfoMapper();
        standardRequestTimeCalculator = new StandardRequestTimeCalculator();
        standardDisplayTimeCalculator = new StandardDisplayTimeCalculator();
        priorityRequestTimeCalculator = new PriorityRequestTimeCalculator();
        standardPickupTimingsHelper = new StandardPickupTimingsHelper(standardRequestTimeCalculator, standardDisplayTimeCalculator);
        priorityPickupTimingsHelper = new PriorityPickupTimingsHelper(priorityRequestTimeCalculator);
    }

    @Test(description = "Need it sooner eligible")
    public void getPickupTimingsTest1() throws IOException {

        ServiceResponse serviceResponse = locationServiceOrchestratorWrapper.getPharmacyStoreInfo("5597");

        StoresInfoDTO storesInfoDTO = objectMapper.readValue(serviceResponse.getDataResponse(), StoresInfoDTO.class);

        StoreInfoBO storeInfoBO = locationPlatformServiceOmninodeFormatGetStoresInfoMapper.handle(storesInfoDTO).getStoreInfoBOs().get(0);

        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.pickuptimings.dto.PickupTiming standardPickupTiming = standardPickupTimingsHelper.getPickupTimings(storeInfoBO).get();
        com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.pickuptimings.dto.PickupTiming priorityPickupTiming = priorityPickupTimingsHelper.getPickupTimings(storeInfoBO).get();

        LocalDate currentDate = LocalDate.now(ZoneId.of(storeInfoBO.getTimeZoneId()));
        DateTimeFormatter dateTimeFormatterMMddyyyy = DateTimeFormatter.ofPattern("MMddyyyy");

        DateTimeFormatter dateTimeFormatterHHmm = DateTimeFormatter.ofPattern("HH:mm");

        PickupTimingsRequest pickupTimingsRequest = new PickupTimingsRequest().pickupStoreNbr(5597).isCT(false)
                .addPrescriptionsItem(new PrescriptionForPickupTimingsApi().storeNbr(5597).rxNbr(1l).numOfRemainingRefills(2).expirationDate(currentDate.plusWeeks(2).format(dateTimeFormatterMMddyyyy)).lastRefillDate(currentDate.minusDays(2).format(dateTimeFormatterMMddyyyy)))
                .addPrescriptionsItem(new PrescriptionForPickupTimingsApi().storeNbr(5597).rxNbr(1l).numOfRemainingRefills(4).expirationDate(currentDate.plusWeeks(4).format(dateTimeFormatterMMddyyyy)).lastRefillDate(currentDate.minusDays(1).format(dateTimeFormatterMMddyyyy)));

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<PickupTimingsResponse> response = orderOrchestratorRetrofit.getPrescriptionsPickupTimings(BUYER_ID1, pickupTimingsRequest, reqId, reqTrackingId);

        PickupTimingsResponse pickupTimingsResponse = response.body();

        List<PickupTiming> pickupTimings = pickupTimingsResponse.getPickupTimings();

        PickupTiming standardPickupTimingInResponse = pickupTimings.stream().filter(pickupTiming -> pickupTiming.getPriority().equals(2))
                .findFirst()
                .get();

        PickupTiming priorityPickupTimingInResponse = pickupTimings.stream().filter(pickupTiming -> pickupTiming.getPriority().equals(1))
                .findFirst()
                .get();

        Assert.assertEquals(pickupTimingsResponse.getPickupTimings().size(), 2);
        Assert.assertEquals(pickupTimingsResponse.getPickupStoreNbr(), 5597);
        Assert.assertEquals(standardPickupTimingInResponse.getRequestDate(), standardPickupTiming.getRequestDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(standardPickupTimingInResponse.getRequestTime(), standardPickupTiming.getRequestTime().format(dateTimeFormatterHHmm));
        Assert.assertEquals(standardPickupTimingInResponse.getDisplayDate(), standardPickupTiming.getDisplayDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(standardPickupTimingInResponse.getDisplayTime(), standardPickupTiming.getDisplayTime().format(dateTimeFormatterHHmm));

        Assert.assertEquals(priorityPickupTimingInResponse.getRequestDate(), priorityPickupTiming.getRequestDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(priorityPickupTimingInResponse.getRequestTime(), priorityPickupTiming.getRequestTime().format(dateTimeFormatterHHmm));
        Assert.assertEquals(priorityPickupTimingInResponse.getDisplayDate(), priorityPickupTiming.getDisplayDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(priorityPickupTimingInResponse.getDisplayTime(), priorityPickupTiming.getDisplayTime().format(dateTimeFormatterHHmm));

    }

   @Test(description = "Need it sooner not eligible")
    public void getPickupTimingsTest2() throws IOException {

        ServiceResponse serviceResponse = locationServiceOrchestratorWrapper.getPharmacyStoreInfo("32517");

        StoresInfoDTO storesInfoDTO = objectMapper.readValue(serviceResponse.getDataResponse(), StoresInfoDTO.class);

        StoreInfoBO storeInfoBO = locationPlatformServiceOmninodeFormatGetStoresInfoMapper.handle(storesInfoDTO).getStoreInfoBOs().get(0);

       com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.datamodels.pojos.pickuptimings.dto.PickupTiming standardPickupTiming = standardPickupTimingsHelper.getPickupTimings(storeInfoBO).get();

        LocalDate currentDate = LocalDate.now(ZoneId.of(storeInfoBO.getTimeZoneId()));
        DateTimeFormatter dateTimeFormatterMMddyyyy = DateTimeFormatter.ofPattern("MMddyyyy");

        DateTimeFormatter dateTimeFormatterHHmm = DateTimeFormatter.ofPattern("HH:mm");

        PickupTimingsRequest pickupTimingsRequest = new PickupTimingsRequest().isCT(false)
                .addPrescriptionsItem(new PrescriptionForPickupTimingsApi().storeNbr(5597).rxNbr(1l).numOfRemainingRefills(2).expirationDate(currentDate.plusWeeks(2).format(dateTimeFormatterMMddyyyy)).lastRefillDate(currentDate.minusDays(2).format(dateTimeFormatterMMddyyyy)))
                .addPrescriptionsItem(new PrescriptionForPickupTimingsApi().storeNbr(32517).rxNbr(1l).numOfRemainingRefills(4).expirationDate(currentDate.plusWeeks(4).format(dateTimeFormatterMMddyyyy)).lastRefillDate(currentDate.minusDays(1).format(dateTimeFormatterMMddyyyy)));

        String trackID = CommonUtil.randomUUID();
        String reqId = reqIdString + trackID;
        String reqTrackingId = reqTrackingString + trackID;

        Response<PickupTimingsResponse> response = orderOrchestratorRetrofit.getPrescriptionsPickupTimings(BUYER_ID1, pickupTimingsRequest, reqId, reqTrackingId);

        PickupTimingsResponse pickupTimingsResponse = response.body();

        List<PickupTiming> pickupTimings = pickupTimingsResponse.getPickupTimings();

        PickupTiming standardPickupTimingInResponse = pickupTimings.stream().filter(pickupTiming -> pickupTiming.getPriority().equals(2))
                .findFirst()
                .get();

        Assert.assertEquals(pickupTimingsResponse.getPickupTimings().size(), 1);
        Assert.assertEquals(pickupTimingsResponse.getPickupStoreNbr(), 32517);
        Assert.assertEquals(standardPickupTimingInResponse.getRequestDate(), standardPickupTiming.getRequestDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(standardPickupTimingInResponse.getRequestTime(), standardPickupTiming.getRequestTime().format(dateTimeFormatterHHmm));
        Assert.assertEquals(standardPickupTimingInResponse.getDisplayDate(), standardPickupTiming.getDisplayDate().format(dateTimeFormatterMMddyyyy));
        Assert.assertEquals(standardPickupTimingInResponse.getDisplayTime(), standardPickupTiming.getDisplayTime().format(dateTimeFormatterHHmm));

    }
}
