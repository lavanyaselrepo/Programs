package orderorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.pharmacy.dp.order.orchestrator.service.restclient.model.GetOrderEntityServiceSuccessResponseV2;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.orderorchestrator.restapi.OrderOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;

public class GetOrdersByBuyerV2Test {

  private OrderOrchestratorRetrofit orderOrchestratorRetrofit;
  private final ObjectMapper mapper = new ObjectMapper();
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";

  private String commonOrderId = "W00c57fa71ac4704733929168f429951793";
  private String commonBuyerId = "6ab77aa5-5709-4aee-ac00-d3cab6aa1687";
  public Long commonPatientId = 126279L;
  public static final long commonRxNbr = 8814677L;
  private Integer commonStoreId = 5597;
  private Integer commonFillId = 1243741;

  @BeforeClass
  void setContext() {
    orderOrchestratorRetrofit = new OrderOrchestratorRetrofit();
  }


  @Test(
          priority = 0,
          description = "Get Orders using Buyer Id - Expect empty response")
  public void getOrdersByBuyerV2Success1() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    Reporter.logJSON("orderId", commonOrderId);
    Reporter.logJSON("buyerId", commonBuyerId);
    Reporter.logJSON("request Id", reqId);
    Reporter.logJSON("request tracking Id", reqTrackingId);

    String randomBuyerId = "6ab77aa5-5709-4aee-ac00-d3cab6aa1";
    Response<GetOrderEntityServiceSuccessResponseV2> getOrderEntityServiceSuccessResponseV2Response = orderOrchestratorRetrofit.getOrdersByBuyerV2(randomBuyerId,reqId, reqTrackingId);
    Assert.assertEquals(getOrderEntityServiceSuccessResponseV2Response.code(),200);
    assert getOrderEntityServiceSuccessResponseV2Response.body() != null;
    Assert.assertTrue(getOrderEntityServiceSuccessResponseV2Response.body().getOrders().isEmpty());
  }
}
