package consentorchestrator;


import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getAdultEcom.GetAdultEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getConsentRequest.GetConsentRequestResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getEcomResponse.GetEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.sendAdultEcommConsent.SendAdultEcommConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.CustomerConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

public class getAndSendAdultEcommConsentRequestTests {
    GetandSaveEcomWrapper consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();
    ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    CustomerConsentWrapper customerConsentWrapper = new CustomerConsentWrapper();

    @Test(description = "validate get and send Adult Ecomm consent request api for Adult dependent with multiple Caregiver", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void getAndSendAdultEcommRequest_MultipleCaregiver(String caregiver1DOB, String caregiver2DOB, String adultDependentDOB, int statusCode, String storeNo) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiver1Email = CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        String caregiver2Email = CommonUtil.generateRandomEmailId(10);
        String caregiver2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiver1Details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
        String caregiver_cid1 = caregiver1Details.get(0);
        Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

        List<String> caregiver2Details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiver2Email, caregiver2FirstName, caregiver2LastName, caregiver2DOB, storeNo);
        String caregiver_cid2 = caregiver2Details.get(0);
        Reporter.logJSON("Caregiver2 Customer Account Id", caregiver_cid2);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid1, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid2, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);


        //Step 2 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult Dependent
        ServiceResponse serRes = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid1);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse = serRes.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid2);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse1 = serRes1.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes1.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse1.getPayload().getStatus());

        //Step 8 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcommMultiCaregiver(adultDependent_cid);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);
        int requestList = getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().size();
        Assert.assertEquals(2, requestList);
        for (int i = 0; i < requestList; i++) {
            if (getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equals(caregiver_cid1)) {
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getFirstName(), caregiver1FirstName);
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getLastName(), caregiver1LastName);
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(), caregiver1Email);
            } else if (getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equals(caregiver_cid2)) {
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getFirstName(), caregiver2FirstName);
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getLastName(), caregiver2LastName);
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(), caregiver2Email);
            }
        }

    }

    @Test(description = "validate get and send Adult Ecomm consent request api for Adult dependent with no Request", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void getAndSendAdultEcommRequest_Norequest(String caregiver1DOB, String adultDependentDOB, int statusCode, String storeNo) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiver1Email = CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiver1Details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
        String caregiver_cid1 = caregiver1Details.get(0);
        Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid1, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);


        //Step 2 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcommMultiCaregiver(adultDependent_cid);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);


    }

    @Test(description = "validate get and send Adult Ecomm consent request api for null dependentId", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void getAndSendAdultEcommRequest_DependentIdNull(String payload, String errorCode, int statusCode) throws InterruptedException, IOException {

        //Step 1 : Get  Adult Dependent
        ServiceResponse serRes = consentEcomOrchestratorWrapper.validategetAdultEcommNegative(payload);
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(getNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate get and send Adult Ecomm consent request api for Adult dependent who is not a valid dependent of caregiver", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void getAndSendAdultEcommRequest_DependentNotLinkedtoCaregiver(String caregiver1DOB, String adultDependentDOB, int statusCode, String storeNo) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiver1Email = CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiver1Details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
        String caregiver_cid1 = caregiver1Details.get(0);
        Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);


        //Step 2 : Get  Adult Dependent
        ServiceResponse serRes = consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        //  GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
//        Assert.assertEquals(getNPPFormErrorResponse.getError().getCode(), errorCode);


    }

    @Test(description = "validate send Adult Ecomm consent request api for null dependentId", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void sendAdultEcommRequest_DependentIdNull(String payload, String errorCode, int statusCode) throws InterruptedException, IOException {

        //Step 1 : Send  Adult Dependent
        ServiceResponse serRes = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequestNegative(payload);
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(getNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(
            description = "Old Caregiver and New Dependents",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData",
            retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void checkOldCaregiverAndNewDependents(String caregiver1DOB,
                                  String caregiver2DOB,
                                  String adultDependentDOB,
                                  String adultDependentDOB1,
                                  String adultDependentDOB2,
                                  int statusCode,
                                  String storeNo, boolean adultConsentEnabled)

            throws InterruptedException, IOException {

        if(!adultConsentEnabled)    return;
        // Step - 1: Setting and logging fill ID's to make the respective calls
        // Emilia
        String caregiver1Email = "emila" + CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Xavier
        String caregiver2Email = "xavier" + CommonUtil.generateRandomEmailId(10);
        String caregiver2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Carlos
        String adultDependentEmail = "carlos" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // James
        String adultDependentEmail1 = "james" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName1 = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName1 = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Aman
        String adultDependentEmail2 = "aman" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName2 = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName2 = CommonUtil.generateRandomLastName(10).toUpperCase();


        List<String> caregiver1Details =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
        String caregiver_cid1 = caregiver1Details.get(0);
        Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);


        List<String> caregiver2Details =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        caregiver2Email, caregiver2FirstName, caregiver2LastName, caregiver2DOB, storeNo);
        String caregiver_cid2 = caregiver2Details.get(0);
        Reporter.logJSON("Caregiver2 Customer Account Id", caregiver_cid2);


        List<String> adultDependentDetails =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail,
                        adultDependentFirstName,
                        adultDependentLastName,
                        adultDependentDOB,
                        storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);
        System.out.println(adultDependent_cid);

        List<String> adultDependentDetails1 =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail1,
                        adultDependentFirstName1,
                        adultDependentLastName1,
                        adultDependentDOB1,
                        storeNo);
        String adultDependent_cid1 = adultDependentDetails1.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id1", adultDependent_cid1);
        System.out.println(adultDependent_cid1);

        List<String> adultDependentDetails2 =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail2,
                        adultDependentFirstName2,
                        adultDependentLastName2,
                        adultDependentDOB2,
                        storeNo);
        String adultDependent_cid2 = adultDependentDetails2.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id2", adultDependent_cid2);

        System.out.println(adultDependent_cid2);

        // Carlos added as dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid2,
                adultDependent_cid,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

//    // carlos ad Dependent to Emila
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid1,
                adultDependent_cid,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

//    // Aman as Dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid2,
                adultDependent_cid2,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

        // James as Dependent to Emila
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid1,
                adultDependent_cid1,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 10 : Get Consent Request For All
        // Get Adult Ecomm Consent Request for Caregiver 1 and Caregiver 2 with all adultDependents
        ServiceResponse serRes1 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(serRes1.getStatusCode(), 204);

        ServiceResponse serRes2 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(serRes2.getStatusCode(), 204);

        ServiceResponse serRes3 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid1);
        Assert.assertEquals(serRes3.getStatusCode(), 204);

        ServiceResponse serRes4 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid2);
        Assert.assertEquals(serRes4.getStatusCode(), 204);

//   Step-10 : Get Consent Request for all caregivers and dependents

        ServiceResponse serviceResponse1 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "caregiver", "false");
        Assert.assertEquals(serviceResponse1.getStatusCode(),200);
        Assert.assertEquals(serviceResponse1.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(),0);
        Assert.assertEquals(serviceResponse1.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(),0);


        ServiceResponse serviceResponse2 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "caregiver", "false");
        Assert.assertEquals(serviceResponse2.getStatusCode(),200);
        Assert.assertEquals(serviceResponse2.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(),0);
        Assert.assertEquals(serviceResponse2.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(),0);



        ServiceResponse serviceResponse3 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "dependent", "false");
        Assert.assertEquals(serviceResponse3.getStatusCode(),200);
        Assert.assertEquals(serviceResponse3.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(),0);
        Assert.assertEquals(serviceResponse3.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(),0);


        ServiceResponse serviceResponse4 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid1, "dependent", "false");
        Assert.assertEquals(serviceResponse4.getStatusCode(),200);
        Assert.assertEquals(serviceResponse4.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(),0);
        Assert.assertEquals(serviceResponse4.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(),0);



        ServiceResponse serviceResponse5 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid2, "dependent", "false");
        Assert.assertEquals(serviceResponse5.getStatusCode(),200);
        Assert.assertEquals(serviceResponse5.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(),0);
        Assert.assertEquals(serviceResponse5.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(),0);

//         Step:11 Xavier Send to Carlos and Aman Old Send Adult Ecomm Consent
//         Dependent, caregiver
        ServiceResponse serResForOldSendAdultConsent1 =
                consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
                        adultDependent_cid,caregiver_cid2);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse1 =
                serResForOldSendAdultConsent1.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serResForOldSendAdultConsent1.getStatusCode(), statusCode);
        Assert.assertEquals("success",sendAdultEcommConsentResponse1 .getPayload().getStatus());

        ServiceResponse serResForOldSendAdultConsent2 =
                consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
                        adultDependent_cid2,caregiver_cid2);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse2 =
                serResForOldSendAdultConsent2.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serResForOldSendAdultConsent2.getStatusCode(), statusCode);
        Assert.assertEquals("success",sendAdultEcommConsentResponse2 .getPayload().getStatus());


//     Validations for Get Adult Ecomm after old Send Adult Ecomm Consent
        ServiceResponse serRes11 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        GetAdultEcomResponse getAdultEcomResponse = serRes11.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes11.getStatusCode(), 200);
        for(int i=0;i<getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().size();i++) {
            if (getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equalsIgnoreCase(caregiver_cid2)) {
                Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(),caregiver2Email);
            }
        }
        Assert.assertEquals(getAdultEcomResponse.getPayload().getDependentInfo().getCustomerAccountId(), adultDependent_cid);

        ServiceResponse serRes12 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid2);
        GetAdultEcomResponse getAdultEcomResponse1 = serRes12.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes12.getStatusCode(), 200);
        for(int i=0;i<getAdultEcomResponse1.getPayload().getRequesterCaregiverInfo().size();i++) {
            if (getAdultEcomResponse1.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equalsIgnoreCase(caregiver_cid2)) {
                Assert.assertEquals(getAdultEcomResponse1.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(),caregiver2Email);
            }
        }
        Assert.assertEquals(getAdultEcomResponse1.getPayload().getDependentInfo().getCustomerAccountId(), adultDependent_cid2);

        //  Validations for Get Consent Request after old Send Adult Ecomm Consent
        ServiceResponse serviceResponse7 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "", "false");
        Assert.assertEquals(serviceResponse7.getStatusCode(),200);
        for(int i=0;i<serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid2)) {
                Assert.assertEquals(serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver2Email);
                Assert.assertEquals(serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        ServiceResponse serviceResponse8 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid2, "", "false");
        Assert.assertEquals(serviceResponse8.getStatusCode(),200);
        for(int i=0;i<serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid2)) {
                Assert.assertEquals(serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver2Email);
                Assert.assertEquals(serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        // Step:12 Emila Send to Carlos and James Old Send Adult Ecomm Consent
        // Dependent, caregiver
        ServiceResponse serResForOldSendAdultConsent3 =
                consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
                        adultDependent_cid,caregiver_cid1);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse3 =
                serResForOldSendAdultConsent3.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serResForOldSendAdultConsent3.getStatusCode(), statusCode);
        Assert.assertEquals("success",sendAdultEcommConsentResponse3 .getPayload().getStatus());

        ServiceResponse serResForOldSendAdultConsent4 =
                consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
                        adultDependent_cid1,caregiver_cid1);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse4 =
                serResForOldSendAdultConsent4.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serResForOldSendAdultConsent4.getStatusCode(), statusCode);
        Assert.assertEquals("success",sendAdultEcommConsentResponse4 .getPayload().getStatus());


        // Validations for Get Adult Ecomm after old Send Adult Ecomm Consent
        ServiceResponse serRes13 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        GetAdultEcomResponse getAdultEcomResponse2 = serRes13.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes13.getStatusCode(), 200);
        for(int i=0;i<getAdultEcomResponse2.getPayload().getRequesterCaregiverInfo().size();i++) {
            if (getAdultEcomResponse2.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equalsIgnoreCase(caregiver_cid1)) {
                Assert.assertEquals(getAdultEcomResponse2.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(),caregiver1Email);
            }
        }
        Assert.assertEquals(getAdultEcomResponse2.getPayload().getDependentInfo().getCustomerAccountId(), adultDependent_cid);

        ServiceResponse serRes14 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid1);
        GetAdultEcomResponse getAdultEcomResponse4 = serRes14.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes14.getStatusCode(), 200);
        for(int i=0;i<getAdultEcomResponse4.getPayload().getRequesterCaregiverInfo().size();i++) {
            if (getAdultEcomResponse4.getPayload().getRequesterCaregiverInfo().get(i).getCustomerAccountId().equalsIgnoreCase(caregiver_cid1)) {
                Assert.assertEquals(getAdultEcomResponse4.getPayload().getRequesterCaregiverInfo().get(i).getEmailId(),caregiver1Email);
            }
        }
        Assert.assertEquals(getAdultEcomResponse4.getPayload().getDependentInfo().getCustomerAccountId(), adultDependent_cid1);

        //  Validations for Get Consent Request after old Send Adult Ecomm Consent
        ServiceResponse serviceResponse9 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "", "false");
        Assert.assertEquals(serviceResponse9.getStatusCode(),200);
        for(int i=0;i<serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid1)) {
                Assert.assertEquals(serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver1Email);
                Assert.assertEquals(serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        ServiceResponse serviceResponse10 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid1, "", "false");
        Assert.assertEquals(serviceResponse10.getStatusCode(),200);
        for(int i=0;i<serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid1)) {
                Assert.assertEquals(serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver1Email);
                Assert.assertEquals(serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        // Step:13 Carlos Accepted For Emila and Xavier
        ServiceResponse serviceResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(adultDependent_cid,"50000","0000","001",storeNo,"Accept",adultDependentDetails.get(1));
        Assert.assertEquals(serviceResponse.getStatusCode(),200);

        // Validations for Get Ecomm after Carlos Accepted for Emila and Xavier
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
        GetEcomResponse getEcomResponse = serRes10.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes10.getStatusCode(), statusCode);
        Assert.assertEquals(
                "ACCEPT", getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        // Validate Get Adult Ecomm for Caregiver 1 and Caregiver 2 after Carlos Accepted
        ServiceResponse validategetAdultEcommResponse =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponse.getStatusCode(), 204);

        ServiceResponse validategetAdultEcommResponse2 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponse2.getStatusCode(), 204);

        // Validation Get Consent Request for Cargiver 1 and Caregiver 2 after Carlos Accepted

        ServiceResponse serviceResp9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serviceResp9.getStatusCode(),200);
        if(serviceResp9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serviceResp9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serviceResp9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid)) {
                    Assert.assertTrue(serviceResp9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED"));
                }
            }
        }


        ServiceResponse serviceResp10 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(serviceResp10.getStatusCode(),200);
        if(serviceResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serviceResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serviceResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid)) {
                    Assert.assertTrue(serviceResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED"));
                }
            }
        }

        // Step:14 Aman Dismissed For Xavier
        ServiceResponse dismissSerResponse = consentEcomOrchestratorWrapper.RejectConsentRequest_Dependent(adultDependent_cid2,"50000",List.of(caregiver_cid2));
        Assert.assertEquals(dismissSerResponse.getStatusCode(),200);


        ServiceResponse dissMissResponse = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(dissMissResponse.getStatusCode(),200);
        if(dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid2)) {
                    Assert.assertTrue(dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED"));
                }
            }
        }


//         Step15: Carlos as deny
        ServiceResponse denySerResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(adultDependent_cid,"50000","0000","001",storeNo,"deny", adultDependentDetails.get(1));
        Assert.assertEquals(denySerResponse.getStatusCode(),200);

        //    // Validations for Get Ecomm after Carlos Dismissed for Emila and Xavier

        ServiceResponse serviceResponseDeny = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
        GetEcomResponse getEcomResponseDeny = serviceResponseDeny.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serviceResponseDeny.getStatusCode(), statusCode);
        Assert.assertEquals(
                "DENY", getEcomResponseDeny.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        // Validate Get Adult Ecomm for Caregiver 1 and Caregiver 2 after Carlos Accepted
        ServiceResponse validategetAdultEcommResp =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResp.getStatusCode(), 204);

        ServiceResponse validategetAdultEcommResp1=
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResp1.getStatusCode(), 204);

        // Validation Get Consent Request for Cargiver 1 and Caregiver 2 after Carlos Deny

        ServiceResponse serRes9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serRes9.getStatusCode(),200);
        if(serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid)) {
                    Assert.assertTrue(serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED"));
                }
            }
        }

        if(serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid1)) {
                    Assert.assertTrue(serRes9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED"));
                }
            }
        }


        ServiceResponse serResp10 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(serResp10.getStatusCode(),200);
        if(serResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid)) {
                    Assert.assertTrue(serResp10.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED"));
                }
            }
        }
        //  Step:16 Calling revoke by emila
        ServiceResponse revokeServiceResponse = customerConsentWrapper.revokeCustomerConsent(caregiver_cid1);

        // Validate status code
        Assert.assertEquals("Status code did not match", revokeServiceResponse.getStatusCode(), statusCode);

        ServiceResponse validategetAdultEcommResponseAfterRevoke =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponseAfterRevoke.getStatusCode(), 204);


        ServiceResponse serviceRevoke9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serviceRevoke9.getStatusCode(),200);
        if(serviceRevoke9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<serviceRevoke9.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (serviceRevoke9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid)) {
                    Assert.assertTrue(serviceRevoke9.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED"));
                }
            }
        }
    }

    @Test(
            description = "New Caregiver Old Dependents",
            dataProviderClass = DataProvider.class,
            dataProvider = "getData",
            retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSendAdultEcommRequest")
    public void checkNewCaregiverAndOldDependents(String caregiver1DOB,
                                  String caregiver2DOB,
                                  String adultDependentDOB,
                                  String adultDependentDOB1,
                                  String adultDependentDOB2,
                                  int statusCode,
                                  String storeNo,
                                  boolean adultConsentEnabled                )
            throws InterruptedException, IOException {
        if(!adultConsentEnabled)    return;

        // Step - 1: Setting and logging fill ID's to make the respective calls
        // Emilia
        String caregiver1Email = "emila" + CommonUtil.generateRandomEmailId(10);
        String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Xavier
        String caregiver2Email = "xavier" + CommonUtil.generateRandomEmailId(10);
        String caregiver2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiver2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Carlos
        String adultDependentEmail = "carlos" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        // James
        String adultDependentEmail1 = "james" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName1 = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName1 = CommonUtil.generateRandomLastName(10).toUpperCase();
        // Aman
        String adultDependentEmail2 = "aman" + CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName2 = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String adultDependentLastName2 = CommonUtil.generateRandomLastName(10).toUpperCase();


        List<String> caregiver1Details =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
        String caregiver_cid1 = caregiver1Details.get(0);
        Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);


        List<String> caregiver2Details =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        caregiver2Email, caregiver2FirstName, caregiver2LastName, caregiver2DOB, storeNo);
        String caregiver_cid2 = caregiver2Details.get(0);
        Reporter.logJSON("Caregiver2 Customer Account Id", caregiver_cid2);


        List<String> adultDependentDetails =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail,
                        adultDependentFirstName,
                        adultDependentLastName,
                        adultDependentDOB,
                        storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);
        System.out.println(adultDependent_cid);

        List<String> adultDependentDetails1 =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail1,
                        adultDependentFirstName1,
                        adultDependentLastName1,
                        adultDependentDOB1,
                        storeNo);
        String adultDependent_cid1 = adultDependentDetails1.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id1", adultDependent_cid1);
        System.out.println(adultDependent_cid1);

        List<String> adultDependentDetails2 =
                digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                        adultDependentEmail2,
                        adultDependentFirstName2,
                        adultDependentLastName2,
                        adultDependentDOB2,
                        storeNo);
        String adultDependent_cid2 = adultDependentDetails2.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id2", adultDependent_cid2);

        System.out.println(adultDependent_cid2);

        // Carlos added as dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid2,
                adultDependent_cid,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

//    // carlos ad Dependent to Emila
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid1,
                adultDependent_cid,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

//    // Aman as Dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid2,
                adultDependent_cid2,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

        // James as Dependent to Emila
        consentOrchestratorWrapper.caAddDependent(
                caregiver_cid1,
                adultDependent_cid1,
                DependentInfo.TypeEnum.ADULT,
                DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 10 : Get Consent Request For All
        // Get Adult Ecomm Consent Request for Caregiver 1 and Caregiver 2 with all adultDependents
        ServiceResponse serRes1 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(serRes1.getStatusCode(), 204);

        ServiceResponse serRes2 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(serRes2.getStatusCode(), 204);

        ServiceResponse serRes3 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid1);
        Assert.assertEquals(serRes3.getStatusCode(), 204);

        ServiceResponse serRes4 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid2);
        Assert.assertEquals(serRes4.getStatusCode(), 204);

//   Step-10 : Get Consent Request for all caregivers and dependents

        ServiceResponse serviceResponse1 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "caregiver", "false");
        Assert.assertEquals(serviceResponse1.getStatusCode(), 200);
        Assert.assertEquals(serviceResponse1.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        Assert.assertEquals(serviceResponse1.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(), 0);


        ServiceResponse serviceResponse2 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "caregiver", "false");
        Assert.assertEquals(serviceResponse2.getStatusCode(), 200);
        Assert.assertEquals(serviceResponse2.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        Assert.assertEquals(serviceResponse2.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(), 0);


        ServiceResponse serviceResponse3 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "dependent", "false");
        Assert.assertEquals(serviceResponse3.getStatusCode(), 200);
        Assert.assertEquals(serviceResponse3.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        Assert.assertEquals(serviceResponse3.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(), 0);


        ServiceResponse serviceResponse4 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid1, "dependent", "false");
        Assert.assertEquals(serviceResponse4.getStatusCode(), 200);
        Assert.assertEquals(serviceResponse4.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        Assert.assertEquals(serviceResponse4.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(), 0);


        ServiceResponse serviceResponse5 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid2, "dependent", "false");
        Assert.assertEquals(serviceResponse5.getStatusCode(), 200);
        Assert.assertEquals(serviceResponse5.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        Assert.assertEquals(serviceResponse5.getDataResponse(GetConsentRequestResponse.class).getDependentRequest().size(), 0);

//         Step:11 Xavier Send to Carlos and Aman Old Send Adult Ecomm Consent
//         Dependent, caregiver
        ServiceResponse serResForConsentRequest1 =
                consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(caregiver_cid2,"50000", List.of(adultDependent_cid,adultDependent_cid2));

        Assert.assertEquals(serResForConsentRequest1.getStatusCode(), statusCode);

        //  Validations for Get Consent Request after old Send Adult Ecomm Consent
        ServiceResponse serviceResponse7 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "", "false");
        Assert.assertEquals(serviceResponse7.getStatusCode(),200);
        for(int i=0;i<serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid2)) {
                Assert.assertEquals(serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver2Email);
                Assert.assertEquals(serviceResponse7.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        ServiceResponse serviceResponse8 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid2, "", "false");
        Assert.assertEquals(serviceResponse8.getStatusCode(),200);
        for(int i=0;i<serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid2)) {
                Assert.assertEquals(serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver2Email);
                Assert.assertEquals(serviceResponse8.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

//        // Step:12 Emila Send to Carlos and James
//        // Dependent, caregiver
        ServiceResponse serResForConsentRequest2 =
                consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(caregiver_cid1,"50000", List.of(adultDependent_cid,adultDependent_cid1));

        Assert.assertEquals(serResForConsentRequest2.getStatusCode(), statusCode);

        //  Validations for Get Consent Request after old Send Adult Ecomm Consent
        ServiceResponse serviceResponse9 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid, "", "false");
        Assert.assertEquals(serviceResponse9.getStatusCode(),200);
        for(int i=0;i<serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid1)) {
                Assert.assertEquals(serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver1Email);
                Assert.assertEquals(serviceResponse9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        ServiceResponse serviceResponse10 = consentEcomOrchestratorWrapper.GetConsentRequest(adultDependent_cid1, "", "false");
        Assert.assertEquals(serviceResponse10.getStatusCode(),200);
        for(int i=0;i<serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size();i++) {
            if (serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getCustomerId().contains(caregiver_cid1)) {
                Assert.assertEquals(serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getEmailId(),caregiver1Email);
                Assert.assertEquals(serviceResponse10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().get(i).getRequestStatus(),"PENDING");
            }
        }

        // Step:13 Carlos Accepted For Emila and Xavier
        ServiceResponse serviceResponse = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(adultDependent_cid,"50000","0000","001",storeNo,adultDependentDetails.get(1),"Accept");
        Assert.assertEquals(serviceResponse.getStatusCode(),200);

        // Validations for Get Ecomm after Carlos Accepted for Emila and Xavier
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
        GetEcomResponse getEcomResponse = serRes10.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes10.getStatusCode(), statusCode);
        Assert.assertEquals(
                "ACCEPT", getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        // Validate Get Adult Ecomm for Caregiver 1 and Caregiver 2 after Carlos Accepted
        ServiceResponse validategetAdultEcommResponse =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponse.getStatusCode(), 204);

        ServiceResponse validategetAdultEcommResponse2 =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponse2.getStatusCode(), 204);

        // Validation Get Consent Request for Cargiver 1 and Caregiver 2 after Carlos Accepted

        ServiceResponse serviceResp9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serviceResp9.getStatusCode(),200);
        Assert.assertEquals(serviceResp9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);


        ServiceResponse serviceResp10 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(serviceResp10.getStatusCode(),200);
        Assert.assertEquals(serviceResp10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);

        // Step:14 Aman Dismissed For Xavier
        ServiceResponse dismissSerResponse = consentEcomOrchestratorWrapper.RejectConsentRequest_Dependent(adultDependent_cid2,"50000",List.of(caregiver_cid2));
        Assert.assertEquals(dismissSerResponse.getStatusCode(),200);


        ServiceResponse dissMissResponse = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(dissMissResponse.getStatusCode(),200);
        Assert.assertEquals(dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);
        if(dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().size()>0) {
            for(int i=0;i<dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().size();i++) {
                if (dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getIdentifiers().get(0).getDependentCustomerAccountId().contains(adultDependent_cid2)) {
                    Assert.assertTrue(dissMissResponse.getDataResponse(GetConsentRequestResponse.class).getP13ns().get(i).getEntity().contains("ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED"));
                }
            }
        }

//         Step15: Carlos as deny
        ServiceResponse denySerResponse = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(adultDependent_cid,"50000","0000","001",storeNo, adultDependentDetails.get(1),"deny");
        Assert.assertEquals(denySerResponse.getStatusCode(),200);


        ServiceResponse serviceResponseDeny = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
        GetEcomResponse getEcomResponseDeny = serviceResponseDeny.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serviceResponseDeny.getStatusCode(), statusCode);
        Assert.assertEquals(
                "DENY", getEcomResponseDeny.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        // Validate Get Adult Ecomm for Caregiver 1 and Caregiver 2 after Carlos Accepted
        ServiceResponse validategetAdultEcommResp =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResp.getStatusCode(), 204);

        ServiceResponse validategetAdultEcommResp1=
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid2, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResp1.getStatusCode(), 204);

        // Validation Get Consent Request for Cargiver 1 and Caregiver 2 after Carlos Deny

        ServiceResponse serRes9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serRes9.getStatusCode(),200);
        Assert.assertEquals(serRes9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);

        ServiceResponse serResp10 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid2, "", "true");
        Assert.assertEquals(serResp10.getStatusCode(),200);
        Assert.assertEquals(serResp10.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);

        //  Step:16 Calling revoke by emila
        ServiceResponse revokeServiceResponse = customerConsentWrapper.revokeCustomerConsent(caregiver_cid1);

        // Validate status code
        Assert.assertEquals("Status code did not match", revokeServiceResponse.getStatusCode(), statusCode);

        ServiceResponse validategetAdultEcommResponseAfterRevoke =
                consentEcomOrchestratorWrapper.validategetAdultEcomm(caregiver_cid1, adultDependent_cid);
        Assert.assertEquals(validategetAdultEcommResponseAfterRevoke.getStatusCode(), 204);

        ServiceResponse serviceRevoke9 = consentEcomOrchestratorWrapper.GetConsentRequest(caregiver_cid1, "", "true");
        Assert.assertEquals(serviceRevoke9.getStatusCode(),200);
        Assert.assertEquals(serviceRevoke9.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size(), 0);

    }
}
