package consentorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getVerbiage.GetVerbiageResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.utilities.Retry;
import org.junit.Assert;
import org.testng.annotations.Test;


public class getVerbiageTests {
    GetandSaveEcomWrapper consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();


    @Test(description = "validate get Verbiage API for ecomm self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_Self(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for ecomm self and dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_SelfDependent(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for ecomm self and dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_Dependent(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_SELF(String payload, String key1, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for self and dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_SELFDependent(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for multiple dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_MultipleDependent(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for medicaid", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Medicaid(String payload, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());
        Assert.assertNotNull(getVerbiageResponse.getForms().get(0).getFormContent());

    }

    @Test(description = "validate get Verbiage API for all forms", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_AllForms(String payload, int statusCode, String formId) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(3, getVerbiageResponse.getForms().size());
        for (int i = 0; i < getVerbiageResponse.getForms().size(); i++) {
            Assert.assertTrue(formId.contains(getVerbiageResponse.getForms().get(i).getFormId()));
            Assert.assertNotNull(getVerbiageResponse.getForms().get(i).getFormContent());
        }

    }

    @Test(description = "validate get Verbiage API without headers", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NoHeader(String payload, int statusCode, String errorCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiageNegative(payload);
        GetNPPFormErrorResponse getVerbiageResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(errorCode, getVerbiageResponse.getError().getCode());


    }

    @Test(description = "validate get Verbiage API for ecomm self Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_Self_Spanish(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for ecomm self and dependent Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_SelfDependent_Spanish(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for ecomm self and dependent Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_Dependent_Spanish(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for self Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_SELF_Spanish(String payload, String key1, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for self and dependent Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_SELFDependent_Spanish(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for NPP for multiple dependent Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_NPP_MultipleDependent_Spanish(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key1));
        Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(0).getFormContent().contains(key2));
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());

    }

    @Test(description = "validate get Verbiage API for medicaid Spanish", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Medicaid_Spanish(String payload, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        Assert.assertEquals(formId, getVerbiageResponse.getForms().get(0).getFormId());
        Assert.assertEquals(patientLocale, getVerbiageResponse.getForms().get(0).getPatientLocale());
        Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(0).getReturnStatusCode());
        Assert.assertNotNull(getVerbiageResponse.getForms().get(0).getFormContent());

    }

    @Test(description = "validate get Verbiage API for ecomm self MultipleLocale", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getVerbiage")
    public void getVerbiage_Ecomm_Self_MultipleLocale(String payload, String key1, String key2, int statusCode, String formId, String patientLocale, String returnStatusCode) {

        // Step - 1: calling getVerbiage
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getVerbiage(payload);
        GetVerbiageResponse getVerbiageResponse = serRes.getDataResponse(GetVerbiageResponse.class);

        // Validating the response
        Assert.assertEquals(serRes.getStatusCode(), statusCode);
        int noOfForms=getVerbiageResponse.getForms().size();
        Assert.assertEquals(2,noOfForms);
        for(int i=0;i<noOfForms;i++) {
            Assert.assertEquals(formId, getVerbiageResponse.getForms().get(i).getFormId());
            Assert.assertTrue("key1 is not present in form content", getVerbiageResponse.getForms().get(i).getFormContent().contains(key1));
            Assert.assertTrue("key2 is not present in form content", getVerbiageResponse.getForms().get(i).getFormContent().contains(key2));
            Assert.assertTrue(patientLocale.contains(getVerbiageResponse.getForms().get(i).getPatientLocale()));
            Assert.assertEquals(returnStatusCode, getVerbiageResponse.getForms().get(i).getReturnStatusCode());
        }

    }


}

