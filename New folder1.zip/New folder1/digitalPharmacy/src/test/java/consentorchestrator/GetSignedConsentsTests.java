package consentorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getSignedFormsResponse.SignedConsentsResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.searchSaveConsentResponse.SaveConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.SaveConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.SignedConsentsWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;

import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

/**
 * =====================================================================
 * GET SIGNED CONSENTS API TEST SUITE
 * =====================================================================
 *
 * @description This comprehensive test suite validates the end-to-end flow of
 *              Signed Consents API for Walmart Digital Pharmacy.
 *
 * @api POST /v1/consents/signed-consents
 * @service HW-CONSENT-ORCHESTRATOR
 *
 * Test data is maintained in Excel file: consentOrchestratorEcomData.xlsx
 * Sheet: signedConsentsData (single merged sheet for all test scenarios)
 *
 * =====================================================================
 * BUSINESS LOGIC OVERVIEW
 * =====================================================================
 *
 * The Consent Orchestrator implements a generic API to retrieve signed consent forms with
 * reconciliation logic for Rxd E-commerce (50000) and Extended HIPAA (50001) consents.
 *
 * RECONCILIATION RULES:
 *   - Extended HIPAA (50001) is PRIORITIZED over Ecomm (50000) when both are ACCEPT
 *   - If only one is ACCEPT, that form is returned
 *   - If both are DENY/NULL, returns 204 No Content
 *
 * DEPENDENT ACCOUNT CRITERIA:
 *   - Caregiver needs to sign either 50000 OR 50001 (not both required)
 *   - Both Self (dependent) AND Caregiver must have valid authorization
 *
 * =====================================================================
 * FORM CODES REFERENCE
 * =====================================================================
 *
 * | Form Code | Form ID          | Description               |
 * |-----------|------------------|---------------------------|
 * | 50000     | 50000-0000-001   | Ecomm Consent             |
 * | 50001     | 50001-0000-000   | Extended HIPAA Consent    |
 *
 * =====================================================================
 * TEST FLOW
 * =====================================================================
 *
 * 1. Create Account (using DigitalPharmacyOperationsUtil)
 * 2. Save Consent (using SaveConsentWrapper - PUT /v1/consents)
 * 3. Get Signed Consent (using SignedConsentsWrapper - POST /v1/consents/signed-consents)
 * 4. Validate Response
 *
 * =====================================================================
 * TEST SCENARIOS COVERAGE (37 Total Scenarios + 2 Validation Tests)
 * =====================================================================
 *
 * @author Automation Team
 */
public class GetSignedConsentsTests {

    // =====================================================================
    // CONSTANTS - FORM CODES
    // =====================================================================

    /** Ecomm Consent Form Code */
    private static final String ECOMM_FORM_CODE = "50000";

    /** Extended HIPAA Consent Form Code */
    private static final String HIPAA_FORM_CODE = "50001";

    /** Form ID: ECOMM */
    private static final String ECOMM_FORM_ID = "50000-0000-001";

    /** Form ID: HIPAA */
    private static final String HIPAA_FORM_ID = "50001-0000-000";

    // =====================================================================
    // CONSTANTS - AUTHORIZATION STATUS
    // =====================================================================

    /** Authorization Status: Accepted */
    private static final String AUTH_STATUS_ACCEPT = "ACCEPT";

    // =====================================================================
    // CONSTANTS - DEFAULT VALUES
    // =====================================================================

    /** Default LOB */
    private static final String DEFAULT_LOB = "PHARMACY";

    /** Default Tenant ID */
    private static final String DEFAULT_TENANT_ID = "tenant-id-1";

    /** Default Location State */
    private static final String DEFAULT_LOCATION_STATE = "AZ";

    /** Wait time for consent propagation */
    private static final long SAVE_PROPAGATION_WAIT_MS = 20;

    /** Excel sheet name for all signed consents test data */
    private static final String SHEET_NAME = "signedConsentsData";

    /** Excel file path */
    private static final String EXCEL_FILE_PATH = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx";

    // =====================================================================
    // WRAPPERS AND UTILITIES
    // =====================================================================

    /** Wrapper for Save Consent API (PUT /v1/consents) */
    protected SaveConsentWrapper saveConsentWrapper;

    /** Wrapper for Get Signed Consents API (POST /v1/consents/signed-consents) */
    protected SignedConsentsWrapper signedConsentsWrapper;

    /** Utility for account operations */
    protected DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil;

    /** Wrapper for dependent management */
    protected ConsentOrchestratorWrapper consentOrchestratorWrapper;

    // =====================================================================
    // SETUP - Initialize all wrappers
    // =====================================================================

    /**
     * Initialize all wrappers and utilities before test execution.
     * Called automatically by TestNG.
     */
    @BeforeClass
    public void setUp() {
        // Set default maxRetryAttempts if not already set (prevents NumberFormatException in Retry class)
        if (System.getProperty("maxRetryAttempts") == null) {
            System.setProperty("maxRetryAttempts", "2");
        }

        saveConsentWrapper = new SaveConsentWrapper();
        signedConsentsWrapper = new SignedConsentsWrapper();
        digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
        consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    }

    // =====================================================================
    // HELPER METHODS
    // =====================================================================

    /**
     * Convert Excel "NULL" string to actual null value
     */
    private String nullSafe(String value) {
        return (value == null || value.equalsIgnoreCase("NULL") || value.isEmpty()) ? null : value;
    }

    // =====================================================================
    // SELF ACCOUNT TYPE - ECOMM CONSENT TESTS (Scenarios 1-2)
    // =====================================================================

    /**
     * Test: Save Ecomm Consent for Self → Get Signed Consent → Validate
     * Scenarios: 1-2 (Ecomm ACCEPT/DENY)
     */
    @Test(description = "Save Ecomm Consent for Self then fetch signed consent", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentSelfEcommOnly(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        // Step 1: Create Customer Account
        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                email, firstName, lastName, nullSafe(caregiverDOB), storeNo);
        String customerId = details.get(0);
        Reporter.logJSON("Step 1 - Created Customer Account", customerId);

        // Step 2: Save Ecomm Consent using SaveConsentWrapper
        Reporter.log("Step 2: Saving Ecomm Consent (50000) via PUT /v1/consents with status: " + selfConsentStatus);
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForSelf(
                customerId, ECOMM_FORM_ID, ECOMM_FORM_CODE, selfConsentStatus,
                DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 3: Get Signed Consent using SignedConsentsWrapper
        Reporter.log("Step 3: Fetching Signed Consent via POST /v1/consents/signed-consents");
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsSelf(
                customerId, firstName, lastName, "",
                List.of(ECOMM_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Self Ecomm " + selfConsentStatus,
                expectedStatusCode, response.getStatusCode());

        // Step 4: Validate Response (only for ACCEPT/200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, ECOMM_FORM_CODE, firstName);
        } else if (expectedStatusCode == 204) {
            Reporter.log("Step 4: Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Self Ecomm consent test", "Status: " + selfConsentStatus + ", Expected: " + expectedStatusCode);
    }

    // =====================================================================
    // SELF ACCOUNT TYPE - EXTENDED HIPAA CONSENT TESTS (Scenarios 3-4)
    // =====================================================================

    /**
     * Test: Save Extended HIPAA Consent for Self → Get Signed Consent → Validate
     * Scenarios: 3-4 (Extended HIPAA ACCEPT/DENY)
     */
    @Test(description = "Save Extended HIPAA Consent for Self then fetch signed consent", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentSelfExtendedHipaaOnly(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        // Step 1: Create Customer Account
        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                email, firstName, lastName, nullSafe(caregiverDOB), storeNo);
        String customerId = details.get(0);
        Reporter.logJSON("Step 1 - Created Customer Account", customerId);

        // Step 2: Save Extended HIPAA Consent using SaveConsentWrapper ACCEPT
        Reporter.log("Step 2: Saving Extended HIPAA Consent (50001) via PUT /v1/consents with status: " + selfConsentStatus);
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForSelf(
                customerId, HIPAA_FORM_ID, HIPAA_FORM_CODE, selfConsentStatus,
                DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 3: Get Signed Consent
        Reporter.log("Step 3: Fetching Signed Consent via POST /v1/consents/signed-consents");
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsSelf(
                customerId, firstName, lastName, "",
                List.of(HIPAA_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Self Extended HIPAA " + selfConsentStatus,
                expectedStatusCode, response.getStatusCode());

        // Step 4: Validate Response (only for ACCEPT/200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, HIPAA_FORM_CODE, firstName);
        } else if (expectedStatusCode == 204) {
            Reporter.log("Step 4: Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Self Extended HIPAA consent test", "Status: " + selfConsentStatus + ", Expected: " + expectedStatusCode);
    }

    // =====================================================================
    // SELF ACCOUNT TYPE - BOTH FORMS WITH RECONCILIATION (Scenarios 5-9)
    // =====================================================================

    /**
     * Test: Save Both Ecomm & Extended HIPAA for Self → Get Signed Consent → Validate Reconciliation
     * Scenarios: 5-9 (Both forms with various status combinations)
     */
    @Test(description = "Save both Ecomm & Extended HIPAA for Self then validate reconciliation", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentSelfBothFormsReconciliation(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Ecomm Status: " + ecommStatus + ", ExtHIPAA Status: " + extendedHipaaStatus);

        // Step 1: Create Customer Account
        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                email, firstName, lastName, nullSafe(caregiverDOB), storeNo);
        String customerId = details.get(0);
        Reporter.logJSON("Step 1 - Created Customer Account", customerId);

        // Step 2: Save Ecomm Consent if not NULL/empty
        if (ecommStatus != null && !ecommStatus.isEmpty() && !ecommStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 2a: Saving Ecomm Consent (50000) with status: " + ecommStatus);
            ServiceResponse saveEcommResponse = saveConsentWrapper.saveConsentForSelf(
                    customerId, ECOMM_FORM_ID, ECOMM_FORM_CODE, ecommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
            Assert.assertEquals("Save Ecomm Consent should succeed", 200, saveEcommResponse.getStatusCode());
            Thread.sleep(100);
        }

        // Step 3: Save Extended HIPAA Consent if not NULL/empty
        if (extendedHipaaStatus != null && !extendedHipaaStatus.isEmpty() && !extendedHipaaStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 2b: Saving Extended HIPAA Consent (50001) with status: " + extendedHipaaStatus);
            ServiceResponse saveHipaaResponse = saveConsentWrapper.saveConsentForSelf(
                    customerId, HIPAA_FORM_ID, HIPAA_FORM_CODE, extendedHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
            Assert.assertEquals("Save HIPAA Consent should succeed", 200, saveHipaaResponse.getStatusCode());
        }

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 4: Get Signed Consent for both form codes
        Reporter.log("Step 3: Fetching Signed Consent for both form codes");
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsSelf(
                customerId, firstName, lastName, "",
                List.of(ECOMM_FORM_CODE, HIPAA_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Self Reconciliation", expectedStatusCode, response.getStatusCode());

        // Step 5: Validate Reconciliation (only for 200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, expectedFormCode, firstName);
            Reporter.log("Reconciliation validated - Expected FormCode: " + expectedFormCode);
        } else if(expectedStatusCode == 204) {
            Reporter.log("Step 5: Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Self reconciliation test", "Ecomm: " + ecommStatus + ", ExtHIPAA: " + extendedHipaaStatus);
    }

    // =====================================================================
    // DEPENDENT ACCOUNT TYPE - ECOMM CONSENT TESTS (Scenarios 10-17)
    // =====================================================================

    /**
     * Test: Save Ecomm Consent for Dependent → Get Signed Consent
     * Scenarios: 10-17 (Dependent Ecomm with various CG authorization combinations)
     */
    @Test(description = "Save Ecomm Consent for Dependent then fetch signed consent", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentDependentEcommOnly(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException, java.io.IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        // Step 1: Create Caregiver Account
        String cgEmail = CommonUtil.generateRandomEmailId(10);
        String cgFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String cgLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> cgDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                cgEmail, cgFirstName, cgLastName, nullSafe(caregiverDOB), storeNo);
        String caregiverId = cgDetails.get(0);
        Reporter.logJSON("Step 1a - Created Caregiver Account", caregiverId);

        // Step 2: Create Dependent Account
        String depEmail = CommonUtil.generateRandomEmailId(10);
        String depFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String depLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> depDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                depEmail, depFirstName, depLastName, dependentDOB, storeNo);
        String dependentId = depDetails.get(0);
        Reporter.logJSON("Step 1b - Created Dependent Account", dependentId);

        // Step 3: Link Dependent to Caregiver
        consentOrchestratorWrapper.caAddDependent(caregiverId, dependentId,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);
        Reporter.log("Step 2 - Linked Dependent to Caregiver");

        // Step 4: Save Consents for Dependent (Minor) - Ecomm only
        if (selfEcommStatus != null && !selfEcommStatus.isEmpty() && !selfEcommStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3a: Saving Ecomm Consent for Minor Dependent with status: " + selfEcommStatus);
            saveConsentWrapper.saveConsentForOnlyMinor(caregiverId,dependentId, ECOMM_FORM_ID, ECOMM_FORM_CODE, selfEcommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        // Step 5: Save Consents for Caregiver
        if (caregiverEcommStatus != null && !caregiverEcommStatus.isEmpty() && !caregiverEcommStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3b: Saving Ecomm Consent for Caregiver with status: " + caregiverEcommStatus);
            saveConsentWrapper.saveConsentForSelf(caregiverId, ECOMM_FORM_ID, ECOMM_FORM_CODE, caregiverEcommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }
        if (caregiverExtHipaaStatus != null && !caregiverExtHipaaStatus.isEmpty() && !caregiverExtHipaaStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3c: Saving ExtHIPAA Consent for Caregiver with status: " + caregiverExtHipaaStatus);
            saveConsentWrapper.saveConsentForSelf(caregiverId, HIPAA_FORM_ID, HIPAA_FORM_CODE, caregiverExtHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 6: Get Signed Consent for Dependent
        Reporter.log("Step 4: Fetching Signed Consent for Dependent");
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsDependent(
                dependentId, depFirstName, depLastName, "",
                caregiverId, cgFirstName, cgLastName, "",
                List.of(ECOMM_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Dependent Ecomm", expectedStatusCode, response.getStatusCode());

        // Validate Response (only for 200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, ECOMM_FORM_CODE, depFirstName);
        } else if(expectedStatusCode == 204) {
            Reporter.log("Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Dependent Ecomm test", "Expected: " + expectedStatusCode);
    }

    // =====================================================================
    // DEPENDENT ACCOUNT TYPE - EXTENDED HIPAA CONSENT TESTS (Scenarios 18-25)
    // =====================================================================

    /**
     * Test: Save Extended HIPAA Consent for Dependent → Get Signed Consent
     * Scenarios: 18-25 (Dependent ExtHIPAA with various CG authorization combinations)
     */
    @Test(description = "Save Extended HIPAA Consent for Dependent then fetch signed consent", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentDependentExtendedHipaaOnly(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException, java.io.IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        // Step 1: Create Caregiver Account
        String cgEmail = CommonUtil.generateRandomEmailId(10);
        String cgFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String cgLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> cgDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                cgEmail, cgFirstName, cgLastName, nullSafe(caregiverDOB), storeNo);
        String caregiverId = cgDetails.get(0);
        Reporter.logJSON("Step 1a - Created Caregiver", caregiverId);

        // Step 2: Create Dependent Account
        String depEmail = CommonUtil.generateRandomEmailId(10);
        String depFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String depLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> depDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                depEmail, depFirstName, depLastName, nullSafe(dependentDOB), storeNo);
        String dependentId = depDetails.get(0);
        Reporter.logJSON("Step 1b - Created Dependent", dependentId);

        // Step 3: Link Dependent to Caregiver
        consentOrchestratorWrapper.caAddDependent(caregiverId, dependentId,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Consents for Dependent (Minor) - Extended HIPAA only
        if (selfExtHipaaStatus != null && !selfExtHipaaStatus.isEmpty() && !selfExtHipaaStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3a: Saving Extended HIPAA Consent for Minor Dependent with status: " + selfExtHipaaStatus);
            saveConsentWrapper.saveConsentForOnlyMinor(caregiverId,dependentId, HIPAA_FORM_ID, HIPAA_FORM_CODE, selfExtHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        // Step 5: Save Consents for Caregiver
        if (caregiverEcommStatus != null && !caregiverEcommStatus.isEmpty() && !caregiverEcommStatus.equalsIgnoreCase("NULL")) {
            saveConsentWrapper.saveConsentForSelf(caregiverId, ECOMM_FORM_ID, ECOMM_FORM_CODE, caregiverEcommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }
        if (caregiverExtHipaaStatus != null && !caregiverExtHipaaStatus.isEmpty() && !caregiverExtHipaaStatus.equalsIgnoreCase("NULL")) {
            saveConsentWrapper.saveConsentForSelf(caregiverId, HIPAA_FORM_ID, HIPAA_FORM_CODE, caregiverExtHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 6: Get Signed Consent
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsDependent(
                dependentId, depFirstName, depLastName, "",
                caregiverId, cgFirstName, cgLastName, "",
                List.of(HIPAA_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Dependent Extended HIPAA", expectedStatusCode, response.getStatusCode());

        // Validate Response (only for 200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, HIPAA_FORM_CODE, depFirstName);
        } else if(expectedStatusCode == 204) {
            Reporter.log("Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Dependent Extended HIPAA test", "Expected: " + expectedStatusCode);
    }

    // =====================================================================
    // DEPENDENT ACCOUNT TYPE - BOTH FORMS WITH RECONCILIATION (Scenarios 26-37)
    // =====================================================================

    /**
     * Test: Save Both Forms for Dependent → Get Signed Consent → Validate Reconciliation
     * Scenarios: 26-37 (Both forms with various status combinations for dependent & caregiver)
     */
    @Test(description = "Save both forms for Dependent then validate reconciliation", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void fetchSignedConsentDependentBothFormsReconciliation(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException, java.io.IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        // Step 1: Create Caregiver Account
        String cgEmail = CommonUtil.generateRandomEmailId(10);
        String cgFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String cgLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> cgDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                cgEmail, cgFirstName, cgLastName, nullSafe(caregiverDOB), storeNo);
        String caregiverId = cgDetails.get(0);

        // Step 2: Create Dependent Account
        String depEmail = CommonUtil.generateRandomEmailId(10);
        String depFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String depLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> depDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                depEmail, depFirstName, depLastName, nullSafe(dependentDOB), storeNo);
        String dependentId = depDetails.get(0);

        // Step 3: Link Dependent to Caregiver
        consentOrchestratorWrapper.caAddDependent(caregiverId, dependentId,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        Reporter.logJSON("Testing Dependent Both Forms Reconciliation", dependentId);

        // Step 4: Save Consents for Dependent (Minor) - Both forms
        if (selfEcommStatus != null && !selfEcommStatus.isEmpty() && !selfEcommStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3a: Saving Ecomm Consent for Minor Dependent with status: " + selfEcommStatus);
            saveConsentWrapper.saveConsentForOnlyMinor(caregiverId,dependentId, ECOMM_FORM_ID, ECOMM_FORM_CODE, selfEcommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }
        if (selfExtHipaaStatus != null && !selfExtHipaaStatus.isEmpty() && !selfExtHipaaStatus.equalsIgnoreCase("NULL")) {
            Reporter.log("Step 3b: Saving Extended HIPAA Consent for Minor Dependent with status: " + selfExtHipaaStatus);
            saveConsentWrapper.saveConsentForOnlyMinor(caregiverId,dependentId, HIPAA_FORM_ID, HIPAA_FORM_CODE, selfExtHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        // Step 5: Save Consents for Caregiver
        if (caregiverEcommStatus != null && !caregiverEcommStatus.isEmpty() && !caregiverEcommStatus.equalsIgnoreCase("NULL")) {
            saveConsentWrapper.saveConsentForSelf(caregiverId, ECOMM_FORM_ID, ECOMM_FORM_CODE, caregiverEcommStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }
        if (caregiverExtHipaaStatus != null && !caregiverExtHipaaStatus.isEmpty() && !caregiverExtHipaaStatus.equalsIgnoreCase("NULL")) {
            saveConsentWrapper.saveConsentForSelf(caregiverId, HIPAA_FORM_ID, HIPAA_FORM_CODE, caregiverExtHipaaStatus,
                    DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);
        }

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Step 6: Get Signed Consent
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsDependent(
                dependentId, depFirstName, depLastName, "",
                caregiverId, cgFirstName, cgLastName, "",
                List.of(ECOMM_FORM_CODE, HIPAA_FORM_CODE), contentType, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code mismatch for Dependent Reconciliation", expectedStatusCode, response.getStatusCode());

        // Validate Response (only for 200 scenarios)
        if (expectedStatusCode == 200) {
            validateSignedConsentResponse(response, expectedFormCode, depFirstName);
        } else if(expectedStatusCode == 204) {
            Reporter.log("Skipping response validation for DENY scenario (204 No Content expected)");
        }

        Reporter.logJSON("PASSED - Dependent reconciliation test", "Expected FormCode: " + expectedFormCode);
    }

    // =====================================================================
    // CONTENT TYPE AND LANGUAGE VALIDATION TESTS
    // =====================================================================

    /**
     * Test: Validate default PDF content type when not specified
     */
    @Test(description = "Validate default PDF content type when not specified in request", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void validateDefaultContentTypePDF(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                email, firstName, lastName, nullSafe(caregiverDOB), storeNo);
        String customerId = details.get(0);

        // Save Ecomm Consent with ACCEPT
        saveConsentWrapper.saveConsentForSelf(customerId, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        // Call without specifying content type - should default to PDF
        ServiceResponse response = signedConsentsWrapper.getSignedConsentsSelf(
                customerId, firstName, lastName, "",
                List.of(ECOMM_FORM_CODE), null, SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());

        Reporter.logJSON("PASSED - Default content type validation", "Content type defaults to PDF");
    }

    /**
     * Test: Validate default English language code
     */
    @Test(description = "Validate default English language code when not specified in request", retryAnalyzer = Retry.class,
            dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = EXCEL_FILE_PATH, sheetName = SHEET_NAME)
    public void validateDefaultLanguageCodeEnglish(
            String testname, String description, String caregiverDOB, String dependentDOB, String storeNo,
            String selfConsentStatus, String ecommStatus, String extendedHipaaStatus,
            String selfEcommStatus, String selfExtHipaaStatus,
            String caregiverEcommStatus, String caregiverExtHipaaStatus,
            int expectedStatusCode, String expectedFormCode, String contentType) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                email, firstName, lastName, nullSafe(caregiverDOB), storeNo);
        String customerId = details.get(0);

        saveConsentWrapper.saveConsentForSelf(customerId, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                DEFAULT_LOB, DEFAULT_TENANT_ID, storeNo, DEFAULT_LOCATION_STATE);

        Thread.sleep(SAVE_PROPAGATION_WAIT_MS);

        ServiceResponse response = signedConsentsWrapper.getSignedConsentsSelf(
                customerId, firstName, lastName, "",
                List.of(ECOMM_FORM_CODE), SignedConsentsWrapper.CONTENT_TYPE_PDF,
                SignedConsentsWrapper.LANGUAGE_CODE_ENGLISH);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        Reporter.logJSON("PASSED - Language code validation", "English (101) used");
    }

    // =====================================================================
    // VALIDATION HELPER METHODS
    // =====================================================================

    /**
     * Validates signed consent response
     */
    private void validateSignedConsentResponse(ServiceResponse response, String expectedFormCode, String expectedFirstName) {
        SignedConsentsResponse signedConsentsResponse = response.getDataResponse(SignedConsentsResponse.class);
        Assert.assertNotNull("Response should not be null", signedConsentsResponse);

        SignedConsentsResponse.SignedConsentInfo consentInfo = signedConsentsResponse.getFirstSignedConsent();
        Assert.assertNotNull("SignedConsentInfo should not be null", consentInfo);
        Assert.assertEquals("Form code should match", expectedFormCode, consentInfo.getFormCode());
        Assert.assertNotNull("Content should not be null", consentInfo.getContent());

        Reporter.logJSON("Validated signed consent response", "FormCode: " + consentInfo.getFormCode());
    }
}
