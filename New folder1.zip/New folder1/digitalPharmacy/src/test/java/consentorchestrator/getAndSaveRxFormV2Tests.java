package consentorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getEcomResponse.GetEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getMedicaidFormResponse.GetRxFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getSignedFormsResponse.GetSignedFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.saveEcom.SaveEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.savenpp.SaveNppResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Retry;
import org.apache.commons.lang3.text.WordUtils;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class getAndSaveRxFormV2Tests {
    GetandSaveEcomWrapper consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();
    ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();

    @Test(description = "Validate if the saveRxLevelConsents() API returns success code 202 Accepted when valid request payload with complete Flow Patient Safety", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveMedicaidFormValidTest_1(int statusCode, String caregiverDOB, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId, String status, String formIdNPP, String formVrsnNbrNPP, String signatureTypeCodeNPP, String type, String storeNo, String formIdMedicaid, String formVrsnNbrMedicaid, String signatureTypeCodeMedicaid, String languageCode, String createdSource, String lasturl, String formIdEcomm, String signatureTypeCodeEcomm, String formVrsnNbrEcomm) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);

        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Switch to Cash flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_SwitchToCash(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        Thread.sleep(240000);
        // Step - 4: Validate getMedicaid Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "32766");
        GetRxFormResponse getMedicaidFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serResMedicaid.getStatusCode());
        int noOfMedicaidForm = getMedicaidFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfMedicaidForm, 1);
        Assert.assertEquals(rxDetails.get(0), getMedicaidFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getPatientId().toString());
        Assert.assertEquals(formIdMedicaid, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId().toString());
        Assert.assertEquals(formVrsnNbrMedicaid, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr().toString());
        Assert.assertEquals(signatureTypeCodeMedicaid, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode().toString());
        Assert.assertEquals(true, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        // Step - 3: Validate getNPP Form
        ServiceResponse serResNPP = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serResNPP.getDataResponse(GetNPPFormResponse.class);
        Assert.assertEquals("Status code did not match", serResNPP.getStatusCode(), statusCode);
        Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(0).getFirstName());
        Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(0).getLastName());
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Assert.assertEquals(type, getNPPFormResponse.getPatientSigForms().get(0).getType());
        Assert.assertEquals(formIdNPP, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrNPP, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeNPP, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Integer SaveNPPPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
            }

        }

        // Step - 4: Validate getEcomm Form
        ServiceResponse serResEcomm = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serResEcomm.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serResEcomm.getStatusCode(), statusCode);

        Assert.assertEquals(formIdEcomm, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbrEcomm, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeEcomm, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        String customerAccountId = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();


        //Step - 5: Call the getSignedForm to validate no form is returned
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serRess.getStatusCode(), 204);

        //Step - 8: Save Medicaid Form
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveMedicaid(signatureTypeCodeMedicaid, formIdMedicaid, formVrsnNbrMedicaid, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        //Step - 6: Save Ecomm Consent Form
        ServiceResponse serResSaveEcomm = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(customerAccountId, SignatureTypeCode, formIdEcomm, formVrsnNbrEcomm, StoreNbr, PatientId, status);
        SaveEcomResponse saveEcomResponse = serResSaveEcomm.getDataResponse(SaveEcomResponse.class);
        Assert.assertEquals("Status code did not match", serResSaveEcomm.getStatusCode(), statusCode);

        //Step - 7: Save NPP Consent Form
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCodeNPP, formIdNPP, formVrsnNbrNPP, status, languageCode, createdSource, lasturl, getNPPFormResponse.getPatientSigForms().get(0).getStoreNumber(), Customer, SaveNPPPatientId);
        SaveNppResponse saveNppResponse = serRes1.getDataResponse(SaveNppResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), 202);


        //Step - 9: Invoke GetEcomm Forms API to validate ecomm consent is captured
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        //Step 10: Validate the form content firstName, lastName and dobx
        ServiceResponse serResss = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serResss.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponses = serResss.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponses.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString = getSignedFormResponses.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Step - 4: Validate getMedicaid Form is not asked again
        ServiceResponse serResMedicaids = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "32766");
        GetRxFormResponse getMedicaidFormResponses = serResMedicaids.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", serResMedicaids.getStatusCode(), 200);
    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge auto fill enrollment", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveAutofillFormValidTest_1(String caregiverDOB, String statusCode, String formIdAutofill, String formVrsnNbrAutofill, String signatureTypeCodeRx, String storeNo) throws InterruptedException, IOException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        //  String storeNo="5597";

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        ServiceResponse serviceResponse = consentOrchestratorWrapper.autofillEnrollment(storeNo, rxDetails.get(0));
        consentOrchestratorWrapper.updateAutofillEnrollmentStatus(Integer.parseInt(storeNo), Integer.parseInt(rxDetails.get(2)));

        // Step - 5: Validate getAutofill Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeRx, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge auto fill enrollment and user accepts", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveAutofillFormValidTest_2(String caregiverDOB, String statusCode, String formIdAutofill, String formVrsnNbrAutofill, String signatureTypeCodeRx, String storeNo, String enrolledStatus) throws InterruptedException, IOException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        ServiceResponse serviceResponse = consentOrchestratorWrapper.autofillEnrollment(storeNo, rxDetails.get(0));
        consentOrchestratorWrapper.updateAutofillEnrollmentStatus(Integer.parseInt(storeNo), Integer.parseInt(rxDetails.get(2)));

        // Step - 3: Validate getAutofill Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);

        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeRx, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        //Step - 4: Save Autofill Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveAutofill(signatureTypeCodeRx, formIdAutofill, formVrsnNbrAutofill, caregiverDetails.get(0), Integer.parseInt(rxDetails.get(0)), storeNo, enrolledStatus);
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        Thread.sleep(120000);
        //Step - 5: Hit Get Form API again and check it is not asked again
        ServiceResponse serResMedicaids = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914");
        GetRxFormResponse getRxFormResponses = serResMedicaids.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", serResMedicaids.getStatusCode(), 200);


    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge auto fill enrollment and user unenrolls Rx", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveAutofillFormValidTest_3(String caregiverDOB, String statusCode, String formIdAutofill, String formVrsnNbrAutofill, String signatureTypeCodeRx, String storeNo, String enrolledStatus) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        ServiceResponse serviceResponse = consentOrchestratorWrapper.autofillEnrollment(storeNo, rxDetails.get(0));
        consentOrchestratorWrapper.updateAutofillEnrollmentStatus(Integer.parseInt(storeNo), Integer.parseInt(rxDetails.get(2)));

        // Step - 3: Validate getAutofill Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);

        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeRx, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        //Step - 4: Save Autofill Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveAutofill(signatureTypeCodeRx, formIdAutofill, formVrsnNbrAutofill, caregiverDetails.get(0), Integer.parseInt(rxDetails.get(0)), storeNo, enrolledStatus);
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);
        Thread.sleep(120000);
        //Step - 5: Hit Get Form API again and check it is not asked again
        ServiceResponse serResMedicaids = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914");
        GetRxFormResponse getRxFormResponses = serResMedicaids.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", serResMedicaids.getStatusCode(), 200);

    }

    @Test(description = "Validate error retrieving Autofill and medicaid when correct headers are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormInvalidTest_1(String errorCode, int statusCode, String storeNo) {

        // Step - 1: Set up test data for get Rx Form
        ArrayList<String> rxDetails = new ArrayList<>();
        rxDetails.add("8001170");
        rxDetails.add("1140885");

        // Step - 1: Validate get Rx Form without headers
        ServiceResponse serRes = consentOrchestratorWrapper.getRxForm_withoutHeadersV2(storeNo, rxDetails, "3914");
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);
        Assert.assertEquals("Error code did not match", getNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "Validate error retrieving Autofill and medicaid when correct signatureTypeCodes are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormInvalidTest_2(String errorCode, int statusCode, String storeNo) {

        // Step - 1: Set up test data for get Rx Form
        ArrayList<String> rxDetails = new ArrayList<>();
        rxDetails.add("8001170");
        rxDetails.add("1140885");

        // Step - 1: Validate get Rx Form without headers
        ServiceResponse serRes = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "1234");
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serRes.getStatusCode());

        Assert.assertEquals("Error code did not match", errorCode, getNPPFormErrorResponse.getError().getCode());
    }

    @Test(description = "Validate error saving Autofill and medicaid when correct headers are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormInvalidTest_3(String errorCode, int statusCode, String storeNo) {

        // Step - 1: Set up test data for get Rx Form
        ArrayList<String> rxDetails = new ArrayList<>();
        rxDetails.add("8001170");
        rxDetails.add("1140885");

        // Step - 1: Validate get Rx Form without headers
        ServiceResponse serRes = consentOrchestratorWrapper.saveMedicaid_Invalid("3914", "1", "1", rxDetails.get(0), storeNo, "49c1696d-6d67-49a7-9eb2-e5b38c719340");
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        Assert.assertEquals("Error code did not match", getNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge SOD form", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveSODFormValidTest_1(String caregiverDOB, String statusCode, String formIdSOD, String formVrsnNbrSOD, String signatureTypeCodeRx, String storeNo, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with SOD flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        Thread.sleep(240000);// wait time for rx to sync

        // Step - 5: Validate getSOD Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3900");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdSOD, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrSOD, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeRx, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge SOD form and Save it", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveSODFormValidTest_2(String caregiverDOB, String statusCode, String formIdSOD, String formVrsnNbrSOD, String signatureTypeCodeRx, String storeNo, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with SOD flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        Thread.sleep(240000);// wait time for rx to sync

        // Step - 5: Validate getSOD Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3900");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdSOD, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrSOD, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeRx, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());


        //Step - 4: Save SOD Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveMedicaid(signatureTypeCodeRx, formIdSOD, formVrsnNbrSOD, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);
        Thread.sleep(120000);

        //Step - 5: Hit Get Form API again and check it is not asked again
        ServiceResponse serResMedicaids = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, signatureTypeCodeRx);
        GetRxFormResponse getRxFormResponses = serResMedicaids.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", serResMedicaids.getStatusCode(), 200);

    }

    @Test(description = "Validate getSOD form api when there is no sod form for the rx", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveSODFormValidTest_3(String caregiverDOB, String statusCode, String formIdSOD, String formVrsnNbrSOD, String signatureTypeCodeRx, String storeNo, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with SOD flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        Thread.sleep(240000);// wait time for rx to sync

        // Step - 5: Validate getSOD Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3900");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().size();
        Assert.assertEquals(noOfRxForm, 0);

    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge Autofill and medicaid form and Save it", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveRxFormValidTest_4(String caregiverDOB, String statusCode, String formIdAutofill, String formVrsnNbrAutofill, String formIdMedicaid, String formVrsnNbrMedicaid, String signatureTypeCodeRx, String enrolledStatus, String storeNo, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Medicaid and Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_SwitchToCash(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));

        ServiceResponse serviceResponse = consentOrchestratorWrapper.autofillEnrollment(storeNo, rxDetails.get(0));
        consentOrchestratorWrapper.updateAutofillEnrollmentStatus(Integer.parseInt(storeNo), Integer.parseInt(rxDetails.get(2)));
        Thread.sleep(240000);// wait time for rx to sync

        // Step - 4: Validate Autofill and Medicaid Form
        ServiceResponse serResResponse = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, signatureTypeCodeRx);
        Assert.assertEquals("Status code did not match", statusCode, String.valueOf(serResResponse.getStatusCode()));
        GetRxFormResponse getRxFormResponse = serResResponse.getDataResponse(GetRxFormResponse.class);

        int noOfRxForms = getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().size();
        Assert.assertEquals(noOfRxForms, 2); //Autofill and Medicaid forms

        for (int i = 0; i < noOfRxForms; i++) {
            if (getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode().equals("3914")) {
                Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
                Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
                Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
                Assert.assertEquals(formIdAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormId());
                Assert.assertEquals(formVrsnNbrAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormVrsnNbr());
                Assert.assertEquals("3914", getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode());
            } else {
                Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
                Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
                Assert.assertEquals(caregiverDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getPatientId().toString());
                Assert.assertEquals(formIdMedicaid, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormId().toString());
                Assert.assertEquals(formVrsnNbrMedicaid, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormVrsnNbr().toString());
                Assert.assertEquals("32766", getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode().toString());
            }
        }

        //Step - 5: Save Medicaid Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveMedicaid("32766", formIdMedicaid, formVrsnNbrMedicaid, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        //Step - 6: Save Autofill Form - Accept
        ServiceResponse serResSaveMedicaids = consentOrchestratorWrapper.saveAutofill("3914", formIdAutofill, formVrsnNbrAutofill, caregiverDetails.get(0), Integer.parseInt(rxDetails.get(0)), storeNo, enrolledStatus);
        Assert.assertEquals("Status code did not match", serResSaveMedicaids.getStatusCode(), 202);
        Thread.sleep(120000);

        //Step - 5: Hit Get Form API again and check it is not asked again
        ServiceResponse serResMedicaidForms = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, signatureTypeCodeRx);
        GetRxFormResponse getRxFormResponsess = serResMedicaidForms.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", serResMedicaidForms.getStatusCode(), 200);

    }

    @Test(description = "Validate error retrieving all forms when correct rxNumber are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormV2InvalidRxNbr(String errorCode, int statusCode, String storeNo) throws InterruptedException {
        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String caregiverDOB = "12121998";

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        rxDetails.set(0,"8");
        Thread.sleep(240000);


        ServiceResponse serRes = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "");
        GetRxFormResponse getRxFormResponse = serRes.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serRes.getStatusCode());
        Assert.assertEquals("Error code did not match", errorCode, getRxFormResponse.getRxSigForms().get(0).getError().getCode());
    }

    @Test(description = "Validate error retrieving all forms when correct rxFillId are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormV2InvalidRxFillId(String errorCode, int statusCode, String storeNo) throws InterruptedException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String caregiverDOB = "12121998";

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        rxDetails.set(1,"1");
       Thread.sleep(240000);


        ServiceResponse serRes = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "");
        GetRxFormResponse getRxFormResponse = serRes.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serRes.getStatusCode());
        Assert.assertEquals("Error code did not match", errorCode, getRxFormResponse.getRxSigForms().get(0).getError().getCode());
    }

    @Test(description = "Validate retrieving all forms when correct rxNumber and rxFillId are passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormV2ValidRxs(int statusCode, String storeNo) throws InterruptedException {


        ArrayList<String> rxDetails = new ArrayList<>();
        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String caregiverDOB = "12121998";

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));

        // Step - 3: Set up test data for get Rx Form
        ArrayList<String> rxDetails1 = new ArrayList<>();

        // Step - 5: Create Rx with Autofill flow and move till Pickup
        rxDetails1 = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));

        rxDetails.addAll(rxDetails1);
        Thread.sleep(360000);

        ServiceResponse serRes = consentOrchestratorWrapper.getRxResponseMultipleForms(storeNo, rxDetails, "");
        Assert.assertEquals("Status code did not match", statusCode, serRes.getStatusCode());
    }

    @Test(description = "Validate retrieving all forms when correct rxNumber and incorrect rxFillId are passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandSaveRxFormV2MixesResponseRxs(int statusCode, String storeNo) throws InterruptedException {

        ArrayList<String> rxDetails = new ArrayList<>();
        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        String caregiverDOB = "12121998";

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        rxDetails.set(0,"8");
        // Step - 3: Set up test data for get Rx Form
        ArrayList<String> rxDetails1 = new ArrayList<>();
        // Step - 5: Create Rx with Autofill flow and move till Pickup
        rxDetails1 = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        rxDetails.addAll(rxDetails1);
        Thread.sleep(360000);
        ServiceResponse serRes = consentOrchestratorWrapper.getRxResponseMultipleForms(storeNo, rxDetails, "");
        Assert.assertEquals("Status code did not match", statusCode, serRes.getStatusCode());
    }


    @Test(description = "Validate Reconstituted form when correct rxNumber and rxFillId are passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveReconstitutedFormValidTest_1(int statusCode, String caregiverDOB, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String storeNo, String signatureTypeCodeMedicaid, String cardHolderId) throws InterruptedException {


       // Step - 1: Creating patients for consent test
       String caregiverEmail = CommonUtil.generateRandomEmailId(10);
       String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
       String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

       List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);

       String caregiver_cid = caregiverDetails.get(0);
       Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

       // Step - 2: Create Rx with Switch to Cash flow and move till Pickup
       ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_SwitchToCash_RAndR(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo), "00143988701");
       Thread.sleep(240000);

        // Step - 4: Validate getMedicaid Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3900");
        GetRxFormResponse getMedicaidFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);

       Assert.assertEquals("Status code did not match", statusCode, serResMedicaid.getStatusCode());
       int noOfRAndR= getMedicaidFormResponse.getRxSigForms().size();
       Assert.assertEquals(noOfRAndR, 1);
       Assert.assertEquals(rxDetails.get(0), getMedicaidFormResponse.getRxSigForms().get(0).getRxNumber());
       Assert.assertEquals(rxDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getRxFillId());
       Assert.assertEquals(caregiverDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getPatientId().toString());
       Assert.assertEquals(signatureTypeCodeMedicaid, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode().toString());
       Assert.assertEquals(true, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());
   }

    @Test(description = "Validate Refrigerated form when correct rxNumber and rxFillId are passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveRefrigeratedFormValidTest_1(int statusCode, String caregiverDOB, String insuranceCarrierPlanId, String insuranceCarrierCompanyId, String cardHolderId, String storeNo, String signatureTypeCodeMedicaid) throws InterruptedException {


        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_WithTP(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo, Integer.parseInt(insuranceCarrierPlanId), Integer.parseInt(insuranceCarrierCompanyId), cardHolderId);

        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Switch to Cash flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_SwitchToCash_RAndR(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo), "00169643910");
        Thread.sleep(240000);

        // Step - 4: Validate getMedicaid Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3900");
        GetRxFormResponse getMedicaidFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);

        Assert.assertEquals("Status code did not match", statusCode, serResMedicaid.getStatusCode());
        int noOfRAndR= getMedicaidFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRAndR, 1);
        Assert.assertEquals(rxDetails.get(0), getMedicaidFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), getMedicaidFormResponse.getRxSigForms().get(0).getPatientId().toString());
        Assert.assertEquals(signatureTypeCodeMedicaid, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode().toString());
        Assert.assertEquals(true, getMedicaidFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());
    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge lilly", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveLillyFormValidTestWithoutTenantIdAndLob_1(String caregiverDOB, String statusCode, String formIdLilly, String formVrsnNbrLilly, String signatureTypeCodeLilly, String storeNo, String ndc) throws InterruptedException, IOException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Lilly flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.createRxDetailsForLillyConsent(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo),0, "00074055402");
        Thread.sleep(240000);
        // Step - 4: Validate getMedicaid Form
        ServiceResponse serResLilly = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        GetRxFormResponse getLillyFormResponse = serResLilly.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serResLilly.getStatusCode());
        int noOfLillyForm = getLillyFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfLillyForm, 1);
        Assert.assertEquals(rxDetails.get(0), getLillyFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getLillyFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), getLillyFormResponse.getRxSigForms().get(0).getPatientId().toString());
        Assert.assertEquals(formIdLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId().toString());
        Assert.assertEquals(formVrsnNbrLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr().toString());
        Assert.assertEquals(signatureTypeCodeLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode().toString());
        Assert.assertEquals(true, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        //Step - 5: Hit Get Form API again and the response is from cosmos
        ServiceResponse serResLilly2 = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        Assert.assertEquals("Status code did not match", String.valueOf(serResLilly2.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResLilly2.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(false, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        // Step - 6: Save Lilly Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveMedicaid("3915", formIdLilly, formVrsnNbrLilly, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        // Step - 7: Hit Get Form API again and check it is not asked again
        ServiceResponse serResLilly3 = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        Assert.assertEquals("Status code did not match", String.valueOf(serResLilly3.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse1 = serResLilly3.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm1 = getRxFormResponse1.getRxSigForms().get(0).getSignatureTypes().size();
        Assert.assertEquals(noOfRxForm1, 0);

    }

    @Test(description = "Validate On add to cart an Rx requires to acknowledge lilly With Tenant id and lob", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveLillyFormValidTestWithTenantIdAndLob_1(String caregiverDOB, String statusCode, String formIdLilly, String formVrsnNbrLilly, String signatureTypeCodeLilly, String storeNo, String ndc) throws InterruptedException, IOException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Lilly flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.createRxDetailsForLillyConsent(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo),0, "00074055402");
        Thread.sleep(240000);
        // Step - 4: Validate getMedicaid Form
        ServiceResponse serResLilly = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        GetRxFormResponse getLillyFormResponse = serResLilly.getDataResponse(GetRxFormResponse.class);
        Assert.assertEquals("Status code did not match", statusCode, serResLilly.getStatusCode());
        int noOfLillyForm = getLillyFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfLillyForm, 1);
        Assert.assertEquals(rxDetails.get(0), getLillyFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getLillyFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), getLillyFormResponse.getRxSigForms().get(0).getPatientId().toString());
        Assert.assertEquals(formIdLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId().toString());
        Assert.assertEquals(formVrsnNbrLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr().toString());
        Assert.assertEquals(signatureTypeCodeLilly, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode().toString());
        Assert.assertEquals(true, getLillyFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        //Step - 5: Hit Get Form API again and the response is from cosmos
        ServiceResponse serResLilly2 = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        Assert.assertEquals("Status code did not match", String.valueOf(serResLilly2.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResLilly2.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForm, 1);
        Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
        Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
        Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
        Assert.assertEquals(formIdLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbrLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCodeLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(false, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        // Step - 6: Save Lilly Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveLillyWithTenantIdAndLobHeaders("3915", formIdLilly, formVrsnNbrLilly, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        // Step - 7: Hit Get Form API again and check it is not asked again
        ServiceResponse serResLilly3 = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915");
        Assert.assertEquals("Status code did not match", String.valueOf(serResLilly3.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse1 = serResLilly3.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm1 = getRxFormResponse1.getRxSigForms().get(0).getSignatureTypes().size();
        Assert.assertEquals(noOfRxForm1, 0);

    }


    @Test(description = "Validate On add to cart an Rx requires to acknowledge auto fill enrollment and Lilly Consent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveRxFormV2")
    public void getandsaveAutofillAndLillyFormValidTest_1(String caregiverDOB, String statusCode, String formIdAutofill, String formVrsnNbrAutofill, String formIdLilly, String formVrsnNbrLilly, String storeNo, String enrolledStatus, String ndc) throws InterruptedException, IOException {

        // Step - 1: Creating patients for consent test
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Create Rx with Autofill flow and move till Pickup
        ArrayList<String> rxDetails = digitalPharmacyOperationsUtil.CreateRxsForPatient_Autofill(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo));
        Thread.sleep(240000);
        ServiceResponse serviceResponse = consentOrchestratorWrapper.autofillEnrollment(storeNo, rxDetails.get(0));
        consentOrchestratorWrapper.updateAutofillEnrollmentStatus(Integer.parseInt(storeNo), Integer.parseInt(rxDetails.get(2)));
        // Step - 3: Create Rx with Lilly flow and move till Pickup
        ArrayList<String> rxDetails1 = digitalPharmacyOperationsUtil.createRxDetailsForLillyConsent(Integer.parseInt(caregiverDetails.get(1)), Integer.parseInt(storeNo),0, "00074055402");
        Thread.sleep(240000);


        // Step - 4: Validate getAutofill and Lilly Form
        ServiceResponse serResMedicaid = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3914,3915");
        Assert.assertEquals("Status code did not match", String.valueOf(serResMedicaid.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse = serResMedicaid.getDataResponse(GetRxFormResponse.class);
        int noOfRxForms = getRxFormResponse.getRxSigForms().size();
        Assert.assertEquals(noOfRxForms, 2);
        for (int i = 0; i < noOfRxForms; i++) {
            if (getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode().equals("3915")) {
                Assert.assertEquals(rxDetails1.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
                Assert.assertEquals(rxDetails1.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
                Assert.assertEquals(caregiverDetails.get(1), String.valueOf(getRxFormResponse.getRxSigForms().get(0).getPatientId()));
                Assert.assertEquals(formIdLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormId());
                Assert.assertEquals(formVrsnNbrLilly, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormVrsnNbr());
                Assert.assertEquals("3915", getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode());
            } else {
                Assert.assertEquals(rxDetails.get(0), getRxFormResponse.getRxSigForms().get(0).getRxNumber());
                Assert.assertEquals(rxDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getRxFillId());
                Assert.assertEquals(caregiverDetails.get(1), getRxFormResponse.getRxSigForms().get(0).getPatientId().toString());
                Assert.assertEquals(formIdAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormId().toString());
                Assert.assertEquals(formVrsnNbrAutofill, getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getFormVrsnNbr().toString());
                Assert.assertEquals("3914", getRxFormResponse.getRxSigForms().get(0).getSignatureTypes().get(i).getSignatureTypeCode().toString());
            }
        }

        // Step-5 save Rx For Autofill
        ServiceResponse serResSaveAutofill = consentOrchestratorWrapper.saveAutofill("3914", formIdAutofill, formVrsnNbrAutofill, caregiverDetails.get(0), Integer.parseInt(rxDetails.get(0)), storeNo, enrolledStatus);
        Assert.assertEquals("Status code did not match", serResSaveAutofill.getStatusCode(), 202);
        Thread.sleep(120000);

        // Step - 6: Save Lilly Form - Accept
        ServiceResponse serResSaveMedicaid = consentOrchestratorWrapper.saveLillyWithTenantIdAndLobHeaders("3915", formIdLilly, formVrsnNbrLilly, rxDetails.get(1), storeNo, caregiverDetails.get(0), caregiverDetails.get(1));
        Assert.assertEquals("Status code did not match", serResSaveMedicaid.getStatusCode(), 202);

        // Step - 7: Hit Get Form API again and check it is not asked again
        ServiceResponse serResLilly3 = consentOrchestratorWrapper.getMedicaidFormV2(storeNo, rxDetails, "3915,3914");
        Assert.assertEquals("Status code did not match", String.valueOf(serResLilly3.getStatusCode()), statusCode);
        GetRxFormResponse getRxFormResponse1 = serResLilly3.getDataResponse(GetRxFormResponse.class);
        int noOfRxForm1 = getRxFormResponse1.getRxSigForms().get(0).getSignatureTypes().size();
        Assert.assertEquals(noOfRxForm1, 0);

    }
}

