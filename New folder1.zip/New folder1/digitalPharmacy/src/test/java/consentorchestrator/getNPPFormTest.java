package consentorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.cpr.GetCPRPatientData;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.savenpp.SaveNPPErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.savenpp.SaveNppResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.List;

public class getNPPFormTest {
    ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();

    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    @Test(description = "validate get NPP Form api when headers are not passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNPPFormNegativeTest_1(String caregiverDOB, int statusCode, String errorCode, String storenumber) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm_withoutHeaders(caregiver_cid);
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);


    }

    @Test(description = "validate get NPP Form api when invalid headers are passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNPPFormNegativeTest_2(String caregiverDOB, int statusCode, String errorCode, String storenumber) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm_withoutHeaders(caregiver_cid);
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);


    }


    @Test(description = "validate get NPP Form api when invalid cid is passed", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNPPFormNegativeTest_3(int statusCode, String errorCode, String storenumber) throws InterruptedException {

        String caregiver_cid = "1234";


        // Step - 1: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormErrorResponse getNPPFormErrorResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);

        // Step - 2: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 3: Validate patient details and fill details
        Assert.assertEquals(getNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormValidTest_1(String caregiverDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and fill details
        Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(0).getFirstName());
        Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(0).getLastName());
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Assert.assertEquals(type, getNPPFormResponse.getPatientSigForms().get(0).getType());
        Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getFormId());
        Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getSignatureTypeCode());
        Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(0).getSignatureTypes().get(0).getRelationshipRequired());

        // Step 5 : Get the Customer and Patient ID from the NPP response
        String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Integer SaveNPPPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
            }

        }
        //  Step  6 Call the Save NPP with CustomerID and PatientID
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, getNPPFormResponse.getPatientSigForms().get(0).getStoreNumber(), Customer, SaveNPPPatientId);
        SaveNppResponse saveNppResponse = serRes1.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again
        Thread.sleep(10000);

        ServiceResponse serRes2 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes2.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);
        Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(0).getSignatureTypes().size());


    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form for ADULT dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormValidTest_3(String caregiverDOB, String adultDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> dependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = dependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        Integer SaveNPPAdultPatientId = null;

        String storeNo = null;


        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();


            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPAdultPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();

            }
        }

        //  Step  6 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Adult(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId, SaveNPPAdultPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form for Minor dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormValidTest_2(String caregiverDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        Integer SaveNPPMinorPatientId = null;

        String storeNo = null;


        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();


            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPMinorPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();

            }
        }

        //  Step  6 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId, SaveNPPMinorPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }


    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form for ADULT dependent and minor dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormValidTest_4(String caregiverDOB, String adultDependentDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultdependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependetDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultdependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = adultDependetDetails.get(0);
        Reporter.logJSON("Adult dependent Customer Account Id", adultDependent_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 3);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        Integer SaveNPPMinorPatientId = null;
        Integer SaveNPPAdultPatientId = null;
        String storeNo = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();


            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPMinorPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();

            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPAdultPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();

            }
        }
        //  Step  6 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Adult_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId, SaveNPPMinorPatientId, SaveNPPAdultPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }


    @Test(description = "validate get NPP Form api when valid headers are passed with patient having pet dependents", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNPPForm_Pet(String caregiverDOB, String minorDependentDOB, int statusCode, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String petEmail = CommonUtil.generateRandomEmailId(10);
        String petFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String petLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> petDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_pet(petEmail, petFirstName, petLastName, minorDependentDOB, storenumber);
        String petDependent_cid = petDependentDetails.get(0);
        Reporter.logJSON("pet Customer Account Id", petDependent_cid);


        consentOrchestratorWrapper.caAddDependent(caregiver_cid, petDependent_cid, DependentInfo.TypeEnum.PET, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals("PET form should not be returned", noOfNPPForm, 1);


    }

    @Test(description = "validate Save NPP Form api when valid headers are passed and null Customer  Account ID ", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void saveNPP_Negative_scenario_1(String caregiverDOB, int statusCode, String errorCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException {

        Integer SaveNPPPatientId = 126334881;
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_NegativeScenario1(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, SaveNPPPatientId);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate Save NPP Form api when valid headers are passed and null patientId and storeId is passed ", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void saveNPP_Negative_scenario_3(int statusCode, String errorCode, String payload) throws InterruptedException {

        Integer SaveNPPPatientId = 126334881;
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_NegativeScenario3(payload);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode); //status code should be 400 for this case, it will be fixed in customer pilot
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate Save NPP Form api when valid headers are passed and patientId and storeId doesnot belong to the cid ", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void saveNPP_Negative_scenario_4(int statusCode, String errorCode, String payload) throws InterruptedException {

        Integer SaveNPPPatientId = 126334881;
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_NegativeScenario3(payload);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate Save NPP Form api when valid headers are passed and null Customer  Account is Invalid ", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void saveNPP_Negative_scenario_2(String caregiverDOB, int statusCode, String errorCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException {

        Integer SaveNPPPatientId = 126334881;
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_NegativeScenario2(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, SaveNPPPatientId);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form for ADULT dependent when Adult is logged in", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormValidTest_5(String caregiverDOB, String adultDependentDOB, int statusCode, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);


        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        Thread.sleep(5000);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        Integer SaveNPPAdultPatientId = null;

        String storeNo = null;


        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();


            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPAdultPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();

            }
        }

        //  Step  6 Call the Save NPP with CustomerID and PatientID

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, adultDependent_cid, SaveNPPAdultPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        Thread.sleep(5000);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again


        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);


        for (int j = 0; j < noOfNPPForm; j++) {

            if (getNPPFormResponse.getPatientSigForms().get(j).getType().equals("ADULT"))
                Assert.assertEquals("Saved NPP Form should not be returned again for ADULT dependent", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());

            else if (getNPPFormResponse.getPatientSigForms().get(j).getType().equals("SELF"))
                Assert.assertEquals("Saved NPP Form should be returned again for CAREGIVER", 1, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());


        }


    }


//    @Test(description = "validate getNPP and saveNPP for Minor Dependent Turning HIPAA Legal Age", dataProviderClass = DataProvider.class, dataProvider = "getData")
//    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
//    public void getNsaveNPPFormValidTest_6(String caregiverDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {
//
//        // Step - 1: Setting and logging fill ID's to make the respective calls
//        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
//        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
//        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
//        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
//        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
//        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
//
//        List<String> caregiverDetails = dpOpsUtils.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
//        String caregiver_cid = caregiverDetails.get(0);
//        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
//
//        List<String> minorDependentDetails = dpOpsUtils.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
//        String minorDependent_cid = minorDependentDetails.get(0);
//        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);
//
//        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);
//
//
//        // Step - 2: Calling getNPP API with customerId
//        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
//        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);
//
//        // Step - 3: Validate status code
//        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);
//
//        // Step - 4: Validate patient details and form details
//        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
//
//        Assert.assertEquals(noOfNPPForm, 2);
//        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
//        Integer SaveNPPPatientId = null;
//        Integer SaveNPPMinorPatientId = null;
//
//        String storeNo = null;
//
//
//        for (int i = 0; i < noOfNPPForm; i++) {
//
//            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
//                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
//                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
//                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
//                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
//                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
//                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
//                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
//
//
//            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("MINOR")) {
//                Assert.assertEquals(minorDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
//                Assert.assertEquals(minorDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
//                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
//                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
//                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
//                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
//                SaveNPPMinorPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
//                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();
//
//            }
//        }
//
//        //  Step  6 Call the Save NPP with CustomerID and PatientID
//
//        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
//
//        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId, SaveNPPMinorPatientId);
//        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);
//
//
//        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);
//
//        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again
//
//        Thread.sleep(5000);
//
//        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
//        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);
//
//        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
//
//        for (int j = 0; j < noOfNPPForm; j++) {
//            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
//        }
//
//
//        //Step 8: Update dob of minor to legal age
//        consentOrchestratorWrapper.updateDOBofMinor(Integer.parseInt(storeNo), SaveNPPMinorPatientId);
//
//        //Step 9: Calling getNPP again as minor is now of legal age
//        ServiceResponse serRes4 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
//        GetNPPFormResponse getNPPFormResponse2 = serRes4.getDataResponse(GetNPPFormResponse.class);
//
//        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);
//
//        for (int j = 0; j < noOfNPPForm; j++) {
//
//            if (getNPPFormResponse.getPatientSigForms().get(j).getType().equals("MINOR"))
//                Assert.assertEquals("Saved NPP Form should not be returned again", 1, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
//        }
//
//
//    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp form is denied", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormDenyTest(String caregiverDOB, int statusCode, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);


        // Step - 1: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 2: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 3: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 1);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;

        String storeNo = null;


        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();

            }
        }

        //  Step  4 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 5: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }

    @Test(description = "validate get NPP Form api when valid hxeaders are passed and then save npp form is denied for dependents", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormDenyTestForDependents(String caregiverDOB, String adultDependentDOB, String minorDependentDOB, int statusCode, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultdependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependetDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultdependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = adultDependetDetails.get(0);
        Reporter.logJSON("Adult dependent Customer Account Id", adultDependent_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 3);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        Integer SaveNPPMinorPatientId = null;
        Integer SaveNPPAdultPatientId = null;
        String storeNo = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();


            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPMinorPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();

            } else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependentFirstName, getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPAdultPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();

            }
        }
        //  Step  6 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Adult_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId, SaveNPPMinorPatientId, SaveNPPAdultPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }


    @Test(description = "validate get NPP Form api for Spanish  and then save npp form for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormSpanishTest_1(String caregiverDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate NPP language code
        Assert.assertEquals(languageCode, getNPPFormResponse.getPatientLocale());

        // Step 5 : Get the Customer and Patient ID from the NPP response
        String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Integer SaveNPPPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
            }

        }
        //  Step  6 Call the Save NPP with CustomerID and PatientID
        ServiceResponse serRes1 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, getNPPFormResponse.getPatientSigForms().get(0).getStoreNumber(), Customer, SaveNPPPatientId);
        SaveNppResponse saveNppResponse = serRes1.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again
        Thread.sleep(10000);

        ServiceResponse serRes2 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes2.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals(languageCode, getNPPFormResponse.getPatientLocale());
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);
        Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(0).getSignatureTypes().size());

    }

    @Test(description = "validate get NPP Form api for Spanish and then save npp form for Minor dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormSpanishTest_2(String caregiverDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Assert.assertEquals(languageCode, getNPPFormResponse.getPatientLocale());
        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());

        //  Step  5 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, customer_id, Integer.valueOf(caregiverDetails.get(1)), Integer.valueOf(minorDependentDetails.get(1)));
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 6: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        Assert.assertEquals(languageCode, getNPPFormResponse.getPatientLocale());

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }
    }

    @Test(description = "validate get NPP Form api for Spanish and then save npp form for ADULT dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormSpanishTest_3(String caregiverDOB, String adultDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> dependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = dependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Assert.assertEquals(languageCode,getNPPFormResponse.getPatientLocale());

        //  Step  5 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Adult(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, customer_id, Integer.valueOf(caregiverDetails.get(1)), Integer.valueOf(dependentDetails.get(1)));
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);


        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 6: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        Assert.assertEquals( languageCode,getNPPFormResponse1.getPatientLocale());

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }
    }

    @Test(description = "validate get NPP Form api for Spanish and then save npp form for multiple dependents Adult and Minor", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormSpanishTest_4(String caregiverDOB, String adultDependentDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultdependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependetDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultdependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storenumber);
        String adultDependent_cid = adultDependetDetails.get(0);
        Reporter.logJSON("Adult dependent Customer Account Id", adultDependent_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Assert.assertEquals(languageCode,getNPPFormResponse.getPatientLocale());
        Assert.assertEquals(noOfNPPForm, 3);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());

        //  Step  5 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Adult_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, customer_id, Integer.valueOf(caregiverDetails.get(1)), Integer.valueOf(minorDependentDetails.get(1)), Integer.valueOf(adultDependetDetails.get(1)));
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        Assert.assertEquals(languageCode,getNPPFormResponse.getPatientLocale());

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }


    }

    @Test(description = "validate get NPP Form api for Spanish and then save npp form for only dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getNsaveNPPFormSpanishTest_5(String caregiverDOB, String adultDependentDOB, String minorDependentDOB, int statusCode, String type, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail1 = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName1 = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName1 = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storenumber);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storenumber);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("Minor dependent Customer Account Id", minorDependent_cid);

        List<String> minorDependentDetails1 = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail1, minorDependentFirstName1, minorDependentLastName1, minorDependentDOB, storenumber);
        String minorDependent_cid1 = minorDependentDetails1.get(0);
        Reporter.logJSON("Minor dependent second Customer Account Id", minorDependent_cid1);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();
        Assert.assertEquals(languageCode,getNPPFormResponse.getPatientLocale());
        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());

        //  Step  5 Call the Save NPP with CustomerID and PatientID

        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();

        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, customer_id, Integer.valueOf(caregiverDetails.get(1)), Integer.valueOf(minorDependentDetails.get(1)));
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);

        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        Assert.assertEquals(languageCode,getNPPFormResponse.getPatientLocale());

        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }

        //Adding another dependent to the caregiver
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid1, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Calling getNPP API with customerId
        ServiceResponse serRes1 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse2 = serRes1.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Validate patient details and form details
        int noOfNPPForm1 = getNPPFormResponse2.getPatientSigForms().size();
        Assert.assertEquals(languageCode,getNPPFormResponse2.getPatientLocale());
        Assert.assertEquals(2, noOfNPPForm1);
        for(int k=0;k<noOfNPPForm1;k++) {
            if(getNPPFormResponse2.getPatientSigForms().get(k).getPatientId().equals(minorDependentDetails1.get(1))) {
                Assert.assertEquals(formId, getNPPFormResponse2.getPatientSigForms().get(k).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse2.getPatientSigForms().get(k).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse2.getPatientSigForms().get(k).getSignatureTypes().get(0).getSignatureTypeCode());
            }
        }
        Assert.assertEquals(caregiver_cid, getNPPFormResponse2.getGenericInfo().getOnlineCustomerID());

        //Call the Save NPP with CustomerID and PatientID
        ServiceResponse serRes4 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storenumber, customer_id, Integer.valueOf(caregiverDetails.get(1)), Integer.valueOf(minorDependentDetails1.get(1)));

        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), 202);

        // Invoke Get NPP API Again to validate the saved NPP form is not returned again
        Thread.sleep(5000);
        ServiceResponse serRes5 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse3 = serRes5.getDataResponse(GetNPPFormResponse.class);

        Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);
        Assert.assertEquals(languageCode,getNPPFormResponse3.getPatientLocale());

        for (int j = 0; j < noOfNPPForm1; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse3.getPatientSigForms().get(j).getSignatureTypes().size());
        }

    }

    @Test(description = "validate get NPP Form api when valid headers are passed for PET Caregiver", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPContract")
    public void getNsaveNPPFormValidTest_withPETCaregiver(String caregiverFirstName, String caregiverLastName, String caregiverCid, int statusCode) throws InterruptedException {

        Reporter.logJSON("Caregiver Customer Account Id", caregiverCid);

        // Step - 1: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiverCid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);

        // Step - 2: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 3: Validate patient details and fill details
        Assert.assertEquals(caregiverFirstName, getNPPFormResponse.getGenericInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getNPPFormResponse.getGenericInfo().getLastName());
        Assert.assertEquals(caregiverCid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Assert.assertEquals(0, getNPPFormResponse.getPatientSigForms().size());
    }

    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp with Closed or Virtual Store", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getSaveNPPFormValidForSelfForClosedOrVirtualStore(String caregiverDOB, int statusCode, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtilCaregiver =
                new DigitalPharmacyOperationsUtil(Integer.valueOf(storenumber),caregiverFirstName,caregiverLastName,caregiverDOB,0,caregiverEmail,"Test@1234");
        List<String> caregiverDetails = digitalPharmacyOperationsUtilCaregiver.testAccountCreationForVirtualStore();
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);


        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);
        System.out.println("ServiceResponse = " + serRes);
        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 1);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        String storeNo = null;

        for (int i = 0; i < noOfNPPForm; i++) {
            Assert.assertEquals(caregiverFirstName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
            Assert.assertEquals(caregiverLastName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getLastName());
            Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
            Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
            Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
            Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
            SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
            storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();
        }

        //  Step  6 Call the Save NPP with CustomerID and PatientID
        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_SELF(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again
        Thread.sleep(5000);
        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);
        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }

        // Step 8: Invoke CPR Patient data and Validate HIPAA ACK Should be against non-Virtual Store
        GetCPRPatientData cprPatientData = digitalPharmacyOperationsUtil.getCPRPatientData(String.valueOf(SaveNPPPatientId), storeNo);
        Assert.assertEquals(storenumber, cprPatientData.getHipaaAckInfo().getStoreNbr());
    }


    @Test(description = "validate get NPP Form api when valid headers are passed and then save npp for Self and Dependent with Closed or Virtual Store", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorData.xlsx", sheetName = "getNPPForm")
    public void getSaveNPPFormValidForSelfAndDependentForClosedOrVirtualStore(String caregiverDOB, String minorDependentDOB, int statusCode, String formId, String formVrsnNbr, String signatureTypeCode, String status, String languageCode, String createdSource, String lasturl, String storenumber) throws InterruptedException, IOException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        Integer saveNppAdultPatientId = 0;

        DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtilCaregiver =
                new DigitalPharmacyOperationsUtil(Integer.valueOf(storenumber),caregiverFirstName,caregiverLastName,caregiverDOB,0,caregiverEmail,"Test@1234");

        List<String> caregiverDetails = digitalPharmacyOperationsUtilCaregiver.testAccountCreationForVirtualStore();
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);


        DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtilDependent =
                new DigitalPharmacyOperationsUtil(Integer.valueOf(storenumber),adultDependentFirstName,adultDependentLastName,minorDependentDOB,0,adultDependentEmail,"Test@1234");

        List<String> caregiverDetails_adult = digitalPharmacyOperationsUtilDependent.testAccountCreationForVirtualStore();
        String adultDependent_cid = caregiverDetails_adult.get(0);
        Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

        // Step - 1 (a): Adding Adult Dependent to the Caregiver account
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getNPP API with customerId
        ServiceResponse serRes = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse = serRes.getDataResponse(GetNPPFormResponse.class);
        System.out.println("ServiceResponse = " + serRes);
        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        int noOfNPPForm = getNPPFormResponse.getPatientSigForms().size();

        Assert.assertEquals(noOfNPPForm, 2);
        Assert.assertEquals(caregiver_cid, getNPPFormResponse.getGenericInfo().getOnlineCustomerID());
        Integer SaveNPPPatientId = null;
        String storeNo = null;

        for (int i = 0; i < noOfNPPForm; i++) {
            if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("SELF")) {
                Assert.assertEquals(caregiverFirstName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(caregiverLastName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                SaveNPPPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();
            }
            else if (getNPPFormResponse.getPatientSigForms().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(adultDependentFirstName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName.toUpperCase(), getNPPFormResponse.getPatientSigForms().get(i).getLastName());
                Assert.assertEquals(formId, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormId());
                Assert.assertEquals(formVrsnNbr, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getFormVrsnNbr());
                Assert.assertEquals(signatureTypeCode, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getSignatureTypeCode());
                Assert.assertEquals(true, getNPPFormResponse.getPatientSigForms().get(i).getSignatureTypes().get(0).getRelationshipRequired());
                saveNppAdultPatientId = getNPPFormResponse.getPatientSigForms().get(i).getPatientId();
                storeNo = getNPPFormResponse.getPatientSigForms().get(i).getStoreNumber();

            }
        }

        //  Step  6 Call the Save NPP with CustomerID and PatientID
        String customer_id = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        ServiceResponse serRes2 = consentOrchestratorWrapper.saveNPP_Minor(signatureTypeCode, formId, formVrsnNbr, status, languageCode, createdSource, lasturl, storeNo, customer_id, SaveNPPPatientId,saveNppAdultPatientId);
        SaveNppResponse saveNppResponse = serRes2.getDataResponse(SaveNppResponse.class);
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), 202);

        // Step 7: Invoke Get NPP API Again to validate the saved NPP form is not returned again
        Thread.sleep(5000);
        ServiceResponse serRes3 = consentOrchestratorWrapper.getNPPForm(caregiver_cid);
        GetNPPFormResponse getNPPFormResponse1 = serRes3.getDataResponse(GetNPPFormResponse.class);
        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);
        for (int j = 0; j < noOfNPPForm; j++) {
            Assert.assertEquals("Saved NPP Form should not be returned again", 0, getNPPFormResponse1.getPatientSigForms().get(j).getSignatureTypes().size());
        }

        // Step 8: Invoke CPR Patient data and Validate HIPAA ACK Should be against non-Virtual Store
        GetCPRPatientData cprPatientData = digitalPharmacyOperationsUtil.getCPRPatientData(String.valueOf(SaveNPPPatientId), storeNo);
        Assert.assertEquals(storenumber, cprPatientData.getHipaaAckInfo().getStoreNbr());

        // Step 9: Invoke CPR Patient data and Validate HIPAA ACK Should be against non-Virtual Store for Adult Dependent
        GetCPRPatientData cprAdultPatientData = digitalPharmacyOperationsUtil.getCPRPatientData(String.valueOf(saveNppAdultPatientId), storeNo);
        Assert.assertEquals(storenumber, cprAdultPatientData.getHipaaAckInfo().getStoreNbr());
    }
}
