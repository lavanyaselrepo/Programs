package consentorchestrator;

import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.Type;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.customerConsents.*;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getEcomResponse.GetEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getSignedFormsResponse.GetSignedFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.CustomerConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.utilities.Retry;
import org.apache.commons.text.CaseUtils;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Consent Orchestrator Test Suite
 *
 * Coverage:
 *  - Fetch & save WHRI consents (statewise and legacy flows)
 *  - Invalid state transitions & metadata eligibility
 *  - Bulk save, invalid ids, empty payloads
 *  - ECOM get/save & signed forms PDF validation
 *  - Revoke flow
 *
 * Refactor Objectives (SOLID / DRY / Readability / Extensibility):
 *  1. Removed repeated customer creation & save logic (single-responsibility helpers)
 *  2. Centralized constants (states, waits, language)
 *  3. Added grouping (@Test groups) for selective execution (e.g., include/exclude statewise)
 *  4. Null-safe customer cloning & builder-style helper methods
 *  5. Clear, concise assertions & intent-revealing method names
 *  6. Reduced brittle Thread.sleep usage into waitFor() wrapper (still using sleep per original impl)
 *
 * To disable statewise-specific logic: -Dstatewise.tests.enabled=false
 */
public class GetAndSaveCustomerConsentsTests {

    // ---------------------------------------------------------------------
    // Configuration / Constants
    // ---------------------------------------------------------------------
    private static final String DEFAULT_LANGUAGE_CODE = "101";
    private static final String STATE_FL = "FL"; // Legacy static state from original assertions
    private static final String STATE_AR = "AR"; // Example eligible state
    private static final String STATE_AL = "AL"; // Example eligible state
    private static final String STATE_CT = "CT"; // Ineligible (whriEligible=false)
    private static final long SAVE_PROPAGATION_WAIT_MS = 2000L;
    private static final long ECOM_PROPAGATION_WAIT_MS = 5000L;


    // ---------------------------------------------------------------------
    // Dependencies
    // ---------------------------------------------------------------------
    private final CustomerConsentWrapper consentWrapper = new CustomerConsentWrapper();
    private final GetandSaveEcomWrapper consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();
    private final ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
    private final DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
    @SuppressWarnings("unused")
    private final ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    // ---------------------------------------------------------------------
    // Test Cases
    // ---------------------------------------------------------------------

    @Test(description = "validate get WHRI Form api when valid headers are passed and then SaveWHRI for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveWHRISuccess(String caregiverDOB, int statusCode, String status, String formId, String storeNo, boolean statewiseEnabled) throws InterruptedException, IOException {
        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        Customer initialCustomer = fetchCustomerConsents(ctx.customerAccountId, formId, statusCode);

        if (statewiseEnabled) {
            assertBaseCustomer(initialCustomer, ctx);
            Assert.assertTrue("Customer forms should be empty.", initialCustomer.getForms().isEmpty());
            // Save each form individually with ACCEPT in AR
            for (String fid : splitCsv(formId)) {
                saveSingleStatewiseConsent(ctx, fid, ConsentStatus.ACCEPT, STATE_AR, statusCode);
            }
            Customer afterSave = fetchCustomerConsents(ctx.customerAccountId, formId, statusCode);
            assertAllForms(afterSave, ConsentStatus.ACCEPT, STATE_AR);

            // Mixed update: add DENY(AR) + ACCEPT(AL)
            List<Form> mixed = new ArrayList<>();
            for (String fid : splitCsv(formId)) mixed.add(buildForm(fid, ConsentStatus.DENY, STATE_AR));
            for (String fid : splitCsv(formId)) mixed.add(buildForm(fid, ConsentStatus.ACCEPT, STATE_AL));
            saveBulkConsents(ctx, mixed, statusCode);

            Customer afterMixed = fetchCustomerConsents(ctx.customerAccountId, formId, statusCode);
            long alAccept = afterMixed.getForms().stream()
                    .filter(f -> STATE_AL.equals(f.getState()) && f.getConsentStatus() == ConsentStatus.ACCEPT)
                    .count();
            Assert.assertEquals("AL ACCEPT forms count mismatch", splitCsv(formId).size(), alAccept);
        } else {
            // Legacy branch retained (forms were previously returned UNSIGNED then updated to ACCEPT in FL)
            List<String> formIds = initialCustomer.getForms().stream().map(Form::getFormId).collect(Collectors.toList());
            for (String fid : formIds) {
                saveSingleNonStatewiseConsent(initialCustomer, ctx.customerAccountId, fid, ConsentStatus.ACCEPT, statusCode);
            }
            Customer finalCustomer = fetchCustomerConsents(ctx.customerAccountId, formId, statusCode);
            assertAllForms(finalCustomer, ConsentStatus.ACCEPT, STATE_FL);
        }
        Reporter.logJSON("WHRI save flow completed for CustomerId", ctx.customerAccountId);
    }

    @Test(description = "Validate WHRI ineligible state for state switch case", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveAPISwitchValidStateToInvalidState(String caregiverDOB, int statusCode, String status, String formId, String storeNo, String errorCode, String errorMessage, boolean statewiseEnabled) throws InterruptedException, IOException {

        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        fetchCustomerConsents(ctx.customerAccountId, formId, 200); // initial fetch (empty expected)

        if (statewiseEnabled) {
            // Establish valid consents in AL first
            for (String fid : splitCsv(formId)) {
                saveSingleStatewiseConsent(ctx, fid, ConsentStatus.ACCEPT, STATE_AL, 200);
            }
            Customer existing = fetchCustomerConsents(ctx.customerAccountId, formId, 200);

            // Invalid batch: introduce ineligible CT + DENY previous AL
            List<Form> invalidBatch = new ArrayList<>();
            for (String fid : splitCsv(formId)) invalidBatch.add(buildForm(fid, ConsentStatus.ACCEPT, STATE_CT));
            for (String fid : splitCsv(formId)) invalidBatch.add(buildForm(fid, ConsentStatus.DENY, STATE_AL));

            ServiceResponse response = consentWrapper.saveCustomerConsent(buildCustomer(existing, ctx.customerAccountId, invalidBatch));
            CustomerConsentErrorResponse error = response.getDataResponse(CustomerConsentErrorResponse.class);
            Assert.assertEquals("Status code mismatch", statusCode, response.getStatusCode());
            Assert.assertEquals("Error code mismatch", errorCode, error.getError().getCode());
            Assert.assertEquals("Error message mismatch", errorMessage, error.getError().getMessage());
            waitFor(SAVE_PROPAGATION_WAIT_MS);
        }
    }

    @Test(description = "Save multiple consents in one request", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveMultipleConsents(String caregiverDOB, int statusCode, String status, String formId, String storeNo, String errorCode, String errorMessage) throws InterruptedException, IOException {

        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        List<Form> forms = splitCsv(formId).stream().map(fid -> buildForm(fid, ConsentStatus.ACCEPT, STATE_AR)).collect(Collectors.toList());
        ServiceResponse res = consentWrapper.saveCustomerConsent(baseCustomer(ctx, forms));
        CustomerConsentErrorResponse error = res.getDataResponse(CustomerConsentErrorResponse.class);
        Assert.assertEquals("Status code mismatch", statusCode, res.getStatusCode());
        Assert.assertEquals("Error code mismatch", errorCode, error.getError().getCode());
    }

    @Test(description = "Validate get Customer Consents Form api and should fail for Invalid FormIds", dataProviderClass = DataProvider.class,
            dataProvider = "getData", retryAnalyzer = Retry.class, groups = {"negative"})
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveWHRIShouldFailForInvalidFormId(String caregiverDOB, int statusCode, String status, String formId, String storeNo, String errorCode, String errorMessage) throws InterruptedException, IOException {
        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        ServiceResponse res = consentWrapper.getCustomerConsent(ctx.customerAccountId, formId);
        CustomerConsentErrorResponse getError = res.getDataResponse(CustomerConsentErrorResponse.class);
        Assert.assertEquals("Status code mismatch", statusCode, res.getStatusCode());
        Assert.assertEquals("Error code mismatch", errorCode, getError.getError().getCode());
        Assert.assertEquals("Error message mismatch", errorMessage, getError.getError().getMessage());

        // Save invalid formId
        List<Form> invalidForms = List.of(new Form("1234", null, null, ConsentStatus.ACCEPT));
        ServiceResponse saveInvalid = consentWrapper.saveCustomerConsent(baseCustomer(ctx, invalidForms));
        CustomerConsentErrorResponse saveError = saveInvalid.getDataResponse(CustomerConsentErrorResponse.class);
        Reporter.logJSON("Invalid consents form ids", invalidForms.get(0).getFormId());
        Assert.assertEquals("Status code mismatch", statusCode, saveInvalid.getStatusCode());
        Assert.assertEquals("Error code mismatch", errorCode, saveError.getError().getCode());

        // Wrong customer id
        CaregiverContext wrongCtx = new CaregiverContext(ctx.customerAccountId + "1", ctx.email, ctx.firstName, ctx.lastName, ctx.storeNo, ctx.dob);
        Customer wrongCustomer = baseCustomer(wrongCtx, List.of(new Form(formId.split(",")[0], null, null, ConsentStatus.ACCEPT)));
        ServiceResponse wrongSave = consentWrapper.saveCustomerConsent(wrongCustomer);
        CustomerConsentErrorResponse wrongError = wrongSave.getDataResponse(CustomerConsentErrorResponse.class);
        Reporter.logJSON("Invalid consents form ids", wrongCustomer.getForms().get(0).getFormId());
        Assert.assertEquals("Status code mismatch", 400, wrongSave.getStatusCode());
        Assert.assertEquals("Error code mismatch", "CHP-CONSORCH-1086", wrongError.getError().getCode());
    }

    @Test(description = "validate get Customer Consent for All Form api when valid headers are passed and then Save Customer Consent for self", dataProviderClass = DataProvider.class,
            dataProvider = "getData", retryAnalyzer = Retry.class, groups = {"ecom"})
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getAndSaveAllConsentFormValidTest(String caregiverDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo, String whriformId, boolean statewiseEnabled) throws InterruptedException, IOException {
        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);

        // GET ECOM
        ServiceResponse ecomRes = consentEcomOrchestratorWrapper.getEcom(ctx.customerAccountId);
        GetEcomResponse getEcom = ecomRes.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code mismatch", statusCode, ecomRes.getStatusCode());
        Assert.assertEquals(formId, getEcom.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcom.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcom.getPayload().getSignatureTypeCode());
        assertEcomCustomer(ctx, getEcom);

        // SAVE ECOM
        ServiceResponse saveEcomRes = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(
                getEcom.getPayload().getCustomerConsentInfo().getCustomerAccountId(),
                getEcom.getPayload().getSignatureTypeCode(),
                getEcom.getPayload().getFormId(),
                getEcom.getPayload().getFormVrsnNbr(),
                getEcom.getPayload().getCustomerConsentInfo().getAuthStoreNbr(),
                getEcom.getPayload().getCustomerConsentInfo().getAuthPatientId(), status);
        Assert.assertEquals("Status code mismatch", statusCode, saveEcomRes.getStatusCode());
        waitFor(ECOM_PROPAGATION_WAIT_MS);

        // Re-fetch ECOM
        ServiceResponse ecomRes2 = consentEcomOrchestratorWrapper.getEcom(ctx.customerAccountId);
        GetEcomResponse getEcom2 = ecomRes2.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals(statusCode, ecomRes2.getStatusCode());
        Assert.assertEquals(status, getEcom2.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        // Signed form PDF validation
        String type = "SELF";
        ServiceResponse signedRes = consentEcomOrchestratorWrapper.performGetSignedForms(ctx.firstName, ctx.lastName, "", type, ctx.customerAccountId, false);
        Assert.assertEquals(200, signedRes.getStatusCode());
        GetSignedFormResponse signed = signedRes.getDataResponse(GetSignedFormResponse.class);
        Assert.assertEquals(
                CaseUtils.toCamelCase(ctx.firstName, true, '_') + "_" +
                        CaseUtils.toCamelCase(ctx.lastName, true, '_') + "_" + type.toLowerCase(),
                signed.getSignedFileInfo().getName());
        String caregiverName = CaseUtils.toCamelCase(ctx.firstName, true, ' ') + " " + CaseUtils.toCamelCase(ctx.lastName, true, ' ');
        Assert.assertTrue("customer name mismatch in PDF", consentEcomOrchestratorWrapper.Base64ToPDF(signed.getSignedFileInfo().getContent(), List.of(caregiverName)));

        // Fetch WHRI consents (expected empty)
        Customer whriCustomer = fetchCustomerConsents(ctx.customerAccountId, whriformId, statusCode);
        if (statewiseEnabled) {
            Assert.assertTrue("Customer forms should be empty.", whriCustomer.getForms().isEmpty());
            assertBaseCustomer(whriCustomer, ctx);
        }

        // Re-fetch to ensure stability (no changes expected)
        Customer after = fetchCustomerConsents(ctx.customerAccountId, whriformId, statusCode);
        assertBaseCustomer(after, ctx);
    }

    @Test(description = "validate states where WHRI State is Eligible and not eligible", dataProviderClass = DataProvider.class,
            dataProvider = "getData", retryAnalyzer = Retry.class, groups = {"metadata"})
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveWHRIMetaData(int statusCode){
        ServiceResponse res = consentWrapper.getConsentMetaData();
        Assert.assertEquals("Status code mismatch", statusCode, res.getStatusCode());
        Assert.assertEquals("Response status mismatch", "OK", res.getStatusDesc());
        Assert.assertTrue("Missing states metadata", res.getDataResponse().contains("states"));
        Assert.assertFalse("Data response unexpectedly empty", res.getDataResponse().isEmpty());
        Assert.assertTrue("CT whriEligible false missing", res.getDataResponse().contains("\"code\":\"CT\",\"whriEligible\":false"));
        Assert.assertTrue("CO whriEligible false missing", res.getDataResponse().contains("\"code\":\"CO\",\"whriEligible\":false"));
        Assert.assertTrue("NV whriEligible false missing", res.getDataResponse().contains("\"code\":\"NV\",\"whriEligible\":false"));
        Assert.assertTrue("WA whriEligible false missing", res.getDataResponse().contains("\"code\":\"WA\",\"whriEligible\":false"));
        Assert.assertTrue("AL whriEligible true missing", res.getDataResponse().contains("\"code\":\"AL\",\"whriEligible\":true"));
        Assert.assertTrue("CA whriEligible true missing", res.getDataResponse().contains("\"code\":\"CA\",\"whriEligible\":true"));
        Assert.assertTrue("TX whriEligible true missing", res.getDataResponse().contains("\"code\":\"TX\",\"whriEligible\":true"));
    }

    @Test(description = "Validate get Customer Consents Form api and should fail for Empty Forms", dataProviderClass = DataProvider.class,
            dataProvider = "getData", retryAnalyzer = Retry.class, groups = {"negative"})
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveWHRIShouldFailFormEmpty(String caregiverDOB, int statusCode, String status, String formId, String storeNo, String errorCode, String errorMessage) throws InterruptedException, IOException {
        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        Customer emptyRequest = baseCustomer(ctx, new ArrayList<>());
        ServiceResponse res = consentWrapper.saveCustomerConsent(emptyRequest);
        CustomerConsentErrorResponse err = res.getDataResponse(CustomerConsentErrorResponse.class);
        Assert.assertEquals("Status code mismatch", statusCode, res.getStatusCode());
        Assert.assertEquals("Error code mismatch", errorCode, err.getError().getCode());
    }

    @Test(description = "validate get WHRI Form api when valid headers are passed and then SaveWHRI for self and revoke", dataProviderClass = DataProvider.class,
            dataProvider = "getData", retryAnalyzer = Retry.class, groups = {"revoke", "whri"})
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getAndSaveWHRI")
    public void getAndSaveThenRevokeSuccess(String caregiverDOB, int statusCode, String status, String formId, String storeNo, boolean statewiseEnabled) throws InterruptedException, IOException {
        CaregiverContext ctx = createCaregiver(storeNo, caregiverDOB);
        Customer customer = fetchCustomerConsents(ctx.customerAccountId, formId, 200);
        if (!statewiseEnabled) {
            // Legacy expectation of UNSIGNED forms
            Assert.assertTrue("Expected UNSIGNED form present", customer.getForms().stream().anyMatch(f -> f.getConsentStatus() == ConsentStatus.UNSIGNED));
        }
        assertBaseCustomer(customer, ctx);

        // Save ACCEPT for all currently returned forms (legacy only – statewise start empty)
        List<String> formIds = customer.getForms().stream().map(Form::getFormId).collect(Collectors.toList());
        for (String fid : formIds) {
            saveSingleNonStatewiseConsent(customer, ctx.customerAccountId, fid, ConsentStatus.ACCEPT, statusCode);
        }
        Customer afterSave = fetchCustomerConsents(ctx.customerAccountId, formId, 200);
        if (!afterSave.getForms().isEmpty()) {
            assertAllForms(afterSave, ConsentStatus.ACCEPT, STATE_FL);
        }

        // Revoke all
        ServiceResponse revokeRes = consentWrapper.revokeCustomerConsent(ctx.customerAccountId);
        Assert.assertEquals("Status code mismatch", statusCode, revokeRes.getStatusCode());

        Customer afterRevoke = fetchCustomerConsents(ctx.customerAccountId, formId, 200);
        if (!afterRevoke.getForms().isEmpty()) {
            Assert.assertTrue("All forms should be DENY after revoke", afterRevoke.getForms().stream().allMatch(f -> f.getConsentStatus() == ConsentStatus.DENY));
            Assert.assertTrue("State should remain FL", afterRevoke.getForms().stream().allMatch(f -> STATE_FL.equals(f.getState())));
        }
    }

    // ---------------------------------------------------------------------
    // Helper Methods
    // ---------------------------------------------------------------------

    private CaregiverContext createCaregiver(String storeNo, String dob) throws IOException, InterruptedException {
        String email = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String lastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        new DigitalPharmacyOperationsUtil(Integer.valueOf(storeNo), firstName, lastName, dob, 0, email, "Test@1234");
        List<String> details = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(email, firstName, lastName, dob, storeNo);
        String cid = details.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", cid);
        return new CaregiverContext(cid, email, firstName, lastName, storeNo, dob);
    }

    private List<String> splitCsv(String csv) { return List.of(csv.split(",")); }

    private Customer fetchCustomerConsents(String customerAccountId, String formId, int expectedStatus) {
        ServiceResponse res = consentWrapper.getCustomerConsent(customerAccountId, formId);
        Assert.assertEquals("Status code mismatch", expectedStatus, res.getStatusCode());
        return res.getDataResponse(GetCustomerConsentsResponse.class).getPayload().getCustomer();
    }

    private void saveSingleStatewiseConsent(CaregiverContext ctx, String formId, ConsentStatus status, String state, int expectedStatus) throws InterruptedException {
        Form f = buildForm(formId, status, state);
        Customer customer = baseCustomer(ctx, List.of(f));
        ServiceResponse res = consentWrapper.saveCustomerConsent(customer);
        Assert.assertEquals("Status code mismatch", expectedStatus, res.getStatusCode());
        waitFor(SAVE_PROPAGATION_WAIT_MS);
    }

    private void saveSingleNonStatewiseConsent(Customer base, String customerAccountId, String formId, ConsentStatus consentStatus, int expectedStatus) throws InterruptedException {
        base.getForms().stream().filter(f -> Objects.equals(f.getFormId(), formId)).forEach(f -> f.setConsentStatus(consentStatus));
        Customer temp = createCustomer(base, customerAccountId, formId);
        ServiceResponse res = consentWrapper.saveCustomerConsent(temp);
        Assert.assertEquals("Status code mismatch", expectedStatus, res.getStatusCode());
        waitFor(SAVE_PROPAGATION_WAIT_MS);
    }

    private void saveBulkConsents(CaregiverContext ctx, List<Form> forms, int expectedStatus) throws InterruptedException {
        Customer c = baseCustomer(ctx, forms);
        ServiceResponse res = consentWrapper.saveCustomerConsent(c);
        Assert.assertEquals("Status code mismatch", expectedStatus, res.getStatusCode());
        waitFor(SAVE_PROPAGATION_WAIT_MS);
    }

    private void assertAllForms(Customer customer, ConsentStatus status, String state) {
        Assert.assertTrue("Consent status mismatch", customer.getForms().stream().allMatch(f -> f.getConsentStatus() == status));
        Assert.assertTrue("State mismatch", customer.getForms().stream().allMatch(f -> state.equals(f.getState())));
    }

    private void assertBaseCustomer(Customer customer, CaregiverContext ctx) {
        Assert.assertEquals(ctx.customerAccountId, customer.getCustomerAccountId());
        Assert.assertEquals(ctx.firstName, customer.getFirstName());
        Assert.assertEquals(ctx.lastName, customer.getLastName());
        Assert.assertEquals(Type.ADULT, customer.getType());
    }

    private void assertEcomCustomer(CaregiverContext ctx, GetEcomResponse resp) {
        Assert.assertEquals(ctx.customerAccountId, resp.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(ctx.firstName, resp.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(ctx.lastName, resp.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(ctx.email, resp.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", resp.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals(DEFAULT_LANGUAGE_CODE, resp.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    }

    private Form buildForm(String formId, ConsentStatus status, String state) {
        return Form.builder().formId(formId).consentStatus(status).state(state).build();
    }

    private Customer baseCustomer(CaregiverContext ctx, List<Form> forms) {
        Customer c = new Customer();
        c.setCustomerAccountId(ctx.customerAccountId);
        c.setFirstName(ctx.firstName);
        c.setLastName(ctx.lastName);
        c.setType(Type.ADULT);
        c.setForms(forms);
        c.setPatientLocale(DEFAULT_LANGUAGE_CODE);
        return c;
    }

    // Null-safe: if formId == null retain all forms
    private Customer createCustomer(Customer baseCustomer, String customerAccountId, String formId) {
        Customer customer = new Customer();
        customer.setCustomerAccountId(customerAccountId);
        customer.setFirstName(baseCustomer.getFirstName());
        customer.setLastName(baseCustomer.getLastName());
        customer.setType(baseCustomer.getType());
        if (formId == null) {
            customer.setForms(baseCustomer.getForms());
        } else {
            customer.setForms(baseCustomer.getForms().stream()
                    .filter(form -> form.getFormId() != null && form.getFormId().equalsIgnoreCase(formId))
                    .collect(Collectors.toList()));
        }
        customer.setDependentConsentInfos(baseCustomer.getDependentConsentInfos());
        customer.setPatientLocale(baseCustomer.getPatientLocale());
        customer.setMiddleName(baseCustomer.getMiddleName());
        return customer;
    }

    // New helper: clone base customer but override customerAccountId & full forms list
    private Customer buildCustomer(Customer baseCustomer, String customerAccountId, List<Form> forms) {
        Customer customer = new Customer();
        customer.setCustomerAccountId(customerAccountId);
        customer.setFirstName(baseCustomer.getFirstName());
        customer.setLastName(baseCustomer.getLastName());
        customer.setType(baseCustomer.getType());
        // If forms list passed is null, retain existing; else set provided
        if (forms == null) {
            customer.setForms(baseCustomer.getForms());
        } else {
            customer.setForms(forms);
        }
        customer.setDependentConsentInfos(baseCustomer.getDependentConsentInfos());
        customer.setPatientLocale(baseCustomer.getPatientLocale());
        customer.setMiddleName(baseCustomer.getMiddleName());
        return customer;
    }

    private void waitFor(long millis) throws InterruptedException { Thread.sleep(millis); }

    // Immutable context holder
    private static class CaregiverContext {
        final String customerAccountId; final String email; final String firstName; final String lastName; final String storeNo; final String dob;
        CaregiverContext(String customerAccountId, String email, String firstName, String lastName, String storeNo, String dob) {
            this.customerAccountId = customerAccountId; this.email = email; this.firstName = firstName; this.lastName = lastName; this.storeNo = storeNo; this.dob = dob;
        }
    }
}