package consentorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.customerConsents.Customer;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getAdultEcom.GetAdultEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getEcomResponse.GetEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.saveEcom.SaveEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.sendAdultEcommConsent.SendAdultEcommConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.validateDOB.ValidateDOBResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.CustomerConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class revokeCustomerConsentsTests {
  GetandSaveEcomWrapper consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();
  CustomerConsentWrapper customerConsentWrapper = new CustomerConsentWrapper();
  ConsentOrchestratorWrapper consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
  DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
  ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

  @Test(
      description = "revoke Consent For self and Multiple Caregiver",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData",
      retryAnalyzer = Retry.class)
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
      sheetName = "revokeConsent")
  public void revokeRequest_MultipleCaregiver(
      String caregiver1DOB,
      String caregiver2DOB,
      String adultDependentDOB,
      int statusCode,
      String storeNo,
      String status,
      String newStatus,
      String formId,
      String formVrsnNbr,
      String signatureTypeCode)
      throws InterruptedException, IOException {

    // Step - 1: Setting and logging fill ID's to make the respective calls
    String caregiver1Email = CommonUtil.generateRandomEmailId(10);
    String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String caregiver2Email = CommonUtil.generateRandomEmailId(10);
    String caregiver2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String caregiver2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
    String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

    List<String> caregiver1Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);

    String caregiver_cid1 = caregiver1Details.get(0);
    Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

    List<String> caregiver2Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            caregiver2Email, caregiver2FirstName, caregiver2LastName, caregiver2DOB, storeNo);
    String caregiver_cid2 = caregiver2Details.get(0);
    Reporter.logJSON("Caregiver2 Customer Account Id", caregiver_cid2);

    List<String> adultDependentDetails =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            adultDependentEmail,
            adultDependentFirstName,
            adultDependentLastName,
            adultDependentDOB,
            storeNo);
    String adultDependent_cid = adultDependentDetails.get(0);
    Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

    consentOrchestratorWrapper.caAddDependent(
        caregiver_cid1,
        adultDependent_cid,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    consentOrchestratorWrapper.caAddDependent(
        caregiver_cid2,
        adultDependent_cid,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    // Step -2: Calling getEcomm for caregiver1 and caregiver2
    ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes1 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse1 = serRes1.getDataResponse(GetEcomResponse.class);

    // Step - 3: Validate status code
    Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

    // Step - 4: Validate patient details and form details for caregiver 1 and caregiver 2
    Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
    Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
    Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

    Assert.assertEquals(
        caregiver_cid1,
        getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
    Assert.assertEquals(
        caregiver1FirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
    Assert.assertEquals(
        caregiver1LastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
    Assert.assertEquals(
        caregiver1Email, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
    Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
    Assert.assertEquals(
        "101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    Assert.assertEquals(
        "English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
    Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertNull(
        getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

    Assert.assertEquals(formId, getEcomResponse1.getPayload().getFormId());
    Assert.assertEquals(formVrsnNbr, getEcomResponse1.getPayload().getFormVrsnNbr());
    Assert.assertEquals(signatureTypeCode, getEcomResponse1.getPayload().getSignatureTypeCode());

    Assert.assertEquals(
        caregiver_cid2,
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCustomerAccountId());
    Assert.assertEquals(
        caregiver2FirstName, getEcomResponse1.getPayload().getCustomerConsentInfo().getFirstName());
    Assert.assertEquals(
        caregiver2LastName, getEcomResponse1.getPayload().getCustomerConsentInfo().getLastName());
    Assert.assertEquals(
        caregiver2Email, getEcomResponse1.getPayload().getCustomerConsentInfo().getEmailId());
    Assert.assertEquals("ADULT", getEcomResponse1.getPayload().getCustomerConsentInfo().getType());
    Assert.assertEquals(
        "101", getEcomResponse1.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    Assert.assertEquals(
        "English", getEcomResponse1.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
    Assert.assertNull(
        getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertNull(
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

    // checking values for caregiver:1
    int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

    for (int i = 0; i < noOfDependent; i++) {
      if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
        Assert.assertEquals(
            adultDependent_cid,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
        Assert.assertEquals(
            adultDependentFirstName,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
        Assert.assertEquals(
            adultDependentLastName,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
        Assert.assertEquals(
            adultDependentEmail,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
        Assert.assertEquals(
            "101",
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
        Assert.assertEquals(
            "English",
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
        Assert.assertNull(
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
        Assert.assertNull(
            getEcomResponse
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getCaregiverAuthorization());
      }
    }

    // checking values for caregiver:2
    int noOfDependent1 = getEcomResponse1.getPayload().getDependentConsentInfo().size();

    for (int i = 0; i < noOfDependent1; i++) {
      if (getEcomResponse1
          .getPayload()
          .getDependentConsentInfo()
          .get(i)
          .getType()
          .equals("ADULT")) {
        Assert.assertEquals(
            adultDependent_cid,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
        Assert.assertEquals(
            adultDependentFirstName,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getFirstName());
        Assert.assertEquals(
            adultDependentLastName,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getLastName());
        Assert.assertEquals(
            adultDependentEmail,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getEmailId());
        Assert.assertEquals(
            "101",
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
        Assert.assertEquals(
            "English",
            getEcomResponse1
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getLanguage()
                .getDescr());
        Assert.assertNull(
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
        Assert.assertNull(
            getEcomResponse1
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getCaregiverAuthorization());
      }
    }

    // Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request For Caregiver 1
    String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
    String FormId = getEcomResponse.getPayload().getFormId();
    String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
    String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId = null;
    String SaveEcomAdultAccountId = null;

    for (int i = 0; i < noOfNPPForm; i++) {

      if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

        SaveEcomAdultPatientId =
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
        SaveEcomAdultAccountId =
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
      }
    }

    ServiceResponse serRes2 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer,
            SignatureTypeCode,
            FormId,
            FormVrsnNbr,
            StoreNbr,
            PatientId,
            status,
            SaveEcomAdultPatientId);

    SaveEcomResponse saveEcomResponse = serRes2.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);

    // Step : 6 Fetch the response from Get Ecom to pass to the Save Ecom Request For Caregiver 2
    String Customer1 =
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode1 = getEcomResponse1.getPayload().getSignatureTypeCode();
    String FormId1 = getEcomResponse1.getPayload().getFormId();
    String FormVrsnNbr1 = getEcomResponse1.getPayload().getFormVrsnNbr();
    String StoreNbr1 = getEcomResponse1.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId1 = getEcomResponse1.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm1 = getEcomResponse1.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId1 = null;

    for (int i = 0; i < noOfNPPForm1; i++) {

      if (getEcomResponse1
          .getPayload()
          .getDependentConsentInfo()
          .get(i)
          .getType()
          .equals("ADULT")) {
        SaveEcomAdultPatientId1 =
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
      }
    }
    ServiceResponse serRes3 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer1,
            SignatureTypeCode1,
            FormId1,
            FormVrsnNbr1,
            StoreNbr1,
            PatientId1,
            status,
            SaveEcomAdultPatientId1);

    SaveEcomResponse saveEcomResponse2 = serRes3.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

    // Step 7 Trigger Validate DOB to validate the dob of adult dependent
    ServiceResponse serRes4 =
        consentEcomOrchestratorWrapper.validateDOB(
            adultDependent_cid, adultDependentDOB, caregiver_cid1);
    ValidateDOBResponse validateDOBResponse = serRes4.getDataResponse(ValidateDOBResponse.class);

    Assert.assertEquals(serRes4.getStatusCode(), statusCode);
    Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), true);

    // Step 8 Trigger Validate DOB to validate the dob of adult dependent
    ServiceResponse serRes5 =
        consentEcomOrchestratorWrapper.validateDOB(
            adultDependent_cid, adultDependentDOB, caregiver_cid2);
    ValidateDOBResponse validateDOBResponse1 = serRes5.getDataResponse(ValidateDOBResponse.class);

    Assert.assertEquals(serRes5.getStatusCode(), statusCode);
    Assert.assertEquals(validateDOBResponse1.getPayload().isValidDob(), true);

    // Step 9 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes6 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid, caregiver_cid1);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse =
        serRes6.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes6.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

    // Step 10 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes7 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid, caregiver_cid2);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse1 =
        serRes7.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes7.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse1.getPayload().getStatus());

    // Step 11 : Get  Adult Dependent
    ServiceResponse serRes8 =
        consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
    GetAdultEcomResponse getAdultEcomResponse = serRes8.getDataResponse(GetAdultEcomResponse.class);
    Assert.assertEquals(serRes8.getStatusCode(), statusCode);
    Assert.assertEquals(
        getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getCustomerAccountId(),
        caregiver_cid1);
    Assert.assertEquals(
        getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getFirstName(),
        caregiver1FirstName);
    Assert.assertEquals(
        getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getLastName(),
        caregiver1LastName);
    Assert.assertEquals(
        getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getEmailId(),
        caregiver1Email);

    // Step 12: Invoke saveEcomm for adult dependent

    ServiceResponse serRes9 =
        consentEcomOrchestratorWrapper.SaveEcom_AdultDependent(
            adultDependent_cid,
            SignatureTypeCode,
            FormId,
            FormVrsnNbr,
            StoreNbr,
            PatientId,
            status,
            SaveEcomAdultPatientId);

    SaveEcomResponse saveEcomResponse1 = serRes9.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes9.getStatusCode(), statusCode);

    // Step 13 invoke getEcomm again to check the response after adult has given consent

    Thread.sleep(5000);

    ServiceResponse serRes10 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse2 = serRes10.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes11 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse3 = serRes11.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes10.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes11.getStatusCode(), statusCode);
    Assert.assertEquals(
        status, getEcomResponse2.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse2.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse2.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        status, getEcomResponse3.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse3.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse3.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    // Calling revoke
    ServiceResponse serviceResponse =
        customerConsentWrapper.revokeCustomerConsent(adultDependent_cid);
    Assert.assertEquals("Status code did not match", serviceResponse.getStatusCode(), statusCode);

    // After Calling revoke Call should status as DENY

    Thread.sleep(5000);

    ServiceResponse serRes12 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse4 = serRes12.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes13 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse5 = serRes13.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes12.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes13.getStatusCode(), statusCode);
    Assert.assertEquals(
        newStatus,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse5.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse5.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
  }

  @Test(
      description = "revoke Consent For self and Multiple Caregiver and Multiple Dependents",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData",
      retryAnalyzer = Retry.class)
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
      sheetName = "revokeConsent")
  public void revokeRequest_MultipleCaregiverAndMultipleDependents(
      String caregiver1DOB,
      String caregiver2DOB,
      String adultDependentDOB,
      String adultDependentDOB1,
      String adultDependentDOB2,
      int statusCode,
      String storeNo,
      String status,
      String newStatus,
      String formId,
      String formVrsnNbr,
      String signatureTypeCode)
      throws InterruptedException, IOException {
    // Step - 1: Setting and logging fill ID's to make the respective calls
    String caregiver1Email = CommonUtil.generateRandomEmailId(10);
    String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String caregiver2Email = CommonUtil.generateRandomEmailId(10);
    String caregiver2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String caregiver2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
    String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String adultDependentEmail1 = CommonUtil.generateRandomEmailId(10);
    String adultDependentFirstName1 = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String adultDependentLastName1 = CommonUtil.generateRandomLastName(10).toUpperCase();
    String adultDependentEmail2 = CommonUtil.generateRandomEmailId(10);
    String adultDependentFirstName2 = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String adultDependentLastName2 = CommonUtil.generateRandomLastName(10).toUpperCase();

    // Caregiver 1
    List<String> caregiver1Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
    String caregiver_cid1 = caregiver1Details.get(0);
    Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

    // Caregiver 2
    List<String> caregiver2Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            caregiver2Email, caregiver2FirstName, caregiver2LastName, caregiver2DOB, storeNo);
    String caregiver_cid2 = caregiver2Details.get(0);
    Reporter.logJSON("Caregiver2 Customer Account Id", caregiver_cid2);

    // Adult Dependent
    List<String> adultDependentDetails =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            adultDependentEmail,
            adultDependentFirstName,
            adultDependentLastName,
            adultDependentDOB,
            storeNo);
    String adultDependent_cid = adultDependentDetails.get(0);
    Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

    // Adult Dependent 1
    List<String> adultDependentDetails1 =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            adultDependentEmail1,
            adultDependentFirstName1,
            adultDependentLastName1,
            adultDependentDOB1,
            storeNo);
    String adultDependent_cid1 = adultDependentDetails1.get(0);
    Reporter.logJSON("Adult Dependent Customer Account Id1", adultDependent_cid1);

    // Adult Dependent 2
    List<String> adultDependentDetails2 =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            adultDependentEmail2,
            adultDependentFirstName2,
            adultDependentLastName2,
            adultDependentDOB2,
            storeNo);
    String adultDependent_cid2 = adultDependentDetails2.get(0);
    Reporter.logJSON("Adult Dependent Customer Account Id2", adultDependent_cid2);

    consentOrchestratorWrapper.caAddDependent(
        caregiver_cid1,
        adultDependent_cid,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    consentOrchestratorWrapper.caAddDependent(
        caregiver_cid2,
        adultDependent_cid,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    consentOrchestratorWrapper.caAddDependent(
        adultDependent_cid,
        adultDependent_cid1,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    consentOrchestratorWrapper.caAddDependent(
        adultDependent_cid,
        adultDependent_cid2,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    // Step -2: Calling getEcomm for caregiver1 and caregiver2
    ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes1 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse1 = serRes1.getDataResponse(GetEcomResponse.class);

    // Step - 3: Validate status code
    Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

    // Step - 4: Validate patient details and form details for caregiver 1 and caregiver 2
    Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
    Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
    Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

    Assert.assertEquals(
        caregiver_cid1,
        getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
    Assert.assertEquals(
        caregiver1FirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
    Assert.assertEquals(
        caregiver1LastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
    Assert.assertEquals(
        caregiver1Email, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
    Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
    Assert.assertEquals(
        "101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    Assert.assertEquals(
        "English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
    Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertNull(
        getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

    Assert.assertEquals(formId, getEcomResponse1.getPayload().getFormId());
    Assert.assertEquals(formVrsnNbr, getEcomResponse1.getPayload().getFormVrsnNbr());
    Assert.assertEquals(signatureTypeCode, getEcomResponse1.getPayload().getSignatureTypeCode());

    Assert.assertEquals(
        caregiver_cid2,
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCustomerAccountId());
    Assert.assertEquals(
        caregiver2FirstName, getEcomResponse1.getPayload().getCustomerConsentInfo().getFirstName());
    Assert.assertEquals(
        caregiver2LastName, getEcomResponse1.getPayload().getCustomerConsentInfo().getLastName());
    Assert.assertEquals(
        caregiver2Email, getEcomResponse1.getPayload().getCustomerConsentInfo().getEmailId());
    Assert.assertEquals("ADULT", getEcomResponse1.getPayload().getCustomerConsentInfo().getType());
    Assert.assertEquals(
        "101", getEcomResponse1.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    Assert.assertEquals(
        "English", getEcomResponse1.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
    Assert.assertNull(
        getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertNull(
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

    // checking values for caregiver:1
    int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

    for (int i = 0; i < noOfDependent; i++) {
      if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
        Assert.assertEquals(
            adultDependent_cid,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
        Assert.assertEquals(
            adultDependentFirstName,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
        Assert.assertEquals(
            adultDependentLastName,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
        Assert.assertEquals(
            adultDependentEmail,
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
        Assert.assertEquals(
            "101",
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
        Assert.assertEquals(
            "English",
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
        Assert.assertNull(
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
        Assert.assertNull(
            getEcomResponse
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getCaregiverAuthorization());
      }
    }

    // checking values for caregiver:2
    int noOfDependent2 = getEcomResponse1.getPayload().getDependentConsentInfo().size();

    for (int i = 0; i < noOfDependent2; i++) {
      if (getEcomResponse1
          .getPayload()
          .getDependentConsentInfo()
          .get(i)
          .getType()
          .equals("ADULT")) {
        Assert.assertEquals(
            adultDependent_cid,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
        Assert.assertEquals(
            adultDependentFirstName,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getFirstName());
        Assert.assertEquals(
            adultDependentLastName,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getLastName());
        Assert.assertEquals(
            adultDependentEmail,
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getEmailId());
        Assert.assertEquals(
            "101",
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
        Assert.assertEquals(
            "English",
            getEcomResponse1
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getLanguage()
                .getDescr());
        Assert.assertNull(
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
        Assert.assertNull(
            getEcomResponse1
                .getPayload()
                .getDependentConsentInfo()
                .get(i)
                .getCaregiverAuthorization());
      }
    }

    // Check no of dependents data
    ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
    GetEcomResponse getEcomResponse2 = serRes3.getDataResponse(GetEcomResponse.class);

    // Step - 3: Validate status code
    Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

    // Step - 4: Validate patient details and form details for caregiver 1 and caregiver 2
    Assert.assertEquals(formId, getEcomResponse2.getPayload().getFormId());
    Assert.assertEquals(formVrsnNbr, getEcomResponse2.getPayload().getFormVrsnNbr());
    Assert.assertEquals(signatureTypeCode, getEcomResponse2.getPayload().getSignatureTypeCode());

    Assert.assertEquals(
        adultDependent_cid,
        getEcomResponse2.getPayload().getCustomerConsentInfo().getCustomerAccountId());
    Assert.assertEquals(
        adultDependentFirstName,
        getEcomResponse2.getPayload().getCustomerConsentInfo().getFirstName());
    Assert.assertEquals(
        adultDependentLastName,
        getEcomResponse2.getPayload().getCustomerConsentInfo().getLastName());
    Assert.assertEquals(
        adultDependentEmail, getEcomResponse2.getPayload().getCustomerConsentInfo().getEmailId());
    Assert.assertEquals("ADULT", getEcomResponse2.getPayload().getCustomerConsentInfo().getType());
    Assert.assertEquals(
        "101", getEcomResponse2.getPayload().getCustomerConsentInfo().getLanguage().getCode());
    Assert.assertEquals(
        "English", getEcomResponse2.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
    Assert.assertNull(
        getEcomResponse2.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertNull(
        getEcomResponse2.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

    int noOfDependent3 = getEcomResponse2.getPayload().getDependentConsentInfo().size();

    // No of dependents
    Assert.assertEquals(2, noOfDependent3);

    // Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request For Caregiver 1
    String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
    String FormId = getEcomResponse.getPayload().getFormId();
    String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
    String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId = null;
    String SaveEcomAdultAccountId = null;

    for (int i = 0; i < noOfNPPForm; i++) {

      if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

        SaveEcomAdultPatientId =
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
        SaveEcomAdultAccountId =
            getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
      }
    }

    ServiceResponse serRes4 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer,
            SignatureTypeCode,
            FormId,
            FormVrsnNbr,
            StoreNbr,
            PatientId,
            status,
            SaveEcomAdultPatientId);

    SaveEcomResponse saveEcomResponse = serRes4.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);

    // Step : 6 Fetch the response from Get Ecom to pass to the Save Ecom Request For Caregiver 2
    String Customer1 =
        getEcomResponse1.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode1 = getEcomResponse1.getPayload().getSignatureTypeCode();
    String FormId1 = getEcomResponse1.getPayload().getFormId();
    String FormVrsnNbr1 = getEcomResponse1.getPayload().getFormVrsnNbr();
    String StoreNbr1 = getEcomResponse1.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId1 = getEcomResponse1.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm1 = getEcomResponse1.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId1 = null;

    for (int i = 0; i < noOfNPPForm1; i++) {

      if (getEcomResponse1
          .getPayload()
          .getDependentConsentInfo()
          .get(i)
          .getType()
          .equals("ADULT")) {
        SaveEcomAdultPatientId1 =
            getEcomResponse1.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
      }
    }
    ServiceResponse serRes5 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer1,
            SignatureTypeCode1,
            FormId1,
            FormVrsnNbr1,
            StoreNbr1,
            PatientId1,
            status,
            SaveEcomAdultPatientId1);

    SaveEcomResponse saveEcomResponse2 = serRes5.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);

    // Step : 6 Fetch the response from Get Ecom to pass to the Save Ecom Request For Caregiver 2
    String Customer2 =
        getEcomResponse2.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode2 = getEcomResponse2.getPayload().getSignatureTypeCode();
    String FormId2 = getEcomResponse2.getPayload().getFormId();
    String FormVrsnNbr2 = getEcomResponse2.getPayload().getFormVrsnNbr();
    String StoreNbr2 = getEcomResponse2.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId2 = getEcomResponse2.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm2 = getEcomResponse2.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId2 = null;
    String SaveEcomAdultPatientId3 = null;

    if (getEcomResponse2.getPayload().getDependentConsentInfo().get(0).getType().equals("ADULT")) {
      SaveEcomAdultPatientId2 =
          getEcomResponse2.getPayload().getDependentConsentInfo().get(0).getAuthPatientId();
    }
    if (getEcomResponse2.getPayload().getDependentConsentInfo().get(1).getType().equals("ADULT")) {
      SaveEcomAdultPatientId3 =
          getEcomResponse2.getPayload().getDependentConsentInfo().get(1).getAuthPatientId();
    }

    ServiceResponse serRes6 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer2,
            SignatureTypeCode2,
            FormId2,
            FormVrsnNbr2,
            StoreNbr2,
            PatientId2,
            status,
            SaveEcomAdultPatientId2);

    SaveEcomResponse saveEcomResponse6 = serRes6.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes6.getStatusCode(), statusCode);

    ServiceResponse serRes7 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer2,
            SignatureTypeCode2,
            FormId2,
            FormVrsnNbr2,
            StoreNbr2,
            PatientId2,
            status,
            SaveEcomAdultPatientId3);

    SaveEcomResponse saveEcomResponse7 = serRes7.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes7.getStatusCode(), statusCode);

    // Step 7 Trigger Validate DOB to validate the dob of adult dependent
    ServiceResponse serRes8 =
        consentEcomOrchestratorWrapper.validateDOB(
            adultDependent_cid, adultDependentDOB, caregiver_cid1);
    ValidateDOBResponse validateDOBResponse = serRes8.getDataResponse(ValidateDOBResponse.class);

    Assert.assertEquals(serRes8.getStatusCode(), statusCode);
    Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), true);

    // Step 8 Trigger Validate DOB to validate the dob of adult dependent
    ServiceResponse serRes9 =
        consentEcomOrchestratorWrapper.validateDOB(
            adultDependent_cid, adultDependentDOB, caregiver_cid2);
    ValidateDOBResponse validateDOBResponse2 = serRes9.getDataResponse(ValidateDOBResponse.class);

    Assert.assertEquals(serRes9.getStatusCode(), statusCode);
    Assert.assertEquals(validateDOBResponse2.getPayload().isValidDob(), true);

    // Step 9 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes10 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid, caregiver_cid1);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse =
        serRes10.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes10.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

    // Step 10 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes11 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid, caregiver_cid2);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse1 =
        serRes11.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes11.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse1.getPayload().getStatus());

    // Step 10 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes12 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid1, adultDependent_cid);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse2 =
        serRes12.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes12.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse2.getPayload().getStatus());

    // Step 10 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes13 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            adultDependent_cid2, adultDependent_cid);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse3 =
        serRes13.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes13.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse3.getPayload().getStatus());

    Thread.sleep(5000);

    ServiceResponse serRes14 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse3 = serRes14.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes15 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse4 = serRes15.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes14.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes15.getStatusCode(), statusCode);
    Assert.assertEquals(
        status, getEcomResponse3.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse3.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse3.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        status, getEcomResponse4.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    // Calling revoke
    ServiceResponse serviceResponse =
        customerConsentWrapper.revokeCustomerConsent(adultDependent_cid);
    Assert.assertEquals("Status code did not match", serviceResponse.getStatusCode(), statusCode);

    // After Calling revoke Call should status as DENY

    Thread.sleep(5000);

    ServiceResponse serRes16 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid1);
    GetEcomResponse getEcomResponse5 = serRes16.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes17 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid2);
    GetEcomResponse getEcomResponse6 = serRes17.getDataResponse(GetEcomResponse.class);

    ServiceResponse serRes18 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
    GetEcomResponse getEcomResponse7 = serRes18.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes16.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes17.getStatusCode(), statusCode);
    Assert.assertEquals("Status code did not match", serRes18.getStatusCode(), statusCode);
    Assert.assertEquals(
        newStatus,
        getEcomResponse5.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse5.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse6.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse6.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        newStatus, getEcomResponse7.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse7.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse7.getPayload().getDependentConsentInfo().get(1).getCaregiverAuthorization());
  }

  @Test(
      description = "revoke Consent For Multiple Dependent",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData",
      retryAnalyzer = Retry.class)
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
      sheetName = "revokeConsent")
  public void revokeRequest_ByDependentId(
      String caregiver1DOB,
      String caregiver2DOB,
      String adultDependentDOB,
      int statusCode,
      String storeNo,
      String status,
      String newStatus,
      String formId,
      String formVrsnNbr,
      String signatureTypeCode)
      throws InterruptedException, IOException {

    // Step - 1: Setting and logging fill ID's to make the respective calls
    String dependent1Email = CommonUtil.generateRandomEmailId(10);
    String dependent1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String dependent1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String dependent2Email = CommonUtil.generateRandomEmailId(10);
    String dependent2FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String dependent2LastName = CommonUtil.generateRandomLastName(10).toUpperCase();
    String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
    String adultDependentFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String adultDependentLastName = CommonUtil.generateRandomLastName(10).toUpperCase();

    List<String> dependent1Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            dependent1Email, dependent1FirstName, dependent1LastName, caregiver1DOB, storeNo);
    String dependent_cid1 = dependent1Details.get(0);
    Reporter.logJSON("Dependent 1 Customer Account Id", dependent_cid1);

    List<String> dependent2Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            dependent2Email, dependent2FirstName, dependent2LastName, caregiver2DOB, storeNo);
    String dependent_cid2 = dependent2Details.get(0);
    Reporter.logJSON("Dependent 2 Customer Account Id", dependent_cid2);

    List<String> adultDependentDetails =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            adultDependentEmail,
            adultDependentFirstName,
            adultDependentLastName,
            adultDependentDOB,
            storeNo);
    String adultDependent_cid = adultDependentDetails.get(0);
    Reporter.logJSON("Adult Dependent Customer Account Id", adultDependent_cid);

    consentOrchestratorWrapper.caAddDependent(
        adultDependent_cid,
        dependent_cid1,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    consentOrchestratorWrapper.caAddDependent(
        adultDependent_cid,
        dependent_cid2,
        DependentInfo.TypeEnum.ADULT,
        DependentInfo.LinkageStatusEnum.ACTIVE);

    // Step -2: Calling getEcomm for caregiver1 and caregiver2
    ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
    GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

    // Step - 3: Validate status code
    Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

    // Step - 4: Validate patient details and form details for caregiver 1 and caregiver 2

    // checking values for caregiver:1
    int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();
    Assert.assertEquals(2, noOfDependent);

    // Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request For Adult
    // Dependent 1
    String Customer2 = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
    String SignatureTypeCode2 = getEcomResponse.getPayload().getSignatureTypeCode();
    String FormId2 = getEcomResponse.getPayload().getFormId();
    String FormVrsnNbr2 = getEcomResponse.getPayload().getFormVrsnNbr();
    String StoreNbr2 = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
    String PatientId2 = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
    int noOfNPPForm2 = getEcomResponse.getPayload().getDependentConsentInfo().size();
    String SaveEcomAdultPatientId2 = null;
    String SaveEcomAdultPatientId3 = null;

    if (getEcomResponse.getPayload().getDependentConsentInfo().get(0).getType().equals("ADULT")) {
      SaveEcomAdultPatientId2 =
          getEcomResponse.getPayload().getDependentConsentInfo().get(0).getAuthPatientId();
    }
    if (getEcomResponse.getPayload().getDependentConsentInfo().get(1).getType().equals("ADULT")) {
      SaveEcomAdultPatientId3 =
          getEcomResponse.getPayload().getDependentConsentInfo().get(1).getAuthPatientId();
    }

    ServiceResponse serRes6 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer2,
            SignatureTypeCode2,
            FormId2,
            FormVrsnNbr2,
            StoreNbr2,
            PatientId2,
            status,
            SaveEcomAdultPatientId2);

    SaveEcomResponse saveEcomResponse6 = serRes6.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes6.getStatusCode(), statusCode);

    ServiceResponse serRes7 =
        consentEcomOrchestratorWrapper.SaveEcom_Adult(
            Customer2,
            SignatureTypeCode2,
            FormId2,
            FormVrsnNbr2,
            StoreNbr2,
            PatientId2,
            status,
            SaveEcomAdultPatientId3);

    SaveEcomResponse saveEcomResponse7 = serRes7.getDataResponse(SaveEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes7.getStatusCode(), statusCode);

    ServiceResponse serRes12 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            dependent_cid1, adultDependent_cid);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse2 =
        serRes12.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes12.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse2.getPayload().getStatus());

    // Step 10 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult
    // Dependent
    ServiceResponse serRes13 =
        consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(
            dependent_cid2, adultDependent_cid);
    SendAdultEcommConsentResponse sendAdultEcommConsentResponse3 =
        serRes13.getDataResponse(SendAdultEcommConsentResponse.class);

    Assert.assertEquals(serRes13.getStatusCode(), statusCode);
    Assert.assertEquals("success", sendAdultEcommConsentResponse3.getPayload().getStatus());

    // Step 13 invoke getEcomm again to check the response after adult has given consent

    Thread.sleep(5000);

    ServiceResponse serRes10 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
    GetEcomResponse getEcomResponse2 = serRes10.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes10.getStatusCode(), statusCode);
    Assert.assertEquals(
        status, getEcomResponse2.getPayload().getCustomerConsentInfo().getSelfAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse2.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        status,
        getEcomResponse2.getPayload().getDependentConsentInfo().get(1).getCaregiverAuthorization());

    // Calling revoke

    List<String> ids = Arrays.asList(dependent_cid1, dependent_cid2);
    Map<String, List<String>> map = new HashMap<>();
    map.put("dependentId", ids);
    ObjectMapper mapper = new ObjectMapper();
    String dependentIdsPayload = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(map);
    ServiceResponse serviceResponse =
        customerConsentWrapper.revokeCustomerConsentWithPayload(
            adultDependent_cid, dependentIdsPayload);
    Assert.assertEquals("Status code did not match", serviceResponse.getStatusCode(), statusCode);

    // After Calling revoke Call should status as DENY
    Thread.sleep(5000);

    ServiceResponse serRes11 = consentEcomOrchestratorWrapper.getEcom(adultDependent_cid);
    GetEcomResponse getEcomResponse4 = serRes11.getDataResponse(GetEcomResponse.class);

    Assert.assertEquals("Status code did not match", serRes11.getStatusCode(), statusCode);
    Assert.assertEquals(
        newStatus,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
    Assert.assertEquals(
        newStatus,
        getEcomResponse4.getPayload().getDependentConsentInfo().get(1).getCaregiverAuthorization());
  }


  @Test(
      description = "validate revoke consent for caregiver where no consent is provided",
      dataProviderClass = DataProvider.class,
      dataProvider = "getData",
      retryAnalyzer = Retry.class)
  @DataProviderArguments(
      filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
      sheetName = "revokeConsent")
  public void getAndSaveThenRevokeSuccessForNoConsent(
      String caregiver1DOB, int statusCode, String storeNo)
      throws InterruptedException, IOException {

    // Step - 1: Creating The Customer

    String caregiver1Email = CommonUtil.generateRandomEmailId(10);
    String caregiver1FirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
    String caregiver1LastName = CommonUtil.generateRandomLastName(10).toUpperCase();

    List<String> caregiver1Details =
        digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
            caregiver1Email, caregiver1FirstName, caregiver1LastName, caregiver1DOB, storeNo);
    String caregiver_cid1 = caregiver1Details.get(0);
    Reporter.logJSON("Caregiver1 Customer Account Id", caregiver_cid1);

    // Step - 2: Calling revoke
    ServiceResponse serviceResponse1 = customerConsentWrapper.revokeCustomerConsent(caregiver_cid1);

    // Step - 6: Validate status code
    Assert.assertEquals("Status code did not match", serviceResponse1.getStatusCode(), statusCode);
  }

  private Customer createCustomer(Customer baseCustomer, String customerAccountId, String formId) {
    Customer customer = new Customer();
    customer.setCustomerAccountId(customerAccountId);
    customer.setFirstName(baseCustomer.getFirstName());
    customer.setLastName(baseCustomer.getLastName());
    customer.setType(baseCustomer.getType());
    customer.setForms(
        baseCustomer.getForms().stream()
            .filter(form -> form.getFormId().equalsIgnoreCase(formId))
            .collect(Collectors.toList()));
    customer.setDependentConsentInfos(baseCustomer.getDependentConsentInfos());
    customer.setPatientLocale(baseCustomer.getPatientLocale());
    customer.setMiddleName(baseCustomer.getMiddleName());
    return customer;
  }
}
