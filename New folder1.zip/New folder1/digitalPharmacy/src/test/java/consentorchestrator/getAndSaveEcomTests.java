package consentorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NEntity;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.enums.P13NType;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.model.request.UpdateCustomerP13NRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountorchestrator.restapi.AccountOrchestratorRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getConsentRequest.CustomerInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getConsentRequest.GetConsentRequestResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.CustomerConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getAdultEcom.GetAdultEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getEcomResponse.GetEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getNPPResponse.GetNPPFormErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.getSignedFormsResponse.GetSignedFormResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.saveEcom.SaveEcomResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.savenpp.SaveNPPErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.sendAdultEcommConsent.SendAdultEcommConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.validateDOB.ValidateDOBErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.validateDOB.ValidateDOBResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.GetandSaveEcomWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.stream.Collectors;

public class getAndSaveEcomTests {

    private final GetandSaveEcomWrapper consentEcomOrchestratorWrapper;
    private final ConsentOrchestratorWrapper consentOrchestratorWrapper;
    private final ConnexusAPIManager connexusAPIManager;
    private final DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil;
    private final AccountOrchestratorRetrofit accountOrchestratorRetrofit;
    private final CustomerConsentWrapper customerConsentWrapper;

    private final String ACCEPT = "ACCEPT";

    public getAndSaveEcomTests() {
        digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
        accountOrchestratorRetrofit = new AccountOrchestratorRetrofit();
        consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
        consentEcomOrchestratorWrapper = new GetandSaveEcomWrapper();
        connexusAPIManager = new ConnexusAPIManager();
        customerConsentWrapper = new CustomerConsentWrapper();
    }

    @Test(description = "validate get Ecomm Form api when valid headers are passed and then SaveEcom for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_1(String caregiverDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, UnsupportedEncodingException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());


        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String customerAccountId = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(customerAccountId, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status);
        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        //Step 9: Validate the form content firstName, lastName and dob
        String type = "SELF";
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serRess.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse = serRess.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));


    }

    @Test(description = "validate get Ecom Form api when valid headers are passed and then SaveEcom for Adult", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_2(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    }

    @Test(description = "validate get Ecom Form api when valid headers are passed and then SaveEcom for Minor", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_3(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, IOException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    }


    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 when item of self is added and email verification", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_4(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());


    }


    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 when item of Adult dependent is added and Save Adult with getAdultEcommConsentRequest", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_5(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        String SaveEcomAdultAccountId = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                SaveEcomAdultAccountId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        //Step 6 Trigger Validate DOB to validate the dob of adult dependent
        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.validateDOB(adultDependent_cid, adultDependentDOB, caregiver_cid);
        ValidateDOBResponse validateDOBResponse = serRes2.getDataResponse(ValidateDOBResponse.class);

        Assert.assertEquals(serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), true);

        //Step 7 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult Dependent
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse = serRes3.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes3.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

        //Step 8 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getCustomerAccountId(), caregiver_cid);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getFirstName(), caregiverFirstName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getLastName(), caregiverLastName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getEmailId(), caregiverEmail);


        //Step 9 Invoke saveEcomm for adult dependent

        ServiceResponse serRes4 = consentEcomOrchestratorWrapper.SaveEcom_AdultDependent(adultDependent_cid, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse1 = serRes4.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);


        //Step 10 invoke getEcomm again to check the response after adult has given consent

        Thread.sleep(5000);

        ServiceResponse serRes5 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes5.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());


    }


    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 when item of Adult dependent is added and Save Adult with getAdultEcommConsentRequest with  patient Safety check for Self and Dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_6(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        String SaveEcomAdultAccountId = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                SaveEcomAdultAccountId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        //Step 6 Trigger Validate DOB to validate the dob of adult dependent
        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.validateDOB(adultDependent_cid, adultDependentDOB, caregiver_cid);
        ValidateDOBResponse validateDOBResponse = serRes2.getDataResponse(ValidateDOBResponse.class);

        Assert.assertEquals(serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), validateDOBResponse.getPayload().isValidDob());

        //Step 7 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult Dependent
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse = serRes3.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes3.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

        //Step 8 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getCustomerAccountId(), caregiver_cid);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getFirstName(), caregiverFirstName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getLastName(), caregiverLastName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getEmailId(), caregiverEmail);

        //Step 9 Invoke saveEcomm for adult dependent

        ServiceResponse serRes4 = consentEcomOrchestratorWrapper.SaveEcom_AdultDependent(adultDependent_cid, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse1 = serRes4.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);

        //Step 10 Invoke Get Adult Ecom
        ServiceResponse serRes7 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse1 = serRes7.getDataResponse(GetAdultEcomResponse.class);
        // Assert.assertEquals(status)
        //Step 11 invoke getEcomm again to check the response after adult has given consent
        Thread.sleep(5000);
        ServiceResponse serRes5 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes5.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

        //Step 12: Validate the form content firstName, lastName and dob -PatientSafety of DEPENDENT
        String type = "SELF";
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, "", type, adultDependentFirstName, adultDependentLastName, "", adultDependent_cid, caregiver_cid,false);
        GetSignedFormResponse getSignedFormResponse = serRes10.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(serRes10.getStatusCode(), 200);
        Assert.assertNotNull(getSignedFormResponse.getSignedFileInfo().getContent());
        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), adultDependentFirstName + "_" + adultDependentLastName + "_DEPENDENT_" + caregiverFirstName + "_" + caregiverLastName);
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        String dependentName = adultDependentFirstName + " " + adultDependentLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));
        al.add(WordUtils.capitalizeFully(dependentName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Validate the form content firstName, lastName and dob for SELF
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serRess.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse1 = serRess.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse1.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString1 = getSignedFormResponse1.getSignedFileInfo().getContent();
        String caregiverName1 = caregiverFirstName + " " + caregiverLastName;
        List<String> al1 = new ArrayList<>();
        al1.add(WordUtils.capitalizeFully(caregiverName1));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString1, al1));

        // Validate the form content firstName, lastName and dob for ADULT Dependent
        ServiceResponse serResss = consentEcomOrchestratorWrapper.performGetSignedForms(adultDependentFirstName, adultDependentLastName, "", type, adultDependent_cid, false);
        Assert.assertEquals(serResss.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse2 = serResss.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse2.getSignedFileInfo().getName().toUpperCase(), adultDependentFirstName + "_" + adultDependentLastName + "_" + type.toUpperCase());
        String inputString2 = getSignedFormResponse2.getSignedFileInfo().getContent();
        String adultdependent = adultDependentFirstName + " " + adultDependentLastName;
        List<String> al2 = new ArrayList<>();
        al2.add(WordUtils.capitalizeFully(adultdependent));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString2, al2));


    }


    @Test(description = "Validate if the getSigneddForms() API returns success code 200 when valid cid for caregiver and minor dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormValidTest_8(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String type, String storeNo) throws InterruptedException, IOException {


        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        String SaveEcomMinorAccountId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                //      SaveEcomMinorAccountId= getEcomResponse.payload.getDependentConsentInfo().get(i).customerAccountId;
            }
        }

        //Call the getSignedForm to validate no form is returned
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, "", type, minorDependentFirstName, minorDependentLastName, "", minorDependent_cid, caregiver_cid,false);
        Assert.assertEquals(serRess.getStatusCode(), 204);


        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes2.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
        String caregiverMiddlename = "null";
        String minorDependentMidllename = "null";

        //Validate the form content firstName, lastName and dob for DEPENDENT
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, caregiverMiddlename, type, minorDependentFirstName, minorDependentLastName, minorDependentMidllename, minorDependent_cid, caregiver_cid,false);
        GetSignedFormResponse getSignedFormResponse = serRes10.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(serRes10.getStatusCode(), 200);
        Assert.assertNotNull(getSignedFormResponse.getSignedFileInfo().getContent());
        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), minorDependentFirstName + "_" + minorDependentLastName + "_DEPENDENT_" + caregiverFirstName + "_" + caregiverLastName);
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        String dependentName = minorDependentFirstName + " " + minorDependentLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));
        al.add(WordUtils.capitalizeFully(dependentName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Validate the form content firstName, lastName and dob for SELF
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serRes3.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse1 = serRes3.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse1.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString1 = getSignedFormResponse1.getSignedFileInfo().getContent();
        String caregiverName1 = caregiverFirstName + " " + caregiverLastName;
        List<String> al1 = new ArrayList<>();
        al1.add(WordUtils.capitalizeFully(caregiverName1));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString1, al1));


    }

    @Test(description = "validate Save ecomm Form api when valid headers are passed and dependentId is not a valid dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcomNegative")
    public void getandsaveEcomFormNegativeTest_1(int statusCode, String errorCode, String payload, String cid) throws InterruptedException {

        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcomm_NegativeScenario1(payload, cid);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate Save ecomm Form api when valid headers are passed and storeId does not belong to patient", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcomNegative")
    public void getandsaveEcomFormNegativeTest_2(int statusCode, String errorCode, String payload, String cid) throws InterruptedException {

        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcomm_NegativeScenario1(payload, cid);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate Save ecomm Form api when valid headers are passed and formId, formversion, status, signatureType is passed as null", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcomNegative")
    public void getandsaveEcomFormNegativeTest_3(int statusCode, String errorCode, String payload, String cid) throws InterruptedException {

        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcomm_NegativeScenario1(payload, cid);
        SaveNPPErrorResponse SaveNPPFormErrorResponse = serRes1.getDataResponse(SaveNPPErrorResponse.class);
        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);
        Assert.assertEquals(SaveNPPFormErrorResponse.getError().getCode(), errorCode);
    }

    @Test(description = "validate get Ecom Form api when valid headers are passed and then SaveEcom for self as DENY", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormDENY_Self(String caregiverDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, UnsupportedEncodingException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());


        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String customerAccountId = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(customerAccountId, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status);
        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

    }

    @Test(description = "validate get Ecom Form api when valid headers are passed and then SaveEcom for self and minor as DENY", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormDENY_SelfMinor(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, IOException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    }

    @Test(description = "validate get Ecom Form api when valid headers are passed and then SaveEcom for self and adult as DENY", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormDENY_SelfAdult(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());


    }

    @Test(description = "validate get Ecom Form api when invalid cid is passed ", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getEcommInvalidCID(int statusCode, String errorCode) {


        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom("1234");
        GetNPPFormErrorResponse getEcomResponse = serRes.getDataResponse(GetNPPFormErrorResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);
        Assert.assertEquals("Error code did not match", getEcomResponse.getError().getCode(), errorCode);

    }

    @Test(description = "Validate dob when dob is not correct", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void validateDOB_FalseCase(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Trigger Validate DOB to validate the dob of adult dependent
        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.validateDOB(adultDependent_cid, "11112000", caregiver_cid);
        ValidateDOBErrorResponse validateDOBErrorResponse = serRes2.getDataResponse(ValidateDOBErrorResponse.class);

        Assert.assertEquals(serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(validateDOBErrorResponse.getPayload().isValidDob(), false);

    }

    @Test(description = "validate get Ecomm Form api for Spanish patient and then SaveEcom for self", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_1(String caregiverDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, UnsupportedEncodingException {

        // Step - 1: Setting and logging fill ID's to make the respective calls
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(10).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(10).toUpperCase();
        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);
        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());
        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String customerAccountId = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.saveEcommConsentForCaregiver(customerAccountId, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status);
        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        //Step 9: Validate the form content firstName, lastName and dob
        String type = "SELF";
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, true);
        Assert.assertEquals(serRess.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse = serRess.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));


    }

    @Test(description = "validate get Ecom Form api for Spanish Patient with dependents and then SaveEcom for Adult", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_2(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    }

    @Test(description = "validate get Ecom Form api for Spanish patient with dependent and then SaveEcom for Minor", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_3(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws InterruptedException, IOException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("101", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("English", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

    }

    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 for Spanish patient when item of self is added and email verification", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_4(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 3 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes3.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes3.getStatusCode(), statusCode);

        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());

        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());


    }

    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 for Spanish patient with dependent and when item of Adult dependent is added and Save Adult with getAdultEcommConsentRequest", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_5(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        String SaveEcomAdultAccountId = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                SaveEcomAdultAccountId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        //Step 6 Trigger Validate DOB to validate the dob of adult dependent
        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.validateDOB(adultDependent_cid, adultDependentDOB, caregiver_cid);
        ValidateDOBResponse validateDOBResponse = serRes2.getDataResponse(ValidateDOBResponse.class);

        Assert.assertEquals(serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), true);

        //Step 7 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult Dependent
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse = serRes3.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes3.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

        //Step 8 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getCustomerAccountId(), caregiver_cid);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getFirstName(), caregiverFirstName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getLastName(), caregiverLastName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getEmailId(), caregiverEmail);


        //Step 9 Invoke saveEcomm for adult dependent

        ServiceResponse serRes4 = consentEcomOrchestratorWrapper.SaveEcom_AdultDependent(adultDependent_cid, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse1 = serRes4.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);


        //Step 10 invoke getEcomm again to check the response after adult has given consent

        Thread.sleep(5000);

        ServiceResponse serRes5 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes5.getDataResponse(GetEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());


    }

    @Test(description = "Validate if the saveEcommConsent() API returns status code 200 for Spanish patient with dependent when item of Adult dependent is added and Save Adult with getAdultEcommConsentRequest with  patient Safety check for Self and Dependent", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_6(String caregiverDOB, String adultDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo) throws IOException, InterruptedException {

        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String adultDependentEmail = CommonUtil.generateRandomEmailId(10);
        String adultDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();


        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> adultDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(adultDependentEmail, adultDependentFirstName, adultDependentLastName, adultDependentDOB, storeNo);
        String adultDependent_cid = adultDependentDetails.get(0);
        Reporter.logJSON("ADULT dependent Customer Account Id", adultDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adultDependent_cid, DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {
                Assert.assertEquals(adultDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(adultDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(adultDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                Assert.assertEquals(adultDependentEmail, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //Step : 5 Fetch the response from Get Ecom to pass to the Save Ecom Request
        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomAdultPatientId = null;
        String SaveEcomAdultAccountId = null;

        for (int i = 0; i < noOfNPPForm; i++) {

            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("ADULT")) {

                SaveEcomAdultPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                SaveEcomAdultAccountId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId();
            }
        }
        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Adult(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        //Step 6 Trigger Validate DOB to validate the dob of adult dependent
        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.validateDOB(adultDependent_cid, adultDependentDOB, caregiver_cid);
        ValidateDOBResponse validateDOBResponse = serRes2.getDataResponse(ValidateDOBResponse.class);

        Assert.assertEquals(serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(validateDOBResponse.getPayload().isValidDob(), validateDOBResponse.getPayload().isValidDob());

        //Step 7 Trigger sendAdultEcommConsentRequest() to Send Consent Authorization to Adult Dependent
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.sendAdultEcommConsentRequest(adultDependent_cid, caregiver_cid);
        SendAdultEcommConsentResponse sendAdultEcommConsentResponse = serRes3.getDataResponse(SendAdultEcommConsentResponse.class);

        Assert.assertEquals(serRes3.getStatusCode(), statusCode);
        Assert.assertEquals("success", sendAdultEcommConsentResponse.getPayload().getStatus());

        //Step 8 : Get  Adult Dependent
        ServiceResponse serRes6 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse = serRes6.getDataResponse(GetAdultEcomResponse.class);
        Assert.assertEquals(serRes6.getStatusCode(), statusCode);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getCustomerAccountId(), caregiver_cid);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getFirstName(), caregiverFirstName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getLastName(), caregiverLastName);
        Assert.assertEquals(getAdultEcomResponse.getPayload().getRequesterCaregiverInfo().get(0).getEmailId(), caregiverEmail);

        //Step 9 Invoke saveEcomm for adult dependent

        ServiceResponse serRes4 = consentEcomOrchestratorWrapper.SaveEcom_AdultDependent(adultDependent_cid, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomAdultPatientId);

        SaveEcomResponse saveEcomResponse1 = serRes4.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes4.getStatusCode(), statusCode);

        //Step 10 Invoke Get Adult Ecom
        ServiceResponse serRes7 = consentEcomOrchestratorWrapper.validategetAdultEcomm(Customer, SaveEcomAdultAccountId);
        GetAdultEcomResponse getAdultEcomResponse1 = serRes7.getDataResponse(GetAdultEcomResponse.class);
        // Assert.assertEquals(status)
        //Step 11 invoke getEcomm again to check the response after adult has given consent
        Thread.sleep(5000);
        ServiceResponse serRes5 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes5.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code did not match", serRes5.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());

        //Step 12: Validate the form content firstName, lastName and dob -PatientSafety of DEPENDENT
        String type = "SELF";
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, "", type, adultDependentFirstName, adultDependentLastName, "", adultDependent_cid, caregiver_cid,true);
        GetSignedFormResponse getSignedFormResponse = serRes10.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(serRes10.getStatusCode(), 200);
        Assert.assertNotNull(getSignedFormResponse.getSignedFileInfo().getContent());
        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), adultDependentFirstName + "_" + adultDependentLastName + "_DEPENDENT_" + caregiverFirstName + "_" + caregiverLastName);
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        String dependentName = adultDependentFirstName + " " + adultDependentLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));
        al.add(WordUtils.capitalizeFully(dependentName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Validate the form content firstName, lastName and dob for SELF
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid,true);
        Assert.assertEquals(serRess.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse1 = serRess.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse1.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString1 = getSignedFormResponse1.getSignedFileInfo().getContent();
        String caregiverName1 = caregiverFirstName + " " + caregiverLastName;
        List<String> al1 = new ArrayList<>();
        al1.add(WordUtils.capitalizeFully(caregiverName1));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString1, al1));

        // Validate the form content firstName, lastName and dob for ADULT Dependent
        ServiceResponse serResss = consentEcomOrchestratorWrapper.performGetSignedForms(adultDependentFirstName, adultDependentLastName, "", type, adultDependent_cid,true);
        Assert.assertEquals(serResss.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse2 = serResss.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse2.getSignedFileInfo().getName().toUpperCase(), adultDependentFirstName + "_" + adultDependentLastName + "_" + type.toUpperCase());
        String inputString2 = getSignedFormResponse2.getSignedFileInfo().getContent();
        String adultdependent = adultDependentFirstName + " " + adultDependentLastName;
        List<String> al2 = new ArrayList<>();
        al2.add(WordUtils.capitalizeFully(adultdependent));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString2, al2));

    }

    @Test(description = "Validate if the getSigneddForms() API returns success code 200 when valid cid for caregiver and minor dependent with Spanish language", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_8(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String type, String storeNo) throws InterruptedException, IOException {


        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("102", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("Spanish", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        String SaveEcomMinorAccountId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                //      SaveEcomMinorAccountId= getEcomResponse.payload.getDependentConsentInfo().get(i).customerAccountId;
            }
        }

        //Call the getSignedForm to validate no form is returned
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, "", type, minorDependentFirstName, minorDependentLastName, "", minorDependent_cid, caregiver_cid,true);
        Assert.assertEquals(serRess.getStatusCode(), 204);


        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes2.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
        String caregiverMiddlename = "null";
        String minorDependentMidllename = "null";

        //Validate the form content firstName, lastName and dob for DEPENDENT
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, caregiverMiddlename, type, minorDependentFirstName, minorDependentLastName, minorDependentMidllename, minorDependent_cid, caregiver_cid,true);
        GetSignedFormResponse getSignedFormResponse = serRes10.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(serRes10.getStatusCode(), 200);
        Assert.assertNotNull(getSignedFormResponse.getSignedFileInfo().getContent());
        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), minorDependentFirstName + "_" + minorDependentLastName + "_DEPENDENT_" + caregiverFirstName + "_" + caregiverLastName);
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        String dependentName = minorDependentFirstName + " " + minorDependentLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));
        al.add(WordUtils.capitalizeFully(dependentName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Validate the form content firstName, lastName and dob for SELF
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, true);
        Assert.assertEquals(serRes3.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse1 = serRes3.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse1.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString1 = getSignedFormResponse1.getSignedFileInfo().getContent();
        String caregiverName1 = caregiverFirstName + " " + caregiverLastName;
        List<String> al1 = new ArrayList<>();
        al1.add(WordUtils.capitalizeFully(caregiverName1));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString1, al1));
    }

    @Test(description = "Validate if the getSigneddForms() API returns success code 200 when valid cid for caregiver with English and minor dependent with Spanish language", dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx", sheetName = "getSaveEcom")
    public void getandsaveEcomFormSpanishTest_9(String caregiverDOB, String minorDependentDOB, int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String type, String storeNo) throws InterruptedException, IOException {


        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String minorDependentEmail = CommonUtil.generateRandomEmailId(10);
        String minorDependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorDependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Caregiver Customer Account Id", caregiver_cid);

        List<String> minorDependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator_Spanish(minorDependentEmail, minorDependentFirstName, minorDependentLastName, minorDependentDOB, storeNo);
        String minorDependent_cid = minorDependentDetails.get(0);
        Reporter.logJSON("MINOR dependent Customer Account Id", minorDependent_cid);

        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minorDependent_cid, DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step - 2: Calling getEcom API with customerId
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);


        // Step - 3: Validate status code
        Assert.assertEquals("Status code did not match", serRes.getStatusCode(), statusCode);

        // Step - 4: Validate patient details and form details
        Assert.assertEquals(formId, getEcomResponse.getPayload().getFormId());
        Assert.assertEquals(formVrsnNbr, getEcomResponse.getPayload().getFormVrsnNbr());
        Assert.assertEquals(signatureTypeCode, getEcomResponse.getPayload().getSignatureTypeCode());

        Assert.assertEquals(caregiver_cid, getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId());
        Assert.assertEquals(caregiverFirstName, getEcomResponse.getPayload().getCustomerConsentInfo().getFirstName());
        Assert.assertEquals(caregiverLastName, getEcomResponse.getPayload().getCustomerConsentInfo().getLastName());
        Assert.assertEquals(caregiverEmail, getEcomResponse.getPayload().getCustomerConsentInfo().getEmailId());
        Assert.assertEquals("ADULT", getEcomResponse.getPayload().getCustomerConsentInfo().getType());
        Assert.assertEquals("101", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getCode());
        Assert.assertEquals("English", getEcomResponse.getPayload().getCustomerConsentInfo().getLanguage().getDescr());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertNull(getEcomResponse.getPayload().getCustomerConsentInfo().getCaregiverAuthorization());

        int noOfDependent = getEcomResponse.getPayload().getDependentConsentInfo().size();

        for (int i = 0; i < noOfDependent; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {
                Assert.assertEquals(minorDependent_cid, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCustomerAccountId());
                Assert.assertEquals(minorDependentFirstName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getFirstName());
                Assert.assertEquals(minorDependentLastName, getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLastName());
                // Assert.assertEquals(minorDependentEmail,getEcomResponse.getPayload().getDependentConsentInfo().get(i).getEmailId());
                Assert.assertEquals("102", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getCode());
                Assert.assertEquals("Spanish", getEcomResponse.getPayload().getDependentConsentInfo().get(i).getLanguage().getDescr());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getSelfAuthorization());
                Assert.assertNull(getEcomResponse.getPayload().getDependentConsentInfo().get(i).getCaregiverAuthorization());
            }
        }

        //   String Customer = getNPPFormResponse.getGenericInfo().getOnlineCustomerID();
        String Customer = getEcomResponse.getPayload().getCustomerConsentInfo().getCustomerAccountId();
        String SignatureTypeCode = getEcomResponse.getPayload().getSignatureTypeCode();
        String FormId = getEcomResponse.getPayload().getFormId();
        String FormVrsnNbr = getEcomResponse.getPayload().getFormVrsnNbr();
        String StoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String PatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();
        int noOfNPPForm = getEcomResponse.getPayload().getDependentConsentInfo().size();
        String SaveEcomMinorPatientId = null;
        String SaveEcomMinorAccountId = null;
        for (int i = 0; i < noOfNPPForm; i++) {
            if (getEcomResponse.getPayload().getDependentConsentInfo().get(i).getType().equals("MINOR")) {

                SaveEcomMinorPatientId = getEcomResponse.getPayload().getDependentConsentInfo().get(i).getAuthPatientId();
                //      SaveEcomMinorAccountId= getEcomResponse.payload.getDependentConsentInfo().get(i).customerAccountId;
            }
        }

        //Call the getSignedForm to validate no form is returned
        ServiceResponse serRess = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, "", type, minorDependentFirstName, minorDependentLastName, "", minorDependent_cid, caregiver_cid,true);
        Assert.assertEquals(serRess.getStatusCode(), 204);


        ServiceResponse serRes1 = consentEcomOrchestratorWrapper.SaveEcom_Minor(Customer, SignatureTypeCode, FormId, FormVrsnNbr, StoreNbr, PatientId, status, SaveEcomMinorPatientId);
        // SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(saveEcomResponse.class);

        SaveEcomResponse saveEcomResponse = serRes1.getDataResponse(SaveEcomResponse.class);

        Assert.assertEquals("Status code did not match", serRes1.getStatusCode(), statusCode);

        // Step 8: Invoke Get Ecomm API Again to validate the saved Ecomm form is captured

        Thread.sleep(5000);

        ServiceResponse serRes2 = consentEcomOrchestratorWrapper.getEcom(caregiver_cid);
        GetEcomResponse getEcomResponse1 = serRes2.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Status code did not match", serRes2.getStatusCode(), statusCode);
        Assert.assertEquals(status, getEcomResponse1.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Assert.assertEquals(status, getEcomResponse1.getPayload().getDependentConsentInfo().get(0).getCaregiverAuthorization());
        String caregiverMiddlename = "null";
        String minorDependentMidllename = "null";

        //Validate the form content firstName, lastName and dob for DEPENDENT
        ServiceResponse serRes10 = consentEcomOrchestratorWrapper.performGetSignedFormsDepenents(caregiverFirstName, caregiverLastName, caregiverMiddlename, type, minorDependentFirstName, minorDependentLastName, minorDependentMidllename, minorDependent_cid, caregiver_cid,true);
        GetSignedFormResponse getSignedFormResponse = serRes10.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(serRes10.getStatusCode(), 200);
        Assert.assertNotNull(getSignedFormResponse.getSignedFileInfo().getContent());
        Assert.assertEquals(getSignedFormResponse.getSignedFileInfo().getName().toUpperCase(), minorDependentFirstName + "_" + minorDependentLastName + "_DEPENDENT_" + caregiverFirstName + "_" + caregiverLastName);
        String inputString = getSignedFormResponse.getSignedFileInfo().getContent();
        String caregiverName = caregiverFirstName + " " + caregiverLastName;
        String dependentName = minorDependentFirstName + " " + minorDependentLastName;

        List<String> al = new ArrayList<>();
        al.add(WordUtils.capitalizeFully(caregiverName));
        al.add(WordUtils.capitalizeFully(dependentName));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString, al));

        // Validate the form content firstName, lastName and dob for SELF
        ServiceResponse serRes3 = consentEcomOrchestratorWrapper.performGetSignedForms(caregiverFirstName, caregiverLastName, "", type, caregiver_cid, false);
        Assert.assertEquals(serRes3.getStatusCode(), 200);
        GetSignedFormResponse getSignedFormResponse1 = serRes3.getDataResponse(GetSignedFormResponse.class);

        Assert.assertEquals(getSignedFormResponse1.getSignedFileInfo().getName().toUpperCase(), caregiverFirstName + "_" + caregiverLastName + "_" + type.toUpperCase());
        String inputString1 = getSignedFormResponse1.getSignedFileInfo().getContent();
        String caregiverName1 = caregiverFirstName + " " + caregiverLastName;
        List<String> al1 = new ArrayList<>();
        al1.add(WordUtils.capitalizeFully(caregiverName1));

        Assert.assertTrue("customer name is not matching in pdf", consentEcomOrchestratorWrapper.Base64ToPDF(inputString1, al1));
    }

    /**
     * Helper method to setup test data for multi-caregiver multi-dependent scenario
     * Creates accounts and establishes dependent relationships
     *
     * Emilia -> dep (Carlos, James)
     * Xavier -> dep (Carlos, Aman)
     *
     * @return Map containing all customer IDs and details
     */
    public Map<String, Object> setupMultiCaregiverMultiDependentScenario(String caregiverDOB, String adultDependentDOB, String storeNo) throws InterruptedException, IOException {
        Map<String, Object> testData = new HashMap<>();

        // Step 1: Create Emilia Account (Caregiver)
        String emiliaEmail = CommonUtil.generateRandomEmailId(10);
        String emiliaFirstName = "EMILIA";
        String emiliaLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        List<String> emiliaDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                emiliaEmail, emiliaFirstName, emiliaLastName, caregiverDOB, storeNo);
        String emilia_cid = emiliaDetails.get(0);
        Reporter.logJSON("Emilia (Caregiver) Customer Account Id", emilia_cid);

        // Step 2: Create Xavier Account (Caregiver)
        String xavierEmail = CommonUtil.generateRandomEmailId(10);
        String xavierFirstName = "XAVIER";
        String xavierLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        List<String> xavierDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                xavierEmail, xavierFirstName, xavierLastName, caregiverDOB, storeNo);
        String xavier_cid = xavierDetails.get(0);
        Reporter.logJSON("Xavier (Caregiver) Customer Account Id", xavier_cid);

        // Step 3: Create Carlos Account (Dependent)
        String carlosEmail = CommonUtil.generateRandomEmailId(10);
        String carlosFirstName = "CARLOS";
        String carlosLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        List<String> carlosDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                carlosEmail, carlosFirstName, carlosLastName, adultDependentDOB, storeNo);
        String carlos_cid = carlosDetails.get(0);
        Reporter.logJSON("Carlos (Dependent) Customer Account Id", carlos_cid);

        // Step 4: Create James Account (Dependent)
        String jamesEmail = CommonUtil.generateRandomEmailId(10);
        String jamesFirstName = "JAMES";
        String jamesLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        List<String> jamesDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                jamesEmail, jamesFirstName, jamesLastName, adultDependentDOB, storeNo);
        String james_cid = jamesDetails.get(0);
        Reporter.logJSON("James (Dependent) Customer Account Id", james_cid);

        // Step 5: Create Aman Account (Dependent)
        String amanEmail = CommonUtil.generateRandomEmailId(10);
        String amanFirstName = "AMAN";
        String amanLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        List<String> amanDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                amanEmail, amanFirstName, amanLastName, adultDependentDOB, storeNo);
        String aman_cid = amanDetails.get(0);
        Reporter.logJSON("Aman (Dependent) Customer Account Id", aman_cid);

        // Step 6: Add Carlos as dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(xavier_cid, carlos_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        Reporter.logJSON("Added Carlos as dependent to Xavier", "Success");

        // Step 7: Add Aman as dependent to Xavier
        consentOrchestratorWrapper.caAddDependent(xavier_cid, aman_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        Reporter.logJSON("Added Aman as dependent to Xavier", "Success");

        // Step 8: Add Carlos as dependent to Emilia
        consentOrchestratorWrapper.caAddDependent(emilia_cid, carlos_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        Reporter.logJSON("Added Carlos as dependent to Emilia", "Success");

        // Step 9: Add James as dependent to Emilia
        consentOrchestratorWrapper.caAddDependent(emilia_cid, james_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);
        Reporter.logJSON("Added James as dependent to Emilia", "Success");

        // Store all data in map
        testData.put("emilia_cid", emilia_cid);
        testData.put("emiliaFirstName", emiliaFirstName);
        testData.put("emiliaLastName", emiliaLastName);
        testData.put("emiliaEmail", emiliaEmail);

        testData.put("xavier_cid", xavier_cid);
        testData.put("xavierFirstName", xavierFirstName);
        testData.put("xavierLastName", xavierLastName);
        testData.put("xavierEmail", xavierEmail);

        testData.put("carlos_cid", carlos_cid);
        testData.put("carlosFirstName", carlosFirstName);
        testData.put("carlosLastName", carlosLastName);
        testData.put("carlosEmail", carlosEmail);

        testData.put("james_cid", james_cid);
        testData.put("jamesFirstName", jamesFirstName);
        testData.put("jamesLastName", jamesLastName);
        testData.put("jamesEmail", jamesEmail);

        testData.put("aman_cid", aman_cid);
        testData.put("amanFirstName", amanFirstName);
        testData.put("amanLastName", amanLastName);
        testData.put("amanEmail", amanEmail);

        // Step 10: Get Consent Request for All - verify no consents exist initially
        ServiceResponse emiliaConsentResponse = consentEcomOrchestratorWrapper.getEcom(emilia_cid);
        GetEcomResponse emiliaConsents = emiliaConsentResponse.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Emilia consent check status code", 200, emiliaConsentResponse.getStatusCode());
        Assert.assertNull("Emilia should not have self authorization initially",
                emiliaConsents.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Reporter.logJSON("Verified no initial consents for Emilia", "Success");

        ServiceResponse xavierConsentResponse = consentEcomOrchestratorWrapper.getEcom(xavier_cid);
        GetEcomResponse xavierConsents = xavierConsentResponse.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Xavier consent check status code", 200, xavierConsentResponse.getStatusCode());
        Assert.assertNull("Xavier should not have self authorization initially",
                xavierConsents.getPayload().getCustomerConsentInfo().getSelfAuthorization());
        Reporter.logJSON("Verified no initial consents for Xavier", "Success");

        return testData;
    }

    // Common helper to validate Send Consent response + Kafka message
    private void validateSendConsent(ServiceResponse response) {
        SendAdultEcommConsentResponse data =
                response.getDataResponse(SendAdultEcommConsentResponse.class);
        Assert.assertEquals("Send consent status code mismatch",
                200, response.getStatusCode());
        Assert.assertEquals("Send consent status mismatch",
                "success", data.getPayload().getStatus());
    }

    private String fetchSelfAuthorization(String customerId) {
        ServiceResponse consentResponse = consentEcomOrchestratorWrapper.getEcom(customerId);
        GetEcomResponse consents = consentResponse.getDataResponse(GetEcomResponse.class);
        Assert.assertEquals("Consent fetch status code", 200, consentResponse.getStatusCode());
        return consents.getPayload().getCustomerConsentInfo().getSelfAuthorization();
    }

    // Helper to assert a pending consent request exists from expected caregiver
    private void assertPendingConsentRequest(ServiceResponse consentRequestResponse,
                                             Set<String> expectedGranteeCids) {
        GetConsentRequestResponse consentRequest =
                consentRequestResponse.getDataResponse(GetConsentRequestResponse.class);

        Set<String> pendingIds = consentRequest.getCaregiverRequest().stream()
                .filter(info -> "PENDING".equals(info.getRequestStatus()))
                .map(CustomerInfo::getCustomerId)
                .collect(Collectors.toSet());

        Set<String> missing = new HashSet<>(expectedGranteeCids);
        missing.removeAll(pendingIds);

        Assert.assertTrue("Missing pending consent grantee ids: " + missing, missing.isEmpty());
    }

    @Test(description = "Validate multi-caregiver multi-dependent consent flow with new APIs",
            dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
            sheetName = "getSaveEcom")
    public void multiCaregiverMultiDependentConsentFlowTest(String caregiverDOB, String adultDependentDOB,
                                                            int statusCode, String status, String formId, String formVrsnNbr, String signatureTypeCode, String storeNo, boolean adultConsentEnabled)
            throws InterruptedException, IOException {

        if(!adultConsentEnabled)    return;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Setup test data - Steps 1-10
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Map<String, Object> testData = setupMultiCaregiverMultiDependentScenario(caregiverDOB, adultDependentDOB, storeNo);

        String emilia_cid = (String) testData.get("emilia_cid"); // f3e1a77b-fe8d-4411-894c-5729d6610843 | ad7979f8-d348-4b3d-92d9-070c9145ed71
        String xavier_cid = (String) testData.get("xavier_cid"); // 650b3297-a8ed-47fb-9828-114673f164ad | bae86481-f30d-4541-9979-20ff4bde67da
        String carlos_cid = (String) testData.get("carlos_cid"); // 5facf96e-7055-493c-ad47-155eeba3c986 | 4db5ca24-dbe0-4175-bdea-61a856a3f253
        String james_cid = (String) testData.get("james_cid"); // 70531fbf-2920-4731-808e-f66bcd410a71 | e0c59170-f644-4c57-a00c-a7be40a7c2b7
        String aman_cid = (String) testData.get("aman_cid"); // cd82bde0-fc1e-44c1-b94f-6108c6bb7465 | c12e1b75-8679-48ea-9821-2f9b724c7dff

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 11: Emilia send consent request to Carlos and James (Old Send Adult Ecomm Consent)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 11", "Emilia sending consent request to Carlos and James");

        ServiceResponse emiliaSendConsentRequestResponse = consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(emilia_cid, signatureTypeCode, List.of(carlos_cid, james_cid));
        Assert.assertEquals("Send Consent Request status code mismatch for Emilia", statusCode, emiliaSendConsentRequestResponse.getStatusCode());
        Reporter.logJSON("Emilia sent consent request to Carlos and James", "Success");

        Thread.sleep(3000);

        // Assert: Carlos should have pending consent request from Emilia
        ServiceResponse carlosGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(carlos_cid, null, null);
        assertPendingConsentRequest(carlosGetAdultEcommResponse, Set.of(emilia_cid));
        Reporter.logJSON("Verified Carlos has pending request from Emilia", "Success");

        // Assert: James should have pending consent request from Emilia
        ServiceResponse jamesGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(james_cid, null, null);
        assertPendingConsentRequest(jamesGetAdultEcommResponse, Set.of(emilia_cid));
        Reporter.logJSON("Verified James has pending request from Emilia", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 12: Xavier send consent request to Carlos and Aman (Send Consent Request for send action - NEW API)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 12", "Xavier sending consent request to Carlos and Aman");

        ServiceResponse xavierSendConsentRequestResponse = consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(xavier_cid, signatureTypeCode, List.of(carlos_cid, aman_cid));
        Assert.assertEquals("Send Consent Request status code mismatch for Xavier", statusCode, xavierSendConsentRequestResponse.getStatusCode());
        Reporter.logJSON("Xavier sent consent request to Carlos and Aman", "Success");

        Thread.sleep(3000);

        // Assert: Carlos should now have pending requests from both Emilia and Xavier
        carlosGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(carlos_cid, null, null);
        assertPendingConsentRequest(carlosGetAdultEcommResponse, Set.of(emilia_cid, xavier_cid));
        Reporter.logJSON("Verified Carlos has pending request from Xavier and Emilia", "Success");

        // Assert: Aman should have pending consent request from Xavier
        ServiceResponse amanGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(aman_cid, null, null);
        assertPendingConsentRequest(amanGetAdultEcommResponse, Set.of(xavier_cid));
        Reporter.logJSON("Verified Aman has pending request from Xavier", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 13: Carlos Accepted (Save Ecomm Consent V2 for Accept action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 13", "Carlos accepting consent requests");

        // Get Carlos's details for accepting the consent
        ServiceResponse serRes = consentEcomOrchestratorWrapper.getEcom(carlos_cid);
        GetEcomResponse getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);
        String carlosStoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String carlosPatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();

        // Save Ecomm V2 for Carlos to accept the Consent
        ServiceResponse carlosSaveEcomResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(carlos_cid, signatureTypeCode, formId, formVrsnNbr, carlosStoreNbr, ACCEPT, carlosPatientId);
        SaveEcomResponse carlosAccept = carlosSaveEcomResponse.getDataResponse(SaveEcomResponse.class);
        Assert.assertEquals("Carlos accept status code", statusCode, carlosSaveEcomResponse.getStatusCode());
        Assert.assertEquals("Carlos accept status code", "success", carlosAccept.getPayload().getStatus());

        Thread.sleep(5000);

        //Assert: Carlos should have no pending requests now
        carlosGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(carlos_cid, null, null);
        Assert.assertEquals("Carlos should have no pending requests", 0, carlosGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());
        Reporter.logJSON("Carlos accepted consent requests", "Success");

        // Assert: Self Authorization for Carlos should be "ACCEPT"
        Assert.assertEquals(ACCEPT, fetchSelfAuthorization(carlos_cid));

        // Assert: Verify Emilia sees Carlos with accepted status
        ServiceResponse emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        Set<String> dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue("Emilia doesn't have approved P13N for Carlos", dependentIds.contains(carlos_cid));
        Reporter.logJSON("Emilia has approved P13N for Carlos", "Success");

        // Assert: Verify Xavier sees Carlos with approved status
        ServiceResponse xavierGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        dependentIds = xavierGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue("Xavier doesn't have approved P13N for Carlos", dependentIds.contains(carlos_cid));
        Reporter.logJSON("Xavier has approved P13N for Carlos", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 14: James Accepted (Save Ecomm Consent V2 for Accept action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 14", "James accepting consent request from Emilia");

        // Get James's consent details for accepting both caregivers
        serRes = consentEcomOrchestratorWrapper.getEcom(james_cid);
        getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        //Fetch the response from Get Ecom to pass to the Save Ecom Request
        String jamesStoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String jamesPatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();

        // James accepts consent
        ServiceResponse jamesSaveEcomResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(james_cid, signatureTypeCode, formId, formVrsnNbr, jamesStoreNbr, ACCEPT, jamesPatientId);
        SaveEcomResponse jamesAccept = carlosSaveEcomResponse.getDataResponse(SaveEcomResponse.class);
        Assert.assertEquals("James accept status code", statusCode, jamesSaveEcomResponse.getStatusCode());
        Assert.assertEquals("James accept status code", "success", jamesAccept.getPayload().getStatus());

        Thread.sleep(3000);

        //Assert: James should have no pending requests now
        jamesGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(james_cid, null, null);
        Assert.assertEquals("James should have no pending requests", 0, jamesGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());
        Reporter.logJSON("James accepted consent requests", "Success");

        // Assert: Self Authorization for James should be "ACCEPT"
        Assert.assertEquals(ACCEPT, fetchSelfAuthorization(james_cid));

        // Assert: Verify Emilia sees Carlos and James with approved status
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue(dependentIds.contains(carlos_cid));
        Assert.assertTrue(dependentIds.contains(james_cid));

        Reporter.logJSON("Emilia has approved P13N for Carlos and James", "Success");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 15: Aman Dismissed (Send Consent Request for action: Reject)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 15", "Aman dismissing consent request from Xavier");

        ServiceResponse amanDismissedResponse = consentEcomOrchestratorWrapper.RejectConsentRequest_Dependent(aman_cid, signatureTypeCode, List.of(xavier_cid));
        Assert.assertEquals("Aman dismissed consent request of Xavier using Send Consent Request API status code", statusCode, amanDismissedResponse.getStatusCode());

        Thread.sleep(3000);

        // Assert: Xavier should see Aman consent as rejected/denied
        xavierGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        dependentIds = xavierGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());
        Assert.assertTrue(dependentIds.contains(aman_cid));

        // Assert: Aman should have no pending requests now
        amanGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(aman_cid, null, null);
        Assert.assertEquals("Aman should have no pending requests", 0, amanGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());
        Reporter.logJSON("Aman accepted consent requests", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 16: Emilia Dismiss p13N for Carlos (Conceptual - not directly implemented in test)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 16", "Emilia dismissing notification for Carlos - conceptual step");
        UpdateCustomerP13NRequest updateCustomerP13NRequest = new UpdateCustomerP13NRequest();
        updateCustomerP13NRequest.setEntity(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED);
        updateCustomerP13NRequest.setType(P13NType.CARD_DISMISSAL);

        HashMap<String, Object> identifier = new HashMap<>();
        identifier.put("dependentCustomerAccountId", carlos_cid);
        updateCustomerP13NRequest.setIdentifiers(List.of(identifier));
        accountOrchestratorRetrofit.updateP13Ns(emilia_cid, updateCustomerP13NRequest, "WM-PHARMACY", RandomStringUtils.randomAlphanumeric(10), RandomStringUtils.randomAlphanumeric(10));

        // Assert: Emilia should not see Carlos p13N (as it has been dismissed)
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertFalse(dependentIds.contains(carlos_cid));
        Assert.assertTrue(dependentIds.contains(james_cid));


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 17: Carlos denied the consents (Save Ecomm Consent V2 for deny action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 17", "Carlos denying consent requests");

        ServiceResponse carlosDenyResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(carlos_cid, signatureTypeCode, formId, formVrsnNbr, carlosStoreNbr, "deny", carlosPatientId);
        Assert.assertEquals("Carlos deny status code", statusCode, carlosDenyResponse.getStatusCode());
        Reporter.logJSON("Carlos denied consent requests", "Success");

        Thread.sleep(3000);

        // Assert: Self Authorization for Carlos should be "DENY"
        Assert.assertEquals("DENY", fetchSelfAuthorization(carlos_cid));

        // Assert: Emilia should not see Carlos p13N (or see it as rejected)
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertFalse(dependentIds.contains(carlos_cid));
        Assert.assertTrue(dependentIds.contains(james_cid));

        // Assert: Xavier should see Carlos with rejected status
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue(dependentIds.contains(carlos_cid));


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 18: James denied the consent (Save Ecomm Consent V2 for deny action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ServiceResponse jamesDenyResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(james_cid, signatureTypeCode, formId, formVrsnNbr, jamesStoreNbr, "deny", jamesPatientId);
        Assert.assertEquals("James deny status code", statusCode, carlosDenyResponse.getStatusCode());
        Reporter.logJSON("James denied consent requests", "Success");

        Thread.sleep(3000);

        // Assert: Self Authorization for James should be "DENY"
        Assert.assertEquals("DENY", fetchSelfAuthorization(james_cid));

        // Assert: Emilia should see James consent request as rejected
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_REJECTED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue(dependentIds.contains(james_cid));


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 19: Xavier Resend to Aman (Send Consent Request for send action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 19", "Xavier resending consent request to Aman");

        xavierSendConsentRequestResponse = consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(xavier_cid, signatureTypeCode, List.of(aman_cid));
        validateSendConsent(xavierSendConsentRequestResponse);
        Reporter.logJSON("Xavier resent consent request to Aman", "Success");

        Thread.sleep(3000);

        // Assert: Aman should have pending consent request from Xavier
        ServiceResponse amanGetAdultEcommResponse2 = consentEcomOrchestratorWrapper.GetConsentRequest(aman_cid, null, null);
        assertPendingConsentRequest(amanGetAdultEcommResponse2, Set.of(xavier_cid));
        Reporter.logJSON("Verified Carlos has pending request from Xavier", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 20: Aman approved the request from Xavier (Save Ecomm Consent V2 for Accept action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 20", "Aman approving consent request from Xavier");

        serRes = consentEcomOrchestratorWrapper.getEcom(aman_cid);
        getEcomResponse = serRes.getDataResponse(GetEcomResponse.class);

        //Fetch the response from Get Ecom to pass to the Save Ecom Request
        String amanStoreNbr = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthStoreNbr();
        String amanPatientId = getEcomResponse.getPayload().getCustomerConsentInfo().getAuthPatientId();

        ServiceResponse amanSaveEcomResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(aman_cid, signatureTypeCode, formId, formVrsnNbr, amanStoreNbr, ACCEPT, amanPatientId);
        Assert.assertEquals("Aman accept status code", statusCode, amanSaveEcomResponse.getStatusCode());

        Thread.sleep(5000);

        //Assert: Aman should have no pending requests now
        amanGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(aman_cid, null, null);
        Assert.assertEquals("Aman should have no pending requests", 0, amanGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());
        Reporter.logJSON("Aman accepted consent requests", "Success");

        // Assert: Self Authorization for Aman should be "ACCEPT"
        Assert.assertEquals("ACCEPT", fetchSelfAuthorization(aman_cid));

        // Assert: Verify Xavier sees Aman with accepted status
        xavierGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        dependentIds = xavierGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue("Emilia doesn't have approved P13N for Carlos",dependentIds.contains(aman_cid));
        Reporter.logJSON("Xavier has approved P13N for Aman", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 21: Carlos accepted the consents again (Save Ecomm Consent V2 for Accept action)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 21", "Carlos accepting consent requests again");


        ServiceResponse carlosAcceptResponse = consentEcomOrchestratorWrapper.SaveEcomV2_AdultDependent(carlos_cid, signatureTypeCode, formId, formVrsnNbr, carlosStoreNbr, ACCEPT, carlosPatientId);
        Assert.assertEquals("Carlos accept status code", statusCode, carlosAcceptResponse.getStatusCode());
        Reporter.logJSON("Carlos Accepted Consent", "Success");

        Thread.sleep(3000);

        // Assert: Self Authorization for Carlos should be "ACCEPT"
        Assert.assertEquals("ACCEPT", fetchSelfAuthorization(carlos_cid));

        // Assert: Emilia should not see Carlos p13N (or see it as rejected)
        emiliaGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(emilia_cid, null, "true");
        dependentIds = emiliaGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertFalse(dependentIds.contains(carlos_cid));

        // Assert: Xavier should see Carlos with accepted consent
        xavierGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        dependentIds = xavierGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class)
                .getP13ns()
                .stream()
                .filter(
                        entity -> entity.getEntity().equals(P13NEntity.ECOMM_ADULT_DEPENDENT_CONSENT_APPROVED.getValue()) && entity.getType().equals(P13NType.SET.getValue())
                ).map(
                        entity -> entity.getIdentifiers().getFirst().getDependentCustomerAccountId()
                ).collect(Collectors.toSet());

        Assert.assertTrue(dependentIds.contains(carlos_cid));


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 22: Emilia send the request to James again (Old Send Adult Ecomm Consent)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 22", "Emilia resending consent request to James");

        emiliaSendConsentRequestResponse = consentEcomOrchestratorWrapper.SendConsentRequest_Caregiver(emilia_cid, signatureTypeCode, List.of(james_cid));
        Assert.assertEquals("Send Consent Request status code mismatch for Xavier", statusCode, emiliaSendConsentRequestResponse.getStatusCode());
        Reporter.logJSON("Emilia sent consent request again to James", "Success");

        Thread.sleep(3000);

        // Assert: James should have pending consent request from Emilia
        jamesGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(james_cid, null, null);
        assertPendingConsentRequest(jamesGetAdultEcommResponse, Set.of(emilia_cid));
        Reporter.logJSON("Verified James has pending request from Emilia", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 23: Emilia Deactivates account (Revoke Consent without dependentCid)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 23", "Emilia deactivating account - revoking all consents");

        ServiceResponse emiliaDeactivatesResponse = customerConsentWrapper.revokeCustomerConsent(emilia_cid);
        Assert.assertEquals("Emilia deactivate account status code", statusCode, emiliaDeactivatesResponse.getStatusCode());
        Reporter.logJSON("Emilia account deactivated", "Success");

        // Assert: No pending request on James of Emilia
        jamesGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(james_cid, null, null);
        Assert.assertEquals("James should have no pending requests after Emilia deactivation", 0,
                jamesGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());
        Reporter.logJSON("Verified James has no pending request from Emilia after deactivation", "Success");


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Step 24: Xavier Removes account of Aman (Revoke Consent with dependentCid)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reporter.logJSON("Step 24", "Xavier removing Aman as dependent");
        Map<String, List<String>> map = new HashMap<>();
        map.put("dependentId", List.of(aman_cid));
        ObjectMapper mapper = new ObjectMapper();
        String dependentIdsPayload = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(map);
        ServiceResponse xavierRemovesAmanResponse = customerConsentWrapper.revokeCustomerConsentWithPayload(xavier_cid, dependentIdsPayload);
        Assert.assertEquals("Xavier remove Aman as dependent status code", statusCode, xavierRemovesAmanResponse.getStatusCode());
        Reporter.logJSON("Xavier removed Aman as dependent", "Success");

        // Assert: No P13N on Xavier for Aman
        xavierGetAdultEcommResponse = consentEcomOrchestratorWrapper.GetConsentRequest(xavier_cid, null, "true");
        Assert.assertEquals("Xavier doesn't have approved P13N for Aman", 0, xavierGetAdultEcommResponse.getDataResponse(GetConsentRequestResponse.class).getCaregiverRequest().size());

        Reporter.logJSON("Xavier has approved P13N for Aman", "Success");
        Reporter.logJSON("Multi-caregiver multi-dependent consent flow test completed", "Success");
    }
}
