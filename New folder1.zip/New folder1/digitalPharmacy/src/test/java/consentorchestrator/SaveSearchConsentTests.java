package consentorchestrator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.annotations.DataProviderArguments;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.DataProvider;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.request.saveNPP.SearchConsentRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.SearchConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.savenpp.SearchConsentErrorResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.searchSaveConsentResponse.SaveConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.searchSaveConsentResponse.SearchConsentResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.serchSaveCommon.ConsentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.response.serchSaveCommon.CustomerConsentInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.ConsentOrchestratorWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.CustomerConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.consentorchestrator.restapi.SaveConsentWrapper;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.Retry;
import com.walmart.pharmacy.dp.account.orchestrator.restclient.model.DependentInfo;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.*;

/**
 * =====================================================================
 * SAVE & SEARCH CONSENT ORCHESTRATOR TEST SUITE
 * =====================================================================
 *
 * @description This comprehensive test suite validates the end-to-end flow of
 *              Consent Orchestrator APIs for Walmart Digital Pharmacy.
 *
 * @apis
 *   - SAVE Consent API (PUT /v1/consents) - Saves consent for customers
 *   - SEARCH Consent API (POST /v1/consents/search) - Retrieves saved consent
 *
 * @flow Save Consent → Search Consent (validates consent persistence)
 *
 * =====================================================================
 * API DETAILS
 * =====================================================================
 *
 * SAVE CONSENT API
 * ----------------
 * Endpoint: PUT https://health-consent.stage.walmart.com/v1/consents
 * Service:  HW-CONSENT-ORCHESTRATOR
 *
 * Required Headers:
 *   - WM_CONSUMER.ID: Consumer ID from vault
 *   - WM_SEC.AUTH_SIGNATURE: Generated signature
 *   - WM_CONSUMER.INTIMESTAMP: Current timestamp
 *   - WM_SEC.KEY_VERSION: Key version (default: "1")
 *   - x-hnw-rx-req-track-id: Request tracking ID
 *   - x-hnw-rx-request-id: Request ID
 *   - x-hnw-rx-client-name: Client name (e.g., "dotcom")
 *
 * Request Body Parameters:
 *   - documentType: "NON_TRANSACTIONAL"
 *   - primaryAccountIdType: "CID"
 *   - managedAccountIdType: "cid"
 *   - primaryAccountId: Caregiver/Self CID
 *   - managedAccountId: Self or Dependent CID
 *   - consentFormId: Form ID (e.g., "50000-0000-001", "50001-0000-000")
 *   - consentFormCode: Form Code ("50000" for Ecomm, "50001" for Extended HIPAA)
 *   - consentStatus: "ACCEPT" or "DENY"
 *   - v1Legacy: Boolean flag for legacy flow
 *
 * Response Status Values:
 *   - CREATED: New consent created
 *   - UPDATED: Existing consent updated
 *   - SKIPPED: No action taken (consent doesn't exist for revoke)
 *
 * SEARCH CONSENT API
 * ------------------
 * Endpoint: POST https://health-consent.stage.walmart.com/v1/consents/search
 * Service:  HW-CONSENT-ORCHESTRATOR
 *
 * Required Headers:
 *   - x-hnw-lob: Line of Business (e.g., "PHARMACY")
 *   - x-hnw-tenantId: Tenant ID
 *   - x-hnw-rx-req-track-id: Request tracking ID
 *   - x-hnw-rx-request-id: Request ID
 *   - x-hnw-rx-client-name: Client name
 *
 * =====================================================================
 * TEST SCENARIOS COVERAGE
 * =====================================================================
 *
 * POSITIVE SCENARIOS (Save → Search Flow):
 * -----------------------------------------
 * | #  | Scenario                                                    | Expected Save Status | Expected Auth |
 * |----|-------------------------------------------------------------|----------------------|---------------|
 * | 1  | Save Ecomm Consent (50000) for Self - ACCEPT                | CREATED              | ACCEPT        |
 * | 2  | Save Extended HIPAA Consent (50001) for Self - ACCEPT       | CREATED              | ACCEPT        |
 * | 3  | Save Ecomm + Extended HIPAA Consent for Self - ACCEPT       | CREATED              | ACCEPT        |
 * | 4  | Revoke Ecomm & Extended HIPAA Consent for Self - DENY       | UPDATED              | DENY          |
 * | 5  | v1 Legacy: Save Ecomm Consent for Self + Minor - ACCEPT     | CREATED              | ACCEPT        |
 * | 6  | Save Extended HIPAA Consent for Self + Minor - ACCEPT       | CREATED              | ACCEPT        |
 * | 7  | Revoke Ecomm & Extended HIPAA Consent for Only Minor - DENY | UPDATED              | DENY (minor)  |
 * | 8  | Save Ecomm Consent for Only Minor (no caregiver consent)    | CREATED              | ACCEPT        |
 * | 9  | Save Ecomm Consent for Adult Dependent - ACCEPT             | CREATED              | ACCEPT        |
 * | 10 | Revoke Consent When Consent Doesn't Exist - SKIPPED         | SKIPPED              | null          |
 * | 11 | Validate CaptureTs Field in Search Response                 | CREATED              | ACCEPT        |
 * | 12 | Search Consent for Fresh Account - No Consent               | N/A                  | null          |
 * | 13 | Revoke Consent for Only Caregiver (with minor dependent)    | UPDATED              | DENY          |
 * | 14 | Save Ecomm Consent for Only Minor (caregiver consent exists)| CREATED              | ACCEPT        |
 * | 15 | v1 Legacy: Save Ecomm for Adult Dependent with PENDING      | CREATED              | ACCEPT        |
 * | 16 | Save Extended HIPAA for Adult Dependent with PENDING        | CREATED              | ACCEPT        |
 * | 17 | Revoke Extended HIPAA for Adult Dependent (ACCEPTED request)| UPDATED              | DENY          |
 * | 18 | Update Existing Consent - ACCEPT to DENY                    | UPDATED              | DENY          |
 *
 * NEGATIVE SCENARIOS (Search API Error Handling):
 * -----------------------------------------------
 * | #  | Scenario                               | Expected Status | Expected Error                    |
 * |----|----------------------------------------|-----------------|-----------------------------------|
 * | 1  | Missing x-hnw-lob Header               | 400             | Missing required header           |
 * | 2  | Missing x-hnw-tenantId Header          | 400             | Missing required header           |
 * | 3  | Missing x-hnw-rx-req-track-id Header   | 400             | Missing required header           |
 * | 4  | Missing x-hnw-rx-request-id Header     | 400             | Missing required header           |
 * | 5  | Missing x-hnw-rx-client-name Header    | 400             | Missing required header           |
 * | 6  | Invalid Account ID                     | 400             | Invalid account ID format         |
 * | 7  | Account ID Type Not CID                | 400             | Invalid account ID type           |
 * | 8  | Missing Account ID (empty body)        | 400             | Account ID is required            |
 * | 9  | Missing Account ID (null value)        | 400             | Account ID cannot be null         |
 * | 10 | Missing Account ID (blank value)       | 400             | Account ID cannot be blank        |
 * | 11 | PET Type Customer                      | 400             | PET type not supported            |
 *
 * SAVE CONSENT NEGATIVE SCENARIOS (Save API Error Handling):
 * ----------------------------------------------------------
 * | #  | Scenario                                          | Expected Status | Expected Error Code      | Expected Error Message                                              |
 * |----|---------------------------------------------------|-----------------|--------------------------|---------------------------------------------------------------------|
 * | 1  | Save Both Ecomm & HIPAA with ACCEPT               | 400             | CHPR-CONSORCH-1118       | Cannot save both Ecomm (50000) and HIPAA (50001) with ACCEPT        |
 * | 2  | Save Consent with Empty ConsentInfo Lists         | 400             | CHPR-CONSORCH-1118       | At least one consent entry is required                              |
 * | 3  | Save Consent with Invalid Authorization (REJECTED)| 400             | CHPR-CONSORCH-1118       | authorization must be 'ACCEPT' or 'DENY'                            |
 * | 4  | Save Consent with Invalid LOB Header              | 400             | CHPR-CONSORCH-1119       | Invalid lob: INVALID_LOB is provided for header: lob                |
 *
 * =====================================================================
 * DEPENDENCIES
 * =====================================================================
 *
 * Wrappers:
 *   - SearchConsentWrapper: Handles Search Consent API calls
 *   - SaveConsentWrapper: Handles Save Consent API calls
 *   - ConsentOrchestratorWrapper: Handles dependent management (caAddDependent)
 *
 * Utilities:
 *   - DigitalPharmacyOperationsUtil: Account creation
 *   - CommonUtil: Random data generation
 *   - SignatureGenerator: WM_SEC.AUTH_SIGNATURE generation
 *
 * Test Data:
 *   - Excel File: testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx
 *   - Sheets: searchConsentNegative, searchConsentPositive
 *
 * =====================================================================
 * FORM CODES REFERENCE
 * =====================================================================
 *
 * | Form Code | Form ID          | Description               |
 * |-----------|------------------|---------------------------|
 * | 50000     | 50000-0000-001   | Ecomm Consent             |
 * | 50001     | 50001-0000-000   | Extended HIPAA Consent    |
 *
 */
public class SaveSearchConsentTests {

    // =====================================================================
    // CONSTANTS - FORM CODES (Business Constants)
    // =====================================================================

    /** Ecomm Consent Form Code */
    private static final String ECOMM_FORM_CODE = "50000";

    /** Extended HIPAA Consent Form Code */
    private static final String HIPAA_FORM_CODE = "50001";

    /** Form ID: ECOMM */
    private static final String ECOMM_FORM_ID = "50000-0000-001";

    /** Form ID: HIPAA */
    private static final String HIPAA_FORM_ID = "50001-0000-000";

    // =====================================================================
    // CONSTANTS - AUTHORIZATION STATUS
    // =====================================================================

    /** Authorization Status: Accepted */
    private static final String AUTH_STATUS_ACCEPT = "ACCEPT";

    /** Authorization Status: Denied */
    private static final String AUTH_STATUS_DENY = "DENY";

    // =====================================================================
    // CONSTANTS - DEFAULT VALUES
    // =====================================================================

    /** Account ID Type: CID */
    private static final String ACCOUNT_ID_TYPE_CID = "CID";

    /** Default Location State */
    private static final String DEFAULT_LOCATION_STATE = "AZ";

    // =====================================================================
    // CONSTANTS - CLASSIFICATION
    // =====================================================================

    /** Valid classification value for RXD-ECOMM-AUTH */
    private static final String CLASSIFICATION_RXD_ECOMM_AUTH = "RXD-ECOMM-AUTH";

    /** Lowercase classification (case-insensitive - should work) */
    private static final String CLASSIFICATION_RXD_ECOMM_AUTH_LOWERCASE = "RXD-ecomm-AUTH";

    /** Invalid classification value (for negative test) */
    private static final String CLASSIFICATION_INVALID = "PHI-AUTH";

    // =====================================================================
    // WRAPPERS AND UTILITIES
    // =====================================================================

    /** Wrapper for Search Consent API */
    protected SearchConsentWrapper searchConsentWrapper;

    /** Wrapper for Save Consent API */
    protected SaveConsentWrapper saveConsentWrapper;

    /** Utility for account operations */
    protected DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil;

    /** Wrapper for dependent management */
    protected ConsentOrchestratorWrapper consentOrchestratorWrapper;

    protected CustomerConsentWrapper customerConsentWrapper;

    // =====================================================================
    // SETUP
    // =====================================================================

    /**
     * Initializes all wrappers and utilities before test execution.
     * Called automatically by TestNG.
     */
    @BeforeClass
    public void setUp() {
        if (System.getProperty("maxRetryAttempts") == null) {
            System.setProperty("maxRetryAttempts", "2");
        }
        searchConsentWrapper = new SearchConsentWrapper();
        saveConsentWrapper = new SaveConsentWrapper();
        digitalPharmacyOperationsUtil = new DigitalPharmacyOperationsUtil();
        consentOrchestratorWrapper = new ConsentOrchestratorWrapper();
        customerConsentWrapper = new CustomerConsentWrapper();
    }

    // =====================================================================
    // SEARCH CONSENT API - FAILURE SCENARIOS
    // =====================================================================


    /**
     * Scenario 2: Missing x-hnw-tenantId Header
     */
    @Test(description = "Validate Search Consent API fails when x-hnw-tenantId header is missing",
          dataProviderClass = DataProvider.class, dataProvider = "getData", retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentNegative")
    public void searchConsentShouldFailWhenTenantIdHeaderMissing(
            String testname, String description, String accountIdType, String formCode, String lob, String tenantId,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        List<String> formCodeList = Arrays.asList(formCode.split(","));

        ServiceResponse response = searchConsentWrapper.searchConsentWithoutTenantIdHeader(
                "12345678", accountIdType, formCodeList, lob);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertEquals("Error code mismatch", expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("Test passed - Error: " + actualErrorMessage);
    }


    /**
     * Scenario 7: Account ID Type Not CID
     */
    @Test(description = "Validate Search Consent API fails when accountIdType is not CID",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent"}, retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentNegative")
    public void searchConsentShouldFailWhenAccountIdTypeNotCID(
            String testname, String description, String accountIdType, String formCode, String lob, String tenantId,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        List<String> formCodeList = Arrays.asList(formCode.split(","));

        ServiceResponse response = searchConsentWrapper.searchConsent(
                "12345678", accountIdType, formCodeList, lob, tenantId);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);
        Assert.assertEquals("Error code mismatch", expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("Test passed - Error: " + actualErrorMessage);
    }


    /**
     * Scenario 9: Missing Account ID (null value)
     */
    @Test(description = "Validate Search Consent API fails when accountId is null",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent"}, retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentNegative")
    public void searchConsentShouldFailWhenAccountIdNull(
            String testname, String description, String accountIdType, String formCode, String lob, String tenantId,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        List<String> formCodeList = Arrays.asList(formCode.split(","));

        SearchConsentRequest requestWithNullAccountId = SearchConsentRequest.builder()
                .accountId(null)
                .accountIdType(accountIdType)
                .formCode(formCodeList)
                .build();

        ServiceResponse response = searchConsentWrapper.searchConsentWithCustomRequest(
                requestWithNullAccountId, lob, tenantId);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);
        Assert.assertEquals("Error code mismatch", expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("Test passed - Error: " + actualErrorMessage);
    }

    /**
     * Scenario 10: Missing Account ID (blank value)
     */
    @Test(description = "Validate Search Consent API fails when accountId is blank",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent"}, retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentNegative")
    public void searchConsentShouldFailWhenAccountIdBlank(
            String testname, String description, String accountIdType, String formCode, String lob, String tenantId,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        List<String> formCodeList = Arrays.asList(formCode.split(","));

        SearchConsentRequest requestWithBlankAccountId = SearchConsentRequest.builder()
                .accountId("")
                .accountIdType(accountIdType)
                .formCode(formCodeList)
                .build();

        ServiceResponse response = searchConsentWrapper.searchConsentWithCustomRequest(
                requestWithBlankAccountId, lob, tenantId);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);
        Assert.assertEquals("Error code mismatch", expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("Test passed - Error: " + actualErrorMessage);
    }

//    /**
//     * Scenario 11: PET Type Customer
//     * Note: This test creates a PET type account dynamically and validates that
//     * the Search Consent API fails for PET type customers.
//     */
    @Test(description = "Validate Search Consent API fails for PET type customer",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent"}, retryAnalyzer = Retry.class)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentNegative")
    public void searchConsentShouldFailForPetTypeCustomer(
            String testname, String description, String accountIdType, String formCode, String lob, String tenantId,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) throws Exception {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");

        List<String> formCodeList = Arrays.asList(formCode.split(","));

        // Create PET Type Account dynamically with default values
        String petEmail = CommonUtil.generateRandomEmailId(10);
        String petFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String petLastName = CommonUtil.generateRandomLastName(5).toUpperCase();
        String defaultDOB = "11111998";  // Default DOB in DDMMYYYY format
        String defaultStoreNo = "5548";  // Default store number

        List<String> petDetails = digitalPharmacyOperationsUtil.testAccountCreation(petEmail, petFirstName, petLastName,defaultDOB,defaultStoreNo,false, true);
        String pet_cid = petDetails.get(0);
        Reporter.logJSON("PET Customer Account Id", pet_cid);

        ServiceResponse response = searchConsentWrapper.searchConsent(
                pet_cid, accountIdType, formCodeList, lob, tenantId);

        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("Test passed - Error: " + actualErrorMessage);
    }

    // =====================================================================
    // SAVE + SEARCH CONSENT API - SUCCESS SCENARIOS (END-TO-END)
    // =====================================================================

    /**
     * SCENARIO 1: Save Ecomm Consent (50000) for Self - ACCEPT
     * Flow: Create Account → Save Consent → Search Consent → Validate ACCEPT
     *
     * Expected:
     * - Save: 200 OK, status: CREATED
     * - Search: 200 OK, selfAuthorization: ACCEPT
     */
    @Test(description = "Save Ecomm Consent for Self (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 1)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveEcommConsentForSelf_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save Consent (50000) → Search Consent → Validate ACCEPT");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Ecomm Consent (50000) for Self
;        Reporter.log("Step 2: Saving Ecomm Consent (50000) via PUT /v1/consents");
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertNotNull("Save response payload should not be null", saveConsentResponse.getPayload());
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());

        // Verify CREATED status for the consent
        Assert.assertNotNull("CustomerConsentInfo should not be null", saveConsentResponse.getPayload().getCustomerConsentInfo());
        Assert.assertTrue("Should have at least 1 consent info",
                saveConsentResponse.getPayload().getCustomerConsentInfo().size() >= 1);
        Assert.assertEquals("Consent status should be CREATED", "CREATED",
                saveConsentResponse.getPayload().getCustomerConsentInfo().get(0).getStatus());
        Reporter.logJSON("Save Consent Response", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 3: Search Consent and validate
        Reporter.log("Step 3: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be " + expectedStatusCode, expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        Assert.assertNotNull("Search response should not be null", searchConsentResponse);

        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary customer consent info should not be null", primaryConsent);

        // Validate Self Authorization for both form codes using generic helper methods
        // For this test (Ecomm only): 50000 should be ACCEPT, 50001 should be null
        validateAllFormCodeAuthorizations(primaryConsent, expectedAuthStatus, null, "Self");

        Reporter.logJSON("PASSED - Save Ecomm Consent for Self (ACCEPT)", searchConsentResponse);
    }

    /**
     * SCENARIO 2: Save Extended HIPAA Consent (50001) for Self - ACCEPT
     * Flow: Create Account → Save Consent → Search Consent → Validate ACCEPT
     */
    @Test(description = "Save Extended HIPAA Consent for Self (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 2)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveExtendedHipaaConsentForSelf_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save Consent (50001) → Search Consent → Validate ACCEPT");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Extended HIPAA Consent (50001) for Self
        Reporter.log("Step 2: Saving Extended HIPAA Consent (50001) via PUT /v1/consents");
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Save Consent Response", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 3: Search Consent and validate
        Reporter.log("Step 3: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, Collections.singletonList(HIPAA_FORM_CODE), lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for HIPAA form code (50001)
        validateAuthorizationForFormCode(primaryConsent, HIPAA_FORM_CODE, expectedAuthStatus, "Self");

        Reporter.logJSON("PASSED - Save Extended HIPAA Consent for Self (ACCEPT)", searchConsentResponse);
    }

    /**
     * =====================================================================
     * SCENARIO 3: Save Both Ecomm & Extended HIPAA Consent for Self - ACCEPT → Revoke → DENY
     * =====================================================================
     *
     * Description: Save ECOMM (50000) and Extended HIPAA (50001) consent for Self,
     *              then Revoke all consents for Self and validate DENY.
     *
     * Flow:
     *   Step 1: Create Caregiver Account
     *   Step 2: Save ECOMM + HIPAA Consent for Self → PUT /v1/consents
     *   Step 3: Search Consent → POST /v1/consents/search → Validate ACCEPT
     *   Step 4: Revoke Consent for Self → POST v1/consents/customer/{cid}/revoke
     *   Step 5: Search Consent → POST /v1/consents/search → Validate DENY
     *
     * Revoke API Details:
     *   - Endpoint: POST v1/consents/customer/{cid}/revoke
     *   - Request: No body required (revokes all consents for the given CID)
     *   - Method: customerConsentWrapper.revokeCustomerConsent(caregiver_cid)
     *
     * Expected:
     *   - Save status code: 200, Search after Save: ACCEPT (ECOMM + HIPAA)
     *   - Revoke status code: 200, Search after Revoke: DENY (ECOMM + HIPAA)
     */
    @Test(description = "Save Ecomm + Extended HIPAA Consent for Self (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "revokeConsent"}, retryAnalyzer = Retry.class, priority = 3)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveEcommAndHipaaConsentForSelf_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save Both Consents (50000 + 50001) → Search → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Both Ecomm + Extended HIPAA Consent one by one as save not support multiple forms
        Reporter.log("Step 2: Saving Ecomm HIPAA Consent via PUT /v1/consents");
        ServiceResponse saveResponse1 = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, ECOMM_FORM_CODE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse1.getStatusCode());
        SaveConsentResponse saveConsentResponse1 = saveResponse1.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse1.getPayload().getStatus());

        Thread.sleep(60);
        ServiceResponse saveResponse2 = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, HIPAA_FORM_CODE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse2.getStatusCode());
        SaveConsentResponse saveConsentResponse2 = saveResponse2.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse2.getPayload().getStatus());


        // Wait for consent propagation
        Thread.sleep(30);

        // Step 3: Search Consent and validate
        Reporter.log("Step 3: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for both form codes - both should be ACCEPT
        validateAllFormCodeAuthorizations(primaryConsent, expectedAuthStatus, expectedAuthStatus, "Self");

        Reporter.logJSON("Save + Search Ecomm + HIPAA Consent for Self - ACCEPT validated", searchConsentResponse);

        // =====================================================================
        // REVOKE ECOMM & HIPAA CONSENT FOR SELF - DENY
        // =====================================================================
        Reporter.log("Step 4: Revoking Ecomm + Extended HIPAA Consent for Self (DENY) via Post v1/consents/customer/{cid}/revoke");
        ServiceResponse revokeResponse = customerConsentWrapper.revokeCustomerConsent(caregiver_cid);

        Assert.assertEquals("Revoke Consent status code should be 200", 200, revokeResponse.getStatusCode());
        SaveConsentResponse revokeConsentResponse = revokeResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertTrue("Revoke status should be SUCCESS",
                "SUCCESS".equalsIgnoreCase(revokeConsentResponse.getPayload().getStatus()));
        Reporter.logJSON("Revoke Consent Response", revokeConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Search Consent after Revoke and validate DENY
        Reporter.log("Step 5: Searching consent after Revoke via POST /v1/consents/search");
        ServiceResponse searchAfterRevokeResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search after revoke status code should be 200", expectedStatusCode, searchAfterRevokeResponse.getStatusCode());

        SearchConsentResponse searchAfterRevokeConsentResponse = searchAfterRevokeResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsentAfterRevoke = searchAfterRevokeConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for both form codes - should be DENY after revoke
        validateAllFormCodeAuthorizations(primaryConsentAfterRevoke, AUTH_STATUS_DENY, AUTH_STATUS_DENY, "Self after Revoke");

        Reporter.logJSON("PASSED - Save + Revoke Ecomm + HIPAA Consent for Self (ACCEPT → DENY)", searchAfterRevokeConsentResponse);
    }

    /**
     * SCENARIO 4: Revoke Ecomm & Extended HIPAA Consent for Self - DENY
     * Flow: Create Account → Save ACCEPT → Revoke (DENY) → Search → Validate DENY
     */
    @Test(description = "Revoke Ecomm + Extended HIPAA Consent for Self (DENY) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 4)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void revokeEcommAndHipaaConsentForSelf_Deny(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save ACCEPT → Revoke (DENY) → Search → Validate DENY");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save ACCEPT consent first ECOMM
        Reporter.log("Step 2: Saving ACCEPT Consent via PUT /v1/consents");
        ServiceResponse saveAcceptResponse1 = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE,ECOMM_FORM_CODE);
        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponse1.getStatusCode());

        ServiceResponse saveAcceptResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE,HIPAA_FORM_CODE);
        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponse1.getStatusCode());

        Thread.sleep(2000);

        // Step 3: Revoke (DENY) consent
        Reporter.log("Step 3: Revoking Consent (DENY) via PUT /v1/consents");
        ServiceResponse revokResponse = saveConsentWrapper.revokeEcommAndExtendedHipaaForSelf(
                caregiver_cid, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Revoke Consent status code should be 200", 200, revokResponse.getStatusCode());
        SaveConsentResponse revokeConsentResponse = revokResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Revoke status should be SUCCESS", "SUCCESS", revokeConsentResponse.getPayload().getStatus());

        // Verify UPDATED status for both consents
        for (SaveConsentResponse.CustomerConsentInfo info : revokeConsentResponse.getPayload().getCustomerConsentInfo()) {
            Assert.assertEquals("Consent status should be UPDATED", "UPDATED", info.getStatus());
            Assert.assertEquals("Authorization should be DENY", AUTH_STATUS_DENY, info.getAuthorization());
        }
        Reporter.logJSON("Revoke Consent Response", revokeConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 4: Search Consent and validate DENY
        Reporter.log("Step 4: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for both form codes - should be DENY after revoke
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_DENY, AUTH_STATUS_DENY, "Self");

        Reporter.logJSON("PASSED - Revoke Ecomm + HIPAA Consent for Self", searchConsentResponse);
    }

    /**
     * SCENARIO 5: v1 Legacy Flow - Save Ecomm Consent for Self + Minor - ACCEPT
     * Flow: Create Accounts → Add Dependent → Save Consent (v1Legacy=true) → Search → Validate
     */
    @Test(description = "v1 Legacy: Save Ecomm Consent for Self + Minor (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "v1Legacy"}, retryAnalyzer = Retry.class, priority = 5)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void v1Legacy_saveEcommConsentForSelfAndMinor_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save Consent (v1Legacy) → Search → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        Reporter.log("Step 3: Adding Minor as Dependent");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Consent with v1Legacy=true
        Reporter.log("Step 4: Saving Ecomm Consent (v1Legacy=true) via PUT /v1/consents");
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForSelfAndMinor(
                caregiver_cid, minor_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, true);


        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());

        // Verify 2 CREATED entries (one for caregiver, one for minor)
        Assert.assertEquals("Should have 2 consent info entries", 2,
                saveConsentResponse.getPayload().getCustomerConsentInfo().size());
        Reporter.logJSON("Save Consent Response (v1 Legacy)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Search Consent and validate
        Reporter.log("Step 5: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for ECOMM form code
        validateAuthorizationForFormCode(primaryConsent, ECOMM_FORM_CODE, expectedAuthStatus, "Self");

        // Validate Minor Dependent Authorization
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        Assert.assertNotNull("Dependents should not be null", dependents);
        Assert.assertTrue("Should have at least 1 dependent", dependents.size() >= 1);

        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                // For Minor: validate caregiverAuthorization instead of authorization
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, expectedAuthStatus, expectedAuthStatus, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - v1 Legacy Save Ecomm for Self + Minor", searchConsentResponse);
    }

    /**
     * SCENARIO 6: Save Extended HIPAA Consent for Self + Minor - ACCEPT
     * Flow: Create Accounts → Add Dependent → Save Consent → Search → Validate
     */
    @Test(description = "Save Extended HIPAA Consent for Self + Minor (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 6)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveExtendedHipaaConsentForSelfAndMinor_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save Extended HIPAA → Search → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        Reporter.log("Step 3: Adding Minor as Dependent");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Extended HIPAA Consent for Self + Minor
        Reporter.log("Step 4: Saving Extended HIPAA Consent for Self + Minor");
        ServiceResponse saveResponse = saveConsentWrapper.saveExtendedHipaaForSelfAndMinor(
                caregiver_cid, minor_cid, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Save Extended HIPAA Response", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Search Consent and validate
        Reporter.log("Step 5: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for HIPAA form code
        validateAuthorizationForFormCode(primaryConsent, HIPAA_FORM_CODE, expectedAuthStatus, "Self");

        // Validate Minor caregiverAuthorization as well
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - Save Extended HIPAA for Self + Minor", searchConsentResponse);
    }

    /**
     * SCENARIO 7: Revoke Ecomm & Extended HIPAA Consent for Only Minor
     * Flow: Create Accounts → Add Minor → Save ACCEPT → Revoke Minor Only → Search → Validate
     */
    @Test(description = "Revoke Ecomm + HIPAA Consent for Only Minor then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 7)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void revokeEcommAndHipaaConsentForOnlyMinor_Deny(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save ACCEPT → Revoke Minor Only → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save ACCEPT consent for both Self and Minor
        Reporter.log("Step 4: Saving ACCEPT Consent for Self + Minor");
        ServiceResponse saveAcceptResponse1 = saveConsentWrapper.saveEcommAndExtendedHipaaForSelfAndMinorDENY(
                caregiver_cid, minor_cid, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false, ECOMM_FORM_CODE);
        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponse1.getStatusCode());


        ServiceResponse saveAcceptResponse2 = saveConsentWrapper.saveEcommAndExtendedHipaaForSelfAndMinorDENY(
                caregiver_cid, minor_cid, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false, HIPAA_FORM_CODE);
        Thread.sleep(2000);
        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponse2.getStatusCode());

        // Step 5: Revoke consent for Only Minor
        Reporter.log("Step 5: Revoking consent for Only Minor");
        ServiceResponse revokeResponse = saveConsentWrapper.revokeEcommAndExtendedHipaaForOnlyMinor(
                caregiver_cid, minor_cid, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Revoke status code should be 200", 200, revokeResponse.getStatusCode());
        SaveConsentResponse revokeConsentResponse = revokeResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Revoke status should be SUCCESS", "SUCCESS", revokeConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Revoke Minor Consent Response", revokeConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Caregiver's consent should still be ACCEPT for both form codes
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Caregiver Self");

        // Minor's consent should be DENY for both form codes
        // For Minor: validate caregiverAuthorization instead of authorization
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_DENY, AUTH_STATUS_DENY, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - Revoke Consent for Only Minor", searchConsentResponse);
    }

    /**
     * SCENARIO 8: Save HIPAA Consent for Only Minor (caregiver consent doesn't exist)
     * Flow: Create Accounts → Add Minor → Save Consent for Minor Only → Search → Validate
     */
    @Test(description = "Save HIPAA Consent for Only Minor (caregiver consent doesn't exist)",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 8)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveHIPPAConsentForOnlyMinor_NoCaregiverConsent(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save Consent for Minor Only → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Consent for Only Minor (NO caregiver consent)
        Reporter.log("Step 4: Saving Ecomm Consent for Only Minor (NO caregiver consent)");
        ServiceResponse saveResponse = saveConsentWrapper.saveConsentForOnlyMinor(
                caregiver_cid, minor_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Consent status code should be 200", 200, saveResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());

        // Only 1 consent (for minor) should be CREATED
        Assert.assertEquals("Should have 1 consent info entry", 1,
                saveConsentResponse.getPayload().getCustomerConsentInfo().size());
        Assert.assertEquals("Minor consent status should be CREATED", "CREATED",
                saveConsentResponse.getPayload().getCustomerConsentInfo().get(0).getStatus());
        Reporter.logJSON("Save Consent Response (Only Minor)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Search Consent and validate
        Reporter.log("Step 5: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Caregiver's consent should be null (no consent saved) for ECOMM
        validateAuthorizationForFormCode(primaryConsent, HIPAA_FORM_CODE, null, "Caregiver Self");


        // Minor's consent should be ACCEPT for ECOMM
        // For Minor: validate caregiverAuthorization instead of authorization
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - Save Consent for Only Minor (no caregiver consent)", searchConsentResponse);
    }

    /**
     * =====================================================================
     * SCENARIO 9: Save HIPAA Consent for Adult Dependent - ACCEPT → Revoke by DependentId → DENY
     * =====================================================================
     *
     * Description: Save Extended HIPAA (50001) consent for Caregiver and Adult Dependent,
     *              then Revoke consent for Adult Dependent by dependentId and validate
     *              Caregiver = ACCEPT, Adult Dependent = DENY.
     *
     * Flow:
     *   Step 1: Create Caregiver Account
     *   Step 2: Create Adult Dependent Account
     *   Step 3: Add Adult as Dependent (LinkageStatus=ACTIVE)
     *   Step 4: Save HIPAA Consent for Caregiver → PUT /v1/consents
     *   Step 5: Save HIPAA Consent for Adult Dependent → PUT /v1/consents
     *   Step 6: Search Consent → POST /v1/consents/search → Validate ACCEPT
     *   Step 7: Revoke Consent for Adult Dependent by DependentId → POST v1/consents/customer/{cid}/revoke
     *   Step 8: Search Consent → POST /v1/consents/search → Validate Caregiver=ACCEPT, Adult=DENY
     *
     * Revoke API Details:
     *   - Endpoint: POST v1/consents/customer/{cid}/revoke
     *   - Request Body: {"dependentId": ["<adult_dependent_cid>"]}
     *   - Method: customerConsentWrapper.revokeCustomerConsentWithPayload(caregiver_cid, dependentIdsPayload)
     *
     * Expected:
     *   - Save status code: 200, Search after Save: Caregiver=ACCEPT, Adult=ACCEPT
     *   - Revoke status code: 200, Search after Revoke: Caregiver=ACCEPT, Adult=DENY
     *
     * SCENARIO 9: Save HIPAA Consent for Adult Dependent - ACCEPT
     * Flow: Create Accounts → Add Adult Dependent → Save Consent → Search → Validate
     */
    @Test(description = "Save HIPAA Consent for Adult Dependent (ACCEPT) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "revokeConsent"}, retryAnalyzer = Retry.class, priority = 9)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveHIPAAConsentForAdultDependent_Accept(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Adult Dependent → Save Consent → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Adult Dependent Account
        String adultEmail = CommonUtil.generateRandomEmailId(10);
        String adultFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> adultDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                adultEmail, adultFirstName, adultLastName, adultDependentDOB, storeNo);
        String adult_cid = adultDetails.get(0);
        Reporter.logJSON("Step 2 - Created Adult Dependent Account", adult_cid);

        // Step 3: Add Adult as Dependent
        Reporter.log("Step 3: Adding Adult as Dependent");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adult_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Consent for Caregiver
        Reporter.log("Step 4: Saving Consent for Caregiver");
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, HIPAA_FORM_CODE);
        Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        // Step 5: Save Consent for Adult Dependent
        Reporter.log("Step 5: Saving Consent for Adult Dependent");
        ServiceResponse saveAdultResponse = saveConsentWrapper.saveExtendedHipaaForAdultDependent(
                adult_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Adult status code should be 200", 200, saveAdultResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveAdultResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Save Consent Response (Adult Dependent)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Caregiver Self Authorization for ECOMM
        validateAuthorizationForFormCode(primaryConsent, HIPAA_FORM_CODE, expectedAuthStatus, "Caregiver Self");

        // Validate Adult Dependent Authorization for ECOMM
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        Assert.assertNotNull("Dependents should not be null", dependents);

        for (CustomerConsentInfo dependent : dependents) {
            if ("ADULT".equals(dependent.getCustomerInfo().getType())) {
                validateAuthorizationForFormCode(dependent, HIPAA_FORM_CODE, expectedAuthStatus, "Adult Dependent");
            }
        }

        Reporter.logJSON("Save + Search Consent for Adult Dependent - ACCEPT validated", searchConsentResponse);

        // =====================================================================
        // REVOKE EXTENDED HIPAA CONSENT FOR ADULT DEPENDENT BY DEPENDENT ID - DENY
        // =====================================================================


        // Step 7: Revoke (DENY) Extended HIPAA consent for Adult Dependent by saving DENY
        // Calling revoke

        List<String> ids = Arrays.asList(adult_cid);
        Map<String, List<String>> map = new HashMap<>();
        map.put("dependentId", ids);
        ObjectMapper mapper = new ObjectMapper();
        String dependentIdsPayload = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(map);
        ServiceResponse serviceResponse =
                customerConsentWrapper.revokeCustomerConsentWithPayload(
                        caregiver_cid, dependentIdsPayload);
        Assert.assertEquals("Revoke Adult Dependent status code should be 200", 200, serviceResponse.getStatusCode());

        // Wait for consent propagation after revoke
        Thread.sleep(5000);

        // Step 8: Search Consent after Revoke and validate DENY for Adult Dependent
        Reporter.log("Step 8: Searching consent after Revoke via POST /v1/consents/search");
        ServiceResponse searchAfterRevokeResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search after revoke status code should be 200", expectedStatusCode, searchAfterRevokeResponse.getStatusCode());

        SearchConsentResponse searchAfterRevokeConsentResponse = searchAfterRevokeResponse.getDataResponse(SearchConsentResponse.class);

        // Validate Caregiver Self Authorization - should still be ACCEPT (untouched)
        CustomerConsentInfo primaryConsentAfterRevoke = searchAfterRevokeConsentResponse.getPrimaryCustomerConsentInfo();
        validateAuthorizationForFormCode(primaryConsentAfterRevoke, HIPAA_FORM_CODE, expectedAuthStatus, "Caregiver Self after Adult Revoke");

        // Validate Adult Dependent Authorization - should be ACCEPT ONLY as Extended HIPPA will not mark adult dependent as DENY after revoke
        List<CustomerConsentInfo> dependentsAfterRevoke = searchAfterRevokeConsentResponse.getDependentCustomerConsentInfo();
        Assert.assertNotNull("Dependents after revoke should not be null", dependentsAfterRevoke);

        for (CustomerConsentInfo dependent : dependentsAfterRevoke) {
            if ("ADULT".equals(dependent.getCustomerInfo().getType())) {
                validateAuthorizationForFormCode(dependent, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT, "Adult Dependent after Revoke");
            }
        }

        Reporter.logJSON("PASSED - Save + Revoke Extended HIPAA for Adult Dependent (ACCEPT → DENY)", searchAfterRevokeConsentResponse);
    }

    /**
     * =====================================================================
     * SCENARIO 10: Revoke Consent When Consent Doesn't Exist - SKIPPED
     * =====================================================================
     *
     * Description: Attempt to Revoke ECOMM + HIPAA consent when no consent has been saved.
     *              Validates revoke behavior for both Self and Minor when no prior consent exists.
     *
     * Flow:
     *   Step 1: Create Caregiver Account (no consent saved)
     *   Step 2: Revoke Consent for Self → POST v1/consents/customer/{cid}/revoke → Validate SKIPPED
     *   Step 3: Search Consent → POST /v1/consents/search → Validate null (no consent)
     *   Step 4: Create Minor Dependent Account (no consent saved)
     *   Step 5: Add Minor as Dependent
     *   Step 6: Revoke Consent for Minor by DependentId → POST v1/consents/customer/{cid}/revoke
     *   Step 7: Search Consent → POST /v1/consents/search → Validate null for both Self & Minor
     *
     * Revoke API Details:
     *   - Self Revoke Endpoint: POST v1/consents/customer/{cid}/revoke
     *     Request: No body required
     *     Method: customerConsentWrapper.revokeCustomerConsent(caregiver_cid)
     *
     *   - Minor Revoke Endpoint: POST v1/consents/customer/{cid}/revoke
     *     Request Body: {"dependentId": ["<minor_cid>"]}
     *     Method: customerConsentWrapper.revokeCustomerConsentWithPayload(caregiver_cid, dependentIdsPayload)
     *
     * Expected:
     *   - Revoke Self status code: 200 (SKIPPED - no consent to revoke)
     *   - Revoke Minor status code: 200 (SKIPPED - no consent to revoke)
     *   - Search: Self = null, Minor = null (no consent exists)
     */
    @Test(description = "Revoke Consent when consent doesn't exist - should return SKIPPED",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "revokeConsent"}, retryAnalyzer = Retry.class, priority = 10)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void revokeConsentWhenConsentDoesNotExist_Skipped(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Revoke Self (SKIPPED) → Create Minor → Revoke Minor (SKIPPED) → Validate");

        // Step 1: Create Fresh Account (NO consent saved)
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Fresh Account (no consent)", caregiver_cid);

        // Step 2: Try to Revoke consent for Self (should return SKIPPED since no consent exists)
        Reporter.log("Step 2: Attempting to Revoke consent for Self (no prior consent exists) via POST v1/consents/customer/{cid}/revoke");
        ServiceResponse revokeResponse = customerConsentWrapper.revokeCustomerConsent(caregiver_cid);

        Assert.assertEquals("Revoke status code should be 200", 200, revokeResponse.getStatusCode());
        Reporter.logJSON("Revoke Self Response (SKIPPED - no consent)", revokeResponse);

        // Step 3: Search Consent - should return null/no consent
        Reporter.log("Step 3: Searching consent (should have no consent)");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization should be null (no consent) for both form codes
        validateAllFormCodeAuthorizations(primaryConsent, null, null, "Self");

        Reporter.logJSON("Revoke Self (SKIPPED when no consent exists) validated", searchConsentResponse);

        // =====================================================================
        // REVOKE ECOMM & HIPAA WHEN NO CONSENT AVAILABLE - MINOR DEPENDENT
        // =====================================================================

        // Step 4: Create Minor Dependent Account (no consent saved)
        Reporter.log("Step 4: Creating Minor Dependent Account (no consent)");
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 4 - Created Minor Account (no consent)", minor_cid);

        // Step 5: Add Minor as Dependent
        Reporter.log("Step 5: Adding Minor as Dependent");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 6: Try to Revoke consent for Minor (should return SKIPPED since no consent exists)
        Reporter.log("Step 6: Attempting to Revoke consent for Minor (no prior consent exists) via POST v1/consents/customer/{cid}/revoke");
        List<String> minorIds = Arrays.asList(minor_cid);
        Map<String, List<String>> minorMap = new HashMap<>();
        minorMap.put("dependentId", minorIds);
        ObjectMapper minorMapper = new ObjectMapper();
        String minorDependentIdsPayload = minorMapper.writerWithDefaultPrettyPrinter().writeValueAsString(minorMap);
        ServiceResponse revokeMinorResponse = customerConsentWrapper.revokeCustomerConsentWithPayload(
                caregiver_cid, minorDependentIdsPayload);

        Assert.assertEquals("Revoke Minor status code should be 200", 200, revokeMinorResponse.getStatusCode());
        Reporter.logJSON("Revoke Minor Response (SKIPPED - no consent)", revokeMinorResponse);

        // Step 7: Search Consent after Minor revoke - should still return null/no consent for both
        Reporter.log("Step 7: Searching consent after Minor revoke (should have no consent)");
        ServiceResponse searchAfterMinorRevokeResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchAfterMinorRevokeResponse.getStatusCode());

        SearchConsentResponse searchAfterMinorRevokeConsentResponse = searchAfterMinorRevokeResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsentAfterMinorRevoke = searchAfterMinorRevokeConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization should still be null (no consent)
        validateAllFormCodeAuthorizations(primaryConsentAfterMinorRevoke, null, null, "Self after Minor Revoke");

        // Validate Minor caregiverAuthorization should be null (no consent)
        List<CustomerConsentInfo> dependentsAfterRevoke = searchAfterMinorRevokeConsentResponse.getDependentCustomerConsentInfo();
        if (dependentsAfterRevoke != null) {
            for (CustomerConsentInfo dependent : dependentsAfterRevoke) {
                if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                    validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, null, null, "Minor Dependent (no consent)", formCodeList);
                }
            }
        }

        Reporter.logJSON("PASSED - Revoke ECOMM & HIPAA When No Consent Available (Self + Minor SKIPPED)", searchAfterMinorRevokeConsentResponse);
    }

    /**
     * SCENARIO 12: Search Consent with No Consent Saved - Fresh Account
     * Flow: Create Account → Search (no save) → Validate null authorization
     */
    @Test(description = "Search Consent for fresh account with no consent saved",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent"}, retryAnalyzer = Retry.class, priority = 12)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentForFreshAccount_NoConsent(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Fresh Account → Search (no save) → Validate null authorization");

        // Step 1: Create Fresh Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Fresh Account (no consent)", caregiver_cid);

        // Step 2: Search Consent directly (no save)
        Reporter.log("Step 2: Searching consent without saving any");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization should be null for fresh account for both form codes
        validateAllFormCodeAuthorizations(primaryConsent, null, null, "Self");

        Reporter.logJSON("PASSED - Search Consent for Fresh Account", searchConsentResponse);
    }

    // =====================================================================
    // ADDITIONAL SCENARIOS - COMPLETE COVERAGE
    // =====================================================================

    /**
     * SCENARIO 13: Revoke Ecomm & Extended HIPAA Consent for Only Caregiver (with minor dependent)
     * Flow: Create Accounts → Add Minor → Save ACCEPT for both → Revoke Caregiver Only → Search → Validate
     *
     * Expected: Caregiver consent = DENY, Minor consent = ACCEPT (unchanged)
     */
    @Test(description = "Revoke Ecomm + HIPAA Consent for Only Caregiver (with minor) then validate via Search",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 13)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void revokeEcommAndHipaaConsentForOnlyCaregiver_WithMinor(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save ACCEPT for both → Revoke Caregiver Only → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save ACCEPT consent for both Self and Minor
        Reporter.log("Step 4: Saving ACCEPT Consent for Self + Minor");
        ServiceResponse saveAcceptResponseECOMM = saveConsentWrapper.saverSelfAndMinor(
                caregiver_cid, minor_cid, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false,ECOMM_FORM_CODE);

        ServiceResponse saveAcceptResponseHIPPA = saveConsentWrapper.saverSelfAndMinor(
                caregiver_cid, minor_cid, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false,HIPAA_FORM_CODE);


        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponseECOMM.getStatusCode());
        Assert.assertEquals("Save ACCEPT status code should be 200", 200, saveAcceptResponseHIPPA.getStatusCode());


        Thread.sleep(2000);

        // Step 5: Revoke consent for Only Caregiver (minor consent unchanged)
        Reporter.log("Step 5: Revoking consent for Only Caregiver");
        ServiceResponse revokeResponse = saveConsentWrapper.revokeEcommAndExtendedHipaaForSelf(
                caregiver_cid, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Revoke status code should be 200", 200, revokeResponse.getStatusCode());
        SaveConsentResponse revokeConsentResponse = revokeResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Revoke status should be SUCCESS", "SUCCESS", revokeConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Revoke Caregiver Consent Response", revokeConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Caregiver's consent should be DENY for both form codes
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_DENY, AUTH_STATUS_DENY, "Caregiver Self");

        // Minor's consent should still be ACCEPT (unchanged) for both form codes
        // For Minor: validate caregiverAuthorization instead of authorization
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - Revoke Consent for Only Caregiver (with minor)", searchConsentResponse);
    }

    /**
     * SCENARIO 14: Save Ecomm Consent for Only Minor (when caregiver consent already exists)
     * Flow: Create Accounts → Add Minor → Save Consent for Caregiver → Save Consent for Minor → Search → Validate
     *
     * Expected: Minor consent = UPDATED (since caregiver consent exists)
     */
    @Test(description = "Save Ecomm Consent for Only Minor (when caregiver consent exists)",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent"}, retryAnalyzer = Retry.class, priority = 14)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveEcommConsentForOnlyMinor_WhenCaregiverConsentExists(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save Caregiver Consent → Save Minor Consent → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save Consent for Caregiver FIRST
        Reporter.log("Step 4: Saving Ecomm Consent for Caregiver FIRST");
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        Thread.sleep(2000);

        // Step 5: Now save Consent for Only Minor (caregiver consent already exists)
        Reporter.log("Step 5: Saving Ecomm Consent for Only Minor (caregiver consent exists)");
        ServiceResponse saveMinorResponse = saveConsentWrapper.saveConsentForOnlyMinor(
                caregiver_cid, minor_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Minor status code should be 200", 200, saveMinorResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveMinorResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());

        // When caregiver consent exists, minor consent should show UPDATED or CREATED
        Reporter.logJSON("Save Consent Response (Minor when caregiver exists)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Caregiver's consent should be ACCEPT for ECOMM
        validateAuthorizationForFormCode(primaryConsent, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT, "Caregiver Self");

        // Minor's consent should be ACCEPT for ECOMM
        // For Minor: validate caregiverAuthorization instead of authorization
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Minor Dependent", formCodeList);
            }
        }

        Reporter.logJSON("PASSED - Save Consent for Minor (when caregiver consent exists)", searchConsentResponse);
    }

    /**
     * SCENARIO 15: Save Ecomm Consent for Adult Dependent (with PENDING consent request)
     * Flow: Create Accounts → Add Adult → Create PENDING consent request → Save Consent → Search → Validate
     *
     * Expected: Adult consent request = ACCEPTED, Consent = CREATED
     */
    @Test(description = "Save Ecomm Consent for Adult Dependent with PENDING consent request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "adultConsentRequest"}, retryAnalyzer = Retry.class, priority = 15)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveEcommConsentForAdultDependent_WithPendingConsentRequest(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Adult → Create PENDING request → Save Consent → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Adult Dependent Account
        String adultEmail = CommonUtil.generateRandomEmailId(10);
        String adultFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> adultDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                adultEmail, adultFirstName, adultLastName, adultDependentDOB, storeNo);
        String adult_cid = adultDetails.get(0);
        Reporter.logJSON("Step 2 - Created Adult Dependent Account", adult_cid);

        // Step 3: Add Adult as Dependent (this creates a PENDING consent request)
        Reporter.log("Step 3: Adding Adult as Dependent (creates PENDING consent request)");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adult_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        Thread.sleep(2000);

        // Step 4: Save Consent for Adult Dependent (this should ACCEPT the pending request)
        Reporter.log("Step 4: Saving Ecomm Consent for Adult Dependent (ACCEPTS pending request)");
        ServiceResponse saveAdultResponse = saveConsentWrapper.saveConsentForSelf(
                adult_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Adult status code should be 200", 200, saveAdultResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveAdultResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Assert.assertEquals("Consent status should be CREATED", "CREATED",
                saveConsentResponse.getPayload().getCustomerConsentInfo().get(0).getStatus());
        Reporter.logJSON("Save Consent Response (Adult with PENDING request)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Save consent for Caregiver as well
        Reporter.log("Step 5: Saving consent for Caregiver");
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE,ECOMM_FORM_CODE);
        Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        Reporter.logJSON("PASSED - Save Ecomm for Adult with PENDING consent request", searchConsentResponse);
    }

    /**
     * SCENARIO 16: Save Extended HIPAA Consent for Adult Dependent (with PENDING consent request)
     * Flow: Create Accounts → Add Adult → Create PENDING consent request → Save HIPAA Consent → Search → Validate
     */
    @Test(description = "Save Extended HIPAA Consent for Adult Dependent with PENDING consent request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "adultConsentRequest"}, retryAnalyzer = Retry.class, priority = 16)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveExtendedHipaaConsentForAdultDependent_WithPendingConsentRequest(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Adult → Create PENDING request → Save HIPAA Consent → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Adult Dependent Account
        String adultEmail = CommonUtil.generateRandomEmailId(10);
        String adultFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> adultDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                adultEmail, adultFirstName, adultLastName, adultDependentDOB, storeNo);
        String adult_cid = adultDetails.get(0);
        Reporter.logJSON("Step 2 - Created Adult Dependent Account", adult_cid);

        // Step 3: Add Adult as Dependent (creates PENDING consent request)
        Reporter.log("Step 3: Adding Adult as Dependent (creates PENDING consent request)");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adult_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        Thread.sleep(2000);

        // Step 4: Save Extended HIPAA Consent for Adult Dependent
        Reporter.log("Step 4: Saving Extended HIPAA Consent for Adult Dependent");
        ServiceResponse saveAdultResponse = saveConsentWrapper.saveConsentForSelf(
                adult_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Save Adult HIPAA status code should be 200", 200, saveAdultResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveAdultResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Reporter.logJSON("Save Extended HIPAA Response (Adult with PENDING request)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Save consent for Caregiver
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, HIPAA_FORM_CODE);
            Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        Reporter.logJSON("PASSED - Save Extended HIPAA for Adult with PENDING consent request", searchConsentResponse);
    }

    /**
     * SCENARIO 17: Revoke Extended HIPAA Consent for Adult Dependent (with ACCEPTED consent request)
     * Flow: Create Accounts → Add Adult → Save ACCEPT → Revoke (DENY) → Search → Validate
     *
     * Expected: Adult consent = DENY, P13n notification sent for REJECTED
     */
    @Test(description = "Revoke Extended HIPAA Consent for Adult Dependent with ACCEPTED consent request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "adultConsentRequest"}, retryAnalyzer = Retry.class, priority = 17)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void revokeExtendedHipaaConsentForAdultDependent_WithAcceptedConsentRequest(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Adult → Save ACCEPT → Revoke (DENY) → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Adult Dependent Account
        String adultEmail = CommonUtil.generateRandomEmailId(10);
        String adultFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> adultDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                adultEmail, adultFirstName, adultLastName, adultDependentDOB, storeNo);
        String adult_cid = adultDetails.get(0);
        Reporter.logJSON("Step 2 - Created Adult Dependent Account", adult_cid);

        // Step 3: Add Adult as Dependent
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adult_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        Thread.sleep(2000);

        // Step 4: Save ACCEPT consent for Adult Dependent (ACCEPTS the consent request)
        Reporter.log("Step 4: Saving ACCEPT Extended HIPAA Consent for Adult Dependent");
        ServiceResponse saveAdultResponse = saveConsentWrapper.saveConsentForSelf(
                adult_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save Adult status code should be 200", 200, saveAdultResponse.getStatusCode());

        Thread.sleep(2000);

        // Step 5: Revoke (DENY) consent for Adult Dependent
        Reporter.log("Step 5: Revoking Extended HIPAA Consent for Adult Dependent");
        ServiceResponse revokeAdultResponse = saveConsentWrapper.saveConsentForSelf(
                adult_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_DENY,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Assert.assertEquals("Revoke Adult status code should be 200", 200, revokeAdultResponse.getStatusCode());
        SaveConsentResponse revokeConsentResponse = revokeAdultResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Revoke status should be SUCCESS", "SUCCESS", revokeConsentResponse.getPayload().getStatus());
        Assert.assertEquals("Consent status should be UPDATED", "UPDATED",
                revokeConsentResponse.getPayload().getCustomerConsentInfo().get(0).getStatus());
        Assert.assertEquals("Authorization should be DENY", AUTH_STATUS_DENY,
                revokeConsentResponse.getPayload().getCustomerConsentInfo().get(0).getAuthorization());
        Reporter.logJSON("Revoke Extended HIPAA Response (Adult)", revokeConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 6: Save consent for Caregiver
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE,HIPAA_FORM_CODE);
        Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        Thread.sleep(30);

        // Step 7: Search Consent and validate
        Reporter.log("Step 7: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        Reporter.logJSON("PASSED - Revoke Extended HIPAA for Adult with ACCEPTED consent request", searchConsentResponse);
    }

    /**
     * SCENARIO 18: v1 Legacy Flow - Save Ecomm Consent for Adult Dependent (with PENDING consent request)
     * Flow: Create Accounts → Add Adult → Save Consent (v1Legacy=true) → Search → Validate
     */
    @Test(description = "v1 Legacy: Save Ecomm Consent for Adult Dependent with PENDING consent request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "v1Legacy", "adultConsentRequest"}, retryAnalyzer = Retry.class, priority = 18)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void v1Legacy_saveEcommConsentForAdultDependent_WithPendingConsentRequest(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Adult → Save Consent (v1Legacy=true) → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Adult Dependent Account
        String adultEmail = CommonUtil.generateRandomEmailId(10);
        String adultFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String adultLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> adultDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                adultEmail, adultFirstName, adultLastName, adultDependentDOB, storeNo);
        String adult_cid = adultDetails.get(0);
        Reporter.logJSON("Step 2 - Created Adult Dependent Account", adult_cid);

        // Step 3: Add Adult as Dependent (creates PENDING consent request)
        Reporter.log("Step 3: Adding Adult as Dependent (creates PENDING consent request)");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, adult_cid,
                DependentInfo.TypeEnum.ADULT, DependentInfo.LinkageStatusEnum.ACTIVE);

        Thread.sleep(2000);

        // Step 4: Save Consent with v1Legacy=true for Adult Dependent
        Reporter.log("Step 4: Saving Ecomm Consent (v1Legacy=true) for Adult Dependent");
        ServiceResponse saveAdultResponse = saveConsentWrapper.saveConsentForAdultDependentWithV1Legacy(
                adult_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, true);

        Assert.assertEquals("Save Adult status code should be 200", 200, saveAdultResponse.getStatusCode());
        SaveConsentResponse saveConsentResponse = saveAdultResponse.getDataResponse(SaveConsentResponse.class);
        Assert.assertEquals("Save status should be SUCCESS", "SUCCESS", saveConsentResponse.getPayload().getStatus());
        Assert.assertEquals("Consent status should be CREATED", "CREATED",
                saveConsentResponse.getPayload().getCustomerConsentInfo().get(0).getStatus());
        Reporter.logJSON("Save Consent Response (v1 Legacy Adult)", saveConsentResponse);

        // Wait for consent propagation
        Thread.sleep(30);

        // Step 5: Save consent for Caregiver
        ServiceResponse saveCaregiverResponse = saveConsentWrapper.saveEcommAndExtendedHipaaForSelf(
                caregiver_cid, AUTH_STATUS_ACCEPT, lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, ECOMM_FORM_CODE);
        Assert.assertEquals("Save Caregiver status code should be 200", 200, saveCaregiverResponse.getStatusCode());

        Thread.sleep(30);

        // Step 6: Search Consent and validate
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        Reporter.logJSON("PASSED - v1 Legacy Save Ecomm for Adult with PENDING consent request", searchConsentResponse);
    }

    /**
     * =====================================================================
     * SCENARIO 19: Save ECOMM + HIPAA for Self & Minor on Same CID → Revoke Both → Validate DENY
     * =====================================================================
     *
     * Description: Save ECOMM (50000) and Extended HIPAA (50001) consent separately for Self & Minor
     *              on the SAME CID, then Revoke consent for both Self and Minor and validate
     *              authorization changes from ACCEPT → DENY.
     *
     * Flow:
     *   Step 1: Create Caregiver Account
     *   Step 2: Create Minor Dependent Account
     *   Step 3: Add Minor as Dependent (LinkageStatus=ACTIVE)
     *   Step 4: Save ECOMM (50000) Consent for Self + Minor → PUT /v1/consents
     *   Step 5: Save Extended HIPAA (50001) Consent for Self + Minor (same CID) → PUT /v1/consents
     *   Step 6: Search Consent → POST /v1/consents/search → Validate ACCEPT for Self & Minor
     *   Step 7: Revoke by Minor DependentId → POST v1/consents/customer/{cid}/revoke with payload
     *   Step 8: Search Consent → Validate Self = ACCEPT, Minor = DENY
     *
     * Revoke API Details:
     *   - Revoke by Minor DependentId Endpoint: POST v1/consents/customer/{cid}/revoke
     *     Request Body: {"dependentId": ["<minor_cid>"]}
     *     Method: customerConsentWrapper.revokeCustomerConsentWithPayload(caregiver_cid, dependentIdsPayload)
     *     Behavior: Revokes consent ONLY for Minor dependent. Self (Caregiver) stays ACCEPT.
     *
     * Expected:
     *   - Save ECOMM + HIPAA status code: 200
     *   - Search after Save: Self = ACCEPT (ECOMM + HIPAA), Minor = ACCEPT (ECOMM + HIPAA)
     *   - Revoke by Minor DependentId status code: 200
     *   - Search after Revoke: Self = ACCEPT (ECOMM + HIPAA), Minor = DENY (ECOMM + HIPAA)
     */
    @Test(description = "Save ECOMM + HIPAA for Self & Minor on same CID then Revoke both and validate DENY",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "saveConsent", "searchConsent", "revokeConsent"}, retryAnalyzer = Retry.class, priority = 19)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void saveEcommAndHipaaForSelfAndMinor_ThenRevokeBoth(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Accounts → Add Minor → Save ECOMM + HIPAA (same CID) → Search ACCEPT → Revoke Minor by DependentId → Self=ACCEPT, Minor=DENY");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Create Minor Dependent Account
        String minorEmail = CommonUtil.generateRandomEmailId(10);
        String minorFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String minorLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> minorDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                minorEmail, minorFirstName, minorLastName, minorDependentDOB, storeNo);
        String minor_cid = minorDetails.get(0);
        Reporter.logJSON("Step 2 - Created Minor Account", minor_cid);

        // Step 3: Add Minor as Dependent
        Reporter.log("Step 3: Adding Minor as Dependent");
        consentOrchestratorWrapper.caAddDependent(caregiver_cid, minor_cid,
                DependentInfo.TypeEnum.MINOR, DependentInfo.LinkageStatusEnum.ACTIVE);

        // Step 4: Save ECOMM Consent for Self + Minor (same CID)
        Reporter.log("Step 4: Saving ECOMM Consent (50000) for Self + Minor");
        ServiceResponse saveEcommResponse = saveConsentWrapper.saveConsentForSelfAndMinor(
                caregiver_cid, minor_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false);
        Assert.assertEquals("Save ECOMM status code should be 200", 200, saveEcommResponse.getStatusCode());
        Reporter.logJSON("Save ECOMM Response (Self + Minor)", saveEcommResponse);

        // Step 5: Save Extended HIPAA Consent for Self + Minor (same CID)
        Reporter.log("Step 5: Saving Extended HIPAA Consent (50001) for Self + Minor (same CID)");
        ServiceResponse saveHipaaResponse = saveConsentWrapper.saveConsentForSelfAndMinor(
                caregiver_cid, minor_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE, false);
        Assert.assertEquals("Save HIPAA status code should be 200", 200, saveHipaaResponse.getStatusCode());
        Reporter.logJSON("Save Extended HIPAA Response (Self + Minor)", saveHipaaResponse);

        Thread.sleep(2000);

        // Step 6: Search Consent and validate both ECOMM + HIPAA are ACCEPT
        Reporter.log("Step 6: Searching consent via POST /v1/consents/search");
        List<String> formCodeList = Arrays.asList(formCodes.split(","));
        ServiceResponse searchResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchConsentResponse = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization for both ECOMM and HIPAA = ACCEPT
        validateAllFormCodeAuthorizations(primaryConsent, expectedAuthStatus, expectedAuthStatus, "Self");

        // Validate Minor caregiverAuthorization for both ECOMM and HIPAA = ACCEPT
        List<CustomerConsentInfo> dependents = searchConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependents) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Minor Dependent", formCodeList);
            }
        }
        Reporter.logJSON("Save ECOMM + HIPAA for Self + Minor (same CID) - ACCEPT validated", searchConsentResponse);

        // =====================================================================
        // REVOKE ECOMM & HIPAA CONSENT BY MINOR DEPENDENT ID - ONLY MINOR → DENY, SELF → ACCEPT
        // =====================================================================

        // Step 7: Revoke consent by passing Minor dependentId in payload
        // API Behavior: Revoking by dependentId only revokes Minor's consent, Self (Caregiver) stays ACCEPT
        Reporter.log("Step 7: Revoking consent for Minor via POST v1/consents/customer/{cid}/revoke with dependentId payload");
        List<String> minorIds = Arrays.asList(minor_cid);
        Map<String, List<String>> minorMap = new HashMap<>();
        minorMap.put("dependentId", minorIds);
        ObjectMapper mapper = new ObjectMapper();
        String minorDependentIdsPayload = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(minorMap);

        ServiceResponse revokeMinorResponse = customerConsentWrapper.revokeCustomerConsentWithPayload(
                caregiver_cid, minorDependentIdsPayload);
        Assert.assertEquals("Revoke Minor status code should be 200", 200, revokeMinorResponse.getStatusCode());
        Reporter.logJSON("Revoke Minor Consent Response (dependentId payload)", revokeMinorResponse);

        // Wait for consent propagation
        Thread.sleep(2000);

        // Step 8: Search Consent after Minor Revoke by DependentId - Self=ACCEPT, Minor=DENY
        Reporter.log("Step 8: Searching consent after Minor Revoke by DependentId via POST /v1/consents/search");
        ServiceResponse searchAfterMinorRevokeResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, lob, tenantId);

        Assert.assertEquals("Search after minor revoke status code should be 200", expectedStatusCode, searchAfterMinorRevokeResponse.getStatusCode());

        SearchConsentResponse searchAfterMinorRevokeConsentResponse = searchAfterMinorRevokeResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsentAfterMinorRevoke = searchAfterMinorRevokeConsentResponse.getPrimaryCustomerConsentInfo();

        // Validate Self Authorization - Self should still be ACCEPT (revoke by dependentId only revokes Minor, not Self)
        validateAllFormCodeAuthorizations(primaryConsentAfterMinorRevoke, expectedAuthStatus, expectedAuthStatus, "Self after Minor Revoke by DependentId (should still be ACCEPT)");

        // Validate Minor caregiverAuthorization - both ECOMM and HIPAA should be DENY after revoke
        List<CustomerConsentInfo> dependentsAfterMinorRevoke = searchAfterMinorRevokeConsentResponse.getDependentCustomerConsentInfo();
        for (CustomerConsentInfo dependent : dependentsAfterMinorRevoke) {
            if ("MINOR".equals(dependent.getCustomerInfo().getType())) {
                validateMinorFormCodeCareGiverAuthorizationsFromList(dependent, AUTH_STATUS_DENY, AUTH_STATUS_DENY, "Minor Dependent after Minor Revoke", formCodeList);
            }
        }
        Reporter.logJSON("PASSED - Save ECOMM + HIPAA (same CID) → Revoke Minor by DependentId → Self=ACCEPT, Minor=DENY", searchAfterMinorRevokeConsentResponse);
    }

    // =====================================================================
    // SEARCH CONSENT API - CLASSIFICATION SCENARIOS
    // =====================================================================

    /**
     * =====================================================================
     * SCENARIO 20: Search with formCode only returns specific consents
     * =====================================================================
     *
     * Description: Validates that when formCode filter is provided in search request,
     *              only the matching consents are returned.
     *              Tests: [50000,50001], [50000], [50001] filters
     *
     * Flow:
     *   Step 1: Create Account
     *   Step 2: Save ECOMM (50000) Consent for Self
     *   Step 3: Save HIPAA (50001) Consent for Self
     *   Step 4: Search with formCode [50000,50001] → returns both
     *   Step 5: Search with formCode [50000] → returns only ECOMM
     *   Step 6: Search with formCode [50001] → returns only HIPAA
     *
     * Expected: 200 OK, consentInfo filtered by formCode
     */
    @Test(description = "Search with formCode filter returns only specific consents matching the filter",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 20)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithFormCodeFilter(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save ECOMM + HIPAA → Search with formCode filter → Validate filtered results");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save ECOMM Consent (50000) for Self
        Reporter.log("Step 2: Saving ECOMM Consent (50000) via PUT /v1/consents");
        ServiceResponse saveEcommResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save ECOMM status code should be 200", 200, saveEcommResponse.getStatusCode());

        // Step 3: Save HIPAA Consent (50001) for Self
        Reporter.log("Step 3: Saving HIPAA Consent (50001) via PUT /v1/consents");
        ServiceResponse saveHipaaResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save HIPAA status code should be 200", 200, saveHipaaResponse.getStatusCode());

        Thread.sleep(2000);

        // Step 4: Search with formCode [50000, 50001] → should return both
        Reporter.log("Step 4: Search with formCode [50000, 50001] - expect both consents");
        List<String> bothFormCodes = Arrays.asList(ECOMM_FORM_CODE, HIPAA_FORM_CODE);
        ServiceResponse searchBothResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, bothFormCodes, lob, tenantId);

        Assert.assertEquals("Search (both) status code should be 200", 200, searchBothResponse.getStatusCode());
        SearchConsentResponse searchBothResult = searchBothResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryBoth = searchBothResult.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary consent info should not be null", primaryBoth);
        Assert.assertEquals("Should have 2 consent records when both formCodes provided", 2, primaryBoth.getConsentInfo().size());
        validateAllFormCodeAuthorizations(primaryBoth, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Self (both formCodes)");
        Reporter.log("Step 4 PASSED - Both formCodes returned 2 consents");

        // Step 5: Search with formCode [50000] → should return only ECOMM
        Reporter.log("Step 5: Search with formCode [50000] - expect only ECOMM consent");
        ServiceResponse searchEcommResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, Collections.singletonList(ECOMM_FORM_CODE), lob, tenantId);

        Assert.assertEquals("Search (ECOMM only) status code should be 200", 200, searchEcommResponse.getStatusCode());
        SearchConsentResponse searchEcommResult = searchEcommResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryEcomm = searchEcommResult.getPrimaryCustomerConsentInfo();
        Assert.assertEquals("Should have 1 consent record when only ECOMM formCode provided", 1, primaryEcomm.getConsentInfo().size());
        Assert.assertEquals("Returned consent should be ECOMM (50000)", ECOMM_FORM_CODE, primaryEcomm.getConsentInfo().get(0).getFormCode());
        validateAuthorizationForFormCode(primaryEcomm, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT, "Self (ECOMM only)");
        Reporter.log("Step 5 PASSED - Only ECOMM consent returned");

        // Step 6: Search with formCode [50001] → should return only HIPAA
        Reporter.log("Step 6: Search with formCode [50001] - expect only HIPAA consent");
        ServiceResponse searchHipaaResponse = searchConsentWrapper.searchConsent(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, Collections.singletonList(HIPAA_FORM_CODE), lob, tenantId);

        Assert.assertEquals("Search (HIPAA only) status code should be 200", 200, searchHipaaResponse.getStatusCode());
        SearchConsentResponse searchHipaaResult = searchHipaaResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryHipaa = searchHipaaResult.getPrimaryCustomerConsentInfo();
        Assert.assertEquals("Should have 1 consent record when only HIPAA formCode provided", 1, primaryHipaa.getConsentInfo().size());
        Assert.assertEquals("Returned consent should be HIPAA (50001)", HIPAA_FORM_CODE, primaryHipaa.getConsentInfo().get(0).getFormCode());
        validateAuthorizationForFormCode(primaryHipaa, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT, "Self (HIPAA only)");
        Reporter.log("Step 6 PASSED - Only HIPAA consent returned");

        Reporter.log("PASSED - formCode filter correctly returns specific consents");
    }

    /**
     * =====================================================================
     * SCENARIO 21: Classification returns mapped formCodes (50000, 50001)
     * =====================================================================
     *
     * Description: When classification "RXD-ECOMM-AUTH" is provided in search request,
     *              API returns all mapped formCodes (50000, 50001) and includes
     *              consentClassificationInfo with aggregated authorization status.
     *
     * Flow:
     *   Step 1: Create Account
     *   Step 2: Save ECOMM + HIPAA Consent for Self
     *   Step 3: Search with classification "RXD-ECOMM-AUTH"
     *   Step 4: Validate consentInfo has both 50000 and 50001
     *   Step 5: Validate consentClassificationInfo is present with correct values
     *
     * Expected:
     *   - 200 OK
     *   - consentInfo contains both ECOMM and HIPAA
     *   - consentClassificationInfo.classification = "RXD-ECOMM-AUTH"
     *   - consentClassificationInfo.authorization = "ACCEPT" (for primary)
     */
    @Test(description = "Search with classification RXD-ECOMM-AUTH returns mapped formCodes and consentClassificationInfo",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 21)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithClassificationReturnsConsents(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save ECOMM + HIPAA → Search with classification → Validate consentClassificationInfo");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Both ECOMM + HIPAA Consent for Self
        Reporter.log("Step 2: Saving ECOMM Consent (50000) via PUT /v1/consents");
        ServiceResponse saveEcommResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save ECOMM status code should be 200", 200, saveEcommResponse.getStatusCode());

        Reporter.log("Step 2b: Saving HIPAA Consent (50001) via PUT /v1/consents");
        ServiceResponse saveHipaaResponse = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save HIPAA status code should be 200", 200, saveHipaaResponse.getStatusCode());

        Thread.sleep(2000);

        // Step 3: Search with classification "RXD-ECOMM-AUTH"
        Reporter.log("Step 3: Searching consent with classification=" + CLASSIFICATION_RXD_ECOMM_AUTH);
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithClassification(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, CLASSIFICATION_RXD_ECOMM_AUTH, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchResult = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchResult.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary consent info should not be null", primaryConsent);

        // Step 4: Validate consentInfo has both ECOMM and HIPAA
        Assert.assertNotNull("ConsentInfo list should not be null", primaryConsent.getConsentInfo());
        Assert.assertEquals("Should have 2 consent records (mapped from classification)", 2, primaryConsent.getConsentInfo().size());
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Self (classification search)");
        Reporter.log("Step 4 PASSED - Both ECOMM and HIPAA consents returned via classification");

        // Step 5: Validate consentClassificationInfo from raw response using JsonPath
        String classificationValue = searchResponse.getJsonElement("$.primaryCustomerConsentInfo.consentClassificationInfo.classification");
        String authorizationValue = searchResponse.getJsonElement("$.primaryCustomerConsentInfo.consentClassificationInfo.authorization");
        Assert.assertNotNull("consentClassificationInfo.classification should be present", classificationValue);
        Assert.assertEquals("classification should be RXD-ECOMM-AUTH",
                CLASSIFICATION_RXD_ECOMM_AUTH, classificationValue);
        Assert.assertEquals("authorization should be ACCEPT",
                AUTH_STATUS_ACCEPT, authorizationValue);
        Reporter.log("Step 5 PASSED - consentClassificationInfo validated: classification=" +
                classificationValue + ", authorization=" + authorizationValue);

        Reporter.logJSON("PASSED - Classification search returns mapped formCodes + consentClassificationInfo", searchResult);
    }

    /**
     * =====================================================================
     * SCENARIO 22: Lowercase classification works (case-insensitive)
     * =====================================================================
     *
     * Description: Search with lowercase classification "RXD-ecomm-AUTH" works.
     *              API normalizes it to "RXD-ECOMM-AUTH" in response.
     *              consentClassificationInfo is returned with normalized value.
     *
     * Flow:
     *   Step 1: Create Account
     *   Step 2: Save ECOMM + HIPAA Consent for Self
     *   Step 3: Search with classification "RXD-ecomm-AUTH" (mixed case)
     *   Step 4: Validate response succeeds and consentClassificationInfo has normalized classification
     *
     * Expected: 200 OK, consentClassificationInfo.classification = "RXD-ECOMM-AUTH"
     */
    @Test(description = "Search with lowercase classification RXD-ecomm-AUTH works (case-insensitive)",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 22)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithLowercaseClassification(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save ECOMM + HIPAA → Search with lowercase classification → Validate");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Both ECOMM + HIPAA Consent for Self
        Reporter.log("Step 2: Saving ECOMM + HIPAA Consent via PUT /v1/consents");
        saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Thread.sleep(2000);

        // Step 3: Search with lowercase classification "RXD-ecomm-AUTH"
        Reporter.log("Step 3: Searching consent with lowercase classification=" + CLASSIFICATION_RXD_ECOMM_AUTH_LOWERCASE);
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithClassification(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, CLASSIFICATION_RXD_ECOMM_AUTH_LOWERCASE, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchResult = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchResult.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary consent info should not be null", primaryConsent);

        // Step 4: Validate consentInfo and consentClassificationInfo
        Assert.assertNotNull("ConsentInfo should not be null", primaryConsent.getConsentInfo());
        Assert.assertEquals("Should have 2 consent records", 2, primaryConsent.getConsentInfo().size());
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Self (lowercase classification)");

        // Validate consentClassificationInfo from raw response using JsonPath
        String classificationValue = searchResponse.getJsonElement("$.primaryCustomerConsentInfo.consentClassificationInfo.classification");
        String authorizationValue = searchResponse.getJsonElement("$.primaryCustomerConsentInfo.consentClassificationInfo.authorization");
        Assert.assertNotNull("consentClassificationInfo.classification should be present", classificationValue);
        Assert.assertEquals("classification should be normalized to RXD-ECOMM-AUTH",
                CLASSIFICATION_RXD_ECOMM_AUTH, classificationValue);
        Assert.assertEquals("authorization should be ACCEPT",
                AUTH_STATUS_ACCEPT, authorizationValue);

        Reporter.logJSON("PASSED - Lowercase classification works (case-insensitive)", searchResult);
    }

    /**
     * =====================================================================
     * SCENARIO 23: Neither formCode nor classification - returns all consents
     * =====================================================================
     *
     * Description: When neither formCode nor classification is provided in search request,
     *              API returns all consents for the customer.
     *              No consentClassificationInfo in response.
     *
     * Flow:
     *   Step 1: Create Account
     *   Step 2: Save ECOMM + HIPAA Consent for Self
     *   Step 3: Search without formCode or classification
     *   Step 4: Validate all consents are returned
     *   Step 5: Validate consentClassificationInfo is NOT present
     *
     * Expected: 200 OK, all consents returned, no consentClassificationInfo
     */
    @Test(description = "Search without formCode or classification returns all consents",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 23)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithNeitherFormCodeNorClassification(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save ECOMM + HIPAA → Search without formCode/classification → Validate all returned");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Both ECOMM + HIPAA Consent for Self
        Reporter.log("Step 2: Saving ECOMM + HIPAA Consent via PUT /v1/consents");
        ServiceResponse saveEcomm = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save ECOMM status code should be 200", 200, saveEcomm.getStatusCode());

        ServiceResponse saveHipaa = saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        Assert.assertEquals("Save HIPAA status code should be 200", 200, saveHipaa.getStatusCode());

        Thread.sleep(2000);

        // Step 3: Search without formCode or classification
        Reporter.log("Step 3: Searching consent WITHOUT formCode or classification (neither provided)");
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithoutFormCode(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, lob, tenantId);

        Assert.assertEquals("Search status code should be 200", expectedStatusCode, searchResponse.getStatusCode());

        SearchConsentResponse searchResult = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchResult.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary consent info should not be null", primaryConsent);

        // Step 4: Validate all consents returned (both ECOMM and HIPAA)
        Assert.assertNotNull("ConsentInfo should not be null", primaryConsent.getConsentInfo());
        Assert.assertTrue("Should have at least 2 consent records when neither filter provided",
                primaryConsent.getConsentInfo().size() >= 2);
        validateAllFormCodeAuthorizations(primaryConsent, AUTH_STATUS_ACCEPT, AUTH_STATUS_ACCEPT, "Self (no filter)");
        Reporter.log("Step 4 PASSED - All consents returned when neither formCode nor classification provided");

        // Step 5: Validate consentClassificationInfo is NOT present (no classification in request)
        String rawResponse = searchResponse.getDataResponse();
        Assert.assertFalse("consentClassificationInfo should NOT be present when classification is not used in request",
                rawResponse.contains("consentClassificationInfo"));
        Reporter.log("Step 5 PASSED - consentClassificationInfo is not in response when classification not provided");

        Reporter.logJSON("PASSED - Neither formCode nor classification returns all consents", searchResult);
    }

    /**
     * =====================================================================
     * SCENARIO 24: Both formCode and classification provided - Error 1132
     * =====================================================================
     *
     * Description: When BOTH formCode and classification are provided in search request,
     *              API returns error CHPR-CONSORCH-1132.
     *
     * Request:
     * {
     *   "accountId": "<CID>",
     *   "accountIdType": "CID",
     *   "formCode": ["50000","50001"],
     *   "classification": "RXD-ECOMM-AUTH"
     * }
     *
     * Expected:
     *   - 400 Bad Request
     *   - Error code: CHPR-CONSORCH-1132
     *   - Error message: Both formCode and classification cannot be provided together
     */
    @Test(description = "Search with both formCode and classification returns error CHPR-CONSORCH-1132",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 24)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithBothFormCodeAndClassification_Error(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Search with BOTH formCode AND classification → Validate error 1132");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Search with BOTH formCode AND classification (should fail with 1132)
        Reporter.log("Step 2: Searching with BOTH formCode=[50000,50001] AND classification=RXD-ECOMM-AUTH");
        List<String> formCodeList = Arrays.asList(ECOMM_FORM_CODE, HIPAA_FORM_CODE);
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithFormCodeAndClassification(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, CLASSIFICATION_RXD_ECOMM_AUTH, lob, tenantId);

        // Step 3: Validate error response
        Assert.assertEquals("Status code should be 400", 400, searchResponse.getStatusCode());
        SearchConsentErrorResponse errorResponse = searchResponse.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);
        Assert.assertNotNull("Error details should not be null", errorResponse.getError());
        Assert.assertEquals("Error code should be CHPR-CONSORCH-1132",
                "CHPR-CONSORCH-1132", errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should mention both formCode and classification cannot be provided together",
                actualErrorMessage.contains("cannot be provided together"));

        Reporter.log("PASSED - Error 1132: " + actualErrorMessage);
    }

    /**
     * =====================================================================
     * SCENARIO 25: Invalid classification returns error 1131
     * =====================================================================
     *
     * Description: When an invalid classification value is provided (e.g., "PHI-AUTH"),
     *              API returns error CHPR-CONSORCH-1131.
     *
     * Request:
     * {
     *   "accountId": "<CID>",
     *   "accountIdType": "CID",
     *   "classification": "PHI-AUTH"
     * }
     *
     * Expected:
     *   - 400 Bad Request
     *   - Error code: CHPR-CONSORCH-1131
     *   - Error message: Invalid classification value: 'PHI-AUTH'. Supported values: [RXD-ECOMM-AUTH]
     */
    @Test(description = "Search with invalid classification PHI-AUTH returns error CHPR-CONSORCH-1131",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 25)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithInvalidClassification_Error(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Search with invalid classification → Validate error 1131");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Search with invalid classification "PHI-AUTH" (should fail with 1131)
        Reporter.log("Step 2: Searching with invalid classification=" + CLASSIFICATION_INVALID);
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithClassification(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, CLASSIFICATION_INVALID, lob, tenantId);

        // Step 3: Validate error response
        Assert.assertEquals("Status code should be 400", 400, searchResponse.getStatusCode());
        SearchConsentErrorResponse errorResponse = searchResponse.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertNotNull("Error response should not be null", errorResponse);
        Assert.assertNotNull("Error details should not be null", errorResponse.getError());
        Assert.assertEquals("Error code should be CHPR-CONSORCH-1131",
                "CHPR-CONSORCH-1131", errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Assert.assertTrue("Error message should mention invalid classification value",
                actualErrorMessage.contains("Invalid classification value"));
        Assert.assertTrue("Error message should mention PHI-AUTH",
                actualErrorMessage.contains(CLASSIFICATION_INVALID));
        Assert.assertTrue("Error message should mention supported values",
                actualErrorMessage.contains("RXD-ECOMM-AUTH"));

        Reporter.log("PASSED - Error 1131: " + actualErrorMessage);
    }

    /**
     * =====================================================================
     * SCENARIO 26: LOB header not mandatory - Search succeeds without LOB
     * =====================================================================
     *
     * Description: LOB header is no longer mandatory for Search Consent API.
     *              Search should succeed even without LOB header.
     *
     * Flow:
     *   Step 1: Create Account
     *   Step 2: Save ECOMM + HIPAA Consent for Self (with LOB)
     *   Step 3: Search WITHOUT LOB header
     *   Step 4: Validate search succeeds with 200 OK
     *
     * Expected: 200 OK (previously was 400 for missing LOB)
     */
    @Test(description = "Search Consent API succeeds without LOB header (LOB is no longer mandatory)",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"positive", "searchConsent", "classification"}, retryAnalyzer = Retry.class, priority = 26)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "searchConsentPositive")
    public void searchConsentWithoutLobHeader_Success(
            String testname, String description, String caregiverDOB, String adultDependentDOB,
            String minorDependentDOB, String storeNo, String formCodes,
            String lob, String tenantId, int expectedStatusCode, String expectedAuthStatus) throws InterruptedException {

        Reporter.log("=== Test: " + testname + " - " + description + " ===");
        Reporter.log("Flow: Create Account → Save Consent (with LOB) → Search WITHOUT LOB → Validate success");

        // Step 1: Create Caregiver Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.logJSON("Step 1 - Created Caregiver Account", caregiver_cid);

        // Step 2: Save Both ECOMM + HIPAA Consent (with LOB header - save API still needs LOB)
        Reporter.log("Step 2: Saving ECOMM + HIPAA Consent via PUT /v1/consents");
        saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, ECOMM_FORM_ID, ECOMM_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);
        saveConsentWrapper.saveConsentForSelf(
                caregiver_cid, HIPAA_FORM_ID, HIPAA_FORM_CODE, AUTH_STATUS_ACCEPT,
                lob, tenantId, storeNo, DEFAULT_LOCATION_STATE);

        Thread.sleep(2000);

        // Step 3: Search WITHOUT LOB header (LOB is no longer mandatory)
        Reporter.log("Step 3: Searching consent WITHOUT LOB header");
        List<String> formCodeList = Arrays.asList(ECOMM_FORM_CODE, HIPAA_FORM_CODE);
        ServiceResponse searchResponse = searchConsentWrapper.searchConsentWithoutLobHeader(
                caregiver_cid, ACCOUNT_ID_TYPE_CID, formCodeList, tenantId);

        // Step 4: Validate search succeeds
        Assert.assertEquals("Search without LOB should return 200 (LOB is no longer mandatory)",
                200, searchResponse.getStatusCode());

        SearchConsentResponse searchResult = searchResponse.getDataResponse(SearchConsentResponse.class);
        CustomerConsentInfo primaryConsent = searchResult.getPrimaryCustomerConsentInfo();
        Assert.assertNotNull("Primary consent info should not be null", primaryConsent);
        Assert.assertNotNull("ConsentInfo should not be null", primaryConsent.getConsentInfo());
        Assert.assertTrue("Should have consent records", primaryConsent.getConsentInfo().size() >= 2);

        Reporter.logJSON("PASSED - LOB header not mandatory - Search succeeded without LOB", searchResult);
    }

    // =====================================================================
    // SAVE CONSENT API - FAILURE SCENARIOS
    // =====================================================================

    /**
     * =====================================================================
     * NEGATIVE SCENARIO 1: Save Both Ecomm & Extended HIPAA Consent with ACCEPT
     * =====================================================================
     *
     * Description: Save consent for formCode 50000 (Ecomm) and 50001 (Extended HIPAA)
     *              for the primary customer in a single request with ACCEPT.
     *
     * Request Payload:
     * {
     *   "primaryCustomerConsentInfo": {
     *     "customerInfo": { "accountId": "<CID>", "accountIdType": "cid" },
     *     "consentInfo": [
     *       { "formCode": "50000", "formId": "50000-0000-001", "authorization": "ACCEPT" },
     *       { "formCode": "50001", "formId": "50001-0000-001", "authorization": "ACCEPT" }
     *     ]
     *   }
     * }
     *
     * Expected Behavior:
     * - Response Status Code: 400 Bad Request
     * - Error Code: CHPR-CONSORCH-1118
     * - Error Message: Request cannot contain both ecomm (50000) and extended HIPAA (50001) consents with ACCEPT authorization
     */
    @Test(description = "Save consent for formCode 50000 (Ecomm) and 50001 (Extended HIPAA) with ACCEPT should fail - cannot have both ACCEPT",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "saveConsent"}, retryAnalyzer = Retry.class, priority = 100)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "saveConsentNegative")
    public void saveConsentShouldFailWhenBothEcommAndHipaaWithAccept(
            String testname, String description, String caregiverDOB, String storeNo,
            String lob, String tenantId, String invalidAuth,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " ===");
        Reporter.log("Description: " + description);
        Reporter.log("Expected Behavior: 400 Bad Request - Cannot save both Ecomm (50000) and HIPAA (50001) with ACCEPT authorization");

        // Step 1: Create Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.log("Step 1 - Created Account with CID: " + caregiver_cid);

        // Step 2: Try to save both Ecomm and HIPAA with ACCEPT - should fail
        Reporter.log("Step 2: Attempting to save both Ecomm (50000) and HIPAA (50001) with ACCEPT authorization");
        Reporter.log("Request: primaryCustomerConsentInfo with consentInfo containing both formCodes with ACCEPT");
        ServiceResponse response = saveConsentWrapper.saveBothEcommAndHipaaWithAccept(caregiver_cid, lob, tenantId);

        // Validate Response
        Reporter.log("Step 3: Validating Error Response");
        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertEquals("Error code should be " + expectedErrorCode, expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Reporter.log("Actual Error Code: " + errorResponse.getError().getCode());
        Reporter.log("Actual Error Message: " + actualErrorMessage);
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("PASSED - API correctly rejected request with expected error: " + expectedErrorCode);
    }

    /**
     * =====================================================================
     * NEGATIVE SCENARIO 2: Save Consent with empty consentInfo lists
     * =====================================================================
     *
     * Description: Both primary and dependent consentInfo lists are empty.
     *              At least one consent entry is required in payload.
     *
     * Request Payload:
     * {
     *   "primaryCustomerConsentInfo": {
     *     "customerInfo": { "accountId": "<CID>", "accountIdType": "cid" },
     *     "consentInfo": []
     *   },
     *   "dependentCustomerConsentInfo": [{
     *     "customerInfo": { "accountId": "<CID>", "accountIdType": "cid" },
     *     "consentInfo": []
     *   }]
     * }
     *
     * Expected Behavior:
     * - Response Status Code: 400 Bad Request
     * - Error Code: CHPR-CONSORCH-1118
     * - Error Message: At least one consent entry is required in primaryCustomerConsentInfo or dependentCustomerConsentInfo
     */
    @Test(description = "Both primary and dependent consentInfo lists are empty - at least one consent entry is required",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "saveConsent"}, retryAnalyzer = Retry.class, priority = 102)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "saveConsentNegative")
    public void saveConsentShouldFailWhenConsentInfoEmpty(
            String testname, String description, String caregiverDOB, String storeNo,
            String lob, String tenantId, String invalidAuth,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " ===");
        Reporter.log("Description: " + description);
        Reporter.log("Expected Behavior: 400 Bad Request - At least one consent entry is required");

        // Step 1: Create Primary Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.log("Step 1 - Created Primary Account with CID: " + caregiver_cid);

        // Step 2: Create Dependent Account
        String dependentEmail = CommonUtil.generateRandomEmailId(10);
        String dependentFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String dependentLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> dependentDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                dependentEmail, dependentFirstName, dependentLastName, caregiverDOB, storeNo);
        String dependent_cid = dependentDetails.get(0);
        Reporter.log("Step 2 - Created Dependent Account with CID: " + dependent_cid);

        // Step 3: Try to save with empty consentInfo - should fail
        Reporter.log("Step 3: Attempting to save with empty consentInfo lists for both primary and dependent");
        Reporter.log("Request: primaryCustomerConsentInfo.consentInfo=[], dependentCustomerConsentInfo[0].consentInfo=[]");
        ServiceResponse response = saveConsentWrapper.saveConsentWithEmptyConsentInfo(caregiver_cid, dependent_cid, lob, tenantId);

        // Validate Response
        Reporter.log("Step 4: Validating Error Response");
        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertEquals("Error code should be " + expectedErrorCode, expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Reporter.log("Actual Error Code: " + errorResponse.getError().getCode());
        Reporter.log("Actual Error Message: " + actualErrorMessage);
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("PASSED - API correctly rejected empty consentInfo: " + expectedErrorCode);
    }

    /**
     * =====================================================================
     * NEGATIVE SCENARIO 3: Save Consent with invalid authorization value
     * =====================================================================
     *
     * Description: authorization field value is not ACCEPT or DENY.
     *              Only ACCEPT and DENY are valid authorization values.
     *
     * Request Payload:
     * {
     *   "primaryCustomerConsentInfo": {
     *     "customerInfo": { "accountId": "<CID>", "accountIdType": "cid" },
     *     "consentInfo": [
     *       { "formCode": "50000", "formId": "50000-0000-011", "authorization": "REJECTED" }
     *     ]
     *   }
     * }
     *
     * Expected Behavior:
     * - Response Status Code: 400 Bad Request
     * - Error Code: CHPR-CONSORCH-1118
     * - Error Message: primaryCustomerConsentInfo.consentInfo[0].authorization must be 'ACCEPT' or 'DENY', received: REJECTED
     */
    @Test(description = "authorization value is not ACCEPT or DENY (sending REJECTED) - should return 400 Bad Request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "saveConsent"}, retryAnalyzer = Retry.class, priority = 103)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "saveConsentNegative")
    public void saveConsentShouldFailWhenAuthorizationInvalid(
            String testname, String description, String caregiverDOB, String storeNo,
            String lob, String tenantId, String invalidAuth,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " ===");
        Reporter.log("Description: " + description);
        Reporter.log("Expected Behavior: 400 Bad Request - authorization must be 'ACCEPT' or 'DENY', received: " + invalidAuth);

        // Step 1: Create Account
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.log("Step 1 - Created Account with CID: " + caregiver_cid);

        // Step 2: Try to save with invalid authorization - should fail
        Reporter.log("Step 2: Attempting to save with invalid authorization value: " + invalidAuth);
        Reporter.log("Request: primaryCustomerConsentInfo.consentInfo[0].authorization=" + invalidAuth);
        ServiceResponse response = saveConsentWrapper.saveConsentWithInvalidAuthorization(caregiver_cid, invalidAuth, lob, tenantId);

        // Validate Response
        Reporter.log("Step 3: Validating Error Response");
        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertEquals("Error code should be " + expectedErrorCode, expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Reporter.log("Actual Error Code: " + errorResponse.getError().getCode());
        Reporter.log("Actual Error Message: " + actualErrorMessage);
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("PASSED - API correctly rejected invalid authorization: " + expectedErrorCode);
    }

    /**
     * =====================================================================
     * NEGATIVE SCENARIO 4: Save Consent with invalid LOB header
     * =====================================================================
     *
     * Description: LOB header has invalid enum value (Other than PHARMACY, VISION).
     *              Only PHARMACY and VISION are valid LOB values.
     *
     * Request Headers:
     * - lob: INVALID_LOB
     *
     * Request Payload:
     * {
     *   "primaryCustomerConsentInfo": {
     *     "customerInfo": { "accountId": "<CID>", "accountIdType": "cid" },
     *     "consentInfo": [
     *       { "formCode": "50000", "formId": "50000-0000-001", "authorization": "ACCEPT" }
     *     ]
     *   }
     * }
     *
     * Expected Behavior:
     * - Response Status Code: 400 Bad Request
     * - Error Code: CHPR-CONSORCH-1119
     * - Error Message: Invalid lob: INVALID_LOB is provided for header: lob
     */
    @Test(description = "LOB header has invalid enum value INVALID_LOB (valid values: PHARMACY, VISION) - should return 400 Bad Request",
          dataProviderClass = DataProvider.class, dataProvider = "getData",
          groups = {"negative", "saveConsent"}, retryAnalyzer = Retry.class, priority = 104)
    @DataProviderArguments(filePath = "testdata/digitalpharmacy/consentOrchestrator/consentOrchestratorEcomData.xlsx",
                           sheetName = "saveConsentNegative")
    public void saveConsentShouldFailWhenLobInvalid(
            String testname, String description, String caregiverDOB, String storeNo,
            String lob, String tenantId, String invalidAuth,
            int expectedStatusCode, String expectedErrorCode, String expectedErrorMessage) throws InterruptedException, IOException {

        Reporter.log("=== Test: " + testname + " ===");
        Reporter.log("Description: " + description);
        Reporter.log("Expected Behavior: 400 Bad Request - Invalid lob: " + lob + " is provided for header: lob");

        // Step 1: Create Account (use valid LOB for account creation)
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5).toUpperCase();
        String caregiverLastName = CommonUtil.generateRandomLastName(5).toUpperCase();

        List<String> caregiverDetails = digitalPharmacyOperationsUtil.testAccountCreation_consentOrchestrator(
                caregiverEmail, caregiverFirstName, caregiverLastName, caregiverDOB, storeNo);
        String caregiver_cid = caregiverDetails.get(0);
        Reporter.log("Step 1 - Created Account with CID: " + caregiver_cid);

        // Step 2: Try to save with invalid LOB - should fail
        Reporter.log("Step 2: Attempting to save with invalid LOB header: " + lob);
        Reporter.log("Request Header: lob=" + lob);
        ServiceResponse response = saveConsentWrapper.saveConsentWithInvalidLob(caregiver_cid, lob, tenantId);

        // Validate Response
        Reporter.log("Step 3: Validating Error Response");
        Assert.assertEquals("Status code should be " + expectedStatusCode, expectedStatusCode, response.getStatusCode());
        SearchConsentErrorResponse errorResponse = response.getDataResponse(SearchConsentErrorResponse.class);
        Assert.assertEquals("Error code should be " + expectedErrorCode, expectedErrorCode, errorResponse.getError().getCode());

        String actualErrorMessage = errorResponse.getError().getMessage();
        Reporter.log("Actual Error Code: " + errorResponse.getError().getCode());
        Reporter.log("Actual Error Message: " + actualErrorMessage);
        Assert.assertTrue("Error message should contain: " + expectedErrorMessage,
                actualErrorMessage.contains(expectedErrorMessage));

        Reporter.log("PASSED - API correctly rejected invalid LOB: " + expectedErrorCode);
    }

    // =====================================================================
    // VALIDATION HELPER METHODS
    // =====================================================================

    /**
     * Gets authorization status by form code from CustomerConsentInfo.
     *
     * @param customerConsentInfo The customer consent info containing consent details
     * @param formCode The form code to search for (e.g., "50000" for Ecomm, "50001" for HIPAA)
     * @return The authorization status (ACCEPT/DENY) for the given form code, or null if not found
     */
    private String getAuthorizationByFormCode(CustomerConsentInfo customerConsentInfo, String formCode) {
        if (customerConsentInfo == null || customerConsentInfo.getConsentInfo() == null) {
            return null;
        }
        for (ConsentInfo consent : customerConsentInfo.getConsentInfo()) {
            if (formCode.equals(consent.getFormCode())) {
                return consent.getAuthorization();
            }
        }
        return null;
    }

    /**
     * Gets Minor's caregiverAuthorization by form code from consentInfo list.
     *
     * @param customerConsentInfo The customer consent info containing consent details
     * @param formCode The form code to search for
     * @return The caregiver authorization status for the given form code, or null if not found
     */
    private String getMinorCareGiverAuthorizationByFormCode(CustomerConsentInfo customerConsentInfo, String formCode) {
        if (customerConsentInfo == null || customerConsentInfo.getConsentInfo() == null) {
            return null;
        }
        for (ConsentInfo consent : customerConsentInfo.getConsentInfo()) {
            if (formCode.equals(consent.getFormCode())) {
                return consent.getCaregiverAuthorization();
            }
        }
        return null;
    }

    /**
     * Validates authorization status for a specific form code and logs the result.
     *
     * @param customerConsentInfo The customer consent info containing consent details
     * @param formCode The form code to validate
     * @param expectedStatus The expected authorization status
     * @param customerType Description of customer type for logging
     */
    private void validateAuthorizationForFormCode(CustomerConsentInfo customerConsentInfo, String formCode,
                                                  String expectedStatus, String customerType) {
        String actualAuth = getAuthorizationByFormCode(customerConsentInfo, formCode);
        String formName = ECOMM_FORM_CODE.equals(formCode) ? "ECOMM" : "HIPAA";
        Reporter.log(customerType + " Authorization for " + formCode + " (" + formName + "): " + actualAuth);
        Assert.assertEquals(customerType + " authorization for " + formCode + " should be " + expectedStatus,
                expectedStatus, actualAuth);
    }

    /**
     * Validates both ECOMM (50000) and HIPAA (50001) authorization statuses.
     *
     * @param customerConsentInfo The customer consent info containing consent details
     * @param expectedEcommStatus Expected status for ECOMM form code (50000)
     * @param expectedHipaaStatus Expected status for HIPAA form code (50001)
     * @param customerType Description of customer type for logging
     */
    private void validateAllFormCodeAuthorizations(CustomerConsentInfo customerConsentInfo,
                                                   String expectedEcommStatus, String expectedHipaaStatus,
                                                   String customerType) {
        validateAuthorizationForFormCode(customerConsentInfo, ECOMM_FORM_CODE, expectedEcommStatus, customerType);
        validateAuthorizationForFormCode(customerConsentInfo, HIPAA_FORM_CODE, expectedHipaaStatus, customerType);
    }

    /**
     * Validates Minor's authorization for specific form codes from a list.
     *
     * @param customerConsentInfo Minor's customer consent info
     * @param expectedEcommStatus Expected ECOMM (50000) status
     * @param expectedHipaaStatus Expected HIPAA (50001) status
     * @param customerType Customer type for logging
     * @param formCodeList List of form codes to validate
     */
    private void validateMinorFormCodeCareGiverAuthorizationsFromList(CustomerConsentInfo customerConsentInfo,
                                                                      String expectedEcommStatus,
                                                                      String expectedHipaaStatus,
                                                                      String customerType,
                                                                      List<String> formCodeList) {
        if (formCodeList == null || formCodeList.isEmpty()) {
            Reporter.log("No form codes to validate for " + customerType);
            return;
        }

        List<ConsentInfo> consentInfos = customerConsentInfo.getConsentInfo();
        if (consentInfos == null || consentInfos.isEmpty()) {
            Reporter.log("No consent info available for " + customerType);
            return;
        }

        for (String formCode : formCodeList) {
            String expectedStatus = ECOMM_FORM_CODE.equals(formCode) ? expectedEcommStatus : expectedHipaaStatus;
            String actualAuth = getMinorCareGiverAuthorizationByFormCode(customerConsentInfo, formCode);
            String formName = ECOMM_FORM_CODE.equals(formCode) ? "ECOMM" : "HIPAA";

            Reporter.log(customerType + " CaregiverAuthorization for " + formCode + " (" + formName + "): " + actualAuth);
            Assert.assertEquals(customerType + " caregiver authorization for " + formCode + " should be " + expectedStatus,
                    expectedStatus, actualAuth);
        }
    }
}
