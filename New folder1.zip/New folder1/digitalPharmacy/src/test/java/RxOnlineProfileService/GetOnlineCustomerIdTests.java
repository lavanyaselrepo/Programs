package RxOnlineProfileService;

import RxOnlineProfileService.dataModels.request.GetOnlineCustomerIdRequest;
import RxOnlineProfileService.dataModels.request.StorePatientDetails;
import RxOnlineProfileService.dataModels.response.GetOnlineCustomerIdResponse;
import RxOnlineProfileService.restapi.RxOnlineProfileServiceRetrofit;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;

/**
 * Automation Test Class for RxOnlineProfileService - getOnlineCustomerId API
 *
 * Endpoint: POST /v1/customer/online-customer-id/action/get
 *
 * All test data and service configuration are loaded dynamically from
 * DragonLibrary PropertyReader (config/digitalPharmacy/{env}.properties).
 *
 * Test scenarios covered:
 *  TC-01 : Valid store + patient + tenant                            → 200 with onlineCustomerId
 *  TC-02 : Empty storePatientDetailsList                            → 400
 *  TC-03 : Null storePatientDetailsList (field absent via NON_NULL) → 500 (service bug — no validation)
 *  TC-04 : Invalid storeNbr + invalid patientId                     → 400 (store pre-validation)
 *  TC-05 : Null tenant (field absent via NON_NULL)                  → 400
 *  TC-06 : Invalid / unrecognised tenant value                      → 400
 *  TC-07 : Null storeNbr in StorePatientDetails (field absent)      → 400
 *  TC-08 : Null patientId in StorePatientDetails (field absent)     → 400
 *  TC-09 : Multiple valid StorePatientDetails entries               → 200 with onlineCustomerId
 *  TC-10 : Valid storeNbr with invalid/non-existent patientId       → 400
 *  TC-11 : Mixed list — one valid entry + one invalid entry         → 200 (service processes valid entry independently)
 *  TC-12 : Empty string tenant ("")                                 → 400
 */
public class GetOnlineCustomerIdTests {

    private RxOnlineProfileServiceRetrofit rxOnlineProfileServiceRetrofit;

    // ---------------------------------------------------------------------------
    // Property keys for test data — values live in DragonLibrary config files
    // (config/digitalPharmacy/{env}.properties)
    // ---------------------------------------------------------------------------
    private static final String PROP_VALID_STORE_NBR    = "dp.profile.service.test.valid.store.nbr";
    private static final String PROP_VALID_PATIENT_ID   = "dp.profile.service.test.valid.patient.id";
    private static final String PROP_VALID_TENANT       = "dp.profile.service.test.valid.tenant";
    private static final String PROP_VALID_STORE_NBR_2  = "dp.profile.service.test.valid.store.nbr.2";
    private static final String PROP_VALID_PATIENT_ID_2 = "dp.profile.service.test.valid.patient.id.2";
    private static final String PROP_INVALID_STORE_NBR  = "dp.profile.service.test.invalid.store.nbr";
    private static final String PROP_INVALID_PATIENT_ID = "dp.profile.service.test.invalid.patient.id";
    private static final String PROP_INVALID_TENANT     = "dp.profile.service.test.invalid.tenant";

    // ---------------------------------------------------------------------------
    // Test data — populated from PropertyReader in @BeforeClass
    // ---------------------------------------------------------------------------
    private int    validStoreNbr;
    private int    validPatientId;
    private String validTenant;
    private int    validStoreNbr2;
    private int    validPatientId2;
    private int    invalidStoreNbr;
    private int    invalidPatientId;
    private String invalidTenant;

    @BeforeClass
    public void setUpRetrofitClient() {
        rxOnlineProfileServiceRetrofit = new RxOnlineProfileServiceRetrofit();

        PropertyReader props = PropertyReader.getInstance();
        validStoreNbr    = Integer.parseInt(props.getProperty(PROP_VALID_STORE_NBR));
        validPatientId   = Integer.parseInt(props.getProperty(PROP_VALID_PATIENT_ID));
        validTenant      = props.getProperty(PROP_VALID_TENANT);
        validStoreNbr2   = Integer.parseInt(props.getProperty(PROP_VALID_STORE_NBR_2));
        validPatientId2  = Integer.parseInt(props.getProperty(PROP_VALID_PATIENT_ID_2));
        invalidStoreNbr  = Integer.parseInt(props.getProperty(PROP_INVALID_STORE_NBR));
        invalidPatientId = Integer.parseInt(props.getProperty(PROP_INVALID_PATIENT_ID));
        invalidTenant    = props.getProperty(PROP_INVALID_TENANT);
    }

    // ---------------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------------

    /**
     * Builds a standard valid request with one StorePatientDetails entry.
     */
    private GetOnlineCustomerIdRequest buildValidRequest() {
        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        return GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant(validTenant)
                .build();
    }

    private String generateRequestId()         { return "req-id-"       + UUID.randomUUID(); }
    private String generateRequestTrackingId() { return "req-tracking-" + UUID.randomUUID(); }

    /**
     * Reads the error body string. errorBody() is a one-shot stream — call this once per response.
     */
    private String readErrorBody(Response<?> response) throws IOException {
        return response.errorBody() != null ? response.errorBody().string() : "";
    }

    /**
     * TC-01: Valid store, patient, and tenant should return HTTP 200 with a non-null, non-empty onlineCustomerId.
     */
    @Test(priority = 1, description = "TC-01 | Valid request returns 200 with onlineCustomerId")
    public void getOnlineCustomerId_validRequest_returns200() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        GetOnlineCustomerIdRequest request = buildValidRequest();
        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 200,
                "Expected HTTP 200 for valid getOnlineCustomerId request");
        Assert.assertNotNull(response.body(),
                "Response body should not be null for a valid request");
        Assert.assertNotNull(response.body().getOnlineCustomerId(),
                "onlineCustomerId in response should not be null");
        Assert.assertFalse(response.body().getOnlineCustomerId().isEmpty(),
                "onlineCustomerId in response should not be empty");

        Reporter.logJSON("onlineCustomerId", response.body().getOnlineCustomerId());
    }

    /**
     * TC-02: Empty storePatientDetailsList should return HTTP 400 Bad Request.
     *        Validates the error response body is non-empty.
     */
    @Test(priority = 2, description = "TC-02 | Empty storePatientDetailsList returns 400 Bad Request")
    public void getOnlineCustomerId_emptyStorePatientList_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.emptyList())
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 when storePatientDetailsList is empty");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    /**
     * TC-03: storePatientDetailsList = null → field is omitted from JSON by @JsonInclude(NON_NULL).
     * NOTE: dp-profile-service returns 500 (not 400) when the field is absent entirely —
     *       service lacks validation for a completely missing required field.
     */
    @Test(priority = 3, description = "TC-03 | Null storePatientDetailsList (field absent) returns 500")
    public void getOnlineCustomerId_nullStorePatientList_returns500() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(null)
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        // Service throws 500 because the missing field is not validated — causes internal processing error
        Assert.assertEquals(response.code(), 500,
                "Expected HTTP 500 when storePatientDetailsList is null (field omitted from payload)");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 500 response");
    }

    /**
     * TC-04: Invalid storeNbr + invalid patientId — both unrecognised.
     * NOTE: dp-profile-service validates storeNbr before DB lookup → returns 400 (not 404).
     */
    @Test(priority = 4, description = "TC-04 | Invalid storeNbr + patientId returns 400 Bad Request")
    public void getOnlineCustomerId_invalidStorePatient_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails invalidDetails = StorePatientDetails.builder()
                .storeNbr(invalidStoreNbr)
                .patientId(invalidPatientId)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(invalidDetails))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        // Service validates storeNbr before DB lookup — unknown storeNbr returns 400
        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 for invalid storeNbr + patientId (storeNbr fails pre-lookup validation)");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    /**
     * TC-05: tenant = null → field is omitted from JSON by @JsonInclude(NON_NULL).
     * NOTE: dp-profile-service returns 500 (not 400) when tenant is absent —
     *       consistent with TC-03 behaviour: service lacks validation for completely missing required fields
     *       and instead crashes internally.
     */
    @Test(priority = 5, description = "TC-05 | Null tenant (field absent) returns 500")
    public void getOnlineCustomerId_nullTenant_returns500() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        // tenant = null → @JsonInclude(NON_NULL) omits it — payload: {"storePatientDetailsList":[...]}
        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant(null)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        // Service throws 500 when tenant is absent — same as TC-03 (missing field not validated, causes internal error)
        Assert.assertEquals(response.code(), 500,
                "Expected HTTP 500 when tenant is null/absent from request payload");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 500 response");
    }

    /**
     * TC-06: tenant = invalid value — unknown tenant string.
     * Service should reject unrecognised tenants with 400 Bad Request.
     */
    @Test(priority = 6, description = "TC-06 | Invalid tenant value returns 400")
    public void getOnlineCustomerId_invalidTenant_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant(invalidTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 for unrecognised tenant value: " + invalidTenant);

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    /**
     * TC-07: storeNbr = null inside StorePatientDetails → field omitted from JSON by @JsonInclude(NON_NULL).
     * Service should reject the request with 400 Bad Request for missing storeNbr.
     */
    @Test(priority = 7, description = "TC-07 | Null storeNbr in StorePatientDetails returns 400")
    public void getOnlineCustomerId_nullStoreNbr_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        // storeNbr = null → field absent from serialized JSON; patientId is present and valid
        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(null)
                .patientId(validPatientId)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 when storeNbr is null/absent in StorePatientDetails");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    /**
     * TC-08: patientId = null inside StorePatientDetails → field omitted from JSON by @JsonInclude(NON_NULL).
     * Service should reject the request with 400 Bad Request for missing patientId.
     */
    @Test(priority = 8, description = "TC-08 | Null patientId in StorePatientDetails returns 400")
    public void getOnlineCustomerId_nullPatientId_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        // patientId = null → field absent from serialized JSON; storeNbr is present and valid
        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(null)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 when patientId is null/absent in StorePatientDetails");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    /**
     * TC-09: storePatientDetailsList with multiple valid entries.
     * Service should process all entries and return HTTP 200 with a non-null onlineCustomerId.
     */
    @Test(priority = 9, description = "TC-09 | Multiple valid StorePatientDetails entries returns 200")
    public void getOnlineCustomerId_multipleStorePatientEntries_returns200() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails entry1 = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        StorePatientDetails entry2 = StorePatientDetails.builder()
                .storeNbr(validStoreNbr2)
                .patientId(validPatientId2)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Arrays.asList(entry1, entry2))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 200,
                "Expected HTTP 200 with multiple valid storePatientDetails entries");
        Assert.assertNotNull(response.body(),
                "Response body should not be null for a valid multi-entry request");
        Assert.assertNotNull(response.body().getOnlineCustomerId(),
                "onlineCustomerId should not be null for a valid multi-entry request");
        Assert.assertFalse(response.body().getOnlineCustomerId().isEmpty(),
                "onlineCustomerId should not be empty for a valid multi-entry request");

        Reporter.logJSON("onlineCustomerId", response.body().getOnlineCustomerId());
    }

    /**
     * TC-10: Valid storeNbr with an invalid/non-existent patientId — isolated test.
     * Validates that a bad patientId alone triggers an error response.
     * NOTE: Expected 400 based on TC-04 pre-lookup validation behaviour.
     *       Update to 404 if service performs a DB lookup for the patient and returns 404 for unknown patient.
     */
    @Test(priority = 10, description = "TC-10 | Valid storeNbr with invalid patientId returns 400")
    public void getOnlineCustomerId_validStoreInvalidPatient_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails details = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(invalidPatientId)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(details))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        // Expected 400 based on TC-04 observed behaviour.
        // Update to 404 if service performs a DB lookup and returns 404 for unknown patient.
        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 for valid storeNbr with invalid/non-existent patientId");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }

    // ---------------------------------------------------------------------------
    // TC-11 : Mixed list — one valid + one invalid StorePatientDetails entry
    // ---------------------------------------------------------------------------

    /**
     * TC-11: storePatientDetailsList with one valid and one invalid entry.
     * Service processes each entry independently — it resolves the valid entry and returns 200,
     * silently ignoring the invalid storeNbr entry rather than rejecting the entire request.
     */
    @Test(priority = 11, description = "TC-11 | Mixed valid+invalid StorePatientDetails entries returns 200")
    public void getOnlineCustomerId_mixedStorePatientList_returns200() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails validEntry = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        StorePatientDetails invalidEntry = StorePatientDetails.builder()
                .storeNbr(invalidStoreNbr)
                .patientId(invalidPatientId)
                .build();

        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Arrays.asList(validEntry, invalidEntry))
                .tenant(validTenant)
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        // Service processes valid entry independently and returns 200 — invalid entry is silently skipped
        Assert.assertEquals(response.code(), 200,
                "Expected HTTP 200 when list contains a mix of valid and invalid StorePatientDetails entries");
        Assert.assertNotNull(response.body(),
                "Response body should not be null when at least one valid entry exists");
        Assert.assertNotNull(response.body().getOnlineCustomerId(),
                "onlineCustomerId should not be null when a valid entry is present in the list");
        Assert.assertFalse(response.body().getOnlineCustomerId().isEmpty(),
                "onlineCustomerId should not be empty when a valid entry is present in the list");

        Reporter.logJSON("onlineCustomerId", response.body().getOnlineCustomerId());
    }

    // ---------------------------------------------------------------------------
    // TC-12 : Empty string tenant
    // ---------------------------------------------------------------------------

    /**
     * TC-12: tenant = "" (empty string) — unlike null, an empty string IS serialized into the JSON payload
     * as {@code "tenant": ""} and reaches the service. Service should reject it with 400 Bad Request.
     */
    @Test(priority = 12, description = "TC-12 | Empty string tenant returns 400")
    public void getOnlineCustomerId_emptyStringTenant_returns400() throws IOException {
        String requestId         = generateRequestId();
        String requestTrackingId = generateRequestTrackingId();

        Reporter.logJSON("requestId",        requestId);
        Reporter.logJSON("requestTrackingId", requestTrackingId);

        StorePatientDetails storePatientDetails = StorePatientDetails.builder()
                .storeNbr(validStoreNbr)
                .patientId(validPatientId)
                .build();

        // tenant = "" → serialized as "tenant":"" in JSON (NOT omitted like null)
        GetOnlineCustomerIdRequest request = GetOnlineCustomerIdRequest.builder()
                .storePatientDetailsList(Collections.singletonList(storePatientDetails))
                .tenant("")
                .build();

        Reporter.logJSON("Request payload", request.toString());

        Response<GetOnlineCustomerIdResponse> response =
                rxOnlineProfileServiceRetrofit.getOnlineCustomerId(request, requestId, requestTrackingId);

        Reporter.logJSON("HTTP Status Code", String.valueOf(response.code()));

        Assert.assertEquals(response.code(), 400,
                "Expected HTTP 400 when tenant is an empty string");

        String errorBody = readErrorBody(response);
        Reporter.logJSON("Error Response Body", errorBody);
        Assert.assertFalse(errorBody.isEmpty(),
                "Error response body should not be empty for a 400 response");
    }
}
