package RxOnlineProfileService.restapi;

import RxOnlineProfileService.dataModels.request.GetOnlineCustomerIdRequest;
import RxOnlineProfileService.dataModels.response.GetOnlineCustomerIdResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.SSLUtils;
import com.walmart.hwqe.commons.signaturegenerator.SignatureGenerator;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Retrofit client wrapper for RxOnlineProfileService.
 * Provides typed methods to invoke REST endpoints of dp-profile-service.
 * All configuration is loaded from DragonLibrary PropertyReader (no hardcoded values).
 */
public class RxOnlineProfileServiceRetrofit {

    // ── Property keys (keys only — values come from DragonLibrary config files) ─
    private static final String PROP_BASE_URL    = "dp.profile.service.base.url";
    private static final String PROP_CONSUMER_ID = "dp.profile.service.consumer.id";
    private static final String PROP_SVC_NAME    = "dp.profile.service.name";
    private static final String PROP_SVC_ENV     = "dp.profile.service.env";
    private static final String PROP_KEY_VERSION = "dp.profile.service.key.version";
    private static final String PROP_PRIVATE_KEY = "dp.account.orchestrator.service.private.key";
    // ───────────────────────────────────────────────────────────────────────────

    private final RxOnlineProfileServiceRetrofitApi retrofitApi;
    private final String consumerId;
    private final String svcName;
    private final String svcEnv;
    private final String keyVersion;

    public RxOnlineProfileServiceRetrofit() {
        PropertyReader props = PropertyReader.getInstance();

        consumerId = props.getProperty(PROP_CONSUMER_ID);
        svcName    = props.getProperty(PROP_SVC_NAME);
        svcEnv     = props.getProperty(PROP_SVC_ENV);
        keyVersion = props.getProperty(PROP_KEY_VERSION);

        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(props.getProperty(PROP_BASE_URL))
                .addConverterFactory(JacksonConverterFactory.create(objectMapper))
                .client(SSLUtils.getUnsafeOkHttpClient())
                .build();

        retrofitApi = retrofit.create(RxOnlineProfileServiceRetrofitApi.class);
    }

    /**
     * Builds the standard set of headers required by dp-profile-service,
     * including a freshly computed WM_SEC.AUTH_SIGNATURE.
     *
     * @param requestId         unique request identifier
     * @param requestTrackingId request tracking/correlation identifier
     * @return Map of header key-value pairs
     */
    private Map<String, String> buildHeaders(String requestId, String requestTrackingId) {
        String timestamp  = Long.toString(Instant.now().toEpochMilli());
        String privateKey = PropertyReader.getInstance().getProperty(PROP_PRIVATE_KEY);
        String authSig    = SignatureGenerator.generateSig(privateKey, consumerId, keyVersion, timestamp);

        Map<String, String> headers = new HashMap<>();
        headers.put("WM_CONSUMER.ID",          consumerId);
        headers.put("WM_SVC.NAME",             svcName);
        headers.put("WM_SVC.ENV",              svcEnv);
        headers.put("WM_SEC.KEY_VERSION",      keyVersion);
        headers.put("WM_CONSUMER.INTIMESTAMP", timestamp);
        headers.put("WM_SEC.AUTH_SIGNATURE",   authSig);
        headers.put("request_id",              requestId);
        headers.put("request_tracking_id",     requestTrackingId);
        headers.put("Content-Type",            "application/json");
        return headers;
    }

    /**
     * Calls POST /v1/customer/online-customer-id/action/get
     *
     * @param request           GetOnlineCustomerIdRequest payload
     * @param requestId         unique request identifier
     * @param requestTrackingId request tracking identifier
     * @return Retrofit Response wrapping GetOnlineCustomerIdResponse
     * @throws IOException if a network error occurs
     */
    public Response<GetOnlineCustomerIdResponse> getOnlineCustomerId(
            GetOnlineCustomerIdRequest request,
            String requestId,
            String requestTrackingId) throws IOException {
        return retrofitApi.getOnlineCustomerId(request, buildHeaders(requestId, requestTrackingId))
                .execute();
    }
}
