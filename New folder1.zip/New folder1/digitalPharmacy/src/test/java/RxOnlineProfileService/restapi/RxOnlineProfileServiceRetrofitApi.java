package RxOnlineProfileService.restapi;

import RxOnlineProfileService.dataModels.request.GetOnlineCustomerIdRequest;
import RxOnlineProfileService.dataModels.response.GetOnlineCustomerIdResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.HeaderMap;
import retrofit2.http.Headers;
import retrofit2.http.POST;

import java.util.Map;

public interface RxOnlineProfileServiceRetrofitApi {

    /**
     * POST endpoint to retrieve Online Customer ID for given store-patient details.
     *
     * @param body    GetOnlineCustomerIdRequest containing storePatientDetailsList and tenant
     * @param headers Map of required headers (WM_CONSUMER.ID, WM_SVC.NAME, WM_SVC.ENV, request_id, request_tracking_id)
     * @return Call wrapping GetOnlineCustomerIdResponse
     */
    @Headers({"Content-Type:application/json"})
    @POST("v1/customer/online-customer-id/action/get")
    Call<GetOnlineCustomerIdResponse> getOnlineCustomerId(
            @Body GetOnlineCustomerIdRequest body,
            @HeaderMap Map<String, String> headers
    );
}
