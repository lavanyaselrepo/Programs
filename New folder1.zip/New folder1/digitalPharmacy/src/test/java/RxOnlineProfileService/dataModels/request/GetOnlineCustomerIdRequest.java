package RxOnlineProfileService.dataModels.request;

import RxOnlineProfileService.dataModels.request.StorePatientDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetOnlineCustomerIdRequest {
    private List<StorePatientDetails> storePatientDetailsList;
    private String tenant;   // API expects plain string e.g. "WALMART", not an object
}
