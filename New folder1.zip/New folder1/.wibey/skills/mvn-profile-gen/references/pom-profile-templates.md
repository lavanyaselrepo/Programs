# Maven Profile Templates

Copy-paste templates for inserting into `pom.xml` inside the `<profiles>` block.
All templates match the patterns already used in AutomationBaseFramework.

---

## Template A — Basic Profile (Compilation Scoping Only)

Use when the team just wants to **scope compilation** to specific packages (faster compile, no custom deps needed).

```xml
        <!-- <TEAM_NAME> team profile -->
        <!-- Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/<FOLDER>/... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

**Replace:**
| Placeholder | Example |
|-------------|---------|
| `<TEAM_NAME>` | `Connexus`, `RDM`, `Billing` |
| `<PROFILE_ID>` | `cnx`, `rdm`, `billing` |
| `<FOLDER>` | `connexus/FillingFlows`, `rdm/centralpatient`, `bom` |

---

## Template B — Profile with GCP Dependencies

Use when the team needs **Google Cloud** services (BigQuery, Storage) and encounters the `getUniverseDomain()` error.

**Problem:** DragonLibrary bundles `google-auth 1.5.3` which lacks `getUniverseDomain()`.
**Solution:** This template adds `google-auth 1.23.0` explicitly.

```xml
        <!-- <TEAM_NAME> team profile -->
        <!-- Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/<FOLDER>/... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <!-- ══════════════════════════════════════════════════════════════════ -->
            <!-- Google Auth 1.23.0 — fixes getUniverseDomain() missing method      -->
            <!--                                                                    -->
            <!-- DragonLibrary fat JAR bundles google-auth 1.5.3 internally.        -->
            <!-- These explicit deps ensure 1.23.0 is available for this profile.  -->
            <!-- ══════════════════════════════════════════════════════════════════ -->
            <dependencies>
                <dependency>
                    <groupId>com.google.auth</groupId>
                    <artifactId>google-auth-library-credentials</artifactId>
                    <version>1.23.0</version>
                </dependency>
                <dependency>
                    <groupId>com.google.auth</groupId>
                    <artifactId>google-auth-library-oauth2-http</artifactId>
                    <version>1.23.0</version>
                </dependency>
                <!-- Google Cloud Storage with exclusions -->
                <dependency>
                    <groupId>com.google.cloud</groupId>
                    <artifactId>google-cloud-storage</artifactId>
                    <version>2.30.1</version>
                    <exclusions>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-credentials</artifactId>
                        </exclusion>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-oauth2-http</artifactId>
                        </exclusion>
                    </exclusions>
                </dependency>
                <!-- Google Cloud BigQuery with exclusions -->
                <dependency>
                    <groupId>com.google.cloud</groupId>
                    <artifactId>google-cloud-bigquery</artifactId>
                    <version>2.34.2</version>
                    <exclusions>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-credentials</artifactId>
                        </exclusion>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-oauth2-http</artifactId>
                        </exclusion>
                    </exclusions>
                </dependency>
            </dependencies>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

---

## Template C — Profile with Azure Cosmos Dependencies

Use when the team needs **Azure Cosmos DB** for test data.

```xml
        <!-- <TEAM_NAME> team profile -->
        <!-- Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/<FOLDER>/... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <dependencies>
                <dependency>
                    <groupId>com.azure</groupId>
                    <artifactId>azure-cosmos</artifactId>
                    <version>4.65.0</version>
                </dependency>
            </dependencies>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

---

## Template D — Profile with Kafka Avro Dependencies

Use when the team needs **Kafka Avro Serializer** for event-driven tests.

```xml
        <!-- <TEAM_NAME> team profile -->
        <!-- Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/<FOLDER>/... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <dependencies>
                <dependency>
                    <groupId>io.confluent</groupId>
                    <artifactId>kafka-avro-serializer</artifactId>
                    <version>5.5.1</version>
                    <exclusions>
                        <exclusion>
                            <groupId>org.apache.kafka</groupId>
                            <artifactId>kafka-clients</artifactId>
                        </exclusion>
                    </exclusions>
                </dependency>
            </dependencies>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

---

## Insertion Point in pom.xml

Always insert new profiles **before** the closing `</profiles>` tag:

```xml
        <!-- existing last profile -->
        </profile>

        <!-- ═══ NEW PROFILE GOES HERE ═══ -->
        <profile>
            <id>new-team</id>
            ...
        </profile>

    </profiles>   ← closing tag stays last
</project>
```

---

## Run Command Cheatsheet

| Scenario | Command |
|----------|---------|
| Compile only | `mvn test-compile -P<id>` |
| Run with env | `mvn test -P<id> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=...` |
| Run single test class | `mvn test -P<id> -Dtest=MyTestClass` |
| Run single test method | `mvn test -P<id> -Dtest=MyTestClass#myMethod` |
| Skip tests | `mvn compile -P<id> -DskipTests` |

---

## Existing Profiles in pom.xml

| Profile ID | Team | Test Folder | Custom Deps |
|------------|------|-------------|-------------|
| `billing` | BOM | `bom/**` | None |
| `cpr-tests` | CPR | `rdm/centralpatient/**` | None |
| `unit-tests` | Framework | `hwqe/baseframework/**` | Mockito |
| `quick-tests` | Framework | N/A | None (skips compile) |
| `inv` | Inventory | `inv/**` | google-auth 1.23.0, google-cloud-* |

---

## Suite XML Locations

```
src/test/resources/suites/
├── bom/                    ← Billing team
├── connexus/               ← Connexus team
│   ├── ERX_DepandNon/
│   ├── FillingFlows/
│   ├── DropOff/
│   └── UserExperience/
├── cnxmodularization/      ← CNX Modularization
├── cs/                     ← Customer Service
├── framework/              ← Framework sanity tests
├── inv/                    ← Inventory team
│   ├── acsi/
│   ├── acp/
│   ├── sles/
│   └── ...
└── rdm/                    ← RDM team
    └── centralpatient/
```
