---
name: mvn-profile-gen
description: >
  Generates a Maven profile in pom.xml for a specific team's test folder.
  Input: team name and test folder path. Output: complete profile XML block
  inserted into pom.xml with compiler configuration, optional dependencies,
  and usage instructions for CLI, IntelliJ, and Looper CI/CD.
  Trigger phrases: "create a maven profile", "generate mvn profile", 
  "add profile for my team", "create profile for tests", "add surefire profile",
  "create profile for <team-name>".
metadata:
  author: Wibey
  version: 2.0.0
  updated: 2026-05-06
sample-prompts:
  - "create a maven profile for the connexus team"
  - "generate a profile for rdm/centralpatient tests"
  - "add a maven profile for the billing team's bom folder"
  - "create profile for cs tests with custom dependencies"
---

# Maven Profile Generator

## What This Skill Does

Takes a **team name** + **test folder path** from the user and generates a complete Maven `<profile>` block that:

1. **Scopes compilation** to only the team's test classes (faster builds)
2. **Adds team-specific dependencies** if needed (e.g., google-auth for GCP)
3. **Inserts the profile** into `pom.xml`
4. **Provides run instructions** for CLI, IntelliJ, and Looper CI/CD

---

## Workflow

### Step 1 — Collect Inputs

Ask the user for (or extract from their message):

| Input | Example | Required | Notes |
|-------|---------|----------|-------|
| **Team Name** | `connexus`, `rdm`, `billing` | Yes | Used as profile ID (kebab-case) |
| **Test Folder** | `connexus/FillingFlows` | Yes | Relative to `src/test/java/` |
| **Suite XML Folder** | `connexus/FillingFlows` | No | Defaults to same as test folder, relative to `src/test/resources/suites/` |
| **Custom Dependencies** | google-auth, azure-cosmos | No | Team-specific deps to add |
| **Environment** | `dev`, `qe`, `prod` | No | Default: `dev` |

**Auto-suggest profile ID** from team name:
- `connexus` → `cnx`
- `rdm/centralpatient` → `cpr`
- `billing` → `billing`
- `inventory` → `inv`

### Step 2 — Scan for Test Files and Suite XMLs

Use Glob to verify the test folder exists and find suite XMLs:

```bash
# Verify test classes exist
src/test/java/<folder>/**/*.java

# Find suite XMLs
src/test/resources/suites/<folder>/**/*.xml
```

Report findings to user:
```
Found:
  - 45 Java test files in src/test/java/connexus/FillingFlows/
  - 3 TestNG suite XMLs in src/test/resources/suites/connexus/FillingFlows/
```

### Step 3 — Check for Dependency Requirements

Ask the user if their tests require any special dependencies:

| Test Type | Dependencies Needed |
|-----------|---------------------|
| GCP (BigQuery, Storage) | google-auth 1.23.0, google-cloud-* |
| Azure Cosmos | azure-cosmos |
| Kafka Avro | kafka-avro-serializer |
| None | No additional deps |

### Step 4 — Pre-flight Checks

**Check 1 — Test folder exists**
```bash
ls src/test/java/<folder>/
```
If missing: stop and ask user to verify path.

**Check 2 — Profile ID not already taken**
```bash
grep "<id><profile-id></id>" pom.xml
```
If exists: ask to update existing or use different name.

**Check 3 — Suite XMLs exist (optional)**
```bash
ls src/test/resources/suites/<folder>/
```
Warn if no suite XMLs found.

### Step 5 — Generate Profile XML

Use the appropriate template based on user requirements.

#### Template A: Basic Profile (Compilation Only)

```xml
        <!-- <TEAM_NAME> team profile — Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

#### Template B: Profile with GCP Dependencies

Use this when team needs google-auth 1.23.0 (fixes `getUniverseDomain()` error):

```xml
        <!-- <TEAM_NAME> team profile — Usage: mvn test -P<PROFILE_ID> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=... -->
        <profile>
            <id><PROFILE_ID></id>
            <properties>
                <testType>e2e</testType>
                <sendReportEmail>false</sendReportEmail>
                <enableTestBurst>false</enableTestBurst>
            </properties>
            <!-- Google Auth 1.23.0 — fixes getUniverseDomain() missing from DragonLibrary's bundled 1.5.3 -->
            <dependencies>
                <dependency>
                    <groupId>com.google.auth</groupId>
                    <artifactId>google-auth-library-credentials</artifactId>
                    <version>1.23.0</version>
                </dependency>
                <dependency>
                    <groupId>com.google.auth</groupId>
                    <artifactId>google-auth-library-oauth2-http</artifactId>
                    <version>1.23.0</version>
                </dependency>
                <dependency>
                    <groupId>com.google.cloud</groupId>
                    <artifactId>google-cloud-storage</artifactId>
                    <version>2.30.1</version>
                    <exclusions>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-credentials</artifactId>
                        </exclusion>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-oauth2-http</artifactId>
                        </exclusion>
                    </exclusions>
                </dependency>
                <dependency>
                    <groupId>com.google.cloud</groupId>
                    <artifactId>google-cloud-bigquery</artifactId>
                    <version>2.34.2</version>
                    <exclusions>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-credentials</artifactId>
                        </exclusion>
                        <exclusion>
                            <groupId>com.google.auth</groupId>
                            <artifactId>google-auth-library-oauth2-http</artifactId>
                        </exclusion>
                    </exclusions>
                </dependency>
            </dependencies>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-compiler-plugin</artifactId>
                        <version>3.11.0</version>
                        <configuration>
                            <source>21</source>
                            <target>21</target>
                            <includes>
                                <include>**/*.java</include>
                            </includes>
                            <testIncludes>
                                <testInclude><FOLDER>/**/*.java</testInclude>
                                <testInclude>hwqe/baseframework/**/*.java</testInclude>
                            </testIncludes>
                            <annotationProcessorPaths>
                                <path>
                                    <groupId>org.projectlombok</groupId>
                                    <artifactId>lombok</artifactId>
                                    <version>1.18.38</version>
                                </path>
                            </annotationProcessorPaths>
                        </configuration>
                    </plugin>
                </plugins>
            </build>
        </profile>
```

### Step 6 — Insert Profile into pom.xml

Find the insertion point:
```xml
    </profiles>   ← Insert new profile BEFORE this closing tag
</project>
```

Use the Edit tool to insert the profile XML.

### Step 7 — Validate

Run validation:
```bash
mvn validate -P<profile-id> -q
```

If validation fails, revert and report error.

### Step 8 — Report Run Instructions

Output the complete usage guide:

```
═══════════════════════════════════════════════════════════════════
  Profile Created: <profile-id>
═══════════════════════════════════════════════════════════════════

  Team:        <team-name>
  Test Folder: src/test/java/<folder>/
  Suite XMLs:  src/test/resources/suites/<folder>/

═══════════════════════════════════════════════════════════════════
  Run Commands
═══════════════════════════════════════════════════════════════════

  ▶ Compile only (no tests):
    mvn test-compile -P<profile-id>

  ▶ Run specific suite:
    mvn test -P<profile-id> -DtestEnvironment=dev \
      -Dsurefire.suiteXmlFiles=src/test/resources/suites/<folder>/<suite>.xml

  ▶ Run multiple suites:
    mvn test -P<profile-id> -DtestEnvironment=dev \
      -Dsurefire.suiteXmlFiles=src/test/resources/suites/<folder>/a.xml,src/test/resources/suites/<folder>/b.xml

═══════════════════════════════════════════════════════════════════
  IntelliJ Setup
═══════════════════════════════════════════════════════════════════

  1. Open Maven tool window (View → Tool Windows → Maven)
  2. Expand Profiles → check ✅ <profile-id>
  3. Right-click test class → Run

  OR create a Run Configuration:
    Type:    Maven
    Command: test -P<profile-id> -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=...
    Name:    <team-name> Tests

═══════════════════════════════════════════════════════════════════
  Looper CI/CD Pipeline
═══════════════════════════════════════════════════════════════════

  mvn_args: "test -P<profile-id> -DtestEnvironment=${ENV} -Dsurefire.suiteXmlFiles=..."

═══════════════════════════════════════════════════════════════════
```

---

## Existing Profiles Reference

| Profile ID | Team | Test Folder | Has Custom Deps? |
|------------|------|-------------|------------------|
| `billing` | BOM | `bom/**` | No |
| `cpr-tests` | CPR | `rdm/centralpatient/**` | No |
| `unit-tests` | Framework | `hwqe/baseframework/**` | Mockito |
| `quick-tests` | Framework | N/A (skips compile) | No |
| `inv` | Inventory | `inv/**` | Yes (google-auth 1.23.0) |

---

## Common Dependency Blocks

### Google Cloud (GCP) - BigQuery, Storage

```xml
<dependency>
    <groupId>com.google.auth</groupId>
    <artifactId>google-auth-library-credentials</artifactId>
    <version>1.23.0</version>
</dependency>
<dependency>
    <groupId>com.google.auth</groupId>
    <artifactId>google-auth-library-oauth2-http</artifactId>
    <version>1.23.0</version>
</dependency>
```

### Azure Cosmos DB

```xml
<dependency>
    <groupId>com.azure</groupId>
    <artifactId>azure-cosmos</artifactId>
    <version>4.65.0</version>
</dependency>
```

### Kafka Avro Serializer

```xml
<dependency>
    <groupId>io.confluent</groupId>
    <artifactId>kafka-avro-serializer</artifactId>
    <version>5.5.1</version>
</dependency>
```

---

## Documentation

For detailed documentation on existing profiles, see:
- [INV Profile Documentation](../../../docs/profiles/INV-PROFILE.md)

---

## Troubleshooting

### "Profile not found"
Ensure the profile was inserted inside `<profiles>...</profiles>` tags.

### "Test classes not compiled"
Check that `<testInclude>` paths match your folder structure.

### "getUniverseDomain() not found"
Add google-auth 1.23.0 dependencies to your profile (use Template B).

### "Suite XML not found"
Verify the `-Dsurefire.suiteXmlFiles=` path is correct.
