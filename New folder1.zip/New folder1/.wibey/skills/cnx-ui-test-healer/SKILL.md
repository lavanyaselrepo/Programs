---
name: cnx-ui-test-healer
description: >
  Analyses Connexus UI (WinAppDriver/Appium) test failures and applies targeted fixes.
  Use when a developer pastes a test failure, stack trace, TestNG XML/HTML report, or
  asks why a Connexus test is failing. Covers all known failure patterns: flaky login,
  popup timing, stale sessions, null pointer, race conditions, string comparison, flag
  values, disabled tests, and data mismatches.
  Trigger phrases: "analyse failure", "fix test case", "why is this test failing",
  "heal test", "test keeps failing", "flaky test", "HWPHME2E failing", "cnx test broken".
metadata:
  author: r0c03ir
sample-prompts:
  - "analyse this test failure and fix it"
  - "HWPHME2E_510 keeps failing, what's wrong?"
  - "why does the DropOff test fail with NullPointerException?"
  - "this cnx test is flaky, can you heal it?"
  - "fix the failing connexus test cases"
---

# CNX UI Test Healer

## What This Skill Does

Reads a Connexus test failure → classifies it into one of the **10 known failure patterns** → applies or suggests the minimal targeted fix. All patterns are derived from real PRs merged into `AutomationBaseFramework` (Jan 2025–May 2026).

> For detailed pattern descriptions, fix templates, and code examples → read `references/failure-patterns.md`.
> For key classes, file locations, and locator reference → read `references/cnx-codebase-map.md`.

---

## Workflow

### Step 1 — Collect the Failure Evidence

Accept any of the following (the more provided, the better the diagnosis):

| Input | Where to find it | What to do |
|-------|-----------------|------------|
| **TestNG HTML report** | `target/surefire-reports/index.html` or CI pipeline artifacts | Read file or accept pasted failure section |
| **TestNG XML report** | `target/surefire-reports/TEST-*.xml` | Read `<failure>` and `<error>` nodes |
| **Stack trace** | Pasted directly in chat | Parse exception class + line numbers |
| **Jira ticket / test ID** | e.g. `HWPHME2E_510` | Grep codebase to locate test method |
| **Screenshot** | Shared as file path or pasted image | Visual confirmation of which screen/popup is visible |
| **Maven console log** | Pasted or as a file | Scan for `FAILED`, `ERROR`, `Exception` lines |

If only a test ID is given, grep the codebase first, then ask:
> "Can you share the stack trace or TestNG report for this run? It helps classify the failure faster."

If a **file path** is given, use the `Read` tool to load it directly — do not ask the user to paste it.

### Step 2 — Read Failure Patterns

Load `references/failure-patterns.md` and classify the failure into one of the 10 patterns.
If ambiguous, ask one clarifying question: "Does the failure happen every time or only sometimes?"

### Step 3 — Locate the Code

Use Grep/Read to find:
- The test method (search by Jira ID, e.g. `HWPHME2E_510`)
- The Page Object method where it fails
- Any relevant locator or property

### Step 4 — Apply Fix

Apply the minimal change matching the pattern:
- Prefer adding guards over restructuring
- Preserve existing code style (indentation, import order)
- Add a `Reporter.log("[HEALER] ...")` line explaining what was fixed
- Do NOT change unrelated code

### Step 5 — Report

After fixing, output:
```
Pattern:  <pattern name>
File:     <file path>
Change:   <one-line description>
Why:      <root cause explanation>
```

---

## Quick Pattern Lookup

| Exception / Symptom | Pattern | Quick Fix |
|---------------------|---------|-----------|
| `NullPointerException` on menu/nav | Null guard missing | Wrap in `if (x != null)` |
| `StaleElementReferenceException` | Stale driver session | Refresh `winDriver` from `ConnexusManager` |
| `AssertionError` on string compare | String mismatch | `.replace(".", "").trim().equalsIgnoreCase()` |
| `TimeoutException` / element not found | Timing / flakiness | Increase wait or use `handlePopup()` |
| Test skipped or not run | `enabled=false` set | Re-enable or investigate why it was disabled |
| API called before queue transition | Race condition | Add DB polling for queue state before API call |
| Login fails / `lblStationIcon` not found | Login popup timing | Use `handlePopup("","BtnAccept",35)` + `switchWindow(40_000)` |
| Wrong DB flag value | Flag/DB value wrong | Check "TRUE"/"FALSE" case, add missing flag update |
| Optional screen causes failure | Optional UI flow | Wrap with `if (isElementDisplayed(locator, 5))` |
| Assertion wrong after data change | Data/SQL mismatch | Fix SQL query or update `.xlsx` test data file |

See `references/failure-patterns.md` for full code templates for each pattern.
