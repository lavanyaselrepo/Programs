# CNX UI Test Codebase Map

Quick reference for navigating the AutomationBaseFramework when healing Connexus test failures.

---

## Key Source Locations

| What | Path |
|------|------|
| Login logic | `src/main/java/hwqe/baseframework/models/pageobjectmodels/connexus/LoginPage.java` |
| Driver management | `src/main/java/hwqe/baseframework/connexuscontext/ConnexusManager.java` |
| Session state (PS handshake) | `src/main/java/hwqe/baseframework/connexuscontext/CnxSessionState.java` |
| Pre-login PS script | `scripts/Start-CnxSession.ps1` |
| Drop-Off page | `src/main/java/hwqe/baseframework/models/pageobjectmodels/connexus/DropOffPage.java` |
| Filling Flows tests | `src/test/java/connexus/FillingFlows/testcases/` |
| Drop-Off UAT tests | `src/test/java/connexus/DropOff/testcases/` |
| Drop-Off UAT scripts | `src/test/java/connexus/DropOff/testscripts/DropOffScreenUatTestScripts.java` |
| UserExperience tests | `src/test/java/connexus/UserExperience/testcases/` |
| CNX Mod refill tests | `src/test/java/cnxmodularization/` |
| DB validation service | `src/test/java/cnxmodularization/services/DbValidationService.java` |
| Base Windows page | `src/main/java/hwqe/baseframework/models/pageobjectmodels/WindowsBasePage.java` |
| AutomationManager | `src/main/java/hwqe/baseframework/AutomationManager.java` |
| Connexus utils | `src/main/java/hwqe/baseframework/connexuscontext/ConnexusAppUtils.java` |
| Test data (DropOff) | `src/test/resources/TestData/connexus/DropOff/DropOffUatTestSet1DataBook.xlsx` |
| Properties (dev) | `src/test/resources/config/connexus/dev.properties` |
| Global config | `src/main/resources/config/config.properties` |

---

## Key Locators (LoginPage)

| Element | AccessibilityId | Screen |
|---------|----------------|--------|
| New HO username | `username1` | HO new screen |
| New HO password | `password` | HO new screen |
| RPH/Tech username | `txtUsername` | RPH/Tech new screen |
| Old screen username | `txtUserName` (capital N) | Old ADFlagOff screen |
| Old/both password | `txtPassword` | All screens |
| OK popup dismiss | `2` | Pre/post-login popups |
| Security accept | `BtnAccept` | Security warning |
| Main screen | `lblStationIcon` | Confirms login complete |
| Shell form | `ShellForm` | Top-level window |

---

## Key Properties

```properties
# Credentials
cnx.ho.userName=SVCRX1U
cnx.rph.userName=svccnxp
cnx.tech.userName=svccnxt

# Pre-login PS script (leave blank to use legacy Java login)
cnx.prelogin.script=scripts/Start-CnxSession.ps1
cnx.prelogin.loginType=HOMEOFFICE
cnx.prelogin.timeout=300

# WinAppDriver
app.winAppServer=http://127.0.0.1:4723/
app.connexusExecutable=C:\\Walmart Applications\\Connexus.Net\\UI\\Connexus.exe
```

---

## LoginAs.userType Enum Values

```java
HOMEOFFICE_ADFlagOn    // new login screen — username1/password
HOMEOFFICE_ADFlagOff   // old login screen — txtUserName/txtPassword
PHARMACIST_ADFlagOn    // new login screen — txtUsername/txtPassword
PHARMACIST_ADFlagOff   // old login screen
TECHNICIAN_ADFlagOn    // new login screen
TECHNICIAN_ADFlagOff   // old login screen
```

---

## Jira ID → Test File Convention

Tests are named by Jira ID: `HWPHME2E_510` → search for `HWPHME2E_510` in `src/test/java/connexus/`.

```bash
# Find a test method by Jira ticket
grep -r "HWPHME2E_510" src/test/java/connexus/ --include="*.java" -l
```

TestNG suites: `src/test/resources/suites/connexus/`

---

## Common `@BeforeMethod` Setup Issues

Many Connexus tests rely on `@BeforeMethod` to:
1. Launch Connexus (`launchConnexus()`)
2. Login (`loginConnexus(userType)` or `loginConnexusOldScreen(userType)`)
3. Set DB flags (`updateFlagValue(...)`)
4. Navigate to the screen under test

If a test fails in `@BeforeMethod`, the root cause is almost always Pattern 1, 4, 7, or 8.

---

## Reporter Usage (required in all fixes)

```java
// Always add a healer log when applying a fix so it's visible in TestNG HTML report
Reporter.log("[HEALER] <pattern-name>: <what was fixed and why>");
Reporter.logScreenShot("After heal fix", takeScreenShot());
```
