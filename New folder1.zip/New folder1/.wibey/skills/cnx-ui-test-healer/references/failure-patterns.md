# CNX UI Test Failure Patterns

All patterns are derived from real PRs in AutomationBaseFramework (Jan 2025–May 2026).
Each entry: trigger symptoms → root cause → fix template.

---

## Pattern 1 — Null Guard Missing

**Symptoms:** `NullPointerException` in `selectNavigation()`, menu traversal, or any code that accesses `.getAppMenu()` or similar on optional menu objects.

**Root cause:** Caller passes `null` for a sub-menu level that doesn't exist for that navigation path.

**Fix template:**
```java
// BEFORE
for (int i = 0; i < subMenuNavigation.getAppMenu(); i++) { ... }

// AFTER
if (subMenuNavigation != null) {
    for (int i = 0; i < subMenuNavigation.getAppMenu(); i++) { ... }
}
if (superSubMenuNavigation != null) {
    for (int i = 0; i < superSubMenuNavigation.getAppMenu(); i++) { ... }
    automationManager.performSleep(4);
}
```

**Key files:** `connexus/DropOffPage.java`, `WindowsBasePage.java`, any Page Object with navigation.

---

## Pattern 2 — Stale Driver Session

**Symptoms:** `NoSuchSessionException`, `WebDriverException: session not created`, or click/findElement failing on elements that visually exist. Occurs especially after long waits or multi-step flows.

**Root cause:** The `winDriver` reference held by a Page Object becomes stale because `ConnexusManager` has re-created the session (e.g. after login or window switch).

**Fix template:**
```java
// BEFORE
public boolean clickPatientSearch() {
    click(patientSearchButton);
    return true;
}

// AFTER
public boolean clickPatientSearch() {
    try {
        // Refresh driver from ConnexusManager before each critical interaction
        this.winDriver = AutomationManager.getInstance().getConnexus().getDriver();
        if (this.winDriver == null || this.winDriver.getSessionId() == null) {
            Reporter.log("[HEALER] Driver session is null — cannot click patientSearch");
            return false;
        }
        click(patientSearchButton);
        return true;
    } catch (Exception e) {
        Reporter.log("[HEALER] clickPatientSearch failed: " + e.getMessage());
        return false;
    }
}
```

---

## Pattern 3 — String Comparison Mismatch

**Symptoms:** `AssertionError: expected [Dr Call In] but was [Dr. Call In]`, or priority/status comparison failures. Data from DB and UI differ by punctuation, case, or whitespace.

**Root cause:** UI renders "Dr. Call In" while DB stores "Dr Call In" (or vice versa). Direct `.equals()` fails.

**Fix template:**
```java
// BEFORE
Assert.assertEquals(actualPriority, expectedPriority);

// AFTER — normalize both sides before comparison
String normalize(String s) {
    return s == null ? "" : s.replace(".", "").replaceAll("\\s+", " ").trim().toLowerCase();
}
Assert.assertEquals(normalize(actualPriority), normalize(expectedPriority),
    "Priority mismatch after normalization");
```

**Also applies to:** patient name comparison, drug names, status labels.

---

## Pattern 4 — Timing / Flakiness (Element Not Found / Timeout)

**Symptoms:** `TimeoutException`, `NoSuchElementException`, test intermittently passes and fails. Often seen in popup dismissal, post-login state, navigation.

**Root cause A — Popup dismissal cap:** `handelInitialLoginPopUps()` had a hard cap of 7 iterations. Stores with more data show more popups.

**Fix:** Replaced with condition-based loop (see `ConnexusManager` / `LoginPage` changes):
```java
// Loop until main screen visible, not a fixed count
while (!isElementDisplayed(leftBarWorkQueue, 2) && attempts < 30) {
    if (isElementDisplayed(okButton, 5)) {
        click(okButton);
        Reporter.log("[HEALER] OK dismissed (attempt " + (++attempts) + ")");
    } else {
        switchWindow();
        attempts++;
    }
}
```

**Root cause B — Insufficient wait for security popup:**
```java
// BEFORE: 3 × 3s = 9s max — too short under auth load
for (int attempt = 1; attempt <= 3; attempt++) {
    if (moveToElementAndClick(securityWarningAcceptButton, 3)) { break; }
}

// AFTER: 35s single wait using handlePopup() which scans all windows
boolean accepted = handlePopup("", "BtnAccept", 35);
if (!accepted) {
    switchWindow(30_000);
    moveToElementAndClick(securityWarningAcceptButton, 10);
}
```

**Root cause C — Shell window not re-acquired after auth:**
```java
// After BtnAccept is clicked, add this BEFORE handelInitialLoginPopUps()
Reporter.log("[HEALER] Waiting for main shell window after auth...");
switchWindow(40_000);
```

---

## Pattern 5 — Test Disabled (enabled=false)

**Symptoms:** Test never runs, shows as skipped in TestNG report. Sometimes done incorrectly — feature is live but test wasn't re-enabled.

**Root cause:** Developer set `enabled=false` pending a fix, then forgot to re-enable.

**Fix:** Re-enable and verify the underlying issue is resolved:
```java
// BEFORE
@Test(priority = 19, dataProviderClass = DataProvider.class,
      dataProvider = "getDataAsMap", enabled=false)

// AFTER — remove enabled=false (default is true)
@Test(priority = 19, dataProviderClass = DataProvider.class,
      dataProvider = "getDataAsMap")
```

**Caution:** Only re-enable if the Jira ticket for the blocking issue is closed/resolved.

---

## Pattern 6 — Race Condition (API Called Before Queue Transition)

**Symptoms:** Test calls WaitToSolve / RefillsApproved / CancelFill / ChangeRx API and gets wrong result or 404. Rx is still in Queue 1 or 18 when the test expects it in Queue 7 (TRBL).

**Root cause:** Rx transitions Queue 1 → Queue 18 (eRx verification) → Queue 7. The API requires Rx to be in Queue 7 before calling resolution methods.

**Fix:** Add DB polling for queue state before making API call:
```java
// Add before calling any resolution API
dbValidationService.waitForRxInQueue(rxNumber, 7,
    Duration.ofSeconds(60), "Waiting for Rx to reach Queue 7 before resolution");
Reporter.log("[HEALER] Rx confirmed in Queue 7 — proceeding with resolution API");
```

**Key class:** `cnxmodularization.services.DbValidationService`

---

## Pattern 7 — Login / Post-Login Popup Failure

**Symptoms:** `lblStationIcon` never found. Test fails at `Assert.fail("Login not successful")`. Connexus is launched but main screen never confirmed.

**Root cause:** See Pattern 4 root cause B and C. Additionally: wrong login method called for current ADFlag state.

**Login method selection:**
```
Screen has "username1"  → loginConnexus() with HOMEOFFICE_ADFlagOn
Screen has "txtUsername" → loginConnexus() with PHARMACIST/TECHNICIAN_ADFlagOn
Screen has "txtUserName" (capital N) → loginConnexusOldScreen() with ADFlagOff variant
```

**Pre-login guard (added to both login methods):**
```java
if (isAlreadyLoggedIn()) {
    Reporter.log("[HEALER] Already logged in — skipping login for: " + userType);
    return;
}
```

---

## Pattern 8 — Flag / DB Value Wrong

**Symptoms:** Feature behaves unexpectedly mid-test. A flag that enables/disables a feature is set to wrong value or case.

**Root cause:** Flag values are case-sensitive in some DB tables. `"true"` ≠ `"TRUE"`. Or a required companion flag was not set.

**Fix template:**
```java
// BEFORE
connexusAppUtils.updateFlagValue("17310", "true");

// AFTER — use uppercase, add companion flag
connexusAppUtils.updateFlagValue("17310", "TRUE");
connexusAppUtils.updateFlagValue("31760", "FALSE");  // companion flag required
```

**Tip:** Check if the failing test has a `@BeforeMethod` or setup that calls `updateFlagValue`. Cross-reference the flag ID with the Connexus feature table.

---

## Pattern 9 — Optional UI Screen Causes Failure

**Symptoms:** Test fails on a screen/popup that appears in some stores but not others. Works locally, fails in CI for a different store config.

**Root cause:** Test assumes a screen is always present when it's actually conditional (store-specific, patient-specific, or feature-flag driven).

**Fix template:**
```java
// BEFORE — hard call that fails if screen absent
dropOffPage.handleAnnualValidatePatInfoPopUp();

// AFTER — guard with isElementDisplayed
if (isElementDisplayed(patInfoPopupLocator, 5)) {
    dropOffPage.handleAnnualValidatePatInfoPopUp();
    Reporter.log("[HEALER] Patient info popup handled (optional screen)");
} else {
    Reporter.log("[HEALER] Patient info popup not present — skipping (optional screen)");
}
```

---

## Pattern 10 — Data / SQL Mismatch

**Symptoms:** `AssertionError` on count validation (expected 3, got 2). Test data in `.xlsx` file doesn't match current DB state or business rules.

**Root cause A — SQL filters too broadly or too narrowly:**
```java
// BEFORE — multiple NOT LIKE conditions miss edge cases
WHERE patient_name NOT LIKE '%[0-9]%'

// AFTER — use regex MATCHES for cleaner exclusion
WHERE patient_name NOT MATCHES '^.*[0-9].*$'
```

**Root cause B — Test data in Excel out of date:**
- File: `src/test/resources/TestData/connexus/DropOff/DropOffUatTestSet1DataBook.xlsx`
- Update the expected count/priority columns to match current store data

**Root cause C — Calculation off by one:**
```java
// BEFORE — wrong: qty not reduced after fill
on_hand_qty_AfterSetFill = on_hand_qty_BeforeSetFill;

// AFTER — correct: subtract fill quantity
on_hand_qty_AfterSetFill = on_hand_qty_BeforeSetFill - fillItemQty;
```
