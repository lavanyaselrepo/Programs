# Sauce Labs Integration for Playwright Tests

This project is configured to run Playwright tests on Sauce Labs cloud infrastructure.

## Prerequisites

1. **Sauce Labs Account**: Username `sso-walmart-Saloni.Sharma`
2. **saucectl CLI**: Install globally with `npm install -g saucectl`
3. **Tunnel Access**: Uses `dx-centralized-tunnel` for internal network access

## Running Tests

### Local Testing

```bash
npm run test:local
```

### Sauce Labs Cloud Testing

```bash
npm run test:sauce
```

## Configuration Files

- **`.sauce/config.yml`**: Sauce Labs configuration with tunnel settings
- **`playwright-sauce.config.ts`**: Playwright config optimized for Sauce Labs
- **`config/test-config.<env>.json`**: Environment-specific test configuration (e.g., `config/test-config.stg.json`, `config/test-config.dev.json`)

## Key Features

- ✅ Runs on Sauce Labs cloud (Windows 11, Chrome)
- ✅ Uses centralized tunnel for internal network access
- ✅ Automatic screenshot capture on test completion
- ✅ Video recording of test execution
- ✅ Test results available in Sauce Labs dashboard

## Test Results

After running tests on Sauce Labs, view results at:

- Sauce Labs Dashboard: https://app.saucelabs.com/
- Build links are provided in console output
