import { defineConfig } from '@playwright/test';
// Using runtime config loader in tests instead of importing here


/**
 * Playwright configuration specifically for Sauce Labs
 * This config doesn't define projects to avoid conflicts with saucectl --browser option
 * 
 * @Author: Saloni Sharma
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
export default defineConfig({
  globalSetup: './src/utilities/globalSetup.js',
  globalTeardown: './src/utilities/globalTeardown.js',
  // Fail the Playwright run before Sauce suite timeout (75m)
  globalTimeout: 75 * 60 * 1000,
  // Increase per-test timeout for slower cloud runs
  timeout: 600000,
  // Be explicit
  retries: 2,
  // Keep to 5 worker on Sauce for stability
  workers: 5,
  // Stop the run quickly when failures happen
  maxFailures: 30,
  testDir: './src',
  testMatch: ['**/*.test.js', '**/*.spec.js', '**/*test.js', '**/*-test.js'],
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['html', { open: 'never', outputFolder: "playwright-report", }], // Generate report but don't serve it
    ['json', { outputFile: 'test-results/results.json' }],
    ['list']  // Show progress in console
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://localhost:3000',

    /* Trust self-signed/stage certificates */
    ignoreHTTPSErrors: true,

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
    
    /* Take screenshot for all tests (pass and fail) */
    screenshot: 'on',
    
    /* Record video on failure */
    video: 'retain-on-failure',
    
    /* Browser configuration for Sauce Labs */
    browserName: 'chromium',
    headless: false, // saucectl will handle headless mode
    viewport: null,
    launchOptions: {
      args: ['--start-maximized'],
      slowMo: 0
    }
  },

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
