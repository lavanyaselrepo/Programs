/**
 * Config - Environment-specific URLs and settings (non-sensitive)
 * Credentials are loaded separately via credentials.js
 */

const env = (process.env.ENV || 'stg').toLowerCase();
const urls = require('./urls.json');

function getConfig() {
  return {
    carbonInsurance: {
      url: urls[env]?.carbonInsurance || urls.stg.carbonInsurance,
      authUrlPattern: '/as/authorization',
    },
    carbonDrug: {
      url: urls[env]?.carbonDrug || urls.stg.carbonDrug,
      authUrlPattern: '/as/authorization',
    },
    sauceLabs: {
      region: 'us-west-1',
      headless: false,
      runOnSauce: true,
      build: 'Playwright-Carbon-UI-Tests',
      tunnelName: 'default-tunnel',
    },
    env: env,
  };
}

module.exports = { getConfig };


