import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';

// Using runtime config loader in tests instead of importing here

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
dotenv.config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  globalSetup: './src/utilities/globalSetup.js',
  globalTeardown: './src/utilities/globalTeardown.js',
  // Increase per-test timeout to accommodate login + navigation waits
  timeout: 120000,
  testDir: './src/tests',
  testMatch: ['**/*.test.js', '**/*.spec.js', '**/*test.js', '**/*-test.js'],
  /* Run tests in files in parallel */
  fullyParallel: true,
  workers: process.env.CI ? 1 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['html'],
    ['json', { outputFile: 'test-results/results.json' }]
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://localhost:3000',

    /* Trust self-signed/stage certificates */
    ignoreHTTPSErrors: true,

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
    
    /* Take screenshot for all tests (pass and fail) */
    screenshot: 'on',
    
    /* Record video on failure */
    video: 'retain-on-failure',
  },

  /* Configure projects for major browsers */
  projects: [
    // Local Chrome configuration
    {
      name: 'chromium-local',
      use: { 
        browserName: 'chromium',
        headless: false,
        viewport: null,
        launchOptions: {
          args: ['--start-maximized'],
          slowMo: process.env.CI ? 0 : 1000
        }
      },
    },

    // Sauce Labs Chrome configuration (used by saucectl)
    {
      name: 'chromium-sauce',
      use: {
        browserName: 'chromium',
        headless: false, // saucectl will handle headless mode
        viewport: null,
        launchOptions: {
          args: ['--start-maximized'],
          slowMo: 1000
        }
      },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
