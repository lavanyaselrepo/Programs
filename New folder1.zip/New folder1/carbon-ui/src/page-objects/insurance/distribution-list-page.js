const { expect } = require('@playwright/test');

function distributionListLocators(page) {
  return {
    // Page identity
    heading: page.getByRole('heading', { name: 'Distribution List' }),

    // Actions
    newListButton: page.getByRole('button', { name: /New List/i }),
    addButtonByName: page.locator('//button[@name="Add"]'),
    saveButtonByName: page.locator('//button[@name="Save"]'),
    updateButtonByName: page.locator('//button[@name="Update"]'),
    editButton: page.getByRole('button', { name: /^Edit$/i }),
    deleteButton: page.getByRole('button', { name: /^Delete$/i }),

    // Form fields
    listNameInputById: page.locator('//input[@id="listName" and @type="text"]'),
    editableSwitch: page.locator('//input[@id="editable"]'),
    storesTextareaById: page.locator('//textarea[@id="stores"]'),

    // Search
    searchByPlaceholder: page.getByPlaceholder(/Search by List Name/i),
    searchByLabel: page.getByLabel(/Search by List Name/i),
    searchFallbackInput: page.getByTestId('data-distribution-search').locator('input[type="text"]').first(),

    // Table
    tableRows: page.locator('table tbody tr'),
    rowByName: (name) => page.locator('table tbody tr').filter({ hasText: name }).first(),
    rowRadio: (row) => row.locator('input[type="radio"]'),
    rowCells: (row) => row.locator('td'),

    //Info Message
    systemGeneratedListOnlyInfo: page.getByText('You have read-only access to this system-generated list.'),
    writeUserWarningMessage: page.getByText('You can only edit distribution lists that you created.'),
    validStoresGroup: page.getByRole('group', { name: /Valid store numbers/i }),
    invalidStoresGroup: page.getByRole('group', { name: /Invalid store numbers/i })
  };
}

class DistributionListPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;
    this.ui = distributionListLocators(page);
  }

  async verifyOnDistributionListPage() {
    await this.page.waitForLoadState('networkidle');
    await expect(this.ui.heading).toBeVisible({ timeout: 20000 });
  }

  async waitForAnyRow() {
    await expect(this.ui.tableRows.first()).toBeVisible({ timeout: 15000 });
  }

  async getFirstRowData() {
    const row = this.ui.tableRows.first();
    await expect(row).toBeVisible({ timeout: 10000 });
    const cells = this.ui.rowCells(row);
    const name = await cells.nth(1).innerText();
    const storeCount = await cells.nth(2).innerText();
    const createdBy = await cells.nth(3).innerText();
    return { name, storeCount, createdBy };
  }

  async openNewListForm() {
    await expect(this.ui.newListButton).toBeVisible({ timeout: 20000 });
    await this.ui.newListButton.click();
    await this.page.waitForLoadState('networkidle');
    await expect(this.ui.listNameInputById).toBeVisible({ timeout: 20000 });
  }

  async setEditableToggle(desiredChecked) {
    if (typeof desiredChecked !== 'boolean') return;
    const current = await this.ui.editableSwitch.isChecked();
    if (current !== desiredChecked) {
      await this.ui.editableSwitch.click();
    }
  }

  async fillListName(name) {
    await this.ui.listNameInputById.click();
    await this.ui.listNameInputById.fill(name);
  }

  async fillStores(stores) {
    const value = Array.isArray(stores) ? stores.join(', ') : String(stores || '');
    await expect(this.ui.storesTextareaById).toBeVisible({ timeout: 20000 });
    await this.ui.storesTextareaById.fill(value);
  }

  async clickAddStores() {
    try {
      await this.ui.addButtonByName.click();
    } catch {
      try {
        await this.page.getByRole('button', { name: /Add/i }).click();
      } catch (error) {
        throw new Error('Failed to find Add button after multiple attempts');
      }
    }
  }

  async clickSave() {
    await expect(this.ui.saveButtonByName).toBeEnabled({ timeout: 10000 });
    await this.ui.saveButtonByName.click();
    await this.page.waitForLoadState('networkidle');
  }

  async clickUpdate() {
    await expect(this.ui.updateButtonByName).toBeEnabled({ timeout: 10000 });
    await this.ui.updateButtonByName.click();
    await this.page.waitForLoadState('networkidle');
  }

  async createNewList({ name, stores, editable, userType = 'admin' } = {}) {
    await this.openNewListForm();
    // Write users don't have the editable toggle in the New List form; skip toggling for them.
    if (userType !== 'write' && typeof editable !== 'undefined') {
      await this.setEditableToggle(!!editable);
    }
    await this.fillListName(name);
    await this.fillStores(stores);
    await this.clickAddStores();
    await this.clickSave();
  }

  async searchByListName(targetName) {
    let input;
    try {
      input = this.ui.searchByPlaceholder;
      await expect(input).toBeVisible({ timeout: 5000 });
    } catch {
      try {
        input = this.ui.searchByLabel;
        await expect(input).toBeVisible({ timeout: 5000 });
      } catch {
        input = this.ui.searchFallbackInput;
        await expect(input).toBeVisible({ timeout: 5000 });
      }
    }

    await input.click();
    try {
      await input.fill('');
      await input.press('ControlOrMeta+A');
      await input.press('Backspace');
    } catch {}
    await input.fill(targetName);
    try { await input.press('Enter'); } catch {}
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(1500);
    return input;
  }

  rowByName(name) {
    return this.ui.rowByName(name);
  }

  async readRowValues(row) {
    const cells = this.ui.rowCells(row);
    const name = await cells.nth(1).innerText();
    const storeCount = await cells.nth(2).innerText();
    const createdBy = await cells.nth(3).innerText();
    return { name, storeCount, createdBy };
  }

  async selectRow(row) {
    await expect(row).toBeVisible({ timeout: 20000 });
    await this.ui.rowRadio(row).check();
  }

  async clickEdit() {
    await expect(this.ui.editButton).toBeVisible({ timeout: 20000 });
    await this.ui.editButton.click();
  }

  async isEditableToggleDisabled() {
    return this.ui.editableSwitch.isDisabled();
  }

  async isEditableToggleChecked() {
    return this.ui.editableSwitch.isChecked();
  }

  async replaceStoresAndUpdate(newStores) {
    const value = Array.isArray(newStores) ? newStores.join(', ') : String(newStores || '');
    await expect(this.ui.storesTextareaById).toBeVisible({ timeout: 20000 });
    await this.ui.storesTextareaById.fill(value);
    await this.ui.addButtonByName.click();
    await this.ui.updateButtonByName.click();
  }

  async appendStoresAndUpdate(additionalStores) {
    await expect(this.ui.storesTextareaById).toBeVisible({ timeout: 20000 });
    const currentValue = await this.ui.storesTextareaById.inputValue();
    const currentList = currentValue.split(/[\s,]+/).filter(Boolean);
    const toAdd = Array.isArray(additionalStores) ? additionalStores.map(String) : [String(additionalStores)];
    const combined = [...currentList, ...toAdd];
    const value = combined.join(', ');
    await this.ui.storesTextareaById.fill(value);
    await this.ui.addButtonByName.click();
    await this.ui.updateButtonByName.click();
    await this.page.waitForLoadState('networkidle');
  }

  async deleteSelectedAndConfirm() {
    await expect(this.ui.deleteButton).toBeVisible({ timeout: 20000 });
    await this.ui.deleteButton.click();
    try {
      await this.ui.deleteButton.click();
    } catch {
      await this.page.getByRole('dialog').getByRole('button', { name: /Delete|Confirm|Yes/i }).click();
    }
  }

  async verifySystemGeneratedListOnlyInfo(){
    await expect(this.ui.systemGeneratedListOnlyInfo).toBeVisible({ timeout: 15000 });
  }

  async verifyWriteUserWarningMessage(){
    await expect(this.ui.writeUserWarningMessage).toBeVisible({ timeout: 15000 });
  }

  async verifyInvalidStores(stores) {
    await expect(this.ui.invalidStoresGroup).toBeVisible({ timeout: 10000 });
		for (const store of stores) {
			await expect(this.ui.invalidStoresGroup.getByRole('button', { name: store })).toBeVisible();
		}
  }
  
  async verifyValidStores(stores) {
    await expect(this.ui.validStoresGroup).toBeVisible({ timeout: 10000 });
		for (const store of stores) {
			await expect(this.ui.validStoresGroup.getByRole('button', { name: store })).toBeVisible();
		}
  }

  async clickOnTheDlName(name) {
    await this.page.getByText(name, { exact: true }).click();
    await this.page.waitForLoadState('networkidle');
  }

  async clickCancelOrCloseButton() {
    await this.page.getByRole('button', { name: 'Close dialog' }, { exact: true }).click();
    await this.page.waitForLoadState('networkidle');
  }
}

module.exports = { DistributionListPage };


