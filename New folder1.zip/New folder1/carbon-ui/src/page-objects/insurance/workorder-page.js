const { expect } = require('@playwright/test');

function workorderPageLocators(page) {
    return {
        // Page identity
        workOrderPageHeading: page.getByRole('heading', { name: 'Work Orders' }),
        packagingPageHeading: page.getByRole('heading', { name: 'Create Package' }),
        searchWorkOrderByNameSearchBar: page.getByRole('searchbox', { name: 'Name' }), 
        workOrderHyperLink: (planName) => page.locator('a').filter({ hasText: planName }).first(),
        approveButton: page.getByRole('button', { name: 'Approve' }),
        editButton: page.getByRole('button', { name: 'Edit' }),
    }
}

class WorkorderPage {
    constructor(page, config) {
        this.page = page;
        this.config = config;
        this.ui = workorderPageLocators(page);
    }

    async approveAnyTypeOfWorkOrder(workOrderType, carrier, plan) {
        expect(this.ui.workOrderPageHeading).toBeVisible({ timeout: 20000 });
        const workOrderName = workOrderType + ' ' + carrier + '/' + plan;
        await this.ui.searchWorkOrderByNameSearchBar.fill(workOrderName);
        await this.page.waitForTimeout(3000);
        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                await this.ui.workOrderHyperLink(workOrderName).click();
                await this.page.waitForTimeout(3000);
                await this.ui.approveButton.waitFor({ state: 'visible', timeout: 3000 });
                break;
            } catch (error) {
                if (attempt === 3) throw error;
                console.log(`Click attempt ${attempt} failed, retrying...`);
                await this.page.waitForTimeout(500);
            }
        }
        await this.ui.approveButton.click();
        await expect(this.ui.packagingPageHeading).toBeVisible({ timeout: 20000 });
    }

    async approveTheWorkOrder(regionalPlanData, plan) {
        await this.page.waitForTimeout(5000);
        const planSetupIpName = 'NEW_PLAN_SETUP_' + regionalPlanData.CARRIER + '/' + plan;
        await this.ui.workOrderHyperLink(planSetupIpName).click();
        await this.ui.approveButton.click();
        await expect(this.ui.packagingPageHeading).toBeVisible({ timeout: 20000 });
    }

    async clickEditWorkOrderButton(regionalPlanData, plan) {
        await this.page.waitForTimeout(5000);
        const planSetupIpName = 'NEW_PLAN_SETUP_' + regionalPlanData.CARRIER + '/' + plan;
        await this.ui.workOrderHyperLink(planSetupIpName).click();
        await this.ui.editButton.click();
    }

    async verifyLandedOnWorkOrdersPage() {
        await expect(this.ui.workOrderPageHeading).toBeVisible({ timeout: 15000 });
    }

    async verifyWorkOrderNameVisible(workOrderName) {
        await expect(this.ui.workOrderPageHeading).toBeVisible({ timeout: 15000 });
        await expect(this.page.getByRole('cell', { name: workOrderName })).toBeVisible({ timeout: 15000 });
    }
}

module.exports = { WorkorderPage };