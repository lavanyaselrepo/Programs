const { expect } = require('@playwright/test');
const { authlogin } = require('../../../src/page-objects/commons/authlogin');
const { clickWithRetry } = require('../../../src/page-objects/commons/clickWithRetry');
const { credentials } = require('../../utilities/credentials');


function plansPageLocators(page){
    return {
        plansHeading: page.getByRole('heading', { name: 'Plans' }),
        createNewPlanButton: page.getByRole('button', { name: 'Create New Plan' }),
        advancedSearchButton: page.getByRole('button', { name: 'Advanced search' }),
        planNameSearchBar: page.getByRole('searchbox', { name: 'Plan Name', exact: true }),
        selectPlanNameLink: (planName) => page.getByRole('link', { name: planName }),
        selectPlanCheckBox: (planName) => page.getByRole('row', { name: planName }).getByRole('checkbox'),
        addStoresButton: page.getByTestId('add-stores-button-empty'),
        storeNumberSearchBar: page.getByRole('searchbox', { name: 'Store Number' }),
        selectStoreNumber: page.getByRole('row', { name: 'Store Number Address City' }).getByRole('checkbox'),
        packageButton: page.getByRole('button', { name: 'Package' }),        
        differentRegionalPlansWarning: page.getByText('Selected plans are part of different regional plans'),
        mixedPlansWarning: page.getByText('Selected plans contain a mix of regional and chain-wide plans'),
        binSearchBar: page.getByRole('searchbox', { name: 'BIN' }),
        planRowByFlag: (flag, index = 0) => page.getByRole('row', { name: new RegExp(`\\s${flag}\\s`) }).nth(index).getByRole('checkbox'),

        createNewPlan_BIN: page.getByRole('textbox', { name: 'BIN' }),
        createNewPlan_PlanName: page.getByRole('textbox', { name: 'Plan Name' }),
        createNewPlan_PCN: page.getByRole('textbox', { name: 'PCN' }),
        createNewPlan_Carrier: page.getByRole('textbox', { name: 'Carrier' }),
        createNewPlan_Plan: page.getByRole('textbox', { name: 'Plan', exact: true }),
        createNewPlan_ExpirationDate: page.getByRole('textbox', { name: 'Expiration Date' }),
        createNewPlan_EditFlagButton: page.locator('#flags').getByRole('button', { name: 'Edit', exact: true }),
        createNewPlan_EditFlag_AUTOPOPULATE: page.getByRole('row', { name: 'AUTO POPULATE COB REJECT' }).getByRole('combobox'),
        createNewPlan_EditFlag_COB: page.getByRole('row', { name: 'COB 794 NONE' }).getByRole('combobox'),
        createNewPlan_EditFlag_CATEGORY: page.getByRole('row', { name: 'CATEGORY 32663 NONE' }).getByRole('combobox'),
        createNewPlan_EditFlag_DELIVERY: page.getByRole('row', { name: 'DELIVERY TP SIGNATURE 32001' }).getByRole('combobox'),
        createNewPlan_EditFlag_INSTORE: page.getByRole('row', { name: 'IN STORE TP SIGNATURE 732 NONE' }).getByRole('combobox'),
        createNewPlan_EditFlag_PLAINCHAIN: page.getByRole('row', { name: 'PLAN CHAIN FLAG 5608 NONE' }).getByRole('combobox'),
        createNewPlan_EditFlag_SUBMISSION: page.getByRole('row', { name: 'SUBMISSION ROUTE 32660 NONE' }).getByRole('combobox'),
        createNewPlan_EditFlag_NONE: page.getByRole('cell', { name: 'NONE' }).getByRole('combobox'),
        createNewPlan_SaveButton: page.getByRole('button', { name: 'Save' }),
        createNewPlan_AddClaimFormatButton: page.getByRole('button', { name: 'Add Claim Format' }),
        createNewPlan_CF_ProcessorName: page.getByRole('textbox', { name: 'Processor Name' }),
        createNewPlan_CF_ProcessorName_Select: page.getByRole('cell').first(),
        createNewPlan_CF_AddButton: page.getByRole('button', { name: 'Add' }),
        createNewPlan_AddClaimParametersButton: page.getByRole('button', { name: 'Add Claim Parameters' }),
        createNewPlan_ContactsAddButton: page.getByTestId('contacts-add-button-empty'),
        createNewPlan_ContactsAddButton_edit: page.getByTestId('contacts-add-button'),
        createNewPlan_Contacts_Type: page.getByLabel('Contact Type*'),
        createNewPlan_Contacts_Name: page.getByRole('textbox', { name: 'Name*' }),
        createNewPlan_Contacts_Save: page.getByTestId('contact-modal-save-button'),
        createNewPlan_SyncGroupExceptionButton: page.getByRole('button', { name: 'Sync Group Exception' }),
        createNewPlan_FinalizeButton: page.getByRole('button', { name: 'Finalize' }),
        createNewPlan_GroupAndSchedulePackageButton: page.getByRole('button', { name: 'Group and Schedule Package' }),
        createNewPlan_DistributionList: page.getByRole('textbox', { name: 'Distribution List *' }),
        createNewPlan_AddDistributionListButton: page.getByRole('button', { name: '+ Add' }),
        createNewPlan_ScheduleButton: page.getByRole('button', { name: 'Schedule', exact: true }),

        // AutoPackaging
        autoPackagingToggle: page.getByRole('checkbox', { name: 'No' }),
        packageNameInput: page.getByRole('textbox', { name: 'Package Name*' }),
    }
}


class PlansPage {
    constructor(page, config){
        this.page=page;
        this.config=config;
        this.ui = plansPageLocators(page);
    }

    async openInsuranceAndLoginIfNeeded(userType) {
        console.log('🔐 Opening Insurance and logging in if needed');
        console.log('🔐 Username:', credentials.carbonInsurance.username(userType));
        await authlogin.navigateAndEnsureAuth(
          this.page,
          this.config.carbonInsurance.url,
          this.config.carbonInsurance.authUrlPattern,
          credentials.carbonInsurance.username(userType),
          credentials.carbonInsurance.password(userType),
          this.ui.plansHeading
        );
      }

    async goToCreateNewPlan(regionalPlanData, planName, plan) {
        await clickWithRetry({
            locator: this.ui.createNewPlanButton,
            label: 'Create New Plan click',
            afterClick: async () => {
                await expect(this.page.locator('h1')).toHaveText('New Insurance Plans');
            }
        });
        await this.ui.createNewPlan_BIN.fill(regionalPlanData.BIN);
        await this.ui.createNewPlan_PlanName.fill(planName);
        await this.ui.createNewPlan_PCN.fill(regionalPlanData.PCN);
        await this.ui.createNewPlan_Carrier.fill(regionalPlanData.CARRIER);
        await this.ui.createNewPlan_Plan.fill(plan);
        await this.ui.createNewPlan_ExpirationDate.click();
        await this.ui.createNewPlan_ExpirationDate.pressSequentially(regionalPlanData.EXPIRATION_DATE);

        await this.ui.createNewPlan_AddClaimFormatButton.click();
        await this.ui.createNewPlan_CF_ProcessorName.fill(regionalPlanData.PROCESSOR);
        //add locator for selecting first tile.
        await this.ui.createNewPlan_CF_ProcessorName_Select.click();
        await this.ui.createNewPlan_CF_AddButton.click();

        await this.ui.createNewPlan_AddClaimParametersButton.click();
        await this.ui.createNewPlan_SaveButton.click();

        await this.ui.createNewPlan_EditFlagButton.click();
        await this.ui.createNewPlan_EditFlag_AUTOPOPULATE.selectOption(regionalPlanData.AUTOPOPULATE);
        await this.ui.createNewPlan_EditFlag_COB.selectOption(regionalPlanData.COB);
        await this.ui.createNewPlan_EditFlag_CATEGORY.selectOption(regionalPlanData.CATEGORY);
        await this.ui.createNewPlan_EditFlag_DELIVERY.selectOption(regionalPlanData.DELIVERY);
        await this.ui.createNewPlan_EditFlag_INSTORE.selectOption(regionalPlanData.INSTORE);
        await this.ui.createNewPlan_EditFlag_PLAINCHAIN.selectOption(regionalPlanData.PLAINCHAIN);
        await this.ui.createNewPlan_EditFlag_NONE.selectOption(regionalPlanData.NONE);
        await this.ui.createNewPlan_SaveButton.click();

        await this.ui.createNewPlan_ContactsAddButton.click();
        await this.ui.createNewPlan_Contacts_Type.click();
        await this.ui.createNewPlan_Contacts_Type.selectOption(regionalPlanData.CONTACTS_TYPE);
        await this.ui.createNewPlan_Contacts_Name.fill(regionalPlanData.CONTACTS_NAME);
        await this.ui.createNewPlan_Contacts_Save.click();

        await clickWithRetry({
            locator: this.ui.createNewPlan_SyncGroupExceptionButton,
            label: 'Sync Group Exception click',
            afterClick: async () => {
                await this.ui.createNewPlan_SaveButton.waitFor({ state: 'visible', timeout: 3000 });
            }
        });

        // Creating a promise for getting the request Body from the createAndSchedule API.
        const createAndSchedulePromise =this.getWorkOrderDetailsFromCreateAndSchedule();
        await this.ui.createNewPlan_SaveButton.click();
        const requestData = await createAndSchedulePromise;

        await clickWithRetry({
            locator: this.ui.createNewPlan_FinalizeButton,
            label: 'Finalize button click'
        });
        return requestData;
    }

    async addEnrolledStoresToRegionalPlanAndFinalise(regionalPlanData, planName) {
        await this.page.waitForTimeout(5000);
        if(! this.page.url().includes('/insurance/plans') ) {
            await this.page.goto('https://hw-carbon.stage.walmart.com/insurance/plans');
        } 
        await this.page.waitForLoadState('networkidle');
        await this.ui.advancedSearchButton.click();
        await this.ui.planNameSearchBar.fill(planName);
        await clickWithRetry({
            locator: this.ui.selectPlanNameLink(planName),
            label: 'Select plan link click',
            afterClick: async () => {
                await this.ui.addStoresButton.waitFor({ state: 'visible', timeout: 3000 });
            }
        });
        await this.ui.addStoresButton.click();
        for(const storeNumber of regionalPlanData.ENROLLED_STORES) {
            await this.ui.storeNumberSearchBar.fill(storeNumber.toString());
            await this.page.waitForTimeout(3000);
            await clickWithRetry({
                locator: this.ui.selectStoreNumber,
                label: 'Select store checkbox click',
                afterClick: async () => {
                    await this.ui.createNewPlan_SaveButton.waitFor({ state: 'visible', timeout: 3000 });
                }
            });
        }
        await this.ui.createNewPlan_SaveButton.click();
        await this.page.waitForTimeout(3000);
        await this.ui.createNewPlan_FinalizeButton.click();
    }

    /**
     * Waits for the planDetails API response. Must be used by starting the wait before the action that triggers the request (e.g. before clicking Package).
     */
    async getGroupIdFromApi() {
        const response = await this.page.waitForResponse(
            (resp) =>
                resp.url().includes('/api/insurance/v1/packageData/planDetails') &&
                resp.status() === 200 || resp.status() === 400,
            { timeout: 15000 }
        );
        if(response.status() == 200) {
            const body = await response.json();
            return body.groupId;
        }
        else if(response.status() == 400) {
            const body = undefined;
            return body;
        }
    }

    async getWorkOrderDetailsFromUpdate() {
        let capturedData = null;
        
        await this.page.route('**/api/insurance/v1/packageData/package-schedule/update', async (route) => {
            const response = await route.fetch();
            const requestData = route.request().postData() ? JSON.parse(route.request().postData()) : null;
            const responseBody = await response.text();
            
            capturedData = { requestData, responseBody };
            await route.fulfill({ response });
        });
        
        return new Promise((resolve) => {
            const checkInterval = setInterval(() => {
                if (capturedData) {
                    clearInterval(checkInterval);
                    this.page.unroute('**/api/insurance/v1/packageData/package-schedule/update');
                    resolve(capturedData);
                }
            }, 100);
            
            setTimeout(() => {
                clearInterval(checkInterval);
                this.page.unroute('**/api/insurance/v1/packageData/package-schedule/update');
                resolve({ requestData: null, responseBody: '' });
            }, 6000);
        });
    }

    async getWorkOrderDetailsFromCreateAndSchedule() {
        const response = await this.page.waitForResponse(
            (resp) => resp.url().includes('/api/insurance/v1/packageData/createAndSchedule'),
            { timeout: 30000 }
        );
        expect(response.ok()).toBeTruthy();
        const request = response.request();
        const requestData = request.postData() ? JSON.parse(request.postData()) : null;
        return requestData;
    }


    async packagingInPlanScreen(planName) {
        await this.page.waitForTimeout(5000);
        if(! this.page.url().includes('/insurance/plans') ) {
            await this.page.goto('https://hw-carbon.stage.walmart.com/insurance/plans');
        }
        await this.page.waitForLoadState('networkidle');
        await this.ui.advancedSearchButton.click();
        await this.ui.planNameSearchBar.fill(planName);
        await this.ui.selectPlanCheckBox(planName).click();
        await expect(this.ui.packageButton).toBeEnabled();

        // Start waiting for the API *before* clicking so we don't miss the response
        const groupIdPromise = this.getGroupIdFromApi();
        await this.ui.packageButton.click();
        const groupId = await groupIdPromise;
        console.log('Group ID: ' + groupId);
        return groupId;
    }

    async addNewContact(regionalPlanData) {
        await this.ui.createNewPlan_ContactsAddButton_edit.click();
        await this.ui.createNewPlan_Contacts_Type.click();
        await this.ui.createNewPlan_Contacts_Type.selectOption(regionalPlanData.CONTACTS_TYPE_2);
        await this.ui.createNewPlan_Contacts_Name.fill(regionalPlanData.CONTACTS_NAME_2);
        await this.ui.createNewPlan_Contacts_Save.click();

        await this.ui.createNewPlan_SaveButton.click();

        await this.ui.createNewPlan_ContactsAddButton_edit.click();
        await this.ui.createNewPlan_Contacts_Type.click();
        await this.ui.createNewPlan_Contacts_Type.selectOption(regionalPlanData.CONTACTS_TYPE_2);
        await this.ui.createNewPlan_Contacts_Name.fill(regionalPlanData.CONTACTS_NAME_2);
        await this.ui.createNewPlan_Contacts_Save.click();

        // Creating a promise for getting the request and response from the update API.
        const updatePromise = this.getWorkOrderDetailsFromUpdate();
        await this.ui.createNewPlan_FinalizeButton.click();
        const { requestData, responseBody } = await updatePromise;
        //await this.ui.createNewPlan_FinalizeButton.click();
        return { requestData, responseBody };
    }

    async updateDistListAndScheduleInfo(regionalPlanData, plan) {
        await this.ui.autoPackagingToggle.check();
        await this.ui.packageNameInput.fill(regionalPlanData.PACKAGE_NAME);
        await this.ui.createNewPlan_DistributionList.fill(regionalPlanData.DISTRIBUTION_LIST);
        await this.ui.createNewPlan_AddDistributionListButton.click();
        
        
        await this.ui.createNewPlan_SaveButton.click();
        await this.ui.createNewPlan_FinalizeButton.click();
    }

    async selectMultipleRegionalPlans(bin, planNumber = 1) {
        await this.ui.binSearchBar.clear();
        await this.page.waitForTimeout(3000);
        await this.ui.binSearchBar.fill(bin);
        await this.page.waitForTimeout(3000);
        for(let i = 0; i < planNumber; i++) {
            await this.ui.planRowByFlag('N', i).click();
        }
    }

    /**
     * Asserts that the warning about selected plans being part of different regional plans is visible.
     */
    async expectDifferentRegionalPlansWarningVisible() {
        await expect(this.ui.differentRegionalPlansWarning).toBeVisible({ timeout: 5000 });
    }

    async expectMixedPlansWarningVisible() {
        await expect(this.ui.mixedPlansWarning).toBeVisible({ timeout: 5000 });
    }

    async selectMultipleChainPlans(bin, planNumber = 1) {
        await this.ui.binSearchBar.clear();
        await this.ui.binSearchBar.fill(bin);
        for(let i = 0; i < planNumber; i++) {
            await this.ui.planRowByFlag('Y', i).click();
        }
    }

    async selectMixedPlans(binList = []) {
        for(let i = 0; i < binList.length; i++) {
            await this.ui.binSearchBar.clear();
            await this.page.waitForTimeout(3000);
            await this.ui.binSearchBar.fill(binList[i].bin);
            await this.page.waitForTimeout(3000);
            await this.ui.planRowByFlag(binList[i].flag, 0).click();
        }
    }
}

module.exports = { PlansPage };