const { expect } = require('@playwright/test');
const { authlogin } = require('../commons/authlogin');
const { credentials } = require('../../utilities/credentials');

function packagingDashboardLocators(page) {
	return {
		// Global/post-login signal
		plansHeading: page.getByRole('heading', { name: 'Plans' }),

		// Navigation
		packagingNavText: page.getByText('Packaging'),
		packageDashboardButton: page.getByRole('button', { name: 'Package Dashboard' }),
		packageDashboardHeading: page.getByRole('heading', { name: 'Package Dashboard', level: 2 }),
		listMaintenanceButton: page.getByRole('button', { name: 'List Maintenance' }),
    packageDistributionPopUp: page.getByRole('heading', { name: 'Distribution Information*' }),
    redistributePackageHeading: page.getByRole('heading', { name: 'Redistribute Package' }),

    subjectAreaDropdown: page.getByLabel('Subject Area'),
    searchByNameInput: page.getByRole('searchbox', { name: 'Name' }),
    selectTheSearchResult: (searchName) => page.getByRole('row', { name: searchName }).getByRole('checkbox'),
    groupAndSchedulePackageButton: page.getByRole('button', { name: 'Group and Schedule Package' }),
    schedulePackageHeading: page.getByRole('heading', { name: 'Schedule a Package' }),
    storeSelectionHeading: page.getByRole('heading', { name: 'Select Stores for Regional Plan' }),
    storeRowCheckbox: (storeId) =>
      page.getByRole('row').filter({ has: page.getByRole('cell', { name: String(storeId) }) }).getByRole('checkbox'),
    schedulePackageNextButton: page.getByRole('button', { name: 'Next', exact: true }),
    distributionListInput: page.getByRole('textbox', { name: 'Distribution List *' }),
    selectDLFromDropdown: (dlName) => page.getByRole('option', { name: dlName }),
    addDLButton: page.getByRole('button', { name: '+ Add' }),
    scheduleButton: page.getByRole('button', { name: 'Schedule', exact: true }),
    searchByPackageNameInPackageDashboard: page.getByRole('searchbox', { name: 'Package Name' }),
    redistributeButton: page.getByRole('button', { name: 'Redistribute' }),
    selectAllEnrolledStoresForRegionalPlan: page.getByRole('row', { name: 'Store # Type Address City' }).getByRole('checkbox'),
    redistributePackageButton: page.getByRole('button', { name: 'Redistribute Package' }),
		listMaintenanceButton: page.getByRole('button', { name: 'List Maintenance' }),

		// Log Out (button or link in app header)
		logOutButton: page.getByRole('button', { name: /log out/i }),
		logOutLink: page.getByRole('link', { name: /log out/i }),
	};
}

class PackagingDashboardPage {
  constructor(page, config) {
    this.page = page;
    this.config = config;
    this.ui = packagingDashboardLocators(page);
  }
  /**
   * Navigates to Insurance application home and performs login if required.
   * Verifies the Plans heading as post-login signal.
   */
  async openInsuranceAndLoginIfNeeded(userType) {
    console.log('🔐 Opening Insurance and logging in if needed');
    console.log('🔐 Username:', credentials.carbonInsurance.username(userType));
    await authlogin.navigateAndEnsureAuth(
      this.page,
      this.config.carbonInsurance.url,
      this.config.carbonInsurance.authUrlPattern,
      credentials.carbonInsurance.username(userType),
      credentials.carbonInsurance.password(userType),
      this.ui.plansHeading
    );
  }

  /**
   * From main app shell, open the Packaging area and ensure Package Dashboard action is visible.
   */
  async openPackagingArea() {
    await expect(this.ui.packagingNavText).toBeVisible({ timeout: 15000 });
    await this.ui.packagingNavText.click();
    // Double click to stabilize if first click doesn't land
    await this.ui.packagingNavText.click();
    await expect(this.ui.packageDashboardButton).toBeVisible({ timeout: 15000 });
  }

  /**
   * Clicks the Package Dashboard action and waits for dashboard route.
   */
  async goToPackageDashboard() {
    for (let attempt = 1; attempt <= 3; attempt++) {
      await this.ui.packageDashboardButton.click();
      try {
        await this.page.waitForURL(/\/insurance\/package-dashboard/, { timeout: 7000 });
        break;
      } catch (error) {
        if (attempt === 3) throw error;
        await this.page.waitForTimeout(1000);
      }
    }
  }

  /**
   * From Package Dashboard, open List Maintenance (Distribution List) and wait for route.
   */
  async goToDistributionList() {
    for (let attempt = 1; attempt <= 3; attempt++) {
      await this.ui.listMaintenanceButton.click();
      try {
        await this.page.waitForURL(/\/package-dashboard\/distribution-list/, { timeout: 8000 });
        break;
      } catch (error) {
        if (attempt === 3) throw error;
        await this.page.waitForTimeout(1000);
      }
    }
  }

  async searchInsPlanAndClickGroupAndSchedulePackage(regionalPlanData, plan, groupId='') {
    await this.page.waitForTimeout(5000);
    if(! this.page.url().includes('/insurance/packaging') ) {
      await this.page.goto('https://hw-carbon.stage.walmart.com/insurance/packaging');
    } 
    await this.page.waitForLoadState('networkidle');
    let planSetupIpName;
    if(groupId) 
      planSetupIpName = 'INSURANCE PLAN GROUP# : ' + groupId;
    else
      planSetupIpName = 'NEW_PLAN_SETUP_' + regionalPlanData.CARRIER + '/' + plan;
    await this.ui.searchByNameInput.fill(planSetupIpName);
    await this.ui.selectTheSearchResult(planSetupIpName).click();
    await this.ui.groupAndSchedulePackageButton.click();
  }

  async checkIfItIsGoingForDLorEnrolledStore() {
    try {
      await expect(this.ui.packageDistributionPopUp).toBeVisible({ timeout: 3000 });
      return true;
    } catch {
      return false;
    }
  }

  async packageViaDistributionList(distributionListName) {
    await expect(this.ui.schedulePackageHeading).toBeVisible({ timeout: 3000 });
    await this.ui.distributionListInput.click();
    await this.ui.distributionListInput.fill(distributionListName);
    await this.ui.selectDLFromDropdown(distributionListName).click();
    await this.ui.addDLButton.click();
    await this.ui.scheduleButton.click();
    await expect(this.ui.packageDashboardHeading).toBeVisible({ timeout: 3000 });
  }

  async packageViaEnrolledStore(enrolledStoreIds) {
    await expect(this.ui.schedulePackageHeading).toBeVisible({ timeout: 3000 });
    await expect(this.ui.storeSelectionHeading).toBeVisible();

    for (const storeId of enrolledStoreIds) {
      await this.ui.storeRowCheckbox(storeId).click();
    }
    await this.ui.schedulePackageNextButton.click();
    await expect(this.ui.schedulePackageHeading).toBeVisible({ timeout: 3000 });
    await this.ui.scheduleButton.click();
    await expect(this.ui.packageDashboardHeading).toBeVisible({ timeout: 3000 });
  }

  async selectPackageByStorePrefix(packageName, shouldMatch = true, prefix = 'INS') {
    await this.ui.searchByPackageNameInPackageDashboard.fill(packageName);
    
    // Wait for the table to update after search
    await this.page.waitForTimeout(2000);
    
    // Wait for at least one row to be present (or empty state)
    await this.page.waitForLoadState('networkidle');
    
    const headers = await this.page.locator('table thead th').allTextContents();
    const storeColIdx = headers.findIndex(h => h.includes('# Store'));
    
    const rows = await this.page.locator('table tbody tr');
    const count = await rows.count();
    
    for (let i = 0; i < count; i++) {
      const row = rows.nth(i);
      const storeCell = row.locator('td').nth(storeColIdx);
      const storeValue = await storeCell.textContent();
      
      const matches = storeValue.trim().startsWith(prefix);
      
      // If shouldMatch=true, look for INS. If false, look for non-INS
      if (matches === shouldMatch) {
        // Find the clickable package name link - it's the first nested div inside the first cell
        const packageNameCell = row.locator('td').first();
        const packageNameText = await packageNameCell.textContent();
        
        // Click the package name to open the Package Details dialog
        await packageNameCell.locator('div').first().click();
        
        // Wait for the Package Details dialog to appear
        await expect(this.page.getByRole('dialog', { name: 'Package Details' })).toBeVisible({ timeout: 5000 });
        
        return packageNameText.split('\n')[0].trim(); // Return first line which is the actual package name
      }
    }
    
    throw new Error(`No package found with # Store ${shouldMatch ? '' : 'NOT '}starting with "${prefix}"`);
  }
  
  async clickRedistributePackageButton() {
    await this.ui.redistributeButton.click();
  }

  async selectAllStoresForRegionalPlanPackage() {
    await this.ui.selectAllEnrolledStoresForRegionalPlan.click();
    await this.ui.schedulePackageNextButton.click();
    await this.ui.redistributePackageButton.click();
  }

  async redistributePackageViaDistributionList(distributionListName) {
    expect(this.ui.redistributePackageHeading).toBeVisible({ timeout: 3000 });
    await this.ui.distributionListInput.click();
    await this.ui.distributionListInput.fill(distributionListName);
    await this.ui.selectDLFromDropdown(distributionListName).click();
    await this.ui.addDLButton.click();
    await this.ui.redistributeButton.click();
  }

  /**
   * Click Log Out and wait for navigation (back to auth or home).
   */
  async logout() {
    try {
      await expect(this.ui.logOutButton).toBeVisible({ timeout: 5000 });
      await this.ui.logOutButton.click();
    } catch {
      await expect(this.ui.logOutLink).toBeVisible({ timeout: 5000 });
      await this.ui.logOutLink.click();
    }
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(1000);
  }

  /**
   * Click Log Out and wait for navigation (back to auth or home).
   */
  async logout() {
    try {
      await expect(this.ui.logOutButton).toBeVisible({ timeout: 5000 });
      await this.ui.logOutButton.click();
    } catch {
      await expect(this.ui.logOutLink).toBeVisible({ timeout: 5000 });
      await this.ui.logOutLink.click();
    }
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(1000);
  }
}

module.exports = { PackagingDashboardPage };


