const { expect } = require("@playwright/test");

function processorPageLocators(page) {
    return {
        processorsHeading: page.getByRole("heading", { name: "Processors" }),
        addNewProcessorHeading: page.getByRole("heading", { name: "Add New Processor" }),
        processorsNavItem: page.getByText("Processors", { exact: true }).first(),
        newProcessorButton: page.getByRole("button", { name: "New Processor" }),
        processorNameInput: page.getByRole("textbox", { name: "Processor Name" }),
        softwareVendorCertificationIdInput: page.getByRole("textbox", { name: "Software Vendor Certification ID" }),
        saveButton: page.getByRole("button", { name: "Save" }),
        finalizeButton: page.getByRole("button", { name: "Finalize" }),
        workOrderSuccessToast: page.getByText(/work order created successfully/i),
    };
}

class ProcessorPage {
    constructor(page) {
        this.page = page;
        this.ui = processorPageLocators(page);
    }

    async openProcessorsModule() {
        await this.ui.processorsNavItem.click();
        await expect(this.ui.processorsHeading).toBeVisible();
    }

    async clickNewProcessor() {
        await this.ui.newProcessorButton.click();
        await expect(this.ui.addNewProcessorHeading).toBeVisible();
    }

    async fillProcessorBasicInformation(processorName, softwareVendorCertificationId) {
        await this.ui.processorNameInput.fill(processorName);
        await this.ui.softwareVendorCertificationIdInput.fill(softwareVendorCertificationId);
    }

    async saveAndVerifyWorkOrderSuccessToast() {
        await this.ui.saveButton.click();
        await expect(this.ui.workOrderSuccessToast).toBeVisible({ timeout: 10000 });
    }

    async finalizeProcessor() {
        await this.ui.finalizeButton.click();
    }
}

module.exports = { ProcessorPage };
