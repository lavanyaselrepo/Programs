/**
 * Retry a locator click with optional post-click validation.
 *
 * @param {object} options
 * @param {import('@playwright/test').Locator} options.locator
 * @param {number} [options.attempts=3]
 * @param {number} [options.delayMs=500]
 * @param {string} [options.label='Click']
 * @param {() => Promise<void>} [options.afterClick]
 */
async function clickWithRetry({
  locator,
  attempts = 3,
  delayMs = 500,
  label = 'Click',
  afterClick,
}) {
  let lastError;

  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await locator.click();
      if (afterClick) {
        await afterClick();
      }
      return;
    } catch (error) {
      lastError = error;
      if (attempt === attempts) {
        throw error;
      }
      console.log(`${label} attempt ${attempt} failed, retrying...`);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  throw lastError;
}

module.exports = { clickWithRetry };
