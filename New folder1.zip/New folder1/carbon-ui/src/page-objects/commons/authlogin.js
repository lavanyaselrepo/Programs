const { expect } = require('@playwright/test');

class authlogin {
  /**
   * Navigate to a target URL and perform login if the app routes to an auth page.
   * 
   * @param {import('@playwright/test').Page} page
   * @param {string} targetUrl - The Carbon-UI target URL for the module/area
   * @param {string} authUrlPattern - Pattern to detect auth page (e.g., '/as/authorization')
   * @param {Function} getUsername - Function that returns username
   * @param {Function} getPassword - Function that returns password
   * @param {import('@playwright/test').Locator | null} postLoginLocator - Optional locator for post-login verification
   */
  static async navigateAndEnsureAuth(page, targetUrl, authUrlPattern, userName, password, postLoginLocator = null) {
    await page.goto(targetUrl);
    await page.waitForLoadState('load');

    try{
      await page.waitForTimeout(10000);
      await page.waitForLoadState('networkidle');
      const currentUrl = page.url();
      console.log('🔐 Current URL:', currentUrl);
      if (currentUrl.includes(authUrlPattern)) {
        await page.getByRole('textbox', { name: /User ID/ }).fill(userName);
        await page.getByRole('textbox', { name: 'Password' }).fill(password);
        await page.keyboard.press('Enter');
        await page.waitForLoadState('load');
      }
      if (postLoginLocator) {
        await expect(postLoginLocator).toBeVisible({ timeout: 10000 });
      }
    }catch(error){
      console.error('Error:', error);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
      console.error('Error name:', error.name);
      console.error('Error code:', error.code);
      console.error('Error signal:', error.signal);
      console.error('Error cause:', error.cause);
      console.error('Error message:', error.message);
    }
  }
}

module.exports = { authlogin };