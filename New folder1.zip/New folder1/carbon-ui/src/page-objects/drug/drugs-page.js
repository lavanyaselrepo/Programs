const { expect } = require('@playwright/test');
const { authlogin } = require('../../../src/page-objects/commons/authlogin');
const { credentials } = require('../../utilities/credentials');

function drugsPageLocators(page) {
    return {
        drugsHeading: page.getByRole('heading', { name: 'Drugs' }),
        addNewProductButton: page.getByRole('button', { name: 'Add New Product' }),
    }
}

class DrugsPage {
    constructor(page, config) {
        this.page = page;
        this.config = config;
        this.ui = drugsPageLocators(page);
    }

    async openDrugAndLoginIfNeeded(userType) {
        console.log('🔐 Opening Drug module and logging in if needed');
        console.log('🔐 Username:', credentials.carbonDrug.username(userType));
        await authlogin.navigateAndEnsureAuth(
            this.page,
            this.config.carbonDrug.url,
            this.config.carbonDrug.authUrlPattern,
            credentials.carbonDrug.username(userType),
            credentials.carbonDrug.password(userType),
            this.ui.drugsHeading
        );
    }
}

module.exports = { DrugsPage };
