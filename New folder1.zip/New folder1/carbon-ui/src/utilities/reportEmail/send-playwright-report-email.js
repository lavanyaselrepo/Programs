const fs = require("fs");
const path = require("path");
const nodemailer = require("nodemailer");
require("dotenv").config();

const FROM_ADDRESS = "DragonFramework@email.wal-mart.com";
const FROM_NAME = "Dragon Framework";
const SMTP_HOST = "smtp-gw1.wal-mart.com";

function parseBoolean(value) {
  return String(value || "")
    .trim()
    .toLowerCase() === "true";
}

function readJsonIfExists(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    console.warn(`Failed to parse JSON file ${filePath}: ${error.message}`);
    return fallback;
  }
}

function readTextIfExists(filePath) {
  try {
    if (!fs.existsSync(filePath)) return "";
    return fs.readFileSync(filePath, "utf8").trim();
  } catch (error) {
    console.warn(`Failed to read file ${filePath}: ${error.message}`);
    return "";
  }
}

function readReportLinks(filePath) {
  try {
    if (!fs.existsSync(filePath)) return [];
    return fs
      .readFileSync(filePath, "utf8")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .map((line) => {
        const idx = line.indexOf("|");
        if (idx === -1) return null;
        return {
          suite: line.slice(0, idx).trim(),
          url: line.slice(idx + 1).trim(),
        };
      })
      .filter((x) => x && x.url);
  } catch (error) {
    console.warn(`Failed to read report links: ${error.message}`);
    return [];
  }
}

function recipientsFromEnv() {
  const raw =
    process.env.EMAIL_REPORT_TO ||
    process.env.emailReportTo ||
    process.env.EMAIL_REPORT_RECIPIENTS ||
    "";
  return raw
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);
}

function buildSubject(environment, suiteName, passed, failed, skipped, flaky) {
  if (failed === 0 && skipped === 0 && flaky === 0) {
    return `[${environment}]- Carbon UI Regression Test Execution Results (PASSED).`;
  }
  return `[${environment}]- Carbon UI Regression Test Execution Results (${passed} PASS, ${failed} FAILURES, ${skipped} SKIPPED, ${flaky} FLAKY).`;
}

function buildBody({
  suiteName,
  environment,
  reportUrl,
  reportLinks,
  passed,
  failed,
  skipped,
  flaky,
  executed,
  suiteSummaries,
}) {
  const total = Number(executed || 0) || Number(passed) + Number(failed) + Number(skipped) + Number(flaky);
  const passPct = total > 0 ? Math.round((Number(passed) / total) * 100) : 0;
  const safeReportUrl = reportUrl || "N/A";
  const links =
    Array.isArray(reportLinks) && reportLinks.length > 0
      ? reportLinks
      : [{ suite: suiteName, url: safeReportUrl }];
  const linksHtml = links
    .map((l) => `<li>${l.suite || "Suite"}: <a href="${l.url}">${l.url}</a></li>`)
    .join("");
  const suiteRows = Array.isArray(suiteSummaries)
    ? suiteSummaries
        .map(
          (s) => `
        <tr>
          <td>${s.name || "Unknown Suite"}</td>
          <td style="text-align:center">${Number(s.executed || 0)}</td>
          <td style="text-align:center">${Number(s.passed || 0)}</td>
          <td style="text-align:center">${Number(s.failed || 0)}</td>
          <td style="text-align:center">${Number(s.flaky || 0)}</td>
          <td style="text-align:center">${Number(s.skipped || 0)}</td>
        </tr>`
        )
        .join("")
    : "";

  return `
    <div style="font-family: Arial, sans-serif; font-size: 14px; color: #111;">
      <p>Environment: ${environment}</p>
      <p><b>Overall:</b> Executed ${total}, Passed ${passed}, Failed ${failed}, Flaky ${flaky}, Skipped ${skipped}, Pass % ${passPct}</p>
      <p><b>Report Link(s):</b></p>
      <ul>${linksHtml}</ul>
      <br />
      ${
        suiteRows
          ? `
      <p>Suite-wise execution summary:</p>
      <table width="100%" cellpadding="6" border="1" style="border-collapse: collapse; border: 1px solid black;">
        <tr>
          <th style="background-color:#d3d3d3">Suite</th>
          <th style="background-color:#d3d3d3">Executed</th>
          <th style="background-color:#15d643">Passed</th>
          <th style="background-color:#fa0505">Failed</th>
          <th style="background-color:#f7b733">Flaky</th>
          <th style="background-color:#faa316">Skipped</th>
        </tr>
        ${suiteRows}
      </table>
      <br />
      `
          : ""
      }
      <i>
        This is an auto generated email. Please do not reply to this email.
        For any questions reach us on slack channel
        <a href="https://walmart.slack.com/app_redirect?channel=hw_qe_automation">#hw_qe_automation</a>
      </i>
    </div>
  `;
}

function buildTransporters() {
  return [
    nodemailer.createTransport({
      host: SMTP_HOST,
      port: 25,
      secure: false,
      proxy: "http://proxy.wal-mart.com:9080",
      tls: { rejectUnauthorized: false },
    }),
    nodemailer.createTransport({
      host: SMTP_HOST,
      port: 25,
      secure: false,
      proxy: "http://sysproxy.wal-mart.com:8080",
      tls: { rejectUnauthorized: false },
    }),
  ];
}

async function send() {
  const shouldSend = parseBoolean(
    process.env.SEND_REPORT_EMAIL || process.env.sendReportEmail || "false"
  );

  if (!shouldSend) {
    console.log("SEND_REPORT_EMAIL is false. Skipping email.");
    return;
  }

  const recipients = recipientsFromEnv();
  if (!recipients.length) {
    console.log("EMAIL_REPORT_TO is empty. Skipping email.");
    return;
  }

  const cwd = process.cwd();
  const resultsPath = path.join(cwd, "test-results", "results.json");
  const reportUrlPath = path.join(cwd, "test-results", "report-url.txt");
  const reportUrlsPath = path.join(cwd, "test-results", "report-urls.txt");

  const results = readJsonIfExists(resultsPath, {
    totalPassed: 0,
    totalFailed: 0,
    totalSkipped: 0,
    totalFlaky: 0,
    totalExecuted: 0,
    suiteSummaries: [],
  });
  const reportUrl = readTextIfExists(reportUrlPath);
  const reportLinks = readReportLinks(reportUrlsPath);

  const suiteName = process.env.SUITE_NAME || process.env.JOB_NAME || "Playwright Tests";
  const environment = process.env.TEST_ENV || process.env.ENV || "unknown";
  const passed = Number(results.totalPassed || 0);
  const failed = Number(results.totalFailed || 0);
  const skipped = Number(results.totalSkipped || 0);
  const flaky = Number(results.totalFlaky || 0);
  const executed = Number(results.totalExecuted || 0);
  const suiteSummaries = Array.isArray(results.suiteSummaries) ? results.suiteSummaries : [];

  const mail = {
    from: `"${FROM_NAME}" <${FROM_ADDRESS}>`,
    to: recipients.join(","),
    subject: buildSubject(environment, suiteName, passed, failed, skipped, flaky),
    html: buildBody({
      suiteName,
      environment,
      reportUrl,
      reportLinks,
      passed,
      failed,
      skipped,
      flaky,
      executed,
      suiteSummaries,
    }),
  };

  const transporters = buildTransporters();
  let lastError = null;
  for (const transporter of transporters) {
    try {
      await transporter.sendMail(mail);
      console.log(`Report email sent to: ${recipients.join(", ")}`);
      return;
    } catch (error) {
      lastError = error;
      console.warn(`Email send attempt failed: ${error.message}`);
    }
  }

  throw new Error(
    `Failed to send report email using all configured SMTP routes: ${
      lastError ? lastError.message : "unknown error"
    }`
  );
}

send().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
