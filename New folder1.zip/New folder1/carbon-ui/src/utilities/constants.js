/**
 * Constants - Application-wide constant values
 */

const VAULT_PATH = '/Prod/WCNP/homeoffice/wmt_hw_qe/ProjectDragon/';

module.exports = {
  VAULT_PATH,
};
