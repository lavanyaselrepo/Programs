/**
 * Simple logger utility
 */
function logger(message, type = "info") {
  const emoji = {
    start: "⏳ Start:",
    end: "✅ End:",
    failed: "❌ Failed:",
    info: "ℹ️ Info:",
  };

  const prefix = emoji[type] || emoji.info;
  console.log(`${prefix} ${message}`);
}

module.exports = { logger };
