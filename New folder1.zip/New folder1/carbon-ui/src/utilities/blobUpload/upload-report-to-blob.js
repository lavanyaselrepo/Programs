const fs = require("fs");
const path = require("path");
require("dotenv").config();
const { logger } = require("./logger");
const {
  uploadDirectoryToAzureBlob,
  uploadToAzureBlob,
} = require("./azure-blob");

/**
 * Uploads the Playwright report to Azure Blob Storage.
 * Prefers uploading the unzipped report folder so the Slack link opens the HTML report in the browser.
 * Falls back to uploading the zip if no folder is available.
 */
async function uploadReport() {
  try {
    const connectionString = process.env.AZURE_BLOB_CONNECTION_STRING;
    const containerName =
      process.env.AZURE_BLOB_CONTAINER_NAME || "hw-qe-storage";

    if (!connectionString) {
      logger(
        "AZURE_BLOB_CONNECTION_STRING environment variable is not set",
        "failed"
      );
      process.exit(1);
    }

    const cwd = process.cwd();
    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, "-")
      .split("T")[0];
    const suiteName = process.env.SUITE_NAME || "all-suites";
    const safeSuiteName = suiteName.replace(/[^a-zA-Z0-9-_]/g, "_");
    const runId = `${safeSuiteName}-${timestamp}-${Date.now()}`;
    const blobPrefix = `playwright-reports/${runId}`;

    // Prefer unzipped folder so the link opens the report in the browser (not a zip download)
    // Zip may be flat (index.html at root) or contain a root folder (e.g. playwright-report/index.html)
    const extractDir = path.join(cwd, "playwright-report-extract");
    const reportDir = findReportDir(cwd, extractDir);

    let url;

    if (reportDir) {
      logger(
        `Uploading report folder (so link opens in browser): ${reportDir}`,
        "start"
      );
      url = await uploadDirectoryToAzureBlob(
        reportDir,
        blobPrefix,
        connectionString,
        containerName
      );
      logger("✅ Playwright report (HTML) uploaded successfully", "end");
    } else {
      const zipFilePath = path.join(cwd, "playwright-report.zip");
      if (!fs.existsSync(zipFilePath)) {
        logger(`Playwright report zip not found: ${zipFilePath}`, "failed");
        process.exit(1);
      }
      const blobName = `${blobPrefix}.zip`;
      logger(
        `Uploading zip (link will download file): ${zipFilePath}`,
        "start"
      );
      url = await uploadToAzureBlob(
        zipFilePath,
        blobName,
        connectionString,
        containerName,
        true
      );
      logger("✅ Playwright report (zip) uploaded successfully", "end");
    }

    logger(`Report URL: ${url}`, "end");

    const urlFilePath = path.join(cwd, "test-results", "report-url.txt");
    fs.mkdirSync(path.dirname(urlFilePath), { recursive: true });
    fs.writeFileSync(urlFilePath, url);

    console.log(JSON.stringify({ reportUrl: url }));
  } catch (error) {
    logger(`Error uploading report: ${error.message}`, "failed");
    console.error(error);
    process.exit(1);
  }
}

/**
 * Finds directory containing index.html (handles zip with or without root folder).
 */
function findReportDir(cwd, extractDir) {
  if (!fs.existsSync(extractDir) || !fs.statSync(extractDir).isDirectory()) {
    return null;
  }
  const indexAtRoot = path.join(extractDir, "index.html");
  if (fs.existsSync(indexAtRoot)) {
    return extractDir;
  }
  // Zip from Sauce may contain a single root folder (e.g. playwright-report/)
  const entries = fs.readdirSync(extractDir, { withFileTypes: true });
  for (const e of entries) {
    if (e.isDirectory()) {
      const candidate = path.join(extractDir, e.name);
      if (fs.existsSync(path.join(candidate, "index.html"))) {
        return candidate;
      }
    }
  }
  if (
    fs.existsSync(path.join(cwd, "playwright-report")) &&
    fs.existsSync(path.join(cwd, "playwright-report", "index.html"))
  ) {
    return path.join(cwd, "playwright-report");
  }
  return null;
}

uploadReport();
