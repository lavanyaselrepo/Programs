const fs = require("fs");
const path = require("path");
const {
  BlobSASPermissions,
  BlobServiceClient,
  StorageSharedKeyCredential,
  generateBlobSASQueryParameters,
} = require("@azure/storage-blob");
const { logger } = require("./logger");

/**
 * Gets content type based on file extension
 */
function getContentType(ext) {
  const contentTypes = {
    html: "text/html",
    htm: "text/html",
    txt: "text/plain",
    json: "application/json",
    zip: "application/zip",
    pdf: "application/pdf",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    gif: "image/gif",
  };
  return contentTypes[ext] || "application/octet-stream";
}

/**
 * Extracts account name from Azure Storage connection string
 */
function extractAccountName(connectionString) {
  const match = connectionString.match(/AccountName=([^;]+)/);
  return match ? match[1] : null;
}

/**
 * Extracts account key from Azure Storage connection string
 */
function extractAccountKey(connectionString) {
  const match = connectionString.match(/AccountKey=([^;]+)/);
  return match ? match[1] : null;
}

/**
 * Uploads a file to Azure Blob Storage and returns a URL with SAS token
 */
async function uploadToAzureBlob(
  filePath,
  blobName,
  connectionString,
  containerName,
  overwrite = true
) {
  try {
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }

    const blobServiceClient =
      BlobServiceClient.fromConnectionString(connectionString);
    const containerClient = blobServiceClient.getContainerClient(containerName);

    // Ensure container exists
    await containerClient.createIfNotExists();

    const blobClient = containerClient.getBlockBlobClient(blobName);

    // Delete existing blob if overwrite is requested
    if (overwrite) {
      try {
        await blobClient.deleteIfExists();
      } catch (error) {
        // Ignore if blob doesn't exist
      }
    }

    // Determine content type based on file extension
    const ext = path.extname(filePath).toLowerCase().substring(1);
    const contentType = getContentType(ext);

    // Upload the file
    const fileContent = fs.readFileSync(filePath);
    await blobClient.upload(fileContent, fileContent.length, {
      blobHTTPHeaders: {
        blobContentType: contentType,
      },
    });

    logger(`File uploaded to blob: ${blobName}`, "end");

    // Generate SAS token for read access (valid for 6 months)
    const accountName = extractAccountName(connectionString);
    const accountKey = extractAccountKey(connectionString);

    if (!accountName || !accountKey) {
      // If we can't extract credentials, return URL without SAS
      return blobClient.url;
    }

    const sharedKeyCredential = new StorageSharedKeyCredential(
      accountName,
      accountKey
    );
    const sasToken = generateBlobSASQueryParameters(
      {
        containerName,
        blobName,
        permissions: BlobSASPermissions.parse("r"), // Read permission
        expiresOn: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000), // 6 months
      },
      sharedKeyCredential
    ).toString();

    const url = `${blobClient.url}?${sasToken}`;
    logger(`Blob URL with SAS: ${url}`, "end");
    return url;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logger(`Failed to upload to Azure Blob: ${errorMessage}`, "failed");
    throw error;
  }
}

/**
 * Uploads a directory to Azure Blob Storage under a prefix and returns the index.html URL with SAS.
 */
async function uploadDirectoryToAzureBlob(
  dirPath,
  blobPrefix,
  connectionString,
  containerName
) {
  if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
    throw new Error(`Directory not found: ${dirPath}`);
  }

  const blobServiceClient =
    BlobServiceClient.fromConnectionString(connectionString);
  const containerClient = blobServiceClient.getContainerClient(containerName);
  await containerClient.createIfNotExists();

  const prefix = `${blobPrefix.replace(/\/$/, "")}/`;
  const files = walkDir(dirPath, dirPath);

  for (const filePath of files) {
    const relative = path.relative(dirPath, filePath).split(path.sep).join("/");
    const blobName = prefix + relative;
    const ext = path.extname(filePath).toLowerCase().substring(1);
    const contentType = getContentType(ext);
    const content = fs.readFileSync(filePath);
    const blobClient = containerClient.getBlockBlobClient(blobName);
    await blobClient.upload(content, content.length, {
      blobHTTPHeaders: { blobContentType: contentType },
    });
    logger(`Uploaded: ${blobName}`, "end");
  }

  const indexBlobName = `${prefix}index.html`;
  const accountName = extractAccountName(connectionString);
  const accountKey = extractAccountKey(connectionString);
  if (!accountName || !accountKey) {
    return `${containerClient.getBlockBlobClient(indexBlobName).url}`;
  }

  const sharedKeyCredential = new StorageSharedKeyCredential(
    accountName,
    accountKey
  );
  const sasToken = generateBlobSASQueryParameters(
    {
      containerName,
      blobName: indexBlobName,
      permissions: BlobSASPermissions.parse("r"),
      expiresOn: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000),
    },
    sharedKeyCredential
  ).toString();

  const blobClient = containerClient.getBlockBlobClient(indexBlobName);
  return `${blobClient.url}?${sasToken}`;
}

/**
 * Recursively walks a directory and returns all file paths
 */
function walkDir(dir, root, list = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      walkDir(full, root, list);
    } else {
      list.push(full);
    }
  }
  return list;
}

module.exports = {
  uploadToAzureBlob,
  uploadDirectoryToAzureBlob,
};
