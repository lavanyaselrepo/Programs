/**
 * Credentials - Simple helper to access secrets loaded by PropertyReader
 * 
 * Usage:
 *   const { credentials } = require('./utilities/credentials.js');
 *   const username = credentials.carbonInsurance.username();
 *   const password = credentials.carbonInsurance.password();
 */

const fs = require('fs');
const path = require('path');

/**
 * Cache for loaded secrets - loaded once from JSON file then deleted
 */
let secretsCache = null;

/**
 * Load secrets from temporary JSON file created by PropertyReader
 * File will be deleted by globalTeardown after all tests complete
 */
function loadSecretsFromCache() {
  if (secretsCache) {
    return secretsCache; // Already loaded
  }

  const cacheFile = path.join(__dirname, 'akeyless-cache.json');
  
  if (!fs.existsSync(cacheFile)) {
    console.warn('⚠️ Akeyless cache file not found. Secrets may not be loaded.');
    return {};
  }

  try {
    // Read the secrets (file will be deleted by globalTeardown)
    const fileContent = fs.readFileSync(cacheFile, 'utf-8');
    secretsCache = JSON.parse(fileContent);
    
    return secretsCache;
  } catch (error) {
    console.error('❌ Failed to load secrets from cache:', error.message);
    return {};
  }
}

/**
 * Get any credential by key from the cache
 * @param {string} key - The Akeyless key (e.g., 'app.carbon.insurance.username')
 * @param {string} defaultValue - Default value if not found
 */
function getCredential(key, defaultValue = '') {
  const secrets = loadSecretsFromCache();
  return secrets[key] || defaultValue;
}

const credentials = {
  carbonInsurance: {
    username: (userType) => getCredential(`app.carbon.serviceuser.username.${userType}`, 'fallback-username'),
    password: (userType) => getCredential(`app.carbon.serviceuser.password.${userType}`, 'fallback-secret'),
  },
  
  carbonDrug: {
    username: (userType) => getCredential(`app.carbon.serviceuser.username.${userType}`, 'fallback-username'),
    password: (userType) => getCredential(`app.carbon.serviceuser.password.${userType}`, 'fallback-secret'),
  },
  
  sauceLabs: {
    username: () => getCredential('app.saucelabs.username', ''),
    accessKey: () => getCredential('app.saucelabs.accesskey', ''),
  }
};

module.exports = { credentials, getCredential };
