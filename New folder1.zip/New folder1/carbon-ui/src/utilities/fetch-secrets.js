#!/usr/bin/env node

/**
 * Fetch secrets from Akeyless and create cache file
 * This runs BEFORE saucectl in CI/Looper environment
 * 
 * Usage:
 *   node src/utilities/fetch-secrets.js
 * 
 * Environment variables required:
 *   - AKEYLESS_URL
 *   - AKEYLESS_CONNECTION_STRING
 *   - TEST_ENV (optional, defaults to 'dev')
 */

const path = require('path');
const fs = require('fs');

// Load environment variables from .env file if it exists
const envPath = path.resolve(__dirname, '../../.env');
if (fs.existsSync(envPath)) {
  require('dotenv').config({ path: envPath });
  console.log('📄 Loaded environment variables from .env');
}

const PropertyReader = require('./propertyReader.js');

(async () => {
  console.log('🔐 Starting Akeyless secrets fetch...');
  console.log(`📍 Environment: ${process.env.TEST_ENV || 'dev'}`);
  
  try {
    const reader = new PropertyReader();
    await reader.ready;
    
    // Verify cache file was created
    const cacheFile = path.join(__dirname, 'akeyless-cache.json');
    if (fs.existsSync(cacheFile)) {
      const stats = fs.statSync(cacheFile);
      console.log('✅ Secrets cached successfully');
      console.log(`📦 Cache file: ${cacheFile}`);
      console.log(`📊 Cache size: ${stats.size} bytes`);
      
      // Read and display secret count (without showing values)
      const cache = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
      const secretCount = Object.keys(cache).length;
      console.log(`🔑 Loaded ${secretCount} secrets`);
      
      process.exit(0);
    } else {
      console.error('❌ Cache file was not created');
      console.error('This usually means Akeyless authentication failed or no secrets were found');
      process.exit(1);
    }
  } catch (error) {
    console.error('❌ Failed to fetch secrets:', error.message);
    if (error.stack) {
      console.error('Stack trace:', error.stack);
    }
    process.exit(1);
  }
})();
