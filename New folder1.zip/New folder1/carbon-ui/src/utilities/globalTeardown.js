const fs = require('fs');
const path = require('path');

/**
 * Global Teardown - Runs once after all tests complete
 * 
 * 1. Closes any remaining browser instances
 * 2. Deletes the Akeyless cache file for security
 */
async function globalTeardown(config) {
  console.log('\n🧹 Starting global teardown...\n');

  // Close all browser instances if any are still open
  // Playwright's test runner usually handles this, but we ensure cleanup
  try {
    if (global.browser) {
      await global.browser.close();
      console.log('✅ Global browser instance closed');
    }
    
    // Clean up any browser contexts that might be lingering
    if (global.context) {
      await global.context.close();
      console.log('✅ Global browser context closed');
    }

    // Clean up any pages that might be lingering
    if (global.page) {
      await global.page.close();
      console.log('✅ Global page instance closed');
    }
  } catch (error) {
    // Silently handle - browser might already be closed by Playwright
    console.log('ℹ️  Browser instances already cleaned up by Playwright');
  }

  // Delete Akeyless cache file for security
  const cacheFile = path.join(__dirname, 'akeyless-cache.json');
  
  if (fs.existsSync(cacheFile)) {
    try {
      fs.unlinkSync(cacheFile);
      console.log('🗑️  Akeyless cache file deleted');
    } catch (error) {
      console.error('❌ Failed to delete Akeyless cache file:', error.message);
    }
  } else {
    console.log('✅ Akeyless cache file already cleaned up');
  }

  console.log('\n✨ Global teardown completed\n');
}

module.exports = globalTeardown;
