const akeyless = require('akeyless');
const fs = require('fs');
const path = require('path');
const { VAULT_PATH } = require('./constants');
require('dotenv').config();

/**
 * PropertyReader - Loads configuration and secrets from Akeyless vault
 * 
 * Simplified implementation that writes secrets to a temporary JSON file
 * 
 * The JSON file is automatically deleted after credentials.js reads it.
 */
class PropertyReader {
  constructor() {
    this.ready = this.init();
  }

  /**
   * Initialize Akeyless vault and load secrets
   */
  async init() {
    try {
      // Read Akeyless URL and connection string from environment variables
      const url = process.env.AKEYLESS_URL;
      const connectionString = process.env.AKEYLESS_CONNECTION_STRING;

      if (!url || !connectionString) {
        console.warn('⚠️ Akeyless connection string is missing or empty.');
        return;
      }

      console.info('🔐 Attempting to initialize Akeyless vault with connection string');

      // Parse the connection string into a map
      const connectionMap = JSON.parse(connectionString);

      // -------- Akeyless Client Setup --------
      const client = new akeyless.ApiClient();
      client.basePath = url;
      client.rejectUnauthorized = false; // same as setVerifyingSsl(false)

      const api = new akeyless.V2Api(client);

      // -------- AUTH --------
      // Note: JavaScript SDK uses 'username' and 'ldap-password' (not 'ldap-username')
      const authBody = {
        'access-id': connectionMap.accessId,
        'access-type': connectionMap.accessType,
        'username': connectionMap.userId,
        'ldap-password': connectionMap.svcPass
      };

      // Authenticate and get token
      const authResult = await api.auth(authBody);
      const token = authResult.token;

      // -------- LIST ITEMS --------
      const listBody = akeyless.ListItems.constructFromObject({
        token,
        path: VAULT_PATH
      });

      const listOutput = await api.listItems(listBody);

      if (!listOutput.items || listOutput.items.length === 0) {
        throw new Error(`No secrets found under path ${VAULT_PATH}`);
      }

      // Collect secret names
      // Java: for (Item item : listOutput.getItems()) secretNames.add(item.getItemName())
      // Note: JavaScript SDK uses 'item_name' property (with underscore)
      const secretNames = listOutput.items.map(item => item.item_name || item.itemName);

      // -------- GET SECRET VALUES --------
      const getSecretBody = akeyless.GetSecretValue.constructFromObject({
        token,
        names: secretNames,
        prettyPrint: true
      });

      const resultMap = await api.getSecretValue(getSecretBody);

      // Build vaultKeyValues map with extracted key names
      const vaultKeyValues = {};
      for (const [path, value] of Object.entries(resultMap)) {
        const key = path.substring(path.lastIndexOf('/') + 1);
        vaultKeyValues[key] = value;
      }

      // Default to dev if env is undefined
      const env = process.env.TEST_ENV?.toLowerCase() || 'dev';
      
      const allSecrets = {};
      
      // 1. Import all entries in env_shared
      this.loadSecretsToObject(vaultKeyValues, 'env_shared', allSecrets);
      
      // 2. Overwrite any entries specific to dm_{env}
      this.loadSecretsToObject(vaultKeyValues, `dm_${env}`, allSecrets);
      
      // 3. Overwrite any entries specific to env_{env}_unique
      this.loadSecretsToObject(vaultKeyValues, `env_${env}_unique`, allSecrets);

      // Write secrets to temporary JSON file instead of process.env
      // This avoids E2BIG error when Playwright spawns worker processes
      const cacheFile = path.join(__dirname, 'akeyless-cache.json');
      fs.writeFileSync(cacheFile, JSON.stringify(allSecrets, null, 2));
      
      console.log('✅ Akeyless vault initialized from PROD Env');
      console.log(`📦 Loaded secrets for environment: ${env}`);
      console.log(`💾 Secrets cached to: ${cacheFile}`);
      
      return true;
      
    } catch (error) {
      console.error('❌ Failed to initialize Akeyless vault');
      console.error('Exception occurred:', error.message);
      console.error('Full error:', error);
      
      if (error.code && error.responseBody) {
        console.error(`API Error: ${error.code} - ${error.responseBody}`);
      }
      
      if (error.stack) {
        console.error('Stack trace:', error.stack);
      }
      
      return false;
    }
  }

  /**
   * Load secrets from vault into a target object
   * 
   * This is a modified version that loads into a plain object instead of process.env
   * to avoid E2BIG errors when Playwright spawns worker processes.
   * 
   * @param {Object} vaultKeyValues - Map of vault key names to their values
   * @param {string} matchKey - The key pattern to match (e.g., 'env_shared', 'dm_dev')
   * @param {Object} targetObject - The object to load secrets into
   */
  loadSecretsToObject(vaultKeyValues, matchKey, targetObject) {
    for (const [vaultKey, vaultValue] of Object.entries(vaultKeyValues)) {
      if (vaultKey.includes(matchKey)) {
        // vaultValue might be a JSON string, so parse it first
        let secretsMap = vaultValue;
        if (typeof vaultValue === 'string') {
          try {
            secretsMap = JSON.parse(vaultValue);
          } catch (e) {
            console.warn(`Failed to parse secrets for key ${vaultKey}:`, e.message);
            continue;
          }
        }
        
        if (typeof secretsMap === 'object' && secretsMap !== null) {
          for (const [configKey, configValue] of Object.entries(secretsMap)) {
            targetObject[configKey] = configValue;
          }
        }
      }
    }
  }

  /**
   * Load secrets from vault into process.env
   * 
   * DEPRECATED: This method is kept for backward compatibility but should not be used.
   * Use loadSecretsToObject() instead to avoid E2BIG errors.
   * 
   * @param {Object} vaultKeyValues - Map of vault key names to their values
   * @param {string} matchKey - The key pattern to match (e.g., 'env_shared', 'dm_dev')
   */
  loadSecretsFromVault(vaultKeyValues, matchKey) {
    for (const [vaultKey, vaultValue] of Object.entries(vaultKeyValues)) {
      if (vaultKey.includes(matchKey)) {
        // vaultValue might be a JSON string, so parse it first
        let secretsMap = vaultValue;
        if (typeof vaultValue === 'string') {
          try {
            secretsMap = JSON.parse(vaultValue);
          } catch (e) {
            console.warn(`Failed to parse secrets for key ${vaultKey}:`, e.message);
            continue;
          }
        }
        
        if (typeof secretsMap === 'object' && secretsMap !== null) {
          for (const [configKey, configValue] of Object.entries(secretsMap)) {
            process.env[configKey] = configValue;
          }
        }
      }
    }
  }

  /**
   * Compatibility method - mirrors Java's loadSecrets (old implementation)
   * Kept for backward compatibility
   */
  loadSecrets(resultMap, matchKey) {
    Object.entries(resultMap).forEach(([path, value]) => {
      const keyName = path.substring(path.lastIndexOf('/') + 1);

      if (keyName.includes(matchKey)) {
        Object.entries(value).forEach(([k, v]) => {
          process.env[k] = v;
        });
      }
    });
  }
}

module.exports = PropertyReader;