const path = require('path');
const fs = require('fs');

/**
 * Global Setup - Runs once before all tests
 * 
 * Two modes:
 * 1. CI Mode: Cache file pre-fetched by scripts/fetch-secrets.js (in Looper)
 * 2. Local Mode: Fetch secrets from Akeyless on-demand
 */
module.exports = async () => {
  const cacheFile = path.join(__dirname, 'akeyless-cache.json');
  
  // Check if cache already exists (pre-fetched in CI)
  if (fs.existsSync(cacheFile)) {
    console.log('📦 Using pre-fetched secrets cache (CI mode)');
    console.log('✅ Skipping Akeyless fetch - cache already available');
    return; // Skip Akeyless fetch
  }
  
  // Cache doesn't exist - fetch from Akeyless (local mode)
  console.log('🔐 Fetching secrets from Akeyless (local mode)...');
  
  // Try to load .env file if it exists
  const envPath = path.resolve(__dirname, '../../.env');
  if (fs.existsSync(envPath)) {
    require('dotenv').config({ path: envPath });
    console.log('📄 Loaded environment variables from .env');
  } else {
    console.log('☁️ No .env file found - using system environment variables');
  }
  
  const PropertyReader = require('./propertyReader.js');
  const props = new PropertyReader();
  await props.ready;
};