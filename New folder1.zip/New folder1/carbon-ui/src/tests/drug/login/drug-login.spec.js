const { getConfig } = require("../../../../config");
const { test, expect } = require("@playwright/test");
const { DrugsPage } = require("../../../page-objects/drug/drugs-page");

const config = getConfig();

test.describe("Drug Module - Access Control", () => {
    test("Verify Drug Module Admin can access Drugs page", async ({ page }) => {
        const drugsPage = new DrugsPage(page, config);
        
        // 1-3. Retrieve admin credentials and login to carbon UI
        await drugsPage.openDrugAndLoginIfNeeded("admin");
        
        // 4-5. Verify landing on Drugs page with heading visible
        await expect(drugsPage.ui.drugsHeading).toBeVisible();
        
        // 6. Verify "Add New Product" button is enabled
        await expect(drugsPage.ui.addNewProductButton).toBeEnabled();
    });
});
