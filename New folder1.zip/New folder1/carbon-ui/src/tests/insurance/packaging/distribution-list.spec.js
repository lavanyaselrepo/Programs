const { test, expect } = require('@playwright/test');
const { getConfig } = require('../../../../config');
const { PackagingDashboardPage } = require('../../../page-objects/insurance/packaging-dashboard-page');
const { DistributionListPage } = require('../../../page-objects/insurance/distribution-list-page');
const { PackagingData, buildAutoListName } = require('../../../test-data/insurance/packaging/packaging.data');
const { authlogin } = require('../../../page-objects/commons/authlogin');
const { credentials } = require('../../../utilities/credentials');

const config = getConfig();

async function login(page, config, userType = 'admin') {
  const dashboard = new PackagingDashboardPage(page, config);
  await dashboard.openInsuranceAndLoginIfNeeded(userType);
}

/**
 * Log in and navigate to the Distribution List page.
 * Returns { dashboard, dl } for use in test steps.
 */
async function loginAndGoToDistributionList(page, config, userType = 'admin') {
  await login(page, config, userType);
  const dashboard = new PackagingDashboardPage(page, config);
  const dl = new DistributionListPage(page);
  await dashboard.openPackagingArea();
  await dashboard.goToPackageDashboard();
  await dashboard.goToDistributionList();
  await dl.verifyOnDistributionListPage();
  return { dashboard, dl };
}

test.describe('Insurance › Packaging › Distribution List', () => {

  test('HWCENTSAF-28919 - GET All Distribution List for Admin User UI', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    await expect(dl.ui.heading).toBeVisible({ timeout: 20000 });
    await expect(dl.ui.tableRows.first()).toBeVisible({ timeout: 15000 });

    const firstRow = await dl.getFirstRowData();
    console.log(`📋 First Distribution List Name: ${firstRow.name}`);
    console.log(`📋 First Distribution List Store Count: ${firstRow.storeCount}`);
    console.log(`📋 First Distribution List Created By: ${firstRow.createdBy}`);

    await page.screenshot({ path: 'test-results/distribution-list-verification.png', fullPage: true });
  });

  test('HWCENTSAF-28920 - GET All Distribution List for Read User', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'read');
    await expect(dl.ui.heading).toBeVisible({ timeout: 20000 });
    await expect(dl.ui.tableRows.first()).toBeVisible({ timeout: 15000 });

    const row = dl.ui.tableRows.first();
    await expect(row).toBeVisible({ timeout: 10000 });
    const cells = dl.ui.rowCells(row);
    const name = await cells.nth(0).innerText();
    const storeCount = await cells.nth(1).innerText();
    const createdBy = await cells.nth(2).innerText();
  
    console.log(`📋 First Distribution List Name (Read User): ${name}`);
    console.log(`📋 First Distribution List Store Count: ${storeCount}`);
    console.log(`📋 First Distribution List Created By: ${createdBy}`);

    await page.screenshot({ path: 'test-results/distribution-list-read-user-verification.png', fullPage: true });
  });

  test('HWCENTSAF-28921 - Non-Insurance Module user must NOT access DL', async ({ page }) => {
    await authlogin.navigateAndEnsureAuth(
      page,
      config.carbonInsurance.url,
      config.carbonInsurance.authUrlPattern,
      credentials.carbonInsurance.username('nonInsurance'),
      credentials.carbonInsurance.password('nonInsurance'),
      null
    );
    await page.waitForLoadState('networkidle');

    await expect(page.getByRole('button', { name: 'Create New Plan' })).toBeDisabled({ timeout: 5000 });

    await page.screenshot({ path: 'test-results/non_insurance_unauthorized_dl.png', fullPage: true });
  });

  test('HWCENTSAF-28911,HWCENTSAF-28915, HWCENTSAF-28937 - Create Distribution List And Verify Store Nums', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(4);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK });

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const values = await dl.readRowValues(row);
    console.log(`📌 Created List Name (from table): ${values.name}`);
    console.log(`📌 Store Count (from table): ${values.storeCount}`);
    console.log(`📌 Created By (from table): ${values.createdBy}`);

    await page.screenshot({ path: `test-results/distribution-list-created-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('Search Distribution List by List Name - Web flow', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const targetName = PackagingData.SEARCH_SAMPLE_NAME;
    await dl.searchByListName(targetName);
    await dl.waitForAnyRow();

    const first = await dl.getFirstRowData();
    console.log(`📋 List Name: ${first.name}`);
    console.log(`📋 Store Count: ${first.storeCount}`);
    console.log(`📋 Created By: ${first.createdBy}`);

    await expect(async () => {
      const normalized = first.name.replace(/\s+/g, ' ').trim();
      expect(normalized).toContain(targetName);
    }).toPass();

    await page.screenshot({ path: 'test-results/distribution-list-search-by-name.png', fullPage: true });
  });

  test('HWCENTSAF-28912 - Create and Edit Distribution List - Web flow', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(5);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK });
    console.log(`✅ Distribution List created (skipping toast): ${createdName}`);

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const before = await dl.readRowValues(row);
    const beforeCount = parseInt((before.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count BEFORE edit for ${createdName}: ${beforeCount}`);

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.replaceStoresAndUpdate(PackagingData.EDIT_ADDITIONAL_STORES);

    await dl.searchByListName(createdName);
    const rowAfter = dl.rowByName(createdName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const after = await dl.readRowValues(rowAfter);
    const afterCount = parseInt((after.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count AFTER edit for ${createdName}: ${afterCount}`);
    console.log(`📊 Delta stores: ${afterCount - beforeCount}`);

    await page.screenshot({ path: `test-results/distribution-list-edit-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28913 - Create and Delete Distribution List - Web flow', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(5);
    await dl.createNewList({ name: createdName, stores: PackagingData.DELETE_FLOW_STORES });
    console.log(`✅ Distribution List created (skipping toast): ${createdName}`);

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    await dl.selectRow(row);
    await dl.deleteSelectedAndConfirm();

    await dl.searchByListName(createdName);
    const matchAgain = dl.rowByName(createdName);
    await expect(matchAgain).toHaveCount(0, { timeout: 10000 });
    console.log('✅ Deletion verified: list not found');

    await page.screenshot({ path: `test-results/distribution-list-delete-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28914 - Packaging navigation and US_CHAIN read-only info validation', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    // 8) Search "US_CHAIN" by List Name
    await dl.searchByListName(PackagingData.US_CHAIN_DL_NAME);

    // 9) Select the radio button for "US_CHAIN"
    const row = dl.rowByName(PackagingData.US_CHAIN_DL_NAME);
    await expect(row).toBeVisible({ timeout: 20000 });
    await dl.selectRow(row);

    // 10) Validate read-only info message
    await dl.verifySystemGeneratedListOnlyInfo();

    await page.screenshot({ path: 'test-results/us_chain_readonly_validation.png', fullPage: true });
  });

  test('HWCENTSAF-28939 - Clearly highlight non-editable and non-deletable lists', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');

    // 1) System-generated read-only list (US_CHAIN) should be clearly highlighted in the table
    await dl.searchByListName(PackagingData.US_CHAIN_DL_NAME);
    const systemRow = dl.rowByName(PackagingData.US_CHAIN_DL_NAME);
    await expect(systemRow).toBeVisible({ timeout: 20000 });
    await dl.selectRow(systemRow);
    await dl.verifySystemGeneratedListOnlyInfo();
    await page.screenshot({ path: 'test-results/rx_chain_readonly_validation_.png', fullPage: true });

     // 2) Search NON_DELETABLE_LIST_NAME DL, click it and verify Edit toggle is not toggled (disabled & unchecked)
     await dl.searchByListName(PackagingData.NON_DELETABLE_LIST_NAME);
     const row = dl.rowByName(PackagingData.NON_DELETABLE_LIST_NAME);
     await expect(row).toBeVisible({ timeout: 20000 });
     const values = await dl.readRowValues(row);
     await dl.clickOnTheDlName(values.name);
     await page.waitForTimeout(3000);
     await expect(dl.ui.editableSwitch).toBeDisabled();
 
     await page.screenshot({ path: 'test-results/non_editable_lists_highlighted.png', fullPage: true });
   });

   // For both admin and write user
  test.describe.serial('HWCENTSAF-28953, HWCENTSAF-28954 - RX_CHAIN read-only (admin then write)', () => {
    for (const userType of ['admin', 'write']) {
      test(`RX_CHAIN remains untouched by any edits/deletes (${userType} user)`, async ({ page }) => {
        const { dashboard, dl } = await loginAndGoToDistributionList(page, config, userType);
        // 8) Search "RX_CHAIN" by List Name
        await dl.searchByListName(PackagingData.RX_CHAIN_DL_NAME);

        // 9) Select the radio button for "RX_CHAIN"
        const row = dl.rowByName(PackagingData.RX_CHAIN_DL_NAME);
        await expect(row).toBeVisible({ timeout: 20000 });
        await dl.selectRow(row);

        // 10) Validate read-only info message
        if(userType === 'write'){
          await dl.verifyWriteUserWarningMessage();
        } else {
          await dl.verifySystemGeneratedListOnlyInfo();
        }

        await page.screenshot({ path: `test-results/rx_chain_readonly_validation_${userType}.png`, fullPage: true });
      });
    }
  }); 

  test('HWCENTSAF-28938 - New List shows entered invalid stores under "Invalid Stores"', async ({ page }) => {
		const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
		// 8) Click on "New List"
		await dl.openNewListForm();

		// 9) Fill "List Name" with randomized "Auto/<4-alnum>"
		const listName = buildAutoListName(4);
		await dl.fillListName(listName);

		// 10) Fill "Stores" with 1, 8 and keep values for validation
		await dl.fillStores(PackagingData.INVALID_STORES);

		// 11) Click on "Add"
		await dl.clickAddStores();

		// 12) Validate that the added stores appear under invalid stores group
    await dl.verifyInvalidStores(PackagingData.INVALID_STORES);
    await page.screenshot({ path: 'test-results/invalid_stores_validation.png', fullPage: true });
	});

  test('HWCENTSAF-28947 - Duplicate Store Num while creating DL are NOT allowed', async ({ page }) => {
		const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
		await dl.openNewListForm();
		const listName = buildAutoListName(4);
		await dl.fillListName(listName);
		await dl.fillStores(PackagingData.DUPLICATE_STORES);
		await dl.clickAddStores();
    await dl.verifyValidStores(PackagingData.DUPLICATE_STORES);
    await page.screenshot({ path: 'test-results/distinct_stores_validation.png', fullPage: true });
	});

  test('HWCENTSAF-28940 - Create Non Editable/Non DeletableDistribution List And Verify the edit toggle is disabled', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(4);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK, editable: false });

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const values = await dl.readRowValues(row);
    console.log(`📌 Created List Name (from table): ${values.name}`);
    console.log(`📌 Store Count (from table): ${values.storeCount}`);
    console.log(`📌 Created By (from table): ${values.createdBy}`);

    await dl.clickOnTheDlName(values.name);
    await expect(dl.ui.editableSwitch).toBeDisabled();
    await expect(await dl.isEditableToggleChecked()).toBeFalsy();

    await page.screenshot({ path: `test-results/distribution-list-created-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28941 - Create Non Editable/Non DeletableDistribution List And while editing same, make toggle to true', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(4);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK, editable: false });

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const values = await dl.readRowValues(row);
    console.log(`📌 Created List Name (from table): ${values.name}`);
    console.log(`📌 Store Count (from table): ${values.storeCount}`);
    console.log(`📌 Created By (from table): ${values.createdBy}`);

    await dl.clickOnTheDlName(values.name);
    await expect(dl.ui.editableSwitch).toBeDisabled();
    await expect(await dl.isEditableToggleChecked()).toBeFalsy();
    await dl.clickCancelOrCloseButton();

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.setEditableToggle(true);
    await dl.clickUpdate();
    await page.waitForTimeout(3000);

    await dl.clickOnTheDlName(values.name);
    await expect(await dl.isEditableToggleChecked()).toBeTruthy();

    await page.screenshot({ path: `test-results/distribution-list-edit-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28942 - Create Non Editable/Non DeletableDistribution List And edit it being an Admin User', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(4);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK, editable: false });
    console.log(`✅ Distribution List created (skipping toast): ${createdName}`);

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const before = await dl.readRowValues(row);
    const beforeCount = parseInt((before.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count BEFORE edit for ${createdName}: ${beforeCount}`);

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.replaceStoresAndUpdate(PackagingData.EDIT_ADDITIONAL_STORES);

    await dl.searchByListName(createdName);
    const rowAfter = dl.rowByName(createdName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const after = await dl.readRowValues(rowAfter);
    const afterCount = parseInt((after.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count AFTER edit for ${createdName}: ${afterCount}`);
    console.log(`📊 Delta stores: ${afterCount - beforeCount}`);

    

    await page.screenshot({ path: `test-results/noneditable-dl-updated-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  // For both admin and write user
  test.describe.serial('HWCENTSAF-28943, HWCENTSAF-28949 - Non Editable DL create and delete (admin then write)', () => {
    for (const userType of ['admin', 'write']) {
      test(`Create Non Editable/Non Deletable Distribution List And delete it (${userType} user)`, async ({ page }) => {
        const { dashboard, dl } = await loginAndGoToDistributionList(page, config, userType);
        const createdName = buildAutoListName(5);
        await dl.createNewList({ name: createdName, stores: PackagingData.DELETE_FLOW_STORES, editable: false, userType });
        console.log(`✅ Distribution List created (skipping toast): ${createdName}`);

        await dl.searchByListName(createdName);
        const row = dl.rowByName(createdName);
        await expect(row).toBeVisible({ timeout: 20000 });
        await dl.selectRow(row);
        await dl.deleteSelectedAndConfirm();

        await dl.searchByListName(createdName);
        const matchAgain = dl.rowByName(createdName);
        await expect(matchAgain).toHaveCount(0, { timeout: 10000 });
        console.log('✅ Deletion verified: list not found');

        await page.screenshot({ path: `test-results/noneditable-distribution-list-delete-${userType}-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
      });
    }
  });

  test('HWCENTSAF-28948 - Duplicate Store Num while editing DL are NOT allowed', async ({ page }) => {
		const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const createdName = buildAutoListName(5);
    await dl.createNewList({ name: createdName, stores: PackagingData.DEFAULT_STORES_BULK });
    console.log(`✅ Distribution List created (skipping toast): ${createdName}`);

    await dl.searchByListName(createdName);
    const row = dl.rowByName(createdName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const before = await dl.readRowValues(row);
    const beforeCount = parseInt((before.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count BEFORE edit for ${createdName}: ${beforeCount}`);

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.replaceStoresAndUpdate(PackagingData.DUPLICATE_STORES);

    await dl.searchByListName(createdName);
    const rowAfter = dl.rowByName(createdName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const after = await dl.readRowValues(rowAfter);
    const afterCount = parseInt((after.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    console.log(`🧮 Store count AFTER edit for ${createdName}: ${afterCount}`);
    console.log(`📊 Delta stores: ${afterCount - beforeCount}`);

    await page.screenshot({ path: `test-results/edit-duplicateStoreNum-distribution-list-edit-${createdName.replace(/\W/g, '')}.png`, fullPage: true });
	});

  test('HWCENTSAF-28944 - Admin altering Write\'s DL - edit the DL to make it non-editable/non-deletable', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin');
    const writeListName = PackagingData.WRITE_USER_LIST_NAME;

    await dl.searchByListName(writeListName);
    const row = dl.rowByName(writeListName);
    await expect(row).toBeVisible({ timeout: 20000 });
    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.setEditableToggle(false);
    await dl.clickUpdate();

    await dl.searchByListName(writeListName);
    const rowAfter = dl.rowByName(writeListName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const values = await dl.readRowValues(rowAfter);
    await dl.clickOnTheDlName(values.name);
    await page.waitForTimeout(3000);
    await expect(dl.ui.editableSwitch).toBeDisabled();
    await expect(await dl.isEditableToggleChecked()).toBeFalsy();

    await page.screenshot({ path: 'test-results/admin_altered_write_dl_non_editable.png', fullPage: true });
  });

  test('HWCENTSAF-28933 - Write users should be able to edit their created list', async ({ page }) => {
    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'write');
    const listName = buildAutoListName(5);
    await dl.createNewList({ name: listName, stores: PackagingData.DEFAULT_STORES_BULK });

    await dl.searchByListName(listName);
    const row = dl.rowByName(listName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const before = await dl.readRowValues(row);
    const beforeCount = parseInt((before.storeCount || '').replace(/[^0-9]/g, '')) || 0;

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.appendStoresAndUpdate(PackagingData.VALID_STORES);

    await dl.searchByListName(listName);
    const rowAfter = dl.rowByName(listName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const after = await dl.readRowValues(rowAfter);
    const afterCount = parseInt((after.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    expect(afterCount).toBeGreaterThanOrEqual(beforeCount + PackagingData.VALID_STORES.length);

    await page.screenshot({ path: `test-results/write_user_edited_own_list_${listName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28936, 	HWCENTSAF-28935 - Admin users can edit any DL as they prefer', async ({ page }) => {
    const listName = buildAutoListName(5);

    // Creating a DL as Write user
    let { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'write');
    await dl.createNewList({ name: listName, stores: PackagingData.DEFAULT_STORES_BULK });
    await dashboard.logout();

    // Editing the same as Admin user to check privileges
    ({ dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin'));
    await dl.searchByListName(listName);
    const row = dl.rowByName(listName);
    await expect(row).toBeVisible({ timeout: 20000 });
    const before = await dl.readRowValues(row);
    const beforeCount = parseInt((before.storeCount || '').replace(/[^0-9]/g, '')) || 0;

    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.appendStoresAndUpdate(PackagingData.VALID_STORES);

    await dl.searchByListName(listName);
    const rowAfter = dl.rowByName(listName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });
    const after = await dl.readRowValues(rowAfter);
    const afterCount = parseInt((after.storeCount || '').replace(/[^0-9]/g, '')) || 0;
    expect(afterCount).toBeGreaterThanOrEqual(beforeCount + PackagingData.VALID_STORES.length);

    await page.screenshot({ path: `test-results/write_created_admin_appended_stores_${listName.replace(/\W/g, '')}.png`, fullPage: true });
  });

  test('HWCENTSAF-28945 - Admin altering Write\'s DL - edit the non-editable DL created by Write user', async ({ page }) => {
    const listName = buildAutoListName(5);

    // Login as Write user, create a Distribution List with the given options, then log out.
    let { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'write');
    await dl.createNewList({ name: listName, stores: PackagingData.DEFAULT_STORES_BULK, editable: false, userType: 'write' });
    await dashboard.logout();

    // Login as Admin user, search for the Write user's list and edit it
    ({ dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin'));
    await dl.searchByListName(listName);
    const row = dl.rowByName(listName);
    await expect(row).toBeVisible({ timeout: 20000 });
    await dl.selectRow(row);
    await dl.clickEdit();
    await dl.replaceStoresAndUpdate(PackagingData.EDIT_ADDITIONAL_STORES);

    await dl.searchByListName(listName);
    const rowAfter = dl.rowByName(listName);
    await expect(rowAfter).toBeVisible({ timeout: 20000 });

    await page.screenshot({ path: 'test-results/admin_edited_write_non_editable_dl.png', fullPage: true });
  });

  test('HWCENTSAF-28946 - Admin altering Write\'s DL - delete the non-deletable DL created by Write user', async ({ page }) => {
    const listName = buildAutoListName(5);

    // Login as Write user, create a Distribution List with the given options, then log out.
    let { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'write');
    await dl.createNewList({ name: listName, stores: PackagingData.DEFAULT_STORES_BULK, editable: false, userType: 'write' });
    await dashboard.logout();

    // Login as Admin user, search for the Write user's list and delete it
    ({ dashboard, dl } = await loginAndGoToDistributionList(page, config, 'admin'));
    await dl.searchByListName(listName);
    const row = dl.rowByName(listName);
    await expect(row).toBeVisible({ timeout: 20000 });
    await dl.selectRow(row);
    await dl.deleteSelectedAndConfirm();

    await dl.searchByListName(listName);
    const matchAgain = dl.rowByName(listName);
    await expect(matchAgain).toHaveCount(0, { timeout: 10000 });

    await page.screenshot({ path: 'test-results/admin_deleted_write_non_deletable_dl.png', fullPage: true });
  });

  test('HWCENTSAF-28950, HWCENTSAF-28951, HWCENTSAF-28952, HWCENTSAF-28934 - Checking the Write user privileges', async ({ page }) => {
    const writeUserCannotDeleteCases = [
      { testId: '28951', title: "Admin's DL", listName: PackagingData.ADMIN_LIST_NAME, screenshot: 'admin_dl' },
      { testId: '28952', title: 'non-deletable DL', listName: PackagingData.NON_DELETABLE_LIST_NAME, screenshot: 'non_deletable_dl' },
      { testId: '28950', title: "other Write's DL", listName: PackagingData.OTHER_USER_LIST_NAME, screenshot: 'other_write_dl' },
    ];

    const { dashboard, dl } = await loginAndGoToDistributionList(page, config, 'write');

    for (const { testId, title, listName, screenshot } of writeUserCannotDeleteCases) {
      await test.step(`${testId} - Write user can NOT delete ${title}`, async () => {
        await dl.searchByListName(listName);
        const row = dl.rowByName(listName);
        await expect(row).toBeVisible({ timeout: 20000 });
        await dl.selectRow(row);
        await expect(dl.ui.deleteButton).not.toBeVisible();
        await expect(dl.ui.editButton).not.toBeVisible();
        await page.screenshot({ path: `test-results/write_user_cannot_delete_${screenshot}.png`, fullPage: true });        
      });
    }
  });
});


