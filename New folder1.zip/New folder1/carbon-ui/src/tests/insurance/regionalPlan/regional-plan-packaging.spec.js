const { getConfig } = require("../../../../config");
const { test, expect } = require("@playwright/test");
const { PlansPage } = require('../../../page-objects/insurance/plans-page');
const { WorkorderPage } = require('../../../page-objects/insurance/workorder-page');
const { PackagingDashboardPage } = require('../../../page-objects/insurance/packaging-dashboard-page');
const { regionalPlanData, buildPlan, buildPlanName } = require('../../../test-data/insurance/regional-plan/regional-plan.data');
const { chainPlanData, buildChainPlan, buildChainPlanName } = require('../../../test-data/insurance/regional-plan/chain-plan.data');

const config = getConfig();

test.describe('Insurance › Regional Plan › Packaging Tests', () => {
    test.beforeEach(async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        await plansPage.openInsuranceAndLoginIfNeeded('admin');
    });

    test('HWCENTSAF-30729 - Creation of Regional Plan', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        
        const planName = buildPlanName();
        const plan = buildPlan();
        
        // Create new regional plan
        await plansPage.goToCreateNewPlan(regionalPlanData, planName, plan);
        
        // Approve work order
        await workOrder.approveTheWorkOrder(regionalPlanData, plan);
        
        // Verify plan was created successfully by checking if we're on the packaging page
        await expect(workOrder.ui.packagingPageHeading).toBeVisible({ timeout: 20000 });
        
        console.log(`✅ Regional Plan created successfully: ${planName} / ${plan}`);
        await page.screenshot({ path: `test-results/regional-plan-created-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30730 - Packaging the new Regional Plan created (SKIP package creation)', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        const packageDashboard = new PackagingDashboardPage(page, config);
        const createPlan = new PlansPage(page, config);
        
        const planName = buildPlanName();
        const plan = buildPlan();
        
        // Create new regional plan without enrolled stores
        await plansPage.goToCreateNewPlan(regionalPlanData, planName, plan);
        await workOrder.approveTheWorkOrder(regionalPlanData, plan);
        
        // Try to package without enrolled stores
        // Go to Plans page. Select this plan, and click on Package Button.
        const groupId = await createPlan.packagingInPlanScreen(planName);
        //it will land on package screen
        //click on group and schedule
        if(typeof groupId == 'undefined'){
            console.log(`✅ Verified: Package NOT created for regional plan without enrolled stores`);
        }
        await page.screenshot({ path: `test-results/regional-plan-no-package-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30731 - Package the new Regional Plan', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        const packageDashboard = new PackagingDashboardPage(page, config);
        const createPlan = new PlansPage(page, config);
        
        const planName = buildPlanName();
        const plan = buildPlan();
        
        // Create new regional plan
        await plansPage.goToCreateNewPlan(regionalPlanData, planName, plan);
        await workOrder.approveTheWorkOrder(regionalPlanData, plan);
        
        // Add enrolled stores to regional plan
        await plansPage.addEnrolledStoresToRegionalPlanAndFinalise(regionalPlanData, planName);
        await workOrder.approveAnyTypeOfWorkOrder('ADD_STORES_ATTACHED_TO_PLAN', regionalPlanData.CARRIER, plan);
        
        // Go to Plans page. Select this plan, and click on Package Button.
        const groupId = await createPlan.packagingInPlanScreen(planName);

        await packageDashboard.searchInsPlanAndClickGroupAndSchedulePackage(regionalPlanData, plan, groupId);

        // // Verify packaging flow
        const isDistributionFlow = await packageDashboard.checkIfItIsGoingForDLorEnrolledStore();
        
        // Regional plans should go through enrolled store flow, not distribution list
        if (isDistributionFlow) {
            throw new Error('❌ Regional plan should NOT use distribution list flow');
        } else {
            console.log(`✅ Regional plan correctly using enrolled store flow`);
            await packageDashboard.packageViaEnrolledStore(regionalPlanData.ENROLLED_STORES);
        }
        
        console.log(`✅ Regional Plan packaged successfully: ${planName} / ${plan}`);
        await page.screenshot({ path: `test-results/regional-plan-packaged-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30733 - Select multiple Regional Plan and Package in Plans Page', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        
        // Navigate to Plans page
        if (!page.url().includes('/insurance/plans')) {
            await page.goto('https://hw-carbon.stage.walmart.com/insurance/plans');
        }
        await page.waitForLoadState('networkidle');
        
        // Search for regional plans (plans with PLAINCHAIN flag = 'N')
        await plansPage.selectMultipleRegionalPlans(regionalPlanData.BIN, 2);

        // Verify yellow warning is displayed
        await plansPage.expectDifferentRegionalPlansWarningVisible();
        
        console.log(`✅ Verified: Multiple regional plans cannot be packaged together from Plans page`);
        await page.screenshot({ path: 'test-results/multiple-regional-plans-no-package.png', fullPage: true });
    });

    test('HWCENTSAF-30734 - Select mix of Chain and Regional Plan, then Package in Plans Page', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        // Navigate to Plans page
        if (!page.url().includes('/insurance/plans')) {
            await page.goto('https://hw-carbon.stage.walmart.com/insurance/plans');
        }
        await page.waitForLoadState('networkidle');
        await plansPage.selectMixedPlans(regionalPlanData.CHAIN_AND_REGIONAL_MIXED_PLAN_BIN_TESTDATA);

        // Verify yellow warning is displayed
        await plansPage.expectMixedPlansWarningVisible();
        
        console.log(`✅ Verified: Mixed Chain and Regional plans cannot be packaged together`);
        await page.screenshot({ path: 'test-results/mixed-plans-no-package.png', fullPage: true });
    });

    test('HWCENTSAF-30715,HWCENTSAF-30716,HWCENTSAF-30717 - Create Regional Plan and Package from Plans Page', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        const packageDashboard = new PackagingDashboardPage(page, config);
        
        const planName = buildPlanName();
        const plan = buildPlan();
        
        // Create new regional plan
        await plansPage.goToCreateNewPlan(regionalPlanData, planName, plan);
        await workOrder.approveTheWorkOrder(regionalPlanData, plan);
        
        // Add enrolled stores to regional plan
        await plansPage.addEnrolledStoresToRegionalPlanAndFinalise(regionalPlanData, planName);
        await workOrder.approveAnyTypeOfWorkOrder('ADD_STORES_ATTACHED_TO_PLAN', regionalPlanData.CARRIER, plan);

        // Package the regional plan from Plans Page
        let groupId = await plansPage.packagingInPlanScreen(planName);

        //Package it
        await packageDashboard.searchInsPlanAndClickGroupAndSchedulePackage(regionalPlanData, plan, groupId);
        await packageDashboard.packageViaEnrolledStore(regionalPlanData.ENROLLED_STORES);

        console.log(`✅ Regional Plan created and packaged successfully: ${planName} / ${plan}`);
        await page.screenshot({ path: `test-results/regional-plan-packaged-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30843 - Redistribute Regional Plan Package', async ({ page }) => {
        const packageDashboard = new PackagingDashboardPage(page, config);
        await packageDashboard.openPackagingArea();
        await packageDashboard.goToPackageDashboard();
        await packageDashboard.selectPackageByStorePrefix('INSURANCE PLAN GROUP# : 11935');
        await packageDashboard.clickRedistributePackageButton();
        await packageDashboard.selectAllStoresForRegionalPlanPackage();
        console.log(`✅ Regional Plan redistributed successfully`);
        await page.screenshot({ path: `test-results/regional-plan-redistributed.png`, fullPage: true });
    });
});

test.describe('Insurance › Regional Plan › Chain Plan Tests', () => {
    test.beforeEach(async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        await plansPage.openInsuranceAndLoginIfNeeded('admin');
    });

    test(`HWCENTSAF-30728 - Creation of Chain Plan & Package
          HWCENTSAF-30727 - Verify update modifies existing package
          HWCENTSAF-30726 - Verified the update Response`, async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        const packageDashboard = new PackagingDashboardPage(page, config);
        
        const planName = buildChainPlanName();
        const plan = buildChainPlan();
        
        // Create new chain plan (using chainPlanData which has PLAINCHAIN = 'Y')
        const createChainPlanRequestData = await plansPage.goToCreateNewPlan(chainPlanData, planName, plan);

        // Editing the workOrder
        await workOrder.clickEditWorkOrderButton(chainPlanData, plan);

        // Adding the new contacts
        const updateChainPlanData = await plansPage.addNewContact(chainPlanData);

        // Verify workOrderId and workOrderName are the same in Create and Update request data
        const createFirst = createChainPlanRequestData?.workOrderAndSubjectAreas?.[0];
        const updateFirst = updateChainPlanData?.requestData?.workOrderAndSubjectAreas?.[0];
        expect(createFirst?.workOrderId).toBe(updateFirst?.workOrderId);
        expect(createFirst?.workOrderName).toBe(updateFirst?.workOrderName);
        console.log(`✅ Verified update modifies existing workOrder`);

        expect(updateChainPlanData?.responseBody).toContain('Package schedule updated successfully with GroupId');
        console.log(`✅ Package schedule updated successfully with GroupId`);

        await workOrder.approveTheWorkOrder(chainPlanData, plan);
        
        // Package the chain plan via distribution list
        await packageDashboard.searchInsPlanAndClickGroupAndSchedulePackage(chainPlanData, plan);
        
        // Verify it uses distribution list flow (not enrolled store)
        const isDistributionFlow = await packageDashboard.checkIfItIsGoingForDLorEnrolledStore();
        
        if (!isDistributionFlow) {
            throw new Error('❌ Chain plan should use distribution list flow');
        }
        
        console.log(`✅ Chain plan correctly using distribution list flow`);
        await packageDashboard.packageViaDistributionList(chainPlanData.DISTRIBUTION_LIST);
        
        console.log(`✅ Chain Plan created and packaged successfully: ${planName} / ${plan}`);
        await page.screenshot({ path: `test-results/chain-plan-packaged-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30732 - Select multiple Chain Plan and Package in Plans Page', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        await plansPage.selectMultipleChainPlans(chainPlanData.BIN, 2);
        console.log(`✅ Verified: Multiple chain plans can be packaged together from Plans page`);
        await page.screenshot({ path: 'test-results/multiple-chain-plans-package.png', fullPage: true });
    });

    test('HWCENTSAF-30718 - Create Chain Plan and Package from Plans Page', async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        const workOrder = new WorkorderPage(page, config);
        const packageDashboard = new PackagingDashboardPage(page, config);
        
        const planName = buildPlanName();
        const plan = buildPlan();
        
        // Create new regional plan
        await plansPage.goToCreateNewPlan(chainPlanData, planName, plan);
        
        // Approve the workOrder
        await workOrder.approveTheWorkOrder(chainPlanData, plan);

        //Package it
        await packageDashboard.searchInsPlanAndClickGroupAndSchedulePackage(chainPlanData, plan);
        await packageDashboard.packageViaDistributionList(chainPlanData.DISTRIBUTION_LIST);

        console.log(`✅ Chain Plan created and packaged successfully: ${planName} / ${plan}`);
        await page.screenshot({ path: `test-results/chain-plan-packaged-${plan.replace(/\W/g, '')}.png`, fullPage: true });
    });

    test('HWCENTSAF-30844 - Redistribute Chain Plan Package', async ({ page }) => {
        const packageDashboard = new PackagingDashboardPage(page, config);
        await packageDashboard.openPackagingArea();
        await packageDashboard.goToPackageDashboard();
        await packageDashboard.selectPackageByStorePrefix('INSURANCE PLAN GROUP# : 11243', false);
        await packageDashboard.clickRedistributePackageButton();
        await packageDashboard.redistributePackageViaDistributionList(chainPlanData.DISTRIBUTION_LIST);
        console.log(`✅ Chain Plan redistributed successfully`);
        await page.screenshot({ path: `test-results/chain-plan-redistributed.png`, fullPage: true });
    });
});
