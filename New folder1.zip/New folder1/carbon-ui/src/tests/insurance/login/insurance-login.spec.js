const { getConfig } = require("../../../../config");
const { test, expect } = require("@playwright/test");
const { PlansPage } = require("../../../page-objects/insurance/plans-page");

const config = getConfig();

test.describe("Insurance Module - Access Control", () => {
    test("Verify Insurance Module Admin can access Plans page", async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        
        // 1-3. Retrieve admin credentials and login to carbon UI
        await plansPage.openInsuranceAndLoginIfNeeded("admin");
        
        // 4-5. Verify landing on Plans page with heading visible
        await expect(plansPage.ui.plansHeading).toBeVisible();
        
        // 6. Verify "Create New Plan" button is enabled
        await expect(plansPage.ui.createNewPlanButton).toBeEnabled();
    });

    test("Verify Insurance Module Write access can access Plans page", async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        
        // 1-3. Retrieve write access credentials and login to carbon UI
        await plansPage.openInsuranceAndLoginIfNeeded("write");
        
        // 4-5. Verify landing on Plans page with heading visible
        await expect(plansPage.ui.plansHeading).toBeVisible();
        
        // 6. Verify "Create New Plan" button is enabled
        await expect(plansPage.ui.createNewPlanButton).toBeEnabled();
    });

    test("Verify Insurance Module Read access can access Plans page with restricted access", async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        
        // 1-3. Retrieve read access credentials and login to carbon UI
        await plansPage.openInsuranceAndLoginIfNeeded("read");
        
        // 4-5. Verify landing on Plans page with heading visible
        await expect(plansPage.ui.plansHeading).toBeVisible();
        
        // 6. Verify "Create New Plan" button is disabled
        await expect(plansPage.ui.createNewPlanButton).toBeDisabled();
    });
});

test.describe("Insurance Module - Authentication", () => {
    test("Verify login with invalid credentials shows error", async ({ page }) => {
        const invalidUsername = "invalid_user_test";
        const invalidPassword = "invalid_pass_test";
        
        // 1-2. Retrieve invalid credentials and attempt login
        await page.goto(config.carbonInsurance.url);
        await page.waitForLoadState('load');
        await page.waitForTimeout(3000);
        
        const currentUrl = page.url();
        if (currentUrl.includes(config.carbonInsurance.authUrlPattern)) {
            await page.getByRole('textbox', { name: /User ID/ }).fill(invalidUsername);
            await page.getByRole('textbox', { name: 'Password' }).fill(invalidPassword);
            await page.keyboard.press('Enter');
            
            // Wait for navigation or error
            await page.waitForTimeout(5000);
        }
        
        // 3. Verify URL contains authentication failure indicators or remains on auth page
        const finalUrl = page.url();
        const urlLower = finalUrl.toLowerCase();
        
        const hasAuthError = urlLower.includes('error=access_denied') || 
                            urlLower.includes('authentication') ||
                            urlLower.includes('error_description');
        
        // 4. Check if still on auth page (didn't progress means auth failed)
        const stillOnAuthPage = urlLower.includes('pfedcert') && urlLower.includes('authorization');
        
        // 5. Check for error page content
        let hasErrorOnPage = false;
        try {
            hasErrorOnPage = await page.getByText(/Oops! Something went wrong/i).isVisible({ timeout: 2000 }).catch(() => false) ||
                            await page.getByText(/Error Code: 500/i).isVisible({ timeout: 2000 }).catch(() => false);
        } catch (e) {
            // Page might not have error messages
        }
        
        // Assert that either URL shows error, still blocked on auth, or shows error page
        expect(hasAuthError || stillOnAuthPage || hasErrorOnPage).toBeTruthy();
    });
});
