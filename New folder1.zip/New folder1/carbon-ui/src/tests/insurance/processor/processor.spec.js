const { getConfig } = require("../../../../config");
const { test } = require("@playwright/test");
const { PlansPage } = require("../../../page-objects/insurance/plans-page");
const { ProcessorPage } = require("../../../page-objects/insurance/processor-page");
const { WorkorderPage } = require("../../../page-objects/insurance/workorder-page");
const {
    buildProcessorName,
    buildVendorCertificationId,
    buildProcessorWorkOrderName,
} = require("../../../test-data/insurance/processor/processor.data");

const config = getConfig();

test.describe("Insurance > Processors", () => {
    test.beforeEach(async ({ page }) => {
        const plansPage = new PlansPage(page, config);
        await plansPage.openInsuranceAndLoginIfNeeded("admin");
    });

    test("Create and finalize a new processor", async ({ page }) => {
        const processorPage = new ProcessorPage(page);
        const workorderPage = new WorkorderPage(page, config);
        const processorName = buildProcessorName();
        const vendorCertificationId = buildVendorCertificationId();
        const expectedWorkOrderName = buildProcessorWorkOrderName(processorName);

        // 1-4. Navigate to Processors and open Add New Processor page.
        await processorPage.openProcessorsModule();
        await processorPage.clickNewProcessor();

        // 5. Fill required processor fields.
        await processorPage.fillProcessorBasicInformation(processorName, vendorCertificationId);

        // 6. Save and verify success popup text.
        await processorPage.saveAndVerifyWorkOrderSuccessToast();

        // 7. Finalize the work order.
        await processorPage.finalizeProcessor();
        await workorderPage.verifyLandedOnWorkOrdersPage();
        await workorderPage.verifyWorkOrderNameVisible(expectedWorkOrderName);
    });
});