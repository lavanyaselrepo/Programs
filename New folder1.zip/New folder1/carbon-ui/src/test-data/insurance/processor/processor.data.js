function generateRandomId(length = 8) {
    return Math.random().toString(36).slice(2, 2 + length).toUpperCase();
}

function buildProcessorName() {
    return `AUTO/PO/PROC-${generateRandomId()}`;
}

function buildVendorCertificationId() {
    return `AUTO/PO/SVC-${generateRandomId()}`;
}

function buildProcessorWorkOrderName(processorName) {
    return `NEW_PROCESSOR_${processorName}`;
}

module.exports = {
    buildProcessorName,
    buildVendorCertificationId,
    buildProcessorWorkOrderName,
};
