const PackagingData = {
  DEFAULT_STORES_BULK: ['17', '13', '10', '101', '117'],
  EDIT_ADDITIONAL_STORES: ['21', '37'],
  DELETE_FLOW_STORES: ['15', '16'],
  VALID_STORES: ['15', '16', '21'],
  SEARCH_SAMPLE_NAME: 'abcd/11111',
  US_CHAIN_DL_NAME: 'US_CHAIN',
  RX_CHAIN_DL_NAME: 'RX_CHAIN',
  INVALID_STORES: ['1', '8'],
  DUPLICATE_STORES: ['15', '15', 13, 13, 13],
  ADMIN_LIST_NAME: 'Checking_List_Test',
  NON_DELETABLE_LIST_NAME: 'Checking_List_Test',
  DELETE_LIST_NAME: 'Animesh_test_02',
  OTHER_USER_LIST_NAME: 'Checking_List_Test',
  /** List created by a Write user; used for Admin altering Write's DL (e.g. make non-editable) */
  WRITE_USER_LIST_NAME: 'Checking_List_Test',
};

function generateRandomId(length = 4) {
  return Math.random().toString(36).slice(2, 2 + length).toUpperCase();
}

function buildAutoListName(randomLength = 4) {
  return `Auto/${generateRandomId(randomLength)}`;
}

module.exports = { PackagingData, generateRandomId, buildAutoListName };


