const ChainPlanData = {
  BIN: '227002',
  PCN: '739',
  CARRIER: 'CHP',
  PLAN: 'CHPT01',
  EXPIRATION_DATE: '31122030',
  AUTOPOPULATE: 'Y',
  COB: 'Y',
  CATEGORY: 'CASH PLAN',
  DELIVERY: 'Y',
  INSTORE: 'Y',
  PLAINCHAIN: 'Y', // This flag = 'Y' makes it a Chain plan
  SUBMISSION: 'D0',
  NONE: 'Y',
  PROCESSOR: 'Test Processor',
  CLAIM_FORMAT: 'Test Claim Format',
  CLAIM_PARAMETERS: 'Test Claim Parameters',
  CONTACTS_NAME: 'CHAIN_CONTACT',
  CONTACTS_TYPE: '1000',
  CONTACTS_NAME_2: 'CHAIN_CONTACT_2',
  CONTACTS_TYPE_2: '1000',
  DISTRIBUTION_LIST: 'US_CHAIN', // Chain plans use distribution lists
  PACKAGE_NAME: 'TEST_CHAIN_PACKAGE',
};

const GroupExceptionData = {
  // Sample BIN/PCN for group exceptions
  COMMON_BIN: '227001',
  COMMON_PCN: '738',
  
  // Plans for group exception testing
  CHAIN_PLANS: [
    {
      CARRIER: 'GRP',
      PLAN: 'GRP001',
      TYPE: 'CHAIN'
    },
    {
      CARRIER: 'GRP',
      PLAN: 'GRP002',
      TYPE: 'CHAIN'
    }
  ],
  
  REGIONAL_PLANS: [
    {
      CARRIER: 'GRP',
      PLAN: 'GRPR01',
      TYPE: 'REGIONAL',
      ENROLLED_STORES: [5560, 5561]
    },
    {
      CARRIER: 'GRP',
      PLAN: 'GRPR02',
      TYPE: 'REGIONAL',
      ENROLLED_STORES: [5562, 5563]
    }
  ]
};

function generateRandomId(length = 4) {
    return Math.random().toString(36).slice(2, 2 + length).toUpperCase();
}
  
function buildChainPlanName(randomLength = 4) {
    return `Chain/${generateRandomId(randomLength)}`;
}

function buildChainPlan(randomLength = 4) {
    return `CH0/${generateRandomId(randomLength)}`;
}

module.exports = { 
  chainPlanData: ChainPlanData, 
  groupExceptionData: GroupExceptionData,
  buildChainPlan, 
  buildChainPlanName 
};
