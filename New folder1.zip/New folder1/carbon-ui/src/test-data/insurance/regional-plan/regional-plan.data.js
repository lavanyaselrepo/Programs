const RegionalPlanData = {
  BIN: '227001',
  CHAIN_AND_REGIONAL_MIXED_PLAN_BIN_TESTDATA: [{
    flag : 'N',
    bin : '227001'
  }, {
    flag : 'Y',
    bin : '001234'
  }],
  PCN: '738',
  CARRIER: 'ATM',
  PLAN: 'AATT01',
  EXPIRATION_DATE: '31122030',
  AUTOPOPULATE: 'Y',
  COB: 'Y',
  CATEGORY: 'CASH PLAN',
  DELIVERY: 'Y',
  INSTORE: 'Y',
  PLAINCHAIN: 'N',
  SUBMISSION: 'D0',
  NONE: 'Y',
  PROCESSOR: 'Test Processor',
  CLAIM_FORMAT: 'Test Claim Format',
  CLAIM_PARAMETERS: 'Test Claim Parameters',
  CONTACTS_NAME: 'STALE_NAME',
  CONTACTS_TYPE: '1000',
  ENROLLED_STORES: [100,2203,9682],
};

function generateRandomId(length = 4) {
    return Math.random().toString(36).slice(2, 2 + length).toUpperCase();
}
  
function buildPlanName(randomLength = 4) {
    return `Auto/${generateRandomId(randomLength)}`;
}

function buildPlan(randomLength=4) {
    return `AT0/${generateRandomId(randomLength)}`;
}

module.exports = { regionalPlanData: RegionalPlanData, buildPlan, buildPlanName };