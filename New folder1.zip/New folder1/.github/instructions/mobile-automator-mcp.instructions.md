---
description: "Use when executing mobile or pharmacy tests on Android or iOS, generating mobile test scripts from device actions, planning mobile test scenarios, or working with mobile automator MCP tools. Fetch execution guidelines first and complete the automatic post-execution pipeline without stopping."
applyTo: "pharmacy-ui/**, **/TESTS.md, **/dpTestDataCreationJob.json, **/pageObjects/**, **/*.java"
---

# Mobile Automator MCP

## Mandatory first action (do this before any execution or test generation)

1. **Read this instruction and the project skill** so the correct workflow is followed:
   - Instruction: this file (`.github/instructions/mobile-automator-mcp.instructions.md`).
   - Skill: `.github/skills/mobile-automator-mcp-workflow/SKILL.md` (and `framework-patterns.md` for adaptation).
2. **Fetch execution guidelines** using the MCP resource:
   - Call `fetch_mcp_resource` with `uri: "guidelines://mobile-test-automation"` and `server` set to the **exact name** of the mobile automator MCP server as configured (e.g. `"mobile-automator"` or `"user-mobile-automator"`). If you get "Server not found", use `list_mcp_resources()` to see which servers/resources exist.
   - **If the guidelines resource is unavailable** (server not found, or server has no resources): proceed using **this instruction and the skill only**; they define the full workflow (baseline, login tool, pipeline). Do not block execution.
3. **Do not search the codebase** for baseline steps (launch, Teflon, sign-in, navigate to Pharmacy, PIN). Baseline is defined only in this instruction, the skill above, and the MCP guidelines. Follow the "Two upfront questions" section below — do not reimplement from repo code.
4. **When sign-in fails** and the sign-in form is already open (email field visible): do NOT dismiss or close the sheet. Complete sign-in on it using `click_element`/`input_text` (email → Continue → password → Sign in). Do not relaunch the app.
5. Do not proceed with execution or test generation until you have read the skill and fetched the guidelines.

## Cross-platform test execution (test already automated on one platform)

**When user says:** "execute [testMethodName] test on [platform]" (e.g., "execute testSMSCreateAccountFlowForSelf test on iOS")

This indicates the test is **already automated** on one platform (e.g., Android) and needs to run on another (e.g., iOS).

**Workflow:**

1. **Search for existing test:** Use Grep to find `[testMethodName]` in `pharmacy-ui/src/test/java/mobile-e2e-tests/`
2. **If test found:**
   - Read the existing test file to understand the test flow and steps
   - Read all Page Objects referenced in the test
   - Fetch execution guidelines from MCP for the **specified platform** (e.g., iOS)
   - **Execute using BOTH sources:**
     - **Baseline (launch, setup, login):** Use MCP guidelines for the specified platform (e.g., iOS baseline)
     - **Test logic/steps:** Follow the existing test file's flow (same test logic applies to both platforms)
     - **Locators:** During execution, use `get_page_elements` to find platform-specific locators for the new platform
   - **After execution (automatic pipeline):**
     - Call `generate_test_from_actions` with all actions
     - **Update Page Objects:** Add locators for the newly executed platform (e.g., add `@iOSXCUITFindBy` alongside existing `@AndroidFindBy`)
     - Update comments to indicate both platforms are now supported
     - **Result:** Same test file now supports both platforms without duplication
3. **If test NOT found:** Proceed with normal execution (fetch guidelines, ask for data, execute, create new test file)

**Key benefits:**
- Single test file supports multiple platforms
- Page Objects have locators for all executed platforms
- Test logic is reused; only platform-specific locators differ
- No duplication of test methods

---

## Two upfront questions — ask before anything else

Before running any setup tool or calling `get_page_elements` for the first time:

**Q1 — Teflon:** "Does the app need to be pointed to Teflon? (Yes / No)"

| Answer | Action |
|---|---|
| Yes — needs Teflon | `setup_android_app` → sign in → navigate to PD |
| No — already configured | Skip `setup_android_app`; launch app if not open, sign in if needed, navigate to PD |

❌ Never call `setup_android_app` without asking Q1 first — the user may already be signed in.

**Q2 — Evidence report:** "Would you like an HTML evidence report with screenshots? (Yes / No)"
- **Yes** → include `captureLabel`, `captureDescription`, `captureStatus` on every `get_page_elements` call.
- **No** → call `get_page_elements` without `captureLabel` — no buffering, no report.

**Full baseline (when Q1 = Yes):**
  1. `setup_android_app(deviceId)` — selects Teflon + enables Skip Step up + skips onboarding + kills app + relaunches via pharmacy deep link + dismisses popup → **stops on pharmacy dashboard (does NOT sign in)**
  2. Sign in manually: `click_element(deviceId, text="Sign in or create account")` → `input_text` email → `click_element("Continue")` → `input_text` password → `click_element("Sign in")`
  3. Enter PIN `1111` if pharmacy-connected. Verify Pharmacy Dashboard loaded.
- **If `setup_android_app` reports teflon configured but deep link failed:** do NOT call `setup_android_app` again. Call `open_pharmacy_dashboard` to retry the deep link.
- Do not start feature-specific actions (e.g. SMS create account, connect account) until Pharmacy Dashboard is reached.
- **Generated test code must always be self-contained:** even if setup was skipped during execution, always include the full setup sequence (setup_android_app → sign in → PIN) in the actions passed to `generate_test_from_actions`. The test must be runnable on a fresh device.

## When user says "Execute test case [ID]" or "execute [testMethodName] test on [platform]"

1. **Cross-Platform Detection:** If user specifies a test name (e.g., `testSMSCreateAccountFlowForSelf`) and platform (e.g., `on iOS`):
   - **Search for existing test file** in codebase: Use Grep to find the test method name in `pharmacy-ui/src/test/java/mobile-e2e-tests/`
   - **If found (test was automated on another platform):**
     - Read the existing test file to understand the test logic and steps
     - Fetch execution guidelines from MCP for the specified platform (iOS, Android, etc.)
     - **Combine both:** Use MCP guidelines for baseline (launch, setup, login) specific to the requested platform, and use the test file logic for feature steps
     - **Adapt locators:** During execution, use `get_page_elements` to find platform-specific locators (iOS XPath if running on iOS, Android if on Android)
   - **If NOT found:** Proceed with normal execution (guidelines + user data) and create test file afterward
2. **Ask user for required data.** Do not assume or use data from files. Wait for confirmation.
   - **Pharmacy-connected account:** email, password, PIN, and any test-specific data.
   - **Non-pharmacy-connected account:** email, password only (no PIN); on pharmacy dashboard, "Connect account" CTA will be visible and no PIN verification will occur.
   - **Flows that start from Pharmacy Dashboard** (e.g. **SMS create account**, **connect to pharmacy**, **connect account**): always sign in first (email, password only — via `click_element`/`input_text` after `setup_android_app`). Do **not** ask for phone number or OTP as initial credentials—only email and password. Phone/OTP are entered during the flow when the app prompts for them, not upfront.
3. **Execute on device** per the fetched execution guidelines. Ask Q1 and Q2 (see above) if not already asked.
4. **Automatically, without stopping - complete ALL steps in order:**
   1. **Generate report only if user said Yes to Q2:**
      - If **Yes**: call `preview_report_buffer(deviceId)` first to verify all screens are present, then call `generate_flow_report` (no screenshots field). Save to `~/Desktop/[flowName]-report.html` unless the user specifies a path.
      - If **No**: skip entirely.
   2. Ask the user: "Would you like a test script generated from the recorded actions? (Yes / No)"
      - If **Yes**: Call `generate_test_from_actions` with all documented actions, then complete the full framework adaptation pipeline below.
      - If **No**: Skip test generation entirely.
   3. **Search for existing methods FIRST** - grep `BasePageApplicationManager`, platform managers (`AndroidPageManager`, `IOSPageManager`), and Page Objects to find reusable methods. Many flows already exist (e.g. `proceedToPharmacyDashboard()` includes PIN, `selectPrimaryProfileForTransfer()` includes non-Walmart selection).
   4. **Reuse existing methods** instead of creating duplicates.
   5. **For NEW methods that don't exist**: Add to `BasePageApplicationManager` FIRST with full implementation. Override in platform managers ONLY when platform differences are discovered (don't prematurely optimize).
   6. **Club similar test cases**: Check if related test file exists and add new test method to it (e.g., add family member test to existing competitive transfer test file). Create new file ONLY for completely different features.
   7. Read existing framework tests in this repo to infer structure and patterns.
   8. Adapt generated test to framework using **existing wrapper methods**.
   9. **Verify and update locators**: Compare execution locators (from `get_page_elements`) with Page Object locators. Update to use **content-desc/accessibility-id** instead of generic `instance(n)` numbers. **CRITICAL: Only update locators for the platform executed** (don't add iOS if only Android was run). Add comment indicating which platform and TODO for others.
   10. **Place test method in `pharmacy-ui/src/test/java/mobile-e2e-tests/`** (package: `mobile.e2e.tests`). Add to existing file if related, create new file if different feature.
   11. Add test data to **`pharmacy-ui/src/test/java/mobile-e2e-tests/testdata/mobileE2ETestData.json`** (NOT `dpTestDataCreationJob.json`).
   12. Present final framework-adapted test showing: which methods were reused, which new methods added (and where), which tests were clubbed together, which locators were updated.
4. Do not stop after execution to say "Test complete" or wait for "continue". Do not present raw Appium output without framework adaptation.

## Dropdown selections: always use select_dropdown_option

**Whenever the app shows a dropdown, spinner, or picker and the user says "select [option]":**

1. **Always** call `get_page_elements(deviceId)` first to find the dropdown trigger element.
2. **Always** use `select_dropdown_option` (NOT `click_element`) to select the option:
   - Pass `id` (resource-id or accessibility-id) of the dropdown trigger — preferred over `xpath`
   - Pass `optionText` as the exact visible label of the option to select (case-sensitive)
   - Pass `deviceId` and optionally `platform` and `appPackage`
3. **Never** use `click_element` to open a dropdown and then click the option separately when `select_dropdown_option` is available.
4. **Examples of when to use:**
   - "Select Male from the gender dropdown" → `select_dropdown_option(deviceId, optionText="Male", id=<dropdown trigger id>)`
   - "Select relationship from picker" → `select_dropdown_option(deviceId, optionText="Spouse", id=<picker id>)`
   - "Select state" → `select_dropdown_option(deviceId, optionText="California", id=<state dropdown id>)`

This applies to ALL dropdowns, spinners, pickers, and select lists on both Android and iOS.

---

## Critical: Always ask user for runtime data during execution

**For ANY flow execution (applies to ALL flows, not just account creation):**

When the app prompts for user input during execution, **always ask the user** to provide it:

- ✅ **Ask user for:** phone number, OTP/verification code, date of birth, address, zip code, prescription number, Rx details, insurance card info, family member details, payment info, etc.
- ❌ **Never use:** dummy values, test data, hardcoded values, or made-up information without asking
- ⏸️ **Pause execution:** When the app displays an input field, stop and prompt: "The app is asking for [field name]. What value should I enter?"
- ▶️ **Resume after:** User provides the value, then continue execution

## When user says "Generate test cases" (planning only)

1. Use execution guidelines and call `generate_tests_planning` with appropriate `flowId`, `platform`, `priority`.
2. Show test scenarios and coverage. Stop and ask if the user wants to create test files. Do not create files until they confirm.

## When user says "Create test files" or "Implement tests"

After user has confirmed following planning: create tests in **`pharmacy-ui/src/test/java/mobile-e2e-tests/`** using framework patterns (Page Objects, `BasePageApplicationManager` wrappers, test data JSON). Use the skill `.github/skills/mobile-automator-mcp-workflow/SKILL.md` and its `framework-patterns.md` for patterns.

## Where to put MCP-generated / new mobile E2E tests

- **Test classes:** Always add under **`pharmacy-ui/src/test/java/mobile-e2e-tests/`** (package: `mobile.e2e.tests` or subpackages as needed).
  - **Club similar tests**: Check if a related test file exists and add new test method to it.
  - **Create new file ONLY**: If it's a completely different feature with no related test file.
- **Test data:** Add to **`pharmacy-ui/src/test/java/mobile-e2e-tests/testdata/mobileE2ETestData.json`** (NOT `dpTestDataCreationJob.json`).
- **Page Objects:**
  - **EXISTING Page Objects**: Use existing Page Objects in their current packages. **ALWAYS update locators** to match MCP execution data.
  - **NEW Page Objects**: When creating new Page Objects, **only add locators for the platform executed**.
- **Manager methods:**
  - **For NEW methods**: Add to `BasePageApplicationManager` FIRST with full implementation.
  - **Override later**: Only override in `AndroidPageManager` or `IOSPageManager` when platform differences are discovered.
  - **Always search for existing methods first** before creating new ones.

## Locator Verification (MANDATORY after execution)

After test execution, **systematically verify ALL locators** from MCP data:

1. **Extract ALL xpaths** from `generate_test_from_actions` output (in "actions" array)
2. **For EVERY Page Object used (existing OR newly created)**:
   - Find each locator field and compare with MCP xpath from execution
   - If different: Update to **exact MCP xpath** (not simplified)
3. **Use EXACT MCP xpaths**:
   - ✅ `//android.widget.LinearLayout[@content-desc='Password']//android.widget.EditText` (MCP)
   - ❌ `@content-desc='Password'` (simplified guess - WRONG)
4. **CRITICAL - Single Platform Locators**:
   - **Only add locators for the platform executed**
   - Add comment: `// Note: Only Android locators added - executed on Android only`
   - Add TODO: `// TODO: Add iOS locators when flow is executed on iOS platform`

## Framework reuse checklist (critical)

**MANDATORY checks before creating ANY new method:**
- [ ] Thorough search completed — searched with MULTIPLE keywords/variations
- [ ] Searched `BasePageApplicationManager` for existing wrapper methods
- [ ] Searched BasePage and parent classes for generic methods (`clickElement()`, `waitForElement()`, `verifyElement()`)
- [ ] Searched `AndroidPageManager` / `IOSPageManager` for platform-specific overrides
- [ ] Read found methods to understand what they do (don't rely on names alone)
- [ ] Verified if existing methods already handle the needed behavior

**Only after thorough search:**
- [ ] Only creating new methods/locators if they truly don't exist after exhaustive search
- [ ] **For NEW methods**: Adding to `BasePageApplicationManager` FIRST (not platform managers)
- [ ] Override in platform managers ONLY when genuine platform differences are confirmed during execution

**Test organization:**
- [ ] Checked for existing related test files to club similar tests together
- [ ] Using content-desc/accessibility-id for locators, NOT instance numbers
- [ ] Locator verification: Extracted ALL xpaths from MCP and updated ALL Page Objects to match exactly
- [ ] Single platform locators: Added ONLY the platform executed
- [ ] Added comments indicating which platform(s) was executed and TODO for remaining platforms

**Final verification:**
- [ ] NO duplicate methods created
- [ ] NO unnecessary platform-specific methods — BasePage methods used where appropriate
- [ ] Final summary includes: which existing methods were reused, which were updated/overridden, and only genuinely new methods
