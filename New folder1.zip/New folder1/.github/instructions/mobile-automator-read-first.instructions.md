---
description: "Use when executing a test on device, pharmacy dashboard flows, mobile automator MCP, Android or iOS test runs, cross-platform execution, or SMS create account or connect to pharmacy. Signals that the mobile automator instruction and skill must be read before any action."
applyTo: "**"
---

# Mobile automator: read instruction and skill first

When the user's request is about **executing a test on device**, **pharmacy dashboard**, **mobile automator MCP**, **Android/iOS test run**, **cross-platform execution** (e.g., "execute [testName] test on iOS"), or **SMS create account / connect to pharmacy**:

1. **First** read (do not skip):
   - `.github/instructions/mobile-automator-mcp.instructions.md`
   - `.github/skills/mobile-automator-mcp-workflow/SKILL.md`
2. **For cross-platform execution** (test name + platform specified): Search codebase for existing test, read test file + Page Objects, fetch execution guidelines for the specified platform, then execute using both sources.
3. **Then** follow that workflow: fetch execution guidelines, ask for credentials per instruction (e.g. email + password for non–pharmacy-connected), use **login_pharmacy_connected** or **login_non_pharmacy_connected** to reach Pharmacy Dashboard, then do feature steps. Do **not** search the codebase for baseline or login flow.

This ensures the correct flow is used even when no Java/test file is open, and supports cross-platform test execution seamlessly.
