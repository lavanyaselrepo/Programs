---
description: "Use when writing, editing, or generating API tests for the digitalPharmacy module. Covers Retrofit client usage, TestNG structure, CommonUtil, ResponseUtil, naming conventions, and file placement. Apply when adding new digitalPharmacy endpoints, test classes, or test methods."
applyTo: "digitalPharmacy/**/*.java"
---

# digitalPharmacy API test conventions

Follow these patterns when writing or editing API tests in the `digitalPharmacy` module.

## Stack and dependencies

- **HTTP client**: Retrofit (via DragonLibrary). Use existing Retrofit wrappers from `com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.*.restapi` (e.g. `AccountEntityServiceRetrofit`, `CprPatientUpdateRetrofit`, `RxOrchestratorRetrofit`). Do not use raw RestAssured or HTTP client in digitalPharmacy tests.
- **Test framework**: TestNG (`@Test`, `@BeforeClass`). Use `org.testng.Assert` for assertions.
- **Utilities**: `CommonUtil` and `ResponseUtil` from `digitalpharmacyapicontext.utils` for IDs, error parsing, and response parsing. Use `Gson` for JSON; parse payloads with `ResponseUtil.parseResponse(gson, payload, ResponseClass.class)`.
- **Logging**: `Reporter.log`, `Reporter.logJSON` from `com.walmart.hwqe.commons.utilities.Reporter`.

## Test class structure

- **@BeforeClass**: Initialize Retrofit client(s) and shared test data (e.g. `CommonUtil.randomUUID()`, `CommonUtil.generateRandomNumber(n)`). Set up request IDs: `reqIdString + trackID`, `reqTrackingString + trackID`.
- **Test methods**: Use `@Test(priority = N, description = "human-readable description")`. Order by dependency or logical flow.

## Request/response handling

- Build request objects from `digitalpharmacyapicontext` or `com.walmart.pharmacy.dp.*.restclient.model` packages.
- Call API via Retrofit: `Response<ServiceResponse> response = retrofitClient.methodName(...)`.
- **Success (2xx)**: Assert `response.code()` (e.g. 200), then parse: `ResponseUtil.parseResponse(gson, ((LinkedTreeMap<String, Object>) response.body().getPayload()), ResponseClass.class)` and assert key fields.
- **Error (4xx/5xx)**: Use `Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, response)` and `CommonUtil.buildEntityServiceErrorMessage(errorResponse)` for assertion messages; assert `response.code()` and error code/message as needed.

## Naming

- Test method names: `<operation>APISuccess` for success, `<operation>API<Reason>Failure` or `<operation>API<Scenario>Error` for failures (e.g. `createPharmacyAccountV1APISuccess`, `getIsacIdVerificationV1ByStageIdSuccess`, `nullValuesInRequestForGetIsacIdVerificationV1Error`).
- Class names: `<Feature>Test`, `<Feature>TestFlow`, or `<Feature>Tests` (e.g. `AccountEntityPharmacyAccountTest`, `GetIsacIdVerificationTest`).

## Test data and config

- Static JSON: `src/test/resources/testdata/digitalpharmacy/<domain>/<feature>/<filename>.json`.
- TestNG suites: `src/test/resources/suites/digitalpharmacy/` when adding new suites.
- Use `CommonUtil.logFlowIdentifiers(...)` for traceability when needed.

## References

- Project API automation guidelines: `API_AUTOMATION_RULES.md` (wrapper/manager pattern, DB usage, POJOs).
- Existing tests: `digitalPharmacy/src/test/java/accountentity/`, `rxorchestrator/`, `accountorchestrator/`, `consentorchestrator/` for patterns.
