---
name: generate-digital-pharmacy-api-test
description: Generates or guides writing of digitalPharmacy API test classes using Retrofit, TestNG, CommonUtil, and ResponseUtil. Use when a contributor asks to add new API tests for digitalPharmacy, to automate a new API or endpoint in the digitalPharmacy folder, or to generate test scripts for digitalPharmacy APIs.
---

# Generate digitalPharmacy API test automation

Use this skill when a contributor wants to write new API test automation in the `digitalPharmacy` folder. Follow the project's existing patterns so generated or edited code is consistent and reviewable.

## When to use this skill

- User asks to add, write, or generate API tests for digitalPharmacy.
- User mentions a new API or endpoint they want to automate in digitalPharmacy.
- User asks for a test class or test methods for a specific digitalPharmacy service/flow.

## Step-by-step workflow

### 1. Identify the API and Retrofit client

- Determine which service/domain the API belongs to: accountentity, rxorchestrator, accountorchestrator, consentorchestrator, etc.
- Identify the Retrofit client class from `com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.<domain>.restapi` (e.g. `AccountEntityServiceRetrofit`, `RxOrchestratorRetrofit`).
- Identify the Retrofit method that calls the endpoint (e.g. `createPharmacyAccountV1`, `getIsacIdVerificationV1`).

### 2. Identify request and response types

- Request/response models usually live in:
  - `com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.<domain>.model.request` / `model.response`
  - `com.walmart.pharmacy.dp.<service>.restclient.model` (e.g. `ServiceResponse`, `Error`, and operation-specific request/response classes).
- Use these types for building requests and parsing responses with `ResponseUtil.parseResponse`.

### 3. Choose package and class location

- Place the test class under `digitalPharmacy/src/test/java/` in the appropriate package:
  - accountentity → `accountentity.customer`, `accountentity.isac`, `accountentity.accountverification`, etc.
  - rxorchestrator → `rxorchestrator` or subpackages
  - accountorchestrator → `accountorchestrator` or subpackages
- Class name: `<Feature>Test`, `<Feature>Tests`, or `<Feature>TestFlow` (e.g. `GetIsacIdVerificationTest`, `AccountEntityPharmacyAccountTest`).

### 4. Implement the test class

Follow the structure below. Respect the **instruction** in `.github/instructions/digital-pharmacy-api-tests.instructions.md` (Retrofit only, TestNG, CommonUtil, ResponseUtil, naming).

**Class skeleton:**

```java
package <domain>.<subdomain>;  // e.g. accountentity.isac

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.<domain>.restapi.<RetrofitClient>;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.ResponseUtil;
import com.walmart.pharmacy.dp.<service>.restclient.model.Error;
import com.walmart.pharmacy.dp.<service>.restclient.model.ServiceResponse;
// ... operation-specific request/response imports
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import retrofit2.Response;

public class <TestClassName> {
  private <RetrofitClient> retrofitClient;
  private Gson gson;
  private String reqIdString = "req-id-";
  private String reqTrackingString = "req-tracking-";
  private String domainId = "WM-PHARMACY";  // or as needed

  @BeforeClass
  void setContext() {
    retrofitClient = new <RetrofitClient>();
    gson = new GsonBuilder().create();
  }

  @Test(priority = 1, description = "<short description>")
  public void <operation>APISuccess() throws IOException {
    String trackID = CommonUtil.randomUUID();
    String reqId = reqIdString + trackID;
    String reqTrackingId = reqTrackingString + trackID;
    // Build request object
    <RequestType> request = ...;
    Response<ServiceResponse> response = retrofitClient.<method>(domainId, reqId, reqTrackingId, request);
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, response);
    String errorMessage = CommonUtil.buildEntityServiceErrorMessage(errorResponse);
    Assert.assertEquals(response.code(), 200, errorMessage);
    <ResponseType> parsed = ResponseUtil.parseResponse(gson,
        ((LinkedTreeMap<String, Object>) response.body().getPayload()), <ResponseType>.class);
    // Assert key fields
  }

  @Test(priority = 2, description = "<failure scenario>")
  public void <operation>API<Reason>Failure() throws IOException {
    // Build request that triggers failure (e.g. invalid input)
    Response<ServiceResponse> response = ...;
    Error errorResponse = CommonUtil.getEntityServiceErrorResponse(gson, response);
    Assert.assertEquals(response.code(), 400, CommonUtil.buildEntityServiceErrorMessage(errorResponse));
    // Assert error code/message if needed
  }
}
```

### 5. Success vs failure tests

- **Success (2xx)**: Assert status code, parse payload with `ResponseUtil.parseResponse(gson, (LinkedTreeMap) response.body().getPayload(), ResponseClass.class)`, then assert important fields.
- **Failure (4xx/5xx)**: Use `CommonUtil.getEntityServiceErrorResponse(gson, response)` and assert status code and optionally `errorResponse.getCode()` / `getMessage()`.

### 6. Test data

- If the test needs static JSON: add under `digitalPharmacy/src/test/resources/testdata/digitalpharmacy/<domain>/<feature>/` and load with `ObjectMapper.readValue(new File("src/test/resources/..."), RequestClass.class)` or equivalent.
- For dynamic data use `CommonUtil.randomUUID()`, `CommonUtil.generateRandomNumber(n)`.

### 7. Optional: TestNG suite

- If adding a new suite, add or update XML under `digitalPharmacy/src/test/resources/suites/digitalpharmacy/` and reference it from Looper or Maven as needed.

## Reference examples in repo

- **Account entity**: `digitalPharmacy/src/test/java/accountentity/customer/AccountEntityPharmacyAccountTest.java`, `accountentity/isac/GetIsacIdVerificationTest.java`
- **Rx orchestrator**: `digitalPharmacy/src/test/java/rxorchestrator/`
- **Account orchestrator**: `digitalPharmacy/src/test/java/accountorchestrator/`

## Cross-reference

- **Workspace instruction** (conventions): `.github/instructions/digital-pharmacy-api-tests.instructions.md`
- **Project API guidelines**: `API_AUTOMATION_RULES.md` (wrapper pattern, DB, POJOs, config)

When generating code, prefer copying patterns from these existing tests and only deviate when the contributor explicitly requests a different approach.
