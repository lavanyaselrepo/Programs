---
name: mobile-automator-mcp-workflow
description: Execute mobile tests via MCP, generate tests from device actions, or plan test scenarios. Fetches execution guidelines first (mobile-automator MCP resource), runs the automatic post-execution pipeline (generate_test_from_actions then adapt to framework), and applies framework patterns. Use when the user asks to execute a test case, generate tests, create test files, or work with mobile automator MCP tools.
---

# Mobile Automator MCP Workflow

## Step 0: Read rule + skill first, then fetch guidelines (mandatory)

Before any execution or test generation:

1. **Read the project instruction** `.github/instructions/mobile-automator-mcp.instructions.md` so you follow the correct workflow (when to ask for data, which login tool to use, pipeline).
2. **Baseline (reach Pharmacy Dashboard)** is defined only in this skill and the MCP guidelines. Do **not** search the repo for sign-in, navigate to Pharmacy, or PIN steps. Follow the "Reaching Pharmacy Dashboard" section below.
3. **Fetch execution guidelines**: Call **fetch_mcp_resource** with `uri`: `"guidelines://mobile-test-automation"` and `server` set to the **exact MCP server name** from Cursor's config (e.g. `"mobile-automator"` or `"user-mobile-automator"`). If you get "Server not found", the mobile automator may be registered under a different name (check Cursor Settings → MCP) or may expose only tools, not resources. Use **list_mcp_resources()** to see available servers/resources. **If the resource is unavailable**, proceed with this rule and skill only—they define the workflow; do not block.
4. That resource (when available) contains: baseline steps (launch/Teflon, then login tool), when to ask for user data, and platform details. Do not execute or generate tests without reading this skill; use the guidelines when the resource loads, otherwise use this skill and the rule.

---

## Reaching Pharmacy Dashboard (Android)

**Before doing anything, ask two upfront questions:**

**Q1 — Teflon:**
> "Does the app need to be pointed to Teflon? (Yes / No)"
>
> - **Yes** → `setup_android_app` → sign in → navigate to Pharmacy Dashboard
> - **No** → skip `setup_android_app`; only launch the app if not already open, sign in if needed, navigate to PD
> - ❌ Never call `setup_android_app` without asking this — the user may already be signed in and configured

**Q2 — Evidence report:**
> "Would you like an HTML evidence report with screenshots generated after execution? (Yes / No)"
>
> - **Yes** → include `captureLabel`, `captureDescription`, `captureStatus` in every `get_page_elements` call during execution.
> - **No** → skip `captureLabel` in all `get_page_elements` calls — no buffering, no report.

| Q1 Answer | Action |
|---|---|
| Yes — needs Teflon | `setup_android_app` → sign in → navigate to Pharmacy Dashboard |
| No — already configured | Skip `setup_android_app`; launch app if not open, sign in if needed, navigate to PD |

❌ Never call `setup_android_app` without asking Q1 first.

**Full baseline (when setup is needed):**

```
1. setup_android_app(deviceId)
      → Teflon + Skip Step up + skip onboarding + kills app
      → Relaunches via pharmacy deep link → dismisses popup
      → Stops on pharmacy dashboard (does NOT sign in)
2a. get_page_elements(deviceId)   ← ALWAYS call before each click
2b. click_element(deviceId, id=<"Sign in or create account" resource-id>)
      or click_element(deviceId, text="Sign in or create account")
2c. input_text(deviceId, id=<email field resource-id>, text=<email>)
2d. click_element(deviceId, text="Continue")
   ── "Welcome back!" auth method screen may appear ──
2e. get_page_elements(deviceId)  ← check screen state
2f. click_element(deviceId, id=<auth_choice_radio_button_password>)
      → ALWAYS select "Enter your password" — NEVER "Send code" options
2g. input_text(deviceId, id=<password field resource-id>, text=<password>)
2h. click_element(deviceId, text="Sign in")   ← no OTP (Skip Step up enabled)
3. Enter PIN 1111 if pharmacy-connected account
```

- **Pharmacy-connected account**: ask for email, password, PIN. After sign-in, enter PIN `1111`. Outcome: Pharmacy Dashboard with PIN verified.
- **Non-pharmacy-connected account**: ask for email and password only (no PIN). After sign-in, verify "Connect account" CTA is visible. No PIN entry.
- **SMS create account, connect to pharmacy, connect account:** Sign in first (email + password only). Do **not** ask for phone/OTP upfront — those come later when the app prompts.
- **If `setup_android_app` reports teflon configured but deep link failed:** call `open_pharmacy_dashboard` to retry — do NOT re-run `setup_android_app`.
- **If sign-in form is already visible** (email field on screen): do NOT dismiss it. Continue on that screen.
- **If a popup appears during sign-in:** dismiss it by `id` (from `get_page_elements`), then call `get_page_elements` again to confirm — do NOT repeat the last action blindly.

**Generated test code must always be self-contained:** even if you skipped setup during execution (because the app was already running), always include the full setup sequence in the actions list passed to `generate_test_from_actions`. The test must run correctly on a fresh device with nothing pre-configured.

---

## Dropdown selections: always use select_dropdown_option

**Whenever the app shows a dropdown, spinner, or picker and the user says "select [option]":**

1. **Always** call `get_page_elements(deviceId)` first to identify the dropdown trigger element.
2. **Always** use `select_dropdown_option` tool (NOT `click_element`) to handle any dropdown/spinner/picker selection:
   - `id` — resource-id or accessibility-id of the dropdown trigger (preferred over xpath)
   - `optionText` — exact visible label of the option (case-sensitive)
   - `deviceId`, and optionally `platform` and `appPackage`
3. **Never** use a two-step `click_element` (open) + `click_element` (pick option) pattern when a dropdown tool is available.
4. **Applies to:** dropdowns, spinners, PickerWheels, select lists — on both Android and iOS.

**Example:**
```
User: "Select Male from the gender dropdown"
→ get_page_elements(deviceId)          ← find dropdown trigger id
→ select_dropdown_option(deviceId, id=<gender_dropdown_id>, optionText="Male")
```

---

## Runtime data during execution (applies to ALL flows)

**CRITICAL: When the app prompts for input during execution, always ask the user for the value:**

- ✅ **Ask user during execution for:** phone number, OTP, date of birth, address, zip code, prescription number, Rx details, insurance card info, family member details, payment info, etc. (any field the app prompts for)
- ❌ **Never enter:** test data, dummy values, or hardcoded information without asking the user
- ⏸️ **Pause and ask:** When the app shows an input field, stop execution and ask: "The app is asking for [field name]. What value should I enter?"
- ▶️ **Resume after user provides the value**

**This applies to ALL flows, not just account creation flows.**

---

## Execution vs planning vs implementation

| User intent                                      | Action                                                               | Stop and ask?                            |
| ------------------------------------------------ | -------------------------------------------------------------------- | ---------------------------------------- |
| **Execute test case [ID]**                       | Ask for data → Execute on device → Auto pipeline (generate + adapt)  | No; complete pipeline in one go          |
| **Execute [testMethodName] test on [platform]**  | Search for existing test → Read test + fetch guidelines → Execute using both → Update Page Objects with new platform locators | No; complete pipeline in one go |
| **Generate test cases**                          | Call `generate_tests_planning` → Show scenarios from TESTS.md/PRD    | Yes; ask if they want test files created |
| **Create test files / Implement tests**          | Create .java tests, Page Objects, test data using framework patterns | Only after user confirmed from planning  |

---

## Cross-platform execution (test already exists on another platform)

**When user specifies a test name + platform** (e.g., "execute testSMSCreateAccountFlowForSelf test on iOS"):

1. **Search for existing test:** Use Grep to find the test method name in `pharmacy-ui/src/test/java/mobile-e2e-tests/`
2. **If test found (automated on another platform):**
   - Read the existing test file to understand the test logic and flow
   - Read the Page Objects used in the test
   - **Read existing methods used in the test** (from BasePageApplicationManager and platform managers)
   - Fetch execution guidelines from MCP for the **requested platform** (e.g., iOS)
   - **Execute using both sources:**
     - Use MCP guidelines for platform-specific baseline (launch, setup, login for iOS)
     - Follow the test logic/steps from the existing test file
     - Use `get_page_elements` during execution to find platform-specific locators
   - **After execution, update both locators AND methods:**
     - **Update Page Objects:** Add locators for the newly executed platform (e.g., add `@iOSXCUITFindBy` if iOS was executed)
     - **Analyze existing methods:** Compare method implementations with actual execution steps on new platform
     - **Update methods if needed:** If execution revealed platform differences, create override in platform-specific manager OR update base method
   - **Result:** Same test now supports both platforms (original + newly executed), with updated locators and methods
3. **If test NOT found:** Proceed with normal execution and create test file

---

## Automatic pipeline after test execution

When a test has been executed on device, do **all** of the following without stopping or asking:

0. **During execution (only if user said Yes to report):**
   Every `get_page_elements` call must include `captureLabel` so the screenshot is buffered in the same single call:
   ```
   get_page_elements(deviceId, captureLabel="<screen name>", captureDescription="<what was done or validated>", captureStatus="pass|fail|info")
   ```
   - **If user said No to report**: call `get_page_elements` without `captureLabel` — do not buffer anything.
   - Do **NOT** call `capture_screen_for_report` separately — `captureLabel` handles buffering in one step.
   - Use `captureStatus="pass"` when verifying expected outcomes, `"fail"` for errors/failures, `"info"` for neutral navigation.
   - The text response from `get_page_elements` will confirm `[Report buffer] Screenshot buffered as "..."` so you can verify it was captured.

1. **Generate report only if user said Yes at the start of execution:**
   - If **Yes**:
     1. Call `preview_report_buffer(deviceId)` — verify all expected screens are present. Add any missing ones with `capture_screen_for_report`.
     2. Call `generate_flow_report`:
        - `flowName`: descriptive name of the test scenario
        - `platform`: android or ios
        - `deviceId`: the device used
        - `outputPath`: `~/Desktop/[scenario-name]-report.html` (or user-specified path)
        - `tester`: use name already provided, or ask if not known
        - **Do NOT pass `screenshots`** — buffered screenshots are used automatically
   - If **No**: Skip entirely — do not call `generate_flow_report`.

2. Ask the user: **"Would you like a test script generated from the recorded actions? (Yes / No)"**
   - If **Yes**: Call `generate_test_from_actions` with the documented actions, then complete the full framework adaptation pipeline (steps 3–14 below).
   - If **No**: Skip test generation entirely.

3. **MANDATORY: Thorough search for existing methods FIRST** - before creating anything new:
   - **Use multiple search terms and variations** - for "close consent", search: `close.*consent`, `dismiss.*consent`, `close.*delivery`, `consent.*popup`, etc.
   - Check `BasePageApplicationManager` for existing wrapper methods (search with variations)
   - **Check BasePage and parent classes** - many reusable generic methods exist (`clickElement()`, `waitForElement()`, `verifyElement()`, etc.)
   - Check platform-specific managers (`AndroidPageManager`, `IOSPageManager`) for overrides
   - Check existing Page Objects for locators and methods
   - **Read the found methods** to understand what they do (don't just rely on names)
   - **REUSE existing methods** - do NOT create duplicates
   - **Common mistakes to avoid:**
     - Creating `closeDeliveryConsent()` when `dismissDeliveryConsentPopup()` already exists
     - Creating `verifyDeliveryAddress()` when `validateDeliveryAddressDisplayed()` already exists
     - Creating platform-specific method in IOSPageManager when BasePage method can be used
4. **Verify no duplicates before creating new methods:**
   - For EACH action, re-confirm a method doesn't already exist
   - If unsure, search again with different keywords
   - **NEVER create a new method without completing thorough search in step 3**
5. **Check if BasePage/parent class methods can be used:**
   - Before creating a new method in platform managers, check if generic BasePage method handles it
   - Example: Use `clickElement(locator)` from BasePage instead of creating `clickCloseButton()` in IOSPageManager
   - Example: Use `waitForElement(locator)` instead of creating `waitForAddressField()`
   - Only create platform-specific methods when there's a genuine platform difference (not just a simple click/wait/verify)
6. **Analyze existing methods against execution** (especially for cross-platform):
   - Read the implementation of existing methods that were used
   - Compare with actual execution steps performed on the platform
   - Identify if platform differences exist (different locators, different flow, different behavior)
   - Document findings: which methods work as-is, which need platform-specific overrides
7. **Update or override existing methods based on execution findings:**
   - If execution revealed the existing method works on the new platform → reuse as-is (no changes needed)
   - If execution revealed different locators/behavior → Create platform-specific override (e.g., in IOSPageManager) OR update base method
   - **For cross-platform**: Add new platform locators to existing Page Objects (don't create new Page Objects if they already exist)
8. **For NEW methods that genuinely don't exist** (only after step 3 search confirms):
   - Add to `BasePageApplicationManager` FIRST with full implementation
   - Override in platform managers ONLY when platform differences are discovered
9. **Verify and update locators**: Compare execution xpaths with existing Page Object locators. Use EXACT xpaths from execution (content-desc/accessibility-id preferred). **CRITICAL: Only update locators for the platform executed.**
   - Add comment: `// Note: Only [Platform] locators added - executed on [Platform] only`
   - Add TODO: `// TODO: Add [Other Platform] locators when flow is executed on [Other Platform]`
10. **For cross-platform execution**: Add new platform locators (e.g., `@iOSXCUITFindBy`) alongside existing ones in existing Page Objects.
11. **Test organization:**
    - **If cross-platform (test already exists):** Update the existing test file's Page Objects with new platform locators. The same test method can now run on both platforms.
    - **If new test:** Check if a test file for this feature already exists (e.g., `CompetitiveTransferConnectedUserTest.java`)
    - Add new test method to existing file if it's related (e.g., family member variant goes in same file as primary profile test)
    - Create new test file ONLY if it's a completely different feature
    - **Write test class under `pharmacy-ui/src/test/java/mobile-e2e-tests/`** (package `mobile.e2e.tests` or a subpackage)
12. Add test data to **`pharmacy-ui/src/test/java/mobile-e2e-tests/testdata/mobileE2ETestData.json`** (NOT dpTestDataCreationJob.json). Create the file if it doesn't exist.
13. **Final verification before presenting**: Review all methods used in adapted test and confirm:
    - NO duplicate methods were created (thorough search completed)
    - NO platform-specific methods created when BasePage methods could be used
    - ALL existing methods were properly reused
    - Only genuinely new methods (that don't exist anywhere) were added
14. Present the **final framework-adapted** test showing:
    - Which existing methods were reused (unchanged)
    - **Which existing methods were updated/overridden** for new platform (explain what changed and why)
    - Which new methods were added (if any) - **ONLY if they truly didn't exist after thorough search**
    - Which locators were updated (for which platform)
    - **For cross-platform**: Which Page Objects now support both platforms

Do **not** stop after execution to say "Test complete" or wait for "continue". Do **not** deliver only the raw `generate_test_from_actions` result.

---

## Framework adaptation (summary)

When adapting generated tests to this framework (AutomationBaseFramework / pharmacy-ui):

### 1. Reuse Pattern (CRITICAL - Check First!)

- **ALWAYS search existing methods first with MULTIPLE search terms** before creating new ones
- **Search order**: `BasePageApplicationManager` → **BasePage/parent classes** → Platform managers → Page Objects
- **Use multiple keywords**: For "close consent", search: `close.*consent`, `dismiss.*consent`, `close.*delivery`, `consent.*popup`
- **Read found methods** to understand what they do (don't just rely on names)
- Many flows already exist (e.g. `proceedToPharmacyDashboard()` includes PIN entry, `selectPrimaryProfileForTransfer()` includes non-Walmart selection)
- **Do NOT duplicate** methods that already exist
- **Common mistakes (MUST AVOID):**
  - ❌ Creating `closeDeliveryConsent()` when `dismissDeliveryConsentPopup()` already exists
  - ❌ Creating `verifyDeliveryAddress()` when `validateDeliveryAddressDisplayed()` already exists
  - ❌ Creating method in IOSPageManager when BasePage method (e.g., `clickElement()`) can be used
  - ❌ Creating simple wrapper methods instead of using base class methods directly
- **For cross-platform execution**: Analyze existing methods against actual execution steps to identify if platform-specific overrides are needed
- **Update existing methods** if execution revealed different behavior on new platform (create override or improve base implementation)
- **Do NOT add methods to `BasePageApplicationManager`** if only needed for mobile - use platform-specific managers instead

### 2. Where to Add New Methods (CRITICAL Decision Tree)

**For NEW methods that don't exist anywhere:**

1. ✅ **Add to `BasePageApplicationManager` FIRST** with full implementation
2. ⏸️ **Wait to override** - Don't create platform-specific code prematurely
3. 🔍 **Override ONLY when you discover platform differences**
   - When implementing iOS and it needs different approach → Override in `IOSPageManager`
   - When Android needs different behavior → Override in `AndroidPageManager`
   - If all platforms work the same → Keep ONLY base implementation

**For EXISTING methods:**

- **Android-specific behavior**: Add overrides to `AndroidPageManager` (e.g. `proceedToPharmacyDashboard()` handles deep links, PIN, permissions)
- **iOS-specific behavior**: Add overrides to `IOSPageManager`
- **Cross-platform (WEB + Mobile)**: Only then add to `BasePageApplicationManager`
- **Single-platform execution**: If you only executed on Android, do NOT add iOS implementations

**Decision Example:**

```
New method: selectFamilyMemberForTransfer()
├─ Step 1: Add to BasePageApplicationManager with full implementation ✅
├─ Step 2: Test on Android → Works ✅
├─ Step 3: Later test on iOS
│  ├─ Same XPath works? → Keep only base implementation ✅
│  └─ Different locator needed? → Override in IOSPageManager ✅
```

### 3. Locator Strategy (Prefer Specific over Generic)

- ✅ **Prefer**: `description("Medication name*")` or `id("com.walmart.android.debug:id/field_name")`
- ⚠️ **Avoid**: `className("android.widget.EditText").instance(1)` - fragile, breaks with page changes
- **Update existing locators** if execution found more specific ones (content-desc vs instance)
- **Only update the platform executed** (don't add iOS locators if you only ran on Android)
- **CRITICAL - Only update the platform executed**:
  - Don't add iOS locators if you only ran on Android
  - Don't add Android locators if you only ran on iOS
  - Don't add Web locators unless executed on Web
  - Add comment: `// Note: Only [Platform] locators added - executed on [Platform] only`
  - Add TODO: `// TODO: Add [Other Platform] locators when flow is executed on [Other Platform]`

### 4. Test Structure

- **Structure:** Test class extends the project test base (e.g. `DigitalPharmacyTestBase`); uses `@BeforeMethod` (launch app, get page manager), `@Test` (with `Method` for test data), `@AfterMethod` (screenshot on failure, quit driver).
- **Abstraction:** Tests call **existing wrapper methods** on `BasePageApplicationManager`; Page Objects hold low-level locators and interactions.

### 5. Test Data Location

- **Mobile E2E tests**: `pharmacy-ui/src/test/java/mobile-e2e-tests/testdata/mobileE2ETestData.json`
- **NOT**: `dpTestDataCreationJob.json` (that's for other tests)
- **Key**: test method name
- **Load via**: `commonUtilsForData.getJsonTestData(testDataJsonPath, method.getName())`

### 6. Naming

- Descriptive test class and method names (e.g. `testCompetitiveTransferFromNonWalmartPharmacyVerifyTrackerCard`)
- Page Object and method names clear and camelCase

For full patterns (reusability, platform override, Page Object vs wrapper, naming, test data shape, decision tree, completion checklist), see [framework-patterns.md](framework-patterns.md).

---

## Checklist before delivering

### Before Execution

- [ ] Execution guidelines fetched before any run or generation.
- [ ] **For cross-platform execution**: Searched for existing test in codebase and read test file + Page Objects.
- [ ] **For cross-platform execution**: Combined existing test logic with platform-specific MCP guidelines.
- [ ] For "execute test case": user data requested and confirmed.
- [ ] Asked user **Q1 — Teflon** ("Does the app need to be pointed to Teflon?") before any setup/launch tool.
- [ ] Asked user **Q2 — evidence report** (Yes / No) before starting execution. Answer saved.

### During Execution

- [ ] Ask user for runtime data when app prompts (phone, OTP, Rx number, etc.)
- [ ] Document all actions performed for test generation.
- [ ] If report = Yes: every `get_page_elements` call included `captureLabel`, `captureDescription`, `captureStatus`.
- [ ] If report = No: `get_page_elements` called without `captureLabel` — no buffering done.

### After Execution - Automatic Pipeline

- [ ] If yes to Q2: called `preview_report_buffer` first to verify all screens are in the buffer.
- [ ] If yes: any missing screens were captured with `capture_screen_for_report` before generating.
- [ ] If yes: `generate_flow_report` called (no `screenshots` param — buffered automatically).
- [ ] Asked user if they want a test script generated.
- [ ] If yes: `generate_test_from_actions` called with all actions.
- [ ] **Thorough search for existing methods** completed with multiple search terms/variations.
- [ ] **Searched BasePage and parent classes** for generic methods before creating new ones.
- [ ] **Verified no duplicates** - confirmed methods like `dismissDeliveryConsentPopup()`, `validateDeliveryAddressDisplayed()` don't already exist before creating similar ones.
- [ ] **Analyzed existing methods** against actual execution steps to identify platform differences.
- [ ] **Updated/overridden existing methods** based on execution findings (created platform-specific overrides or improved base methods as needed).
- [ ] **Reused existing methods** (unchanged) where they work for the new platform.
- [ ] **For NEW methods (only if truly don't exist)**: Added to `BasePageApplicationManager` FIRST (not platform managers).
- [ ] **Override decision**: Only override in platform managers when genuine platform differences discovered (not for simple clicks/waits).
- [ ] **Test organization**: Checked for existing related test files and clubbed similar tests together.
- [ ] **Verified and updated locators** to use content-desc/accessibility-id (not instance numbers).
- [ ] **For cross-platform execution**: Added new platform locators to existing Page Objects (e.g., added `@iOSXCUITFindBy` to Page Objects that previously only had `@AndroidFindBy`).
- [ ] **For single-platform execution**: Only updated platform executed (no iOS changes if only Android was run, no Android changes if only iOS was run).
- [ ] **Added comments in Page Objects** indicating which platform(s) locators were added and TODO for remaining platforms (if any).
- [ ] **NEW Page Objects created** (if any) have ONLY the executed platform's locators with appropriate comments.
- [ ] Test data added to `mobile-e2e-tests/testdata/mobileE2ETestData.json`.
- [ ] Test file created/updated in `mobile-e2e-tests/` directory (clubbed with related tests if applicable, or updated existing test for cross-platform support).
- [ ] **Final verification completed**:
  - [ ] NO duplicate methods created (thorough search was done)
  - [ ] NO unnecessary platform-specific methods (BasePage methods used where appropriate)
  - [ ] ALL existing methods properly reused
- [ ] Delivered artifact is framework-adapted showing:
  - Which existing methods were reused (unchanged)
  - **Which existing methods were updated/overridden** and why (based on execution evidence)
  - Which new methods added (if any) - **ONLY if they truly didn't exist**
  - Updated locators (for which platform)
  - Clubbed tests
  - Cross-platform support (if applicable)

### For Planning Mode

- [ ] For "generate test cases": only planning shown; user asked before creating files.
