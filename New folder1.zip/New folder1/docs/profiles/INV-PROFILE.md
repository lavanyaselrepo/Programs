# INV (Inventory) Maven Profile Documentation

## Overview

The `inv` Maven profile is a team-scoped build configuration that optimizes build times and isolates dependencies specifically for the **Inventory (INV)** test suite. This profile allows INV team members to compile and run only inventory-related tests without affecting other teams or triggering a full project build.

---

## Table of Contents

1. [Why Use the INV Profile?](#why-use-the-inv-profile)
2. [Profile Configuration Details](#profile-configuration-details)
3. [Comparison: With Profile vs Without Profile](#comparison-with-profile-vs-without-profile)
4. [Usage Guide](#usage-guide)
5. [Dependencies Included](#dependencies-included)
6. [Troubleshooting](#troubleshooting)
7. [For Other Teams](#for-other-teams)

---

## Why Use the INV Profile?

### Problems Solved

| Problem | Solution |
|---------|----------|
| **Slow build times** | Only compiles `inv/**/*.java` instead of entire codebase |
| **Dependency conflicts** | Isolates INV-specific deps (google-auth 1.23.0) without affecting other teams |
| **DragonLibrary google-auth issue** | Bundles google-auth 1.23.0 to fix `getUniverseDomain()` missing method |
| **Test isolation** | Run only inventory tests via `-Dsurefire.suiteXmlFiles=...` |

### The DragonLibrary Problem

`DragonLibrary` is a **fat JAR** that bundles `google-auth-library-credentials 1.5.3` internally. This old version lacks the `getUniverseDomain()` method required by newer Google Cloud libraries.

**Error without fix:**
```
java.lang.NoSuchMethodError: 'java.lang.String com.google.auth.oauth2.ServiceAccountCredentials.getUniverseDomain()'
```

**Solution in INV Profile:**
The profile declares `google-auth 1.23.0` explicitly, which provides the missing method for INV tests that use GCP services (BigQuery, Cloud Storage).

---

## Profile Configuration Details

### Location
`pom.xml` → `<profiles>` → `<profile id="inv">`

### Components

```xml
<profile>
    <id>inv</id>
    
    <!-- 1. Properties -->
    <properties>
        <testType>e2e</testType>
        <sendReportEmail>false</sendReportEmail>
        <enableTestBurst>false</enableTestBurst>
    </properties>
    
    <!-- 2. Dependencies (INV-specific) -->
    <dependencies>
        <!-- Google Auth 1.23.0 - fixes getUniverseDomain() -->
        <dependency>
            <groupId>com.google.auth</groupId>
            <artifactId>google-auth-library-credentials</artifactId>
            <version>1.23.0</version>
        </dependency>
        <dependency>
            <groupId>com.google.auth</groupId>
            <artifactId>google-auth-library-oauth2-http</artifactId>
            <version>1.23.0</version>
        </dependency>
        
        <!-- Google Cloud Storage & BigQuery with auth exclusions -->
        <!-- ... -->
    </dependencies>
    
    <!-- 3. Build Configuration -->
    <build>
        <plugins>
            <!-- Compiler: Only compile inv/**/*.java -->
            <plugin>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <testIncludes>
                        <testInclude>inv/**/*.java</testInclude>
                        <testInclude>hwqe/baseframework/**/*.java</testInclude>
                    </testIncludes>
                </configuration>
            </plugin>
        </plugins>
    </build>
</profile>
```

---

## Comparison: With Profile vs Without Profile

### Build Time Comparison

| Scenario | Without Profile | With `-Pinv` Profile |
|----------|-----------------|----------------------|
| **Test Compilation** | Compiles ALL test classes (~5000+ files) | Compiles only `inv/**/*.java` (~200 files) |
| **Estimated Time** | 3-5 minutes | 30-60 seconds |
| **Memory Usage** | High (full classpath) | Lower (scoped deps) |

### Dependency Scope

| Aspect | Without Profile | With `-Pinv` Profile |
|--------|-----------------|----------------------|
| **google-auth version** | 1.5.3 (from DragonLibrary) | 1.23.0 (explicit) |
| **google-cloud-storage** | 1.17.0 (old) | 2.30.1 (upgraded) |
| **google-cloud-bigquery** | 2.56.0 | 2.34.2 (with exclusions) |
| **GCP compatibility** | `getUniverseDomain()` error | Works correctly |

### Test Execution

| Command | Without Profile | With `-Pinv` Profile |
|---------|-----------------|----------------------|
| Run specific suite | `mvn test -Dsurefire.suiteXmlFiles=...` | `mvn test -Pinv -Dsurefire.suiteXmlFiles=...` |
| Compilation scope | Full project | INV tests only |
| Other teams affected? | Yes (shared classpath) | No (isolated) |

---

## Usage Guide

### Basic Commands

**1. Compile INV tests only (no execution):**
```bash
mvn test-compile -Pinv
```

**2. Run a specific INV test suite:**
```bash
mvn test -Pinv -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/inv/vendorreturns/VendorReturns.xml
```

**3. Run multiple suites:**
```bash
mvn test -Pinv -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/inv/acsi/acsiTest.xml,src/test/resources/suites/inv/acp/suppliercost.xml
```

**4. Run with different environment:**
```bash
mvn test -Pinv -DtestEnvironment=qe -Dsurefire.suiteXmlFiles=src/test/resources/suites/inv/cyclecount/CycleCountInCloudTest.xml
```

### IntelliJ IDEA Setup

**Option 1: Maven Tool Window**
1. Open **View → Tool Windows → Maven**
2. Expand **Profiles**
3. Check ✅ `inv`
4. Right-click test class → **Run**

**Option 2: Run Configuration**
1. **Run → Edit Configurations → + → Maven**
2. **Command line:** `test -Pinv -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/inv/vendorreturns/VendorReturns.xml`
3. **Name:** `INV - VendorReturns`
4. Click **OK** → **Run**

### Looper CI/CD Pipeline

In your Looper pipeline YAML:
```yaml
stages:
  - name: inv-tests
    maven:
      goals: test
      profiles:
        - inv
      properties:
        testEnvironment: ${ENV}
        surefire.suiteXmlFiles: src/test/resources/suites/inv/vendorreturns/VendorReturns.xml
```

Or via `mvn_args`:
```yaml
mvn_args: "test -Pinv -DtestEnvironment=${ENV} -Dsurefire.suiteXmlFiles=src/test/resources/suites/inv/vendorreturns/VendorReturns.xml"
```

---

## Dependencies Included

The INV profile adds these dependencies **only when activated**:

| Dependency | Version | Purpose |
|------------|---------|---------|
| `google-auth-library-credentials` | 1.23.0 | Fixes `getUniverseDomain()` method |
| `google-auth-library-oauth2-http` | 1.23.0 | OAuth2 HTTP transport for GCP |
| `google-cloud-storage` | 2.30.1 | GCP Storage API (with auth exclusions) |
| `google-cloud-bigquery` | 2.34.2 | GCP BigQuery API (with auth exclusions) |

### Why Exclusions?

The `google-cloud-storage` and `google-cloud-bigquery` dependencies have exclusions for `google-auth-library-*` to prevent version conflicts. This ensures the explicit 1.23.0 version is used instead of whatever version these libraries transitively depend on.

---

## Troubleshooting

### Error: `getUniverseDomain()` method not found

**Cause:** DragonLibrary's bundled google-auth 1.5.3 is being loaded instead of 1.23.0.

**Solution:** Ensure you're using the `-Pinv` profile:
```bash
mvn test -Pinv -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=...
```

**Alternative:** Use the standalone `inv-pom.xml`:
```bash
mvn -f inv-pom.xml test -DskipTests=false -Dsurefire.suiteXmlFiles=...
```

### Error: Test class not found

**Cause:** The test class is not in the `inv/**/*.java` path.

**Solution:** Check that your test class is located under `src/test/java/inv/`.

### Error: Suite XML not found

**Cause:** Invalid path to suite XML file.

**Solution:** Verify the path exists:
```bash
ls src/test/resources/suites/inv/
```

### Slow compilation despite using profile

**Cause:** Main sources still being compiled.

**Solution:** Use `test-compile` instead of `compile`:
```bash
mvn test-compile -Pinv
```

---

## For Other Teams

Want to create a similar profile for your team? See:

- **Wibey Skill:** Use `/mvn-profile-gen` to generate a profile automatically
- **Manual Guide:** See [Creating Team Profiles](#creating-team-profiles-manually) below

### Creating Team Profiles Manually

1. **Identify your test folder:** e.g., `src/test/java/connexus/`
2. **Find your suite XMLs:** e.g., `src/test/resources/suites/connexus/`
3. **Add a profile to pom.xml:**

```xml
<profile>
    <id>your-team-id</id>
    <properties>
        <testType>e2e</testType>
    </properties>
    <!-- Add team-specific dependencies here if needed -->
    <dependencies>
        <!-- ... -->
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>21</source>
                    <target>21</target>
                    <testIncludes>
                        <testInclude>your-folder/**/*.java</testInclude>
                        <testInclude>hwqe/baseframework/**/*.java</testInclude>
                    </testIncludes>
                    <annotationProcessorPaths>
                        <path>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                            <version>1.18.38</version>
                        </path>
                    </annotationProcessorPaths>
                </configuration>
            </plugin>
        </plugins>
    </build>
</profile>
```

4. **Run with your profile:**
```bash
mvn test -Pyour-team-id -DtestEnvironment=dev -Dsurefire.suiteXmlFiles=src/test/resources/suites/your-folder/your-suite.xml
```

---

## Available INV Test Suites

| Category | Suite Path |
|----------|------------|
| ACSI | `suites/inv/acsi/acsiTest.xml` |
| ACSI RxOne | `suites/inv/acsiRxOne/AcsiRxOne.xml` |
| ACSI Reporting | `suites/inv/acsiReportingTool/acsiReportingTool.xml` |
| ACP | `suites/inv/acp/suppliercost.xml`, `avgcostcalprocess.xml`, `acpotcinei.xml` |
| Count Inventory | `suites/inv/countinv/countInventory.xml` |
| Cycle Count | `suites/inv/cyclecount/CycleCountInCloudTest.xml` |
| Drug Diversion | `suites/inv/drugdiversion/drugDiversionTest.xml` |
| Get/Set Onhands | `suites/inv/getonhands/getOnhandsTest.xml`, `setonhands/setOnhandsTest.xml` |
| Inbound Receiving | `suites/inv/inboundrcv/InboundRcv.xml` |
| Pharmacy Profile | `suites/inv/pharmacyprofile/pharmacyprofile.xml` |
| SLES | `suites/inv/sles/*.xml` (9 suites) |
| Smart Cloud Services | `suites/inv/smart_cloudservices/*.xml` (5 suites) |
| Smart Elimination | `suites/inv/smart_elimination/*.xml` (9 suites) |
| Vendor Returns | `suites/inv/vendorreturns/VendorReturns.xml` |

---

## Changelog

| Date | Change | Author |
|------|--------|--------|
| 2026-05-06 | Initial INV profile creation with google-auth 1.23.0 fix | Wibey |

---

## Contact

For questions about the INV profile, reach out to the **Inventory (INV) team** or ask in **#wibey** on Slack.
