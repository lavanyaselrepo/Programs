# Windsurf Web Application Automation Rules & Guidelines

## Overview

This document defines the mandatory rules and best practices for creating web application automation scripts in the AutomationBaseFramework. Follow these guidelines to ensure consistency, maintainability, and reliability across all web UI test automation.

---

## 🏗️ Architecture Pattern (Page Object Model)

### 1. Page Object Model Structure

**MANDATORY**: Every web page must have a dedicated Page Object Model class.

**Hierarchy:**

```
WebAndMobileBasePage (Parent)
    ↓
YourPageClass extends WebAndMobileBasePage
```

**Structure:**

```
src/main/java/hwqe/baseframework/models/pageobjectmodels/<domain>/<feature>/
├── pages/
│   ├── CreatePatientPage.java
│   ├── LoginPage.java
│   └── HomePage.java
├── utility/
│   ├── <Domain>BaseDriver.java
│   ├── <Domain>BaseAppManager.java
│   └── WebAndMobileBasePage.java
```

**Requirements:**

- Extends `WebAndMobileBasePage`
- Contains web element locators using `By` objects
- Implements action methods for UI interactions
- Uses proper naming conventions
- Includes validation methods

---

## 🎯 Page Object Model Implementation

### Element Declaration Pattern

**MANDATORY**: Use `private final By` for all web elements.

```java
// ✅ Correct Pattern
private final By prescriberRadioBtn = By.xpath("(//input[@type='radio'])[1]");
private final By createPatientBtn = By.id("create-new-patient-button");
private final By prescriberNameInput = By.xpath("//input[@placeholder='Search Provider']");

// ❌ Avoid
@FindBy(id = "create-new-patient-button")
WebElement createPatientBtn;
```

### Action Methods Pattern

**Structure:**

```java
public void methodName(parameters) {
    // Perform actions using inherited methods from WebAndMobileBasePage
    click(elementLocator);
    sendText(inputLocator, text);

    // Add validations
    if (isElementDisplayed(expectedElement)) {
        // Success path
    } else {
        Reporter.logScreenShot("Error message", takeScreenShot());
    }
}
```

**Example:**

```java
public void chooseProvider(String pharmacistName) {
    click(chooseRenderingPharmacistBtn);
    if (isElementDisplayed(prescriberNameInput)) {
        sendText(prescriberNameInput, pharmacistName);
        click(prescriberSearchBtn);
        click(prescriberRadioBtn);
        if (isElementEnabled(useSelectedProviderBtn)) {
            click(useSelectedProviderBtn);
        }
    } else {
        Reporter.logScreenShot("Failed to select Rendering Pharmacist", takeScreenShot());
    }
}
```

---

## 🧪 Test Class Implementation

### Test Class Structure

**Location:** `src/test/java/<domain>/<feature>/`

**Requirements:**

- Initialize WebDriver from BaseDriver class
- Use AppManager for page interactions
- Include proper TestNG annotations
- Implement comprehensive assertions
- Add screenshot logging for verification

### Test Method Pattern

```java
@Test
public void testMethodName(String param1, String param2, String param3) {
    // Step 1: Initialize WebDriver
    webDriver = <Domain>BaseDriver.getWebDriver(platform, version, this.getClass().getSimpleName());

    // Step 2: Initialize AppManager
    appManager = new <Domain>BaseAppManager(webDriver);

    // Step 3: Navigate to application
    webDriver.get(appManager.applicationURL());
    webDriver.navigate().refresh();

    // Step 4: Perform login
    appManager.login.loginSSO();
    appManager.login.performLogin(credentials);

    // Step 5: Execute test steps with assertions
    appManager.createPatientWithRandomInfo(false);
    Assert.assertTrue(appManager.createPage.IsDisplayedAdServiceTypeBtn());
    Reporter.logScreenShot("Created patient successfully", appManager.createPage.takeScreenShot());

    // Step 6: Continue test flow with validations
    // ... additional test steps
}
```

---

## 🔧 Base Classes and Utilities

### WebDriver Initialization

**Base Driver Class:** `src/main/java/hwqe/baseframework/models/pageobjectmodels/<domain>/utility/<Domain>BaseDriver.java`

**Pattern:**

```java
public static WebDriver getWebDriver(String platform, String version, String testClassName) {
    // WebDriver initialization logic
    // Platform-specific driver setup (Chrome, Firefox, Safari, etc.)
    // Version handling
    // Test-specific configurations
    return driver;
}
```

### Base App Manager

**Location:** `src/main/java/hwqe/baseframework/models/pageobjectmodels/<domain>/utility/<Domain>BaseAppManager.java`

**Pattern:**

```java
public class SuperMarioBaseAppManager {
    public LoginPage login;
    public CreatePatientPage createPage;
    public CreateOrderPage createOrderPage;

    public SuperMarioBaseAppManager(WebDriver driver) {
        this.login = new LoginPage(driver);
        this.createPage = new CreatePatientPage(driver);
        this.createOrderPage = new CreateOrderPage(driver);
    }

    public String healthServicePortalURL() {
        return PropertyReader.getInstance().getProperty("app.url");
    }
}
```

### WebAndMobileBasePage

**Location:** `src/main/java/hwqe/baseframework/models/pageobjectmodels/<domain>/utility/WebAndMobileBasePage.java`

**Inherited Methods:**

- `click(By locator)`
- `sendText(By locator, String text)`
- `isElementDisplayed(By locator)`
- `isElementEnabled(By locator)`
- `takeScreenShot()`
- `waitForElement(By locator)`

---

## 📋 TestNG Suite Configuration

### Suite Structure

**Location:** `src/test/resources/suites/<domain>/<feature>/`

**Example:** `cancelUiFlow.xml`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<suite name="CancelUiFlowSuite">
    <test name="CancelUiFlowTest">
        <parameter name="platform" value="Chrome"/>
        <parameter name="version" value="latest"/>
        <classes>
            <class name="clinicalservices.SuperMario.DropOffUI.CancelUiFlow"/>
        </classes>
    </test>
</suite>
```

### Suite Naming Convention

- `<feature><TestType>.xml`
- Examples: `cancelUiFlow.xml`, `patientCreation.xml`, `orderManagement.xml`

---

## 📊 Test Data Management

### Test Data Structure

**Location:** `src/test/resources/TestData/<domain>/<feature>/`

**File Types:**

- **Excel Files:** `.xlsx` for tabular data
- **JSON Files:** `.json` for structured data
- **Properties Files:** `.properties` for configuration data

**Example Structure:**

```
TestData/
├── CsData/
│   ├── SuperMario/
│   │   ├── Excel/
│   │   │   ├── CancelOrder.xlsx
│   │   │   ├── PatientCreation.xlsx
│   │   │   └── ProviderSelection.xlsx
│   │   ├── JSON/
│   │   │   └── testScenarios.json
│   │   └── Properties/
│   │       └── testConfig.properties
```

### Data Provider Pattern

```java
@DataProvider(name = "patientData")
public Object[][] getPatientData() {
    return DataProvider.getDataAsObjectArray("TestData/CsData/SuperMario/Excel/PatientCreation.xlsx", "PatientData");
}

@Test(dataProvider = "patientData")
public void createPatientTest(String firstName, String lastName, String dob) {
    // Test implementation
}
```

---

## 🔧 Implementation Checklist

### Before Creating Web Automation:

#### ✅ 1. Page Object Model Setup

- [ ] Create page class extending `WebAndMobileBasePage`
- [ ] Declare all web elements using `private final By`
- [ ] Implement action methods with proper error handling
- [ ] Add validation methods for page state verification
- [ ] Include screenshot logging for critical steps

#### ✅ 2. Base Driver Configuration

- [ ] Set up `<Domain>BaseDriver.java` for WebDriver initialization
- [ ] Configure platform-specific driver setup
- [ ] Implement proper driver lifecycle management
- [ ] Add browser configuration options

#### ✅ 3. App Manager Setup

- [ ] Create `<Domain>BaseAppManager.java`
- [ ] Initialize all page objects
- [ ] Implement common workflow methods
- [ ] Add URL configuration methods

#### ✅ 4. Test Class Implementation

- [ ] Create test class with proper TestNG annotations
- [ ] Initialize WebDriver and AppManager
- [ ] Implement test methods with comprehensive assertions
- [ ] Add proper cleanup in `@AfterMethod` or `@AfterClass`

#### ✅ 5. TestNG Suite Configuration

- [ ] Create XML suite file with proper parameters
- [ ] Configure test classes and methods
- [ ] Set up parallel execution if needed
- [ ] Add test groups for categorization

#### ✅ 6. Test Data Setup

- [ ] Create test data files in appropriate format
- [ ] Implement data providers for parameterized tests
- [ ] Set up data-driven test scenarios
- [ ] Validate data loading and parsing

---

## 🎯 Locator Strategy Best Practices

### Locator Priority (Most Reliable → Least Reliable)

1. **ID** - `By.id("element-id")`
2. **Name** - `By.name("element-name")`
3. **CSS Selector** - `By.cssSelector(".class-name")`
4. **XPath** - `By.xpath("//tag[@attribute='value']")`

### XPath Best Practices

```java
// ✅ Good XPath - Specific and stable
private final By submitBtn = By.xpath("//button[@id='submit-button']");
private final By firstNameInput = By.xpath("//input[@name='firstName']");

// ❌ Avoid - Fragile XPath
private final By submitBtn = By.xpath("//div[1]/div[2]/button[3]");
private final By element = By.xpath("/html/body/div[5]/span[2]");
```

---

## 📝 Code Standards

### Naming Conventions

- **Page Classes**: `<PageName>Page.java` (e.g., `CreatePatientPage.java`)
- **Test Classes**: `<Feature><TestType>.java` (e.g., `CancelUiFlow.java`)
- **Locators**: `camelCase` with descriptive names (e.g., `createPatientBtn`)
- **Methods**: `camelCase` with action verbs (e.g., `chooseProvider()`)

### Method Structure

```java
public void performAction(String parameter) {
    // Step 1: Pre-condition check
    if (!isElementDisplayed(requiredElement)) {
        Reporter.logScreenShot("Pre-condition failed", takeScreenShot());
        Assert.fail("Required element not displayed");
    }

    // Step 2: Perform action
    click(targetElement);
    sendText(inputField, parameter);

    // Step 3: Validation
    Assert.assertTrue(isElementDisplayed(expectedResult), "Action validation failed");
    Reporter.logScreenShot("Action completed successfully", takeScreenShot());
}
```

### Error Handling Pattern

```java
try {
    // Perform UI action
    click(elementLocator);
} catch (Exception e) {
    Reporter.logScreenShot("Action failed: " + e.getMessage(), takeScreenShot());
    Assert.fail("Test failed due to: " + e.getMessage());
}
```

---

## 🚫 Common Anti-Patterns to Avoid

1. **Hard-coded waits**: Use explicit waits instead of `Thread.sleep()`
2. **Fragile locators**: Avoid index-based XPath
3. **Missing assertions**: Every action should have validation
4. **No error handling**: Always include try-catch for critical actions
5. **Duplicate code**: Reuse common methods from base classes
6. **Missing screenshots**: Log screenshots for verification and debugging

---

## 📚 Reference Examples

### Existing Implementations

- **Clinical Services**: `src/test/java/clinicalservices/SuperMario/`
- **Page Objects**: `src/main/java/hwqe/baseframework/models/pageobjectmodels/clinicalservices/`
- **Test Suites**: `src/test/resources/suites/cs/SuperMario/`

### Framework Components

- **WebAndMobileBasePage**: Base class for all page objects
- **SuperMarioBaseDriver**: WebDriver initialization and management
- **SuperMarioBaseAppManager**: Page object orchestration
- **Reporter**: Logging and screenshot utilities

---

## 🎯 Success Criteria

A well-implemented web automation should:

1. ✅ Follow the Page Object Model pattern
2. ✅ Use stable and reliable locators
3. ✅ Include comprehensive assertions and validations
4. ✅ Have proper error handling and logging
5. ✅ Be maintainable and reusable across test cases
6. ✅ Provide clear screenshots for verification
7. ✅ Support data-driven testing scenarios

---

## 🔄 Execution Commands

### Run Single Test Class

```bash
mvn test -Dtest=CancelUiFlow
```

### Run TestNG Suite

```bash
mvn test -DsuiteXmlFile=src/test/resources/suites/cs/SuperMario/FrontEndTestSuite/cancelUiFlow.xml
```

### Run with Parameters

```bash
mvn test -Dtest=CancelUiFlow -Dplatform=Chrome -Dversion=latest
```

---

_This document should be referenced before creating any new web application automation scripts. For questions or clarifications, consult existing implementations in the framework._
