# Self-Healing LLM Integration — Design Document

**Project:** AutomationBaseFramework (Dragon)
**Feature:** Phase 1 — LLM-assisted Connexus UI Test Failure Analysis
**Branch:** `feat/self-healing-llm-phase1`
**Status:** Implementation Complete — In Review (PR #6962)
**Author:** r0c03ir
**Last Updated:** May 2026

---

## 1. Executive Summary

When a Connexus UI test fails, the framework automatically:

1. Captures a WinAppDriver screenshot (confirms it is a live UI test)
2. Sends failure context + screenshot to the Walmart Element LLM Gateway (stage sandbox)
3. Receives a structured failure analysis: pattern classification, root cause, and suggested fix
4. Writes the analysis as a `LlmHealRecord` Cosmos document linked to the suite run

This runs silently in the background — it **never alters test outcomes** — and enables the team to query recurring failure patterns across runs without manually reading every stack trace.

---

## 2. Problem Statement

| Problem | Impact |
|---------|--------|
| 50+ test cases per suite run, each failure requires manual triage | Hours of analysis per sprint |
| Same root causes recur (timing, null guards, login popups) | No automated pattern detection |
| Cosmos only stores pass/fail counts — no failure reason | Cannot query "why did test X fail?" |
| Screenshots exist but are discarded after the run | Evidence lost |

---

## 3. Architecture

```
TestNG Suite Execution
│
├── Reporter.onStart(ISuite)
│     └─ SelfHealContext.init(suiteRunId, maxCalls=10)
│
└── Reporter.onTestFailure(ITestResult)
      ├─ [existing] Extent log, Jira, Slack, Cosmos update   ← UNCHANGED
      └─ SelfHealingService.analyse(result, jiraId)          ← NEW (appended)
              │
              ├─ isEnabled() check  (selfheal.llm.enabled=false → return immediately)
              ├─ ctx.claimSlot()    (slot > 10 → return, call released)
              │
              ├─ tryTakeScreenshot()
              │     ├─ SUCCESS → UI test confirmed, driver alive
              │     └─ FAIL   → isConnexusSessionDead()?
              │                    YES → Connexus crashed (send without screenshot)
              │                    NO  → not a UI test → ctx.releaseSlot(), return silently
              │
              ├─ LlmGatewayClient.chat(systemPrompt, userPrompt, screenshotB64)
              │     POST https://wmtllmgateway.stage.walmart.com/wmtllmgateway
              │          /openai/deployments/gpt-4.1-mini@2025-04-14
              │          /chat/completions?api-version=2024-10-21
              │     Headers: api-key, WM_LLM_GW.USER_TYPE, WM_LLM_GW.USER_NAME
              │
              └─ writeToCosmos(LlmHealRecord)
                    POST {insert.update.test.record.url}
```

---

## 4. What Is Sent to the LLM

### 4.1 System Prompt

The system prompt is **embedded in code** (`SelfHealingService.buildSystemPrompt()`). It provides the 10 known failure patterns as context and mandates a strict output format.

```
You are a Connexus UI pharmacy automation test failure analyst.
You know the following 10 failure patterns:

Pattern 1  - Null Guard Missing:         NullPointerException on menu/nav objects.
Pattern 2  - Stale Driver Session:       NoSuchSessionException, WebDriverException.
Pattern 3  - String Comparison Mismatch: AssertionError on string compare (punctuation/case).
Pattern 4  - Timing / Flakiness:         TimeoutException, element not found, popup cap.
Pattern 5  - Test Disabled:              enabled=false not re-enabled.
Pattern 6  - Race Condition:             API called before queue transition (Queue 7).
Pattern 7  - Login / Post-Login Popup:   lblStationIcon not found.
Pattern 8  - Flag / DB Value Wrong:      updateFlagValue wrong case or missing companion flag.
Pattern 9  - Optional UI Screen:         conditional popup assumed always present.
Pattern 10 - Data / SQL Mismatch:        wrong count, stale Excel data, SQL filter wrong.

Analyse the failure and respond ONLY in this exact format:
Pattern: <pattern name>
Root cause: <1-2 sentences>
Suggested fix: <specific code change>
Confidence: HIGH | MEDIUM | LOW
```

### 4.2 User Prompt

The user prompt is **built per-failure** (`SelfHealingService.buildUserPrompt()`):

```
Test: verifyDropOffFlow (HWPHME2E_510)
Store: 5510 | Environment: dev
Exception type: org.testng.AssertionError
[Optional] Note: Connexus application terminated before screenshot could be taken.

Stack trace:
AssertionError: expected [lblStationIcon] to be displayed
  at hwqe.baseframework.models.pageobjectmodels.connexus.LoginPage.loginConnexus(LoginPage.java:214)
  at hwqe.cnxe2e.tests.HWPHME2E_510_verifyDropOffFlow.verifyDropOffFlow(HWPHME2E_510.java:38)
  ...[truncated to 2000 chars]
```

Fields populated:

| Field | Source |
|-------|--------|
| Test name | `ITestResult.getMethod().getMethodName()` |
| Jira ID | `@Jira` annotation extracted by `Reporter` |
| Store number | `cnx.store` property |
| Environment | `testEnvironment` property |
| Exception type | `Throwable.getClass().getName()` |
| Stack trace | `Throwable.getStackTrace()`, truncated at 2000 chars |
| Crash note | Added only when `isConnexusSessionDead()` is true |

### 4.3 Screenshot

- Format: PNG captured by WinAppDriver via `connexus.takeScreenShot()`
- Encoding: Base64, sent as `data:image/png;base64,{data}` in an `image_url` content part
- Present when: driver is alive and screenshot succeeds
- Absent when: Connexus crashed before screenshot (analysis still runs without it)
- `screenshotAvailable: false` is stored in Cosmos so queries can filter

---

## 5. What Is Expected Back

The LLM must respond **only** in this format (enforced by the system prompt):

```
Pattern: Pattern 7 - Login / Post-Login Popup Failure
Root cause: lblStationIcon not found because the security warning popup (BtnAccept) was not dismissed within the 9-second window, causing the station icon to never appear.
Suggested fix: Replace the 3-attempt loop with handlePopup("", "BtnAccept", 35) and add switchWindow(40_000) after BtnAccept is clicked to ensure focus returns before asserting lblStationIcon.
Confidence: HIGH
```

### 5.1 Response Parsing

`SelfHealingService.parse(llmRaw, label)` extracts each labelled line:

| Parsed field | Label searched | Stored in |
|---|---|---|
| Pattern | `"Pattern:"` | `LlmHealRecord.llmPattern` |
| Root cause | `"Root cause:"` | `LlmHealRecord.llmRootCause` |
| Suggested fix | `"Suggested fix:"` | `LlmHealRecord.llmSuggestedFix` |
| Confidence | `"Confidence:"` | `LlmHealRecord.llmConfidence` |

If a label is not found, the field stores `"UNKNOWN"` (not null).
If the LLM call was skipped entirely (key missing, disabled), fields store `"LLM_UNAVAILABLE"`.

---

## 6. Authentication

### 6.1 API Key

| Property | Value |
|----------|-------|
| Key name | `WMT_LLM_GK` |
| Source | CCM (Strati) — loaded automatically by `PropertyReader` at runtime |
| Never stored in | `dev.properties`, source code, or logs |
| Log output | `"LLM key loaded: YES (length=N)"` — value never printed |

### 6.2 HTTP Headers

Every LLM request includes:

| Header | Value | Purpose |
|--------|-------|---------|
| `api-key` | `{WMT_LLM_GK from CCM}` | Walmart LLM Gateway auth (NOT `Authorization: Bearer`) |
| `Content-Type` | `application/json` | Request body format |
| `WM_LLM_GW.USER_TYPE` | `NO_END_USER` | Mandatory audit header — signals no PII in payload |
| `WM_LLM_GW.USER_NAME` | `{selfheal.llm.callerUserId}` | Mandatory audit header — identifies the calling service |

> **Why `api-key` not `Authorization: Bearer`?**
> Walmart Element LLM Gateway uses Azure OpenAI-style authentication where the key goes in the `api-key` header, not a Bearer token. The Walmart spec document confirmed this.

### 6.3 URL Structure

```
{selfheal.llm.endpoint}/openai/deployments/{selfheal.llm.model}/chat/completions?api-version={selfheal.llm.apiVersion}
```

With current values:
```
https://wmtllmgateway.stage.walmart.com/wmtllmgateway/openai/deployments/gpt-4.1-mini@2025-04-14/chat/completions?api-version=2024-10-21
```

The **model is in the URL path** — it is NOT sent in the request body. This is the Azure OpenAI deployment pattern used by Walmart's gateway.

---

## 7. Configuration Properties

All properties live in `src/test/resources/config/connexus/dev.properties`.

```properties
# Self-Healing LLM Gateway (Phase 1)
# API key WMT_LLM_GK is loaded automatically from CCM — do NOT add it here
selfheal.llm.enabled=true
selfheal.llm.maxCallsPerSuite=10
selfheal.llm.endpoint=https://wmtllmgateway.stage.walmart.com/wmtllmgateway
selfheal.llm.model=gpt-4.1-mini@2025-04-14
selfheal.llm.apiVersion=2024-10-21
selfheal.llm.callerUserId=r0c03ir
```

| Property | Purpose | Kill switch? |
|---|---|---|
| `selfheal.llm.enabled` | Set `false` to disable entirely — zero code change needed | YES |
| `selfheal.llm.maxCallsPerSuite` | Hard cap on LLM calls per suite run | Limits cost |
| `selfheal.llm.endpoint` | Base URL of the LLM Gateway (includes context path) | |
| `selfheal.llm.model` | Deployment name embedded in URL path | |
| `selfheal.llm.apiVersion` | Azure OpenAI API version in URL query string | |
| `selfheal.llm.callerUserId` | Audit header value — identifies calling engineer/service | |

---

## 8. How It Cannot Break Existing Tests

This is the most critical design guarantee.

### 8.1 Top-Level Try-Catch

The entire `SelfHealingService.analyse()` method is wrapped in:

```java
try {
    // all self-heal logic
} catch (Exception e) {
    // Broad catch is intentional — self-heal must never affect test outcome
    log.warn("[SelfHeal] Unexpected error during analysis: {}", e.getMessage());
}
```

Any exception — network timeout, NPE in the LLM client, Cosmos write failure, JSON parse error — is silently absorbed. The test result is already set before `analyse()` is called.

### 8.2 Kill Switch

```properties
selfheal.llm.enabled=false
```

First line of `analyse()` checks this flag and returns immediately if not `"true"`. No screenshot, no HTTP call, no Cosmos write.

### 8.3 Call Cap

`SelfHealContext.claimSlot()` atomically increments a counter and returns `-1` when it exceeds `maxCallsPerSuite` (default 10). When the cap is hit, `analyse()` returns immediately after logging one INFO line.

### 8.4 UI Test Gate — Non-UI Tests Are Always Skipped

```
Screenshot OK?       YES → proceed
Screenshot fails?    isConnexusSessionDead()? 
                       YES → Connexus crashed → proceed without screenshot
                       NO  → ctx.releaseSlot(); return  ← API/DB tests end here
```

API tests, DB tests, and any test that doesn't use WinAppDriver will never reach the LLM call.

### 8.5 Timeout Limits

- `LlmGatewayClient` uses a 20-second socket timeout
- In the absolute worst case (gateway hangs), a failed test waits an extra 20 seconds
- This is within acceptable bounds; most calls return in under 3 seconds

### 8.6 Injection Points Are Appended, Not Spliced

In `Reporter.java`:
- `SelfHealContext.init()` is appended to the **end** of `onStart()` — after all existing suite setup
- `selfHealingService.analyse()` is appended **after** `updateCosmosOnFailure()` — after all existing failure handling

Zero changes to existing method logic, no conditional wrapping of existing code.

---

## 9. Cosmos Data Model

### 9.1 Document Type

`LlmHealRecord` documents co-exist in the **same Cosmos container** as `TestRecord` documents. The `docType` field discriminates them:

| docType | Document | Created by |
|---------|----------|-----------|
| `TEST_RECORD` | Existing test run summary | `Reporter.updateCosmosOnFailure()` |
| `LLM_HEAL` | LLM analysis for one failure | `SelfHealingService.writeToCosmos()` |

No new container, no infrastructure change.

### 9.2 LlmHealRecord Fields

| Field | Type | Example | Notes |
|-------|------|---------|-------|
| `id` | String | `suite_001_verifyDropOffFlow_1746123456789` | Unique; never overwritten |
| `docType` | String | `LLM_HEAL` | Cosmos discriminator |
| `suiteRunId` | String | `suite_001` | FK to `TestRecord.id` |
| `testName` | String | `verifyDropOffFlow` | TestNG method name |
| `jiraId` | String | `HWPHME2E_510` | From `@Jira` annotation |
| `store` | String | `5510` | From `cnx.store` property |
| `environment` | String | `dev` | From `testEnvironment` property |
| `exceptionType` | String | `org.testng.AssertionError` | Full class name |
| `stackTrace` | String | `...` | Truncated at 2000 chars |
| `screenshotAvailable` | boolean | `true` | `false` when Connexus crashed |
| `screenshotBase64` | String | `iVBORw0KGgo...` | PNG as base64; null when unavailable |
| `llmPattern` | String | `Pattern 7 - Login / Post-Login Popup Failure` | Parsed from LLM response |
| `llmRootCause` | String | `lblStationIcon not found because...` | Parsed from LLM response |
| `llmSuggestedFix` | String | `Replace 3-attempt loop with handlePopup(...)` | Parsed from LLM response |
| `llmConfidence` | String | `HIGH` | `HIGH`, `MEDIUM`, `LOW`, or `UNKNOWN` |
| `callTimestamp` | long | `1746123456789` | Epoch ms when LLM was called |
| `failureIndex` | int | `3` | 1-based position in suite run (1–10) |
| `llmHttpStatus` | int | `200` | 0 if LLM not called |

### 9.3 Useful Cosmos Queries

```sql
-- All LLM analyses for one suite run (linked to TestRecord)
SELECT * FROM c
WHERE c.suiteRunId = 'suite_001' AND c.docType = 'LLM_HEAL'
ORDER BY c.failureIndex ASC

-- All failures classified as timing/flakiness across all runs
SELECT c.suiteRunId, c.testName, c.callTimestamp, c.llmConfidence
FROM c
WHERE c.docType = 'LLM_HEAL' AND c.llmPattern LIKE '%Pattern 4%'
ORDER BY c.callTimestamp DESC

-- Same test failing repeatedly — track pattern over time
SELECT c.suiteRunId, c.llmPattern, c.llmConfidence, c.callTimestamp
FROM c
WHERE c.docType = 'LLM_HEAL' AND c.testName = 'verifyDropOffFlow'
ORDER BY c.callTimestamp DESC

-- All HIGH-confidence analyses this week with suggested fixes
SELECT c.testName, c.llmPattern, c.llmSuggestedFix
FROM c
WHERE c.docType = 'LLM_HEAL'
  AND c.llmConfidence = 'HIGH'
  AND c.callTimestamp > 1746000000000
ORDER BY c.callTimestamp DESC

-- Test report + LLM analyses for one run (all doc types)
SELECT * FROM c WHERE c.suiteRunId = 'suite_001'

-- Distribution: which patterns are most common?
SELECT c.llmPattern, COUNT(1) AS occurrences
FROM c
WHERE c.docType = 'LLM_HEAL'
GROUP BY c.llmPattern
ORDER BY occurrences DESC
```

---

## 10. New Components Summary

| Class | Package | Lines | Purpose |
|-------|---------|-------|---------|
| `SelfHealingService` | `selfheal` | ~360 | Orchestrates the full flow; never throws |
| `LlmGatewayClient` | `selfheal` | ~120 | Apache HttpClient wrapper for LLM Gateway |
| `LlmHealRecord` | `selfheal` | ~50 | Lombok `@Builder` Cosmos document model |
| `SelfHealContext` | `selfheal` | ~65 | Suite-scoped singleton; AtomicInteger call counter |

### Modified Files

| File | Nature of change |
|------|-----------------|
| `Reporter.java` | 3 additions: field, end of `onStart()`, end of `onTestFailure()` |
| `dev.properties` | 6 new properties appended (additive only) |

---

## 11. SonarQube / Code Quality Compliance

| Rule | How addressed |
|------|--------------|
| No hardcoded credentials | `WMT_LLM_GK` loaded from CCM via `PropertyReader` |
| No hardcoded URIs | `apiVersion` is a configurable property, not a constant |
| No duplicate string literals | `JSON_KEY_CONTENT = "content"` constant; 4 uses |
| Thread safety for singletons | `AtomicReference<SelfHealContext>` replaces `volatile` |
| Proper resource closing | `CloseableHttpClient` / `CloseableHttpResponse` in try-with-resources |
| Restricted identifiers | Variable `record` renamed to `healRecord` (Java 16+) |
| String concatenation in loops | `buildSystemPrompt()` uses Java text block |
| Broad catch documented | Intentional; `@SuppressWarnings` + Javadoc explanation |
| No unused fields | `Gson gson` removed from `SelfHealingService` |

---

## 12. Local Smoke Test

`scripts/Test-SelfHealLlm.ps1` makes the same HTTP call as `LlmGatewayClient` without needing Maven or the full test stack.

```powershell
# Retrieve WMT_LLM_GK from puppy.walmart.com → Consumer Keys
$env:WMT_LLM_GK = "your-key-here"
.\scripts\Test-SelfHealLlm.ps1

# Or pass directly:
.\scripts\Test-SelfHealLlm.ps1 -ApiKey "your-key-here"
```

A successful run outputs:
```
[PASS] LLM Gateway call successful - response format is correct.
```

This confirms:
- The gateway endpoint is reachable
- The `api-key` header is accepted
- The model deployment responds
- The response format matches what `SelfHealingService.parse()` expects

---

## 13. Rollout Plan

| Phase | Action |
|-------|--------|
| Week 1 | Deploy with `selfheal.llm.enabled=false` — confirm zero regression on existing suite runs |
| Week 2 | Enable on dev (`selfheal.llm.enabled=true`) — watch logs for `[SelfHeal] Analysis #N complete` |
| Week 3 | Run 3-5 CNX suite runs — query Cosmos with `docType = 'LLM_HEAL'`, review accuracy |
| Week 4 | Share pattern distribution query with team — identify top 3 recurring patterns |
| Phase 2 | Auto-suggest fixes inline in Extent report (separate PR) |

---

## 14. File Inventory

| File | Status |
|------|--------|
| `src/main/java/hwqe/baseframework/selfheal/SelfHealingService.java` | NEW |
| `src/main/java/hwqe/baseframework/selfheal/LlmGatewayClient.java` | NEW |
| `src/main/java/hwqe/baseframework/selfheal/LlmHealRecord.java` | NEW |
| `src/main/java/hwqe/baseframework/selfheal/SelfHealContext.java` | NEW |
| `src/main/java/hwqe/baseframework/utilities/Reporter.java` | MODIFIED (3 additive changes) |
| `src/test/resources/config/connexus/dev.properties` | MODIFIED (6 new properties) |
| `scripts/Test-SelfHealLlm.ps1` | NEW (local smoke test) |
| `docs/self-healing-llm-design.md` | NEW (this document) |
