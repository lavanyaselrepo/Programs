# PRD — Yearly Immunization Coverage Plan
**Author:** Ragini Pesaru  
**Status:** Draft  
**Date:** April 2026  
**Team:** ASUI Clinical Services Automation  

---

## 1. Overview

Walmart Pharmacy administers immunizations year-round across thousands of stores. Today there is **no formal yearly plan** that coordinates which vaccines are in scope for each season, when automation test coverage must be ready, or how readiness is communicated to stakeholders before peak periods begin.

This PRD proposes a **Yearly Immunization Coverage Plan** — a repeating, calendar-driven framework that defines:
- Which vaccine services are in scope each season
- Automation coverage gates that must pass before each campaign launch
- A shared readiness signal for QA, pharmacy ops, and product leadership

---

## 2. Problem Statement

### What is happening today
| Problem | Impact |
|---|---|
| No yearly IMZ testing roadmap exists | Test coverage is written reactively — often after rollout |
| Vaccine campaigns (Flu, COVID, RSV etc.) go live without a formal QA sign-off | Bugs reach production during peak scheduling windows |
| Each season's effort starts from scratch | Duplicated work, missed edge cases, and scrambled timelines |
| No shared visibility across QA, product, and pharmacy ops | Misaligned expectations on what is and isn't tested |

### The bottom line
Every immunization season is treated as a surprise. That is unsustainable as the number of supported vaccines (Flu, COVID-19, RSV, Pneumonia, Hepatitis A/B, mNEXSPIKE, Flublok, LAI) continues to grow.

---

## 3. Goals

| # | Goal |
|---|---|
| G1 | Define a **calendar of vaccine seasons** so the team can prepare months ahead instead of weeks |
| G2 | Establish **automation coverage requirements** per vaccine per season (locators, copy-text validation, scheduling flow, edge cases) |
| G3 | Create a **release readiness checklist** that acts as a go/no-go gate before each campaign |
| G4 | Provide **stakeholder-facing visibility** into testing status via a lightweight quarterly review |
| G5 | Make the plan **reusable** — adding a new vaccine in a future year requires filling in a template, not starting from scratch |

### Non-Goals
- This PRD does **not** define clinical eligibility rules (owned by pharmacy ops / regulatory)
- This PRD does **not** cover the patient-facing scheduling UI design (owned by product)
- This PRD does **not** replace the existing sprint-level test planning process

---

## 4. Vaccine Seasons & Calendar

| Season | Vaccines in Scope | Typical Campaign Window | Automation Readiness Deadline |
|---|---|---|---|
| **Fall / Flu Season** | Influenza (Flublok, standard flu) | Aug – Mar | **July 15** each year |
| **COVID Booster Campaign** | COVID-19 (Moderna, mNEXSPIKE) | Sep – ongoing | **August 15** each year |
| **RSV Season** | RSV | Sep – Feb | **August 15** each year |
| **Spring IMZ** | Hepatitis A/B, Pneumonia, LAI | Mar – Jun | **February 15** each year |
| **Year-round** | All of the above (ongoing scheduling) | Jan – Dec | Covered in each season above |

---

## 5. Coverage Requirements Per Vaccine

For each in-scope vaccine each season, the following must be verified before the readiness deadline:

### 5.1 Locators
- [ ] Drug tile locator validated (`aria-label` matches live DOM)
- [ ] Eligibility page locators confirmed (heading, subheading, bullet texts)
- [ ] Footer action buttons (`Continue`, `Previous`, `Schedule appointment`)
- [ ] Dose-selection controls (where applicable: Dose #2, Dose #3, Three-dose series)

### 5.2 Copy-Text Validation
- [ ] Vaccine heading — dynamic patient name portion renders correctly
- [ ] Brand subheading — correct vaccine brand name displayed
- [ ] Patient eligibility label — exact text match
- [ ] Eligibility bullet(s) — full text match (whitespace-normalized)

### 5.3 End-to-End Scheduling Flow
- [ ] Patient search → service selection → dose selection → slot selection → confirmation
- [ ] Reschedule flow
- [ ] Cancel flow
- [ ] Multi-patient / group booking (where applicable)

### 5.4 Edge Cases
- [ ] Patient below minimum eligible age — appropriate messaging shown
- [ ] Immunocompromised additional dose path
- [ ] No available slots — "all appointments currently booked" state
- [ ] Logged-out state mid-flow — redirect to login and back

---

## 6. Release Readiness Checklist (Go / No-Go Gate)

Before each seasonal campaign launches, **all** of the following must be ✅:

```
[ ] All locators for in-scope vaccines validated against staging environment
[ ] Copy-text validation tests passing (HCI-15515 Flu, HCI-15516 COVID, ...)
[ ] E2E scheduling flow green on CI for all in-scope vaccines
[ ] Edge case tests passing or explicitly deferred with a Jira ticket
[ ] Screenshot evidence captured and attached to the readiness ticket
[ ] QA sign-off recorded on the campaign Jira epic
[ ] Stakeholder notification sent (QA lead → pharmacy product lead)
```

---

## 7. Proposed Automation Structure

The existing `ClinicalServiceAppointmentsPage.java` page object already supports this model. The yearly plan formalises it:

```
ClinicalServiceAppointmentsPage.java
├── Flu locators          ← fluVaccineTitle, fluFlublokInfo, fluEligibilityBullet ...
├── COVID-19 locators     ← covidVaccineHeading, covidEligibilityBullet1/2 ...
├── RSV locators          ← rsvDrug ...
├── Hepatitis A/B         ← hepatitisABDrug ...
├── Pneumonia             ← pneumonia ...
└── [New vaccine]         ← added per template each season

CopyTextValidationTest.java
├── verifyFluCopyTexts()      HCI-15515
├── verifyCovidCopyTexts()    HCI-15516
├── verifyRsvCopyTexts()      HCI-XXXXX  ← to be created
└── [one @Test per vaccine per season]
```

**Template for adding a new vaccine season:**
1. Add locators block to `ClinicalServiceAppointmentsPage.java` under a clearly labelled section comment
2. Add `validate<Vaccine>BookingCopyTexts()` method following the existing FLU/COVID pattern
3. Add `verify<Vaccine>CopyTexts()` `@Test` method in `CopyTextValidationTest.java` with a `@Jira` tag
4. Update this PRD's calendar table and readiness checklist

---

## 8. Metrics & Success Criteria

| Metric | Baseline (Today) | Target (End of Year 1) |
|---|---|---|
| Vaccine campaigns with full automation coverage before launch | 0 of N | 3 of 3 seasonal campaigns |
| Production bugs caught during peak IMZ windows | Unknown — no tracking | Tracked + trending down |
| Time from vaccine campaign announcement to test-ready | Reactive (days before) | ≥ 4 weeks ahead |
| Locator breakage incidents per season | Untracked | ≤ 1 per season, resolved within 24h |
| Stakeholder readiness reviews completed | 0 | 4 per year (quarterly) |

---

## 9. Milestones

| Date | Milestone |
|---|---|
| May 2026 | PRD reviewed and approved by team |
| Jun 2026 | Spring IMZ readiness checklist completed (Hep A/B, Pneumonia, LAI) |
| Jul 15, 2026 | Flu season automation ready — copy-text + E2E green |
| Aug 15, 2026 | COVID + RSV automation ready |
| Sep 2026 | Q3 stakeholder review — season results presented |
| Dec 2026 | Retrospective — refine plan for 2027 |

---

## 10. Risks & Mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| Vaccine brand names / copy changes close to launch | Medium | Copy-text tests use `contains()` on stable prefix — brittle exact-match tests avoided |
| New vaccine added to campaign with short notice | Medium | Template-based approach (Section 7) reduces onboarding time to < 1 sprint |
| `aria-label` DOM changes break locators | Low–Medium | Locators reviewed against staging 2 weeks before readiness deadline |
| Stakeholder review cadence deprioritised | Low | Calendar invites sent at PRD approval; QA lead owns scheduling |

---

## 11. Open Questions

| # | Question | Owner | Due |
|---|---|---|---|
| Q1 | Which Jira epic should yearly IMZ readiness tickets be filed under? | Ragini Pesaru | May 2026 |
| Q2 | Who is the pharmacy product lead to include in the quarterly review? | TBD | May 2026 |
| Q3 | Should RSV get its own `verify<Rsv>CopyTexts()` test this season or is presence-only sufficient? | QA team | Jun 2026 |
| Q4 | Do we need a separate readiness gate for the mNEXSPIKE 3-month interval rule? | Ragini Pesaru | Jun 2026 |

---

## 12. Appendix — Existing Coverage Reference

| Vaccine | Locator | Copy-Text Test | E2E Test |
|---|---|---|---|
| Flu (Influenza) | ✅ `fluDrug` | ✅ `HCI-15515` | ✅ |
| COVID-19 | ✅ `covidDrug`, `covidVaccineHeading` | ✅ `HCI-15516` | 🔲 Planned |
| RSV | ✅ `rsvDrug` | 🔲 Planned | 🔲 Planned |
| Hepatitis A/B | ✅ `hepatitisABDrug` | 🔲 Planned | 🔲 Planned |
| Hepatitis B | ✅ `hepatitisB` | 🔲 Planned | 🔲 Planned |
| Pneumonia | ✅ `pneumonia` | 🔲 Planned | 🔲 Planned |
| LAI Visit | ✅ `laiVisitCheckbox` | 🔲 Planned | ✅ |

---

*This document is a living PRD — update it each quarter as campaigns complete and new vaccines are onboarded.*
