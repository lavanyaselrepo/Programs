# Dragon Core Refactoring Implementation Plan

**Team:** Core Functionality Team  
**Scope:** Dragon Core (`hwqe.baseframework.*`) + Shared Libraries  
**Created:** 2026-03-13  
**Status:** Phase 0 Complete ✅

---

## Executive Summary

This document outlines a multi-phase refactoring plan for the Dragon Core framework, focusing on code quality, maintainability, and best practices. The refactoring follows the "strangler fig" pattern - we wrap existing code with tests, then incrementally improve it while maintaining backward compatibility.

### Key Principles
- **Test First:** No refactoring without characterization tests
- **Backward Compatible:** Public APIs must remain stable
- **Incremental:** Small, reviewable PRs per phase
- **DRY/YAGNI/SOLID:** Follow these religiously
- **Zero Regressions:** All existing tests must pass

---

## Phase 0: Test Harness ✅ COMPLETE

**Branch:** `refactor/phase-0-test-harness`  
**Status:** 🎉 563 tests passing, ~12 second execution

### Deliverables
**Test Coverage (33 test files, 563 tests):**

| Package | Files | Key Classes Tested |
|---------|-------|--------------------|
| `apicontext/` | 6 | RestClient, ServiceRequest, ServiceResponse, Proxy, GsonAdapter |
| `datacontext/` | 11 | DataProvider, DataTable, DataRow, Credentials, XLS, FileUtil |
| `utilities/` | 15 | StringUtils, DateUtils, FileUtils, JsonUtils, Poller, Retry |
| `contracts/` | 1 | API Contract Tests (public method signatures) |

**Infrastructure:**
- [x] Maven `unit-tests` profile with Mockito support
- [x] Maven `quick-tests` profile (skip compile, ~12s)
- [x] `run-tests.sh` script with noise filtering
- [x] testng-unit.xml test suite
- [x] log4j2-test.xml for quiet test logging

### Usage
```bash
# RECOMMENDED: Clean output with noise filtering
./run-tests.sh              # Default: quick-tests (~15s)
./run-tests.sh unit-tests   # Full compile + tests (~2min)
./run-tests.sh quick-tests  # Skip compile (~15s)

# Or use Maven directly (noisier output)
mvn test -Pquick-tests      # Fast, skips compile
mvn test -Punit-tests       # Full compile
```

### Build Noise Fixes Applied
- Fixed swagger.json invalid URL (added https:// protocol)
- Fixed avro schema logicalType format (nested in type)
- Fixed duplicate awaitility dependency
- Added version to maven-resources-plugin
- Created run-tests.sh with comprehensive output filtering
- Added log4j2-test.xml to suppress Kafka/CCM/Strati runtime noise

### Known Bugs Documented
| Component | Bug | Severity |
|-----------|-----|----------|
| DataProvider | Thread-unsafe `dataTypes` HashMap | HIGH |
| DataProvider | `getBaseRxData()` has broken cast | HIGH |
| DataProvider | Magic numbers -1, -2 | LOW |
| RestClient | Duplicated HttpClient builder (7x) | MEDIUM |
| RestClient | No try-with-resources (resource leak) | MEDIUM |
| RestClient | `printStackTrace()` instead of logging | LOW |
| PropertyReader | `lock` field not final | LOW |
| PropertyReader | `loadDmLocalConfig()` clobbers vault values | MEDIUM |
| PropertyReader | Dead HashiCorp vault code | LOW |

---

## Phase 1: Code Formatting & Static Analysis

**Estimated Duration:** 1-2 days  
**Risk:** LOW

### Tasks
1. [ ] Add `.editorconfig` for consistent formatting
2. [ ] Add Checkstyle configuration (Google Java Style)
3. [ ] Add SpotBugs/FindBugs Maven plugin
4. [ ] Fix all naming convention violations:
   - `HasKey` → `hasKey`
   - `CONNECTIONTIMEOUT` → `CONNECTION_TIMEOUT`
   - `INTERNALPROXY` → `INTERNAL_PROXY`
5. [ ] Remove dead code:
   - `loadHashiCorpVault()` and `processVault()`
   - Commented out `writeToFile()` methods
6. [ ] Fix all `printStackTrace()` → `logger.error()`
7. [ ] Add missing `@Override` annotations

### Acceptance Criteria
- All formatting rules pass
- SpotBugs reports 0 critical issues
- All 128+ tests still pass

---

## Phase 2: RestClient DRY Refactoring

**Estimated Duration:** 2-3 days  
**Risk:** MEDIUM

### Problem
The RestClient has 7 copies of the same HttpClient builder code (~20 lines each).

### Solution
Extract `buildHttpClient(ServiceRequest request)` method.

### Tasks
1. [ ] Add integration tests for RestClient HTTP methods
2. [ ] Extract `buildHttpClient(ServiceRequest)` method
3. [ ] Convert to try-with-resources for `CloseableHttpClient`
4. [ ] Replace `Integer.parseInt("9080")` with `9080`
5. [ ] Add proper constants:
   ```java
   private static final int INTERNAL_PROXY_PORT = 9080;
   private static final int EXTERNAL_PROXY_PORT = 8080;
   private static final int CONNECTION_TIMEOUT_MS = 600_000;
   private static final int REQUEST_TIMEOUT_MS = 600_000;
   ```
6. [ ] Replace internal JDK Log class with SLF4J

### Before
```java
public ServiceResponse performGet(ServiceRequest request) {
    // 20 lines of HttpClient builder code
}
public ServiceResponse performPost(ServiceRequest request) {
    // Same 20 lines of builder code
}
// ... repeated 5 more times
```

### After
```java
private CloseableHttpClient buildHttpClient(ServiceRequest request) {
    // Single source of truth
}

public ServiceResponse performGet(ServiceRequest request) {
    try (CloseableHttpClient client = buildHttpClient(request)) {
        // Just the GET-specific logic
    }
}
```

### Acceptance Criteria
- HttpClient builder code exists in ONE place only
- No resource leaks (try-with-resources)
- All existing tests pass
- New integration tests pass

---

## Phase 3: DataProvider Thread-Safety Fix

**Estimated Duration:** 2-3 days  
**Risk:** HIGH (thread-safety changes)

### Problem
The `dataTypes` HashMap is instance state that gets mutated during `getData()` calls. In parallel TestNG execution, multiple threads corrupt this map.

### Solution
Make `dataTypes` method-local or use `ConcurrentHashMap` with proper synchronization.

### Tasks
1. [ ] Add concurrent test demonstrating the bug
2. [ ] Option A: Make `dataTypes` method-local (preferred)
3. [ ] Option B: Use `ConcurrentHashMap` + `ThreadLocal`
4. [ ] Fix `getBaseRxData()` broken cast or deprecate
5. [ ] Replace magic numbers with named constants:
   ```java
   private static final int ALL_ROWS = -1;
   private static final int ALL_ROWS_RANDOMIZED = -2;
   ```
6. [ ] Add JavaDoc explaining the data provider contract

### Acceptance Criteria
- Concurrent test passes (multiple threads calling getData)
- No `ClassCastException` from `getBaseRxData()`
- All existing data provider tests pass
- Performance benchmark shows no regression

---

## Phase 4: PropertyReader Improvements

**Estimated Duration:** 1-2 days  
**Risk:** MEDIUM

### Tasks
1. [ ] Make `lock` field `final`
2. [ ] Fix `loadDmLocalConfig()` to not clobber vault values
3. [ ] Remove dead HashiCorp vault code
4. [ ] Rename `HasKey` → `hasKey` (keep old method as `@Deprecated`)
5. [ ] Add null-safety to `getProperty()`
6. [ ] Document initialization order in JavaDoc

### Acceptance Criteria
- Double-checked locking is correct
- Vault values not clobbered by local config
- No dead code
- All tests pass

---

## Phase 5: Utilities Cleanup

**Estimated Duration:** 2-3 days  
**Risk:** LOW

### StringUtils Tasks
1. [ ] Add null-safety to all methods
2. [ ] Use `Optional<T>` for methods that may return null
3. [ ] Consolidate duplicate date formatting code with DateUtils
4. [ ] Add input validation with clear error messages
5. [ ] Document all public methods with JavaDoc

### DateUtils Tasks
1. [ ] Migrate from `Date`/`Calendar` to `java.time` API
2. [ ] Add null-safety
3. [ ] Consolidate with StringUtils date methods
4. [ ] Add timezone-aware methods

### FileUtils Tasks
1. [ ] Review and test `getStreamFromResources()`
2. [ ] Add proper exception handling
3. [ ] Use try-with-resources consistently

### Acceptance Criteria
- All utility methods have JavaDoc
- Null inputs handled gracefully
- Modern `java.time` API used for dates
- All tests pass

---

## Phase 6: Documentation & Final Cleanup

**Estimated Duration:** 1 day  
**Risk:** LOW

### Tasks
1. [ ] Generate JavaDoc for all public APIs
2. [ ] Create CONTRIBUTING.md for the framework
3. [ ] Add CHANGELOG.md documenting all changes
4. [ ] Review and update README.md
5. [ ] Create architecture diagram
6. [ ] Final code review

### Acceptance Criteria
- JavaDoc coverage > 80%
- All public APIs documented
- Architecture diagram created
- Code review approved

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Breaking existing tests | Run full test suite after each change |
| Breaking other teams | Public API backward compatibility |
| Performance regression | Add benchmarks in Phase 3 |
| Thread-safety issues | Concurrent tests + code review |
| Merge conflicts | Small, frequent PRs |

---

## Timeline

| Phase | Duration | Dependencies |
|-------|----------|-------------|
| Phase 0 ✅ | DONE | None |
| Phase 1 | 1-2 days | Phase 0 |
| Phase 2 | 2-3 days | Phase 1 |
| Phase 3 | 2-3 days | Phase 1 |
| Phase 4 | 1-2 days | Phase 1 |
| Phase 5 | 2-3 days | Phase 1 |
| Phase 6 | 1 day | All phases |

**Total Estimated:** 10-15 business days

Phases 2-5 can run in parallel after Phase 1 is complete.

---

## Questions for You

Before I proceed to Phase 1, I want to confirm:

1. **Priority:** Which phase is most urgent for your team?
   - Thread-safety (Phase 3) affects parallel test execution
   - RestClient DRY (Phase 2) affects maintenance burden
   - Formatting (Phase 1) is lowest risk, good starting point

2. **Scope confirmation:** Should I include any additional classes in scope?
   - I noticed `CCMContext`, `AkeylessVault` - vault/config classes
   - `TestNameFilter`, `RetryAnalyzer` - TestNG utilities
   - `XMLParser` - additional utility

3. **Backward compatibility:** Are there any methods we can safely deprecate/remove?
   - `getBaseRxData()` appears broken - can we remove it?
   - HashiCorp vault code is commented out - safe to delete?

4. **Code style:** Any existing style guides I should follow?
   - Google Java Style?
   - Custom Walmart style guide?

---

## Appendix: File Inventory

### In Scope (Dragon Core)
```
src/main/java/hwqe/baseframework/
├── apicontext/         # RestClient, ServiceRequest/Response, Proxy
├── datacontext/        # DataProvider, Excel integration
├── utilities/          # StringUtils, DateUtils, FileUtils, PropertyReader
├── models/             # Environment enum, data models
├── annotations/        # Custom annotations
├── interfaces/         # Contracts
└── vaults/             # CCMContext, AkeylessVault
```

### Out of Scope (Team-Specific)
```
src/test/java/
├── bom/               # BOM team tests
├── clinicalservices/  # Clinical team tests
├── connexus/          # Connexus team tests
├── rdm/               # RDM team tests
└── rxpd/              # RXPD team tests
```
