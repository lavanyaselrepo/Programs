# Windsurf API Automation Rules & Guidelines

## Overview

This document defines the mandatory rules and best practices for creating API automation scripts in the AutomationBaseFramework. Follow these guidelines to ensure consistency, maintainability, and reliability across all API test automation.

---

## 🏗️ Architecture Pattern

### 1. Wrapper Class (Manager Pattern)

**MANDATORY**: Every API domain must have a dedicated wrapper/manager class.

**Structure:**

```
src/main/java/hwqe/baseframework/<domain>apicontext/<DomainName>APIManager.java
```

**Requirements:**

- Contains all necessary HTTP headers configuration
- Implements database interaction methods for data validation
- Provides data to test script classes for assertions
- Reuses existing database connections when available
- Handles API response parsing and validation

**Example Domains:**

- `connexuswrapperapicontext` → ConnexusAPIManager
- `digitalPharmacyapicontext` → DigitalPharmacyAPIManager
- `fom` → FOMAPIManager

### 2. Test Script Classes

**Location:** `src/test/java/<domain>/`

**Requirements:**

- Contains defined test cases using TestNG annotations
- Validates results using wrapper class methods
- May use main framework methods when wrapper methods are insufficient
- Follows naming convention: `<Feature>_<TestType>.java`

---

## 🗄️ Database Integration Rules

### Supported Databases

- **Cosmos DB** - Document database for modern applications
- **Azure SQL** - Relational database for structured data
- **Informix** - Legacy system database (Connexus, BOSS)

### Database Connection Rules

1. **Reuse Existing Connections**: Check `AutomationManager.getInstance()` for existing DB contexts
2. **Connection Methods**:
   - `am.getConnexusDB(storeId)` - Informix Connexus
   - `am.getBossDB()` - Informix BOSS
   - Custom methods for Cosmos/Azure SQL as needed
3. **Validation Pattern**:
   ```java
   // In Manager class
   public DataRow validateDatabaseRecord(String recordId) {
       IDatabaseContext db = am.getConnexusDB(storeId);
       String query = "SELECT * FROM table WHERE id = " + recordId;
       DataTable dt = db.getDataTable(query);
       Assert.assertEquals(dt.getRowCount(), 1);
       return dt.getDataRows().get(0);
   }
   ```

---

## 📝 POJO Classes (Data Models)

### Request/Response Models

**Location:** `src/main/java/hwqe/baseframework/<domain>apicontext/datamodels/`

**Structure:**

```
datamodels/
├── <endpoint>/
│   ├── <EndpointName>Request.java
│   ├── <EndpointName>Response.java
│   └── <NestedObject>.java
```

**Requirements:**

- Use proper Jackson annotations (`@JsonProperty`, `@JsonIgnoreProperties`)
- Include constructors, getters, setters
- Follow Java naming conventions
- Add validation annotations where appropriate

**Example:**

```java
@JsonIgnoreProperties(ignoreUnknown = true)
public class PharmacyParameterRequest {
    @JsonProperty("siteId")
    private int siteId;

    @JsonProperty("phmParmCode")
    private String phmParmCode;

    // Constructors, getters, setters
}
```

---

## 🧪 Test Data Management

### Test Data Locations

- **Static Data:** `src/test/resources/TestData/<domain>/`
- **Dynamic Data:** Generated via utility classes or database queries

### Data Generation Rules

1. **Random Data**: Use existing utilities or create domain-specific generators
2. **Database Data**: Retrieve via wrapper class methods
3. **Environment-Specific**: Store in configuration files per environment

### Data File Structure

```
TestData/
├── <domain>/
│   ├── <feature>/
│   │   ├── request_templates/
│   │   ├── response_samples/
│   │   └── test_datasets.xlsx
```

---

## ⚙️ Configuration Management

### Environment Configuration

**Location:** `src/test/resources/config/<domain>/`

**Environments:**

- **DEV** - Development environment
- **QE** - Quality Engineering environment
- **STG** - Staging environment

### Configuration Structure

```
config/
├── <domain>/
│   ├── dev/
│   │   ├── api.properties
│   │   └── database.properties
│   ├── qe/
│   └── stg/
```

### Security Configuration

- **CCM (Configuration Management)**: Non-sensitive runtime variables
- **Akeyless**: Sensitive data (API keys, passwords, tokens)
- **PropertyReader**: Access via `PropertyReader.getInstance().getProperty("key")`

---

## 🔧 Implementation Checklist

### Before Creating API Automation:

#### ✅ 1. Wrapper Class Setup

- [ ] Create `<Domain>APIManager.java` in appropriate package
- [ ] Implement HTTP client using existing `RestClient`
- [ ] Add database interaction methods
- [ ] Include response parsing utilities
- [ ] Add logging via `Reporter.log()`

#### ✅ 2. POJO Classes

- [ ] Create request/response models in `datamodels/` folder
- [ ] Add proper Jackson annotations
- [ ] Implement validation methods
- [ ] Test serialization/deserialization

#### ✅ 3. Test Script Class

- [ ] Create test class in `src/test/java/<domain>/`
- [ ] Use TestNG annotations (`@Test`, `@BeforeClass`, `@AfterClass`)
- [ ] Implement data providers for parameterized tests
- [ ] Add proper assertions using wrapper methods

#### ✅ 4. Configuration

- [ ] Add API endpoints to environment-specific config files
- [ ] Configure database connections if needed
- [ ] Set up authentication headers/tokens
- [ ] Validate configuration loading

#### ✅ 5. Test Data

- [ ] Create test data files in appropriate structure
- [ ] Implement data generation utilities if needed
- [ ] Set up database queries for validation data
- [ ] Test data loading and parsing

---

## 📋 Code Standards

### Naming Conventions

- **Classes**: PascalCase (`PharmacyParameterManager`)
- **Methods**: camelCase (`getPharmacyParameters`)
- **Variables**: camelCase (`siteId`, `responseData`)
- **Constants**: UPPER_SNAKE_CASE (`DEFAULT_TIMEOUT`)

### Error Handling

```java
try {
    ServiceResponse response = performAPICall(request);
    Assert.assertEquals(response.getStatusCode(), 200);
    return parseResponse(response);
} catch (Exception e) {
    Reporter.log("API call failed: " + e.getMessage());
    Assert.fail("Test failed due to: " + e.getMessage());
}
```

### Logging Standards

```java
Reporter.log("API Endpoint: " + request.getUrl());
Reporter.logJSON("Request Payload", request.getRequestPayload());
Reporter.logJSON("Response", response.getDataResponse());
```

---

## 🚫 Common Anti-Patterns to Avoid

1. **Hardcoded URLs**: Always use configuration properties
2. **Direct Database Queries in Tests**: Use wrapper methods
3. **Missing Assertions**: Every test must have meaningful validations
4. **Ignoring Response Codes**: Always validate HTTP status codes
5. **No Error Handling**: Implement proper try-catch blocks
6. **Duplicate Code**: Reuse existing utilities and methods

---

## 📚 Reference Examples

### Existing Implementations

- **Connexus**: `src/test/java/connexus/` - UI and API automation
- **FOM RxLabel**: `src/test/java/fom/rxlabel/` - Reference implementation
- **Digital Pharmacy**: `src/test/java/digitalPharmacyMobileAppTests/`

### Framework Components

- **RestClient**: `hwqe.baseframework.apicontext.RestClient`
- **ServiceRequest/Response**: `hwqe.baseframework.apicontext.*`
- **PropertyReader**: `hwqe.baseframework.utilities.PropertyReader`
- **Reporter**: `hwqe.baseframework.utilities.Reporter`

---

## 🎯 Success Criteria

A well-implemented API automation should:

1. ✅ Follow the wrapper pattern architecture
2. ✅ Include comprehensive database validations
3. ✅ Use proper POJO classes for request/response
4. ✅ Have environment-specific configurations
5. ✅ Include meaningful test data and assertions
6. ✅ Provide clear logging and error messages
7. ✅ Be maintainable and reusable across test cases

---

_This document should be referenced before creating any new API automation scripts. For questions or clarifications, consult existing implementations in the framework._
