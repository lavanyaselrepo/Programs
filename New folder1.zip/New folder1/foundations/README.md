# Foundations Backend Automation Framework

## Table of Contents

- [Overview](#overview)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Key Features](#key-features)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
  - [Running Tests](#running-tests)
- [Writing Your First Test](#writing-your-first-test)
- [Complete Test Example](#complete-test-example)
- [Property Loading Architecture](#property-loading-architecture)
- [FoundationsPropertyReader Usage](#foundationspropertyreader-usage)
- [Environment Configuration Files](#environment-configuration-files)
- [Best Practices](#best-practices)
- [Dependencies](#dependencies)
- [Integration with Main Framework](#integration-with-main-framework)
- [Looper Integration (CI/CD)](#looper-integration-cicd)
- [Troubleshooting](#troubleshooting)
- [Quick Reference](#quick-reference)
- [Support](#support)
- [Version History](#version-history)

## Overview

The **Foundations** module is a lightweight, backend-focused automation framework designed for API testing. It leverages the **Dragon Library** for common utilities and provides a clean structure with essential dependencies for REST API automation.

## Technology Stack

- **Java**: 21
- **Build Tool**: Maven 3.x
- **Test Framework**: TestNG 7.5
- **API Testing**: REST Assured 5.4.0
- **JSON Processing**: Jackson 2.15.3, Gson, JSON Path 2.8.0
- **Test Data Generation**: JavaFaker 1.0.2
- **Base Framework**: Dragon Library 2.1-SNAPSHOT
- **HW Common Library**: 1.0
- **Assertions**: AssertJ 3.18.1, Hamcrest 2.2
- **Reporting**: ExtentReports 4.1.7, TestBurst Listener 3.15
- **Boilerplate Reduction**: Lombok 1.18.38
- **Async Testing**: Awaitility 4.2.0
- **Logging**: SLF4J 1.7.36
- **Utilities**: Apache Commons, Google Guava, Commons Codec

## Project Structure

```
foundations/
├── pom.xml                              # Maven POM with backend dependencies
├── testng.xml                          # Default TestNG suite
├── README.md                           # This file
├── .gitignore                          # Git ignore rules
├── looper/
│   └── sample-api-test.yml             # Looper configuration for CI/CD
└── src/
    ├── main/
    │   └── java/
    │       └── foundations/
    │           ├── api/
    │           │   └── SampleApiWrapper.java    # API wrapper with reusable methods
    │           ├── base/
    │           │   └── BaseApi.java             # Base class for API tests
    │           ├── config/
    │           │   └── FoundationsPropertyReader.java  # Works with Dragon Library PropertyReader
    │           └── models/
    │               ├── request/
    │               │   └── SampleRequest.java   # Request POJO model
    │               └── response/
    │                   └── SampleResponse.java  # Response POJO model
    └── test/
        ├── java/
        │   └── foundations/
        │       └── sample/
        │           └── SampleApiTest.java       # Sample API test with POJO models
        └── resources/
            ├── config/
            │   ├── stg.properties       # Stage environment config
            │   ├── dev.properties       # Dev environment config
            │   └── qe.properties        # QE environment config
            ├── testdata/
            │   └── sample-test-data.json # Sample test data
            └── suites/
                └── sample.xml           # Sample test suite
```

## Key Features

### 1. **Dragon Library Integration**

- Uses Dragon Library (2.1-SNAPSHOT) for common utilities and Reporter
- `FoundationsPropertyReader` uses composition pattern with Dragon Library's `PropertyReader`
- Leverages existing framework utilities (CommonUtils, Reporter) for consistency

### 2. **Environment-Specific Configuration**

- Three environment properties files: `stg.properties`, `dev.properties`, `qe.properties`
- `FoundationsPropertyReader` loads configuration based on environment parameter
- Easy switching between environments via TestNG parameters or command line

### 3. **BaseApi Class**

- Pre-configured RestAssured request and response specifications
- Integrated with `FoundationsPropertyReader`
- Environment-based configuration (stg, dev, qe)
- Automatic initialization of API wrappers
- Common setup methods for all API tests

### 4. **Property Reader with Unified Access**

- Uses composition with Dragon Library's `PropertyReader`
- Loads environment-specific properties configuration
- Provides typed getters for common properties (baseUri, timeout, retryCount, apiVersion, etc.)
- Unified access to all property sources (Foundations, Dragon Library, Akeyless, CCM)
- Singleton pattern for efficiency

### 5. **POJO Models**

- Request and Response POJO models using Lombok
- Type-safe API interaction
- Clean separation between request/response structures
- Easy serialization/deserialization with Jackson

### 6. **API Wrapper Pattern**

- Reusable API wrapper classes following Dragon Library pattern
- Centralized API method implementations
- Built-in Reporter logging for all API calls
- POJO-based methods for type safety
- Support for GET, POST, PUT, DELETE operations

### 7. **Sample Tests**

- Demonstrates PropertyReader usage with unified property access
- GET, POST request examples using POJO models
- Test data driven from JSON files using CommonUtils
- Reporter logging integration
- Environment-specific testing patterns

## Getting Started

### Prerequisites

- Java 21 or higher
- Maven 3.6 or higher
- IDE (IntelliJ IDEA, Eclipse, or VS Code)

### Project Setup

Follow these steps to import the Foundations module into IntelliJ as part of the Dragon project:

1. Import the Dragon project in IntelliJ IDEA
2. Go to **File → Project Structure → Modules**
3. Click on the **+** icon → **Import Module**
4. Select the **foundations** module directory
5. Select **Import module from external sources**
6. Select the **Maven** radio button
7. Click **OK**
8. Build both Dragon and Foundations Module:

```bash
mvn clean install -DskipTests
```

### Installation

1. Navigate to the foundations module:

```bash
cd /path/to/project/foundations
```

2. Build the project:

```bash
mvn clean install
```

### Running Tests

#### Run with default environment (stg):

```bash
mvn test -DsuiteXmlFile=src/test/resources/suites/sample.xml
```

#### Run with specific environment:

```bash
# Dev environment
mvn test -DsuiteXmlFile=src/test/resources/suites/sample.xml -Denvironment=dev

# QE environment
mvn test -DsuiteXmlFile=src/test/resources/suites/sample.xml -Denvironment=qe

# Stage environment
mvn test -DsuiteXmlFile=src/test/resources/suites/sample.xml -Denvironment=stg
```

#### Run specific test:

```bash
mvn test -Dtest=SampleApiTest
```

#### Run specific test method:

```bash
mvn test -Dtest=SampleApiTest#testSampleApiRequest
```

#### Run tests with specific group:

```bash
mvn test -Dgroups=smoke
mvn test -Dgroups=pojo
```

## Writing Your First Test

### 1. Create a Test Class

```java
package foundations.yourpackage;

import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.base.BaseApi;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class YourApiTest extends BaseApi {

    @Test(description = "Your test description", groups = {"smoke"})
    public void testYourApi() {
        // Use PropertyReader for configuration
        String baseUri = propertyReader.getBaseUri();
        String apiVersion = propertyReader.getApiVersion();
        String endpoint = propertyReader.getEndpoint("yourEndpoint");

        Reporter.log("Testing on: " + baseUri);
        Reporter.log("API Version: " + apiVersion);

        // Arrange
        String requestBody = "{ \"key\": \"value\" }";

        // Act - Use Reporter for logging instead of System.out
        Reporter.log("Sending POST request to: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);

        Response response = given()
                .spec(requestSpec)
                .body(requestBody)
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();

        // Assert
        Assert.assertEquals(response.getStatusCode(), 200);
        Reporter.log("Response Status: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().prettyPrint());
    }
}
```

### 2. Add Environment Configuration

Edit `src/test/resources/config/stg.properties` (or dev.properties, qe.properties):

```properties
# Stage Environment Configuration
environment=stg
baseUri=https://api-stage.walmart.com
timeout=30000
retryCount=3
apiVersion=v1
enableLogging=true
maxConnections=10

# Endpoints
endpoints.health=/health
endpoints.yourEndpoint=/api/your/endpoint

# Custom Properties
yourCustomProperty=yourValue
```

Access in test:

```java
// Access any property through unified property reader
String customValue = propertyReader.getProperty("yourCustomProperty");
String endpoint = propertyReader.getEndpoint("yourEndpoint");
```

### 3. Create POJO Models

Create request and response models in `src/main/java/foundations/models/`:

**Request Model:**

```java
package foundations.models.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class YourRequest {
    private String name;
    private String value;
    private String description;
    private boolean isActive;
}
```

**Response Model:**

```java
package foundations.models.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class YourResponse {
    private String id;
    private String name;
    private String value;
    private String status;
    private long timestamp;
}
```

### 4. Create API Wrapper

Create a wrapper class in `src/main/java/foundations/api/`:

```java
package foundations.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.config.FoundationsPropertyReader;
import foundations.models.request.YourRequest;
import foundations.models.response.YourResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

public class YourApiWrapper {

    private FoundationsPropertyReader propertyReader;
    private RequestSpecification requestSpec;
    private ObjectMapper objectMapper;

    public YourApiWrapper(RequestSpecification requestSpec) {
        this.requestSpec = requestSpec;
        this.propertyReader = FoundationsPropertyReader.getInstance();
        this.objectMapper = new ObjectMapper();
    }

    public YourResponse createResource(YourRequest request) {
        try {
            String endpoint = propertyReader.getEndpoint("yourEndpoint");
            String requestBody = objectMapper.writeValueAsString(request);

            Reporter.log("Creating resource");
            Reporter.logJSON("Request Body:", requestBody);

            Response response = given()
                    .spec(requestSpec)
                    .body(requestBody)
                    .when()
                    .post(endpoint)
                    .then()
                    .extract()
                    .response();

            Reporter.log("Response Status Code: " + response.getStatusCode());
            Reporter.logJSON("Response Body:", response.body().asString());

            return response.as(YourResponse.class);
        } catch (Exception e) {
            Reporter.log("Error creating resource: " + e.getMessage());
            throw new RuntimeException("Failed to create resource", e);
        }
    }
}
```

### 5. Create Test Data

Create a JSON file in `src/test/resources/testdata/`:

```json
{
  "testYourApiRequest": {
    "name": "Test Item",
    "value": "Test Value",
    "description": "This is a test item",
    "isActive": true,
    "expectedStatusCode": 201
  },
  "testGetYourResource": {
    "resourceId": "12345",
    "expectedStatusCode": 200
  }
}
```

**Load test data in your test:**

```java
@Test
public void testYourApiRequest(Method method) {
    // Load test data using CommonUtils from Dragon Library
    JSONObject testData = new CommonUtils().getJsonTestData(
        "src/test/resources/testdata/your-test-data.json",
        method.getName()
    );

    // Access test data
    String name = testData.get("name").toString();
    int expectedStatusCode = Integer.parseInt(testData.get("expectedStatusCode").toString());

    // Use in your test...
}
```

### 6. Create a TestNG Suite

Create an XML file in `src/test/resources/suites/`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd">
<suite name="Your Test Suite" verbose="1">
    <parameter name="environment" value="stg"/>

    <test name="Your Tests">
        <classes>
            <class name="foundations.yourpackage.YourApiTest"/>
        </classes>
    </test>
</suite>
```

Or run by test groups:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd">
<suite name="Smoke Test Suite" verbose="1">
    <parameter name="environment" value="stg"/>

    <test name="Smoke Tests">
        <groups>
            <run>
                <include name="smoke"/>
            </run>
        </groups>
        <packages>
            <package name="foundations.*"/>
        </packages>
    </test>
</suite>
```

## Complete Test Example

Here's a complete example showing how all components work together:

**Test Class** (`src/test/java/foundations/user/UserApiTest.java`):

```java
package foundations.user;

import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.base.BaseApi;
import foundations.models.request.CreateUserRequest;
import foundations.models.response.UserResponse;
import foundations.api.UserApiWrapper;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

public class UserApiTest extends BaseApi {

    private UserApiWrapper userApiWrapper;
    private String jsonPath = "src/test/resources/testdata/user-test-data.json";

    @Override
    @BeforeMethod
    public void setupTest() {
        super.setupTest();
        // Initialize your custom wrapper
        userApiWrapper = new UserApiWrapper(requestSpec);
    }

    @Test(description = "Create user with valid data", groups = {"smoke", "user"})
    public void testCreateUserWithValidData(Method method) {
        // Load test data
        JSONObject testData = new CommonUtils().getJsonTestData(jsonPath, method.getName());

        Reporter.log("Test: " + method.getName());
        Reporter.log("Environment: " + propertyReader.getEnvironmentName());

        // Build request using POJO
        CreateUserRequest request = CreateUserRequest.builder()
                .username(testData.get("username").toString())
                .email(testData.get("email").toString())
                .firstName(testData.get("firstName").toString())
                .lastName(testData.get("lastName").toString())
                .build();

        // Execute via wrapper
        UserResponse response = userApiWrapper.createUser(request);

        // Assertions
        Assert.assertNotNull(response.getId(), "User ID should not be null");
        Assert.assertEquals(response.getUsername(), testData.get("username").toString());
        Assert.assertEquals(response.getStatus(), "ACTIVE");

        Reporter.log("Created user with ID: " + response.getId());
    }
}
```

This example demonstrates:

- ✅ Extending `BaseApi` for automatic setup
- ✅ Using `CommonUtils` to load test data
- ✅ Using `Reporter` for logging
- ✅ POJO models with Lombok builders
- ✅ API wrapper pattern
- ✅ PropertyReader for configuration
- ✅ TestNG groups for organization

## Property Loading Architecture

### How It Works

The `FoundationsPropertyReader` provides **unified access** to properties from multiple sources with automatic fallback using **composition pattern**:

```
┌─────────────────────────────────────┐
│  propertyReader.getProperty("key")  │
└─────────────────────────────────────┘
              ↓
    ┌──────────────────────────────┐
    │ 1. Check Properties First    │  ← Foundations Properties (stg.properties, dev.properties, qe.properties)
    └──────────────────────────────┘
              ↓ If not found
    ┌─────────────────────┐
    │ 2. Dragon Library   │  ← Via composition: dragonPropertyReader.getProperty(key)
    └─────────────────────┘
              ↓
    ┌─────────────────────────────────────┐
    │ Dragon Library automatically loads: │
    │  ✓ config.properties                │
    │  ✓ Akeyless Vault secrets           │
    │  ✓ CCM properties                   │
    │  ✓ OS-specific properties           │
    └─────────────────────────────────────┘
```

### Property Sources (Priority Order)

1. **Foundations Properties Files** (Highest Priority)
   - `src/test/resources/config/stg.properties`
   - `src/test/resources/config/dev.properties`
   - `src/test/resources/config/qe.properties`

2. **Dragon Library Properties** (via composition)
   - `config/config.properties`
   - OS-specific files (windows/mac/linux.properties)

3. **Akeyless Vault** (via Dragon Library)
   - Secrets, API keys, credentials
   - Loaded automatically

4. **CCM - Central Configuration Management** (via Dragon Library)
   - Centralized configuration
   - Loaded automatically

### Property Precedence

If the same key exists in multiple sources, it will be retrieved from the **highest priority** source:

```
Foundations Properties (stg/dev/qe.properties)    ← Highest Priority
    ↓
Dragon Library (config.properties)
    ↓
Akeyless Vault
    ↓
CCM
    ↓
OS-specific properties                            ← Lowest Priority
```

## FoundationsPropertyReader Usage

### Available Methods

```java
// Get instance
FoundationsPropertyReader propertyReader = FoundationsPropertyReader.getInstance();

// Unified access - checks ALL sources automatically
String baseUri = propertyReader.getProperty("baseUri");        // From .properties
String dbUrl = propertyReader.getProperty("db.url");            // From config.properties
String apiKey = propertyReader.getProperty("api.key");          // From Akeyless
String ccmValue = propertyReader.getProperty("ccm.setting");    // From CCM

// Foundations-specific typed getters (from .properties)
String baseUri = propertyReader.getBaseUri();
int timeout = propertyReader.getTimeout();
int retryCount = propertyReader.getRetryCount();
String apiVersion = propertyReader.getApiVersion();
boolean loggingEnabled = propertyReader.isLoggingEnabled();
int maxConnections = propertyReader.getMaxConnections();
String environment = propertyReader.getEnvironmentName();

// Get endpoint from config
String healthEndpoint = propertyReader.getEndpoint("health");  // Gets "endpoints.health" value

// Get property with default value
String customValue = propertyReader.getProperty("customKey", "defaultValue");

// Access only Foundations properties
String foundationsValue = propertyReader.getFoundationsProperty("baseUri");

// Access only Dragon Library properties
String dragonValue = propertyReader.getDragonProperty("db.url");

// Direct Dragon Library access
PropertyReader dragonReader = propertyReader.getDragonPropertyReader();

// Full Foundations config as Properties
Properties config = propertyReader.getConfig();

// Set environment programmatically (useful for testing)
propertyReader.setEnvironment("qe");
```

### Usage Examples

#### Example 1: API Configuration

```java
@Test
public void testApiCall() {
    // Get base URI from JSON
    String baseUri = propertyReader.getBaseUri();

    // Get API key from Akeyless
    String apiKey = propertyReader.getProperty("api.secret.key");

    // Make API call with config from multiple sources
    Response response = given()
        .baseUri(baseUri)
        .header("API-Key", apiKey)
        .when()
        .get("/endpoint");
}
```

#### Example 2: Database Connection

```java
@Test
public void testDatabaseQuery() {
    // Get DB config from Dragon Library
    String dbUrl = propertyReader.getProperty("db.connection.url");
    String dbUser = propertyReader.getProperty("db.username");

    // Get DB password from Akeyless
    String dbPassword = propertyReader.getProperty("db.password");

    // Use credentials
}
```

#### Example 3: Environment-Specific Testing

```java
@Test
public void testEnvironmentSpecific() {
    // Check environment
    String env = propertyReader.getEnvironmentName();
    System.out.println("Running on: " + env);

    // Get environment-specific base URI
    String baseUri = propertyReader.getBaseUri();

    // Property automatically switches based on environment
    // stg → stg.json, dev → dev.json, qe → qe.json
}
```

## Environment Configuration Files

### Structure

Each environment file (`stg.properties`, `dev.properties`, `qe.properties`) contains:

```properties
# Stage Environment Configuration
environment=stg
baseUri=https://api-stage.walmart.com
timeout=30000
retryCount=3
apiVersion=v1
enableLogging=true
maxConnections=10

# Endpoints
endpoints.health=/health
endpoints.sample=/api/sample
endpoints.search=/api/search
endpoints.user=/api/user
endpoints.order=/api/order
```

### Switching Environments

**Option 1: TestNG XML**

```xml
<parameter name="environment" value="dev"/>
```

**Option 2: Command Line**

```bash
mvn test -Denvironment=qe
```

**Option 3: System Property**

```java
System.setProperty("environment", "dev");
```

## Best Practices

### 1. **Use Dragon Library Utilities**

- Don't recreate utilities that exist in Dragon Library
- Use `CommonUtils` for JSON test data loading
- Use `Reporter` for all logging instead of System.out.println()
- Leverage Dragon Library's existing utilities and patterns

### 2. **API Wrapper Pattern**

- Create API wrapper classes for each API domain (e.g., `UserApiWrapper`, `OrderApiWrapper`)
- Keep all API interaction logic in wrapper classes
- Build POJOs inside wrapper methods for cleaner test code
- Follow the `SampleApiWrapper` pattern for consistency

### 3. **POJO Models**

- Use Lombok annotations (`@Builder`, `@Data`, `@AllArgsConstructor`, etc.)
- Separate request and response models
- Keep models in `models/request/` and `models/response/` packages
- Use Jackson annotations for serialization/deserialization

### 4. **Property Reader Usage**

- Always use `FoundationsPropertyReader` for configuration
- Store all environment-specific values in `.properties` config files
- Don't hardcode URLs, timeouts, or environment-specific values
- Use `getEndpoint()` method for endpoint paths
- Leverage unified property access for all property sources

### 5. **Test Organization**

- Extend `BaseApi` for all API test classes
- Use meaningful package names under `foundations.{domain}`
- Group related tests together
- Use TestNG groups for categorization (e.g., `smoke`, `regression`, `pojo`)

### 6. **Reporter Logging**

- Use `Reporter.log()` for general logging
- Use `Reporter.logJSON()` for JSON request/response logging
- Log test configurations, environment details, and key test data
- Never use `System.out.println()` in tests

### 7. **Environment Management**

- Keep environment files in sync (same structure/keys)
- Document any custom properties added
- Use consistent naming across environments
- Prefix endpoint keys with `endpoints.`

### 8. **Naming Conventions**

- Test methods: `test<Feature><Scenario>()` (e.g., `testCreateUserWithValidData()`)
- Test classes: `<Feature>Test.java` (e.g., `UserManagementTest.java`)
- API wrappers: `<Domain>ApiWrapper.java` (e.g., `UserApiWrapper.java`)
- Request POJOs: `<Feature>Request.java` (e.g., `CreateUserRequest.java`)
- Response POJOs: `<Feature>Response.java` (e.g., `UserResponse.java`)

## Dependencies

### Core Testing

- REST Assured 5.4.0 (rest-assured, json-path, xml-path)
- TestNG 7.5
- Dragon Library 2.1-SNAPSHOT
- HW Common Library 1.0

### JSON Processing

- Jackson 2.15.3 (databind, core, annotations, datatype-jsr310)
- Gson 2.10.1
- JSON Simple 1.1.1
- JSON Path 2.8.0

### Utilities

- Apache Commons Lang3 3.1
- Apache Commons IO 2.5
- Apache Commons Collections4 4.3
- Apache Commons Codec 1.17.2
- Google Guava 31.0.1-jre
- JavaFaker 1.0.2 (test data generation)
- Lombok 1.18.38 (boilerplate reduction)

### Assertions & Testing

- AssertJ 3.18.1
- Hamcrest 2.2
- Awaitility 4.2.0 (async testing)
- JUnit 4.12 (optional, migration support)

### HTTP Clients

- Apache HTTP Client 4.5.2
- Apache HTTP Core 4.4.4
- Commons HTTP Client 3.1

### Logging

- SLF4J API 1.7.36
- SLF4J Simple 1.7.36

### Reporting

- ExtentReports 4.1.7
- TestBurst Listener 3.15 (Walmart specific)
- TestBurst Listener 1.0.96 (Walmart specific)

## Integration with Main Framework

### As Standalone Module

Navigate to the foundations directory and run tests directly:

```bash
cd foundations
mvn clean test -DsuiteXmlFile=src/test/resources/suites/sample.xml -Denvironment=stg
```

### As Dependency

Add to another module's pom.xml:

```xml
<dependency>
    <groupId>com.walmart.hwqe</groupId>
    <artifactId>foundations</artifactId>
    <version>1.0-SNAPSHOT</version>
</dependency>
```

## Looper Integration (CI/CD)

The module includes Looper configuration for automated test execution in CI/CD pipelines.

### Looper Configuration

Located at `looper/sample-api-test.yml`, this file defines how tests run in the Looper framework:

- Test suite selection
- Environment configuration
- Parallel execution settings
- Retry policies
- Reporting configuration

### Running via Looper

Tests can be triggered through Looper for automated regression and continuous testing:

```bash
# Looper will use the configuration in looper/sample-api-test.yml
looper run foundations/looper/sample-api-test.yml
```

### Creating Additional Looper Configs

For different test scenarios (smoke, regression, specific features):

1. Create new YAML file in `looper/` directory
2. Configure suite path, environment, and execution parameters
3. Reference the appropriate TestNG suite XML
4. Set up test groups and parallel execution as needed

## Troubleshooting

### Common Issues

1. **PropertyReader Not Finding Config File**
   - Verify environment parameter is set correctly (stg, dev, or qe)
   - Check that `.properties` files exist in `src/test/resources/config/`
   - Ensure properties files have correct syntax (key=value format)
   - Check for typos in property keys

2. **Build Failures**
   - Ensure Java 21 is installed and configured
   - Run `mvn clean` before building
   - Check Dragon Library dependency is accessible from Walmart Nexus
   - Verify network access to `repo.wal-mart.com` and `gec-maven-nexus.walmart.com`

3. **Test Failures**
   - Verify environment configuration in properties files
   - Check base URI is correct for the target environment
   - Review logs for PropertyReader initialization messages
   - Ensure endpoints are properly configured with `endpoints.` prefix
4. **Lombok Not Working**
   - Enable annotation processing in IDE
   - Install Lombok plugin for IntelliJ/Eclipse
   - Rebuild project after enabling Lombok

5. **Reporter Logging Issues**
   - Verify Dragon Library is properly initialized
   - Check TestNG listeners are configured
   - Ensure ExtentReports and TestBurst dependencies are available

6. **Surefire Plugin References Wrong Suite**
   - The `pom.xml` default suite references `smoke.xml` which doesn't exist
   - Either create `smoke.xml` or update `pom.xml` to reference `sample.xml`
   - Or override at runtime: `mvn test -DsuiteXmlFile=src/test/resources/suites/sample.xml`

## Quick Reference

### Key Components

| Component                   | Location                                     | Purpose                      |
| --------------------------- | -------------------------------------------- | ---------------------------- |
| `BaseApi`                   | `src/main/java/foundations/base/`            | Base class for all API tests |
| `FoundationsPropertyReader` | `src/main/java/foundations/config/`          | Unified property access      |
| API Wrappers                | `src/main/java/foundations/api/`             | Reusable API methods         |
| Request Models              | `src/main/java/foundations/models/request/`  | Request POJOs                |
| Response Models             | `src/main/java/foundations/models/response/` | Response POJOs               |
| Config Files                | `src/test/resources/config/`                 | Environment properties       |
| Test Data                   | `src/test/resources/testdata/`               | JSON test data               |
| Test Suites                 | `src/test/resources/suites/`                 | TestNG XML suites            |
| Looper Config               | `looper/`                                    | CI/CD configuration          |

### Common Commands

```bash
# Build the module
mvn clean install

# Run all tests (default environment: stg)
mvn test

# Run with specific environment
mvn test -Denvironment=dev

# Run specific test class
mvn test -Dtest=SampleApiTest

# Run specific test method
mvn test -Dtest=SampleApiTest#testSampleApiRequest

# Run by test group
mvn test -Dgroups=smoke
```

### Property Access Patterns

```java
// Environment-specific properties
propertyReader.getProperty("baseUri")          // From stg/dev/qe.properties
propertyReader.getProperty("endpoints.health")  // From stg/dev/qe.properties

// Typed getters
propertyReader.getBaseUri()
propertyReader.getTimeout()
propertyReader.getEndpoint("health")

// Dragon Library properties
propertyReader.getProperty("db.url")           // From config.properties or Akeyless
propertyReader.getDragonProperty("db.url")     // Explicitly from Dragon Library
```

## Support

For questions or issues:

- Check sample tests in `foundations.sample` for examples
- Review JavaDoc in `FoundationsPropertyReader.java`
- Examine `SampleApiWrapper.java` for API wrapper patterns
- Consult Dragon Library documentation
- Reach out to the QA Automation team

## Version History

- **1.0-SNAPSHOT** (January 2026)
  - Initial release
  - Dragon Library integration via composition pattern
  - FoundationsPropertyReader implementation with unified property access
  - Environment-specific properties configuration (stg, dev, qe)
  - POJO models with Lombok support
  - API wrapper pattern implementation
  - Reporter logging integration
  - Sample tests demonstrating best practices
  - Looper CI/CD integration
  - HW Common Library integration
  - TestBurst listener support

---

**Last Updated**: January 21, 2026  
**Maintained By**: QA Automation Team  
**Module Status**: Active Development
