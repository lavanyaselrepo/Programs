package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy Update Enrollment preference endpoint (POST).
 *
 * <p>Endpoint: {@code POST /proxy/v1/customer/{id}/domain/{domain}/notification/preference}
 *
 * <p>Covers success scenarios (caregiver enroll/unenroll, caregiver + dependent enroll)
 * and negative scenarios (invalid URL params, invalid payload fields, invalid preference fields).
 *
 * <p>All test data lives under {@code testdata/cpo/v3/8.proxy/updateenrollment/}.
 */
public class ProxyUpdateEnrollmentApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/8.proxy/updateenrollment/";

    // ── Success — Caregiver Only ────────────────────────────────────────────

    @Test(description = "Update enrollment preference for only caregiver for enrollment - expects 200")
    public void proxyUpdateEnrollmentCaregiverEnroll(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment preference for only caregiver for unenrollment - expects 200")
    public void proxyUpdateEnrollmentCaregiverUnenroll(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Success — Caregiver + Dependent ─────────────────────────────────────

    @Test(description = "Update enrollment preference for caregiver and a dependent enrollment - expects 200")
    public void proxyUpdateEnrollmentCaregiverAndDependentEnroll(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Both Unenroll ────────────────────────────────────────────

    @Test(description = "Update enrollment for caregiver and dependent both unenrollment - expects 400 only one opt-out allowed")
    public void proxyUpdateEnrollmentBothUnenrollNotAllowed(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid URL Parameters ───────────────────────────────────

    @Test(description = "Update enrollment with invalid customerAccountId in URL - expects 400")
    public void proxyUpdateEnrollmentInvalidCustomerIdInUrl(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment with invalid domainId in URL - expects 400")
    public void proxyUpdateEnrollmentInvalidDomainInUrl(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Payload CustomerAccountId ────────────────────────

    @Test(description = "Update enrollment with invalid primary customerAccountId in payload - expects 400")
    public void proxyUpdateEnrollmentInvalidPrimaryCustomerIdInPayload(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment with invalid dependent customerAccountId in payload - expects 400")
    public void proxyUpdateEnrollmentInvalidDependentCustomerIdInPayload(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Source ───────────────────────────────────────────

    @Test(description = "Update enrollment with invalid source (DP1) in payload - expects 500")
    public void proxyUpdateEnrollmentInvalidSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Primary isDependent=true ─────────────────────────────────

    @Test(description = "Update enrollment with primary isDependent=true in payload - expects 400")
    public void proxyUpdateEnrollmentPrimaryIsDependentTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Preference Fields ────────────────────────────────

    @Test(description = "Update enrollment with invalid preferences.type (SM) in payload - expects 500")
    public void proxyUpdateEnrollmentInvalidPreferenceType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment with invalid preferences.value (11 digits) in payload - expects 400")
    public void proxyUpdateEnrollmentInvalidPreferenceValue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment with invalid preferences.program (WALMART R) in payload - expects 400")
    public void proxyUpdateEnrollmentInvalidPreferenceProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update enrollment with invalid preferences.status (NENROLLED) in payload - expects 400")
    public void proxyUpdateEnrollmentInvalidPreferenceStatus(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Dependent isDependent=false ──────────────────────────────

    @Test(description = "Update enrollment with dependent isDependent=false in payload - expects 400")
    public void proxyUpdateEnrollmentDependentIsDependentFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
