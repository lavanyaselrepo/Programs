package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO {@code /preferences/email/unsubscribe} endpoint.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/4.emailunsubscribe/}.
 * Each JSON file contains exactly one test-case block keyed by the test method name.
 *
 * <p>Covers the happy-path unsubscribe scenario and three negative cases:
 * missing source field, invalid/corrupt prefInfo encoding, and upstream service error (503).
 */
public class EmailUnsubscribeApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/4.emailunsubscribe/";

    @Test(description = "Email unsubscribe successfully - expects 200 with Unsubscribed Successfully")
    public void unsubscribeEmailSuccess(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email unsubscribe with missing source field - expects 400")
    public void unsubscribeEmailMissingSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email unsubscribe with invalid/corrupt prefInfo encoding - expects 400")
    public void unsubscribeEmailInvalidPrefInfo(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email unsubscribe with upstream service unavailable - expects 503")
    public void unsubscribeEmailServiceUnavailable(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
