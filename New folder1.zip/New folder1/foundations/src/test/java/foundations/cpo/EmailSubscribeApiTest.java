package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO {@code /preferences/email/subscribe} endpoint.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/3.emailsubscribe/}.
 * Each JSON file contains exactly one test-case block keyed by the test method name.
 *
 * <p>Covers the happy-path subscribe scenario and three negative cases:
 * missing source field, invalid/corrupt prefInfo encoding, and upstream service error (503).
 */
public class EmailSubscribeApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/3.emailsubscribe/";

    @Test(description = "Email subscribe successfully - expects 200 with Subscribed Successfully")
    public void subscribeEmailSuccess(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email subscribe with missing source field - expects 400")
    public void subscribeEmailMissingSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email subscribe with invalid/corrupt prefInfo encoding - expects 400")
    public void subscribeEmailInvalidPrefInfo(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Email subscribe with upstream service unavailable - expects 503")
    public void subscribeEmailApiError(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
