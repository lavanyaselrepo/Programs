package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getPrefDataV2 endpoint.
 *
 * <p>Endpoint: {@code POST /getPrefDataV2}
 *
 * <p>This API retrieves patient notification preferences (SMS/Voice enrollment status).
 * Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getprefdatav2/}.
 */
public class GetPrefDataV2ProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/6.getprefdatav2/";

    @Test(description = "Get pref data V2 for enrolled patient - SMS, RX, Walmart (buType=1) - expects 200 SUCCESS")
    public void proxyGetPrefDataV2EnrolledSmsRxWalmart(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 for enrolled patient - SMS, RX, SAMs (buType=18) - expects 200 SUCCESS")
    public void proxyGetPrefDataV2EnrolledSmsRxSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 for not enrolled patient - expects 200 SUCCESS with empty patientPreferences")
    public void proxyGetPrefDataV2NotEnrolledPatient(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with isEmailRequired=true - SMS + Email preferences - expects 200 SUCCESS")
    public void proxyGetPrefDataV2IsEmailRequiredTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with isPmsRequest=true - returns msgEnrollStatusVal and toolTipCode - expects 200 SUCCESS")
    public void proxyGetPrefDataV2IsPmsRequestTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with invalid storeNbr (non-numeric) - expects error")
    public void proxyGetPrefDataV2InvalidStoreNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with invalid patientId (non-numeric) - expects error")
    public void proxyGetPrefDataV2InvalidPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with invalid buType (99) - expects error")
    public void proxyGetPrefDataV2InvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with invalid shortCodeType (INVALID) - expects error")
    public void proxyGetPrefDataV2InvalidShortCodeType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V2 with missing isEmailRequired - expects error or default behavior")
    public void proxyGetPrefDataV2MissingIsEmailRequired(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
