package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getEnrolledPatients endpoint.
 *
 * <p>Endpoint: {@code POST /getEnrolledPatients}
 *
 * <p>This API retrieves enrolled patients by phone number. Unlike other proxy APIs that
 * search by patientId/storeNbr, this one uses {@code phoneNbr} as the primary lookup key.
 *
 * <p>Required param: {@code phoneNbr}.
 * Optional filters: {@code notificationType} (default 1/SMS), {@code buType} (default null=both),
 * {@code shortCodeType} (default null=both).
 *
 * <p>Response (200): array of enrolled patient objects with {@code storeNbr}, {@code patientId},
 * {@code buType}, {@code shortCodeType}, {@code notificationType}.
 * <p>Response (204): no content — phone number has no enrollments.
 * <p>Response (400): validation error with {@code statusCode=102}.
 *
 * <p>Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getenrolledpatients/}.
 */
public class GetEnrolledPatientsProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/11.getenrolledpatients/";

    @Test(description = "Get enrolled patients by phone number only (defaults) - expects 200 SUCCESS")
    public void proxyGetEnrolledPatientsPhoneOnly(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients with all params - notificationType=1, buType=1, shortCodeType=RX - expects 200 SUCCESS")
    public void proxyGetEnrolledPatientsAllParams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients filtered by SAMs (buType=18) - expects 200 SUCCESS")
    public void proxyGetEnrolledPatientsSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients for phone with no enrollments - expects 204 No Content")
    public void proxyGetEnrolledPatientsNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients with invalid phoneNbr (non-numeric) - expects 400 Validation Error")
    public void proxyGetEnrolledPatientsInvalidPhoneNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients with invalid buType (99) - expects 400 Validation Error")
    public void proxyGetEnrolledPatientsInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrolled patients with invalid notificationType (99) - expects 400 Validation Error")
    public void proxyGetEnrolledPatientsInvalidNotificationType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
