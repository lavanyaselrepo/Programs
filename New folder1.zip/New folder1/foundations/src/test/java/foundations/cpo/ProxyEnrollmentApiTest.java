package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy Enrollment preference endpoints.
 *
 * <p>These endpoints proxy to the V2 notification preference service:
 * <ul>
 *   <li>GET  {@code /proxy/v1/customer/{id}/domain/{domain}/notification/preference} — query preferences</li>
 *   <li>POST {@code /proxy/v1/customer/{id}/domain/{domain}/notification/preference} — update preferences</li>
 * </ul>
 *
 * <p>Tests that require a specific enrollment state use a setup step (POST) before the actual
 * GET assertion. All test data lives under {@code testdata/cpo/v3/8.proxy/getenrollment/}.
 */
public class ProxyEnrollmentApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/8.proxy/getenrollment/";

    // ── Caregiver only (dependentsInfo=false) ────────────────────────────────

    @Test(description = "Get enrollment preference for caregiver when not enrolled - expects 200 with empty preferences")
    public void proxyGetEnrollmentPrefCaregiverNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference for caregiver when enrolled - expects 200 with ENROLLED preference")
    public void proxyGetEnrollmentPrefCaregiverEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Caregiver + Dependent (dependentsInfo=true) ──────────────────────────

    @Test(description = "Get enrollment preference for caregiver and dependent when both are enrolled - expects 200")
    public void proxyGetEnrollmentPrefCaregiverAndDependentBothEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference for caregiver enrolled and dependent not enrolled - expects 200")
    public void proxyGetEnrollmentPrefCaregiverEnrolledDependentNot(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Dependent ID in path param — not enrolled ────────────────────────────

    @Test(description = "Get enrollment preference with dependent ID and dependentsInfo=true when not enrolled - expects 200")
    public void proxyGetEnrollmentPrefDependentIdDepsInfoTrueNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference with dependent ID and dependentsInfo=false when not enrolled - expects 200")
    public void proxyGetEnrollmentPrefDependentIdDepsInfoFalseNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Dependent ID in path param — enrolled ────────────────────────────────

    @Test(description = "Get enrollment preference with dependent ID and dependentsInfo=true when enrolled - expects 200")
    public void proxyGetEnrollmentPrefDependentIdDepsInfoTrueEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference with dependent ID and dependentsInfo=false when enrolled - expects 200")
    public void proxyGetEnrollmentPrefDependentIdDepsInfoFalseEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Customer ID ───────────────────────────────────────

    @Test(description = "Get enrollment preference with invalid customer ID and dependentsInfo=true - expects 400")
    public void proxyGetEnrollmentPrefInvalidCustomerIdDepsInfoTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference with invalid customer ID and dependentsInfo=false - expects 400")
    public void proxyGetEnrollmentPrefInvalidCustomerIdDepsInfoFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Domain ────────────────────────────────────────────

    @Test(description = "Get enrollment preference with invalid domain and dependentsInfo=true - expects 400")
    public void proxyGetEnrollmentPrefInvalidDomainDepsInfoTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference with invalid domain and dependentsInfo=false - expects 400")
    public void proxyGetEnrollmentPrefInvalidDomainDepsInfoFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Negative — Invalid Type ──────────────────────────────────────────────

    @Test(description = "Get enrollment preference with invalid type (VOICE) and dependentsInfo=true - expects 400")
    public void proxyGetEnrollmentPrefInvalidTypeDepsInfoTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get enrollment preference with invalid type (VOICE) and dependentsInfo=false - expects 400")
    public void proxyGetEnrollmentPrefInvalidTypeDepsInfoFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testProxyEnrollmentApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
