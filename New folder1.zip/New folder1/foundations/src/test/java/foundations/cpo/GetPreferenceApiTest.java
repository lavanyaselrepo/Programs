package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO legacy {@code /v1/getPreferences} endpoint.
 *
 * <p>Covers all three supported programs/tenants — RX, WHRI, and Sam's Club —
 * with test data organized under:
 * <ul>
 *   <li>{@code testdata/cpo/v3/1.getpreference/rx/}   — RX program (5 tests)</li>
 *   <li>{@code testdata/cpo/v3/1.getpreference/whri/}  — WHRI program (5 tests)</li>
 *   <li>{@code testdata/cpo/v3/1.getpreference/sams/}  — Sam's Club tenant (4 tests)</li>
 * </ul>
 *
 * <p>Each JSON file contains exactly one test-case block keyed by the test method name,
 * following the same convention as the rest of the CPO test suite.
 */
public class GetPreferenceApiTest extends CpoBaseApi {

    private static final String RX_PATH   = "testdata/cpo/v3/1.getpreference/rx/";
    private static final String WHRI_PATH = "testdata/cpo/v3/1.getpreference/whri/";
    private static final String SAMS_PATH = "testdata/cpo/v3/1.getpreference/sams/";

    // ── RX ────────────────────────────────────────────────────────────────────

    @Test(description = "Get RX preference with invalid channel - expects 400")
    public void getPreferenceInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get RX preference with invalid program - expects 400")
    public void getPreferenceInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get RX preference with invalid patient and customerId combination - expects 400")
    public void getPreferenceInvalidPatientCustomerIdCombination(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get RX preference with invalid tenant and buType header - expects 400")
    public void getPreferenceInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get RX preference with invalid customerId - expects 500")
    public void getPreferenceInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── WHRI ──────────────────────────────────────────────────────────────────

    @Test(description = "Get WHRI preference with invalid channel - expects 400")
    public void getPreferenceWhriInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get WHRI preference with invalid program - expects 400")
    public void getPreferenceWhriInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get WHRI preference with invalid patient and customerId combination - expects 400")
    public void getPreferenceWhriInvalidPatientCustomerIdCombination(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get WHRI preference with invalid tenant and buType header - expects 400")
    public void getPreferenceWhriInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get WHRI preference with invalid customerId - expects 500")
    public void getPreferenceWhriInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Sam's Club ────────────────────────────────────────────────────────────

    @Test(description = "Get Sams preference with invalid tenant and buType header - expects 400")
    public void getPreferenceSamsInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get Sams preference with invalid customerId - expects 500")
    public void getPreferenceSamsInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get Sams preference with invalid channel - expects 400")
    public void getPreferenceSamsInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get Sams preference with invalid program - expects 400")
    public void getPreferenceSamsInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
