package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the ProxyController endpoints.
 *
 * <p>The ProxyController forwards all requests to DM-PREFERENCE-SERVICE.
 * Endpoint route through {@code forwardRequest()} method.
 *
 * <p>Covered proxy endpoint:
 * <ul>
 *   <li>{@code /v1/postPreferences}               — POST</li>
 * </ul>
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/}.
 * Each JSON file contains exactly one test-case block keyed by the test method name.
 */

public class V1PostPreferencesProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/12.v1postpreferences/";

    @Test(description = "Proxy v1/postPreferences success OPT_OUT - expects 200 with V1 preferences saved ")
    public void proxyV1PostPreferencesSuccessOPTOUT(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences success OPT_IN - expects 200 with V1 preferences saved")
    public void proxyV1PostPreferencesSuccessOPTIN(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences success Multi Patient Single OPT_IN - expects 200 with V1 preferences saved")
    public void proxyV1PostPreferencesMultiPatientOptInSuccess(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences Invalid Consent Flow - expects 400")
    public void proxyV1PostPreferencesInvalidConsentFlow(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences Invalid Channel - expects 400")
    public void proxyV1PostPreferencesInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences Invalid Short Code Type - expects 400")
    public void proxyV1PostPreferencesInvalidShortCodeType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy v1/postPreferences Double OPT IN With DP Source - expects 400")
    public void proxyV1PostPreferencesDoubleOptInDPSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}