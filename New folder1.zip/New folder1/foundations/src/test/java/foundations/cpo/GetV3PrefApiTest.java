package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Sample API test demonstrating the foundations framework
 * Follows standard test pattern with JSON test data, Reporter logging, and POJO models
 */
public class GetV3PrefApiTest extends CpoBaseApi {

    String jsonPath = "testdata/cpo/v3/17.v3getprefs/";

    // communication flow: happy path scenarios
    @Test(description = "Fetch Preference(PHARMACY_PUSH) for Self without enrollment data")
    public void getCommPushPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch Preference setByCaregiver by given pair without enrollment data")
    public void getCommPrefSetByCaregiver(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-set-by-caregiver.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch Preference (PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS) for Self without enrollment data")
    public void getCommPushRefillPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-refill-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch Preference (PHARMACY_PUSH_REFILL_REMINDER) for Self without enrollment data")
    public void getCommPushRefillReminderPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-refill-reminder-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch Preference (PHARMACY_PUSH_APPOINTMENT_STATUS) for Self without enrollment data")
    public void getCommPushAppointmentPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-appt-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch Preference (PHARMACY_PUSH_CLINICAL_OUTREACH) for Self without enrollment data")
    public void getCommPushClinicalPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-clinical-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch all sms preferences for Self without enrollment data")
    public void getCommSmsPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-sms-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch PHARMACY_PUSH preference for self and dependents")
    public void getCommPharmacyPushPrefSelfDependents(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pharmacy-push-pref-self-dependents.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch PHARMACY_PUSH preference for self using SPID")
    public void getCommPharmacyPushPrefSelfSpId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pharmacy-push-pref-self-sp-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch all preferences for self and dependents and others with 10 pairs using CID and SPID both along with all contact points")
    public void getCommAllPref10Pairs(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-all-pref-10-pairs.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch PHARMACY_SMS preference for self using SPID along with contact points")
    public void getCommPharmacySmsPrefSelfSpId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pharmacy-sms-pref-self-spid.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch PHARMACY_SMS preference for self and dependents using SPID along with contact points")
    public void getCommPharmacySmsPrefSelfDependentsSpId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pharmacy-sms-pref-self-dependents-spid.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch PHARMACY_SMS preference for self and dependents using CID and SPID both along with all contact points")
    public void getCommPharmacySmsPrefSelfDependentsCIdSpId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pharmacy-sms-pref-self-dependents-cid-spid.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // communication flow: negative scenarios
    @Test(description = "Fetch all  preferences with 11 pair using CID and SPID both along with all contact points")
    public void getCommAllPref11Pairs(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-all-pref-11-pairs.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences with invalid preferenceGroupKey")
    public void getCommPrefInvalidPrefGroupKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-pref-group-key.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences with invalid preferenceKey")
    public void getCommPrefInvalidPrefKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-pref-key.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences with invalid IdType")
    public void getCommPrefInvalidIdType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-id-type.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without any pair")
    public void getCommPrefWithoutAnyPair(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-any-pair.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without primaryCustomerId")
    public void getCommPrefWithoutPrimaryCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-primary-customer-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without managedCustomerId")
    public void getCommPrefWithoutManagedCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-managed-customer-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without tenant header value")
    public void getCommPrefWithoutTenantHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-tenant-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without buType header value")
    public void getCommPrefWithoutBuTypeHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-bu-type-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without program header value")
    public void getCommPrefWithoutProgramHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-program-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences without source header value")
    public void getCommPrefWithoutSourceHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-source-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch preferences with invalid contact point value")
    public void getCommPrefWithInvalidContactPoint(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-with-invalid-contact-point.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // wallet flow: happy path scenarios
    @Test(description = "Wallet: Fetch wallet share permission for caregiver's own wallet. Response should have share permission given to dependent by the caregiver and usage decision set by caregiver for himself")
    public void getWalletSharePrefCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-share-pref-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch wallet usage decision for own wallet. Response should only have caregiver's usage decision for own wallet")
    public void getWalletUsagePrefCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-usage-pref-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch wallet share permission as well as usage decision for caregiver's own wallet. Response should have share permission given to dependent by the caregiver and usage decision set by caregiver for himself")
    public void getWalletShareUsagePrefCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-share-usage-pref-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch all wallet preferences by passing an empty preferenceKeys array, for caregiver's own wallet. Response should have share permission given to dependent by the caregiver and usage decision set by caregiver for himself")
    public void getWalletAllPrefCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-all-pref-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch all wallet preferences without passing preferenceKeys field, for caregiver's own wallet. Response should have share permission given to dependent by the caregiver and usage decision set by caregiver for himself")
    public void getWalletAllPrefNoPrefKeysCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-all-pref-no-pref-keys-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch all wallet preferences by passing preferenceKeys as null, for caregiver's own wallet. Response should have share permission given to dependent by the caregiver and usage decision set by caregiver for himself")
    public void getWalletAllPrefNullPrefKeysCaregiverOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-all-pref-null-pref-keys-caregiver-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch wallet share permission for dependent's wallet. Response should have only usage decision set by dependent for himself since the dependent does not have any dependents of his own")
    public void getWalletSharePrefDependentWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-share-pref-dependent-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch wallet usage decisions for dependent when caregiver has shared his wallet with the dependent. Response should have usage decision set by dependent for his own wallet as well as usage decision set by dependent for his caregiver's wallet")
    public void getWalletUsagePrefDependentCaregiverSharedWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-usage-pref-dependent-caregiver-shared-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch wallet usage decisions for dependent when caregiver has not shared his wallet with the dependent. Response should have usage decision set by dependent for his own wallet and empty preferences array for caregiver's wallet irrespective of the usage decision value since caregiver's wallet is not shared with him")
    public void getWalletUsagePrefDependentCaregiverNotSharedWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-usage-pref-dependent-caregiver-not-shared-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch all wallet preferences by passing empty array as preferenceKeys for dependent when caregiver has shared his wallet with the dependent. Response should have usage decision set by dependent for his own wallet as well as usage decision set by dependent for his caregiver's wallet and should not contain any share permission since the dependent does not have any dependents of his own")
    public void getWalletAllPrefDependentCaregiverSharedWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-all-pref-dependent-caregiver-shared-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch all wallet preferences by passing empty array as preferenceKeys for dependent when caregiver has not shared his wallet with the dependent. Response should have usage decision set by dependent for his own wallet and empty preferences array for caregiver's wallet irrespective of the usage decision value since caregiver's wallet is not shared with the dependent. Also, response should not contain any share permission since the dependent does not have any dependents of his own")
    public void getWalletAllPrefDependentCaregiverNotSharedWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-all-pref-dependent-caregiver-not-shared-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // wallet flow: negative scenarios
    @Test(description = "Wallet: Fetch wallet preferences when primaryCustomerId and managedCustomerId are not equal. Response should be a Bad Request error")
    public void getWalletPrefPrimaryManagedCIdNotEqual(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-primary-managed-cid-not-equal.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid preferenceKey. Response should be a Bad Request error")
    public void getWalletPrefInvalidPrefKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-invalid-pref-key.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid IdType. Response should be a Bad Request error")
    public void getWalletPrefInvalidIdType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-invalid-id-type.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences without any pair. Response should be a Bad Request error")
    public void getWalletPrefWithoutAnyPair(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-any-pair.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences without primaryCustomerId. Response should be a Bad Request error")
    public void getWalletPrefWithoutPrimaryCId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-primary-cid.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences without managedCustomerId. Response should be a Bad Request error")
    public void getWalletPrefWithoutManagedCId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-managed-cid.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid tenant header value. Response should be a Bad Request error")
    public void getWalletPrefWithInvalidTenantHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-with-invalid-tenant-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid buType header value. Response should be a Bad Request error")
    public void getWalletPrefWithInvalidBuTypeHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-with-invalid-bu-type-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid program header value. Response should be a Bad Request error")
    public void getWalletPrefWithInvalidProgramHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-with-invalid-program-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Wallet: Fetch preferences with invalid source header value. Response should be a Bad Request error")
    public void getWalletPrefWithInvalidSourceHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-with-invalid-source-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
