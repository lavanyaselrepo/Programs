package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;


public class ProxyGetEnrollmentStatusApiTest extends CpoBaseApi {

    String jsonPath = "testdata/cpo/proxy/getEnrollmentStatus/";

    // happy path scenarios
    @Test(description = "Proxy get enrollment status for sms (notif method 1) for Walmart")
    public void getEnrollmentStatus1Notif(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-1-notif.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status for voice (notif method 2) for Walmart")
    public void getEnrollmentStatus2Notif(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-2-notif.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status for sms and voice (notif methods 1 & 2) for Walmart")
    public void getEnrollmentStatus1And2Notif(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-1-and-2-notif.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status for sms (notif method 1) for Sams")
    public void getEnrollmentStatus1NotifSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-1-notif-sams.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // negative scenarios
    @Test(description = "Proxy get enrollment status without GLOBAL_TRACKING_ID header")
    public void getEnrollmentStatusNoGlobalTrackingId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-no-global-tracking-id.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status without store number")
    public void getEnrollmentStatusNoStoreNumber(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-no-store-number.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status without patient id")
    public void getEnrollmentStatusNoPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-no-patient-id.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status with invalid short code type")
    public void getEnrollmentStatusInvalidShortCodeType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-invalid-short-code-type.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status with invalid bu type")
    public void getEnrollmentStatusInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-invalid-bu-type.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Proxy get enrollment status with invalid notif method code")
    public void getEnrollmentStatusInvalidNotifMethodCode(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-enrollment-status-invalid-notif-method-code.json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
