package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy postPreferences endpoint.
 *
 * <p>Endpoint: {@code POST /postPreferences}
 *
 * <p>This is the direct preference service API for creating/updating patient notification
 * preferences. Unlike {@code /v1/postPreferences} (which uses consentSource/consentFlow/patientPrefInfo),
 * this endpoint uses the legacy contract with individual fields: requestId, language, userId,
 * storeNbr, patientId, timeStamp, zipCode, storePhone, and a preferences array.
 *
 * <p>Preferences array contains objects with: notification_type (1=SMS, 2=Voice, 3=Email),
 * notification_val, short_code_type_id (1=Walmart RX, 2=SAMs RX), enrollment_status_code
 * (26802=Enrolled, 26803=Unenrolled, 26805=Pending), and buType (1=Walmart, 18=SAMs).
 *
 * <p>No setup step needed — this IS the POST API itself.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/postpreferences/}.
 */
public class PostPreferencesProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/10.postpreferences/";

    @Test(description = "Post preferences - SMS OPT_IN for Walmart RX - expects 200 Success")
    public void proxyPostPreferencesSmsOptInWalmartRx(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences - Email OPT_IN for Walmart RX - expects 200 Success")
    public void proxyPostPreferencesEmailOptInWalmartRx(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences - SMS OPT_IN for SAMs RX - expects 200 Success")
    public void proxyPostPreferencesSmsOptInSamsRx(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences - Voice OPT_IN for Walmart RX - expects 200 Success")
    public void proxyPostPreferencesVoiceOptInWalmartRx(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences with missing mandatory field requestId - expects error")
    public void proxyPostPreferencesMissingRequestId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences with invalid notification_type (99) - expects error")
    public void proxyPostPreferencesInvalidNotificationType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Post preferences with invalid enrollment_status_code (99999) - expects error")
    public void proxyPostPreferencesInvalidEnrollmentStatusCode(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
