package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO legacy {@code /v1/updatePreference} endpoint.
 *
 * <p>Covers all three supported programs/tenants — RX, WHRI, and Sam's Club —
 * with test data organized under:
 * <ul>
 *   <li>{@code testdata/cpo/v3/2.updatepreference/rx/}   — RX program (8 tests)</li>
 *   <li>{@code testdata/cpo/v3/2.updatepreference/whri/}  — WHRI program (8 tests)</li>
 *   <li>{@code testdata/cpo/v3/2.updatepreference/sams/}  — Sam's Club tenant (8 tests)</li>
 * </ul>
 *
 * <p>Each JSON file contains exactly one test-case block keyed by the test method name,
 * following the same convention as the rest of the CPO test suite.
 */
public class UpdatePreferenceApiTest extends CpoBaseApi {

    private static final String RX_PATH   = "testdata/cpo/v3/2.updatepreference/rx/";
    private static final String WHRI_PATH = "testdata/cpo/v3/2.updatepreference/whri/";
    private static final String SAMS_PATH = "testdata/cpo/v3/2.updatepreference/sams/";

    // ── RX ────────────────────────────────────────────────────────────────────

    @Test(description = "Update RX preference with invalid channel - expects 400")
    public void updatePreferenceInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid program - expects 400")
    public void updatePreferenceInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid patientInfo (missing storeNbr) - expects 400")
    public void updatePreferenceInvalidPatientInfo(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid consent source - expects 400")
    public void updatePreferenceInvalidConsentSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid consent flow - expects 400")
    public void updatePreferenceInvalidConsentFlow(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid customerId - expects 500")
    public void updatePreferenceInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference with invalid tenant and buType header - expects 400")
    public void updatePreferenceInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update RX preference successfully - expects 200")
    public void updatePreferenceSuccessful(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(RX_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── WHRI ──────────────────────────────────────────────────────────────────

    @Test(description = "Update WHRI preference with invalid channel - expects 400")
    public void updatePreferenceWhriInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid program - expects 400")
    public void updatePreferenceWhriInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid patientInfo (missing storeNbr) - expects 400")
    public void updatePreferenceWhriInvalidPatientInfo(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid consent source - expects 400")
    public void updatePreferenceWhriInvalidConsentSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid consent flow - expects 400")
    public void updatePreferenceWhriInvalidConsentFlow(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid customerId - expects 500")
    public void updatePreferenceWhriInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference with invalid tenant and buType header - expects 400")
    public void updatePreferenceWhriInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update WHRI preference successfully - expects 200")
    public void updatePreferenceWhriSuccessful(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(WHRI_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Sam's Club ────────────────────────────────────────────────────────────

    @Test(description = "Update Sams preference with invalid channel - expects 400")
    public void updatePreferenceSamsInvalidChannel(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with invalid program - expects 400")
    public void updatePreferenceSamsInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with invalid consent source - expects 400")
    public void updatePreferenceSamsInvalidConsentSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with invalid customerId - expects 500")
    public void updatePreferenceSamsInvalidCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with invalid tenant and buType header - expects 400")
    public void updatePreferenceSamsInvalidTenantAndBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with invalid consent flow - expects 400")
    public void updatePreferenceSamsInvalidConsentFlow(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference with patient list size exceeding allowed limit - expects 400")
    public void updatePreferenceSamsInvalidPatientListSize(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Sams preference opt-in successfully - expects 200")
    public void updatePreferenceSamsOptInSuccessful(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(SAMS_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
