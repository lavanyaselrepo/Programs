package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Sample API test demonstrating the foundations framework
 * Follows standard test pattern with JSON test data, Reporter logging, and POJO models
 */
public class UpdateV3PrefApiTest extends CpoBaseApi {

    String jsonPath = "testdata/cpo/v3/18.v3updateprefs/";

    // communication flow: happy path scenarios
    @Test(description = "Update Preference PHARMACY_PUSH for self")
    public void updatePushPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-push-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS for self")
    public void updatePushPrescriptionPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-push-prescription-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference PHARMACY_PUSH_REFILL_REMINDER for self")
    public void updatePushRefillPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-push-refill-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference PHARMACY_PUSH_APPOINTMENT_STATUS for self")
    public void updatePushApptPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-push-appt-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference PHARMACY_PUSH_CLINICAL_OUTREACH for self")
    public void updatePushClinicalPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-push-clinical-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to enable PHARMACY_SMS for self")
    public void updateSmsPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-sms-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable PHARMACY_SMS_PRESCRIPTION_REFILL_STATUS for self")
    public void updateSmsPrescriptionPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-sms-prescription-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable PHARMACY_SMS_REFILL_REMINDER for self")
    public void updateSmsRefillPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-sms-refill-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable PHARMACY_SMS_APPOINTMENT_STATUS for self")
    public void updateSmsApptPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-sms-appt-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable PHARMACY_SMS_CLINICAL_OUTREACH for self")
    public void updateSmsClinicalPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-sms-clinical-pref-self.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable  push category toggle PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS for self and dependent")
    public void updatePrefDisablePushPrescriptionSelfDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-disable-push-prescription-self-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to disable sms category toggle PHARMACY_SMS_PRESCRIPTION_REFILL_STATUS for self and dependent")
    public void updatePrefDisableSmsPrescriptionSelfDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-disable-sms-prescription-self-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to enable push category toggle PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS for self and dependent")
    public void updatePrefEnablePushPrescriptionSelfDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-enable-push-prescription-self-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to enable sms category toggle PHARMACY_SMS_PRESCRIPTION_REFILL_STATUS for self and dependent")
    public void updatePrefEnableSmsPrescriptionSelfDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-enable-sms-prescription-self-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // communication flow: negative scenarios
    @Test(description = "Update Preference to enable sms category toggle PHARMACY_SMS_PRESCRIPTION_REFILL_STATUS when global toggle is disabled for self")
    public void updatePrefEnableSmsCategoryGlobalOff(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-enable-sms-category-global-off.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference to enable push category toggle PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS when global toggle is disabled for self")
    public void updatePrefEnablePushCategoryGlobalOff(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-enable-push-category-global-off.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without lastUpdateUserId value")
    public void updatePrefWithoutLastUpdateUserId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-last-update-user-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without primaryCustomerId value for a single pair of customerRecord")
    public void updatePrefWithoutPrimaryCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-primary-customer-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without any preference for a single pair of customerRecord")
    public void updatePrefWithoutPreference(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-preference.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without tenant value in header")
    public void updatePrefWithoutTenantHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-tenant-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without buType value in header")
    public void updatePrefWithoutBuTypeHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-bu-type-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without program value in header")
    public void updatePrefWithoutProgramHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-program-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Preference without source value in header")
    public void updatePrefWithoutSourceHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-pref-without-source-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // wallet flow: happy path scenarios
    @Test(description = "Update Wallet Preference | Caregiver revoking access from dependent for wallet share| Partial Success")
    public void updateWalletPrefCaregiverRevokeAccess(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-revoke-access.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | Caregiver giving access to dependent for wallet share | Partial Success")
    public void updateWalletPrefCaregiverGiveAccess(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-give-access.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | Dependent choosing to use it's caregiver wallet")
    public void updateWalletPrefDependentEnableUsage(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-dependent-enable-usage.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | Dependent choosing not to use it's caregiver wallet")
    public void updateWalletPrefDependentDisableUsage(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-dependent-disable-usage.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | User is not using it's own wallet")
    public void updateWalletPrefNotUsingOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-not-using-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | Caregiver giving access to dependent to share wallet")
    public void updateWalletPrefCaregiveShareDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-share-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | Caregiver revoking access from dependent to share wallet")
    public void updateWalletPrefCaregiveRevokeAccessDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-revoke-access-dependent.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference | User is using it's own wallet")
    public void updateWalletPrefUsingOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-using-own-wallet.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // wallet flow: negative scenarios
    @Test(description = "Update Wallet Preference without source value in header")
    public void updateWalletPrefWithoutSourceHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-source-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference without tenant value in header")
    public void updateWalletPrefWithoutTenantHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-tenant-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference without program value in header")
    public void updateWalletPrefWithoutProgramHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-program-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference without buType value in header")
    public void updateWalletPrefWithoutBuTypeHeader(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-bu-type-header.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference without preference value")
    public void updateWalletPrefWithoutPreference(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-preferences.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update Wallet Preference without primaryCustomerId value for a single pair of customerRecord")
    public void updateWalletPrefWithoutPrimaryCustomerId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-primary-customer-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "UpdateWallet Preference without lastUpdateUserId value")
    public void updateWalletPrefWithoutLastUpdateUserId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-without-last-update-user-id.json");
        cpoApiWrapper.testV3PreferencesApis(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
