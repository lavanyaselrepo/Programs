package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getPrefDataV3 endpoint.
 *
 * <p>Endpoint: {@code POST /getPrefDataV3}
 *
 * <p>V3 introduces {@code shortCodeTypes} (array), {@code notificationType} (integer array),
 * and a nested response structure with {@code patientPreferences[].prefDetails[]}.
 *
 * <p>Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getprefdatav3/}.
 */
public class GetPrefDataV3ProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/7.getprefdatav3/";

    // ── Success — Enrolled Patient ──────────────────────────────────────────

    @Test(description = "Get pref data V3 for enrolled patient - SMS, RX, Walmart (buType=1) - expects 200 SUCCESS")
    public void proxyGetPrefDataV3EnrolledSmsRxWalmart(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 for enrolled patient - SMS, RX, SAMs (buType=18) - expects 200 SUCCESS")
    public void proxyGetPrefDataV3EnrolledSmsRxSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Success — Not Enrolled Patient ──────────────────────────────────────

    @Test(description = "Get pref data V3 for not enrolled patient - empty prefDetails - expects 200 SUCCESS")
    public void proxyGetPrefDataV3NotEnrolledPatient(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Success — isPmsRequest Variants ───────────────────────────────────────

    @Test(description = "Get pref data V3 with isPmsRequest=false - no msgEnrollStatusVal/toolTipCode - expects 200 SUCCESS")
    public void proxyGetPrefDataV3IsPmsRequestFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // ── Success — isEmailRequired Variants ─────────────────────────────────────

    @Test(description = "Get pref data V3 with isEmailRequired=false - only SMS preference, no email - expects 200 SUCCESS")
    public void proxyGetPrefDataV3IsEmailRequiredFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 with invalid storeNbr (non-numeric) - expects error")
    public void proxyGetPrefDataV3InvalidStoreNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 with invalid patientId (non-numeric) - expects error")
    public void proxyGetPrefDataV3InvalidPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 with invalid buType (99) - expects error")
    public void proxyGetPrefDataV3InvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 with invalid shortCodeTypes ([INVALID]) - expects error")
    public void proxyGetPrefDataV3InvalidShortCodeTypes(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data V3 with invalid notificationType ([99]) - expects error")
    public void proxyGetPrefDataV3InvalidNotificationType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
