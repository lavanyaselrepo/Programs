package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getMultiPatientPrefs endpoint.
 *
 * <p>Endpoint: {@code POST /getMultiPatientPrefs}
 *
 * <p>This API retrieves enrolled patient notification preferences for multiple patients
 * in a single request. Only returns enrolled preferences and only for RX program (not CS).
 *
 * <p>Request takes {@code storeNbr}, {@code patientIds} (String array), and {@code buType}.
 * Response contains {@code prefs[]} with nested {@code preference} objects per patient.
 *
 * <p>Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getmultipatientprefs/}.
 */
public class GetMultiPatientPrefsProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/8.getmultipatientprefs/";


    @Test(description = "Get multi patient prefs for single enrolled patient - Walmart (buType=1) - expects 200 SUCCESS")
    public void proxyGetMultiPatientPrefsEnrolledWalmart(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs for single enrolled patient - SAMs (buType=18) - expects 200 SUCCESS")
    public void proxyGetMultiPatientPrefsEnrolledSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs for multiple patients - mix enrolled/not enrolled - expects 200 SUCCESS with prefs only for enrolled")
    public void proxyGetMultiPatientPrefsMixEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs for not enrolled patient - expects 200 SUCCESS with empty prefs")
    public void proxyGetMultiPatientPrefsNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs with invalid storeNbr (non-numeric) - expects error")
    public void proxyGetMultiPatientPrefsInvalidStoreNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs with invalid buType (99) - expects error")
    public void proxyGetMultiPatientPrefsInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs with empty patientIds array - expects error")
    public void proxyGetMultiPatientPrefsEmptyPatientIds(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient prefs with invalid patientId in array (non-numeric) - expects error")
    public void proxyGetMultiPatientPrefsInvalidPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
