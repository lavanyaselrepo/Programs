package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO {@code POST /v2/preferences/query} endpoint.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.getv2preference/}.
 * Each JSON file contains exactly one test-case block keyed by the test method name,
 * following the same convention as the rest of the CPO test suite.
 *
 * <p>Tests that require pre-existing preference state include a {@code setupPayload}
 * which is executed as a {@code PUT /v2/preferences} call before the main query,
 * mirroring the pattern used in {@link GetV3CommPrefApiTest}.
 */
public class GetV2PreferenceApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/5.getv2preference/";

    @Test(description = "Query preference where granteeId and principalId both have the same value - expects 200")
    public void getV2PreferenceSelfGrantee(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Query preference with only granteeId provided in request - expects 200")
    public void getV2PreferenceGranteeOnly(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Query preference where granteeId and principalId are different [Valid Dependent] - expects 200")
    public void getV2PreferenceValidDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Query preference where granteeId and principalId are different [Invalid Dependent] - expects 400")
    public void getV2PreferenceInvalidDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Invalid tenant passed in request - expects 400")
    public void getV2PreferenceInvalidTenant(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Invalid bu-type passed in request - expects 400")
    public void getV2PreferenceInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Invalid program passed in request - expects 400")
    public void getV2PreferenceInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Empty tenant passed in request - expects 400")
    public void getV2PreferenceEmptyTenant(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Empty bu-type passed in request - expects 400")
    public void getV2PreferenceEmptyBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Empty program passed in request - expects 400")
    public void getV2PreferenceEmptyProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
