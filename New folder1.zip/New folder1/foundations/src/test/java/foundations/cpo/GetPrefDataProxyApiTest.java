package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getPrefData endpoint.
 *
 * <p>Endpoint: {@code POST /getPrefData}
 *
 * <p>V1 of the getPrefData API. Internally calls the same method as V2.
 * Key differences from V2: no {@code shortCodeType} in request,
 * response contains {@code centralPatientId} instead of {@code commId}.
 *
 * <p>Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getprefdata/}.
 */
public class GetPrefDataProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/5.getprefdata/";

    @Test(description = "Get pref data for enrolled patient - Walmart (buType=1), isPmsRequest=true, isEmailRequired=true - expects 200 SUCCESS")
    public void proxyGetPrefDataEnrolledSmsWalmart(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data for enrolled patient - SAMs (buType=18), isPmsRequest=true, isEmailRequired=true - expects 200 SUCCESS")
    public void proxyGetPrefDataEnrolledSmsSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data for not enrolled patient - expects 200 SUCCESS with empty patientPreferences")
    public void proxyGetPrefDataNotEnrolledPatient(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data with isPmsRequest=false and isEmailRequired=false - only SMS, no PMS fields - expects 200 SUCCESS")
    public void proxyGetPrefDataNoPmsNoEmail(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data with invalid storeNbr (non-numeric) - expects error")
    public void proxyGetPrefDataInvalidStoreNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data with invalid patientId (non-numeric) - expects error")
    public void proxyGetPrefDataInvalidPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get pref data with invalid buType (99) - expects error")
    public void proxyGetPrefDataInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
