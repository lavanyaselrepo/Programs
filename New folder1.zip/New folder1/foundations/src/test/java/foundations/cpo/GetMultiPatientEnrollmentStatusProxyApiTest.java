package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the Proxy getMultiPatientEnrollmentStatus endpoint.
 *
 * <p>Endpoint: {@code POST /getMultiPatientEnrollmentStatus}
 *
 * <p>This API checks enrollment status for multiple patients and returns only the
 * enrolled patient IDs. Unlike {@code /getMultiPatientPrefs}, it does not return
 * preference details — just a lightweight list of enrolled patient IDs.
 *
 * <p>Request takes {@code storeNbr}, {@code patientIds} (String array), and {@code buType}.
 * Response contains {@code enrolledPatientIds} (String array), {@code statusCode}, and {@code statusTxt}.
 *
 * <p>Success scenarios use a setup step via {@code POST /v1/postPreferences} to seed
 * enrollment state before querying.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/5.proxy/getmultipatientenrollmentstatus/}.
 */
public class GetMultiPatientEnrollmentStatusProxyApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/9.getmultipatientenrollmentstatus/";

    @Test(description = "Get multi patient enrollment status for single enrolled patient - Walmart (buType=1) - expects 200 SUCCESS")
    public void proxyGetMultiPatientEnrollmentStatusEnrolledWalmart(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status for single enrolled patient - SAMs (buType=18) - expects 200 SUCCESS")
    public void proxyGetMultiPatientEnrollmentStatusEnrolledSams(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status for multiple patients - mix enrolled/not enrolled - expects 200 SUCCESS with only enrolled patientIds")
    public void proxyGetMultiPatientEnrollmentStatusMixEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status for not enrolled patient - expects 200 SUCCESS with empty enrolledPatientIds")
    public void proxyGetMultiPatientEnrollmentStatusNotEnrolled(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status with invalid storeNbr (non-numeric) - expects error")
    public void proxyGetMultiPatientEnrollmentStatusInvalidStoreNbr(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status with invalid buType (99) - expects error")
    public void proxyGetMultiPatientEnrollmentStatusInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status with empty patientIds array - expects error")
    public void proxyGetMultiPatientEnrollmentStatusEmptyPatientIds(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get multi patient enrollment status with invalid patientId in array (non-numeric) - expects error")
    public void proxyGetMultiPatientEnrollmentStatusInvalidPatientId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testCommPreferenceApi(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
