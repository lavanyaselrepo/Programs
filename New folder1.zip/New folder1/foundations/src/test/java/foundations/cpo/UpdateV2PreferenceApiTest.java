package foundations.cpo;

import foundations.base.CpoBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Integration tests for the CPO {@code PUT /v2/preferences} endpoint.
 *
 * <p>All test data lives under {@code testdata/cpo/v3/6.updatev2preference/}.
 * Each JSON file contains exactly one test-case block keyed by the test method name,
 * following the same convention as the rest of the CPO test suite.
 *
 * <p>Both setup and main calls are dispatched through
 * {@link foundations.api.CpoApiWrapper#testV2Preferences}, which routes to PUT or POST
 * based on the {@code httpMethod} field in the test-data JSON.
 */
public class UpdateV2PreferenceApiTest extends CpoBaseApi {

    private static final String JSON_PATH = "testdata/cpo/v3/6.updatev2preference/";

    @Test(description = "Update preference when principalId not received but preferences list is present in principalInfo - expects 200")
    public void updateV2PreferenceMissingPrincipalId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when source is not present in request - expects 400")
    public void updateV2PreferenceMissingSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when invalid source value is present in request - expects 400")
    public void updateV2PreferenceInvalidSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when lastUpdateUser is not present in request - expects 400")
    public void updateV2PreferenceMissingLastUpdateUser(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when granteeId is not present in request - expects 400")
    public void updateV2PreferenceMissingGranteeId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when principalInfo is not received in request - expects 400")
    public void updateV2PreferenceMissingPrincipalInfo(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when granteeId and principalId both have the same value - expects 200")
    public void updateV2PreferenceSelfGrantee(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when granteeId and principalId are different [Valid Dependent] - expects 200")
    public void updateV2PreferenceValidDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when granteeId and principalId are different [Invalid Dependent] - expects 400")
    public void updateV2PreferenceInvalidDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when granteeId and principalId are both provided in request - expects 200")
    public void updateV2PreferenceGranteeAndPrincipalId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when invalid tenant is passed in request - expects 400")
    public void updateV2PreferenceInvalidTenant(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when invalid bu-type is passed in request - expects 400")
    public void updateV2PreferenceInvalidBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when invalid program is passed in request - expects 400")
    public void updateV2PreferenceInvalidProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when tenant header is not received in request - expects 400")
    public void updateV2PreferenceMissingTenant(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when bu-type header is not received in request - expects 400")
    public void updateV2PreferenceMissingBuType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when program header is not received in request - expects 400")
    public void updateV2PreferenceMissingProgram(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when PHARMACY_SMS_TOGGLE is set to true - not allowed, expects 400")
    public void updateV2PreferenceSmsToggleMadeTrue(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update preference when PHARMACY_SMS_TOGGLE is set to false - expects 200")
    public void updateV2PreferenceSmsToggleMadeFalse(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(JSON_PATH + testName + ".json");
        cpoApiWrapper.testV2Preferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
