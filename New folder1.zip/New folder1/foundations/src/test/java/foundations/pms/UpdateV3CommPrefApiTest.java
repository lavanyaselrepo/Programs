package foundations.pms;

import foundations.base.PmsBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

import static foundations.utils.CommonUtils.getCurrentTimestamp;

public class UpdateV3CommPrefApiTest extends PmsBaseApi {
    String jsonPath = "testdata/pms/v3/updatecommprefs/";

    @Test(description = "Toggle the appointment status push notification preference")
    public void updateCommPrefSubPushAppointmentStatusToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-push-appointment-status-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        //System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the clinical outreach push notification preference")
    public void updateCommPrefSubPushClinicalOutreachToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-push-clinical-outreach-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        //System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the refill reminder push notification preference")
    public void updateCommPrefSubPushRefillReminderToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-push-refill-reminder-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        //System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the refill status push notification preference")
    public void updateCommPrefSubPushRefillStatusToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-push-refill-status-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the general push notification preference")
    public void updateCommPrefGPushToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-g-push-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the research opportunities SMS notification preference")
    public void updateCommPrefSubSmsResearchOpportunitiesToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-sms-research-opportunities-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the clinical outreach SMS notification preference")
    public void updateCommPrefSubSmsClinicalOutreachToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-sms-clinical-outreach-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the appointment status SMS notification preference")
    public void updateCommPrefSubSmsAppointmentStatusToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-sms-appointment-status-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the refill reminder SMS notification preference")
    public void updateCommPrefSubSmsRefillReminderToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-sms-refill-reminder-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the refill status SMS notification preference")
    public void updateCommPrefSubSmsRefillStatusToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-sub-sms-refill-status-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Toggle the general SMS notification preference")
    public void updateCommPrefGSmsToggle(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-g-sms-toggle.json");
        // Dynamically update requestTs to current UTC timestamp
        testInputDetails.getJSONObject(testName)
                .getJSONObject("requestPayload")
                .put("requestTs", getCurrentTimestamp());
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Test with old timestamp in communication preference update")
    public void updateCommPrefOldTimestamp(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-old-timestamp.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Test missing source in request headers for communication preference update")
    public void updateCommPrefMissingSourceFromHeaders(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-missing-source.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Test missing lastUpdatedUserId in communication preference update")
    public void updateCommPrefMissingLastUpdatedUserId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-missing-lastUpdatedUserId.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Test missing globalTrackingId in request headers for communication preference update")
    public void updateCommPrefMissingGlobalTrackingIdInHeaders(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-comm-pref-missing-global-tracking-id.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }


}
