package foundations.pms;

import foundations.base.PmsBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;


public class GetV3WalletPrefApiTest extends PmsBaseApi {

    String jsonPath = "testdata/pms/v3/getwalletprefs/";

    // happy path scenarios
    @Test(description = "Get wallet preferences for own wallet")
    public void getWalletPrefOwnWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-own-wallet.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for own wallet for minor dependent")
    public void getWalletPrefOwnWalletMinorDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-own-wallet-minor-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for own wallet for self and minor dependent")
    public void getWalletPrefOwnWalletSelfAndMinorDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-own-wallet-self-minor-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for own wallet for adult dependent")
    public void getWalletPrefOwnWalletAdultDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-own-wallet-adult-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for own wallet for self and adult dependent")
    public void getWalletPrefOwnWalletSelfAndAdultDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-own-wallet-self-adult-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for caregiver's wallet shared with self")
    public void getWalletPrefCaregiverWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-caregiver-wallet.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for caregiver's wallet when caregiver has stopped sharing their wallet. Response should have empty preferences array")
    public void getWalletPrefCaregiverWalletNotShared(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-caregiver-wallet-not-shared.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for self and all dependents by using preference keys")
    public void getWalletPrefSelfAndAllDependentsPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-self-all-dependents-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for self and all dependents without using preference keys")
    public void getWalletPrefSelfAndAllDependents(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-self-all-dependents.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for self and all dependents by using null preference keys")
    public void getWalletPrefSelfAndAllDependentsNullPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-self-all-dependents-null-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences for self and all dependents by using empty preference keys array")
    public void getWalletPrefSelfAndAllDependentsEmptyPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-self-all-dependents-empty-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch wallet share preference for own wallet for self. Response should give wallet usage decision set by self for own wallet")
    public void getWalletSharePrefOwnWalletSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-share-pref-own-wallet-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Fetch wallet usage decision for own wallet for self")
    public void getWalletUsagePrefOwnWalletSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-usage-pref-own-wallet-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet share preferences self and all dependents. All share and usage preferences are returned in response")
    public void getWalletSharePrefSelfAllDependents(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-share-pref-self-all-dependents.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // negative scenarios
    @Test(description = "Get wallet preferences with invalid preference group key")
    public void getWalletPrefInvalidPrefGroupKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-invalid-pref-group-key.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }


    @Test(description = "Get wallet preferences with invalid id type")
    public void getWalletPrefInvalidIdType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-invalid-id-type.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences with empty grantee principal info array")
    public void getWalletPrefEmptyGranteePrincipalArray(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-empty-grantee-principal-array.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences without GlobalTrackingId header")
    public void getWalletPrefWithoutGlobalTrackingId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-global-tracking-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences without source header")
    public void getWalletPrefWithoutSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-source.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences with invalid source header")
    public void getWalletPrefWithInvalidSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-with-invalid-source.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences without grantee id")
    public void getWalletPrefWithoutGranteeId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-grantee-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get wallet preferences without principal id")
    public void getWalletPrefWithoutPrincipalId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-wallet-pref-without-principal-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
