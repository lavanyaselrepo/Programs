package foundations.pms;

import foundations.base.PmsBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

import static foundations.utils.CommonUtils.getCurrentTimestamp;

public class UpdateWalletPrefApiTest extends PmsBaseApi {
    String jsonPath = "testdata/pms/v3/updatewalletprefs/";

    @Test(description = "Update wallet preferences for self")
    public void updateWalletPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-self.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update wallet preferences for self with an older timestamp")
    public void updateWalletPrefOlderTimestamp(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-self-with-older-timestamp.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update wallet preferences with invalid lobId")
    public void updateWalletPrefInvalidLobId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-invalid-lobId.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Caregiver gives wallet usage permission to minor")
    public void updateWalletPrefWalletUsagePermissionToMinor(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-giving-wallet-usage-permission-to-minor.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Minor uses caregiver's wallet")
    public void updateWalletPreMinorUsingCaregiverWallet(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-minor-using-caregiver-wallet.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Caregiver gives wallet share permission to minor")
    public void updateWalletPrefWalletSharePermissionToMinor(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-caregiver-giving-wallet-share-permission-to-minor.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update wallet preferences with invalid grantee type")
    public void updateWalletPrefInvalidGranteeType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-invalid-grantee-type.json");
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Update wallet preferences with invalid grantee type")
    public void updateWalletPrefMissingRequestorId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "update-wallet-pref-missing-requestorId.json");
        System.out.println("testInputDetails: " + testInputDetails.toString());
        pmsApiWrapper.testV3UpdatePreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
