package foundations.pms;

import foundations.base.PmsBaseApi;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * Sample API test demonstrating the foundations framework
 * Follows standard test pattern with JSON test data, Reporter logging, and POJO models
 */
public class GetV3CommPrefApiTest extends PmsBaseApi {

    String jsonPath = "testdata/pms/v3/getcommprefs/";

    // happy path scenarios
    @Test(description = "Get sms communication preferences for self by using preference keys")
    public void getCommSmsPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-sms-pref-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get push communication preferences for self by using preference keys")
    public void getCommPushPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-pref-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get all communication preferences for self without using preference keys")
    public void getCommPrefSelfWithoutPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-self-without-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get sms communication preferences for dependent by using preference keys")
    public void getCommSmsPrefDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-sms-pref-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get push communication preferences for dependent by using preference keys")
    public void getCommPushPrefDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-pref-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get all communication preferences for dependent without using preference keys")
    public void getCommPrefDependentWithoutPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-dependent-without-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get all communication preferences for dependent without using preference keys")
    public void getCommPrefSelfAndDependentWithoutPrefKeys(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-self-and-dependent-without-pref-keys.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get communication push appointment preference for dependent")
    public void getCommPushAppointmentPrefDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-appt-pref-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get communication refill status sms preference for dependent")
    public void getCommSmsRefillStatusPrefDependent(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-sms-refill-status-pref-dependent.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get communication push refill reminder preference for self")
    public void getCommPushRefillRemPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-push-refill-rem-pref-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get communication clinical sms preference for self")
    public void getCommSmsClinicalPrefSelf(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-sms-clinical-pref-self.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    // negative scenarios
    @Test(description = "Get preferences with invalid preference group key")
    public void getPrefInvalidPrefGroupKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-pref-group-key.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences with preference key")
    public void getPrefInvalidPrefKey(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-pref-key.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences with invalid id type")
    public void getPrefInvalidIdType(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-invalid-id-type.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences with empty grantee principal info array")
    public void getPrefEmptyGranteePrincipalArray(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-empty-grantee-principal-array.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences without GlobalTrackingId header")
    public void getCommPrefWithoutGlobalTrackingId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-global-tracking-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences without source header")
    public void getCommPrefWithoutSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-source.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences with invalid source header")
    public void getCommPrefWithInvalidSource(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-with-invalid-source.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences without grantee id")
    public void getCommPrefWithoutGranteeId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-grantee-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }

    @Test(description = "Get preferences without principal id")
    public void getCommPrefWithoutPrincipalId(Method method) {
        String testName = method.getName();
        JSONObject testInputDetails = parseJsonFileFromResources(jsonPath + "get-comm-pref-without-principal-id.json");
        pmsApiWrapper.testV3GetPreferences(testInputDetails.getJSONObject(testName), getCommonHeaders(), testName);
    }
}
