package foundations.constants;

public class GeneralConstants {

    public static String REQUEST_PAYLOAD = "requestPayload";
    public static String SETUP_PAYLOAD = "setupPayload";
    public static String REQUEST_HEADERS = "requestHeaders";
    public static String REQUEST_TRACKING_ID = "requestTrackingId";
    public static String ENS_NOTIFICATION_ID = "ensNotificationId";
    public static String RESPONSE_BODY = "responseBody";
    public static String RESPONSE_STATUS_CODE = "responseStatusCode";
    public static String EXCLUDE_VALUE_VALIDATION = "excludeValueValidation";

    public static String GLOBAL_TRACKING_ID = "global_tracking_id";
    public static String V3_GET_PREFERENCES_ENDPOINT = "v3GetPreferences";
    public static String V3_SAVE_PREFERENCES_ENDPOINT = "v3SavePreferences";
    public static String REQUEST_TS = "requestTs";
    public static String LAST_UPDATE_TS = "lastUpdateTs";
    public static String LAST_CHANGE_TS = "lastChangeTs";
    public static String EFFECTIVE_TS = "effectiveTs";

    public static String CPO_V3_GET_PREFERENCES_ENDPOINT = "cpo.v3GetPreferences";
    public static String CPO_V3_SAVE_PREFERENCES_ENDPOINT = "cpo.v3SavePreferences";

    public static String ENDPOINT          = "endpoint";
    public static String SETUP_ENDPOINT = "setupEndpoint";
    public static String SETUP_HTTP_METHOD = "setupHttpMethod";
    public static String HTTP_METHOD       = "httpMethod";
    public static String MODIFIER_DATA_MAP = "modifierDataMap";
    public static String ACTIVITIES        = "activities";
    public static String SEARCH_DOC        = "searchDoc";
}
