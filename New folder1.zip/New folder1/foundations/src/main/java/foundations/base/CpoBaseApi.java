package foundations.base;

import foundations.api.CpoApiWrapper;
import foundations.validators.CpoResponseValidator;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

/**
 * Service-specific base class for all CPO (Communication Preference Orchestrator) API tests.
 *
 * Extends {@link BaseApi} and owns everything that is CPO-specific:
 *   - CPO base URI
 *   - CPO RestAssured request / response specifications
 *   - {@link CpoApiWrapper} wired with its own {@link CpoResponseValidator}
 *
 * Usage: all CPO test classes should extend this class instead of {@link BaseApi} directly.
 */
public abstract class CpoBaseApi extends BaseApi {

    protected String                cpoBaseUri;
    protected RequestSpecification  cpoRequestSpec;
    protected ResponseSpecification cpoResponseSpec;
    protected CpoResponseValidator  cpoResponseValidator = new CpoResponseValidator();
    protected CpoApiWrapper         cpoApiWrapper;

    /**
     * Extends root environment bootstrap to also resolve the CPO base URI.
     * Called once per test class before any test methods run.
     */
    @BeforeClass
    @Parameters({"environment"})
    @Override
    public void setupEnvironment(String env) {
        super.setupEnvironment(env);
        cpoBaseUri = propertyReader.getCpoBaseUri();
        System.out.println("CPO Base URI       : " + cpoBaseUri);
    }

    /**
     * Rebuilds the CPO RestAssured specs and re-wires the wrapper before every test method.
     * Ensures a clean, isolated spec for each test execution.
     */
    @BeforeMethod
    public void setupTest() {
        configureCpoSpecs();
        initializeCpoWrapper();
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private void configureCpoSpecs() {
        cpoRequestSpec = new RequestSpecBuilder()
                .setBaseUri(cpoBaseUri)
                .setContentType("application/json")
                .addHeader("Accept", "application/json")
                .build();
        cpoResponseSpec = new ResponseSpecBuilder().build();
    }

    private void initializeCpoWrapper() {
        cpoApiWrapper = new CpoApiWrapper(cpoRequestSpec, cpoResponseValidator);
    }
}
