package foundations.base;

import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.config.FoundationsPropertyReader;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Root base class shared by ALL service API tests.
 *
 * Responsibilities (intentionally minimal):
 *   - Environment bootstrap (env name, PropertyReader, system property)
 *   - Common header helpers
 *   - JSON test-data loading utility
 *
 * Service-specific concerns (specs, wrappers, validators) live in the
 * dedicated subclasses: {@link PmsBaseApi} and {@link CpoBaseApi}.
 */
public abstract class BaseApi {

    protected FoundationsPropertyReader propertyReader;
    protected String environment;

    /**
     * Bootstraps the environment once per test class.
     * Subclasses that need additional @BeforeClass work should call
     * {@code super.setupEnvironment(env)} first.
     *
     * @param env Environment from TestNG XML (stg | dev | qe)
     */
    @BeforeClass
    @Parameters({"environment"})
    public void setupEnvironment(String env) {
        this.environment = env != null ? env : "stg";
        System.setProperty("environment", this.environment);

        propertyReader = FoundationsPropertyReader.getInstance();

        System.out.println("Test Environment   : " + environment);
        System.out.println("Dragon Library Env : " + propertyReader.getDragonPropertyReader().getEnvironment());
    }

    // ── Header helpers ────────────────────────────────────────────────────────

    /** Returns base Content-Type / Accept headers shared by all services. */
    protected Map<String, String> getCommonHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Accept", "application/json");
        return headers;
    }

    /**
     * Returns authenticated headers. Override in a concrete test class to
     * inject service-specific auth tokens.
     */
    protected Map<String, String> getAuthHeaders() {
        return getCommonHeaders();
    }

    // ── Config accessor ───────────────────────────────────────────────────────

    protected FoundationsPropertyReader getPropertyReader() {
        return propertyReader;
    }

    // ── Test-data utility ─────────────────────────────────────────────────────

    protected JSONObject parseJsonFileFromResources(String resourcePath) {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) throw new FileNotFoundException(resourcePath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            return new JSONObject(sb.toString());
        } catch (Exception e) {
            Reporter.log(String.format("Error parsing JSON file %s : %s", resourcePath, e.getMessage()));
            return null;
        }
    }
}
