package foundations.base;

import foundations.api.PmsApiWrapper;
import foundations.validators.PmsResponseValidator;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

/**
 * Service-specific base class for all PMS (Preference Management Service) API tests.
 *
 * Extends {@link BaseApi} and owns everything that is PMS-specific:
 *   - PMS base URI
 *   - PMS RestAssured request / response specifications
 *   - {@link PmsApiWrapper} wired with its own {@link PmsResponseValidator}
 *
 * Usage: all PMS test classes should extend this class instead of {@link BaseApi} directly.
 */
public abstract class PmsBaseApi extends BaseApi {

    protected String                pmsBaseUri;
    protected RequestSpecification  pmsRequestSpec;
    protected ResponseSpecification pmsResponseSpec;
    protected PmsResponseValidator  pmsResponseValidator = new PmsResponseValidator();
    protected PmsApiWrapper         pmsApiWrapper;

    /**
     * Extends root environment bootstrap to also resolve the PMS base URI.
     * Called once per test class before any test methods run.
     */
    @BeforeClass
    @Parameters({"environment"})
    @Override
    public void setupEnvironment(String env) {
        super.setupEnvironment(env);
        pmsBaseUri = propertyReader.getPmsBaseUri();
        System.out.println("PMS Base URI       : " + pmsBaseUri);
    }

    /**
     * Rebuilds the PMS RestAssured specs and re-wires the wrapper before every test method.
     * Ensures a clean, isolated spec for each test execution.
     */
    @BeforeMethod
    public void setupTest() {
        configurePmsSpecs();
        initializePmsWrapper();
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private void configurePmsSpecs() {
        pmsRequestSpec = new RequestSpecBuilder()
                .setBaseUri(pmsBaseUri)
                .setContentType("application/json")
                .addHeader("Accept", "application/json")
                .build();
        pmsResponseSpec = new ResponseSpecBuilder().build();
    }

    private void initializePmsWrapper() {
        pmsApiWrapper = new PmsApiWrapper(pmsRequestSpec, pmsResponseValidator);
    }
}
