package foundations.enums;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public enum PreferenceGroupKey {
  PREFERENCES_COMMUNICATION,
  PREFERENCES_WALLET
}
