package foundations.enums;

import lombok.Getter;

@Getter
public enum CommunicationPreferenceKey {
  PHARMACY_SMS("g_sms_toggle"),
  PHARMACY_SMS_PRESCRIPTION_REFILL_STATUS("sub_sms_refill_status_toggle"),
  PHARMACY_SMS_REFILL_REMINDER("sub_sms_refill_reminder_toggle"),
  PHARMACY_SMS_APPOINTMENT_STATUS("sub_sms_appointment_status_toggle"),
  PHARMACY_SMS_CLINICAL_OUTREACH("sub_sms_clinical_outreach_toggle"),
  PHARMACY_SMS_RESEARCH_OPPORTUNITIES("sub_sms_research_opportunities_toggle"),
  PHARMACY_PUSH("g_push_toggle"),
  PHARMACY_PUSH_PRESCRIPTION_REFILL_STATUS("sub_push_refill_status_toggle"),
  PHARMACY_PUSH_REFILL_REMINDER("sub_push_refill_reminder_toggle"),
  PHARMACY_PUSH_APPOINTMENT_STATUS("sub_push_appointment_status_toggle"),
  PHARMACY_PUSH_CLINICAL_OUTREACH("sub_push_clinical_outreach_toggle");
  final String label;

  CommunicationPreferenceKey(String label) {
    this.label = label;
  }

  public static CommunicationPreferenceKey fromLabel(String label) {
    for (CommunicationPreferenceKey key : values()) {
      if (key.getLabel().equals(label)) {
        return key;
      }
    }
    return null;
  }
}
