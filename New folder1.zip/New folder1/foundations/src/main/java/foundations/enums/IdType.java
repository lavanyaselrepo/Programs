package foundations.enums;

public enum IdType {
  CUSTOMER_ID
}
