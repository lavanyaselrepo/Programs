package foundations.enums;

public enum SmsEnrollmentStatus {
  ENROLLED,
  UNENROLLED,
  UNKNOWN
}
