package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CpoGetV3PreferenceRequest {
    private String requestorId;
    private List<String> preferenceGroupKeys;
    private List<String> preferenceKeys;
    private LinkedHashSet<CpoReqCpoCustomerRecord> customerRecords = new LinkedHashSet<>();
    private LinkedHashSet<String> contactPoints = new LinkedHashSet<>();

    // transient fields
    @Hidden
    private transient Map<String, String> requestHeaders;
    @Hidden private transient Map<String, String> queryParams;
}
