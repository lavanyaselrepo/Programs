package foundations.models.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import foundations.models.common.GranteeInfo;
import foundations.models.common.PreferenceData;
import foundations.models.common.PrincipalInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Response model for v3 get preferences api. */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GranteePrincipalInfoResponse {
  private GranteeInfo granteeInfo;
  private PrincipalInfo principalInfo;
  private List<PreferenceData> preferences;
  private Status error;
}
