package foundations.models.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import foundations.enums.IdType;
import foundations.enums.PreferenceGroupKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PmsV3SavePreferencesRequest {
    private String requestTs;
    private String etag;
    private String lastUpdateUserId;
    private String schemaVersion;
    private String buId;
    private String lobId;
    private transient List<GranteePrincipalInfoRequest> granteePrincipalInfo;

    @Builder.Default
    private List<String> preferenceGroupKeys =
            List.of(PreferenceGroupKey.PREFERENCES_COMMUNICATION.name());

    @Builder.Default private String granteeIdType = IdType.CUSTOMER_ID.toString();
    @Builder.Default private String principalIdType = IdType.CUSTOMER_ID.toString();
}
