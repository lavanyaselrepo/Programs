package foundations.models.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import foundations.enums.IdType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GranteeInfo {
  private String type;
  private String granteeId;
  private Integer storeNbr;
  private Integer patientId;

  @Builder.Default private String granteeIdType = IdType.CUSTOMER_ID.toString();
}
