package foundations.models.cpo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Builder
@Data
@EqualsAndHashCode(of = {"channelType"})
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpoContactPoint {
    private String channelType;
    private String notificationValue;
    private Boolean isEnrolled;
    private String recipientRole;
    private CpoContactPointsMetadata metadata;
}
