package foundations.models.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import foundations.enums.CommunicationPreferenceKey;
import foundations.enums.PreferenceGroupKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

/** Request model for v3 get preferences api. */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PmsV3GetPreferencesRequest {

    private String schemaVersion;
    private String buId;
    private String lobId;
    private String requestorId;
    private transient List<GranteePrincipalInfoRequest> granteePrincipalInfo;

    @Builder.Default
    private List<String> preferenceGroupKeys =
            List.of(PreferenceGroupKey.PREFERENCES_COMMUNICATION.name());

    @Builder.Default
    private List<String> preferenceKeys =
            Arrays.stream(CommunicationPreferenceKey.values()).map(Enum::name).toList();
}

