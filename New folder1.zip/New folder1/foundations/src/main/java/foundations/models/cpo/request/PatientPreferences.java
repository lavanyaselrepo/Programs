package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
public class PatientPreferences {

  @NotNull(message = "storeNbr can not be null")
  private Integer storeNbr;

  @NotNull(message = "patientId can not be null")
  private Integer patientId;

  private String customerId;

  @Valid
  @NotNull(message = "preferences can not be null")
  @Size(min = 1, message = "preferences can not be empty")
  private List<PreferenceV1> preferences;

  private List<PreferenceV1> oldPreferences;
  private String language;
  private String firstName;
}
