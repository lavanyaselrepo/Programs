package foundations.models.cpo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CpoUpdateV3PreferenceResponse {
    private CpoStatus cpoStatus;
    private List<CpoResCustomerUpdatePreference> data;
    private Error error;
}