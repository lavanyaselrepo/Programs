package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
public class UserInfo {
  @NotBlank(message = "userId cannot be empty")
  private String userId;

  private String userStoreNumber;
}
