package foundations.models.cpo.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CpoUpdatePreferenceRequestPreferences {
    private String preferenceLabel;
    private String preferenceValue;
}

