package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CpoUpdateV3PreferenceRequest {
    private String lastUpdateUserId;
    private List<String> preferenceGroupKeys;
    private Set<CpoReqCustomerUpdatePreference> customerRecords;

    @Hidden
    private transient Map<String, String> requestHeaders;
    @Hidden private transient Map<String, String> queryParams;
}
