package foundations.models.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Sample response POJO
 * Demonstrates response structure for API responses
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PmsV3GetPreferencesResponse {

    private String requestTs;
    private String etag;
    private String source;
    private String schemaVersion;
    private String buId;
    private String lobId;
    private List<GranteePrincipalInfoResponse> granteePrincipalInfo;
}
