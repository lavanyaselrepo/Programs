package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PreferenceV1 {
  @NotBlank(message = "channel can not be empty")
  private String channel;

  private String prefValue;

  @NotBlank(message = "shortCodeType can not be empty")
  private String shortCodeType;

  private String commId;

  private String changeType;
}
