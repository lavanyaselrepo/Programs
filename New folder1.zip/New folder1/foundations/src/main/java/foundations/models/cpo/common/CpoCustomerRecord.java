package foundations.models.cpo.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpoCustomerRecord {
    private String primaryCustomerId;
    private String managedCustomerId;
    private String primaryCustomerIdType;
    private String managedCustomerIdType;
    private String primaryType;
    private String managedType;
}