package foundations.models.cpo.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class V1PostPreferencesResponse {
  private String requestTrackingId;
  private String statusCode;
  private String statusTxt;
}
