package foundations.models.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import foundations.enums.IdType;
import foundations.enums.SmsEnrollmentStatus;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PrincipalInfo {
  private String type;
  private String principalId;
  private Integer storeNbr;
  private Integer patientId;

  @Builder.Default private String principalIdType = IdType.CUSTOMER_ID.toString();
  @Builder.Default private SmsEnrollmentStatus smsEnrollmentStatus = SmsEnrollmentStatus.UNKNOWN;
}
