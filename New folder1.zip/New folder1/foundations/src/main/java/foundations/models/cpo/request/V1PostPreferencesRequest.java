package foundations.models.cpo.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
public class V1PostPreferencesRequest {

  @NotBlank(message = "consentSource can not be empty")
  private String consentSource;

  @NotBlank(message = "consentFlow can not be empty")
  private String consentFlow;

  @NotNull(message = "isConsentRequired can not be null")
  private Boolean isConsentRequired;

  @Valid
  @NotNull(message = "patientPrefInfo can not be null")
  @Size(min = 1, message = "patientPrefInfo can not be empty")
  @Size(max = 10, message = "patientPrefInfo can not be more than 10 at once")
  private List<PatientPreferences> patientPrefInfo;

  @Valid
  @NotNull(message = "userInfo can not be null")
  private UserInfo userInfo;

  private Map<String, Object> additionalAttributes;
}
