package foundations.config;

import com.walmart.hwqe.commons.utilities.PropertyReader;

import java.io.InputStream;
import java.util.Properties;

/**
 * Foundations-specific property reader that works with Dragon Library's PropertyReader
 * Loads environment-specific configuration from properties files (stg.properties, dev.properties, qe.properties)
 * Uses composition to leverage Dragon Library PropertyReader
 */
public class FoundationsPropertyReader {

    private static FoundationsPropertyReader instance;
    private Properties config;
    private String environmentName;
    private PropertyReader dragonPropertyReader;

    /**
     * Private constructor for singleton pattern
     */
    private FoundationsPropertyReader() {
        // Get Dragon Library PropertyReader instance
        this.dragonPropertyReader = PropertyReader.getInstance();

        // Default environment is "stg" if not specified
        this.environmentName = System.getProperty("environment", "stg");
        loadEnvironmentConfig();
    }

    /**
     * Get singleton instance
     * @return FoundationsPropertyReader instance
     */
    public static synchronized FoundationsPropertyReader getInstance() {
        if (instance == null) {
            instance = new FoundationsPropertyReader();
        }
        return instance;
    }
    
    /**
     * Get Dragon Library PropertyReader instance
     * @return PropertyReader instance
     */
    public PropertyReader getDragonPropertyReader() {
        return dragonPropertyReader;
    }
    
    /**
     * Get property from Dragon Library PropertyReader
     * @param key Property key
     * @return Property value
     */
    public String getDragonProperty(String key) {
        return dragonPropertyReader.getProperty(key);
    }

    /**
     * Load environment-specific configuration from properties file
     */
    private void loadEnvironmentConfig() {
        try {
            String configFile = String.format("/config/%s.properties", environmentName);
            InputStream inputStream = getClass().getResourceAsStream(configFile);

            if (inputStream == null) {
                throw new RuntimeException("Configuration file not found: " + configFile);
            }

            config = new Properties();
            config.load(inputStream);

            System.out.println("Loaded configuration for environment: " + environmentName);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load configuration for environment: " + environmentName, e);
        }
    }

    /**
     * Get property value as String
     * Checks Foundations properties config first, then falls back to Dragon Library properties
     * This provides unified access to all property sources:
     * - Foundations properties files (stg.properties, dev.properties, qe.properties)
     * - Dragon Library config.properties
     * - Akeyless Vault secrets
     * - CCM properties
     * 
     * @param key Property key
     * @return Property value
     */
    public String getProperty(String key) {
        // First check Foundations properties config
        String value = config.getProperty(key);
        if (value != null) {
            return value;
        }
        
        // Fall back to Dragon Library properties (includes Akeyless, CCM, etc.)
        return dragonPropertyReader.getProperty(key);
    }

    /**
     * Get property value with default
     * @param key Property key
     * @param defaultValue Default value if key not found
     * @return Property value or default
     */
    public String getProperty(String key, String defaultValue) {
        String value = getProperty(key);
        return value != null ? value : defaultValue;
    }
    
    /**
     * Get property exclusively from Foundations properties config
     * @param key Property key
     * @return Property value from properties only
     */
    public String getFoundationsProperty(String key) {
        return config.getProperty(key);
    }

    /**
     * Get base URI for API calls
     * @return Base URI
     */
    public String getPmsBaseUri() {
        return getProperty("pmsBaseUri");
    }

    /**
     * Get base URI for API calls
     * @return Base URI
     */
    public String getCpoBaseUri() {
        return getProperty("cpoBaseUri");
    }

    /**
     * Get timeout value
     * @return Timeout in milliseconds
     */
    public int getTimeout() {
        String timeout = getProperty("timeout", "30000");
        return Integer.parseInt(timeout);
    }

    /**
     * Get retry count
     * @return Number of retries
     */
    public int getRetryCount() {
        String retryCount = getProperty("retryCount", "3");
        return Integer.parseInt(retryCount);
    }

    /**
     * Get API version
     * @return API version
     */
    public String getApiVersion() {
        return getProperty("apiVersion", "v1");
    }

    /**
     * Check if logging is enabled
     * @return true if logging enabled
     */
    public boolean isLoggingEnabled() {
        String enabled = getProperty("enableLogging", "true");
        return Boolean.parseBoolean(enabled);
    }

    /**
     * Get max connections
     * @return Maximum number of connections
     */
    public int getMaxConnections() {
        String maxConnections = getProperty("maxConnections", "10");
        return Integer.parseInt(maxConnections);
    }

    /**
     * Get current environment name
     * @return Environment name (stg, dev, qe)
     */
    public String getEnvironmentName() {
        return environmentName;
    }

    /**
     * Set environment (useful for testing)
     * @param env Environment name
     */
    public void setEnvironment(String env) {
        this.environmentName = env;
        loadEnvironmentConfig();
    }

    /**
     * Get full configuration as Properties
     * @return Complete configuration
     */
    public Properties getConfig() {
        return config;
    }
    
    /**
     * Get endpoint from config
     * @param endpointKey Endpoint key (e.g., "health", "sample")
     * @return Endpoint path
     */
    public String getEndpoint(String endpointKey) {
        return config.getProperty("endpoints." + endpointKey);
    }
}
