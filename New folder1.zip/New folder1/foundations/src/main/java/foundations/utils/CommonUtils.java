package foundations.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

public class CommonUtils {
    public static String getCurrentTimestamp() {
        LocalDateTime now = LocalDateTime.ofInstant(Instant.now(), ZoneId.of("UTC"));

        // Define the formatter for the desired format
        DateTimeFormatter formatter =
                new DateTimeFormatterBuilder()
                        .appendPattern("yyyy-MM-dd'T'HH:mm:ss")
                        .appendFraction(ChronoField.MICRO_OF_SECOND, 6, 6, true)
                        .appendLiteral("UTC")
                        .toFormatter();

        // Format the timestamp
        return now.format(formatter);
    }
}
