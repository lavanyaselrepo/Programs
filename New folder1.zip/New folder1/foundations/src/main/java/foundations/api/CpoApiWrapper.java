package foundations.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.config.FoundationsPropertyReader;
import foundations.models.cpo.request.V1PostPreferencesRequest;
import foundations.models.cpo.response.V1PostPreferencesResponse;
import foundations.validators.ICpoValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.http.HttpMethod;

import java.util.HashMap;
import java.util.Map;

import static foundations.constants.GeneralConstants.*;
import static io.restassured.RestAssured.given;

/**
 * API wrapper class for CPO (Communication Preference Orchestrator) endpoints.
 * Contains reusable methods for CPO-specific API calls.
 * Uses POJO models for request/response handling.
 */
public class CpoApiWrapper {

    private final FoundationsPropertyReader propertyReader;
    private final RequestSpecification cpoRequestSpec;
    private final ObjectMapper objectMapper;
    private final ICpoValidator cpoValidator;

    public CpoApiWrapper(RequestSpecification cpoRequestSpec, ICpoValidator cpoValidator) {
        this.cpoRequestSpec = cpoRequestSpec;
        this.cpoValidator = cpoValidator;
        this.propertyReader = FoundationsPropertyReader.getInstance();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Perform GET request to the specified endpoint
     */
    public Response performGetRequest(String endpoint, Map<String, String> headers) {
        Reporter.log("Performing GET request to endpoint: " + endpoint);
        Reporter.log("Base URI: " + propertyReader.getCpoBaseUri());

        Response response = given()
                .spec(cpoRequestSpec)
                .headers(headers)
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();

        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.log("Response Body: " + response.body().asString());
        return response;
    }

    /**
     * Perform POST request to the specified endpoint
     */
    public Response performPostRequest(String endpoint, String requestBody, Map<String, String> headers) {
        Reporter.log("Performing POST request to endpoint: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);

        Response response = given()
                .spec(cpoRequestSpec)
                .body(requestBody)
                .headers(headers)
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();

        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().asString());
        return response;
    }

    /**
     * Perform PUT request to the specified endpoint
     */
    public Response performPutRequest(String endpoint, String requestBody, Map<String, String> headers) {
        Reporter.log("Performing PUT request to endpoint: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);

        Response response = given()
                .spec(cpoRequestSpec)
                .body(requestBody)
                .headers(headers)
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();

        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().asString());
        return response;
    }

    /**
     * Method to test V3 Preferences APIs
     *
     * @param testInputDetails Test data JSON object
     * @param commonHeaders    Common headers to merge with request headers
     * @param testName         Test name used for logging and validation reporting
     */
    public void testV3PreferencesApis(JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String requestEndpoint   = testInputDetails.getString(ENDPOINT);
            String httpMethod = testInputDetails.optString(HTTP_METHOD, HttpMethod.POST.name());
            String requestBody = testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString();
            Reporter.log("Environment: " + propertyReader.getEnvironmentName());
            Reporter.log("Base URI: " + propertyReader.getCpoBaseUri());
            Reporter.log("API Version: " + propertyReader.getApiVersion());
            Reporter.log(String.format("[%s] Request endpoint   : %s", testName, requestEndpoint));
            Reporter.log(String.format("[%s] HTTP Method: %s", testName, httpMethod));

            // Build request POJO from test data
            Reporter.logJSON("Request Body:", requestBody);

            Map<String, String> requestHeaders = objectMapper.readValue(testInputDetails.getJSONObject(REQUEST_HEADERS).toString(), new TypeReference<>() {});
            requestHeaders.putAll(commonHeaders);
            Reporter.logJSON("Request Headers:", requestHeaders);

            // Optional setup step using PUT/POST — setupPayload may be a JSONObject or JSONArray
            if (testInputDetails.has(SETUP_PAYLOAD)) {
                String setupRequest = testInputDetails.optJSONArray(SETUP_PAYLOAD) != null
                        ? testInputDetails.getJSONArray(SETUP_PAYLOAD).toString()
                        : testInputDetails.getJSONObject(SETUP_PAYLOAD).toString();
                String setupEndpoint = testInputDetails.getString(SETUP_ENDPOINT);
                if (StringUtils.isNotBlank(setupRequest)) {
                    Reporter.logJSON("Setup Request Body", setupRequest);
                    Response setupRawResponse = null;
                    String setupHttpMethod = testInputDetails.optString(SETUP_HTTP_METHOD, HttpMethod.PUT.name());
                    if(setupHttpMethod.equalsIgnoreCase(HttpMethod.PUT.name())) {
                        setupRawResponse = performPutRequest(setupEndpoint, setupRequest, requestHeaders);
                    } else if (setupHttpMethod.equalsIgnoreCase(HttpMethod.POST.name())) {
                        setupRawResponse = performPostRequest(setupEndpoint, setupRequest, requestHeaders);;
                    }
                    assert setupRawResponse != null;
                    Reporter.log("Setup Response Status Code: " + setupRawResponse.getStatusCode());
                    Reporter.logJSON("Setup Response Body:", setupRawResponse.getBody().asString());
                }
            }

            Response response = null;
            if(httpMethod.equalsIgnoreCase(HttpMethod.PUT.name())) {
                response = performPutRequest(requestEndpoint, requestBody, requestHeaders);
            } else if (httpMethod.equalsIgnoreCase(HttpMethod.POST.name())) {
                response = performPostRequest(requestEndpoint, requestBody, requestHeaders);
            }

            assert response != null;
            Reporter.log("Response Status Code: " + response.getStatusCode());
            Reporter.logJSON("Response Body:", response.body().asString());

            int actualStatusCode   = response.getStatusCode();
            String actualResponseBody = response.getBody().asString();

            cpoValidator.validateCommPreferenceResponse(testName, actualStatusCode, actualResponseBody, testInputDetails);
        } catch (Exception e) {
            Reporter.log(String.format("Error running test [%s]: %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test [%s]: %s", testName, e.getMessage()));
        }
    }

    /**
     * Executes a Comm Preference Service (legacy CPO) API call.
     *
     * <p>Reads the target {@code endpoint} and {@code httpMethod} directly from the test data JSON,
     * so a single method handles getPreference, updatePreference, email subscribe, and email
     * unsubscribe tests without requiring individual endpoint constants.
     *
     * <p>When {@code modifierDataMap} is present in the test data (e.g.
     * {@code "COMM_PREFERENCE_HEADER_MODIFIER"}), the corresponding header overrides are applied
     * before the request is sent — this allows negative tests that validate invalid tenant / buType
     * header values.
     *
     * @param testInputDetails Test data JSON object (one test-case block from the JSON file)
     * @param commonHeaders    Base headers (Content-Type, Accept) from {@code getCommonHeaders()}
     * @param testName         Method name used for logging and assertion messages
     */
    public void testCommPreferenceApi(JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String endpoint   = testInputDetails.getString(ENDPOINT);
            String httpMethod = testInputDetails.optString(HTTP_METHOD, "POST");
            String requestBody = testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString();

            Reporter.log(String.format("[%s] Endpoint   : %s", testName, endpoint));
            Reporter.log(String.format("[%s] HTTP Method: %s", testName, httpMethod));
            Reporter.logJSON(String.format("[%s] Request Body:", testName), requestBody);

            // Build request headers — start from common headers, then layer on test-data
            // requestHeaders (if present), then apply any modifier overrides
            Map<String, String> headers = new HashMap<>(commonHeaders);
            if (testInputDetails.has(REQUEST_HEADERS) && !testInputDetails.isNull(REQUEST_HEADERS)) {
                Map<String, String> testHeaders = objectMapper.readValue(
                        testInputDetails.getJSONObject(REQUEST_HEADERS).toString(), new TypeReference<>() {});
                headers.putAll(testHeaders);
                Reporter.logJSON(String.format("[%s] Request Headers from test data:", testName), testHeaders.toString());
            }

            if(testInputDetails.has(SETUP_PAYLOAD)){
                V1PostPreferencesRequest setupRequest = objectMapper.readValue(testInputDetails.getJSONObject(SETUP_PAYLOAD).toString(), V1PostPreferencesRequest.class);
                String setupEndpoint = testInputDetails.getString(SETUP_ENDPOINT);
                String setupBody = objectMapper.writeValueAsString(setupRequest);
                if(StringUtils.isNotBlank(setupBody)){
                    Reporter.logJSON("Setup Request Body", setupBody);
                    Response response = performPostRequest(setupEndpoint, setupBody, headers);
                    Reporter.log("Setup Response Status Code: " + response.getStatusCode());
                    Reporter.logJSON("Setup Response Body:", objectMapper.readValue(response.body().asString(),V1PostPreferencesResponse.class));
                }
            }

            if (testInputDetails.has(MODIFIER_DATA_MAP) && !testInputDetails.isNull(MODIFIER_DATA_MAP)) {
                String modifier = testInputDetails.getString(MODIFIER_DATA_MAP);
                applyHeaderModifier(headers, modifier);
                Reporter.log(String.format("[%s] Applied modifier: %s", testName, modifier));
            }

            Reporter.logJSON(String.format("[%s] Request Headers:", testName), headers.toString());

            // Execute the HTTP call (currently only POST is used by all CPO legacy endpoints)
            Response response = performPostRequest(endpoint, requestBody, headers);

            int    actualStatusCode   = response.getStatusCode();
            String actualResponseBody = response.getBody().asString();

            Reporter.log(String.format("[%s] Response Status Code: %d", testName, actualStatusCode));
            Reporter.logJSON(String.format("[%s] Response Body:", testName), actualResponseBody);

            // Log optional activities / searchDoc fields for traceability
            if (testInputDetails.has(ACTIVITIES) && !testInputDetails.isNull(ACTIVITIES)) {
                Reporter.log(String.format("[%s] Activities: %s", testName, testInputDetails.getString(ACTIVITIES)));
            }
            if (testInputDetails.has(SEARCH_DOC) && !testInputDetails.isNull(SEARCH_DOC)) {
                Reporter.logJSON(String.format("[%s] Search Doc (expected):", testName),
                        testInputDetails.getJSONObject(SEARCH_DOC).toString());
            }

            // Route to appropriate validator based on endpoint
            if ("/getEnrolledPatients".equals(endpoint)) {
                cpoValidator.validateEnrolledPatientsResponse(testName, actualStatusCode, actualResponseBody, testInputDetails);
            } else {
                cpoValidator.validateCommPreferenceResponse(testName, actualStatusCode, actualResponseBody, testInputDetails);
            }

        } catch (Exception e) {
            Reporter.log(String.format("Error running test [%s]: %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test [%s]: %s", testName, e.getMessage()));
        }
    }

    /**
     * Executes a CPO V2 Preferences API call — handles both the query flow
     * ({@code POST /v2/preferences/query}) and the update flow ({@code PUT /v2/preferences}).
     *
     * <p>When {@code setupPayload} is present, a {@code PUT /v2/preferences} call is made first
     * to seed the required preference state.  The setup body is sent as raw JSON (not deserialised
     * through a POJO) so that optional fields such as {@code principalId} are transmitted exactly
     * as authored in the test-data file — no null-field injection from Jackson serialisation.
     *
     * <p>Validation is delegated to
     * {@link foundations.validators.ICpoValidator#validateCommPreferenceResponse}, which compares
     * status code and response body against the expected values in the test data and respects
     * the {@code excludeValueValidation} flag.
     *
     * @param testInputDetails Test data JSON object (one test-case block from the JSON file)
     * @param commonHeaders    Base headers (Content-Type, Accept) from {@code getCommonHeaders()}
     * @param testName         Method name used for logging and assertion messages
     */
    public void testV2Preferences(JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String endpoint   = testInputDetails.getString(ENDPOINT);
            String httpMethod = testInputDetails.optString(HTTP_METHOD, "POST");
            String requestBody = testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString();

            Reporter.log(String.format("[%s] Endpoint   : %s", testName, endpoint));
            Reporter.log(String.format("[%s] HTTP Method: %s", testName, httpMethod));
            Reporter.logJSON(String.format("[%s] Request Body:", testName), requestBody);

            // Build request headers — start from common headers, then layer on test-data
            // requestHeaders (if present), then apply any modifier overrides
            Map<String, String> headers = new HashMap<>(commonHeaders);
            if (testInputDetails.has(REQUEST_HEADERS) && !testInputDetails.isNull(REQUEST_HEADERS)) {
                Map<String, String> testHeaders = objectMapper.readValue(
                        testInputDetails.getJSONObject(REQUEST_HEADERS).toString(), new TypeReference<>() {});
                headers.putAll(testHeaders);
                Reporter.logJSON(String.format("[%s] Request Headers from test data:", testName), testHeaders.toString());
            }
            if (testInputDetails.has(MODIFIER_DATA_MAP) && !testInputDetails.isNull(MODIFIER_DATA_MAP)) {
                String modifier = testInputDetails.getString(MODIFIER_DATA_MAP);
                applyHeaderModifier(headers, modifier);
                Reporter.log(String.format("[%s] Applied modifier: %s", testName, modifier));
            }

            Reporter.logJSON(String.format("[%s] Request Headers:", testName), headers.toString());

            // Optional setup step — raw JSON body used directly to preserve optional/missing fields
            if (testInputDetails.has(SETUP_PAYLOAD)) {
                String setupEndpoint = testInputDetails.getString(SETUP_ENDPOINT);
                String setupBody     = testInputDetails.getJSONObject(SETUP_PAYLOAD).toString();
                if (StringUtils.isNotBlank(setupBody)) {
                    Reporter.logJSON("Setup Request Body", setupBody);
                    Response setupResponse = performPutRequest(setupEndpoint, setupBody, headers);
                    Reporter.log("Setup Response Status Code: " + setupResponse.getStatusCode());
                    Reporter.logJSON("Setup Response Body:", setupResponse.body().asString());
                }
            }

            // Dispatch on httpMethod — POST for query endpoints, PUT for update endpoints
            Response response = "PUT".equalsIgnoreCase(httpMethod)
                    ? performPutRequest(endpoint, requestBody, headers)
                    : performPostRequest(endpoint, requestBody, headers);

            int    actualStatusCode   = response.getStatusCode();
            String actualResponseBody = response.getBody().asString();

            Reporter.log(String.format("[%s] Response Status Code: %d", testName, actualStatusCode));
            Reporter.logJSON(String.format("[%s] Response Body:", testName), actualResponseBody);

            cpoValidator.validateCommPreferenceResponse(testName, actualStatusCode, actualResponseBody, testInputDetails);

        } catch (Exception e) {
            Reporter.log(String.format("Error running test [%s]: %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test [%s]: %s", testName, e.getMessage()));
        }
    }

    /**
     * Executes a Proxy Enrollment preference API call — handles both the GET (query)
     * and POST (update) flows for the notification preference proxy endpoints.
     *
     * <p>Endpoint patterns:
     * <ul>
     *   <li>GET  {@code /proxy/v1/customer/{id}/domain/{domain}/notification/preference?type=SMS&...}</li>
     *   <li>POST {@code /proxy/v1/customer/{id}/domain/{domain}/notification/preference}</li>
     * </ul>
     *
     * <p>When {@code setupPayload} is present, a setup call is made first using the
     * {@code setupEndpoint} and {@code setupHttpMethod} from the test data to seed
     * the required preference state before the actual test assertion.
     *
     * <p>The setup payload supports both JSON arrays and JSON objects to accommodate
     * the enrollment API contract which expects an array of preference objects.
     *
     * @param testInputDetails Test data JSON object (one test-case block from the JSON file)
     * @param commonHeaders    Base headers (Content-Type, Accept) from {@code getCommonHeaders()}
     * @param testName         Method name used for logging and assertion messages
     */
    public void testProxyEnrollmentApi(JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String endpoint   = testInputDetails.getString(ENDPOINT);
            String httpMethod = testInputDetails.optString(HTTP_METHOD, "GET");
            String requestBody = null;
            if(testInputDetails.has(REQUEST_PAYLOAD) && !testInputDetails.isNull(REQUEST_PAYLOAD)){
                requestBody = testInputDetails.get(REQUEST_PAYLOAD) instanceof org.json.JSONArray
                        ? testInputDetails.getJSONArray(REQUEST_PAYLOAD).toString()
                        : testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString();
            }

            Reporter.log(String.format("[%s] Endpoint   : %s", testName, endpoint));
            Reporter.log(String.format("[%s] HTTP Method: %s", testName, httpMethod));
            Reporter.logJSON(String.format("[%s] Request Body:", testName), requestBody);

            // Build request headers — start from common headers, then layer on test-data
            // requestHeaders (if present), then apply any modifier overrides
            Map<String, String> headers = new HashMap<>(commonHeaders);
            if (testInputDetails.has(REQUEST_HEADERS) && !testInputDetails.isNull(REQUEST_HEADERS)) {
                Map<String, String> testHeaders = objectMapper.readValue(
                        testInputDetails.getJSONObject(REQUEST_HEADERS).toString(), new TypeReference<>() {});
                headers.putAll(testHeaders);
                Reporter.logJSON(String.format("[%s] Request Headers from test data:", testName), testHeaders.toString());
            }
            if (testInputDetails.has(MODIFIER_DATA_MAP) && !testInputDetails.isNull(MODIFIER_DATA_MAP)) {
                String modifier = testInputDetails.getString(MODIFIER_DATA_MAP);
                applyHeaderModifier(headers, modifier);
                Reporter.log(String.format("[%s] Applied modifier: %s", testName, modifier));
            }

            Reporter.logJSON(String.format("[%s] Request Headers:", testName), headers.toString());

            // Optional setup step — supports both JSON array and object payloads
            if (testInputDetails.has(SETUP_PAYLOAD)) {
                String setupEndpoint   = testInputDetails.getString(SETUP_ENDPOINT);
                String setupBody = testInputDetails.get(SETUP_PAYLOAD) instanceof org.json.JSONArray
                        ? testInputDetails.getJSONArray(SETUP_PAYLOAD).toString()
                        : testInputDetails.getJSONObject(SETUP_PAYLOAD).toString();
                if (StringUtils.isNotBlank(setupBody)) {
                    Reporter.logJSON("Setup Request Body", setupBody);
                    Response setupResponse = performPostRequest(setupEndpoint, setupBody, headers);
                    Reporter.log("Setup Response Status Code: " + setupResponse.getStatusCode());
                    Reporter.logJSON("Setup Response Body:", setupResponse.body().asString());
                }
            }

            // Dispatch on httpMethod — GET for query, POST for update
            Response response = "GET".equalsIgnoreCase(httpMethod)
                    ? performGetRequest(endpoint, headers)
                    : performPostRequest(endpoint, requestBody, headers);

            int    actualStatusCode   = response.getStatusCode();
            String actualResponseBody = response.getBody().asString();

            Reporter.log(String.format("[%s] Response Status Code: %d", testName, actualStatusCode));
            Reporter.logJSON(String.format("[%s] Response Body:", testName), actualResponseBody);

            cpoValidator.validateCommPreferenceResponse(testName, actualStatusCode, actualResponseBody, testInputDetails);

        } catch (Exception e) {
            Reporter.log(String.format("Error running test [%s]: %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test [%s]: %s", testName, e.getMessage()));
        }
    }

    /**
     * Applies header overrides based on the modifier key defined in the test data.
     *
     * <p>{@code COMM_PREFERENCE_HEADER_MODIFIER} sets an invalid tenant/buType header
     * to exercise the "bad tenant" negative-test path (expected HTTP 400).
     * Extend this method when new modifier keys are introduced.
     *
     * @param headers  Mutable header map to be updated in place
     * @param modifier Modifier key from the {@code modifierDataMap} test-data field
     */
    private void applyHeaderModifier(Map<String, String> headers, String modifier) {
        if ("COMM_PREFERENCE_HEADER_MODIFIER".equals(modifier)) {
            // Simulate an unsupported tenant value to trigger the "tenant not supported" 400 response
            headers.put("WM_TENANT_ID", "hw1");
            headers.put("WM_VERTICAL_ID", "1");
        }
        // Add additional modifier cases here as needed
    }
}
