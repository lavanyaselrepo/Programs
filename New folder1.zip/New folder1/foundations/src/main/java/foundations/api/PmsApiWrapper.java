package foundations.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import foundations.config.FoundationsPropertyReader;
import foundations.models.request.PmsV3GetPreferencesRequest;
import foundations.models.request.PmsV3SavePreferencesRequest;
import foundations.models.response.PmsV3GetPreferencesResponse;
import foundations.models.response.ResponseMessage;
import foundations.validators.IValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

import static foundations.constants.GeneralConstants.*;
import static foundations.utils.CommonUtils.getCurrentTimestamp;
import static io.restassured.RestAssured.given;

/**
 * API wrapper class for Sample API endpoints
 * Contains reusable methods for API calls following Dragon Library pattern
 * Uses POJO models for request/response handling
 */
public class PmsApiWrapper {

    private final FoundationsPropertyReader propertyReader;
    private final RequestSpecification pmsRequestSpec;
    private final ObjectMapper objectMapper;
    private final IValidator iValidator;


    public PmsApiWrapper(RequestSpecification pmsRequestSpec, IValidator iValidator) {
        this.pmsRequestSpec = pmsRequestSpec;
        this.iValidator = iValidator;
        this.propertyReader = FoundationsPropertyReader.getInstance();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Perform GET request to the specified endpoint
     * @param endpoint API endpoint
     * @return Response object
     */
    public Response performGetRequest(String endpoint) {
        Reporter.log("Performing GET request to endpoint: " + endpoint);
        Reporter.log("Base URI: " + propertyReader.getPmsBaseUri());
        
        Response response = given()
                .spec(pmsRequestSpec)
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();
        
        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.log("Response Body: " + response.body().asString());
        
        return response;
    }

    /**
     * Perform POST request to the specified endpoint
     * @param endpoint API endpoint
     * @param requestBody Request payload
     * @return Response object
     */
    public Response performPostRequest(String endpoint, String requestBody, Map<String, String> headers) {
        Reporter.log("Performing POST request to endpoint: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);
        
        Response response = given()
                .spec(pmsRequestSpec)
                .body(requestBody)
                .headers(headers)
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();
        
        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().asString());
        
        return response;
    }


    /**
     * Perform PUT request to the specified endpoint
     * @param endpoint API endpoint
     * @param requestBody Request payload
     * @return Response object
     */
    public Response performPutRequest(String endpoint, String requestBody, Map<String, String> headers) {
        Reporter.log("Performing POST request to endpoint: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);

        Response response = given()
                .spec(pmsRequestSpec)
                .body(requestBody)
                .headers(headers)
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();

        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().asString());

        return response;
    }

    /**
     * Perform PUT request to the specified endpoint
     * @param endpoint API endpoint
     * @param requestBody Request payload
     * @return Response object
     */
    public Response performPutRequest(String endpoint, String requestBody) {
        Reporter.log("Performing PUT request to endpoint: " + endpoint);
        Reporter.logJSON("Request Body:", requestBody);
        
        Response response = given()
                .spec(pmsRequestSpec)
                .body(requestBody)
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();
        
        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Response Body:", response.body().asString());
        
        return response;
    }

    /**
     * Perform DELETE request to the specified endpoint
     * @param endpoint API endpoint
     * @return Response object
     */
    public Response performDeleteRequest(String endpoint) {
        Reporter.log("Performing DELETE request to endpoint: " + endpoint);
        
        Response response = given()
                .spec(pmsRequestSpec)
                .when()
                .delete(endpoint)
                .then()
                .extract()
                .response();
        
        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.log("Response Body: " + response.body().asString());
        
        return response;
    }

    /**
     * Perform GET request with query parameters
     * @param endpoint API endpoint
     * @param queryParams Query parameters map
     * @return Response object
     */
    public Response performGetRequestWithQueryParams(String endpoint, java.util.Map<String, Object> queryParams) {
        Reporter.log("Performing GET request with query params to endpoint: " + endpoint);
        Reporter.log("Query Parameters: " + queryParams.toString());
        
        Response response = given()
                .spec(pmsRequestSpec)
                .queryParams(queryParams)
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();
        
        Reporter.log("Response Status Code: " + response.getStatusCode());
        Reporter.log("Response Body: " + response.body().asString());
        
        return response;
    }

    /**
     * Create sample resource using test data JSON
     * Builds POJO internally from test data
     * @param testInputDetails Test data JSON object
     * @return PmsV3GetPreferencesResponse POJO
     */
    public ResponseMessage<PmsV3GetPreferencesResponse> testV3GetPreferences(org.json.JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String requestEndpoint = propertyReader.getEndpoint(V3_GET_PREFERENCES_ENDPOINT);
            String setupEndpoint = propertyReader.getEndpoint(V3_SAVE_PREFERENCES_ENDPOINT);
            Reporter.log("Environment: " + propertyReader.getEnvironmentName());
            Reporter.log("Base URI: " + propertyReader.getPmsBaseUri());
            Reporter.log("API Version: " + propertyReader.getApiVersion());
            Reporter.log("Request Endpoint: " + requestEndpoint);

            // Build request POJO from test data
            PmsV3GetPreferencesRequest request = objectMapper.readValue(testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString(), PmsV3GetPreferencesRequest.class);
            String requestBody = objectMapper.writeValueAsString(request);
            Reporter.logJSON("Request Body:", requestBody);
            Map<String, String> requestHeaders = objectMapper.readValue(testInputDetails.getJSONObject(REQUEST_HEADERS).toString(),new TypeReference<>() {});
            requestHeaders.putAll(commonHeaders);
            Reporter.logJSON("Request Headers:", requestHeaders);

            if(testInputDetails.has(SETUP_PAYLOAD)){
                PmsV3SavePreferencesRequest setupRequest = objectMapper.readValue(testInputDetails.getJSONObject(SETUP_PAYLOAD).toString(), PmsV3SavePreferencesRequest.class);
                setupRequest.setRequestTs(getCurrentTimestamp());
                String setupBody = objectMapper.writeValueAsString(setupRequest);
                if(StringUtils.isNotBlank(setupBody)){
                    Reporter.logJSON("Setup Request Body", setupBody);
                    ResponseMessage<PmsV3GetPreferencesResponse> setupResponse =
                            objectMapper.readValue(performPostRequest(setupEndpoint, setupBody, requestHeaders).getBody().asString(), new TypeReference<>() {});
                    Reporter.log("Setup Response Status Code: " + setupResponse.getStatus().getHttpStatus().value());
                    Reporter.logJSON("Setup Response Body:", setupResponse);
                }
            }

            Response response = performPostRequest(requestEndpoint, requestBody, requestHeaders);;
            ResponseMessage<PmsV3GetPreferencesResponse> actualResponse =
                    objectMapper.readValue(response.getBody().asString(), new TypeReference<>() {});
            Reporter.log("Response Status Code: " + response.getStatusCode());
            Reporter.logJSON("Response Body:", response.body().asString());

            iValidator.validateApiResponse(testName, actualResponse, testInputDetails);
            return actualResponse;
        } catch (Exception e) {
            Reporter.log(String.format("Error running test %s : %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test %s : %s", testName, e.getMessage()));
        }
    }

    public ResponseMessage<PmsV3GetPreferencesResponse> testV3UpdatePreferences(org.json.JSONObject testInputDetails, Map<String, String> commonHeaders, String testName) {
        try {
            String requestEndpoint = propertyReader.getEndpoint(V3_SAVE_PREFERENCES_ENDPOINT);
            String setupEndpoint = propertyReader.getEndpoint(V3_SAVE_PREFERENCES_ENDPOINT);
            Reporter.log("Environment: " + propertyReader.getEnvironmentName());
            Reporter.log("Base URI: " + propertyReader.getPmsBaseUri());
            Reporter.log("API Version: " + propertyReader.getApiVersion());
            Reporter.log("Request Endpoint: " + requestEndpoint);
            Map<String, String> requestHeaders = objectMapper.readValue(testInputDetails.getJSONObject(REQUEST_HEADERS).toString(),new TypeReference<>() {});
            requestHeaders.putAll(commonHeaders);
            Reporter.logJSON("Request Headers:", requestHeaders);
            // Build request POJO from test data
            if(testInputDetails.has(SETUP_PAYLOAD)) {
                PmsV3SavePreferencesRequest setupRequest = objectMapper.readValue(testInputDetails.getJSONObject(SETUP_PAYLOAD).toString(), PmsV3SavePreferencesRequest.class);
                if(setupRequest.getRequestTs()==null) {
                    setupRequest.setRequestTs(getCurrentTimestamp());
                }
                String setupBody = objectMapper.writeValueAsString(setupRequest);
                if(StringUtils.isNotBlank(setupBody)){
                    Reporter.logJSON("Setup Request Body", setupBody);
                    ResponseMessage<PmsV3GetPreferencesResponse> setupResponse =
                            objectMapper.readValue(performPostRequest(setupEndpoint, setupBody, requestHeaders).getBody().asString(), new TypeReference<>() {});
                    Reporter.log("Setup Response Status Code: " + setupResponse.getStatus().getHttpStatus().value());
                    Reporter.logJSON("Setup Response Body:", setupResponse);
                }
            }
            PmsV3SavePreferencesRequest request = objectMapper.readValue(testInputDetails.getJSONObject(REQUEST_PAYLOAD).toString(), PmsV3SavePreferencesRequest.class);
            if(request.getRequestTs()==null) {
                request.setRequestTs(getCurrentTimestamp());
            }
            String requestBody = objectMapper.writeValueAsString(request);
            Response response = performPostRequest(requestEndpoint, requestBody, requestHeaders);;
            ResponseMessage<PmsV3GetPreferencesResponse> actualResponse =
                    objectMapper.readValue(response.getBody().asString(), new TypeReference<>() {});
            Reporter.log("Response Status Code: " + response.getStatusCode());
            Reporter.logJSON("Response Body:", response.body().asString());
            iValidator.validateApiResponse(testName, actualResponse, testInputDetails);
            return actualResponse;
        } catch (Exception e) {
            Reporter.log(String.format("Error running test %s : %s", testName, e.getMessage()));
            throw new RuntimeException(String.format("Error running test %s : %s", testName, e.getMessage()));
        }
    }

}
