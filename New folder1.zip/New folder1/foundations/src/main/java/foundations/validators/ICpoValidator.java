package foundations.validators;

import foundations.models.cpo.response.CpoGetV3PreferenceResponse;

public interface ICpoValidator {

    /**
     * Validates the CPO V3 Get Preferences API response against expected test data.
     * Used by {@code testV3GetPreferences} in CpoApiWrapper.
     */
    void validateApiResponseCpo(String testName, CpoGetV3PreferenceResponse actualResponse, org.json.JSONObject testInputDetails);

    /**
     * Validates the Comm Preference Service (legacy CPO) API response.
     * Compares the actual HTTP status code and response body against the expected
     * values stored in the test data JSON (responseStatusCode / responseBody fields).
     *
     * @param testName           Test method name used for reporting
     * @param actualStatusCode   HTTP status code returned by the service
     * @param actualResponseBody Raw JSON response body string from the service
     * @param testInputDetails   Test data JSON object containing expected values
     */
    void validateCommPreferenceResponse(String testName, int actualStatusCode, String actualResponseBody, org.json.JSONObject testInputDetails);

    /**
     * Validates the getEnrolledPatients API response.
     *
     * <p>For 200 responses with a setup payload: verifies only that the patients seeded
     * via setup (storeNbr + patientId from {@code setupPayload.patientPrefInfo}) appear
     * in the {@code enrolledPatientInfo} array — ignores other enrolled patients returned
     * by the API. Also validates {@code statusCode} and {@code statusText}.
     *
     * <p>For 204: verifies empty body. For 400: does full body comparison.
     *
     * @param testName           Test method name used for reporting
     * @param actualStatusCode   HTTP status code returned by the service
     * @param actualResponseBody Raw JSON response body string from the service
     * @param testInputDetails   Test data JSON object containing expected values and optional setupPayload
     */
    void validateEnrolledPatientsResponse(String testName, int actualStatusCode, String actualResponseBody, org.json.JSONObject testInputDetails);
}
