package foundations.validators;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.models.response.ResponseMessage;
import foundations.models.response.PmsV3GetPreferencesResponse;
import org.testng.Assert;

import java.util.Arrays;

import static foundations.constants.GeneralConstants.*;

public class PmsResponseValidator implements IValidator  {

  @Override
  public void validateApiResponse(String testName, ResponseMessage<PmsV3GetPreferencesResponse> actualResponse, org.json.JSONObject testInputDetails) {
    try {
      ObjectMapper mapper = new ObjectMapper();
      org.json.JSONObject responseBodyJson = testInputDetails.getJSONObject(RESPONSE_BODY);
      JsonObject expectedResponse = JsonParser.parseString(responseBodyJson.toString()).getAsJsonObject();
      boolean excludeValueValidation = testInputDetails.getBoolean(EXCLUDE_VALUE_VALIDATION);

      String correlationId = actualResponse.getGlobalTrackingId();
      Reporter.log(String.format("Response obtained from the service for correlationId: %s is: %s", correlationId, actualResponse));

      int actualStatusCode = actualResponse.getStatus().getHttpStatus().value();
      int expectedStatusCode = testInputDetails.getInt(RESPONSE_STATUS_CODE);
      Assert.assertEquals(actualStatusCode, expectedStatusCode, "Response Status code mismatch");

      StringBuilder diff = new StringBuilder();
      // Add all dynamic fields to exclusion list
      String[] excludeFields = new String[]{GLOBAL_TRACKING_ID, REQUEST_TS, LAST_UPDATE_TS};
      compareJsonNodes(mapper.valueToTree(actualResponse), mapper.readTree(expectedResponse.toString()), "", diff, excludeFields, excludeValueValidation);
      if (!diff.isEmpty()) {
        Reporter.log(String.format("expectedResponse: %s", expectedResponse));
        Reporter.log(String.format("actualResponse: %s", actualResponse));
        Assert.fail(String.format("JSON response mismatch for %s test :\n%s",testName, diff));
      }
    } catch (Exception exception) {
      Reporter.log(String.format("Encountered exception in Preference Service Response Validator. Exception %s. Exception Stacktrace: %s.", exception.getMessage(), Arrays.toString(exception.getStackTrace())));
      Assert.fail(String.format("Encountered exception in Preference Service Response Validator. Exception %s. Exception Stacktrace: %s.", exception.getMessage(), Arrays.toString(exception.getStackTrace())));
    }
  }

  /**
   * Recursively compares two JsonNodes and appends differences to the diff StringBuilder.
   * Excludes fields listed in excludeFields from comparison.
   */
  private static void compareJsonNodes(JsonNode actual, JsonNode expected, String path, StringBuilder diff, String[] excludeFields, boolean excludeValueValidation) {
    if (expected == null && actual == null) return;
    if (expected == null || actual == null) {
      diff.append(String.format("Path '%s': One is null, other is not.\n", path));
      return;
    }
    if (!expected.getNodeType().equals(actual.getNodeType())) {
      diff.append(String.format("Path '%s': Node type mismatch. Expected: %s, Actual: %s\n", path, expected.getNodeType(), actual.getNodeType()));
      return;
    }
    switch (expected.getNodeType()) {
      case OBJECT:
        expected.fieldNames().forEachRemaining(field -> {
          if (isExcluded(field, excludeFields)) return;
          if (!actual.has(field)) {
            diff.append(String.format("Path '%s/%s': Missing in actual.\n", path, field));
          } else {
            compareJsonNodes(actual.get(field), expected.get(field), path + "/" + field, diff, excludeFields, excludeValueValidation);
          }
        });
        actual.fieldNames().forEachRemaining(field -> {
          if (isExcluded(field, excludeFields)) return;
          if (!expected.has(field)) {
            diff.append(String.format("Path '%s/%s': Unexpected field in actual.\n", path, field));
          }
        });
        break;
      case ARRAY:
        if (expected.size() != actual.size()) {
          diff.append(String.format("Path '%s': Array size mismatch. Expected: %d, Actual: %d\n", path, expected.size(), actual.size()));
        } else {
          for (int i = 0; i < expected.size(); i++) {
            compareJsonNodes(actual.get(i), expected.get(i), path + "[" + i + "]", diff, excludeFields, excludeValueValidation);
          }
        }
        break;
      default:
        String fieldName = path.substring(path.lastIndexOf("/") + 1);
        if (isExcluded(fieldName, excludeFields)) {
          break;
        }
        String expectedText = expected.asText();
        String actualText = actual.asText();
        // Handle embedded JSON with excluded fields
        if (shouldHandleEmbeddedJson(path, expectedText, actualText, excludeFields)) {
          handleEmbeddedJsonComparison(expectedText, actualText, path, diff, excludeFields);
          break;
        }
        if (!excludeValueValidation && !expectedText.equals(actualText)) {
          diff.append(String.format("Path '%s': Value mismatch. Expected: %s, Actual: %s\n", path, expectedText, actualText));
        }
        break;
    }
  }

  /**
   * Checks if a field should be excluded from comparison.
   */
  private static boolean isExcluded(String field, String[] excludeFields) {
    for (String exclude : excludeFields) {
      if (exclude.equals(field)) return true;
    }
    return false;
  }

  /**
   * Determines if embedded JSON comparison should be handled for excluded fields.
   */
  private static boolean shouldHandleEmbeddedJson(String path, String expectedText, String actualText, String[] excludeFields) {
    for (String exclude : excludeFields) {
      if ((path.endsWith("/error/message") && expectedText.contains(exclude) && actualText.contains(exclude)) ||
          (expectedText.contains(exclude) && actualText.contains(exclude))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Handles embedded JSON comparison, excluding specified fields.
   */
  private static void handleEmbeddedJsonComparison(String expectedText, String actualText, String path, StringBuilder diff, String[] excludeFields) {
    String expectedEmbedded = extractEmbeddedJson(expectedText);
    String actualEmbedded = extractEmbeddedJson(actualText);
    if (expectedEmbedded != null && actualEmbedded != null) {
      try {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode expectedInner = mapper.readTree(expectedEmbedded);
        JsonNode actualInner = mapper.readTree(actualEmbedded);
        for (String exclude : excludeFields) {
          if (expectedInner.has(exclude)) {
            ((com.fasterxml.jackson.databind.node.ObjectNode) expectedInner).remove(exclude);
          }
          if (actualInner.has(exclude)) {
            ((com.fasterxml.jackson.databind.node.ObjectNode) actualInner).remove(exclude);
          }
        }
        if (!expectedInner.equals(actualInner)) {
          diff.append(String.format("Path '%s': Embedded JSON mismatch (excluding %s). Expected: %s, Actual: %s\n", path, String.join(",", excludeFields), expectedEmbedded, actualEmbedded));
        }
      } catch (Exception e) {
        // If not valid JSON, fallback to normal comparison
      }
    }
  }

  private static String extractEmbeddedJson(String text) {
    int start = text.indexOf('{');
    int end = text.lastIndexOf('}');
    if (start != -1 && end != -1 && end > start) {
      return text.substring(start, end + 1);
    }
    return null;
  }


}
