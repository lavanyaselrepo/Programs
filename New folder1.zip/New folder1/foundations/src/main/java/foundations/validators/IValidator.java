package foundations.validators;

import foundations.models.response.PmsV3GetPreferencesResponse;
import foundations.models.response.ResponseMessage;

public interface IValidator {
    void validateApiResponse(String testName, ResponseMessage<PmsV3GetPreferencesResponse> actualResponse, org.json.JSONObject testInputDetails);
}
