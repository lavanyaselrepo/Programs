package foundations.validators;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.walmart.hwqe.commons.utilities.Reporter;
import foundations.models.cpo.response.CpoGetV3PreferenceResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import java.util.Arrays;

import static foundations.constants.GeneralConstants.*;

public class CpoResponseValidator implements ICpoValidator {

    @Override
    public void validateApiResponseCpo(String testName, CpoGetV3PreferenceResponse actualResponse, org.json.JSONObject testInputDetails) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            org.json.JSONObject responseBodyJson = testInputDetails.getJSONObject(RESPONSE_BODY);
            JsonObject expectedResponse = JsonParser.parseString(responseBodyJson.toString()).getAsJsonObject();
            boolean excludeValueValidation = testInputDetails.getBoolean(EXCLUDE_VALUE_VALIDATION);

            String correlationId = testInputDetails.getJSONObject("requestHeaders").getString("WM_QOS.CORRELATION_ID");
            Reporter.log(String.format("Response obtained from the service for correlationId: %s is: %s", correlationId, actualResponse));

            String actualStatusCode = actualResponse.getStatus().getCode();
            String expectedStatusCode = testInputDetails.getJSONObject("responseBody").getJSONObject("status").getString("code");
            Assert.assertEquals(actualStatusCode, expectedStatusCode, "Response Status code mismatch");

            StringBuilder diff = new StringBuilder();
            String[] excludeFields = new String[]{GLOBAL_TRACKING_ID, REQUEST_TS, LAST_UPDATE_TS};
            compareJsonNodes(mapper.valueToTree(actualResponse), mapper.readTree(expectedResponse.toString()), "", diff, excludeFields, excludeValueValidation);
            if (!diff.isEmpty()) {
                Reporter.log(String.format("expectedResponse: %s", expectedResponse));
                Reporter.log(String.format("actualResponse: %s", actualResponse));
                Assert.fail(String.format("JSON response mismatch for %s test :\n%s", testName, diff));
            }
        } catch (Exception exception) {
            Reporter.log(String.format("Encountered exception in CPO Response Validator. Exception %s. Exception Stacktrace: %s.", exception.getMessage(), Arrays.toString(exception.getStackTrace())));
            Assert.fail(String.format("Encountered exception in CPO Response Validator. Exception %s. Exception Stacktrace: %s.", exception.getMessage(), Arrays.toString(exception.getStackTrace())));
        }
    }

    /**
     * Recursively compares two JsonNodes and appends differences to the diff StringBuilder.
     * Excludes fields listed in excludeFields from comparison.
     */
    private static void compareJsonNodes(JsonNode actual, JsonNode expected, String path, StringBuilder diff, String[] excludeFields, boolean excludeValueValidation) {
        if (expected == null && actual == null) return;
        if (expected == null || actual == null) {
            diff.append(String.format("Path '%s': One is null, other is not.\n", path));
            return;
        }
        if (!expected.getNodeType().equals(actual.getNodeType())) {
            diff.append(String.format("Path '%s': Node type mismatch. Expected: %s, Actual: %s\n", path, expected.getNodeType(), actual.getNodeType()));
            return;
        }
        switch (expected.getNodeType()) {
            case OBJECT:
                expected.fieldNames().forEachRemaining(field -> {
                    if (isExcluded(field, excludeFields)) return;
                    if (!actual.has(field)) {
                        diff.append(String.format("Path '%s/%s': Missing in actual.\n", path, field));
                    } else {
                        compareJsonNodes(actual.get(field), expected.get(field), path + "/" + field, diff, excludeFields, excludeValueValidation);
                    }
                });
                actual.fieldNames().forEachRemaining(field -> {
                    if (isExcluded(field, excludeFields)) return;
                    if (!expected.has(field)) {
                        diff.append(String.format("Path '%s/%s': Unexpected field in actual.\n", path, field));
                    }
                });
                break;
            case ARRAY:
                if (expected.size() != actual.size()) {
                    diff.append(String.format("Path '%s': Array size mismatch. Expected: %d, Actual: %d\n", path, expected.size(), actual.size()));
                } else {
                    for (int i = 0; i < expected.size(); i++) {
                        compareJsonNodes(actual.get(i), expected.get(i), path + "[" + i + "]", diff, excludeFields, excludeValueValidation);
                    }
                }
                break;
            default:
                String fieldName = path.substring(path.lastIndexOf("/") + 1);
                if (isExcluded(fieldName, excludeFields)) {
                    break;
                }
                String expectedText = expected.asText();
                String actualText = actual.asText();
                if (shouldHandleEmbeddedJson(path, expectedText, actualText, excludeFields)) {
                    handleEmbeddedJsonComparison(expectedText, actualText, path, diff, excludeFields);
                    break;
                }
                if (!excludeValueValidation && !expectedText.equals(actualText)) {
                    diff.append(String.format("Path '%s': Value mismatch. Expected: %s, Actual: %s\n", path, expectedText, actualText));
                }
                break;
        }
    }

    private static boolean isExcluded(String field, String[] excludeFields) {
        for (String exclude : excludeFields) {
            if (exclude.equals(field)) return true;
        }
        return false;
    }

    private static boolean shouldHandleEmbeddedJson(String path, String expectedText, String actualText, String[] excludeFields) {
        for (String exclude : excludeFields) {
            if ((path.endsWith("/error/message") && expectedText.contains(exclude) && actualText.contains(exclude)) ||
                    (expectedText.contains(exclude) && actualText.contains(exclude))) {
                return true;
            }
        }
        return false;
    }

    private static void handleEmbeddedJsonComparison(String expectedText, String actualText, String path, StringBuilder diff, String[] excludeFields) {
        String expectedEmbedded = extractEmbeddedJson(expectedText);
        String actualEmbedded = extractEmbeddedJson(actualText);
        if (expectedEmbedded != null && actualEmbedded != null) {
            try {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode expectedInner = mapper.readTree(expectedEmbedded);
                JsonNode actualInner = mapper.readTree(actualEmbedded);
                for (String exclude : excludeFields) {
                    if (expectedInner.has(exclude)) {
                        ((com.fasterxml.jackson.databind.node.ObjectNode) expectedInner).remove(exclude);
                    }
                    if (actualInner.has(exclude)) {
                        ((com.fasterxml.jackson.databind.node.ObjectNode) actualInner).remove(exclude);
                    }
                }
                if (!expectedInner.equals(actualInner)) {
                    diff.append(String.format("Path '%s': Embedded JSON mismatch (excluding %s). Expected: %s, Actual: %s\n", path, String.join(",", excludeFields), expectedEmbedded, actualEmbedded));
                }
            } catch (Exception e) {
                // If not valid JSON, fallback to normal comparison
            }
        }
    }

    private static String extractEmbeddedJson(String text) {
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start != -1 && end != -1 && end > start) {
            return text.substring(start, end + 1);
        }
        return null;
    }

    /**
     * Validates the Comm Preference Service (legacy CPO) API response.
     * <p>
     * Checks:
     * <ol>
     *   <li>The HTTP status code matches {@code responseStatusCode} in the test data.</li>
     *   <li>The response body matches {@code responseBody} in the test data using recursive
     *       JSON node comparison, respecting the {@code excludeValueValidation} flag.</li>
     * </ol>
     */
    @Override
    public void validateCommPreferenceResponse(String testName, int actualStatusCode, String actualResponseBody, org.json.JSONObject testInputDetails) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // 1. HTTP status code assertion
            int expectedStatusCode = testInputDetails.getInt(RESPONSE_STATUS_CODE);
            Reporter.log(String.format("[%s] Validating HTTP status code — expected: %d, actual: %d", testName, expectedStatusCode, actualStatusCode));
            Assert.assertEquals(actualStatusCode, expectedStatusCode,
                    String.format("HTTP Status Code mismatch for test: %s", testName));

            // 2. Handle 204 No Content — no response body expected
            org.json.JSONObject responseBodyJson = testInputDetails.getJSONObject(RESPONSE_BODY);
            boolean isActualBodyEmpty = actualResponseBody == null || actualResponseBody.trim().isEmpty();
            boolean isExpectedBodyEmpty = responseBodyJson.isEmpty();

            if (expectedStatusCode == 204 || (isActualBodyEmpty && isExpectedBodyEmpty)) {
                Reporter.log(String.format("[%s] Status %d with empty response body — skipping body comparison.", testName, actualStatusCode));
                if (!isActualBodyEmpty && isExpectedBodyEmpty) {
                    Assert.fail(String.format("Expected empty response body for test [%s] but got: %s", testName, actualResponseBody));
                }
                return;
            }

            // 3. Response body assertion
            boolean excludeValueValidation = testInputDetails.optBoolean(EXCLUDE_VALUE_VALIDATION, false);

            Reporter.logJSON(String.format("[%s] Expected Response Body:", testName), responseBodyJson.toString());
            Reporter.logJSON(String.format("[%s] Actual Response Body:", testName), actualResponseBody);

            JsonNode actualNode   = mapper.readTree(actualResponseBody);
            JsonNode expectedNode = mapper.readTree(responseBodyJson.toString());

            StringBuilder diff = new StringBuilder();
            String[] excludeFields = new String[]{REQUEST_TRACKING_ID, LAST_CHANGE_TS, EFFECTIVE_TS, ENS_NOTIFICATION_ID};
            compareJsonNodes(actualNode, expectedNode, "", diff, excludeFields, excludeValueValidation);

            if (!diff.isEmpty()) {
                Assert.fail(String.format("Response body mismatch for test [%s]:\n%s", testName, diff));
            }
        } catch (AssertionError ae) {
            throw ae;
        } catch (Exception e) {
            Reporter.log(String.format("Exception in validateCommPreferenceResponse for [%s]: %s. Stack: %s",
                    testName, e.getMessage(), Arrays.toString(e.getStackTrace())));
            Assert.fail(String.format("Exception in validateCommPreferenceResponse for [%s]: %s", testName, e.getMessage()));
        }
    }

    /**
     * Validates the getEnrolledPatients API response.
     *
     * <ul>
     *   <li><b>204</b> — verifies empty/no response body.</li>
     *   <li><b>400</b> — full body comparison (error responses are deterministic).</li>
     *   <li><b>200 with setup</b> — validates {@code statusCode}/{@code statusText}, then checks
     *       that every patient seeded via {@code setupPayload.patientPrefInfo} (matched by
     *       {@code storeNbr} + {@code patientId}) appears in the {@code enrolledPatientInfo} array.
     *       Other patients returned by the API are ignored.</li>
     * </ul>
     */
    @Override
    public void validateEnrolledPatientsResponse(String testName, int actualStatusCode, String actualResponseBody, org.json.JSONObject testInputDetails) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // 1. HTTP status code assertion
            int expectedStatusCode = testInputDetails.getInt(RESPONSE_STATUS_CODE);
            Reporter.log(String.format("[%s] Validating HTTP status code — expected: %d, actual: %d", testName, expectedStatusCode, actualStatusCode));
            Assert.assertEquals(actualStatusCode, expectedStatusCode,
                    String.format("HTTP Status Code mismatch for test: %s", testName));

            // 2. Handle 204 No Content — no response body expected
            org.json.JSONObject responseBodyJson = testInputDetails.getJSONObject(RESPONSE_BODY);
            boolean isActualBodyEmpty = actualResponseBody == null || actualResponseBody.trim().isEmpty();
            boolean isExpectedBodyEmpty = responseBodyJson.isEmpty();

            if (expectedStatusCode == 204 || (isActualBodyEmpty && isExpectedBodyEmpty)) {
                Reporter.log(String.format("[%s] Status %d with empty response body — skipping body comparison.", testName, actualStatusCode));
                if (!isActualBodyEmpty && isExpectedBodyEmpty) {
                    Assert.fail(String.format("Expected empty response body for test [%s] but got: %s", testName, actualResponseBody));
                }
                return;
            }

            Reporter.logJSON(String.format("[%s] Actual Response Body:", testName), actualResponseBody);

            // 3. For non-200 (e.g. 400) — full body comparison since error responses are deterministic
            if (expectedStatusCode != 200) {
                boolean excludeValueValidation = testInputDetails.optBoolean(EXCLUDE_VALUE_VALIDATION, false);
                Reporter.logJSON(String.format("[%s] Expected Response Body:", testName), responseBodyJson.toString());

                JsonNode actualNode = mapper.readTree(actualResponseBody);
                JsonNode expectedNode = mapper.readTree(responseBodyJson.toString());

                StringBuilder diff = new StringBuilder();
                String[] excludeFields = new String[]{REQUEST_TRACKING_ID, LAST_CHANGE_TS, EFFECTIVE_TS};
                compareJsonNodes(actualNode, expectedNode, "", diff, excludeFields, excludeValueValidation);

                if (!diff.isEmpty()) {
                    Assert.fail(String.format("Response body mismatch for test [%s]:\n%s", testName, diff));
                }
                return;
            }

            // 4. For 200 — validate statusCode/statusText + check setup patients exist in enrolledPatientInfo
            JsonNode actualNode = mapper.readTree(actualResponseBody);

            String actualStatusText = actualNode.has("statusText") ? actualNode.get("statusText").asText() : null;
            String actualRespStatusCode = actualNode.has("statusCode") ? actualNode.get("statusCode").asText() : null;
            String expectedStatusText = responseBodyJson.optString("statusText", null);
            String expectedRespStatusCode = responseBodyJson.optString("statusCode", null);

            Assert.assertEquals(actualRespStatusCode, expectedRespStatusCode,
                    String.format("[%s] Response statusCode mismatch", testName));
            Assert.assertEquals(actualStatusText, expectedStatusText,
                    String.format("[%s] Response statusText mismatch", testName));

            // 5. Verify setup patients are present in enrolledPatientInfo
            if (testInputDetails.has(SETUP_PAYLOAD)) {
                JSONObject setupPayload = testInputDetails.getJSONObject(SETUP_PAYLOAD);
                JSONArray patientPrefInfo = setupPayload.getJSONArray("patientPrefInfo");
                JsonNode enrolledPatientInfo = actualNode.get("enrolledPatientInfo");

                Assert.assertNotNull(enrolledPatientInfo,
                        String.format("[%s] enrolledPatientInfo is missing in response", testName));
                Assert.assertTrue(enrolledPatientInfo.isArray(),
                        String.format("[%s] enrolledPatientInfo is not an array", testName));

                for (int i = 0; i < patientPrefInfo.length(); i++) {
                    JSONObject setupPatient = patientPrefInfo.getJSONObject(i);
                    int expectedStoreNbr = setupPatient.getInt("storeNbr");
                    int expectedPatientId = setupPatient.getInt("patientId");

                    boolean found = false;
                    for (int j = 0; j < enrolledPatientInfo.size(); j++) {
                        JsonNode enrolledEntry = enrolledPatientInfo.get(j);
                        int actualStoreNbr = enrolledEntry.get("storeNbr").asInt();
                        int actualPatientId = enrolledEntry.get("patientId").asInt();

                        if (actualStoreNbr == expectedStoreNbr && actualPatientId == expectedPatientId) {
                            found = true;
                            Reporter.log(String.format("[%s] ✓ Found setup patient (storeNbr=%d, patientId=%d) in enrolledPatientInfo[%d]",
                                    testName, expectedStoreNbr, expectedPatientId, j));
                            break;
                        }
                    }

                    Assert.assertTrue(found, String.format(
                            "[%s] Setup patient (storeNbr=%d, patientId=%d) NOT found in enrolledPatientInfo. Actual response: %s",
                            testName, expectedStoreNbr, expectedPatientId, actualResponseBody));
                }

                Reporter.log(String.format("[%s] All %d setup patient(s) verified in enrolledPatientInfo.", testName, patientPrefInfo.length()));
            }

        } catch (Exception e) {
            Reporter.log(String.format("Exception in validateEnrolledPatientsResponse for [%s]: %s. Stack: %s",
                    testName, e.getMessage(), Arrays.toString(e.getStackTrace())));
            Assert.fail(String.format("Exception in validateEnrolledPatientsResponse for [%s]: %s", testName, e.getMessage()));
        }
    }
}
