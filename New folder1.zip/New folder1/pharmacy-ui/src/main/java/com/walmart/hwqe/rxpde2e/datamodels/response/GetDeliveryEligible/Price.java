package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

@lombok.Getter
@lombok.Setter
public class Price {
    public Object estimatedPrice;
    public double patientDueAmt;
    public String currency;
}
