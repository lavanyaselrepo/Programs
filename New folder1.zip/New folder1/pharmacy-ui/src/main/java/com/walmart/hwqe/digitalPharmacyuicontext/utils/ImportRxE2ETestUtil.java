package com.walmart.hwqe.digitalPharmacyuicontext.utils;


import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.utilities.StringUtils;
import com.walmart.hwqe.digitalPharmacyuicontext.constants.CommonConstants;
import com.walmart.hwqe.digitalPharmacyuicontext.dataModels.response.PatientInfo;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class ImportRxE2ETestUtil {

    public static final String MDM_ANONYMOUS_VALUES_FILE = "src/test/java/digitalPharmacyMobileAppTests/testData/mdm-anonymous-values.json";
    private final CommonUtils commonUtils = new CommonUtils();
    private final JSONObject mdmAnonymousValuesJson = new JSONObject(commonUtils.readJsonFile(MDM_ANONYMOUS_VALUES_FILE));

    private final List<String> mdmIgnoreNames = extractListFromJson(CommonConstants.mdmIgnoreCaregiverNames);
    private final List<String> mdmIgnoreDob = extractListFromJson(CommonConstants.mdmIgnoreCaregiverDOBs);
    public static final String accountPassword = CommonConstants.DOT_COM_PASSWORD;
    private static final String ndcNumber = "67877019805";
    public static final String drugName = "Amlodipine 5MG TAB";

    private List<String> extractListFromJson(String key) {
        return mdmAnonymousValuesJson.getJSONArray(key).toList().stream().map(Object::toString).collect(Collectors.toList());
    }

    /**
     * Generates two pharmacy connected accounts with the same demographic data,
     * creates accounts conflict scenario for Import Rx.
     *
     * @param accountAStore Store number for account A
     * @param accountBStore Store number for account B
     * @return List containing PatientInfo for both accounts
     */
    public List<PatientInfo> generateUnderLinkingPatientConflict(String accountAStore, String accountBStore) {

        // generate random patient data based on mdmIgnore lists to avoid CPR synchronization
        Random random = new Random();
        String firstName = mdmIgnoreNames.get(random.nextInt(mdmIgnoreNames.size()));
        String lastName = mdmIgnoreNames.get(random.nextInt(mdmIgnoreNames.size()));
        String dob = mdmIgnoreDob.get(random.nextInt(mdmIgnoreDob.size()));
        String emailAddressForAccountA = CommonUtil.generateRandomEmailId(10);
        String emailAddressForAccountB = CommonUtil.generateRandomEmailId(10);

        try {
            // create first pharmacy patient account
            DigitalPharmacyOperationsUtil accountAUtil = new DigitalPharmacyOperationsUtil(Integer.parseInt(accountAStore), firstName, lastName, dob, 0, emailAddressForAccountA, accountPassword);
            DigitalPharmacyOperationsUtil accountBUtil = new DigitalPharmacyOperationsUtil(Integer.parseInt(accountBStore), firstName, lastName, dob, 0, emailAddressForAccountB, accountPassword);

            CompletableFuture<PatientInfo> accountBPatientDataCompletableFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    accountBUtil.createDigitalPharmacyConnectedStorePatientAccount(false, false);
                    // add rx to the second account to create a conflict for import rx
                    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
                    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
                    String rxNumber = wrapperAPIManager.createOrderAndMoveTo4Pt(accountBUtil.getPatientId(), Integer.parseInt(accountBStore), 5, ndcNumber).get(0);
                    return PatientInfo.builder().emailId(emailAddressForAccountB).patientId(String.valueOf(accountBUtil.getPatientId())).storeNbr(accountBStore).rxNbr(String.valueOf(rxNumber)).build();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });

            // create second pharmacy patient account with the same data as first pharmacy patient account
            /* do not use createDigitalPharmacyConnectedStorePatientAccount method as it is creating pharmacy account using ISAC flow for dev environment.
             if account is created using above method, while loading dashboard PharmacyProfileStatusV2 api is sending twoFASetUpStatus: "INACTIVE" in the response
             only apps consume this flag and show reset pin screen so instead use testAccountCreation method to create pharmacy account using SMS verification flow  */
            accountAUtil.testAccountCreation(accountAUtil.getDotComEmail(), accountAUtil.getPatientFirstName(), accountAUtil.getPatientLastName(), accountAUtil.getPatientDob(), accountAStore, false, false);
            accountAUtil.createPharmacyPin();
            PatientInfo accountAPatientInfo = PatientInfo.builder().emailId(emailAddressForAccountA).patientId(String.valueOf(accountAUtil.getPatientId())).storeNbr(accountAStore).build();

            // wait for the second account to complete and get the patient info
            PatientInfo accountBPatientInfo = accountBPatientDataCompletableFuture.join();


            return Arrays.asList(accountAPatientInfo, accountBPatientInfo);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Generates two patient profiles: one linked to Pharamcy account and one unlinked, with the same demographic data,
     * for under-linking Import Rx scenarios.
     *
     * @param linkedPatientAStore   Store number for the linked patient
     * @param unlinkedPatientBStore Store number for the unlinked patient
     * @return List containing PatientInfo for both patients
     */
    public List<PatientInfo> generateUnderLinkingPatient(String linkedPatientAStore, String unlinkedPatientBStore) {

        // generate random patient data based on mdmIgnore lists to avoid CPR synchronization
        Random random = new Random();
        String firstName = mdmIgnoreNames.get(random.nextInt(mdmIgnoreNames.size()));
        String lastName = mdmIgnoreNames.get(random.nextInt(mdmIgnoreNames.size()));
        String dob = mdmIgnoreDob.get(random.nextInt(mdmIgnoreDob.size()));
        String formattedDob = new DigitalPharmacyOperationsUtil().dateTimeFormatterUtil(dob).get(0);
        String emailAddressForAccountA = CommonUtil.generateRandomEmailId(10);

        try {
            CompletableFuture<PatientInfo> accountBPatientDataCompletableFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    // create unlinked patient account
                    DigitalPharmacyOperationsUtil unlinkedPatient = new DigitalPharmacyOperationsUtil();
                    unlinkedPatient.generatePatient(Integer.parseInt(unlinkedPatientBStore), firstName, lastName, "/Date(" + formattedDob + ")/", false, "M", false);

                    // Drop off Rx
                    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
                    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
                    String rxNumber = wrapperAPIManager.createOrderAndMoveTo4Pt(unlinkedPatient.getPatientId(), Integer.parseInt(unlinkedPatientBStore), 5, ndcNumber).get(0);
                    return PatientInfo.builder().emailId("").patientId(String.valueOf(unlinkedPatient.getPatientId())).storeNbr(unlinkedPatientBStore).rxNbr(String.valueOf(rxNumber)).build();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });

            // create linked patient account with the same data as the unlinked patient
            DigitalPharmacyOperationsUtil linkedPatient = new DigitalPharmacyOperationsUtil(Integer.parseInt(linkedPatientAStore), firstName, lastName, dob, 0, emailAddressForAccountA, accountPassword);
            /* do not use createDigitalPharmacyConnectedStorePatientAccount method as it is creating pharmacy account using ISAC flow for dev environment.
             if account is created using above method, while loading dashboard PharmacyProfileStatusV2 api is sending twoFASetUpStatus: "INACTIVE" in the response
             only apps consume this flag and show reset pin screen so instead use testAccountCreation method to create pharmacy account using SMS verification flow  */
            linkedPatient.testAccountCreation(linkedPatient.getDotComEmail(), linkedPatient.getPatientFirstName(), linkedPatient.getPatientLastName(), linkedPatient.getPatientDob(), linkedPatientAStore, false, false);
            linkedPatient.createPharmacyPin();
            PatientInfo accountAPatientInfo = PatientInfo.builder().emailId(emailAddressForAccountA).patientId(String.valueOf(linkedPatient.getPatientId())).storeNbr(linkedPatientAStore).rxNbr("").build();

            // wait for the second account to complete and get the patient and Rx info
            PatientInfo accountBPatientInfo = accountBPatientDataCompletableFuture.join();

            // return the list of patient info for both accounts
            return Arrays.asList(accountAPatientInfo, accountBPatientInfo);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Generates two profiles for the Import Rx happy path: a caregiver ( with virtual store) and a store patient with Rx.
     *
     * @param pharmacyStore Store number for the store patient
     * @return List containing PatientInfo for the caregiver and the store patient
     */
    public List<PatientInfo> generateProfilesForImportRxHappyPath(String pharmacyStore) {

        // Caregiver Creation
        StringUtils stringUtils = new StringUtils();
        String caregiverFirstName = stringUtils.firstNameGenerator();
        String caregiverLastName = stringUtils.lastNameGenerator();
        String storePatientFirstName = caregiverFirstName + "junior"; // store patient first name should be different than CPR patient first name
        String caregiverDotcomEmail = caregiverFirstName.toLowerCase() + caregiverLastName.toLowerCase() + "@email.com";
        String dob = "01011998";
        String formattedDob = new DigitalPharmacyOperationsUtil().dateTimeFormatterUtil(dob).get(0);

        try {
            CompletableFuture<PatientInfo> storeProfilePatientDataCompletableFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    // create unlinked patient account
                    DigitalPharmacyOperationsUtil unlinkedPatient = new DigitalPharmacyOperationsUtil();
                    unlinkedPatient.generatePatient(Integer.parseInt(pharmacyStore), storePatientFirstName, caregiverLastName, "/Date(" + formattedDob + ")/", false, "M", false);

                    // Drop off Rx
                    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
                    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
                    String rxNumber = wrapperAPIManager.createOrderAndMoveTo4Pt(unlinkedPatient.getPatientId(), Integer.parseInt(pharmacyStore), 5, ndcNumber).get(0);
                    return PatientInfo.builder().emailId("").patientId(String.valueOf(unlinkedPatient.getPatientId())).storeNbr(pharmacyStore).rxNbr(String.valueOf(rxNumber)).build();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });


            // create pharmacy account using virtual store 9928
            DigitalPharmacyOperationsUtil caregiverUtilObject = new DigitalPharmacyOperationsUtil(9928, caregiverFirstName, caregiverLastName, dob, 0, caregiverDotcomEmail, accountPassword);
            caregiverUtilObject.createPharmacyAccountForVirtualStore(accountPassword);
            PatientInfo virtualStoreAccountPatientInfo = PatientInfo.builder().emailId(caregiverDotcomEmail).patientId(String.valueOf(caregiverUtilObject.getPatientId())).storeNbr("9928").rxNbr("").build();

            // wait for the second account to complete and get the patient and Rx info
            PatientInfo pharmacyStorePatientInfo = storeProfilePatientDataCompletableFuture.join();

            // return the patient info
            return Arrays.asList(virtualStoreAccountPatientInfo, pharmacyStorePatientInfo);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
