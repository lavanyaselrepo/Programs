/**
 * BasePageApplicationManager is the crux of the common automation framework where we have common methods of the implementation of interactions with the platforms.
 * Every PageManager inherits BasePageApplicationManager.
 * This base page application manager is for Digital Pharmacy. Create a new base page application manager for any other Project.
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */

package com.walmart.hwqe.digitalPharmacyuicontext.pageManagers;

import com.google.gson.Gson;

import com.walmart.hwqe.commoncontext.utils.TextValidationUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.ExpectedRfpCard;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.utils.OrderTrackerUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.Filling;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.ReadyForPickup;
import com.walmart.hwqe.commons.serviceapi.locationServicesContext.utils.LocationServiceUtils;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.digitalPharmacyuicontext.constants.CommonConstants;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.*;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails.FillDetails;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard.*;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions.*;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails.PrescriptionDetailsPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails.StoreDetailsPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.forms.EcommAuthConsentFormPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.forms.MedicaidConsentFormPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx.FindOrTransferOptionSelectionPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx.FindPrescriptionsPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx.ImportRxProfileSelectionPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.manageFamily.AddFamilyMemberPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.manageFamily.ManageFamilyPage;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.SMSFamilyAdditionPage;
import com.walmart.hwqe.commoncontext.models.datamodels.StoreConfig;
import com.walmart.hwqe.commoncontext.constants.DeliveryStatus;
import com.walmart.hwqe.commoncontext.constants.FillStatusInfo;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.EnterPrescriptionDetailsPage;
import com.walmart.hwqe.commoncontext.utils.Poller;

import com.azure.cosmos.implementation.apachecommons.math.util.Pair;
import org.json.JSONObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.walmart.hwqe.digitalPharmacyuicontext.constants.FillStatusInfo.*;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

public class BasePageApplicationManager {
    CommonUtils commonUtils;
    TextValidationUtils textValidationUtils;
    String translations;
    AutomationManager am;
    protected PropertyReader prop = PropertyReaderHelper.getInstance();
    public SignInPage signInPage;
    public HomePage homePage;
    public PharmacyDashboardPage pharmacyDashboardPage;
    public RefillPrescriptionPage refillPrescriptionPage;
    public RefillChangeCoveragePage refillChangeCoveragePage;
    public ReviewOrderPage reviewOrderPage;
    public TransferRxPage transferRxPage;
    public TransferPharmacyDetailsPage transferPharmacyDetailsPage;
    public SelectStorePage selectStorePage;
    public ReviewTransferPage reviewTransferPage;
    public TransferRxConfirmationPage transferRxConfirmationPage;
    public ScanToRefillPage scanToRefillPage;
    public ContinueAsGuestPage continueAsGuestPage;

    public RemoteWebDriver remoteWebDriver;
    public PinCreationPages pinCreationPages;
    public ConnectMyAccountSuccessScreen connectMyAccountSuccessScreen;
    public ConnectMyAccount connectMyAccount;
    public PharmacyAccountSettingsPage pharmacyAccountSettingsPage;
    public PersonalInformationPage personalInformationPage;
    public ManagePermissionsPage managePermissionsPage;
    public ManageInsurancePage manageInsurancePage;
    public MedicaidConsentFormPage medicaidConsentFormPage;
    public EcommCartPage ecommCartPage;
    public FillStatusTrackerCardPage fillStatusTrackerCardPage;
    public RxReadyForRefillCardPage rxReadyForRefillCardPage;
    public RxFillDelayedStatusTrackerCard rxFillDelayedStatusTrackerCard;
    public RxInFillingCardPage rxInFillingCardPage;
    public RxReadyForPickupAndDeliveryTrackerCardPage rxReadyForPickupAndDeliveryTrackerCardPage;
    public PrescriptionDetailsPage prescriptionDetailsPage;
    public StoreDetailsPage storeDetailsPage;
    public ManageFamilyPage manageFamilyPage;
    public AddFamilyMemberPage addFamilyMemberPage;
    public FillDetails fillDetails;
    public Gson gson;
    private String platform;
    public OrderCheckoutPage orderCheckoutPage;
    public PrescriptionHolderDetailsFormPage prescriptionHolderDetailsFormPage;
    public SelectSourceStorePage selectSourceStorePage;
    public SelectDestinationStorePage selectDestinationStorePage;
    public InputTransferRxDetailsPage inputTransferRxDetailsPage;
    public PrescriptionsToTransferDetailsPage prescriptionsToTransferDetailsPage;
    public ReviewTransferRequestPage reviewTransferRequestPage;
    public TransferRequestSuccessPage transferRequestSuccessPage;
    public CompetitiveTransferTrackerCardPage competitiveTransferTrackerCardPage;
    public OrderConfirmationPage orderConfirmationPage;
    public PurchaseHistoryPage purchaseHistoryPage;
    public PrescriptionHistoryPage prescriptionHistoryPage;
    private LocationServiceUtils locationServiceUtils = new LocationServiceUtils();
    public GetTransferStartedPage getTransferStartedPage;
    public StoreConfig storeConfig;
    public OrderDetailsPage orderDetailsPage;
    public EcommAuthConsentFormPage ecommAuthConsentFormPage;
    public ManageFamilyMembersPage manageFamilyMembersPage;
    public SMSFamilyAdditionPage smsFamilyAdditionPage;
    public DigitalPharmacyAPIManager digitalPharmacyAPIManager;
    public Poller poller;
    public FindOrTransferOptionSelectionPage findOrTransferOptionSelectionPage;
    public ImportRxProfileSelectionPage importRxProfileSelectionPage;
    public FindPrescriptionsPage findPrescriptionsPage;
    public EnterPrescriptionDetailsPage enterPrescriptionDetailsPage;
    public VaccineSchedulePage vaccineSchedulePage;
    public DebugMenuPage debugMenuPage;
    public CommunicationsPage communicationsPage;
    public TextNotificationsEnrollmentPage textNotificationsEnrollmentPage;

    public BasePageApplicationManager() {}

    public BasePageApplicationManager(RemoteWebDriver driver, String platform) {
        am = AutomationManager.getInstance();
        commonUtils = new CommonUtils();
        textValidationUtils = new TextValidationUtils(platform);
        signInPage = new SignInPage(driver);
        homePage = new HomePage(driver);
        pharmacyDashboardPage = new PharmacyDashboardPage(driver);
        refillPrescriptionPage = new RefillPrescriptionPage(driver);
        refillChangeCoveragePage = new RefillChangeCoveragePage(driver);
        reviewOrderPage = new ReviewOrderPage(driver);
        transferRxPage = new TransferRxPage(driver);
        transferPharmacyDetailsPage = new TransferPharmacyDetailsPage(driver);
        selectStorePage = new SelectStorePage(driver);
        reviewTransferPage = new ReviewTransferPage(driver);
        transferRxConfirmationPage = new TransferRxConfirmationPage(driver);
        continueAsGuestPage = new ContinueAsGuestPage(driver);
        scanToRefillPage = new ScanToRefillPage(driver);
        pinCreationPages = new PinCreationPages(driver);
        fillStatusTrackerCardPage = new FillStatusTrackerCardPage(driver);
        rxReadyForRefillCardPage = new RxReadyForRefillCardPage(driver);
        rxFillDelayedStatusTrackerCard = new RxFillDelayedStatusTrackerCard(driver);
        rxInFillingCardPage = new RxInFillingCardPage(driver);
        rxReadyForPickupAndDeliveryTrackerCardPage = new RxReadyForPickupAndDeliveryTrackerCardPage(driver);
        prescriptionDetailsPage = new PrescriptionDetailsPage(driver);
        storeDetailsPage = new StoreDetailsPage(driver);
        medicaidConsentFormPage = new MedicaidConsentFormPage(driver);
        connectMyAccount = new ConnectMyAccount(driver);
        connectMyAccountSuccessScreen = new ConnectMyAccountSuccessScreen(driver);
        pharmacyAccountSettingsPage = new PharmacyAccountSettingsPage(driver);
        personalInformationPage = new PersonalInformationPage(driver);
        managePermissionsPage = new ManagePermissionsPage(driver);
        manageInsurancePage = new ManageInsurancePage(driver);
        ecommCartPage = new EcommCartPage(driver);
        manageFamilyPage = new ManageFamilyPage(driver);
        addFamilyMemberPage = new AddFamilyMemberPage(driver);
        orderCheckoutPage = new OrderCheckoutPage(driver);
        getTransferStartedPage = new GetTransferStartedPage(driver);
        prescriptionHolderDetailsFormPage = new PrescriptionHolderDetailsFormPage(driver);
        selectSourceStorePage = new SelectSourceStorePage(driver);
        selectDestinationStorePage = new SelectDestinationStorePage(driver);
        inputTransferRxDetailsPage = new InputTransferRxDetailsPage(driver);
        prescriptionsToTransferDetailsPage = new PrescriptionsToTransferDetailsPage(driver);
        reviewTransferRequestPage = new ReviewTransferRequestPage(driver);
        transferRequestSuccessPage = new TransferRequestSuccessPage(driver);
        competitiveTransferTrackerCardPage = new CompetitiveTransferTrackerCardPage(driver);
        purchaseHistoryPage = new PurchaseHistoryPage(driver);
        prescriptionHistoryPage = new PrescriptionHistoryPage(driver);
        orderConfirmationPage = new OrderConfirmationPage(driver);
        orderDetailsPage = new OrderDetailsPage(driver);
        ecommAuthConsentFormPage = new EcommAuthConsentFormPage(driver);
        gson = new Gson();
        manageFamilyMembersPage = new ManageFamilyMembersPage(driver);
        smsFamilyAdditionPage = new SMSFamilyAdditionPage(driver);
        digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        poller = new Poller();
        vaccineSchedulePage = new VaccineSchedulePage(driver);
        findOrTransferOptionSelectionPage = new FindOrTransferOptionSelectionPage(driver);
        importRxProfileSelectionPage = new ImportRxProfileSelectionPage(driver);
        findPrescriptionsPage = new FindPrescriptionsPage(driver);
        enterPrescriptionDetailsPage = new EnterPrescriptionDetailsPage(driver);
        debugMenuPage = new DebugMenuPage(driver);
        communicationsPage = new CommunicationsPage(driver);
        textNotificationsEnrollmentPage = new TextNotificationsEnrollmentPage(driver);
        setPlatform(platform);
    }

    public void doSignIn() {

        signInPage.clickSignInButton();
        signInPage.enterEmail("salonisharmatest@walmart.com");
        signInPage.clickContinueButton();
        signInPage.enterPassword("Walmart1234");
        signInPage.clickContinueSignInButton();
    }

    public void doSignIn(String email, String password, String phone) {
    }

    public void waitForAppToLoad() {
        Reporter.log("Waiting for app to load and sign-in screen to appear...");
        am.performSleep(5);
    }

    public void doSignInSkipOnBoardingAndStepUp(String email, String password) {
        // override in platform manager classes
    }

    public void configureDebugSettings() {
        // override in platform manager classes
    }

    public void configureDebugSettingsSkipOnboarding() {
        // override in platform manager classes
    }

    public void doSignInSkipOnBoardingAndStepUpFromPharmacyDashboard(String email, String password) {
        // override in platform manager classes
    }

    public void doSignIn(String email, String password) {
        pharmacyDashboardPage.acceptAlertIfPresent();
        signInPage.clickSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.navigateBack();
        signInPage.clickContinueSignInButton();
        try {
            if (signInPage.isStepUpHeaderDisplayed()) {
                if (signInPage.isStepUpEnabled()) {
                    Reporter.log("Clicking on Email Option for OTP");
                    signInPage.clickSendOtpOnEmailRadioButton();
                } else {
                    Reporter.log("Only Email Option was Available");
                }
                DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
                signInPage.clickSendcode();
                am.performSleep(4);
                String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
                signInPage.enterInputOtpValue(otp);
                signInPage.clickSignInButtonForStepUp();
            } else {
                Reporter.log("SteupDisabled");
            }
        } catch (Exception e) {
            Reporter.log("failed in Stepup flow");
            e.printStackTrace();
        }
        Reporter.log("Signed-In to walmart dotcom account");
        pharmacyDashboardPage.refreshPage();
    }

    public void doSignInForGuestRefill(String email, String password) {
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickOnEnterPasswordRadioBtn();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
            signInPage.clickSendcode();
            // Takes time between sending otp and astro API to receive it
            am.performSleep(3);
            DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
            String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
            signInPage.enterInputOtpValue(otp);
            signInPage.clickSignInButtonForStepUp();
            am.performSleep(3);
        }
    }

    public void addFamilyUsingPhoneNoLookup(String phoneNumber,String emailForPin) {

    }

    public void dismissNotifications() {
    }

    public void dismissAllBottomSheets() {
    }

    public void continueShoppingPersonalisation() {
    }

    public void fillZipCodeDetails() {
        /*signInPage.clickEnterZipCodeLink();
        signInPage.enterZipCode("72719");
        signInPage.clickSearchZipCodeButton();*/
    }

    public void denyPersonalisation() {
        homePage.clickPersonalisationChoiceButton();
    }

    public void closeWalmartPlusProgramButton() {
        homePage.clickWalmartPlusProgramButton();
    }

    public void closeJoinOneProgram() {
    }

    public void closeSparkyPopUp() {
    }

    public void clickServicesTab() {
        homePage.clickServicesButton();
    }

    public void closeAllCampaignPopups() {
    }

    public void proceedToPharmacyDashboard() {
        pharmacyDashboardPage.clickPharmacyServicesButton();
        pharmacyDashboardPage.enterPin();
    }

    public void proceedToPharmacyDashboardWithATCEnabled() {
    }

    public void proceedToPharmacyDashboardAndCloseBottomSheets() {
    }

    public void proceedToPharmacyDashboardAndCloseBottomSheetsWithoutPin() {
    }

    public void handlePharmacyPinValidation(String pin) {
    }

    public void closeDeliveryAvailablePopup() {
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
        Reporter.log("Closed RX delivery available notification");
    }

    public void updateCartCountToZero() {
    }

    public void addRxToCartValidationForC2() {

    }

    public void addRxToCart() {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickAddToCart();
        Reporter.log("Click addToCart CTA for prescription which is ready for pickup");
    }

    public int getAddToCartCount() {
        return rxReadyForPickupAndDeliveryTrackerCardPage.getAddToCartCount();
    }

    public void logScreenShot(String header) {
        Reporter.logScreenShot(header, ecommCartPage.captureScreenShot());
    }

    public void verifyMaxOneQuantity() {
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isMax1TextVisible(), "Max 1 text is not visible");
        Reporter.log("Assert: Max 1 quantity text is visible.");
    }

    public void dismissUnableToAtcFailureBottomSheet() {
        pharmacyDashboardPage.dismissUnableToAtcFailureBottomSheet();
    }

    public boolean verifyCartCount(int expectedCount) {
        return true;
    }

    public void refreshpage() {
    }

    public void addGroceryItemToCart(String item) {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickGlobalSearch();
        Reporter.log("Navigated to ecomm search page");
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSearch();
        rxReadyForPickupAndDeliveryTrackerCardPage.enterGroceryItems(item);
        Reporter.log("Entered Non-RX item in search and clicked enter");
        rxReadyForPickupAndDeliveryTrackerCardPage.clickGotItButton();
        Reporter.log("Accepted similar products notification");
        rxReadyForPickupAndDeliveryTrackerCardPage.waitForLoadingToDisappear(15);
        rxReadyForPickupAndDeliveryTrackerCardPage.clickAddCartButtonForNonRxItem();
        Reporter.log("Click addToCart CTA for non-RX item");
    }

    public void openToEcommCart() {
        pharmacyDashboardPage.proceedToEcommCart();
        Reporter.log("Navigated to ecomm cart page");
    }

    public void selectFirstSlotForDelivery() {
        pharmacyDashboardPage.selectSlot();
    }

    public void scrollToSingleRFRCard() {
    }

    public void proceedToPharmacyDashboardAndGenerateOTP() {
        pharmacyDashboardPage.clickPharmacyServicesButton();
        //clickResetPinContinueButton, enterOTPEmail, clickVerifyCodeButton, setPin, clickConfirmPinButton,
        // setPin, clickConfirmPinButtonm, clickConfirmPinButton
        pinCreationPages.clickResetPinContinueButton();
    }

    public void enterOTPAndCreatePin(String otp) {
        pinCreationPages.enterOTPEmail(otp);
        pinCreationPages.clickVerifyCodeButton();
        pinCreationPages.setPin();
        pinCreationPages.clickConfirmPinButton();
        pinCreationPages.setPin();
        pinCreationPages.clickConfirmPinButton();
        pinCreationPages.clickConfirmPinButton();
        pharmacyDashboardPage.denyBiometricsPermissionButton();
    }

    public void changeDeliveryToPickupFirstSlot() {
    }

    public void verifyCurbSidePickupNotAvailableTxt() {
    }

    public void clearCartAndNavigateToPharmacyDashboardPage() {
    }

    public void verifyRxAmendmentAndRemoveProducts() {
    }

    public void clearCart() {
    }

    public void verifySaveForLaterLinkForRx() {
    }

    public void verifyRxImagesCount(int maxExpectedCount) {
    }

    public void verifyRecommendationProductsGroupVisible(boolean isRx) {
    }

    public void navigateToPharmacyDashboardPage() {
    }

    public void navigateToOrdersPage() {
    }

    public void proceedToMyPrescriptionsSection() {
        pharmacyDashboardPage.clickMyPrescriptionsTab();
    }

    public void proceedToManageInsuranceSection() {
        pharmacyDashboardPage.clickManageInsuranceTab();
    }

    public void addInsuranceWithoutBOM(String memberId, String bin, String pcn) {
        manageInsurancePage.addInsuranceWithoutBOM(memberId, bin, pcn);
        Assert.assertEquals(manageInsurancePage.getInsuranceAddedSuccessMessage().toLowerCase(), ("Insurance has been added").toLowerCase(), "Add insurance success Text is incorrect");
        manageInsurancePage.goBackToManageMyInsurancePage();
    }

    public void addInsuranceWithoutBOM_Dependent(String memberId, String bin, String pcn) {
        manageInsurancePage.addInsuranceWithoutBOM_Dependent(memberId, bin, pcn);
        Assert.assertEquals(manageInsurancePage.getInsuranceAddedSuccessMessage().toLowerCase(), ("Insurance has been added").toLowerCase(), "Add insurance success Text is incorrect");
        manageInsurancePage.goBackToManageMyInsurancePage();
    }

    public void addInsuranceWithBOM() {
        manageInsurancePage.addInsuranceWithBOM();
        Assert.assertEquals(manageInsurancePage.getInsuranceAddedSuccessMessage().toLowerCase(), ("Insurance has been added").toLowerCase(), "Add insurance success Text is incorrect");
        manageInsurancePage.goBackToManageMyInsurancePage();
    }

    public void addInsuranceWithBOM_Dependent() {
        manageInsurancePage.addInsuranceWithBOM_Dependent();
        Assert.assertEquals(manageInsurancePage.getInsuranceAddedSuccessMessage().toLowerCase(), ("Insurance has been added").toLowerCase(), "Add insurance success Text is incorrect");
        manageInsurancePage.goBackToManageMyInsurancePage();
    }

    public void addInsuranceWithoutPCN(String memberId, String bin) {
        manageInsurancePage.addInsuranceWithoutPCN(memberId, bin);
    }

    public void addInsuranceFromNudgeScreen(String memberId, String bin, String pcn) {
        manageInsurancePage.addInsuranceFromNudgeScreen(memberId, bin, pcn);
    }

    public void addInsuranceFromInsuranceHub(String memberId, String bin, String pcn) {
        manageInsurancePage.addInsuranceWithoutBOM(memberId, bin, pcn);
    }

    public void verifyInsuranceNudgeNotVisible() {
    }

    public void navigateBackToPharmacyDashboard() {
        pharmacyDashboardPage.navigateBack();
    }

    public void verifyInsuranceNudgeVisible() {
        Assert.assertTrue(pharmacyDashboardPage.isInsuranceNudgeCTADisplayed(), "Insurance nudge should be visible on Pharmacy Dashboard after removing insurance");
    }

    public void removeInsurance() {
       manageInsurancePage.removeInsurance();
       manageInsurancePage.waitForLoadingToDisappear();
    }

    public void hitBackButton(){}

    public void navigateToManageMyFamilyPage() {
    }

    public void verifyMyAccountInManageMyFamilyPage(String patientName, String patientDob, int prescriptionsCount) {
    }

    public void addFamilyDetails(boolean isAdultPatient, boolean isPet, String firstName, String lastName, String dob, String emailAddress, String prescriptionNumber, String storeNumber) {
    }

    public String getTextFromPatientContainer(String expectedPatientName) {
        return null;
    }

    public void proceedToTransferPrescriptionSection() {
        pharmacyDashboardPage.clickTransferPrescriptionsTab();
        pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
        pharmacyDashboardPage.clickTransferSourceContinueButton();
    }

    public void fillLocationDetailsUsingPreciseLocation() {
    }

    public void selectAnActivePrescription() {

        refillPrescriptionPage.clickSortAndFilterButton();
        refillPrescriptionPage.applyActivePrescriptionsFilter();
        refillPrescriptionPage.applySelectedFilter();
        refillPrescriptionPage.selectFirstActivePrescription();
        refillPrescriptionPage.clickContinueRefillButton();
    }

    /**
     * Applies the Active Prescriptions filter, selects the first Rx, and clicks Continue.
     * Returns the drug name read from the row so the caller can assert on the fill tracker
     * card without needing it in test data.
     */
    public Pair<String, String> selectAnActivePrescriptionAndGetDrugName() {
        refillPrescriptionPage.clickSortAndFilterButton();
        refillPrescriptionPage.applyActivePrescriptionsFilter();
        refillPrescriptionPage.applySelectedFilter();
        String drugName = refillPrescriptionPage.getFirstActivePrescriptionName();
        String price = refillPrescriptionPage.getFirstPrescriptionLastPaidPrice();
        Reporter.log("First active prescription selected: " + drugName + " | Last paid price: " + price);
        refillPrescriptionPage.selectFirstActivePrescription();
        refillPrescriptionPage.clickContinueRefillButton();
        return Pair.create(drugName, price);
    }

    public void selectFamilyMember(String familyMemberName) {
        refillPrescriptionPage.clickMyFamilyButton();
        refillPrescriptionPage.selectFamilyMember(familyMemberName);
        refillPrescriptionPage.applySelectedFilter();
    }

    /**
     * Opens Sort &amp; Filter, applies the Active Prescriptions filter scoped to the
     * given family member, selects the first available Rx checkbox and returns the
     * drug name. Does NOT click Continue — caller is responsible for that.
     */
    public Pair<String, String> selectDependentActivePrescriptionAndGetDrugName(String dependentName) {
        refillPrescriptionPage.clickMyFamilyButton();
        refillPrescriptionPage.selectFamilyMember(dependentName);
        refillPrescriptionPage.applySelectedFilter();
        String drugName = refillPrescriptionPage.getFirstActivePrescriptionName();
        String price = refillPrescriptionPage.getFirstPrescriptionLastPaidPrice();
        Reporter.log("Selected first active prescription for " + dependentName + ": " + drugName + " | Last paid price: " + price);
        refillPrescriptionPage.selectFirstActivePrescription();
        return Pair.create(drugName, price);
    }

    /**
     * Opens Sort &amp; Filter, clicks Reset all to clear any previous patient/status
     * filters, then applies the Active Prescriptions filter scoped to the given
     * family member, selects the first available Rx checkbox, clicks Continue and
     * returns the drug name.
     */
    public Pair<String, String> resetFiltersAndSelectDependentActivePrescriptionAndGetDrugName(String dependentName) {
        refillPrescriptionPage.clickMyFamilyButton();
        refillPrescriptionPage.clickResetAllFilters();
        refillPrescriptionPage.selectFamilyMember(dependentName);
        refillPrescriptionPage.applySelectedFilter();
        String drugName = refillPrescriptionPage.getFirstActivePrescriptionName();
        String price = refillPrescriptionPage.getFirstPrescriptionLastPaidPrice();
        Reporter.log("Selected first active prescription for " + dependentName + " after reset: " + drugName + " | Last paid price: " + price);
        refillPrescriptionPage.selectFirstActivePrescription();
        refillPrescriptionPage.clickContinueRefillButton();
        return Pair.create(drugName, price);
    }

    public BasePageApplicationManager signInAndNavigateToPharmacyDashboardPage(String email, String password) {
        doSignIn(email, password);
        dismissNotifications();
        fillZipCodeDetails();
        continueShoppingPersonalisation();
        closeWalmartPlusProgramButton();
        clickServicesTab();
        closeJoinOneProgram();
        proceedToPharmacyDashboard();
        return this;
    }

    public void placeOrder() {
        reviewOrderPage.clickPlaceOrderButton();
    }

    public void clickDone() {

        reviewOrderPage.clickDoneButton();
    }


    public void verifyTransferRxAssertions() {

        Object value = textValidationUtils.getKeyInObject("transferRxScreen", "transferRxTitle");
//        Assert.assertEquals(transferRxPage.getTransferPrescriptionTitleText(), value, "The transfer rx title doesn't match");
    }

    public void verifyOneRxAdded() {
        Object value = textValidationUtils.getKeyInObject("ScannedPrescriptionPage", "AddMore");
        Assert.assertEquals(scanToRefillPage.getScanAnotherRxButtonText(), value, "The Prescription Wasn't Added");
    }

    public void enterTransferRxDetails() {

        transferRxPage.enterDOBText();
        transferRxPage.enterPhoneNoText();
        transferRxPage.clickContinueButton();
    }

    public void enterPharmacyToTransferDetails() {

        transferPharmacyDetailsPage.clickPharmacyNameDropDown();
        transferPharmacyDetailsPage.selectPharmacyName();
        transferPharmacyDetailsPage.enterPharmacyPhoneNo("2222222222");
        transferPharmacyDetailsPage.selectPharmacyToTransfer();
        selectStoreDetails();
        transferPharmacyDetailsPage.clickContinuePharmacyTransferButton();
    }

    public void selectStoreDetails() {

        selectStorePage.enterZipCode();
        selectStorePage.selectStoreOption();
        selectStorePage.clickSaveStoreButton();
    }

    public void transferIndividualRx() {

        transferRxPage.clickTransferIndividualRx();
        transferRxPage.enterDrugName();
        transferRxPage.clickAddRxButton();
        transferRxPage.clickContinueButton();
    }

    public void reviewTransferRequest() {

        reviewTransferPage.allowTransferredRxTobeRefilled();
        reviewTransferPage.clickSubmitRequestButton();
    }

    public void reviewTransferRxConfirmation() {

        transferRxConfirmationPage.clickDoneButton();
    }

    public void checkoutSelectedRefill() {
        //reviewOrderPage.clickPayAtStoreRadioButton();
        reviewOrderPage.clickPlaceOrderButton();
    }

    public void scanRxDetailsManually(String rxNb, String storeNb, String dob) {
        // Note: "Enter manually" button is already clicked in proceedToScanToRefill()
        // Clicking it again here causes failure as button no longer exists after first click
        // scanToRefillPage.clickEnterRxManually();
        scanToRefillPage.enterRxNumber(rxNb);
        scanToRefillPage.enterStoreNumber(storeNb);
        scanToRefillPage.enterDOB(dob);
        scanToRefillPage.clickContinueButton();
    }

    public void confirmScannedRx() {
        am.performSleep(5);
        scanToRefillPage.clickConfirmRefillContinueButton();
    }

    public void doSignInForGuest(String email, String password) {
        signInPage.enterEmail(email);
        signInPage.clickContinueButton();
        signInPage.enterPassword(password);
        signInPage.clickContinueSignInButton();
    }

    public void proceedToPharmacyDashboardForGuestUser() {
        pharmacyDashboardPage.clickPharmacyServicesButton();
    }

    public void proceedToScanToRefill() {
        pharmacyDashboardPage.clickScanToRefill();
    }

    public void proceedToScanToRefillNotConnected() {
        pharmacyDashboardPage.clickScanToRefillNotConnected();
    }

    public void continueAsGuest() {
        continueAsGuestPage.clickContinueAsGuestButton();
        continueAsGuestPage.clickEnterZipCodeLink();
        continueAsGuestPage.enterZipCode("72719");
        continueAsGuestPage.clickSearchZipCodeButton();
    }

    public void signInAdHoc(String email, String password) {
        signInPage.clickSignInButton();
        signInPage.clickCreateAccountOrSignInButton();
        signInPage.enterEmail(email);
        signInPage.clickContinueButton();
        signInPage.enterPassword(password);
        signInPage.clickContinueSignInButton();
    }

    public void navigateToCreatePinForUser(String email, String password) {
        this.signInAdHoc(email, password);
        pinCreationPages.openPharmacyDashboard();
        pinCreationPages.clickSetupPinButton();
        pinCreationPages.clickSendCodeButton();
    }

    public void enterOtpAndSetupPin(String otp) {
        pinCreationPages.enterVerificationOTP(otp);
        pinCreationPages.clickVerifyCodeButton();
        pinCreationPages.setPin();
        pinCreationPages.clickCreatePinButton();
        pinCreationPages.setPin();
        pinCreationPages.clickConfirmPinButton();
        pinCreationPages.clickPinSuccessContinueButton();
    }

    public FillDetails getFillDetails() {
        fillDetails.setDrugName(prescriptionDetailsPage.getRxName());
        fillDetails.setEstimatedPrice(prescriptionDetailsPage.getRxEstimatedPrice());
        fillDetails.setPatientName(prescriptionDetailsPage.getPatientValue());
        fillDetails.setPrescriberName(prescriptionDetailsPage.getPrescriberValue());
        fillDetails.setPrescriptionDate(prescriptionDetailsPage.getRxDateValue());
        fillDetails.setInstructions(prescriptionDetailsPage.getInstructionsValue());
        fillDetails.setSupply(prescriptionDetailsPage.getSupplyValue());
        fillDetails.setQuantity(prescriptionDetailsPage.getQuantityValue());
        fillDetails.setRxNumber(prescriptionDetailsPage.getRxValue());
        return fillDetails;
    }

    public void verifySingleRxInFilling(String patientName, String drugName, String estimatedPrice, boolean isPet) {
        Object singleRxFillingHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderText");
        Object singleRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderDescriptionText");
        boolean success = rxInFillingCardPage.isFillStatusCardHeaderForFillingStatusVisible();
        if (success) {
            Assert.assertEquals(rxInFillingCardPage.getFillStatusCardHeaderText(1, singleRxFillingHeaderText.toString()), singleRxFillingHeaderText, "Card Header is Incorrect");
            Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), singleRxFillingCardHeaderDescriptionText, "Fill status card sub header text is not visible");
            Assert.assertEquals(rxInFillingCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");
            Assert.assertEquals(rxInFillingCardPage.getRxName().toUpperCase().replaceAll(" ", ""), drugName.toUpperCase().replaceAll(" ", ""), "Drug Name is incorrect");
            Assert.assertEquals(rxInFillingCardPage.getPrescriptionsCount(), rxInFillingCardPage.prescriptionCountTxt(1));
            Assert.assertTrue(rxInFillingCardPage.getEstimatedPrice().contains(estimatedPrice), "Price is incorrect");
            Assert.assertTrue(rxInFillingCardPage.isFillDetailsArrowCTAVisible(), "Chevron icon not visible in Rx row");
            if (isPet) Assert.assertTrue(rxInFillingCardPage.isPetIconVisible());
            logScreenShot("Single Rx in Filling Card Details");
        }
    }
    /*public void verifySingleRxInFillingSelfAndDependent(String patientName, String drugName,String estimatedPrice, boolean isPet) {
        Object singleRxFillingHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderText");
        Object singleRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderDescriptionText");
        // Assert.assertEquals(rxInFillingCardPage.getFillStatusCardHeaderText(), singleRxFillingHeaderText, "Card Header is Incorrect");
        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), singleRxFillingCardHeaderDescriptionText, "Fill status card sub header text is not visible");
        Assert.assertTrue(rxInFillingCardPage.getMultiplePatientNamesOnFillTrackerCard().contains( patientName), "Patient name is incorrect");
        assertThat("drug Name on screen does not match the backend drug name",rxInFillingCardPage.getRxName().replaceAll("\\s", "").toLowerCase(), is(drugName.replaceAll("\\s", "").toLowerCase()));
        Assert.assertEquals(rxInFillingCardPage.getRxName(), drugName, "Drug name is incorrect");
        Assert.assertEquals(rxInFillingCardPage.getPrescriptionsCount(), rxInFillingCardPage.prescriptionCountTxt(1));
        assertThat("Price is incorrect",rxInFillingCardPage.getEstimatedPrice(), containsString(estimatedPrice));
        Assert.assertTrue(rxInFillingCardPage.isFillDetailsArrowCTAVisible(), "Chevron icon not visible in Rx row");
        verifyPatientNamesForMultiRxinFilling(patientNameList);
        verifyRxNamesForMultiRxinFilling(expectedRxNames);
        verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
    }*/

    public void verifySingleRxInDelayed(String patientName, String drugName, String delayedReason, String delayedMessage) {
        Object headerText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxDelayed", "CardHeaderText");
        Object subHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxDelayed", "CardHeaderDescriptionText");
        Object prescriptionCountText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxDelayed", "prescriptionCountText");
        boolean success = rxFillDelayedStatusTrackerCard.isFillStatusCardHeaderVisible();
        if (success) {
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getFillStatusCardHeaderText(), headerText, "Card Header is Incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getFillStatusCardSubHeaderText(), subHeaderText, "Card Sub Header is Incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getPrescriptionsCount(), prescriptionCountText, "Prescriptions count is incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getRxName(), drugName, "Drug name is incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getDelayedStatusReason(), delayedReason, "Delayed reason is incorrect");
            Assert.assertEquals(rxFillDelayedStatusTrackerCard.getDelayedStatusMessage(), delayedMessage, "Delayed reason sub text is incorrect");
            this.logScreenShot(delayedMessage);
        } else {
            this.logScreenShot("Delayed card not present or timeout reached.");
        }
    }

    public void verifySingleRxReadyForRefill(String patientName, String drugName, boolean isPet) {

        Object value = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForRefill", "CardHeaderText");
        Assert.assertEquals(rxReadyForRefillCardPage.getFillStatusCardHeaderText(), value, "Card Header is Incorrect");

        Assert.assertTrue(rxReadyForRefillCardPage.isFillStatusCardSubHeaderTextVisible(), "Fill status card sub header text is not visible");
        Assert.assertEquals(rxReadyForRefillCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");

        Assert.assertEquals(rxReadyForRefillCardPage.getRxName().replaceAll("\\s", "").toLowerCase(), drugName, "Drug name is incorrect");

        if (isPet)
            Assert.assertTrue(rxReadyForRefillCardPage.isPetIconVisible(), "pet icon is not visible for a pet patient");

    }

    public void verifySingleRxReadyForPickup(String patientName, String drugName, String drugPrice, boolean isPet) {

        Object value = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForReadyForPickup", "CardHeaderText");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isDrugImageVisible(), "It's not a Drug");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getFillStatusCardHeaderText(), value, "Card Header is Incorrect");

        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");

        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxName().replaceAll("\\s+", " ").trim().toLowerCase(), drugName.replaceAll("\\s+", " ").trim().toLowerCase(), "Drug name is incorrect");

        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxEstimatedPrice(), "$" + drugPrice, "Drug price is incorrect");

        if (isPet)
            Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isPetPatientIconVisible(), "pet icon is not visible for a pet patient");
    }

    // -------------------------------------------------------------------------
    // RFP card verification — API-driven scroll-and-verify approach
    // -------------------------------------------------------------------------

    /**
     * Scrolls the Pharmacy Dashboard top-to-bottom and verifies every RFP card against the
     * caller-supplied expected list (built from the Fill Summary API response).
     *
     * <p>Instead of reading card data from the DOM — which is unreliable due to Android
     * RecyclerView virtualisation — this method receives a pre-sorted expected dataset and
     * asserts each element is visible at the correct scroll position.</p>
     *
     * <p>Verification includes:</p>
     * <ul>
     *   <li>Each store card header matches the translation string:
     *       {@code "Your prescription is ready"} (1 fill) or
     *       {@code "Your prescriptions are ready"} (multiple fills), sourced from
     *       {@code translations*.json} via {@code textValidationUtils}.</li>
     *   <li>Every expected drug name (UI-normalised from the raw API value) is visible in
     *       the correct DOM position.</li>
     *   <li>Every expected patient name (Title-Case-normalised) is visible alongside its drug.</li>
     *   <li>Elements appear in the expected top-to-bottom order: cards sorted by store name,
     *       fills ordered caregiver-first then dependents alphabetically then drug-name-alpha.</li>
     *   <li>Total verified fill count matches the API total.</li>
     * </ul>
     *
     * @param expectedCards pre-built, pre-sorted list of expected cards from the API;
     *                      each entry holds the store name, store id, and ordered fills
     *                      ({@code [displayPatientName, displayDrugName]} pairs)
     */
    public void verifyRfpCardsDisplayedInOrder(List<ExpectedRfpCard> expectedCards) {
        int totalExpectedFills = expectedCards.stream()
                .mapToInt(OrderTrackerUtils::getFillCount)
                .sum();
        Reporter.log("=== Verifying " + expectedCards.size() + " RFP card(s) with "
                + totalExpectedFills + " total fill(s) from API ===");

        int totalVerifiedFills = 0;

        for (int cardIdx = 0; cardIdx < expectedCards.size(); cardIdx++) {
            ExpectedRfpCard expected = expectedCards.get(cardIdx);
            int fillCount = OrderTrackerUtils.getFillCount(expected);
            String expectedHeader = fillCount == 1
                    ? textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForReadyForPickup", "CardHeaderText").toString()
                    : fillCount + textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxReadyForPickup", "CardHeaderText").toString();

            Reporter.log("--- Card " + cardIdx + " | Store: " + expected.getStoreName()
                    + " (#" + expected.getStoreId() + ") | Expected: " + expectedHeader + " ---");

            // Scroll to the card header and assert it is on screen
            org.openqa.selenium.WebElement headerEl = scrollDownToText(expectedHeader);
            Assert.assertNotNull(headerEl,
                    "Card " + cardIdx + ": header '" + expectedHeader + "' not found in UI after scrolling");
            Reporter.log("ASSERT: Card " + cardIdx + " header '" + expectedHeader + "' verified");

            // For each expected fill (in API-defined order): scroll to drug, assert drug + patient visible
            for (int fillIdx = 0; fillIdx < expected.getFills().size(); fillIdx++) {
                String[] fill       = expected.getFills().get(fillIdx);
                String patientName  = fill[0];
                String drugName     = fill[1];

                org.openqa.selenium.WebElement drugEl = scrollDownToText(drugName);
                Assert.assertNotNull(drugEl,
                        "Card " + cardIdx + ", fill " + fillIdx + ": drug '" + drugName + "' not found in UI");

                boolean patientVisible = isRfpPatientVisible(patientName);
                Assert.assertTrue(patientVisible,
                        "Card " + cardIdx + ", fill " + fillIdx + ": patient '" + patientName
                                + "' not visible alongside drug '" + drugName + "'");

                Reporter.log("ASSERT: fill " + fillIdx + " — '" + drugName + "' for '" + patientName + "' verified");
                totalVerifiedFills++;
            }
        }

        Assert.assertEquals(totalVerifiedFills, totalExpectedFills,
                "Total verified fills (" + totalVerifiedFills + ") does not match API count (" + totalExpectedFills + ")");
        Reporter.log("ASSERT: All " + totalVerifiedFills + " fill(s) from API verified in UI");
    }

    /**
     * Scrolls to the given RFP row, opens See details, asserts dashboard row price vs the details price line once,
     * then {@link #verifyPrescriptionDetailsPage} (labels + value fields: one read
     * and one assertion per prescription-details value locator; Rx# vs API when provided).
     */
    public void selectRFPCardSeeDetailsAndVerifyPrescriptionDetails(ReadyForPickup apiFill,
                                                                    ExpectedRfpCard card,
                                                                    String patientDisplay,
                                                                    String drugDisplay) {
        WebElement drugEl = scrollDownToText(drugDisplay);
        Assert.assertNotNull(drugEl, "Drug not found on dashboard after scroll: '" + drugDisplay + "'");

        String[] dashboardCardDetails = rxReadyForPickupAndDeliveryTrackerCardPage
                .getPatientDrugPriceAndClickSeeDetailsForRow(patientDisplay, drugDisplay);
        // verifying RFP card details
        Assert.assertEquals(dashboardCardDetails[0], patientDisplay,
                "Patient read from RFP dashboardCardDetails should match ExpectedRfpCard");
        Assert.assertEquals(dashboardCardDetails[1], drugDisplay,
                "Drug read from RFP dashboardCardDetails should match ExpectedRfpCard");

        prescriptionDetailsPage.waitForLoadingToDisappear(15);

        String priceOnDetails = prescriptionDetailsPage.getRxEstimatedPrice();
        String rowPrice = dashboardCardDetails[2] == null ? "" : dashboardCardDetails[2].trim();
        String detailNorm = priceOnDetails.replaceFirst("(?i)Price:\\s*", "").trim();
        Assert.assertTrue(
                detailNorm.equals(rowPrice) || priceOnDetails.contains(rowPrice)
                        || detailNorm.endsWith(rowPrice) || rowPrice.endsWith(detailNorm),
                "Price on details should align with dashboard dashboardCardDetails — dashboardCardDetails='" + rowPrice + "', details='" + priceOnDetails + "'");

        verifyPrescriptionDetailsPage(
                dashboardCardDetails[0], dashboardCardDetails[1], apiFill.getRxNbr());

        Reporter.log("ASSERT: Prescription details verified for '" + patientDisplay + "' / '" + drugDisplay
                + "' (store " + card.getStoreId() + ") — same content checks as verifyPrescriptionDetails");
    }

    /**
     * From the Filling Tracker Card: scrolls to the given drug row, taps the chevron CTA to open
     * Prescription Details, then asserts:
     * <ol>
     *   <li>Price on the Filling card row is consistent with the price on the Prescription Details page
     *       (strip the "Est. price:" and "Price:" prefixes before comparing, and allow the "Pending" case).</li>
     *   <li>All Prescription Details page labels and value fields via {@link #verifyPrescriptionDetailsPage}
     *       (patient name, drug name, Rx# from {@code fill.getRxNbr()}, prescriber non-empty,
     *       date non-empty, quantity parseable as integer, supply non-empty, instructions non-empty).</li>
     * </ol>
     *
     * @param fill           the {@link Filling} object from the Fill Summary API that represents
     *                       the fill whose details row was tapped; used for the Rx# ({@code rxNbr})
     * @param patientDisplay the normalised patient display name as shown on the dashboard row
     * @param drugDisplay    the normalised drug display name as shown on the dashboard row
     */
    public void selectFillingCardSeeDetailsAndVerifyPrescriptionDetails(Filling fill,
                                                                        String patientDisplay,
                                                                        String drugDisplay) {
        WebElement drugEl = scrollDownToText(drugDisplay);
        Assert.assertNotNull(drugEl, "Drug '" + drugDisplay + "' not found on Filling card after scroll");

        String rowPriceFull = rxInFillingCardPage.getEstimatedPriceForDrug(drugDisplay);
        String rowPriceValue = rowPriceFull == null ? ""
                : rowPriceFull.replaceFirst("(?i)Est\\.?\\s*price:\\s*", "").trim();

        rxInFillingCardPage.clickFillDetailsArrowCTAForDrug(drugDisplay);
        prescriptionDetailsPage.waitForLoadingToDisappear(15);

        String priceOnDetails = prescriptionDetailsPage.getRxEstimatedPrice();
        String detailNorm = priceOnDetails.replaceFirst("(?i)Price:\\s*", "").trim();
        Assert.assertTrue(
                detailNorm.equals(rowPriceValue)
                        || priceOnDetails.contains(rowPriceValue)
                        || detailNorm.endsWith(rowPriceValue)
                        || rowPriceValue.endsWith(detailNorm)
                        || "Pending".equalsIgnoreCase(rowPriceValue),
                "Price on Prescription Details should align with Filling card row — row='"
                        + rowPriceValue + "', details='" + priceOnDetails + "'");

        verifyPrescriptionDetailsPage(patientDisplay, drugDisplay, fill.getRxNbr());

        Reporter.log("ASSERT: Prescription details verified for '" + patientDisplay
                + "' / '" + drugDisplay + "' — Rx# " + fill.getRxNbr());
    }

    /**
     * Prescription details must already be open. Row price vs details line must already be asserted by the caller.
     * Runs label checks, then reads each value field once and asserts once per locator (patient/drug vs row; Rx# vs
     * API when available; remaining fields non-empty).
     */
    public void verifyPrescriptionDetailsPage(String patientRow, String drugRow,
                                              String rxNbr) {
        UnaryOperator<String> tx = k -> textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "RxDetailsPage", k).toString();
        Assert.assertEquals(prescriptionDetailsPage.getPrescriptionDetailsHeader(), tx.apply("PrescriptionDetailsText"),
                "Prescription details screen title");
        Assert.assertEquals(prescriptionDetailsPage.getRxNoKey(), tx.apply("RxText"), "Rx# label");
        Assert.assertEquals(prescriptionDetailsPage.getPatientNameKey(), tx.apply("PatientText"), "Patient label");
        Assert.assertEquals(prescriptionDetailsPage.getPrescriberNameKey(), tx.apply("PrescriberText"), "Prescriber label");
        Assert.assertEquals(prescriptionDetailsPage.getRxDate(), tx.apply("PrescribedOnText"), "Prescribed on label");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityKey(), tx.apply("QuantityText"), "Quantity label");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyKey(), tx.apply("SupplyText"), "Supply label");
        Assert.assertEquals(prescriptionDetailsPage.getInstructionsKey(), tx.apply("InstructionsText"), "Instructions label");
        if (prescriptionDetailsPage.areMedicationGuideAndDrugInfoLinksPresent()) {
            Assert.assertEquals(prescriptionDetailsPage.getMedicationGuideLinkText(), tx.apply("MedicationGuideText"),
                    "Medication guide link");
            Assert.assertEquals(prescriptionDetailsPage.getDrugInfoLinkText(), tx.apply("DrugInformationText"),
                    "Drug information link");
        } else {
            Reporter.log("Medication guide / Drug information links not present on this prescription details layout — "
                    + "skipping translation asserts (e.g. RFP See details variant).");
        }

        String uiRx = prescriptionDetailsPage.getRxValue();
        String uiPatient = prescriptionDetailsPage.getPatientValue();
        String uiDrug = prescriptionDetailsPage.getRxName();
        String uiPrescriber = prescriptionDetailsPage.getPrescriberValue();
        String uiDate = prescriptionDetailsPage.getRxDateValue();
        String quantityRaw = prescriptionDetailsPage.getQuantityValue().trim();
        String uiSupply = prescriptionDetailsPage.getSupplyValue();
        String uiInstr = prescriptionDetailsPage.getInstructionsValue();

        Assert.assertEquals(uiPatient, patientRow, "Patient name is incorrect");
        Assert.assertEquals(uiDrug, drugRow, "Drug name is incorrect");
        if (rxNbr != null) Assert.assertEquals(uiRx, rxNbr, "Rx# on details should match Fill Summary API");

        Assert.assertFalse(uiPrescriber.trim().isEmpty(), "Prescriber should not be empty");
        Assert.assertFalse(uiDate.trim().isEmpty(), "Prescribed-on date should not be empty");
        Assert.assertFalse(quantityRaw.isEmpty(), "Quantity should not be empty");
        try {
            Integer.parseInt(quantityRaw);
        } catch (NumberFormatException e) {
            Assert.fail("Quantity should parse as an integer: '" + quantityRaw + "'");
        }
        Assert.assertFalse(uiSupply.trim().isEmpty(), "Supply should not be empty");
        Assert.assertFalse(uiInstr.trim().isEmpty(), "Instructions should not be empty");
    }

    /**
     * Verifies the "Rather get them in-store?" footer section on the first RFP card and the
     * Store Information bottom sheet that opens when the info (ⓘ) icon is tapped.
     *
     * <h3>Verification strategy per field</h3>
     * <ul>
     *   <li><b>"Rather get them in-store?"</b> — expected from translation key
     *       {@code SingleRxReadyForReadyForPickup.RatherGetThemInStoreText}; non-empty check,
     *       then UI asserted to equal the translation value.</li>
     *   <li><b>"Ready at the [store]"</b> — prefix from translation key
     *       {@code SingleRxReadyForReadyForPickup.ReadyAtThePrefix}; store name from
     *       {@code expectedCard.getStoreName()} (API-derived) and from store-specific
     *       translation key {@code testStoreData.store{id}.displayName}; all three
     *       asserted non-empty and mutually equal; UI label asserted on-screen.</li>
     *   <li><b>"Open until…" hours</b> — dynamic real-time value; read from UI, asserted
     *       non-empty.</li>
     *   <li><b>Sheet title "Store Information"</b> — expected from translation key
     *       {@code SingleRxReadyForReadyForPickup.StoreInfoSheetTitle}; non-empty check,
     *       UI asserted to equal translation.</li>
     *   <li><b>Store display name in sheet</b> — triple-validated: translation key ↔ API
     *       ↔ UI all equal.</li>
     *   <li><b>Store address in sheet</b> — expected from store-specific translation key
     *       {@code testStoreData.store{id}.address}; non-empty check, UI asserted to equal
     *       translation.</li>
     *   <li><b>Store phone number in sheet</b> — no source; read from UI, asserted
     *       non-empty.</li>
     * </ul>
     *
     * @param expectedCard the RFP card whose store section is currently visible on screen
     */
    public void verifyInStorePickupSectionAndStoreInfo(ExpectedRfpCard expectedCard) {
        // ---- Fetch translation values ----
        String storeKey = "store" + expectedCard.getStoreId();  // e.g. "store5517"
        java.util.function.UnaryOperator<String> rfpTx = k ->
                textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForReadyForPickup", k).toString();
        java.util.function.UnaryOperator<String> storeTx = k ->
                textValidationUtils.getKeyInObject("testStoreData", storeKey, k).toString();
        String translationRatherGetInStore = rfpTx.apply("RatherGetThemInStoreText");
        String translationReadyAtPrefix    = rfpTx.apply("ReadyAtThePrefix");
        String translationStoreInfoTitle   = rfpTx.apply("StoreInfoSheetTitle");
        String translationStoreName        = storeTx.apply("displayName");
        String translationStoreAddress     = storeTx.apply("address");
        String translationStorePhone       = storeTx.apply("phone");
        String translationStoreHours       = storeTx.apply("hoursDay") + " " + storeTx.apply("hoursTime");

        // API storeName is a short label; UI appends store number (e.g. "#5517"). Translation matches full UI text.
        String apiStoreName = expectedCard.getStoreName();
        Assert.assertFalse(apiStoreName == null || apiStoreName.isEmpty(),
                "ASSERT: API store name is null or empty");
        Assert.assertTrue(translationStoreName.contains(apiStoreName),
                "ASSERT: translation display name='" + translationStoreName
                        + "' should contain API store name='" + apiStoreName + "'");
        Reporter.log("PRE-FLIGHT: API store name='" + apiStoreName
                + "' contained in translation display name='" + translationStoreName + "'");

        // ---- Card footer: "Rather get them in-store?" ----
        // The footer sits below all prescription rows and is off-screen; scroll to it before
        // reading — XCUITest getText() fails on elements outside the visible viewport.
        scrollDownToText(translationRatherGetInStore);
        String actualRatherGetInStore = rxReadyForPickupAndDeliveryTrackerCardPage.getRatherGetThemInStoreText();
        Assert.assertEquals(actualRatherGetInStore, translationRatherGetInStore,
                "ASSERT: Card footer heading UI='" + actualRatherGetInStore
                        + "' does not match translation='" + translationRatherGetInStore + "'");
        Reporter.log("ASSERT: 'Rather get them in-store?' UI='" + actualRatherGetInStore
                + "' matches translation='" + translationRatherGetInStore + "'");

        // ---- "Ready at the [Store Name]" ----
        String expectedReadyAtText = translationReadyAtPrefix + translationStoreName;
        String actualReadyAtText = rxReadyForPickupAndDeliveryTrackerCardPage.getReadyAtStoreText();
        Assert.assertTrue(
                actualReadyAtText != null && actualReadyAtText.contains(expectedReadyAtText),
                "ASSERT: '" + expectedReadyAtText + "' label not visible on screen");
        Reporter.log("ASSERT: '" + expectedReadyAtText
                + "' visible (prefix from translation, full store label from translation)");

        // ---- "Open until…" store hours (dynamic — no API or translation source) ----
        String openUntilText = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreOpenTimeText();
        Assert.assertFalse(openUntilText == null || openUntilText.isEmpty(),
                "ASSERT: 'Open until...' store hours label is empty on card");
        Reporter.log("ASSERT: Store open hours non-empty — UI='" + openUntilText + "'");

        // ---- Info icon → Store Information bottom sheet ----
        rxReadyForPickupAndDeliveryTrackerCardPage.clickInfoCTA();
        Reporter.log("ACTION: Tapped info icon — Store Information bottom sheet opened");

        // Sheet title: translation vs UI
        String actualSheetTitle = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreInfoSheetTitleText();
        Assert.assertEquals(actualSheetTitle, translationStoreInfoTitle,
                "ASSERT: Sheet title UI='" + actualSheetTitle
                        + "' does not match translation='" + translationStoreInfoTitle + "'");
        Reporter.log("ASSERT: Sheet title UI='" + actualSheetTitle
                + "' matches translation='" + translationStoreInfoTitle + "'");

        // Store display name: translation vs UI
        String actualSheetStoreName = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreInfoDisplayName();
        Assert.assertFalse(actualSheetStoreName.isEmpty(),
                "ASSERT: Store name in sheet is empty");
        Assert.assertEquals(actualSheetStoreName, translationStoreName,
                "ASSERT: Sheet store name UI='" + actualSheetStoreName
                        + "' does not match translation='" + translationStoreName + "'");
        Reporter.log("ASSERT: Sheet store name UI='" + actualSheetStoreName
                + "' matches translation='" + translationStoreName + "'");

        // Store address: translation vs UI
        String actualSheetAddress = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreInfoAddress();
        Assert.assertFalse(actualSheetAddress.isEmpty(),
                "ASSERT: Store address in sheet is empty");
        Assert.assertEquals(actualSheetAddress, translationStoreAddress,
                "ASSERT: Sheet address UI='" + actualSheetAddress
                        + "' does not match translation='" + translationStoreAddress + "'");
        Reporter.log("ASSERT: Sheet address UI='" + actualSheetAddress
                + "' matches translation='" + translationStoreAddress + "'");

        // Store phone: normalize both to digits only before comparing — iOS renders the
        // tel link as "(479) 636-8238" while the translation stores "479-636-8238".
        String actualSheetPhone = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreInfoPhoneText();
        String actualSheetPhoneDigits      = actualSheetPhone.replaceAll("[^0-9]", "");
        String translationStorePhoneDigits = translationStorePhone.replaceAll("[^0-9]", "");
        Assert.assertEquals(actualSheetPhoneDigits, translationStorePhoneDigits,
                "ASSERT: Sheet phone UI='" + actualSheetPhone
                        + "' does not match translation='" + translationStorePhone + "'");
        Reporter.log("ASSERT: Sheet phone UI='" + actualSheetPhone
                + "' matches translation='" + translationStorePhone + "' (digits compared)");

        // Pharmacy hours: normalize before comparing — iOS accessibility expands abbreviated day
        // names ("Mon" → "Monday") and replaces the en-dash with "to" ("–" → "to"), producing
        // e.g. "Monday to Sunday 12am to 11:30pm" instead of "Mon – Sun 12am – 11:30pm".
        String actualSheetHours = rxReadyForPickupAndDeliveryTrackerCardPage.getStoreInfoHoursText();
        Assert.assertEquals(normalizeHoursText(actualSheetHours), normalizeHoursText(translationStoreHours),
                "ASSERT: Sheet hours UI='" + actualSheetHours
                        + "' does not match translation='" + translationStoreHours + "'");
        Reporter.log("ASSERT: Sheet hours UI='" + actualSheetHours
                + "' matches translation='" + translationStoreHours + "' (normalized)");

        rxReadyForPickupAndDeliveryTrackerCardPage.closeStoreInfoSheet();
        Reporter.log("ACTION: Closed Store Information bottom sheet");
    }

    /**
     * Scrolls the Pharmacy Dashboard downward until the element matching {@code resourceId} and
     * {@code text} is fully within the visible viewport, then returns it.  Returns {@code null}
     * if not found.
     *
     * <p>Delegates to {@code MobileBasePage} scroll helpers:
     * <ul>
     *   <li>Android: {@code androidScrollDownToText} — PointerInput swipe loop with
     *       coordinate-based viewport check.</li>
     *   <li>iOS: {@code mobileScrollToText} — iOSNsPredicate scroll loop with the same
     *       coordinate check; element is fetched separately after the scroll succeeds.</li>
     * </ul>
     * Both use coordinate checks, not {@code isDisplayed()}, which is unreliable for
     * off-screen elements in RecyclerView / iOS table views.
     *
     * <p>Because scrolling is uni-directional (downward only), calling this method for elements
     * in the expected top-to-bottom order implicitly enforces that order: an element that is
     * above the current scroll position will never be found by further downward scrolling.</p>
     */
    public WebElement scrollDownToText(String text) {
        return null;
    }

    /**
     * Returns {@code true} when {@code patientName} is visible on screen inside an RFP card row.
     * Platform-specific: override in {@link IOSPageManager} and {@link AndroidPageManager}.
     */
    public boolean isRfpPatientVisible(String patientName) {
        return false;
    }

    /**
     * Normalizes a pharmacy hours string so that comparisons between the translation value
     * and the iOS accessibility label succeed regardless of formatting differences.
     *
     * <p>iOS VoiceOver expands abbreviated day names and replaces en-dashes with the word "to":
     * e.g. {@code "Mon – Sun 12am – 11:30pm"} becomes {@code "Monday to Sunday 12am to 11:30pm"}.
     * This method maps full names back to the three-letter abbreviations and restores the en-dash,
     * so both strings converge to the same canonical form before they are compared.</p>
     */
    private static String normalizeHoursText(String text) {
        return text
                .replace("Monday",    "Mon").replace("Tuesday",   "Tue")
                .replace("Wednesday", "Wed").replace("Thursday",  "Thu")
                .replace("Friday",    "Fri").replace("Saturday",  "Sat")
                .replace("Sunday",    "Sun")
                .replace(" to ",      " \u2013 ");   // en-dash (–)
    }

    public void verifySingleRxInReadyForPickup(DeliveryStatus deliveryStatus, String patientName, String drugName, String drugPrice, String storeAddress) {
        Object headerText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "CardHeaderText");
        Object prescriptionDeliveryNowAvailableText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "PrescriptionDeliveryNowAvailableText");
        Object learnMoreText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "LearnMoreText");
        Object ratherGetThemInStoreText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "RatherGetThemInStoreText");
        Object headerDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "CardHeaderDescriptionText");
        Object inStorePharmacyOnlyText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "InStorePharmacyOnlyText");
        Object inStorePharmacyOnlyDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "InStorePharmacyOnlyDescriptionText");
        Object whyLinkText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "WhyLinkText");
        Object seeDetailsText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForPickup", "SeeDetailsText");
        if (deliveryStatus.equals(DeliveryStatus.ELIGIBLE)) {
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getDeliveryAvailableMessage(), prescriptionDeliveryNowAvailableText);
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getLearnMoreText(), learnMoreText);
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRatherGetThemInStoreText(), ratherGetThemInStoreText);
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getFillStatusCardSubHeaderText(), headerDescriptionText);
        } else if (deliveryStatus.equals(DeliveryStatus.INELIGIBLE)) {
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getFillStatusCardHeaderText(), inStorePharmacyOnlyText);
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getInStorePharmacyOnlyDescriptionText(), inStorePharmacyOnlyDescriptionText);
            Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getWhyLinkText(), whyLinkText);
            // verifyWhyInEligiblePage();
        }
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getFillStatusCardHeaderText(), headerText);
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxName(), drugName, "Drug name is incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxEstimatedPrice(), drugPrice, "Drug price is incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getSeeDetailsText(), seeDetailsText, "'See details' link is not visible in Rx row");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isHumanIconVisible(), "Human icon is not visible in Rx row");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isDrugImageVisible(), "Refill now' button is not visible");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isInfoCTAVisible(), "pharmacy info circle icon is not visible in Rx row");
        //TODO store hours validation
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getStoreAddressText(), storeAddress, "Store address is incorrect");
    }

    // TODO make changes for assertions
    public void verifySingleRxReadyForReFill(String patientName, String drugName) {

        Object value = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderText");
        Assert.assertEquals(fillStatusTrackerCardPage.getFillStatusCardHeaderText(), value, "Card Header is Incorrect");

        Assert.assertTrue(fillStatusTrackerCardPage.isFillStatusCardSubHeaderTextVisible(), "Fill status card sub header text is nt visible");
        Assert.assertEquals(fillStatusTrackerCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");

        Assert.assertEquals(fillStatusTrackerCardPage.getRxName(), drugName, "Drug name is incorrect");

    }

    public void verifySelectSinglePrescriptionAction() {

        rxReadyForRefillCardPage.clickSelectSinglePrescriptionButton();
        Assert.assertEquals(refillPrescriptionPage.getMyPrescriptionsHeaderLabel(), "My Prescriptions", "My prescriptions screen hasn't open on clicking select prescription");
        refillPrescriptionPage.clickCancelRefillAction();
        //rxReadyForRefillCardPage.navigateBack();
    }

    public void verifySinglePrescriptionSeeDetailsAction() {

        rxReadyForPickupAndDeliveryTrackerCardPage.clickSeeDetails();
        Assert.assertEquals(refillPrescriptionPage.getMyPrescriptionsHeaderLabel(), "My Prescriptions", "My prescriptions screen hasn't open on clicking select prescription");
        rxReadyForRefillCardPage.navigateBack();
    }

    public void verifyDismissButtonReadyForRefillAction() {

        rxReadyForRefillCardPage.clickDismissButton();
        Assert.assertFalse(rxReadyForRefillCardPage.isRxReadyForFillParentCardVisible());
    }

    public void verifyRxNamesForMultiRx(List<String> expectedRxNames) {
        List<String> visibleRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRx();
        Assert.assertTrue(expectedRxNames.containsAll(visibleRxNames), "The rx(s) visible for patient are not correct");
    }

    public void verifyMultiRxInFilling(List<String> patientNameList, List<String> expectedRxNames, List<String> expectedExtimatedPrices, String rxCount) {
        Object singleRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxInFilling", "CardHeaderDescriptionText");
        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), singleRxFillingCardHeaderDescriptionText, "Filling status card sub header text is not visible");
        Assert.assertTrue(rxInFillingCardPage.getFillStatusCardHeaderText(Integer.parseInt(rxCount), "").contains(rxCount), "RxCount is incorrect in the Header");
        verifyPatientNamesForMultiRxinFilling(patientNameList);
        verifyRxNamesForMultiRxinFilling(expectedRxNames);
//        verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
    }

    public void clickShowAllButton() {
        rxReadyForRefillCardPage.clickShowAllItemsButton();
    }

    public void verifyMultiRxReadyForRefill(List<String> patientNameList, List<String> expectedRxNames, String rxCount) {
        Object miultiRxCardHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxReadyForRefill", "CardHeaderBaseText");
        Object miultiRxCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxReadyForRefill", "CardHeaderDescriptionText");
        Assert.assertEquals(rxReadyForRefillCardPage.getFillStatusCardHeaderText(), rxCount + " " + miultiRxCardHeaderText);
        Assert.assertEquals(rxReadyForRefillCardPage.getFillStatusCardSubHeaderText(), miultiRxCardHeaderDescriptionText, "Ready For Refill status card sub header subtext is not visible");
        // Assert.assertTrue(rxReadyForRefillCardPage.getPrescriptionsCount().contains(rxCount), "Prescription Count is not matching");
        Assert.assertTrue(rxReadyForRefillCardPage.getFillStatusCardHeaderText().contains(rxCount), "RxCount is incorrect in the Header");
        verifyPatientNamesForMultiRxReadyForRefill(patientNameList);
        verifyRxNamesForMultiRxReadyForRefill(expectedRxNames);
    }

    public void verifyPatientNamesForMultiRxReadyForRefill(List<String> patientNameList) {
        List<String> visiblePatientNames = rxReadyForRefillCardPage.getPatientNamesForMultiRxWeb();
        Assert.assertTrue(patientNameList.containsAll(visiblePatientNames), "The Patients visible are incorrect");
    }

    public void verifyRxNamesForMultiRxReadyForRefill(List<String> expectedRxNames) {
        List<String> visibleRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRx();
        Assert.assertTrue(expectedRxNames.containsAll(visibleRxNames), "The rx(s) visible are not correct");
    }

    public void verifyPatientNamesForMultiRxinFilling(List<String> patientNameList) {
        List<String> visiblePatientNames = rxInFillingCardPage.getPatientNames();
        List<String> normalizedExpected = patientNameList.stream().map(String::toLowerCase).toList();
        List<String> normalizedVisible = visiblePatientNames.stream().map(String::toLowerCase).toList();
        Assert.assertTrue(normalizedExpected.containsAll(normalizedVisible),
                "The Patients visible are incorrect. Expected: " + normalizedExpected + " | Actual (visible): " + normalizedVisible);
    }

    public void verifyRxNamesForMultiRxinFilling(List<String> expectedRxNames) {
        List<String> visibleRxNames = rxInFillingCardPage.getVisibleRxNamesList();
        List<String> normalizedExpected = expectedRxNames.stream().map(String::toLowerCase).toList();
        List<String> normalizedVisible = visibleRxNames.stream().map(String::toLowerCase).toList();
        Assert.assertTrue(normalizedExpected.containsAll(normalizedVisible),
                "The rx(s) visible are not correct. Expected: " + normalizedExpected + " | Actual (visible): " + normalizedVisible);
    }

    public void verifyEstimatedPricesForMultiRxinFilling(List<String> expectedExtimatedPrices) {
        List<String> visibleExtimatedPrices = rxInFillingCardPage.getVisibleEstimatedRxPricesList();
        for (int i = 0; i < visibleExtimatedPrices.size(); i++) {
            if (!visibleExtimatedPrices.get(i).contains(expectedExtimatedPrices.get(i))) {
                Assert.fail("The rx(s) prices visible are not correct as actual is " + visibleExtimatedPrices.get(i) + " and expected is " + expectedExtimatedPrices.get(i));
                break;
            }
        }
    }

    /** Verifies a tracker card on the Pharmacy Dashboard — works for any card type (cancel fill, delayed, etc.).
     *  Pass {@code null} for {@code expectedStatuses} to skip the per-row status/reason check.
     *  The singular/plural translation key is chosen from the actual header text, not a hardcoded count. */
    public void verifyTrackerCard(String cardHeaderText, String cardItemId,
                                  String singleTransKey, String multiTransKey,
                                  List<String> patientNameList, List<String> expectedRxNames,
                                  List<String> expectedStatuses) {
        Assert.assertTrue(pharmacyDashboardPage.isTrackerCardVisible(cardHeaderText),
                "Tracker card ('" + cardHeaderText + "') is not visible on Pharmacy Dashboard");

        String actualHeaderText = pharmacyDashboardPage.getTrackerCardHeaderText(cardHeaderText, cardHeaderText);
        Reporter.log("Tracker card header: " + actualHeaderText);

        // Determine singular vs plural from the actual header (first word is the count)
        boolean isSingle = actualHeaderText.trim().split("\\s+")[0].equals("1");
        String textKey = isSingle ? singleTransKey : multiTransKey;

        Assert.assertEquals(pharmacyDashboardPage.getTrackerCardSubHeaderText(cardHeaderText),
                textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", textKey, "CardHeaderDescriptionText"),
                "Card sub-header text is incorrect");

        for (int i = 0; i < patientNameList.size(); i++) {
            String patient    = patientNameList.get(i);
            String expectedRx = expectedRxNames.get(i);

            // Find the row once and read both drug_name and status atomically to prevent
            // stale-element failures if the UI refreshes between two separate findElement calls.
            String[] rxDetails = pharmacyDashboardPage.getFirstRxDetails(cardHeaderText, cardItemId, patient);
            String actualRx     = rxDetails[0];
            String actualStatus = rxDetails[1];

            Assert.assertTrue(actualRx.equalsIgnoreCase(expectedRx),
                    "[" + patient + "] Rx name is incorrect. Expected: " + expectedRx + " | Actual: " + actualRx);

            if (expectedStatuses != null) {
                String expectedStatus = expectedStatuses.get(i);
                Assert.assertTrue(actualStatus != null && actualStatus.contains(expectedStatus),
                        "[" + patient + "] Status is incorrect. Expected to contain: " + expectedStatus + " | Actual: " + actualStatus);
                Reporter.log("ASSERT: [" + patient + "] Rx: " + actualRx + " | Status: " + actualStatus);
            } else {
                Reporter.log("ASSERT: [" + patient + "] Rx: " + actualRx);
            }
        }

        logScreenShot("Tracker Card (" + cardHeaderText + ")");
    }

    /** Cancel-fill wrapper — delegates to {@link #verifyTrackerCard}. */
    public void verifyCancelFillTrackerCard(List<String> patientNameList, List<String> expectedRxNames,
                                            List<String> expectedCancelReasons) {
        verifyTrackerCard(
                "cancelled",
                PharmacyDashboardPage.CANCELED_ITEM_ID,
                "SingleRxCancelFill", "MultiRxCancelFill",
                patientNameList, expectedRxNames, expectedCancelReasons);
    }

    /** Cancel-fill wrapper — delegates to {@link #verifyTrackerCard}. */
    public void verifyDelayedTrackerCard(List<String> patientNameList, List<String> expectedRxNames,
                                            List<String> expectedCancelReasons) {
        verifyTrackerCard(
                "delayed",
                PharmacyDashboardPage.DELAYED_FILL_ITEM_ID,
                "SingleRxDelayedFill", "MultiRxDelayedFill",
                patientNameList, expectedRxNames, expectedCancelReasons);
    }

    /** Clicks the first Rx row for a patient on any tracker card and verifies the details screen.
     *  Pass {@code null} for {@code bannerReason} to skip the banner check (e.g. no banner for delayed fill).
     *  Does NOT navigate back — caller is responsible for navigation. */
    public void verifyRxDetailsForPatient(String cardHeaderText, String cardItemId,
                                          String patient, String expectedRx, String bannerReason) {
        pharmacyDashboardPage.isTrackerCardVisible(cardHeaderText); // scroll card into view (needed after navigateBack)
        pharmacyDashboardPage.clickFirstRxRowForPatient(cardHeaderText, cardItemId, patient);
        prescriptionDetailsPage.waitForLoadingToDisappear(15);

        if (bannerReason != null) {
            verifyCancelReasonBanner(bannerReason);
        }
        verifyPrescriptionDetailsPage(patient, expectedRx, null);
        logScreenShot("Rx Details (" + cardHeaderText + ") — " + patient);
    }

    /** Cancel-fill wrapper — delegates to {@link #verifyRxDetailsForPatient}. */
    public void verifyCancelFillRxDetailsForPatient(String patient, String expectedRx,
                                                    String expectedBannerReason) {
        verifyRxDetailsForPatient(
                "cancelled",
                PharmacyDashboardPage.CANCELED_ITEM_ID,
                patient, expectedRx, expectedBannerReason);
    }

    /** Cancel-fill wrapper — delegates to {@link #verifyRxDetailsForPatient}. */
    public void verifyDelayedFillRxDetailsForPatient(String patient, String expectedRx,
                                                    String expectedBannerReason) {
        verifyRxDetailsForPatient(
                "delayed",
                PharmacyDashboardPage.DELAYED_FILL_ITEM_ID,
                patient, expectedRx, expectedBannerReason);
    }

    /** Verifies the cancel reason warning banner on the prescription details screen.
     *  Can also be called independently from a test when already on the details screen. */
    public void verifyCancelReasonBanner(String expectedReason) {
        Assert.assertTrue(prescriptionDetailsPage.isCancelReasonBannerDisplayed(),
                "Cancel reason banner is not visible on the prescription details screen");
        Assert.assertTrue(prescriptionDetailsPage.getCancelReasonText().contains(expectedReason),
                "Cancel reason text is incorrect. Expected to contain: " + expectedReason
                        + " | Actual: " + prescriptionDetailsPage.getCancelReasonText());
        Reporter.log("ASSERT: Cancel reason banner — " + expectedReason);
    }

    public void verifyDetailsForSelfAndDependent(List<String> expectedRxNames, List<String> expectedPatientNames, boolean isPet) {

        List<String> visibleRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRx();
        Assert.assertTrue(expectedRxNames.containsAll(visibleRxNames), "The rx(s) visible for patient are not correct");
        Assert.assertEquals(expectedPatientNames, visibleRxNames, "The patient and dependant names visible are not correct");
        Assert.assertTrue(fillStatusTrackerCardPage.isPetPatientIconVisible(), "pet icon is not visible for pet patient");
    }

    public void verifyShowAllItemsCTABehavior() {

        rxReadyForRefillCardPage.clickShowAllItemsButton();
        Assert.assertTrue(rxReadyForRefillCardPage.getNumberOfItemsToHide().toString().contains("Hide"), "Hide button is not visible on clicking on show all items CTA");
    }

    public void verifyHideAllItemsCTABehavior() {

        rxReadyForRefillCardPage.clickShowAllItemsButton();
        Assert.assertTrue(rxReadyForRefillCardPage.getNumberOfItemsToHide().toString().contains("Hide"), "Hide button is not visible on clicking on show all items CTA");
        rxReadyForRefillCardPage.clickHideItemButton();

        List<String> visibleRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRx();
        Assert.assertEquals(visibleRxNames.size(), 3);
    }

    public void navigateToPrescriptionDetails(FillStatusInfo fillStatusInfo) {
        if (fillStatusInfo.equals(READY_FOR_REFILL)) {
            rxReadyForRefillCardPage.clickFillDetailsArrowCTA();
        } else if (fillStatusInfo.equals(READY_FOR_PICKUP)) {
            rxReadyForPickupAndDeliveryTrackerCardPage.clickSeeDetails();
        } else if (fillStatusInfo.equals(DELAYED)) {
            rxFillDelayedStatusTrackerCard.clickFillDetailsArrowCTA();
        } else if (fillStatusInfo.equals(FILLING)) {
            rxInFillingCardPage.clickFillDetailsArrowCTA();
        } else {
            fillStatusTrackerCardPage.clickFillDetailsArrowCTA();
        }
    }

    public void verifyPharmacyLocationDetails(String storeName, String storeAddress, String storeTimings, String storePhoneNo) {
        Assert.assertEquals(storeDetailsPage.getStoreHeaderTxt(), storeDetailsPage.pharmacyLocationTxt);
        Assert.assertEquals(storeDetailsPage.getDirectionsLinkTxt(), storeDetailsPage.getDirectionsTxt);

        Assert.assertEquals(storeDetailsPage.getStoreName(), storeName, "Store name is incorrect");
        Assert.assertEquals(storeDetailsPage.getStoreAddress(), storeAddress, "Store address is incorrect");
        Assert.assertEquals(storeDetailsPage.getStoreTimings(), storeTimings, "Store timings is incorrect");
        Assert.assertEquals(storeDetailsPage.getStorePhoneNo(), storePhoneNo, "Store phone number is incorrect");
    }

    public void verifyRxDetailsScreenForFilling(String rxName, String rxEstimatedPrice, String rxNbr, String patName, String prescriber, String rxDate, String quantity, String supply, String lastReceived, String instructions) {
        rxInFillingCardPage.clickFillDetailsArrowCTA();
        Assert.assertEquals(prescriptionDetailsPage.getRxName().replaceAll(" ", "").toUpperCase(), rxName.toUpperCase().replaceAll(" ", ""), "Drug Name is incorrect");
        //Assert.assertTrue(prescriptionDetailsPage.getRxEstimatedPrice().contains(rxEstimatedPrice), "Price is incorrect");
        Assert.assertEquals(prescriptionDetailsPage.getRxValue(), rxNbr, "Rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPatientValue(), patName, "Patient Name not matching");
        Assert.assertEquals(prescriptionDetailsPage.getRxDateValue(), "" + LocalDate.parse(rxDate).format(DateTimeFormatter.ofPattern("MMM dd, yyyy")), "Rx Prescription Date not matching");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityValue() + ".0", quantity, "Prescription Quantity not matching");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyValue(), supply + " days", "Rx Supply not matching");
        Assert.assertEquals((prescriptionDetailsPage.getInstructionsValue()).toUpperCase(), instructions, "rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPrescriberValue().toUpperCase(), prescriber.toUpperCase(), "Prescriber Name is not matching");
        rxInFillingCardPage.navigateBack();
    }

    public void verifyRxDetailsScreenForReadyForRefill(String rxName, String rxEstimatedPrice, String rxNbr, String patName, String prescriber, String rxDate, String quantity, String supply, String instructions, String lastReceived) {
        rxReadyForRefillCardPage.clickFillDetailsArrowCTA();
        Assert.assertEquals(prescriptionDetailsPage.getRxName().replaceAll("\\s", "").toLowerCase(), rxName, "rxName not matching");
        assertThat("Price is incorrect", prescriptionDetailsPage.getRxEstimatedPrice(), containsString(rxEstimatedPrice));
        Assert.assertEquals(prescriptionDetailsPage.getRxValue(), rxNbr, "Rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPatientValue(), patName, "Patient Name not matching");
        assertThat("Prescriber Name is Different", prescriptionDetailsPage.getPrescriberValue().toLowerCase(), containsString(prescriber.toLowerCase()));
        Assert.assertEquals(prescriptionDetailsPage.getRxDateValue(), "" + LocalDate.parse(rxDate, DateTimeFormatter.ofPattern("MMddyyyy")).format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")), "Rx Prescription Date not matching");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityValue(), quantity, "Prescription Quantity not matching");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyValue(), supply, "Rx Supply not matching");
        Assert.assertEquals(prescriptionDetailsPage.getLastReceivedValue(), "" + LocalDate.parse(lastReceived, DateTimeFormatter.ofPattern("MMddyyyy")).format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")), "Rx Last Received Not Matching");
        Assert.assertEquals(prescriptionDetailsPage.getInstructionsValue(), instructions, "rx Number not matching");
        rxReadyForRefillCardPage.navigateBack();
    }

    public void verifyRxDetailsScreenForReadyForPickup(String rxName, String rxEstimatedPrice, String rxNbr, String patName, String prescriber, String rxDate, String quantity, String supply, String instructions) {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSeeDetails();
        Assert.assertEquals(prescriptionDetailsPage.getRxName(), rxName, "rxName not matching");
        Assert.assertEquals(prescriptionDetailsPage.getRxEstimatedPrice(), rxEstimatedPrice, "RxExtimated Price Incorrect");
        Assert.assertEquals(prescriptionDetailsPage.getRxValue(), rxNbr, "Rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPatientValue(), patName, "Patient Name not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPrescriberValue(), prescriber, "Prescriber Name not matching");
        Assert.assertEquals(prescriptionDetailsPage.getRxDateValue(), rxDate, "Rx Prescription Date not matching");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityValue(), quantity, "Prescription Quantity not matching");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyValue(), supply, "Rx Supply not matching");
        Assert.assertEquals(prescriptionDetailsPage.getInstructionsValue(), instructions, "rx Number not matching");
        rxReadyForPickupAndDeliveryTrackerCardPage.navigateBack();
    }


    public void verifyAndAcceptMedicaidConsentFormData() {
        Object medicaidFormTitleText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormTitle");
        Object medicaidFormAcknowledgeText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormAcknowledgeText");
        System.out.println("Medicaid form acknowledgement text: " + medicaidFormAcknowledgeText.toString());
        Object medicaidFormDescriptionText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormDescription");
        System.out.println("Medicaid form body text: " + medicaidFormDescriptionText.toString());
        Object medicaidFormDisclaimerText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormDisclaimerText");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidSwitchToCashTitle(), medicaidFormTitleText, "Form Header is Incorrect");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidDisclosureConsentText(), medicaidFormDescriptionText, "Form Description Text is Incorrect");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidDisclosureAcknowledgementText(), medicaidFormAcknowledgeText, "Form Acknowledge Description Text is Incorrect");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidConsentDisclaimerText(), medicaidFormDisclaimerText, "Form Disclaimer Text is Incorrect");
        Assert.assertTrue(medicaidConsentFormPage.checkAcknowledgeButtonVisibility());
        Assert.assertTrue(medicaidConsentFormPage.checkPickupInsteadLinkVisibility());
        Assert.assertTrue(medicaidConsentFormPage.medicaidFormCloseIconVisibility());
        medicaidConsentFormPage.acceptMedicaidClosure();
    }

    public void clickMedicaidDisclosureAcknowledgeButton() {
        medicaidConsentFormPage.clickMedicaidDisclosureAcknowledgeCTA();
    }

    /**
     * Initiates SMS OTP generation by entering phone number for pharmacy account connection
     * @param phoneNo Phone number to use for SMS verification
     */
    public void generateRxMessagingPhoneOtp(String phoneNo) {
        pharmacyDashboardPage.clickConnectMyAccountCTA();
        connectMyAccount.enterPhoneNumber(phoneNo);
        connectMyAccount.clickContinueCTA();
        connectMyAccount.clickContinueAfterEnteringSMSNumber();
    }

    public void generateRxMessagingPhoneOtpScanToRefillFlow(String phoneNo) {

    }

    public void validateNeedMoreDetailsPage() {
        Object needMoreDetailsHeaderText = textValidationUtils.getKeyInObject("smsAccountCreation", "smsAccountCreationFlow", "notEnrolledNeedMoreDetailsHeader");
        Assert.assertEquals(connectMyAccount.needMoreDetailsText(), needMoreDetailsHeaderText, "Need more details header text is not matching");
    }

    public void validateExperianFlowHeader() {
    }

    /**
     * Connects to pharmacy account - handles OTP verification, profile selection, DOB confirmation,
     * PIN creation, and completes SMS account creation flow
     * @param otp OTP code received via SMS or email
     * @param dob Date of birth for profile verification
     */
    public void connectToPharmacy(String otp, String dob) {
       connectMyAccount.sendOTP(otp);
       connectMyAccount.clickOtpAcceptCTA();

        // Select primary profile and confirm DOB
        connectMyAccount.clickContinueForProfileCTA();
        connectMyAccount.enterDobForPatientProfile(dob);
        connectMyAccount.clickConfirmCTA();

        // "Confirm location access" dialog appears on real devices after profile confirmation —
        // the app navigates to the pharmacy PIN screen and overlays this dialog.
        // Wait up to 5s for it to appear so it is caught even if there is a brief render delay.
        pharmacyDashboardPage.dismissLocationAccessDialog(5);

        // Verify PIN entry and skip biometrics
        pharmacyDashboardPage.enterPin();
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.clickDoneOnSuccessScreen();
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
    }

    /**
     * Connects to pharmacy via Experian KYC flow for a phone number not enrolled in SMS.
     * Flow: Connect my account → enter phone → We need more details → Add more details →
     * Experian profile form (DOB + phone) → security questions → gender confirmation →
     * PIN creation → skip biometrics → success screen → Privacy Notice → delivery prompt.
     *
     * <p>The {@code experianAnswers} map must contain the patient's known answers keyed by
     * question topic. The Experian screen may present any subset of questions in any order;
     * {@link ConnectMyAccount#answerExperianQuestions} reads each question's text at runtime
     * and selects the matching answer from this map automatically.
     *
     * <p>Supported keys: zodiac, ssnState, ssnLast4, dlState, currentCity, previousCity,
     * currentStreet, previousStreet, county, yearOfBirth, educationLevel,
     * vehicleMake, vehicleModel, vehicleYear, licensePlate.
     *
     * @param phoneNo         Patient phone number (not SMS-enrolled)
     * @param dob             Patient date of birth (mm/dd/yyyy)
     * @param experianAnswers Map of question-key → answer value for all possible KYC questions
     * @param gender          "Female" or "Male" for gender confirmation screen
     * @param pin             4-digit PIN to create for the account
     */
    public void connectToPharmacyViaExperianFlow(String phoneNo, String dob,
            Map<String, String> experianAnswers, String gender, String pin) {
        pharmacyDashboardPage.clickConnectMyAccountCTA();
        connectMyAccount.enterPhoneNumber(phoneNo);
        connectMyAccount.clickContinueCTA();

        connectMyAccount.clickAddMoreDetails();
        connectMyAccount.fillExperianProfileForm(dob, phoneNo);
        connectMyAccount.clickExperianFormContinueCTA();

        connectMyAccount.answerExperianQuestions(experianAnswers);
        connectMyAccount.submitKycQuestions();

        connectMyAccount.selectGender(gender);
        connectMyAccount.clickGenderContinueCTA();

        enterAndConfirmPin();
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.clickDoneOnExperianSuccessScreen();
        pharmacyDashboardPage.acceptPrivacyPractices();
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
        pharmacyDashboardPage.dismissAccountBeingSetupSheet();
        signInPage.dismissAllBottomSheets();
    }

    public void enterAndConfirmPin() {
        pharmacyDashboardPage.enterPin();
        // confirm pin is not needed for all the platforms
    }

    /**
     * Verifies that the Pharmacy Dashboard is displayed
     * @return true if Pharmacy Dashboard is displayed
     */
    public boolean isPharmacyDashboardDisplayed() {
        return pharmacyDashboardPage.isPharmacyDashboardHeaderDisplayed();
    }

    /**
     * Navigates to Pharmacy Account Settings screen from Pharmacy Dashboard
     */
    public void navigateToPharmacyAccountSettings() {
        pharmacyDashboardPage.navigateToPharmacyAccountSettings();
    }

    /**
     * Navigates to Account settings then Personal information page.
     * Call when already on Pharmacy Dashboard or after navigateToPharmacyAccountSettings().
     */
    public void navigateToPersonalInformationPage() {
        navigateToPharmacyAccountSettings();
        Assert.assertTrue(pharmacyAccountSettingsPage.isAccountSettingsScreenDisplayed(),
                "Account Settings screen should be displayed");
        pharmacyAccountSettingsPage.clickPersonalInformationOption();
        Assert.assertTrue(personalInformationPage.isPersonalInformationPageDisplayed(),
                "Personal information page should be displayed");
        Reporter.log("Navigated to Personal information page");
    }

    /**
     * Verifies Personal information page content: title, description, and all sections (labels + values)
     * using translations and test data. Test data keys: caregiverFirstName, caregiverLastName,
     * caregiverDob (MMDDYYYY), caregiverEmail, phone, address.
     */
    public void verifyPersonalInformationContent(JSONObject userData) {
        String title = textValidationUtils.getKeyInObject("personalInformationPage", "pageTitle").toString();
        Assert.assertTrue(personalInformationPage.getPageTitleText().equalsIgnoreCase(title),
                "Page title mismatch; expected: " + title);

        String description = textValidationUtils.getKeyInObject("personalInformationPage", "description").toString();
        Assert.assertTrue(personalInformationPage.getDescriptionText().replaceAll("\\s+", " ").trim()
                        .contains(description.replaceAll("\\s+", " ").trim()) || personalInformationPage.getDescriptionText().equalsIgnoreCase(description),
                "Description mismatch");

        verifyLabelAndValue(textValidationUtils.getKeyInObject("personalInformationPage", "fullNameLabel").toString(),
                personalInformationPage.getFullNameLabel(),
                buildFullName(userData),
                personalInformationPage.getFullNameValue());

        String dobLabel = textValidationUtils.getKeyInObject("personalInformationPage", "dateOfBirthLabel").toString();
        Assert.assertTrue(personalInformationPage.getDateOfBirthLabel().equalsIgnoreCase(dobLabel), "Date of birth label mismatch");
        String caregiverDob = userData.getString(CommonConstants.caregiverDob).trim();
        String expectedDobDisplay = formatCaregiverDobForDisplay(caregiverDob);
        Assert.assertTrue(personalInformationPage.getDateOfBirthValue().replaceAll("\\s+", " ").trim()
                        .equalsIgnoreCase(expectedDobDisplay.trim()),
                "Date of birth value mismatch; expected: " + expectedDobDisplay);

        verifyLabelAndValue(textValidationUtils.getKeyInObject("personalInformationPage", "emailAddressLabel").toString(),
                personalInformationPage.getEmailAddressLabel(),
                userData.optString(CommonConstants.caregiverEmail, ""),
                personalInformationPage.getEmailAddressValue());

        verifyLabelAndValue(textValidationUtils.getKeyInObject("personalInformationPage", "primaryPhoneNumberLabel").toString(),
                personalInformationPage.getPrimaryPhoneLabel(),
                userData.optString(CommonConstants.phone, ""),
                personalInformationPage.getPrimaryPhoneValue());

        String primaryAddrLabel = textValidationUtils.getKeyInObject("personalInformationPage", "primaryAddressLabel").toString();
        Assert.assertTrue(personalInformationPage.getPrimaryAddressLabel().equalsIgnoreCase(primaryAddrLabel), "Primary address label mismatch");
        String expectedAddress = userData.optString("address", "");
        String normalizedActual = personalInformationPage.getPrimaryAddressValue().replace("\n", " ").replace(",", " ").replaceAll("\\s+", " ").trim();
        String normalizedExpected = expectedAddress.replace("\n", " ").replace(",", " ").replaceAll("\\s+", " ").trim();
        Assert.assertTrue(normalizedActual.contains(normalizedExpected),
                "Primary address value should contain: " + expectedAddress);

        String secondaryLabel = textValidationUtils.getKeyInObject("personalInformationPage", "secondaryAddressLabel").toString();
        Assert.assertTrue(personalInformationPage.getSecondaryAddressLabel().equalsIgnoreCase(secondaryLabel), "Secondary address label mismatch");
        String addSecondary = textValidationUtils.getKeyInObject("personalInformationPage", "addSecondaryAddress").toString();
        Assert.assertTrue(personalInformationPage.getSecondaryAddressValue().equalsIgnoreCase(addSecondary),
                "Secondary address value (placeholder) mismatch; expected: " + addSecondary);

        String emergencyLabel = textValidationUtils.getKeyInObject("personalInformationPage", "emergencyContactLabel").toString();
        Assert.assertTrue(personalInformationPage.getEmergencyContactLabel().equalsIgnoreCase(emergencyLabel), "Emergency contact label mismatch");
        String addEmergency = textValidationUtils.getKeyInObject("personalInformationPage", "addEmergencyContact").toString();
        Assert.assertTrue(personalInformationPage.getEmergencyContactValue().equalsIgnoreCase(addEmergency),
                "Emergency contact value (placeholder) mismatch; expected: " + addEmergency);

        Reporter.log("Verified Personal information page content");
    }

    /**
     * Normalizes a string for comparison by collapsing whitespace and replacing
     * Unicode typographic punctuation (smart quotes, en/em dashes) with their
     * ASCII equivalents. iOS apps commonly render curly apostrophes (U+2019) and
     * other typographic characters that differ from ASCII equivalents in translation files.
     */
    private String normalizeText(String text) {
        if (text == null) return "";
        return text
                .replace('\u2019', '\'')  // RIGHT SINGLE QUOTATION MARK → apostrophe
                .replace('\u2018', '\'')  // LEFT SINGLE QUOTATION MARK
                .replace('\u201C', '"')   // LEFT DOUBLE QUOTATION MARK
                .replace('\u201D', '"')   // RIGHT DOUBLE QUOTATION MARK
                .replace('\u2013', '-')   // EN DASH
                .replace('\u2014', '-')   // EM DASH
                .replace('\u00A0', ' ')   // NON-BREAKING SPACE
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void verifyLabelAndValue(String expectedLabel, String actualLabel, String expectedValue, String actualValue) {
        Assert.assertTrue(actualLabel.trim().equalsIgnoreCase(expectedLabel.trim()), "Label mismatch; expected: " + expectedLabel);
        Assert.assertTrue(actualValue != null && actualValue.trim().equalsIgnoreCase(expectedValue.trim()),
                "Value mismatch; expected: " + expectedValue + ", actual: " + actualValue);
    }

    private String buildFullName(JSONObject userData) {
        String first = userData.optString(CommonConstants.caregiverFirstName, "").trim();
        String last = userData.optString(CommonConstants.caregiverLastName, "").trim();
        return (first + " " + last).trim();
    }

    /** Parses caregiverDob (MMDDYYYY) and returns app display format (e.g. "Dec 09, 1984"). */
    private String formatCaregiverDobForDisplay(String caregiverDob) {
        try {
            LocalDate date = LocalDate.parse(caregiverDob, DateTimeFormatter.ofPattern("MMddyyyy"));
            return date.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
        } catch (Exception e) {
            Reporter.log("Could not parse caregiverDob for display: " + caregiverDob + " - " + e.getMessage());
            return "";
        }
    }

    /**
     * Clicks Edit address, updates address line 1 to random number + addressLine1 from test data, and saves.
     * If the "Unable to verify address" bottom sheet appears, clicks "Continue with entered address".
     * @param userData test data containing "addressLine1" (e.g. "Sw Troon Ln"); default "Sw Troon Ln" if missing
     */
    public void editAddressAndSaveWithRandomNumber(JSONObject userData) {
        String addressLine1 = userData != null ? userData.optString("addressLine1", "Sw Troon Ln") : "Sw Troon Ln";
        int randomNum = ThreadLocalRandom.current().nextInt(3101, 4001);
        String newAddress = randomNum + " " + addressLine1;
        personalInformationPage.clickEditAddress();
        personalInformationPage.enterAddressAndSave(newAddress);
        personalInformationPage.clickSaveAddress();
        Reporter.log("Updated address to: " + newAddress);
        if (personalInformationPage.isUnableToVerifyAddressSheetDisplayed()) {
            personalInformationPage.clickContinueWithEnteredAddress();
        }
    }

    /**
     * Verifies the bottom snackbar message after address save (MCP-captured: message_text inside snackBarContainer).
     * Waits for snackbar, gets text, asserts it contains expected from translations.
     */
    public void verifyAddressUpdatedSnackBarMessage() {
        try {
            String expectedText = textValidationUtils.getKeyInObject("personalInformationPage", "addressUpdatedToast").toString();
            String actualSnackbarText = personalInformationPage.getAddressUpdatedSnackbarText();
            Assert.assertTrue(actualSnackbarText.contains(expectedText),
                    "Snackbar text should contain expected; actual: " + actualSnackbarText + "; expected to contain: " + expectedText);
            Reporter.log("Address-updated snackbar verified: " + actualSnackbarText);
        } catch (Throwable t) {
            Reporter.log("WARNING: Could not verify address updated snackbar due to timing: " + t.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Communications screen methods
    // -------------------------------------------------------------------------

    /**
     * Navigates from Pharmacy Dashboard to Account Settings → Communications.
     * Dismisses the 'Notifications are off' bottom sheet if it appears.
     */
    public void navigateToCommunicationsPage() {
        navigateToPharmacyAccountSettings();
        Assert.assertTrue(pharmacyAccountSettingsPage.isAccountSettingsScreenDisplayed(),
                "Account Settings screen should be displayed");
        pharmacyAccountSettingsPage.clickCommunicationsOption();
        communicationsPage.dismissNotificationsOffBottomSheet();
        Assert.assertTrue(communicationsPage.isCommunicationsPageDisplayed(),
                "Communications page should be displayed");
        Reporter.log("Navigated to Communications page");
    }

    /**
     * Verifies all content on the Communications screen using MCP-captured translations.
     * Checks: page title, subtitle, account holder card, pharmacy notifications section
     * (title, description, toggles), and all four subcategory labels.
     */
    public void verifyCommunicationsScreenContent(JSONObject testData) {
        Map<String, Object> t = Stream.of(
                "pageTitle", "subtitle", "accountHolderLabel", "pharmacyNotificationsTitle",
                "pharmacyNotificationsDescription", "receiveTextNotificationsLabel",
                "prescriptionRefillStatusCategory", "refillReminderCategory",
                "appointmentStatusCategory", "clinicalOutreachCategory"
        ).collect(Collectors.toMap(k -> k, k -> textValidationUtils.getKeyInObject("communicationsPage", k)));

        Assert.assertTrue(communicationsPage.getCommunicationsTitleText().equalsIgnoreCase(t.get("pageTitle").toString()),
                "Communications title mismatch; expected: " + t.get("pageTitle"));
        Assert.assertTrue(communicationsPage.getCommunicationsSubtitleText().equalsIgnoreCase(t.get("subtitle").toString()),
                "Communications subtitle mismatch; expected: " + t.get("subtitle"));
        Assert.assertTrue(communicationsPage.getAccountTypeLabelText().equalsIgnoreCase(t.get("accountHolderLabel").toString()),
                "Account type label mismatch; expected: " + t.get("accountHolderLabel"));

        String expectedFullName = (testData.optString("caregiverFirstName", "") + " " + testData.optString("caregiverLastName", "")).trim();
        Assert.assertTrue(communicationsPage.getAccountHolderNameText().equalsIgnoreCase(expectedFullName),
                "Account holder name mismatch; expected: " + expectedFullName);

        Assert.assertTrue(communicationsPage.getPharmacyNotificationsTitleText().equalsIgnoreCase(t.get("pharmacyNotificationsTitle").toString()),
                "Pharmacy notifications section title mismatch; expected: " + t.get("pharmacyNotificationsTitle"));

        String actualSectionDesc = communicationsPage.getPharmacyNotificationsDescriptionText();
        Assert.assertTrue(normalizeText(actualSectionDesc).toLowerCase().contains(normalizeText(t.get("pharmacyNotificationsDescription").toString()).toLowerCase()),
                "Pharmacy notifications description mismatch; expected to contain: \"" + t.get("pharmacyNotificationsDescription") + "\", actual: \"" + actualSectionDesc + "\"");

        Assert.assertTrue(communicationsPage.getReceiveTextNotificationsLabelText().equalsIgnoreCase(t.get("receiveTextNotificationsLabel").toString()),
                "Receive text notifications label mismatch; expected: " + t.get("receiveTextNotificationsLabel"));
        Assert.assertTrue(communicationsPage.isReceiveTextNotificationsToggleOff(),
                "Receive text notifications toggle should be OFF by default");

        // Scroll down to load all subcategory titles into the DOM before verifying
        scrollDownToLoadPreferencesCategories();

        String[] expectedCategories = {
                t.get("prescriptionRefillStatusCategory").toString(),
                t.get("refillReminderCategory").toString(),
                t.get("appointmentStatusCategory").toString(),
                t.get("clinicalOutreachCategory").toString()
        };
        for (int i = 0; i < expectedCategories.length; i++) {
            Assert.assertTrue(communicationsPage.getCategoryTitleAt(i).equalsIgnoreCase(expectedCategories[i]),
                    "Category title at index " + i + " mismatch; expected: " + expectedCategories[i]);
        }
        Reporter.log("Communications screen content verified");
    }

    public void scrollDownToLoadPreferencesCategories() {
    }

    /** Scrolls back to the "Receive text notifications" toggle row. Overridden per platform. */
    public void scrollToReceiveTextNotificationsToggle() {
    }

    /**
     * Taps the Receive text notifications toggle, then verifies the enrollment screen
     * content (toolbar title, enroll title, description, required fields label).
     */
    public void tapReceiveTextNotificationsAndVerifyEnrollmentScreen(JSONObject testData) {
        communicationsPage.tapReceiveTextNotificationsToggle();
        Assert.assertTrue(textNotificationsEnrollmentPage.isEnrollmentScreenDisplayed(),
                "Text notifications enrollment screen should be displayed");

        Map<String, Object> t = Stream.of("toolbarTitle", "enrollDescription", "requiredFieldsLabel")
                .collect(Collectors.toMap(k -> k, k -> textValidationUtils.getKeyInObject("textNotificationsEnrollmentPage", k)));

        String actualToolbarTitle = textNotificationsEnrollmentPage.getToolbarTitleText();
        Assert.assertTrue(t.get("toolbarTitle").toString().equalsIgnoreCase(actualToolbarTitle),
                "Enrollment screen toolbar title mismatch; expected: " + t.get("toolbarTitle") + ", actual: " + actualToolbarTitle);

        String caregiverFirstName = testData.optString("caregiverFirstName", "");
        Assert.assertTrue(textNotificationsEnrollmentPage.getEnrollPhoneTitleText().contains(caregiverFirstName),
                "Enroll phone title should contain caregiver first name: " + caregiverFirstName);
        Assert.assertTrue(textNotificationsEnrollmentPage.getEnrollPhoneDescriptionText().equalsIgnoreCase(t.get("enrollDescription").toString()),
                "Enrollment description mismatch; expected: " + t.get("enrollDescription"));
        Assert.assertTrue(textNotificationsEnrollmentPage.getRequiredFieldsLabelText().equalsIgnoreCase(t.get("requiredFieldsLabel").toString()),
                "Required fields label mismatch; expected: " + t.get("requiredFieldsLabel"));

        Reporter.log("Enrollment screen content verified");
    }

    /**
     * Enters the phone number and taps Enroll to trigger OTP, then verifies OTP screen elements.
     */
    public void enrollPhoneNumberAndVerifyOtpScreen(String phoneNumber) {
        textNotificationsEnrollmentPage.enterPhoneNumber(phoneNumber);
        for (int attempt = 1; attempt <= 3; attempt++) {
            textNotificationsEnrollmentPage.tapEnroll();
            Reporter.log("Tapped Enroll on enrollment screen (attempt " + attempt + ")");
            am.performSleep(5);
            if (textNotificationsEnrollmentPage.isOtpScreenDisplayed()) {
                Reporter.log("OTP screen appeared on attempt " + attempt);
                break;
            }
            Reporter.log("OTP screen not displayed after attempt " + attempt + ", retrying...");
        }
        Assert.assertTrue(textNotificationsEnrollmentPage.isOtpScreenDisplayed(),
                "OTP verification screen should be displayed after Enroll");

        Assert.assertTrue(textNotificationsEnrollmentPage.isElementDisplayed(
                        textNotificationsEnrollmentPage.getAnotherCodeButton, 5),
                "Get another code button should be visible on OTP screen");

        String expectedVerifyBtn = textValidationUtils.getKeyInObject("textNotificationsEnrollmentPage", "otpVerifyCodeButton").toString();
        Assert.assertTrue(textNotificationsEnrollmentPage.isElementDisplayed(
                        textNotificationsEnrollmentPage.verifyCodeButton, 5),
                "Verify code button should be visible on OTP screen");

        Reporter.log("OTP screen displayed and verified after enrolling phone: " + phoneNumber);
    }

    /**
     * Retrieves the phone OTP for the given email/rxMessagingPhoneNo via Astro API, enters it,
     * and taps Verify code.
     * Uses: v2/teflon/customer/{email}/otp?phone=1{rxMessagingPhoneNo}
     */
    public void getAndEnterPhoneOtpAndVerify(String email, String rxMessagingPhoneNo) {
        String otp = digitalPharmacyAPIManager.getOTPForPhone(email, rxMessagingPhoneNo);
        Assert.assertNotNull(otp, "Phone OTP should not be null for email: " + email);
        textNotificationsEnrollmentPage.enterOtp(otp);
        textNotificationsEnrollmentPage.tapVerifyCode();
        Reporter.log("Entered phone OTP and tapped Verify code");
    }

    /**
     * Selects minor and adult dependents for text notifications on the dependent selection screen,
     * then taps Enroll to complete the flow.
     * Android and iOS locators are MCP-verified.
     */
    public void selectDependentsForTextNotificationsAndSave(String minorFirstName, String adultFirstName) {
        Assert.assertTrue(textNotificationsEnrollmentPage.isDependentSelectionScreenDisplayed(),
                "Dependent selection screen should be displayed after OTP verification");
        textNotificationsEnrollmentPage.selectDependentByName(minorFirstName);
        textNotificationsEnrollmentPage.selectDependentByName(adultFirstName);
        textNotificationsEnrollmentPage.tapSaveOnDependentSelection();
        Reporter.log("Selected dependents: " + minorFirstName + ", " + adultFirstName + " and enrolled");
    }

    /**
     * Verifies the 'Receive text notifications' toggle is ON, the enrolled phone number is displayed,
     * and the text notification toggle for every subcategory (Prescription refill status,
     * Refill reminder, Appointment status, Clinical outreach) is also ON.
     *
     * @param expectedPhone the phone number expected to be shown (e.g. "(408) 504-1432" or "4085041432")
     */
    public void verifyTextNotificationsTogglesAreOn(String expectedPhone) {
        Assert.assertTrue(communicationsPage.isEnrolledPhoneNumberDisplayed(),
                "Enrolled phone number should be displayed when toggle is ON");
        String actual = communicationsPage.getEnrolledPhoneNumberText();
        // Strip non-digits from both sides before comparing: device shows "(408) 504-1432"
        // but test data may pass raw digits "4085041432".
        Assert.assertTrue(actual.replaceAll("[^0-9]", "").contains(expectedPhone.replaceAll("[^0-9]", "")),
                "Enrolled phone number label should contain '" + expectedPhone + "', but was: " + actual);
        Reporter.log("Verified toggle is ON, enrolled phone: " + actual);
        Assert.assertTrue(communicationsPage.isReceiveTextNotificationsToggleOn(),
                "Receive text notifications toggle should be ON after enrollment");



        Map<String, Object> t = Stream.of(
                "prescriptionRefillStatusCategory", "refillReminderCategory",
                "appointmentStatusCategory", "clinicalOutreachCategory"
        ).collect(Collectors.toMap(k -> k, k -> textValidationUtils.getKeyInObject("communicationsPage", k)));

        String[] categories = {
                t.get("prescriptionRefillStatusCategory").toString(),
                t.get("refillReminderCategory").toString(),
                t.get("appointmentStatusCategory").toString(),
                t.get("clinicalOutreachCategory").toString()
        };

        for (String category : categories) {
            if (category.equals(t.get("appointmentStatusCategory").toString())) {
                // Scroll down to bring all subcategory rows into the DOM, then verify each category
                scrollDownToLoadPreferencesCategories();
            }
            Assert.assertTrue(communicationsPage.isCategoryTextNotificationToggleOn(category),
                    "Text notification toggle for '" + category + "' should be ON after enrollment");
            Reporter.log("Verified text notification toggle is ON for category: " + category);
        }
    }

    /**
     * Taps the toggle (currently ON) and confirms opt-out via the bottom sheet.
     * Returns to the Communications screen with the toggle OFF.
     *
     * <p>The toggle tap is retried up to 3 times if the opt-out sheet does not appear
     * (intermittent click miss on the switch element).
     *
     */
    public void optOutTextNotifications() {
        scrollToReceiveTextNotificationsToggle();
        int maxTapAttempts = 3;
        boolean sheetDisplayed = false;
        for (int attempt = 1; attempt <= maxTapAttempts; attempt++) {
            communicationsPage.tapReceiveTextNotificationsToggle();
            sheetDisplayed = communicationsPage.isOptOutBottomSheetDisplayed();
            if (sheetDisplayed) {
                Reporter.log("Opt-out bottom sheet displayed on attempt " + attempt);
                break;
            }
            Reporter.log("Opt-out bottom sheet not shown on attempt " + attempt + " — retrying tap");
        }
        Assert.assertTrue(sheetDisplayed,
                "Opt-out bottom sheet should appear after tapping ON toggle");
        communicationsPage.confirmOptOut();
        Assert.assertTrue(communicationsPage.isReceiveTextNotificationsToggleOff(),
                "Receive text notifications toggle should be OFF after opt-out");
        Reporter.log("Opted out of text notifications, toggle is now OFF");
    }

    /**
     * On a subsequent enrollment, asserts only the minor dependent is shown and the adult
     * dependent (already enrolled in a prior session) is absent from the list.
     * Then selects the minor dependent and taps Enroll.
     *
     * @param minorFirstName  first name of the minor dependent expected in the list
     * @param adultFirstName  first name of the adult dependent expected to be absent
     */
    public void verifyOnlyMinorDependentAndEnroll(String minorFirstName, String adultFirstName) {
        Assert.assertTrue(textNotificationsEnrollmentPage.isDependentSelectionScreenDisplayed(),
                "Dependent selection screen should be displayed after second OTP verification");
        Assert.assertTrue(textNotificationsEnrollmentPage.isDependentDisplayed(minorFirstName),
                "Minor dependent '" + minorFirstName + "' should be present in the list");
        Assert.assertTrue(textNotificationsEnrollmentPage.isDependentNotDisplayed(adultFirstName),
                "Adult dependent '" + adultFirstName + "' should NOT be present (already enrolled)");
        Reporter.log("Verified: '" + minorFirstName + "' shown, '" + adultFirstName + "' not shown (already enrolled)");
        textNotificationsEnrollmentPage.selectDependentByName(minorFirstName);
        textNotificationsEnrollmentPage.tapSaveOnDependentSelection();
        Reporter.log("Selected minor dependent '" + minorFirstName + "' and tapped Enroll");
    }

    /**
     * Disconnects online pharmacy account - app automatically returns to Pharmacy Dashboard
     * Clicks disconnect button and confirms the disconnection
     */
    public void disconnectPharmacyAccount() {
        pharmacyAccountSettingsPage.clickDisconnectOnlinePharmacyAccountButton();
        pharmacyAccountSettingsPage.confirmPharmacyAccountDisconnection();
        Reporter.log("Pharmacy account disconnected successfully");
    }

    /**
     * From Pharmacy Account Settings: navigates to Manage Permissions, opens delivery enable form,
     * verifies form content (static text from translations, dynamic from test data), cancels (Not now),
     * re-opens form, verifies again, sends the request, and verifies pending approval.
     * Call after reaching Pharmacy Dashboard.
     *
     * @param dependent dependent object (e.g. adultDependents[0]) with dependentFirstName, dependentLastName, dependentEmail
     */
    public void sendDependentDeliveryEnableRequest(JSONObject dependent) {
        String dependentFirstName = dependent.getString("dependentFirstName");
        String dependentLastName = dependent.getString("dependentLastName");
        String dependentEmail = dependent.getString("dependentEmail");

        Object formTitleObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "formTitle");
        Object messageTemplateObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "messageTemplate");
        Object requestHeaderObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "requestHeader");
        Object sendRequestButtonObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "sendRequestButton");
        Object notNowButtonObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "notNowButton");

        String expectedFormTitle = formTitleObj != null ? formTitleObj.toString() : "";
        String expectedMessage = messageTemplateObj != null ? messageTemplateObj.toString().replace("{dependentFirstName}", dependentFirstName) : "";
        String expectedRequestHeader = requestHeaderObj != null ? requestHeaderObj.toString() : "";
        String expectedSendRequestButton = sendRequestButtonObj != null ? sendRequestButtonObj.toString() : "";
        String expectedNotNowButton = notNowButtonObj != null ? notNowButtonObj.toString() : "";
        String expectedFullName = dependentFirstName + " " + dependentLastName;

        navigateToPharmacyAccountSettings();
        pharmacyAccountSettingsPage.clickManagePermissionsOption();
        Reporter.log("Navigated to Manage Permissions screen");
        Assert.assertTrue(managePermissionsPage.isManagePermissionsScreenDisplayed(),
                "Manage Permissions screen should be displayed");
        managePermissionsPage.clickDependentDeliveryEnable();
        Assert.assertTrue(managePermissionsPage.isAllDeliveryEnableRequestFormContentDisplayed(),
                "All delivery enable request form content should be displayed");
        verifyDeliveryEnableRequestFormContent(expectedFormTitle, expectedMessage, expectedRequestHeader, expectedFullName, dependentEmail, expectedSendRequestButton, expectedNotNowButton);
        managePermissionsPage.clickCancelRequest();
        Reporter.log("Cancelled form (Not now); reopening form");
        managePermissionsPage.clickDependentDeliveryEnable();
        Assert.assertTrue(managePermissionsPage.isAllDeliveryEnableRequestFormContentDisplayed(),
                "All delivery enable request form content should be displayed after reopening");
        verifyDeliveryEnableRequestFormContent(expectedFormTitle, expectedMessage, expectedRequestHeader, expectedFullName, dependentEmail, expectedSendRequestButton, expectedNotNowButton);
        managePermissionsPage.clickSendRequest();
        Reporter.log("Dependent delivery enable request sent successfully");
        Assert.assertTrue(managePermissionsPage.isPendingDeliveryApprovalDisplayed(),
                "Pending delivery approval should be displayed on Manage Permissions list after request sent");
    }

    /**
     * Verifies delivery enable request form (ecom request) content: static text from translations, dynamic from test data.
     */
    private void verifyDeliveryEnableRequestFormContent(String expectedFormTitle, String expectedMessage, String expectedRequestHeader,
                                                        String expectedFullName, String expectedEmail, String expectedSendRequestButton, String expectedNotNowButton) {
        Assert.assertEquals(normalizeText(managePermissionsPage.getDeliveryEnableFormTitleText()), normalizeText(expectedFormTitle), "Delivery enable form title mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getDeliveryEnableFormBodyText()), normalizeText(expectedMessage), "Delivery enable form message body mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getDeliveryEnableRequestHeaderText()), normalizeText(expectedRequestHeader), "Delivery enable form request header mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getDeliveryEnableFormFullNameText()), normalizeText(expectedFullName), "Delivery enable form full name mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getDeliveryEnableFormEmailText()), normalizeText(expectedEmail), "Delivery enable form email mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getSendRequestButtonText()), normalizeText(expectedSendRequestButton), "Send request button text mismatch");
        Assert.assertEquals(normalizeText(managePermissionsPage.getCancelRequestButtonText()), normalizeText(expectedNotNowButton), "Not now button text mismatch");
        Reporter.log("Verified delivery enable request form content (translations + test data)");
    }

    public void navigateToEcommCartAndValidateRx(String itemCount) {
        openToEcommCart();
        String expectedCartTitle = Integer.parseInt(itemCount) > 1
                ? "(" + itemCount + " items)"
                : "(" + itemCount + " item)";
        Assert.assertTrue(ecommCartPage.getEcommCartTitle().contains(expectedCartTitle),
                "Ecomm cart title should contain: " + expectedCartTitle);
        Assert.assertTrue(ecommCartPage.verifyPrescriptionListEleForRX(),
                "Prescription item badge should be visible in ecomm cart");
        String insuranceText = ecommCartPage.getInsuranceTitleTextForRx();
        Assert.assertNotNull(insuranceText, "Insurance text should not be null in ecomm cart");
        Reporter.log("Ecomm cart validation passed - cart title: " + expectedCartTitle
                + ", prescription badge visible, insurance text: " + insuranceText);
    }

    public void goBackFromEcommCart() {
        ecommCartPage.clickBackButton();
        Reporter.log("Navigated back from ecomm cart to Pharmacy Dashboard");
    }

    public void removeRxFromCartViaDecrementButton() {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnDecreaseQuantityBtn();
        Reporter.log("Clicked the '-' (decrease quantity) button on the ATC card to remove Rx from cart");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isAddToCartButtonVisible(),
                "ATC card should revert to 'Add to cart' after removing Rx from cart");
        Reporter.log("Rx successfully removed from cart - 'Add to cart' button is now visible on the ATC card");
    }

    /**
     * Dismisses any stale ecom rejection/cancelled nudge on the pharmacy dashboard if present.
     * Safe no-op when no nudge is visible (e.g., first run). Used at the start of a test to
     * clear leftover state from previous runs.
     */
    public void dismissEcomRejectionNudgeIfPresent() {
        try {
            if (pharmacyDashboardPage.isRequestRejectedOrCancelledNudgeVisible()) {
                Reporter.log("Stale rejection nudge detected — dismissing before starting test flow");
                pharmacyDashboardPage.clickDismissNudge();
                Reporter.log("Stale rejection nudge dismissed");
            } else {
                Reporter.log("No stale rejection nudge found — proceeding");
            }
        } catch (Exception e) {
            Reporter.log("WARNING: Could not check/dismiss rejection nudge (non-fatal): " + e.getMessage());
        }
    }

    /**
     * Validates the "Permission needed for prescription delivery" bottom sheet that appears
     * when a caregiver clicks Add to Cart on a dependent's delivery-eligible prescription.
     * Verifies all content: visibility of all elements, static text (form title, message body,
     * request header, button labels) sourced from translations, and dynamic data (dependent
     * full name and email) from test data.
     *
     * @param dependentFirstName  expected dependent first name shown on the bottom sheet
     * @param dependentLastName   expected dependent last name shown on the bottom sheet
     * @param dependentEmail      expected dependent email shown on the bottom sheet
     */
    public void validatePermissionNeededForDeliveryModal(String dependentFirstName, String dependentLastName, String dependentEmail) {
        Assert.assertTrue(managePermissionsPage.isAllDeliveryEnableRequestFormContentDisplayed(),
                "Permission needed for prescription delivery modal should be fully displayed");

        Object formTitleObj        = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "formTitle");
        Object messageTemplateObj  = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "messageTemplate");
        Object requestHeaderObj    = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "requestHeader");
        Object sendRequestButtonObj = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "sendRequestButton");
        Object notNowButtonObj     = textValidationUtils.getKeyInObject("deliveryEnableRequestForm", "notNowButton");

        String expectedFormTitle       = formTitleObj != null ? formTitleObj.toString() : "";
        String expectedMessage         = messageTemplateObj != null ? messageTemplateObj.toString().replace("{dependentFirstName}", dependentFirstName) : "";
        String expectedRequestHeader   = requestHeaderObj != null ? requestHeaderObj.toString() : "";
        String expectedSendRequestBtn  = sendRequestButtonObj != null ? sendRequestButtonObj.toString() : "";
        String expectedNotNowBtn       = notNowButtonObj != null ? notNowButtonObj.toString() : "";
        String expectedFullName        = dependentFirstName + " " + dependentLastName;

        verifyDeliveryEnableRequestFormContent(expectedFormTitle, expectedMessage, expectedRequestHeader,
                expectedFullName, dependentEmail, expectedSendRequestBtn, expectedNotNowBtn);

        Reporter.log("ASSERT: 'Permission needed for prescription delivery' modal — all content validated. "
                + "Recipient: " + expectedFullName + " / " + dependentEmail);
    }

    /**
     * Sends the ecomm delivery enable request from the "Permission needed for prescription delivery"
     * bottom sheet (triggered via caregiver's ATC on dependent Rx). Clicks "Send request" and validates
     * that "Pending delivery approval" label is visible on the ATC card afterwards.
     */
    public void sendEcommDeliveryRequestAndValidatePendingOnATCCard() {
        managePermissionsPage.clickSendRequest();
        Reporter.log("Clicked 'Send request' on Permission needed for prescription delivery modal");
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isPendingDeliveryApprovalOnATCCardVisible(),
                "'Pending delivery approval' label should be visible on the ATC card after sending request");
        Reporter.log("ASSERT: 'Pending delivery approval' confirmed on ATC card after request sent");
    }

    /**
     * Validates that the ecom delivery-enable request nudge ("You have a pending request") is visible
     * on the dependent's pharmacy dashboard after the caregiver sent the request.
     *
     * @param caregiverFirstName  caregiver's first name (used for log context only)
     * @param caregiverLastName   caregiver's last name (used for log context only)
     */
    public void validateEcomRequestNudgeOnDependentDashboard(String caregiverFirstName, String caregiverLastName) {
        Assert.assertTrue(pharmacyDashboardPage.isEcomPendingRequestNudgeVisible(),
                "'You have a pending request' ecom nudge should be visible on dependent's pharmacy dashboard");
        Reporter.log("ASSERT: Ecom delivery-enable request nudge is visible on dependent dashboard "
                + "— caregiver: " + caregiverFirstName + " " + caregiverLastName);
    }

    /**
     * Validates that the caregiver ecom request nudge is NOT visible on the pharmacy dashboard.
     * Used after the dependent accepts the ecomm consent form to confirm the nudge has been cleared.
     */
    public void validateCaregiverRequestNudgeNotVisible() {
        Assert.assertFalse(pharmacyDashboardPage.isEcomPendingRequestNudgeVisible(),
                "'You have a pending request' nudge should NOT be visible on dashboard after consent accepted");
        Reporter.log("ASSERT: Caregiver ecom request nudge is NOT visible on pharmacy dashboard");
    }

    /**
     * Validates that the request rejected / cancelled nudge is visible on the caregiver's pharmacy
     * dashboard after the dependent revokes ecom consent.
     *
     * @param dependentFirstName  dependent's first name (used for log context)
     */
    public void validateRequestCancelledNudgeVisible(String dependentFirstName) {
        Assert.assertTrue(pharmacyDashboardPage.isRequestRejectedOrCancelledNudgeVisible(),
                "Request rejected/cancelled nudge should be visible on caregiver's dashboard after dependent revokes consent");
        Reporter.log("ASSERT: Request rejected/cancelled nudge visible on caregiver dashboard — dependent: " + dependentFirstName);
    }

    public void revokeAccountHolderEcommConsent() {
        Assert.assertTrue(managePermissionsPage.isManagePermissionsScreenDisplayed(),
                "Manage Permissions screen should be displayed before revoking ecomm consent");
        Assert.assertTrue(managePermissionsPage.isAccountHolderConsentEnabled(),
                "Account holder ecomm consent toggle should be ON before revoking");
        managePermissionsPage.clickAccountHolderConsentToggle();
        Reporter.log("Clicked account holder consent toggle - revoke confirmation dialog should appear");
        managePermissionsPage.confirmRevokeEcommConsent();
        Assert.assertTrue(managePermissionsPage.isAccountHolderConsentDisabled(),
                "Account holder ecomm consent toggle should be OFF after confirming revocation");
        Reporter.log("Ecomm consent revoked - toggle is now OFF for account holder");
    }

    public void navigateToManagePermissionsAndRevokeEcommConsent() {
        navigateToPharmacyAccountSettings();
        Assert.assertTrue(pharmacyAccountSettingsPage.isAccountSettingsScreenDisplayed(),
                "Pharmacy Account Settings screen should be displayed");
        pharmacyAccountSettingsPage.clickManagePermissionsOption();
        Reporter.log("Navigated to Manage Permissions screen");
        revokeAccountHolderEcommConsent();
    }

    public void navigateToManageFamilyMembers() {
        pharmacyDashboardPage.navigateToManageFamilyMembers();
    }

    /**
     * Remove all family members and cancel pending requests after family addition
     * @param minorName - Name of minor to remove (e.g., "Aarav Patel")
     * @param petName - Name of pet to remove (e.g., "Simba")
     * @param adultName - Name of adult to cancel request (e.g., "Rajesh P***")
     */
    public void removeFamilyMembersAfterAddition(String minorName, String petName, String adultName) {
        try {
            // Remove minor
            if (minorName != null && !minorName.isEmpty()) {
                manageFamilyMembersPage.removeFamilyMemberByName(minorName);
                Reporter.log("Removed minor: " + minorName);
            }
            
            // Remove pet
            if (petName != null && !petName.isEmpty()) {
                manageFamilyMembersPage.removeFamilyMemberByName(petName);
                Reporter.log("Removed pet: " + petName);
            }
            
            // Cancel request for adult
            if (adultName != null && !adultName.isEmpty()) {
                manageFamilyMembersPage.cancelRequestForAdultByName(adultName);
                Reporter.log("Cancelled request for adult: " + adultName);
            }
            
            Reporter.log("Successfully removed all family members");
        } catch (Exception e) {
            Reporter.log("Failed to remove family members: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Navigate back to Pharmacy Dashboard from Manage family members screen
     */
    public void navigateBackToPharmacyDashboardFromFamilyScreen() {
        manageFamilyMembersPage.navigateBackToPharmacyDashboard();
    }

    /**
     * Select a specific family member by name from the SMS family addition list
     * Delegates to SMSFamilyAdditionPage which handles finding and clicking the element
     * 
     * @param familyMemberName - Name of family member to select (e.g., "Aarav P***")
     */
    public void selectFamilyMemberByName(String familyMemberName) {
        smsFamilyAdditionPage.selectFamilyMemberByName(familyMemberName);
    }

    /**
     * Select and add all family members with DOB entry
     * Reusable method for SMS family addition flow
     * 
     * @param minorDob - DOB for minor (mmddyyyy), null if no minor
     * @param hasPet - true if pet exists
     * @param adultDob - DOB for adult (mmddyyyy), null if no adult
     */
    public void selectAndAddFamilyMembersWithDOB(String minorDob, boolean hasPet, String adultDob) {
        Reporter.log("Starting family member selection and DOB entry...");
        
        // Select all family members and add
        smsFamilyAdditionPage.selectAllFamilyMembers();
        smsFamilyAdditionPage.clickAddSelectedMembers();

        // Enter DOBs and confirmations
        if (minorDob != null && !minorDob.isEmpty()) {
            Reporter.log("Entering DOB for minor: " + minorDob);
            smsFamilyAdditionPage.enterDobForFamilyMember(minorDob);
            smsFamilyAdditionPage.clickConfirmDob();
        }
        
        if (hasPet) {
            Reporter.log("Confirming pet ownership");
            smsFamilyAdditionPage.confirmPetOwnership();
            smsFamilyAdditionPage.clickConfirmDob();
        }
        
        if (adultDob != null && !adultDob.isEmpty()) {
            Reporter.log("Entering DOB for adult: " + adultDob);
            smsFamilyAdditionPage.enterDobForFamilyMember(adultDob);
            smsFamilyAdditionPage.clickConfirmDob();
        }
        
        Reporter.log("Family member selection and DOB entry completed");
    }

    /**
     * Complete SMS family addition flow with validation
     * Handles selection of all family members, DOB entry, pet confirmation, and validates confirmation screen
     * 
     * @param minorDob - DOB for minor (mm/dd/yyyy), null if no minor
     * @param hasPet - true if pet exists
     * @param adultDob - DOB for adult (mm/dd/yyyy), null if no adult
     * @param caregiverName - Account holder name
     * @param minorName - Minor name, null if no minor
     * @param petName - Pet name, null if no pet
     * @param adultName - Adult name, null if no adult
     * @return true if successful, false otherwise
     */
    public boolean completeSMSFamilyAdditionWithValidation(String minorDob, boolean hasPet, String adultDob,
                                                            String caregiverName, String minorName, String petName, String adultName) {
        try {
            // Use reusable method for family member selection and DOB entry
            selectAndAddFamilyMembersWithDOB(minorDob, hasPet, adultDob);

            smsFamilyAdditionPage.waitForMobilePageToLoad(10, true);

            // Validate confirmation screen
            Assert.assertTrue(smsFamilyAdditionPage.isConfirmationScreenDisplayed(), "Confirmation screen not displayed");
            Assert.assertEquals(smsFamilyAdditionPage.getConfirmationTitle(), "You're connected!", "Confirmation title mismatch");
            
            // Validate family members in correct sections
            if (caregiverName != null) {
                Assert.assertTrue(smsFamilyAdditionPage.isMemberInAccountHolderSection(caregiverName),
                        "Account holder '" + caregiverName + "' not found in Account holder section");
            }
            if (minorName != null) {
                Assert.assertTrue(smsFamilyAdditionPage.isMemberInAddedProfilesSection(minorName),
                        "Minor '" + minorName + "' not found in Added profiles section");
            }
            if (petName != null) {
                Assert.assertTrue(smsFamilyAdditionPage.isMemberInAddedProfilesSection(petName),
                        "Pet '" + petName + "' not found in Added profiles section");
            }
            if (adultName != null) {
                Assert.assertTrue(smsFamilyAdditionPage.isMemberInPendingSection(adultName),
                        "Adult '" + adultName + "' not found in Pending section (awaiting acceptance)");
            }

            // Complete flow
            smsFamilyAdditionPage.clickDoneOnConfirmationScreen();
            pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
            
            Reporter.log("SMS Family Addition completed successfully");
            return true;
        } catch (Exception e) {
            Reporter.log("SMS Family Addition failed: " + e.getMessage());
            return false;
        }
    }

    public boolean completeSMSFamilyAddition(String minorDob, boolean hasPet, String adultDob) {
        try {
            // Use reusable method for family member selection and DOB entry
            selectAndAddFamilyMembersWithDOB(minorDob, hasPet, adultDob);

            smsFamilyAdditionPage.waitForMobilePageToLoad(10, true);

            return true;
        } catch (Exception e) {
            Reporter.log("SMS Family Addition failed: " + e.getMessage());
            return false;
        }
    }

    public void validateMultipleProfile(String otp) {
        Object multipleProfilesFoundAlertText = textValidationUtils.getKeyInObject("smsAccountCreation", "smsAccountCreationFlow", "multipleProfilesPageAlertHeader");
        connectMyAccount.sendOTP(otp);
        connectMyAccount.clickOtpAcceptCTA();
        Assert.assertTrue(connectMyAccount.primaryProfileHeader.isDisplayed());
        Assert.assertTrue(connectMyAccount.connectedProfileList().size() > 1, "Multiple profiles are not connected to the phone number");
        Assert.assertFalse(connectMyAccount.isAnyProfileEnabled(), "Profiles should not be selected by default");
        connectMyAccount.clickContinueForProfileCTA();
        Assert.assertEquals(connectMyAccount.selectProfileAlertText(), multipleProfilesFoundAlertText, "Alert message mismatch");
        connectMyAccount.selectProfileFromList();
        connectMyAccount.clickContinueForProfileCTA();
        Assert.assertTrue(connectMyAccount.dobPageHeader.isDisplayed(), "DOB page is not displayed");
    }

    public void validateLinkedProfileFoundScenario(String otp) {
        Object verifyIdentitySubHeaderText = textValidationUtils.getKeyInObject("smsAccountCreation", "smsAccountCreationFlow", "linkedProfileFoundPageVerifyIdentitySubHeader");
        connectMyAccount.sendOTP(otp);
        connectMyAccount.clickOtpAcceptCTA();
        Assert.assertTrue(connectMyAccount.linkedProfileFoundHeader.isDisplayed());
        Assert.assertEquals(connectMyAccount.getValidateIdentityText(), verifyIdentitySubHeaderText, "Linked profile found message mismatch");
        connectMyAccount.clickContinueForProfileCTA();
        Assert.assertTrue(connectMyAccount.dobPageHeader.isDisplayed(), "DOB page is not displayed");
    }

    public void navigateToWalmartPharmacy() {
    }

    public void verifyInsuranceNudgeAndClickAddInsurance(String type, String patientName) {
        Object insuranceNudgeTitle = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "insuranceNudgeDFDScreen", "nudgeTitle");
        Object insuranceNudgeDesc = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "insuranceNudgeDFDScreen", "nudgeDescription");
        if (type.equalsIgnoreCase("Self"))
            Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeTitle(), insuranceNudgeTitle, "Insurance Nudge Title is Incorrect");
        else
            Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeTitleForDependent(patientName), insuranceNudgeTitle.toString().replace("your", patientName + "’s"), "Insurance Nudge Title is Incorrect");

        Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeDescription(), insuranceNudgeDesc, "Insurance Nudge Description Text is Incorrect");
        pharmacyDashboardPage.clickAddInsuranceCTA();
    }

    public void verifyReviewAndManageInsuranceCard() {
        Object cardTitle = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "reviewAndManageInsurance", "titleHeader");
        Object cardDesc = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "reviewAndManageInsurance", "titleDescription");
        Assert.assertEquals(connectMyAccountSuccessScreen.getInsCardTitleHeader(), cardTitle, "Review and Update Insurance Card Title is Incorrect");
        Assert.assertEquals(connectMyAccountSuccessScreen.getInsCardDescription(), cardDesc, "Review and Update Insurance Card Description Text is Incorrect");
        connectMyAccountSuccessScreen.clickAccountConnectedDonePrimaryButton();
    }

    public void clickPharmacySuccessScreenManageInsurance() {
        connectMyAccountSuccessScreen.clickManageInsuranceCTA();
        Assert.assertEquals(manageInsurancePage.getManageInsuranceScreenTitle(), "Manage my prescription insurance", "Manage Insurance Header Title is Incorrect");
    }

    public void verifyRxDetailsInEcommCart(String itemCount, String expectedInsuranceTitle) {
        String expectedCartTitle = "";
        if (Integer.parseInt(itemCount) > 1) expectedCartTitle = "(" + itemCount + " items)";
        else expectedCartTitle = "(" + itemCount + " item)";
        Assert.assertTrue(ecommCartPage.getEcommCartTitle().contains(expectedCartTitle));
        Assert.assertEquals(ecommCartPage.getInsuranceTitleTextForRx(), expectedInsuranceTitle);
        Assert.assertEquals(ecommCartPage.getDeliveryOnlyBadgeTextForRx(), "Delivery only");
        Assert.assertEquals(ecommCartPage.getDeliverySectionTitle(), "Delivery from store");
        Assert.assertTrue(ecommCartPage.verifyPrescriptionListEleForRX());
        Reporter.log("Verified insurance title, prescription list badge, delivery badge, cart items count in ecomm cart page");
    }

    public void verifyGroceryDetailsInEcommCart(String item, boolean removeItem) {
        String getGroceryText = ecommCartPage.getNonRxItemText(item);
        Assert.assertEquals(getGroceryText, item);
        Reporter.log("Verified non-RX item details in ecomm cart page");

        if (removeItem) {
            ecommCartPage.removeNonRxItem();
            Reporter.log("Successfully removed non-RX item from cart");
        }
    }

    public void removeRxFromEcommCart() {
        ecommCartPage.removeRxItemFromCart();
        ecommCartPage.confirmRemoveFromCart();
        Reporter.log("RX item successfully removed from cart");
    }

    public void removeNonRxItemFromEcommCart() {
        ecommCartPage.removeNonRxItem();
        Reporter.log("Non RX item successfully removed from cart");
    }

    public void enterEmailOtpAndSetupPin() {
        //pinCreationPages.emailOptNeeded(otp);
        pinCreationPages.setPin();
        pinCreationPages.clickVerifyPinButton();
        // pinCreationPages.clickPinSuccessContinueButton();
    }

    public void isIncreaseRxQuantityButtonDisabled() {
        rxReadyForPickupAndDeliveryTrackerCardPage.isIncreaseRxQuantityButtonDisabled();
    }

    public void clickDecreaseRxQuantityButton() {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickDecreaseRxQuantityButton();
    }

    public String getCurbsideError() {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickClosButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnAddCartButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnTheDeliveryAddressButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickPickupInstead();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnTheDeliveryAddressButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnPickupIcon();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnTheDeliveryAddressButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnViewAllTimesOption();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickRadiobutton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnPickup();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickRadiobutton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickReserveButton();
        rxReadyForPickupAndDeliveryTrackerCardPage.clickOnAddCartButton();
        return rxReadyForPickupAndDeliveryTrackerCardPage.errorMessageCurbside();
    }

    public void renavigateToEcommCart() {
        ecommCartPage.clickBackButton();
        Reporter.log("Navigating back to Pharmacy Dashboard Page");
        homePage.clickServicesButton();
        pharmacyDashboardPage.clickPharmacyServicesButton();
        pharmacyDashboardPage.proceedToEcommCart();
        Reporter.log("Successfully Navigated Back to Ecomm Cart");
    }

    public Boolean verifyCartIsEmpty() {
        try {
            orderDetailsPage.refreshPage();
            Object cartIsEmptyText = textValidationUtils.getKeyInObject("ecommCartPage", "cartIsEmptyText");
            Assert.assertEquals(ecommCartPage.getCartIsEmptyText(), cartIsEmptyText.toString(), "Cart Empty Text Has Changed or Cart Has Items, please report");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } catch (AssertionError arr) {
            arr.printStackTrace();
            return false;
        }
    }

    public void addMultiplePrescriptionsToCart(int numberOfRxsToAdd) throws Exception {
        rxReadyForPickupAndDeliveryTrackerCardPage.addNItemsToCart(numberOfRxsToAdd);
        Reporter.log("Clicked addToCart CTA for prescriptions which are ready for pickup");
    }

    public void verifyEcommCartWithMultiplePrescriptions(int expectedNumberOfRxs, int itemCount) throws Exception {
        String expectedCartTitle = itemCount > 1 ? "(" + itemCount + " items)" : "(" + itemCount + " item)";
        ecommCartPage.waitForLoadingToDisappear(10);
        Assert.assertEquals(ecommCartPage.getEcommCartTitle(), expectedCartTitle, "There are more/less items in cart than expected, please report");
        Assert.assertEquals(ecommCartPage.getNumberOfPrescriptionsInCart(), expectedNumberOfRxs, "There are more/less prescriptions in cart than expected, please report");
    }

    public void proceedToCheckoutRxsAddedToCart(String cvvNumber, Boolean isDiscardCheckout, Boolean isPlaceOrder, Boolean isExpressEvergreenSlot, boolean... isSODNeeded) throws Exception {
        homePage.clickPersonalisationChoiceButton();
        orderCheckoutPage.clickContinueToCheckout();
        orderCheckoutPage.clickStoreDeliveryCTA();
        orderCheckoutPage.selectSlot(isExpressEvergreenSlot);
        orderCheckoutPage.clickConfirmAddressContinueButton();
        orderCheckoutPage.clickBookSlotContinueButton();
        orderCheckoutPage.clickNoThanksButtonForMembers();
        homePage.clickPersonalisationChoiceButton();
        orderCheckoutPage.clickWalmartPlusMembershipPopupDeclineButton();
        orderCheckoutPage.enterCVVNumber(cvvNumber);

        // Commenting this because this is needed exactly once and the preference is saved
        /*boolean isDeliverySignatureNeeded = (isSODNeeded.length >= 1) ? isSODNeeded[0] : false;

        if (isDeliverySignatureNeeded) {
            orderCheckoutPage.clickSignOnDeliveryCTA();
        }*/

        if (isPlaceOrder) orderCheckoutPage.clickPlaceOrderCTA();
        else if (isDiscardCheckout) this.discardCheckoutProcess();
    }

    public void discardCheckoutProcess() {
        orderCheckoutPage.clickNavigateBackButton();
        orderCheckoutPage.clickLeaveAnywayButton();
    }

    public String getPlatform() {
        return this.platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String verifyCheckoutSuccessAndGetOrderId(String customerName) {
        homePage.clickPersonalisationChoiceButton();
        Object orderConfirmedText = textValidationUtils.getKeyInObject("orderConfirmationPage", "orderConfirmedPartialText");
        Assert.assertEquals(orderConfirmationPage.getOrderIsConfirmedHeaderText().toLowerCase(), (customerName + orderConfirmedText.toString()).toLowerCase(), "Order Confirmation Text is incorrect");
        return orderConfirmationPage.getOrderNumber();
    }

    public void verifyPrescriptionNotAvlForDeliveryErrorText() {
        Object prescriptionNotAvlForDeliveryErrorText = textValidationUtils.getKeyInObject("ecommCartPage", "prescriptionNotAvlForDeliveryTxt");
        Assert.assertEquals(ecommCartPage.getPrescriptionNotAvlForDeliveryText(), prescriptionNotAvlForDeliveryErrorText.toString(), "Prescription delivery not available text is not visible, please report");
    }

    public void clickViewDetailsLinkCTA() {
        ecommCartPage.clickOnViewDetailsLink();
    }

    public void verifyRxCannotBeDeliveredToAddressErrorText() {
        Object rxCannotBeDeliveredToAddressErrorText = textValidationUtils.getKeyInObject("ecommCartPage", "rxCannotBeDeliveredToAddressErrorText");
        String rxCannotBeDeliveredToAddressActualErrorText = ecommCartPage.getPrescriptionCannotBeDeliveredText().toString().replace("\n", " ");
        Assert.assertTrue(rxCannotBeDeliveredToAddressActualErrorText.contains(rxCannotBeDeliveredToAddressErrorText.toString()), "This prescription can’t be delivered to your selected address text is not visible, please report");
    }

    public void clickGotItButton() {
        ecommCartPage.clickGotItButton();
    }

    public void clickPromoCodeChevronButton() {
        ecommCartPage.clickPromoCodeChevronButton();
    }

    public void enterPromoCode() {
        ecommCartPage.inputPromoCode();
    }

    public void applyPromoCode() {
        ecommCartPage.clickApplyPromoCodeButton();
    }

    public void getPromoCodeErrorText() {
        Object promoCodeErrorText = textValidationUtils.getKeyInObject("ecommCartPage", "promoCodeErrorText");
        Assert.assertEquals(ecommCartPage.getPromoCodeErrorText(), promoCodeErrorText.toString(), "Promo code error is not visible");
    }

    public void checkMinimumBasketFeeIsZero() {
        Assert.assertTrue(orderCheckoutPage.getMinimumBasketFee().contains("$0"), "Minimum Basket Fee is Not 0");
    }

    public void selectPrimaryProfileForTransfer() {
        getTransferStartedPage.clickPrimaryProfileOption();
        prescriptionsToTransferDetailsPage.clickContinueButton();
        Reporter.log("Verified that Account is Connected to Pharmacy");
    }

    /**
     * Select family member profile for competitive transfer by name
     * Note: Override this method in platform-specific managers (AndroidPageManager, IOSPageManager) 
     * ONLY if the implementation differs for that platform. 
     * If iOS implementation is the same, keep only this base implementation.
     * 
     * @param familyMemberName - Name of family member to select (e.g., "Jolene Fox")
     */
    public void selectFamilyMemberForTransfer(String familyMemberName) {
        // Select specific family member profile by name using Page Object
        getTransferStartedPage.selectFamilyMemberByName(familyMemberName);
        getTransferStartedPage.clickContinueButton();
        Reporter.log("Selected family member for transfer: " + familyMemberName);
    }

    public void verifyAccountUnconnected() {
        Assert.assertTrue(pharmacyDashboardPage.isConnectMyAccountCTAPresent(), "Connect My Account CTA is missing - please check the account Details");
        Object accountUnconnectedHeaderExpectedText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "accountUnconnectedHeaderText");
        Assert.assertEquals(pharmacyDashboardPage.getAccountUnconnectedHeaderText(), accountUnconnectedHeaderExpectedText.toString(), "Header Text For Unconnected Account Is Incorrect, Please Report");
        Reporter.log("Verified that Account is Not Connected to Pharmacy");
    }

    public void fillPatientDetailsForCompetitiveTransfer(String firstName, String lastName, String dob, String gender, String stateCode, String phoneNumber) {
        prescriptionHolderDetailsFormPage.enterFirstName(firstName);
        prescriptionHolderDetailsFormPage.enterLastName(lastName);
        prescriptionHolderDetailsFormPage.enterDob(dob);
        prescriptionHolderDetailsFormPage.enterGender(gender);
        prescriptionHolderDetailsFormPage.enterAddressLine1(StoreConfig.addressLine1);
        prescriptionHolderDetailsFormPage.enterZipCode(StoreConfig.zipCode);
        prescriptionHolderDetailsFormPage.enterCity(StoreConfig.city);
        prescriptionHolderDetailsFormPage.enterState(stateCode);
        prescriptionHolderDetailsFormPage.enterPhoneNumber(phoneNumber);
        prescriptionHolderDetailsFormPage.clickContinueButton();
    }

    public void transferPrescriptionForMyself() { getTransferStartedPage.clickTransferForMyselfBtn(); }

    public void transferPrescriptionForSomeoneElse(){ getTransferStartedPage.clickTransferForSomeoneElseBtn(); }

    public String selectAndGetFirstAvailableCompetitorStoreDetails(String destinationStoreNumber) {
        String sourceStoreZipCode = locationServiceUtils.getStoreZipCode(destinationStoreNumber);
        selectSourceStorePage.clickDenyLocationPermission();
        selectSourceStorePage.enterSourceStoreZip(sourceStoreZipCode);
        selectSourceStorePage.clickContinueButton();
        selectSourceStorePage.clickFirstAvailableSourceStore();
        String sourceStoreNameText = selectSourceStorePage.getFirstSourceStoreNameText();
        selectSourceStorePage.clickContinueButton();
        return sourceStoreNameText;
    }

    // Overload added to support platforms (iOS) that need both sourcePharmacyName and zipCode
    // to locate the source pharmacy (iOS requires a zip-code search before filtering by name).
    // Android ignores zipCode and delegates to its own one-argument override via polymorphism,
    // so existing Android behaviour and other callers are not affected.
    public String selectAndGetFirstAvailableCompetitorStoreDetails(String sourcePharmacyName, String zipCode) {
        return selectAndGetFirstAvailableCompetitorStoreDetails(sourcePharmacyName);
    }

    public void selectDestinationStore(String storeId) {
        selectDestinationStorePage.selectDestinationStoreByStoreNumber(storeId);
        selectDestinationStorePage.clickContinueButton();
    }

    public void addPrescriptionToTransfer(String drugName, String rxNbr, Boolean addInsurance, Boolean skipInsurance) {
        inputTransferRxDetailsPage.enterDrugName(drugName);
        inputTransferRxDetailsPage.enterPrescriptionNumber(rxNbr);
        prescriptionHolderDetailsFormPage.clickDoneButtonForIOSKeyboard();
        inputTransferRxDetailsPage.clickAddEnteredPrescription();
        Assert.assertEquals(prescriptionsToTransferDetailsPage.getRxNoToTransfer(), "Rx# " + rxNbr, "Mismatch in RxNbr");
        Assert.assertEquals(prescriptionsToTransferDetailsPage.getDrugNameToTransfer(), drugName, "drug Name Mismatch");
        prescriptionsToTransferDetailsPage.clickContinueButton();

        if (!skipInsurance) {
            if (addInsurance) prescriptionsToTransferDetailsPage.clickFindMyInsurance();
            else prescriptionsToTransferDetailsPage.clickSkipInsurance();
        }
    }

    public void reviewCtOrderDetailsAndPlaceOrder(String patientName, String sourcePharmacyStoreName, String destinationStoreNumber, String drugName, String rxNbr) {
        reviewTransferRequestPage.waitForLoadingToDisappear(5);
        Assert.assertEquals(reviewTransferRequestPage.getUserNameText().toLowerCase(), patientName.toLowerCase(), "Patient Name Mismatch");
        String sourcePharmacyName = sourcePharmacyStoreName.split(locationServiceUtils.getStoreZipCode(destinationStoreNumber))[0];
        Assert.assertTrue(reviewTransferRequestPage.getTransferFromPharmacyName().toLowerCase().contains(sourcePharmacyName.trim().toLowerCase()), "Transfer From Pharmacy Store Name Incorrect");
        Assert.assertEquals(reviewTransferRequestPage.getDrugName().toLowerCase(), drugName.toLowerCase(), "drug Name Mismatch");
        Assert.assertEquals(reviewTransferRequestPage.getRxNbr(), "Rx# " + rxNbr, "Rx Nbr Mismatch");
        reviewTransferRequestPage.clickRequestTransferButton();
    }

    public void checkCompetitiveTransferSuccess(String patientName) {
        reviewTransferRequestPage.waitForLoadingToDisappear(5);
        Object orderSuccessPageHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageHeader");
        Object orderSuccessPageSubHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageSubHeader");
        Object ctTrackerCardHeading = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "competitiveTransferTrackerCard", "competitiveTransferCardHeading");
        Assert.assertEquals(transferRequestSuccessPage.getTransferRequestSuccessHeading(), orderSuccessPageHeader.toString(), "Ct Transfer Success Page Heading Mismatch");
        Assert.assertEquals(transferRequestSuccessPage.getPharmacistWillContactSubheading(), orderSuccessPageSubHeader, "Ct Transfer Success Page Subheading Mismatch");
        transferRequestSuccessPage.closeCurrentViewAndNavigateToPharmacy();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
        Assert.assertEquals(competitiveTransferTrackerCardPage.getCtCardHeaderText(), ctTrackerCardHeading.toString(), "Card Header Text Mismatch");
        Assert.assertEquals(competitiveTransferTrackerCardPage.getUserNameText().toLowerCase(), patientName.toLowerCase(), "Patient UserName Incorrect");
    }

    public void verifyMinOrderFeeWaivedForPrescriptionsText() {
        Object minOrderFeeWaivedForPrescriptionsText = textValidationUtils.getKeyInObject("ecommCartPage", "minOrderFeeWaivedForPrescriptionsText");
        Assert.assertEquals(orderCheckoutPage.getBelowMinOrderWaivedFeeForPrescriptionsText(), minOrderFeeWaivedForPrescriptionsText.toString(), "Below order minimum fee waived off for prescriptions text is not visible");

        Object minOrderFeeWaivedForPrescriptionsValue = textValidationUtils.getKeyInObject("ecommCartPage", "minOrderFeeWaivedForPrescriptionsValue");
        Assert.assertEquals(orderCheckoutPage.getBelowMinOrderWaivedFeeForPrescriptionsValue(), minOrderFeeWaivedForPrescriptionsValue.toString(), "Below order minimum fee waived off for prescriptions value is not visible");
    }

    public void clickOnHowYouWantYourItemsDownChevron() {
    }

    public void selectDeliveryFromStoreAddress() {
    }

    public void verifyItemErrorDetailsText(String expectedText) {
    }


    public void enterZipCodeOrCityState(String zipCode) {
    }

    public void clickViewDetailsButton() {
    }

    public void verifyItemUpdatesText(String itemUpdatesText) {
    }

    public void setDeliveryFromStore(String storeID, String zipCode) {
    }

    public void changeDeliveryToAddress(String AddressID) {
    }

    public void cancelOrderFromDotCom() {
//        orderConfirmationPage.clickViewDetailsButton();
        orderConfirmationPage.clickAccountCta();
        orderConfirmationPage.clickPurchaseHistoryCta();
        orderConfirmationPage.clickFirstOrderViewDetails();
        orderDetailsPage.clickCancelOrderButton();
        orderDetailsPage.clickWrongPaymentMethodCancellationReason();
        orderDetailsPage.clickConfirmCancellationButton();
    }

    public Boolean verifyOrderCancellationFromBE() {
        try {
            orderDetailsPage.refreshPage();
            Object orderSuccessFullyCanceledIndicatorText = textValidationUtils.getKeyInObject("orderDetailsPage", "orderCanceledHeadertext");
            Assert.assertEquals(orderDetailsPage.getOrderCanceledBannerText(), orderSuccessFullyCanceledIndicatorText.toString(), "Banner Text Incorrect After Order Cancelation, Please Report");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } catch (AssertionError arr) {
            arr.printStackTrace();
            return false;
        }
    }

    public void moveRXsToEOD(List<Integer> rxList, int storeId) {

    }

    public boolean moveRXsToEODJob(List<Integer> rxList, int storeId) {
        return true;
    }

    public List<Integer> getAllFillsInPickupQueue(int storeId) {
        return new ArrayList<>();
    }


    public void verifyRefillPageShouldNotDisplayDisabledCheckBox() {

    }

    public void performRefillForAllPrescriptions() {

    }

    public void moveRXsToPickUp(List<Integer> rxList, int storeId) {

    }

    public void verifyPickupRxsCountInDashboard(int expectedPickupRxsCount) {

    }

    public void verifyRefillOrderConfirmationMessage() {
        Object refillOrderConfirmationMessage = textValidationUtils.getKeyInObject("loggedInRefill", "confirmationMessage");
        Assert.assertEquals(reviewOrderPage.getRefillOrderConfirmationMessage(), refillOrderConfirmationMessage);
    }

    public void verifyAccountUnconnectedOnConfirmation() {
        String expectedHeaderText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "connectAccountHeaderText").toString();
        String actualHeaderText = reviewOrderPage.getConnectToPharmacyHeaderText();
        Assert.assertEquals(actualHeaderText, expectedHeaderText, "Connect to Pharmacy header text does not match. Expected: '" + expectedHeaderText + "', but got: '" + actualHeaderText + "'");
        Reporter.log("Verified Connect to Pharmacy header text: " + actualHeaderText);
        
        Assert.assertTrue(reviewOrderPage.isGetStartedButtonDisplayed(), "Get Started button is not displayed on confirmation screen");
        Reporter.log("Verified Get Started button is displayed for unconnected account");
    }


    public void signOut() {
        signInPage.clickOnAccount();
        signInPage.clickOnSignout();
    }

    public void reLogin(String emailID, String password) {
        signInPage.enterEmail(emailID);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        //signInPage.navigateBack();
        signInPage.clickContinueSignInButton();
        am.performSleep(5);
        signInPage.clickSendcode();
        am.performSleep(4);
        signInPage.clickGetAnotherCode();
        am.performSleep(4);
        DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        String otp = digitalPharmacyAPIManager.getOTPForEmail(emailID);
        signInPage.enterInputOtpValue(otp);
        signInPage.clickSignInButtonForStepUp();
        Reporter.log("Signed-In to walmart dotcom account");
    }

    public void addMinorFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob) {
    }

    public void addPetFamilyMemberUsingRxNumber(String rx, String storeNumber) {
    }

    public void addLivestockFamilyMemberUsingRxNumber(String rx, String storeNumber) {
    }

    /**
     * Remove all dependents (minors and pets) from the Manage Family Members screen.
     * Repeatedly clicks the remove button until no more dependents are found.
     */
    public void removeDependents() {
        try {
            while (manageFamilyMembersPage.isDepedentFound()) {
                manageFamilyMembersPage.removeDependents();
                Reporter.log("Removed a dependent successfully");
                am.performSleep(5);
            }
            Reporter.log("All dependents removed");
        } catch (Exception e) {
            Reporter.log("Failed to remove dependents: " + e.getMessage());
        }
    }

    /**
     * Cancel all pending adult requests from the Manage Family Members screen.
     */
    public void cancelPendingRequests() {
        try {
            manageFamilyMembersPage.cancelRequest();
            Reporter.log("Cancelled pending requests");
            am.performSleep(2);
        } catch (Exception e) {
            Reporter.log("Failed to cancel pending requests: " + e.getMessage());
        }
    }

    public void goToAddFamilyMember() {
        manageFamilyMembersPage.clickAddFamilyMember();
    }

    public void addMinorFamilyMemberUsingPhoneNumber(String phoneNumber, String email, String dob) {
    }

    public void addPetFamilyMemberUsingPhoneNumber(String phoneNumber, String email) {
    }

    public void addLivestockFamilyMemberUsingPhoneNumber(String phoneNumber) {
    }

    public void clickAcceptAll() {
        manageFamilyMembersPage.acceptAll();
    }

    public void navigateToUrl(String url) {
        {
            manageFamilyMembersPage.getUrl(url);
        }
    }

    public void addAdultFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob, String email, String password, String careGiverEmail, String careGiverPassword) {
    }

    public void addAdultFamilyMemberUsingPhoneNumber(String phoneNumber, String storeNumber, String dob, String emailForPin, String email, String password, String careGiverEmail, String careGiverPassword) {
    }

    public void navigateBackToPharmacyFromReviewConfirmation() {
        reviewOrderPage.clickBackToPharmacyCTA();
    }

    public void navigateToPrescriptionHistory() {
        pharmacyDashboardPage.navigateToPrescriptionHistory();
    }

    public void verifyEmptyPrescriptionHistoryScreen() {
        Object pageHeaderText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "pageHeader");
        Object pageSubDescriptionText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "pageSubDescription");
        Object defaultFilterText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "defaultFilter");
        Object emptyStateHeadingText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "emptyStateHeading");
        Object emptyStateSubText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "emptyStateSubText");
        Object emptyStateGetStartedCTA = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "emptyStateGetStartedCTA");

        Assert.assertEquals(prescriptionHistoryPage.getPageHeaderText(), pageHeaderText, "Page header text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getPageSubDescriptionText(), pageSubDescriptionText, "Page sub-description text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getDefaultTimeFilterText(), defaultFilterText, "Default filter text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getEmptyStateHeadingText(), emptyStateHeadingText, "Empty state heading text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getEmptyStateSubText(), emptyStateSubText, "Empty state sub-text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getGetStartedButtonText(), emptyStateGetStartedCTA, "'Get started' CTA button text is incorrect");
        logScreenShot("Empty Prescription History Screen");
    }

    public void clickGetStartedOnEmptyPrescriptionHistory() {
        prescriptionHistoryPage.clickGetStartedButton();
    }

    public void verifyPrescriptionHistoryListScreen(String expectedTotalAmountSpent) {
        Object pageHeaderText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "pageHeader");
        Object pageSubDescriptionText = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "emptyState", "pageSubDescription");
        Object showingLabel = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "showingLabel");
        Object showingDateRangePrefix = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "showingDateRangePrefix");
        Object defaultFamilyFilter = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "defaultFamilyFilter");
        Object defaultTimeFilter = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "defaultTimeFilter");
        Object downloadHistoryButton = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "downloadHistoryButton");
        Object totalAmountSpentLabel = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "totalAmountSpentLabel");

        java.time.ZoneId localZone = java.time.ZoneId.systemDefault();
        java.time.LocalDate today = java.time.LocalDate.now(localZone);
        java.time.LocalDate ninetyDaysAgo = today.minusDays(90);
        java.time.format.DateTimeFormatter dateFormatter = java.time.format.DateTimeFormatter.ofPattern("MMM dd, yyyy");
        String expectedDateRange = showingDateRangePrefix + " " + ninetyDaysAgo.format(dateFormatter) + " to " + today.format(dateFormatter);
        String expectedTotalAmountSpentText = totalAmountSpentLabel + " " + expectedTotalAmountSpent;

        Assert.assertEquals(prescriptionHistoryPage.getPageHeaderText(), pageHeaderText, "Page header text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getPageSubDescriptionText(), pageSubDescriptionText, "Page sub-description text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getShowingLabelText(), showingLabel, "'Showing' label text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getDateRangeText(), expectedDateRange, "Showing date range text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getFamilyFilterText(), defaultFamilyFilter, "Default family filter text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getDefaultTimeFilterText(), defaultTimeFilter, "Default time filter text is incorrect");
        Assert.assertEquals(getDownloadHistoryButtonAttribute(), downloadHistoryButton, "'Download pharmacy history' button text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getTotalAmountSpentText(), expectedTotalAmountSpentText, "'Total amount spent' text is incorrect");
    }

    public String getDownloadHistoryButtonAttribute() {
        return prescriptionHistoryPage.getDownloadHistoryButtonText();
    }

    public void verifyNudgeTitle() {
        Object nudgeTitle = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "nudgeTitle");
        Assert.assertEquals(prescriptionHistoryPage.getNudgeTitleText(), nudgeTitle, "Bottom nudge title text is incorrect");
    }

    public void verifyPrescriptionOwnersInList(List<String> expectedFirstNames) {
        List<String> visibleOwnerNames = prescriptionHistoryPage.getPrescriptionOwnerNames();
        List<String> normalizedVisible = visibleOwnerNames.stream().map(String::toLowerCase).toList();
        for (String firstName : expectedFirstNames) {
            String normalizedName = firstName.toLowerCase();
            boolean found = normalizedVisible.stream().anyMatch(owner -> owner.contains(normalizedName));
            Assert.assertTrue(found,
                    "No prescription found for family member '" + firstName + "' | Visible owners: " + visibleOwnerNames);
        }
    }

    public void verifyFamilyFilterBottomSheet(List<String> expectedFirstNames) {
        Object bottomSheetTitle = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "familyFilterBottomSheetTitle");
        Object applyButton = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "applyFiltersButton");
        Object resetButton = textValidationUtils.getKeyInObject("pharmacyHistoryScreen", "listState", "resetFiltersButton");

        prescriptionHistoryPage.clickFamilyFilter();
        Assert.assertEquals(prescriptionHistoryPage.getFamilyFilterBottomSheetTitle(), bottomSheetTitle, "Family filter bottom sheet title is incorrect");

        List<String> visibleMembers = prescriptionHistoryPage.getFamilyFilterMemberNames();
        List<String> normalizedVisible = visibleMembers.stream().map(String::toLowerCase).toList();
        for (String firstName : expectedFirstNames) {
            String normalizedName = firstName.toLowerCase();
            boolean found = normalizedVisible.stream().anyMatch(member -> member.contains(normalizedName));
            Assert.assertTrue(found,
                    "Family member '" + firstName + "' not found in filter | Visible members: " + visibleMembers);
        }

        Assert.assertEquals(prescriptionHistoryPage.getApplyFilterButtonText(), applyButton, "'Apply' button text is incorrect");
        Assert.assertEquals(prescriptionHistoryPage.getResetAllFilterButtonText(), resetButton, "'Reset all' button text is incorrect");
        logScreenShot("Family Filter Bottom Sheet");
    }

    public void verifyFilteredPrescriptionsForEachMember(
            List<String> memberFirstNames, List<String> drugNames, List<String> prices, List<String> dates) {
        for (int i = 0; i < memberFirstNames.size(); i++) {
            String firstName = memberFirstNames.get(i);

            if (prescriptionHistoryPage.isResetAllFilterEnabled()) {
                prescriptionHistoryPage.clickResetAllFilter();
            }

            am.performSleep(1);
            prescriptionHistoryPage.clickFamilyFilterMemberByFirstName(firstName);
            prescriptionHistoryPage.clickApplyFilter();

            String visibleOwner = prescriptionHistoryPage.getFirstPrescriptionOwner();
            Assert.assertTrue(visibleOwner.toLowerCase().contains(firstName.toLowerCase()),
                    "Owner mismatch for '" + firstName + "' | Visible owner: " + visibleOwner);
            Assert.assertEquals(prescriptionHistoryPage.getFirstPrescriptionDrugName(), drugNames.get(i),
                    "Drug name mismatch for '" + firstName + "'");
            Assert.assertEquals(prescriptionHistoryPage.getFirstPrescriptionPrice(), prices.get(i),
                    "Price mismatch for '" + firstName + "'");
            Assert.assertEquals(prescriptionHistoryPage.getFirstPrescriptionDate(), dates.get(i),
                    "Date mismatch for '" + firstName + "'");
            logScreenShot("Filtered prescriptions for: " + firstName);

            if (i < memberFirstNames.size() - 1) {
                prescriptionHistoryPage.clickFamilyFilter();
            }
        }

    }

    public void verifyFindOrTransferPrescriptionsScreen() {
        Object toolbarTitle = textValidationUtils.getKeyInObject("findOrTransferScreen", "toolbarTitle");
        Object headerTitle = textValidationUtils.getKeyInObject("findOrTransferScreen", "headerTitle");
        Object headerSubTitle = textValidationUtils.getKeyInObject("findOrTransferScreen", "headerSubTitle");
        Object findWalmartHeading = textValidationUtils.getKeyInObject("findOrTransferScreen", "findWalmartHeading");
        Object findWalmartSubHeading = textValidationUtils.getKeyInObject("findOrTransferScreen", "findWalmartSubHeading");
        Object transferHeading = textValidationUtils.getKeyInObject("findOrTransferScreen", "transferHeading");
        Object transferSubHeading = textValidationUtils.getKeyInObject("findOrTransferScreen", "transferSubHeading");

        Assert.assertTrue(findOrTransferOptionSelectionPage.isHeaderTitleDisplayed(), "Find or Transfer Prescriptions screen is not displayed");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getToolbarTitleText(), toolbarTitle, "Toolbar title is incorrect");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getHeaderTitleText(), headerTitle, "Header title is incorrect");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getHeaderSubTitleText(), headerSubTitle, "Header sub-title is incorrect");
        Assert.assertTrue(findOrTransferOptionSelectionPage.isFindWalmartOptionDisplayed(), "'Find Walmart prescriptions' option is not displayed");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getFindWalmartHeadingText(), findWalmartHeading, "'Find Walmart prescriptions' heading text is incorrect");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getFindWalmartSubHeadingText(), findWalmartSubHeading, "'Find Walmart prescriptions' sub-heading text is incorrect");
        Assert.assertTrue(findOrTransferOptionSelectionPage.isTransferPrescriptionsOptionDisplayed(), "'Transfer prescriptions to Walmart' option is not displayed");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getTransferPrescriptionsHeadingText(), transferHeading, "'Transfer prescriptions to Walmart' heading text is incorrect");
        Assert.assertEquals(findOrTransferOptionSelectionPage.getTransferPrescriptionsSubHeadingText(), transferSubHeading, "'Transfer prescriptions to Walmart' sub-heading text is incorrect");
        logScreenShot("Find or Transfer Prescriptions Screen");
    }


    public void verifyAndAcceptEcommConsentFormData(String username) {
        Object ecommFormTitleText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testEcommAuthConsent", "FormTitle");
        Object ecommFormSubTitleText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testEcommAuthConsent", "FormSubTitle");
        Object ecommFormPermissionTitle = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testEcommAuthConsent", "EcommPermissionTitle");
        Object ecommFormPermissionSubTitle = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testEcommAuthConsent", "EcommPermissionSubTitle");
        Object ecommFormAuthUsersVerbiageText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testEcommAuthConsent", "EcommAuthUserNamesVerbiageText");
        Assert.assertTrue(ecommAuthConsentFormPage.checkAcceptDisabled());
        Assert.assertTrue(ecommAuthConsentFormPage.checkNotNowLinkVisibility());
        Assert.assertEquals(ecommAuthConsentFormPage.getEcommAuthHeaderText(), ecommFormTitleText, "Form Header is Incorrect");
        Assert.assertEquals(ecommAuthConsentFormPage.getEcommAuthSubHeaderText(), ecommFormSubTitleText, "Form Sub-Header is Incorrect");
        Assert.assertEquals(ecommAuthConsentFormPage.getEcommHippaPermissionTitleText(), ecommFormPermissionTitle, "Ecomm Form Permission Title Text is Incorrect");
        Assert.assertEquals(ecommAuthConsentFormPage.getEcommHippaPermissionSubTitleText(), ecommFormPermissionSubTitle, "Ecomm Form Permission Sub-Title Text is Incorrect");
        Assert.assertEquals(ecommAuthConsentFormPage.getEcommAuthUserNamesVerbiageText(), ecommFormAuthUsersVerbiageText, "Ecomm Form Auth Username Verbiage Text is Incorrect");
        Assert.assertEquals(ecommAuthConsentFormPage.getFirstAuthConsentorText(username), username, "Username is incorrect in ecomm consent verbiage");
        Assert.assertTrue(ecommAuthConsentFormPage.checkAcceptCTAVisibilityOnScrolling());
        ecommAuthConsentFormPage.acceptEcommConsent();
    }


    public void clickOnGuestRefillCTA() {

        homePage.clickPersonalisationChoiceButton();
        pharmacyDashboardPage.clickGuestRefill();
    }

    public void doSignInWithExpoUrl(String email, String password) {
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickOnEnterPasswordRadioBtn();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
            signInPage.clickSendcode();
            // Takes time between sending otp and astro API to receive it
            am.performSleep(3);
            DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
            String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
            signInPage.enterInputOtpValue(otp);
            signInPage.clickSignInButtonForStepUp();
            am.performSleep(3);
        }
    }


    public void navigateToAddFamilyMemberScreen() {

        CommonUtils commonData = new CommonUtils();
        JSONObject jsonObject = new JSONObject(commonData.readJsonFile(prop.getProperty("dp.regression.test.data.json.filePath")));
        JSONObject testInputDetails = null;
        if (jsonObject.keySet().contains("addMinorPetAndAdultFamilyMemberTogetherUsingPhoneNumberLookup"))
            testInputDetails = jsonObject.getJSONObject("addMinorPetAndAdultFamilyMemberTogetherUsingPhoneNumberLookup");
        String email = testInputDetails.get("caregiverEmail").toString();
        String password = testInputDetails.get("caregiverPassword").toString();

        this.doSignInSkipOnBoardingAndStepUp(email, password);
        this.proceedToPharmacyDashboardAndCloseBottomSheets();
        Reporter.log("Reached Pharmacy Dashboard");
        this.navigateToManageMyFamilyPage();
    }

    public void signInAndnavigateToAddFamilyMemberScreen(String email, String password) {

        this.doSignInSkipOnBoardingAndStepUp(email, password);
        this.proceedToPharmacyDashboardAndCloseBottomSheets();
        Reporter.log("Reached Pharmacy Dashboard");
        this.navigateToManageMyFamilyPage();
    }

    public void navigateBckToAddFamilyMemberScreen() {

    }

    public void validateAddInsuranceErrorForCaregiver(String errorMessage) {
        manageInsurancePage.validateAddInsuranceErrorForCaregiver();
        Assert.assertEquals(manageInsurancePage.unableToFindInsErrorMessage.getText().toLowerCase(), errorMessage.toLowerCase(), "Error message is not matching");
        Assert.assertTrue(manageInsurancePage.isElementDisplayed(manageInsurancePage.enterDetailsManuallyButton));
    }

    public void addMultipleInsuranceWithBOM() {
        manageInsurancePage.addMultipleInsuranceWithBOM();
        Assert.assertEquals(manageInsurancePage.getInsuranceAddedSuccessMessage().toLowerCase(), ("Insurance has been added").toLowerCase(), "Add insurance success Text is incorrect");
        manageInsurancePage.goBackToManageMyInsurancePage();
    }

    public void selectDrug(String drugName) {
        refillPrescriptionPage.clickSortAndFilterButton();
        refillPrescriptionPage.applyActivePrescriptionsFilter();
        refillPrescriptionPage.applySelectedFilter();
        refillPrescriptionPage.clickOnDrug(drugName);
        refillPrescriptionPage.clickContinueRefillButton();
    }

    public void navigateToImportRxAndFindMissingRX(String rxNumber, String storeId) {
        scrollToFindWalmartPrescriptionsModule();
        pharmacyDashboardPage.navigateToFindPrescriptionsScreen();
        findMissingRx(rxNumber, storeId);
    }

    private void findMissingRx(String rxNumber, String storeId) {
        findOrTransferOptionSelectionPage.clickFindWalmartPrescriptionsRadio().clickContinueBtn();
        importRxProfileSelectionPage.selectProfile(0).clickContinueBtn();
        selectEnterPrescriptionManually(); // scan or enter prescription manually selection page is only displayed in apps
        int maxAttempts = 0; // try for 5 mins to find the prescription
        enterPrescriptionDetailsPage.enterRxNumber(rxNumber).enterStoreNumber(storeId);
        while (maxAttempts < 10) {
            am.performSleep(30); // wait for TDC sync
            enterPrescriptionDetailsPage.clickContinueBtn();
            if (enterPrescriptionDetailsPage.isInvalidRxAndStoreNumberDialogDisplayed()) {
                // just in case if the invalid Rx dialog is displayed click ok and wait for another 60 secs
                enterPrescriptionDetailsPage.clickOkDialogButton();
                Reporter.log("invalid rx dialog is still displayed after waiting for " + maxAttempts + 1 + " mins");
            } else {
                Reporter.log("Looks like Rx is found after" + maxAttempts + 1 + " mins");
                break;
            }
            maxAttempts++;
        }
    }

    public void verifyImportRxStateDashboardModuleAndFindMissingRx(String rxNumber, String storeId) {
        // verify the import Rx state module is displayed
        pharmacyDashboardPage.importRxStateModuleIsDisplayed();
        pharmacyDashboardPage.navigateToFindPrescriptionsScreenUsingImportRxStateModule();
        findMissingRx(rxNumber, storeId);
    }

    public void scrollToFindWalmartPrescriptionsModule() {
    }

    public void selectEnterPrescriptionManually() {
    }

    public void verifyImportRxConfirmation(String drugName) {
        AssertUtil.assertTrue(findPrescriptionsPage.verifyImportRxConfirmation(), "Import Rx Confirmation is not displayed");

        // Verify the drug name is displayed in refill prescription page
        findPrescriptionsPage.clickViewPrescriptionsBtn();
        AssertUtil.assertTrue(refillPrescriptionPage.verifyDrugIsDisplayed(drugName), "Prescription is not displayed in refill prescription page");
    }

    public void linkPrescriptionsToCurrentAccount(String heading) {
        AssertUtil.assertTrue(findPrescriptionsPage.getHeadingText().contains(heading), "Link Accounts heading is not displayed as expected");
        findPrescriptionsPage.selectLinkPrescriptionsToThisAccountOption().clickContinueBtn();
        findPrescriptionsPage.clickLinkCurrentAccountBtnInDialog();
    }

    public String getFirstRFPRxNumber() {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSeeDetails();
        String rxNbr = prescriptionDetailsPage.getRxValue();
        prescriptionDetailsPage.clickBackToPharmacyCTA();
        pharmacyDashboardPage.waitForLoadingToDisappear(10);
        return rxNbr;
    }

    public void addInsuranceWithBlankPCN(String memberId, String binNumber) {
        manageInsurancePage.clickButtonChange();
        manageInsurancePage.selectPrescriptionInsuranceRadioButton();
        manageInsurancePage.clickContinueButton();
        manageInsurancePage.clickAddNewInsurance();
        manageInsurancePage.addInsuranceWithBlankPCN(memberId, binNumber);
        manageInsurancePage.clickContinueButton();
    }

    public void verifyCashToInsuranceChangeMessage(String pricePending) {
        Assert.assertEquals(manageInsurancePage.getPricePendingText().toLowerCase(), pricePending.toLowerCase());
    }

    public void clickButtonInsuranceArrowDown(String memberId) {
        manageInsurancePage.clickOnInsuranceArrowDown(memberId);
    }

    public void proceedToPharmacyDashboardWithoutPinValidation() {
        homePage.clickPersonalisationChoiceButton();
        Reporter.log("Denied personalisation choice popup");
        homePage.clickWalmartPlusProgramButton();
        Reporter.log("Closed walmart plus program popup");
        homePage.clickServicesButton();
        Reporter.log("Clicked on Services CTA");
        homePage.clickCloseJoinOneProgramButton();
        homePage.closeOnePayVisaCheckout();
        pharmacyDashboardPage.clickPharmacyServicesButton();
        Reporter.log("Closed join one program popup and clicked pharmacy service");
    }

    public void forceNavigateToCartPage() {
        // This method is only for Web
    }

    public void clickRefreshPageCTA() {
        ecommCartPage.clickRefreshPageCTA();
    }

    public void proceedToScheduleVaccinePageFromNudge() {
        vaccineSchedulePage.scheduleVaccineNudge();
    }

    public void proceedToScheduleVaccinePageFromSideNav() {
        vaccineSchedulePage.scheduleVaccineSideNav();
        vaccineSchedulePage.scheduleVaccineNudge(); //Reusing existing locators
    }

    public void turnedOffVaccineValidationForCaregiver(List<String> turnOffVaccineList) {
        vaccineSchedulePage.selectCaregiverForVaccine();
        vaccineSchedulePage.validateTurnOffVaccine(turnOffVaccineList);
    }

    public void validateRegularFlow() {
        vaccineSchedulePage.validateRegularFlow();
    }

    public void turnedOffVaccineValidation(List<String> turnOffVaccineList) {

        vaccineSchedulePage.validateTurnOffVaccine(turnOffVaccineList);
    }

    public void turnedOffVaccineValidationForChild() {

        vaccineSchedulePage.validateTurnOffVaccineForChild();
    }

    public void addNewPatient(String year) {
        vaccineSchedulePage.addNewPatient(year);
    }

    public void verifyScanToRefillMinorFlow(String RX, String strNo, String Dob) {

    }

    public void verifyScanToRefillPetRxFlow(String RX, String strNo, String Dob) {

    }

    public void verifyScanToRefillFlowWhenAccountNotConnectedTest(String RX, String strNo, String Dob) { }

    /**
     * Changes the pickup store on the Refill Review screen by searching via zip code
     * and selecting a store by its full content-desc (e.g. "Bentonville, Ar Supercenter,2428 W Pinhook Rd, Lafayette, LA 70508").
     */
    public void changeStoreInRefillReview(String zipCode, String storeContentDesc) {
        scanToRefillPage.clickChangeStoreButton();
        selectStorePage.clearZipCode();
        selectStorePage.enterZipCode(zipCode);
        selectStorePage.selectStoreByName(storeContentDesc);
        selectStorePage.clickSaveStoreButton();
        am.performSleep(3);
    }

    /**
     * Submits the refill request from the Review screen.
     */
    public void submitRefillRequest() {
        scanToRefillPage.clickRequestRefillButton();
        am.performSleep(5);
    }

    /**
     * Validates the store details section on the Refill Review screen.
     */
    public void validateRefillReviewStoreDetails(String expectedStoreName, String expectedAddress,
                                                  String expectedCityStateZip) {
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInAndroid(expectedStoreName),
            "Store name '" + expectedStoreName + "' not found on review screen");
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInAndroid(expectedAddress),
            "Store address '" + expectedAddress + "' not found on review screen");
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInAndroid(expectedCityStateZip),
            "City/State/Zip '" + expectedCityStateZip + "' not found on review screen");
        Reporter.log("Refill review store details validated — Store: " + expectedStoreName);
    }

    /**
     * Validates key elements on the Refill Confirmation screen.
     */
    public void validateRefillConfirmationScreen() {
    }

    /**
     * Full scan-to-refill flow with in-flow store change.
     * Navigates: Scan to Refill → enter Rx details → change store → submit refill.
     */
    public void verifyScanToRefillWithStoreChange(String rx, String storeNo, String dob,
                                                   String zipCode, String storeContentDesc) {
        proceedToScanToRefill();
        scanRxDetailsManually(rx, storeNo, dob);
        changeStoreInRefillReview(zipCode, storeContentDesc);
        submitRefillRequest();
    }

    public void validateAddedInsuranceDetails(String memberId, String bin, String pcn) {  }

    // ── Refill Coverage Change flow (PGSPHARM-49814) ─────────────────────────

    /**
     * Asserts that the refill review screen shows the discount card coverage with the given member ID.
     */
    public void verifyReviewScreenShowsDiscountCard(String discountMemberId) {
    }

    /**
     * On the refill review screen, taps "Change" for the given drug's coverage,
     * selects "Prescription insurance" on the coverage type screen, and taps Continue.
     * The "Remove discount card?" bottom sheet will appear after Continue.
     */
    public void changeCoverageToInsurance(String drugName) {
        refillPrescriptionPage.clickChangeCoverageForDrug(drugName);
        refillChangeCoveragePage.selectPrescriptionInsurance();
        refillChangeCoveragePage.clickContinueOnCoverageTypeScreen();
    }

    /**
     * Verifies the "Remove discount card?" bottom sheet is displayed and its title matches
     * the translation. Content text is asserted once the translation placeholder is replaced
     * with the actual device text.
     */
    public void verifyRemoveDiscountCardBottomSheet() {
        String expectedTitle = textValidationUtils.getKeyInObject("removeDiscountCardBottomSheet", "title").toString();
        String expectedContent = textValidationUtils.getKeyInObject("removeDiscountCardBottomSheet", "content").toString();

        String actualTitle = refillChangeCoveragePage.getRemoveDiscountCardTitleText();
        Assert.assertEquals(actualTitle, expectedTitle,
                "Bottom sheet title mismatch — expected='" + expectedTitle + "' actual='" + actualTitle + "'");
        Reporter.log("ASSERT: Bottom sheet title matches translation — '" + actualTitle + "'");

        String actualContent = refillChangeCoveragePage.getRemoveDiscountCardContentText();
        Assert.assertEquals(actualContent, expectedContent,
                "Bottom sheet content mismatch — expected='" + expectedContent + "' actual='" + actualContent + "'");
        Reporter.log("ASSERT: Bottom sheet content matches translation — '" + actualContent + "'");
    }

    /**
     * Confirms the "Remove discount card?" bottom sheet, then taps "Add new insurance"
     * on the "Change Prescription Insurance" screen to trigger the 270 insurance lookup.
     */
    public void confirmRemoveDiscountCardAndAddNewInsurance() {
        refillChangeCoveragePage.clickContinueOnRemoveDiscountCardPrompt();
        refillChangeCoveragePage.clickAddNewInsurance();
    }

    /**
     * On the "Add Insurance" (270 results) screen, selects the first found insurance,
     * taps Continue, then on the "Select prescription insurance" list screen selects
     * the recently-added insurance and taps Continue to return to the review screen.
     */
    public void selectFoundInsuranceFromResultsAndContinue() {
        Assert.assertTrue(
                refillChangeCoveragePage.isInsuranceFoundScreenDisplayed(),
                "Insurance found via 270 services screen was not displayed");
        refillChangeCoveragePage.selectFirstFoundInsurance();
        refillChangeCoveragePage.clickContinueOnCoverageTypeScreen();
        refillChangeCoveragePage.selectRecentlyAddedInsurance();
        refillChangeCoveragePage.clickContinueOnCoverageTypeScreen();
    }

    /**
     * Verifies that the refill review screen now shows "Price Pending" after the coverage
     * was changed from discount card to insurance.
     */
    public void verifyRefillReviewCoverageChangedToPricePending() {
        Assert.assertTrue(
                refillPrescriptionPage.isPricePendingDisplayedOnReview(),
                "Price Pending label not displayed on review screen after coverage change");
        Assert.assertTrue(
                refillPrescriptionPage.isCoverageChangePricePendingMessageDisplayed(),
                "'Due to your coverage change, the price will be available when the prescription is ready.' message not displayed");
    }

    /**
     * Taps the "Request refill" button on the review screen to place the order.
     */
    public void placeRefillRequest() {
        refillPrescriptionPage.clickRequestRefillButton();
        am.performSleep(3);
    }

    /**
     * Verifies the refill confirmation screen shows the success message.
     */
    public void verifyRefillPlacedConfirmationScreen() {
        Assert.assertTrue(
                refillPrescriptionPage.isRefillSuccessMessageDisplayed(),
                "Refill confirmation message 'Your refill request has been placed.' was not displayed");
        Reporter.log("Verified: Refill placed confirmation screen shown");
    }

    /**
     * Taps the Done button on the refill confirmation screen to return to Pharmacy Dashboard.
     */
    public void tapDoneOnRefillConfirmationScreen() {
        reviewOrderPage.clickPlaceOrderDoneButton();
        Reporter.log("Tapped Done on refill confirmation screen — returning to Pharmacy Dashboard");
        reviewOrderPage.closeFeedbackScreen();
        Reporter.log("Dismissed feedback screen if present");
    }


    public void validatePrimaryTag() {

        Assert.assertTrue(manageInsurancePage.isPrimaryInsuranceTagDisplayed(), "Primary tag is not displayed for the added insurance");
        manageInsurancePage.clickExpandInsurance();
    }


    public void clickOnManageFamilyCTA () {

    }
    public void navigateToScheduleVaccineFromPharmacyAndVerifyWhoIsGettingVaccinatedScreen() {
        vaccineSchedulePage.clickScheduleVaccineButton();
        pharmacyDashboardPage.enterPin();
        pharmacyDashboardPage.verifyPin();
        Assert.assertTrue(vaccineSchedulePage.isWhoIsGettingVaccinatedDisplayed(), "Who is getting vaccinated header text is not visible");
        Assert.assertTrue(vaccineSchedulePage.isSelectAndAddNewPatientDisplayed());
    }

    public void clickOnContinue() {
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(3);
    }

    public void selectCaregiverAsPatientAndContinue() {
        vaccineSchedulePage.selectCaregiverForVaccine();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyVaccineSelectionScreenIsDisplayed() {
        Assert.assertTrue(vaccineSchedulePage.isVaccineSelectionScreenDisplayed(), "Vaccine Selection screen header text is not visible");
    }

    public void verifyRecommendedVaccineScreenSelectVaccineAndConitnue() {
        Assert.assertTrue(vaccineSchedulePage.isRecommendedVaccineScreenDisplayed(), "Recommended Vaccine header text is not visible");
        vaccineSchedulePage.clickRecommendedVaccineButton();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyReviewPatientAndSelectAppointmentScreenAndContinue() {
        Assert.assertTrue(vaccineSchedulePage.isReviewPatientAndSelectAppointmentScreenDisplayed(), "Review patient and select appointment screen header text is not visible");
        Assert.assertTrue(vaccineSchedulePage.isRemoveButtonDisplayed(), "Remove button is missing in Review patient and select appointment screen");
        Assert.assertTrue(vaccineSchedulePage.isEditButtonDisplayed(), "Edit Button is missing in Review patient and select appointment screen");
        Assert.assertTrue(vaccineSchedulePage.isAddAnotherPatientButtonDisplayed(), "Add another patient buton is missing in Review patient and select appointment screen");
        vaccineSchedulePage.clickOnSelectAnAppointmentButton();
    }

    public void enterStoreLocationAndAndContinue(String storeId) {
        vaccineSchedulePage.enterStoreLocationAndFind(storeId);
        vaccineSchedulePage.clickContinueButton();
    }

    public void selectAppointmentTimeSlotAndContinue() {
        vaccineSchedulePage.selectAppointmentTimeSlot();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyPatientInformationScreenAndContinue(String patientPhoneNo) {
        Assert.assertTrue(vaccineSchedulePage.isPatientInformationScreenDisplayed(), "Patient Information  screen header text is not visible");
        vaccineSchedulePage.addPatientDetailsInPatientInformationScreen(patientPhoneNo);
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyPrimaryCarePhyscianScreenAndContinue(String PCPFirstName, String PCPLastName, String PCPPhoneNo) {
        vaccineSchedulePage.validatePrimaryCarePhysicianScreen(PCPFirstName, PCPLastName, PCPPhoneNo);
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyInsuranceSectionByChangingInsuranceOfPatientAndContinue() {
        Assert.assertTrue(vaccineSchedulePage.isInsuranceSectionScreenDisplayed(), "Insurance Section screen header text is not visible");
        Assert.assertTrue(vaccineSchedulePage.isMemberIDOfInsuranceSectionScreenDisplayed(), "Member ID is missing for this Insurance");
        vaccineSchedulePage.changeInsuranceForAPatientWithDifferentInsurance();
        vaccineSchedulePage.addThisInsuranceInformationToAppointment();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyAllHealthQuestionnairesOfPatientAndContinue() {
        vaccineSchedulePage.answerAllHealthQuestionnairesOfPatient();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyPatientConsentScreenAcknowledgeAndContinue() {
        Assert.assertTrue(vaccineSchedulePage.verifyAcknowledgeAndDeclineToAcknowledge());
        vaccineSchedulePage.acknowledgeReceipt();
        vaccineSchedulePage.clickContinueButton();
    }

    public void verifyReviewAndConfirmAppointmentScreenAndConfirmAppointment() {
        Assert.assertTrue(vaccineSchedulePage.verifyReviewAndConfirmAppointmentScreen());
        vaccineSchedulePage.clickConfirmAppointmentAndVerifyAppointmentDetails();
        Assert.assertTrue(vaccineSchedulePage.verifyAppointmentConfirmationScreen());

    }

    public void proceedToScheduleImmunization() {
        pharmacyDashboardPage.clickScheduleImmunizationTab();
        am.performSleep(3);
    }

    public void selectMultiplePatientsAndContinue(List<String> patientNames) {
        for (String patientName : patientNames) {
            vaccineSchedulePage.selectPatientByName(patientName);
        }
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(5); // waiting for page to load
    }

    public void selectVaccinesForPatientAndContinue(List<String> vaccineNames) {
        for (String vaccineName : vaccineNames) {
            vaccineSchedulePage.selectVaccineByName(vaccineName);
        }
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(5);
    }

    public void answerShinglesPreScreeningNoAndContinue() {
        vaccineSchedulePage.answerPreScreeningNoAndContinue();
        am.performSleep(3);
    }

    public void answerShinglesPreScreeningYesAndContinue() {
        vaccineSchedulePage.answerPreScreeningYesAndContinue();
        am.performSleep(3);
    }

    public void searchStoreByZipSelectFirstSlotAndContinue(String zip) {
        vaccineSchedulePage.searchStoreByZip(zip);
        am.performSleep(3);
        vaccineSchedulePage.selectFirstAvailableTimeSlot();
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(3);
    }

public void enterPatientPhoneNumberAndContinue(String phoneNumber) {
    vaccineSchedulePage.enterPhoneNumberForPatient(phoneNumber);
    vaccineSchedulePage.clickContinueButton();
}

public void enterPatientInfoAndContinue(String phoneNumber, String race, String ethnicity) {
    vaccineSchedulePage.selectRace(race);
    vaccineSchedulePage.selectEthnicity(ethnicity);
    vaccineSchedulePage.enterPhoneNumberForPatient(phoneNumber);
    vaccineSchedulePage.clickContinueButton();
    am.performSleep(3);
}

    public void selectNoPrimaryCarePhysicianAndContinue() {
        vaccineSchedulePage.selectNoPrimaryCarePhysician();
        vaccineSchedulePage.clickContinueButton();
    }

    public void skipInsuranceAndContinue() {
        vaccineSchedulePage.skipInsurance();
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(3);
    }

    public void completeHealthQuestionnaireAllDefaultNoAndContinue() {
        vaccineSchedulePage.answerHealthQuestionnaire10QuestionsDefaultNoAndContinue();
    }

    public void acknowledgePrivacyNoticeAndContinue() {
        vaccineSchedulePage.acknowledgePrivacyNotice();
        vaccineSchedulePage.clickContinueButton();
        am.performSleep(3);
    }

    public void continueToNextPatient(String patientFirstName) {
        vaccineSchedulePage.clickContinueToNextPatient(patientFirstName);
    }

    public void confirmVaccineAppointmentAndVerify() {
        vaccineSchedulePage.clickConfirmAppointment();
        Assert.assertTrue(vaccineSchedulePage.verifyAppointmentScheduledConfirmationMessage(),
                "Appointment confirmation message 'Your appointment is scheduled' was not displayed");
    }

    public void verifyPatientSelectionScreen() {
        String expectedHeader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientSelectionScreen", "header");
        String expectedSubheader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientSelectionScreen", "subheader");
        // resource-id: patient_list_heading / patient_list_select_text (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getPatientListHeadingText(), expectedHeader,
                "Patient selection screen header mismatch");
        Assert.assertEquals(vaccineSchedulePage.getPatientListSelectText(), expectedSubheader,
                "Patient selection screen subheader mismatch");
    }

    public void verifyVaccineSelectionScreenForPatient(String patientFullName) {
        String headerTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "vaccineSelectionScreen", "headerTemplate");
        String expectedHeader = String.format(headerTemplate, patientFullName);
        // resource-id: select_vaccine (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getVaccineSelectionTitleText(), expectedHeader,
                "Vaccine selection screen header mismatch for patient: " + patientFullName);
    }

    public void verifyPatientVaccineSummaryScreen() {
        String expectedHeader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientVaccineSummaryScreen", "header");
        String expectedSubheader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientVaccineSummaryScreen", "subheader");
        // resource-id: tell_us_title / appointment_subtitle (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getScreenMainTitleText(), expectedHeader,
                "Patient vaccine summary screen header mismatch");
        Assert.assertEquals(vaccineSchedulePage.getTellUsMoreSubtitleText(), expectedSubheader,
                "Patient vaccine summary screen subheader mismatch");
    }

    public void verifyPatientInfoScreenForPatient(String patientFullName) {
        String headerTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientInfoScreen", "headerTemplate");
        String expectedHeader = String.format(headerTemplate, patientFullName);
        // resource-id: patient_information_name (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getPatientInfoHeaderText(), expectedHeader,
                "Patient info screen header mismatch for patient: " + patientFullName);
    }

    public void verifyPCPScreenForPatient(String patientFullName) {
        String headerTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "pcpScreen", "headerTemplate");
        String expectedHeader = String.format(headerTemplate, patientFullName);
        // resource-id: heading_textview (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getPCPScreenHeaderText(), expectedHeader,
                "PCP screen header mismatch for patient: " + patientFullName);
    }

    public void verifyInsuranceScreenForPatient(String patientFullName) {
        String headerTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "insuranceScreen", "headerTemplate");
        String expectedHeader = String.format(headerTemplate, patientFullName);
        // resource-id: insurance_header_title (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getInsuranceScreenTitleText(), expectedHeader,
                "Insurance screen header mismatch for patient: " + patientFullName);
    }

    public void verifyConsentScreenForPatient(String patientFullName) {
        String headerTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "consentScreen", "headerTemplate");
        String expectedHeader = String.format(headerTemplate, patientFullName);
        // resource-id: immunization_patient_consent (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getPatientConsentHeaderText(), expectedHeader,
                "Consent screen header mismatch for patient: " + patientFullName);
    }

    public void verifyPatientCompletedScreen(String patientFullName) {
        String expectedLabel = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "patientSummaryScreen", "completedLabel");
        // resource-id: completed_state (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getCompletedStateLabelText(), expectedLabel,
                "Patient completed label mismatch for patient: " + patientFullName);
    }

    public void verifyReviewAndConfirmScreen() {
        String expectedHeader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "reviewConfirmScreen", "header");
        String expectedSubheader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "reviewConfirmScreen", "subheader");
        // resource-id: tell_us_title / review_subtitle (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getScreenMainTitleText(), expectedHeader,
                "Review and confirm screen header mismatch");
        Assert.assertEquals(vaccineSchedulePage.getReviewConfirmSubtitleText(), expectedSubheader,
                "Review and confirm screen subheader mismatch");
    }

    public void verifyAppointmentConfirmedScreen(String confirmationEmail) {
        String expectedHeader = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "appointmentConfirmedScreen", "header");
        // resource-id: confirmation_message (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getAppointmentConfirmedHeaderText(), expectedHeader,
                "Appointment confirmed screen header mismatch");

        String emailTemplate = (String) textValidationUtils.getKeyInObject(
                "vaccineScheduleFlow", "appointmentConfirmedScreen", "confirmationEmailTemplate");
        String expectedEmailText = String.format(emailTemplate, confirmationEmail);
        // resource-id: confirmation_subtitle (confirmed from execution)
        Assert.assertEquals(vaccineSchedulePage.getAppointmentConfirmedEmailText(), expectedEmailText,
                "Appointment confirmation email text mismatch — expected: " + expectedEmailText);
    }

    public void clickOnContinueWithoutPharmacyItemsButton(){
        ecommCartPage.clickContinueWithoutPharmacyItemsButton();
    }

    public void navigateToRefillPrescriptions(){
    }

    public void replaceInsuranceFromRefillReview(String memberId){
        manageInsurancePage.replaceInsuranceFromRefillReview( memberId);
    }

    public void dismissAddressVerificationDialogIfPresent() {
        pharmacyDashboardPage.dismissAddressVerificationDialogIfPresent();
    }
}