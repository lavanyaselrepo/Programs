package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;
@lombok.Getter
@lombok.Setter
public class Discount{
    public String type;
    public String program;
    public double amount;
}
