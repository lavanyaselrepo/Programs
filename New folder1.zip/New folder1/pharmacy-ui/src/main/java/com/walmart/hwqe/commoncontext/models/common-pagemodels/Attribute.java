package com.walmart.hwqe.commoncontext.models.pagemodels.common;

public enum Attribute {
    Name,
    IsEnabled,
    Enabled,
    Disabled,
    AutomationId,
    ClassName,
    Value,
    HasKeyboardFocus,
    IsPassword,
    IsToggle,
    HorizontalViewSize,
    VerticalViewSize,
    IsScroll,
    ContentDesc,
    innerText
}
