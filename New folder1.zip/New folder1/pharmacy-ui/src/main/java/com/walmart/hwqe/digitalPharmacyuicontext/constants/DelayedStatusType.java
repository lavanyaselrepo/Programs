package com.walmart.hwqe.digitalPharmacyuicontext.constants;

public enum DelayedStatusType {
    REFILL_TOO_SOON,
    PHYSICIAN_DENIED,
    DELAYED_GENERIC,
    OUT_OF_STOCK,
    OUT_OF_REFILLS,
    EXPIRED_RX,
    PAST_PROMISED_TIME
}
