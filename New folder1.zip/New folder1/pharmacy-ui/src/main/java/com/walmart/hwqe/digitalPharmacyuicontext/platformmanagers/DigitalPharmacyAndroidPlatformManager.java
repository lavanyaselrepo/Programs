/**
 * DigitalPharmacyAndroidPlatformManager is the implementation of ICommonDriver for the platform type "ANDROID".
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;


import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.saucelabscontext.SauceLabsTunnelManager;
import com.walmart.hwqe.webcontext.interfaces.ICommonDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.net.URL;
import java.util.*;


@Slf4j
public class DigitalPharmacyAndroidPlatformManager implements ICommonDriver {

    private static ThreadLocal<AppiumDriver> appiumDriverThreadLocal = new ThreadLocal<>();
    PropertyReader prop = PropertyReaderHelper.getInstance();

    private String getProp(String key, String defaultValue) {
        String value = prop.getProperty(key);
        return value != null ? value : defaultValue;
    }

    /**
     * getDriver method initialises RemoteWebDriver according to the type of platform passed.
     *
     * @return returns the implementation of ICommonDriver which is an instance of RemoteWebDriver.
     * @Author: Saloni Sharma
     */
    public RemoteWebDriver getDriver() {
        return appiumDriverThreadLocal.get();
    }

    public void getSessionInformation() {
        Reporter.log(appiumDriverThreadLocal.get().getCapabilities().toString());
    }

    /**
     * launchPlatformApp method initialises an AppiumDriver instance driven entirely by
     * {@code dp.android.run.mode} in ui-config.properties. Supported modes:
     * <ul>
     *   <li>{@code sauce.real.device} – SauceLabs cloud, physical Android device (default)</li>
     *   <li>{@code sauce.emulator}    – SauceLabs cloud, Android emulator</li>
     *   <li>{@code local.real.device} – Local Appium server, USB-connected physical device</li>
     *   <li>{@code local.emulator}    – Local Appium server, running Android emulator</li>
     * </ul>
     *
     * @param testName test case name shown in SauceLabs session / reporter.
     * @return RemoteWebDriver instance.
     * @Author: Saloni Sharma
     */
    public RemoteWebDriver launchPlatformApp(String testName) {

        AppiumDriver driver = null;
        String runMode = getProp("dp.android.run.mode", "sauce.real.device");
        boolean onSauce  = runMode.startsWith("sauce.");
        boolean realDevice = runMode.endsWith(".real.device");

        log.info("Android run mode: {}", runMode);

        try {
            if (onSauce) {
                driver = launchOnSauce(testName, realDevice);
            } else {
                driver = launchLocally(realDevice);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        appiumDriverThreadLocal.set(driver);
        return driver;
    }

    /**
     * Builds and starts an AndroidDriver session against SauceLabs.
     * Device identity (name / platformVersion) is read from properties based on
     * whether a real device or emulator is requested.
     */
    private AppiumDriver launchOnSauce(String testName, boolean realDevice) throws Exception {
        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:app", "storage:filename=" + prop.getProperty("dp.android.app.sauce.filename"));
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appWaitDuration", 30000);
        caps.setCapability("appium:noReset", false);
        caps.setCapability("appium:fullReset", false);
        caps.setCapability("appium:newCommandTimeout", Integer.parseInt(getProp("dp.android.new.command.timeout.sauce", "120")));
        caps.setCapability("appium:autoDismissAlerts", true);
        caps.setCapability("appium:autoGrantPermissions", true);
        caps.setCapability("appium:appPackage", prop.getProperty("dp.android.app.package"));
        // Launch AutomationActivity first so Appium's own am start carries the Teflon intent extra.
        // This avoids the previous mid-session am start -S restart that cold-booted the app a second time.
        caps.setCapability("appium:appActivity", prop.getProperty("dp.android.app.activity"));
        // Teflon environment injected via Appium's internal am start — same pattern as r2-automation.
        // AutomationActivity reads this extra, sets the env, then hands off to SplashActivity.
        caps.setCapability("appium:optionalIntentArguments", "--es glass.auto.ServiceEnv TEFLON");
        // Tell Appium to wait for SplashActivity (the next activity after AutomationActivity hands off)
        // before considering the session ready.
        caps.setCapability("appium:appWaitActivity", prop.getProperty("dp.android.app.wait.activity"));
        // Reduce UiAutomator2 idle polling — default 10 s wait causes noticeable lag between actions
        caps.setCapability("appium:settings[waitForIdleTimeout]", 0);
        // 0 ms: return 404 immediately if element not found — Java-side FluentWait/WebDriverWait
        // handles retries at 500ms intervals. A server-side timeout (e.g. 1500ms) makes each
        // failed poll block for that duration, turning a 550ms cycle into 2000ms and adding
        // 30+ seconds of overhead across a full test flow.
        caps.setCapability("appium:settings[waitForSelectorTimeout]", 0);
        // Limit view hierarchy depth — without this, Appium dumps the full tree on every
        // element lookup causing multi-second delays on complex pharmacy screens
        caps.setCapability("appium:settings[snapshotMaxDepth]", 100);
        // Disable window animations so UiAutomator2 can reach idle quickly on SauceLabs
        caps.setCapability("appium:disableWindowAnimation", true);
        // Increase ADB command timeout to avoid silent failures and retry loops on real devices
        caps.setCapability("appium:adbExecTimeout", 50000);

        if (realDevice) {
            caps.setCapability("appium:deviceName",       prop.getProperty("dp.android.sauce.real.device.name"));
            caps.setCapability("appium:platformVersion",  prop.getProperty("dp.android.sauce.real.device.platform.version"));
        } else {
            caps.setCapability("appium:deviceName",       prop.getProperty("dp.android.sauce.emulator.device.name"));
            caps.setCapability("appium:platformVersion",  prop.getProperty("dp.android.sauce.emulator.platform.version"));
        }

        MutableCapabilities sauceOptions = new MutableCapabilities();
        if (realDevice) sauceOptions.setCapability("appiumVersion", "latest");
        else sauceOptions.setCapability("appiumVersion", prop.getProperty("dp.android.sauce.appium.version"));

        sauceOptions.setCapability("username",  prop.getProperty("z.run.sl.un"));
        sauceOptions.setCapability("accessKey", prop.getProperty("z.run.sl.ak"));
        sauceOptions.setCapability("build", "1");
        sauceOptions.setCapability("name", testName);
        sauceOptions.setCapability("deviceOrientation", "PORTRAIT");
        // Lower idle timeout so SauceLabs recycles stalled sessions faster
        sauceOptions.setCapability("idleTimeout", 90);
        // Cache the installed APK across sessions in the same build — avoids re-install overhead
        sauceOptions.setCapability("cacheId", "walmart-pharmacy-android");
        // Capture system-wide network traffic in SauceLabs session (visible under Network tab)
        sauceOptions.setCapability("networkCapture", true);
        // Automatically retry flaky tests once before marking as failed
        sauceOptions.setCapability("retryFailedTests", true);
        // Mask credentials in SauceLabs session recordings and log output
        sauceOptions.setCapability("filterSendKeys", true);
        String dpEmail    = prop.getProperty("dp.test.email")    != null ? prop.getProperty("dp.test.email")    : "";
        String dpPassword = prop.getProperty("dp.test.password") != null ? prop.getProperty("dp.test.password") : "";
        sauceOptions.setCapability("logFilterText",
                prop.getProperty("z.run.sl.un") + "," + dpEmail + "," + dpPassword);

        if (prop.getProperty("dp.run.sauce.test.with.tunnel").equalsIgnoreCase("true")) {
            if (prop.getProperty("dp.is.custom.tunnel.needed").equalsIgnoreCase("true")) {
                log.info("Using Custom Sauce Tunnel for Tests");
                sauceOptions.setCapability("tunnelName",  SauceLabsTunnelManager.getInstance().getSauceLabsTunnelID());
                sauceOptions.setCapability("tunnelOwner", prop.getProperty("sauce.tunnel.owner"));
            } else {
                log.info("Using Default Sauce Tunnel for Tests");
                sauceOptions.setCapability("tunnelName",  prop.getProperty("sauce.tunnel.name"));
                sauceOptions.setCapability("tunnelOwner", prop.getProperty("sauce.tunnel.owner"));
            }
        }

        caps.setCapability("sauce:options", sauceOptions);

        String hub = String.format("https://%s:%s@ondemand.us-west-1.saucelabs.com:443/wd/hub",
                prop.getProperty("z.run.sl.un"), prop.getProperty("z.run.sl.ak"));
        AppiumDriver driver = new AndroidDriver(new URL(hub), caps);

        // Push idle/selector wait via the settings API immediately after session creation.
        // The session-level appium:settings[] capabilities are not guaranteed to apply
        // before the first command in Appium 2.x — this call ensures they take effect.
        // Without this, animated screens burn up to 10s per command waiting for UI idle.
        driver.setSetting("waitForIdleTimeout", 0);
        driver.setSetting("waitForSelectorTimeout", 0);
        // Enforce snapshotMaxDepth post-session to guarantee it takes effect
        driver.setSetting("snapshotMaxDepth", 100);

        return driver;
    }

    /**
     * Builds and starts an AndroidDriver session against a local Appium server.
     * Device identity (name / platformVersion / udid) is read from properties based on
     * whether a real device or emulator is requested.
     */
    private AppiumDriver launchLocally(boolean realDevice) throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("appium:automationName", "uiautomator2");
        capabilities.setCapability("appium:autoDismissAlerts", true);
        capabilities.setCapability("appium:autoGrantPermissions", true);
        capabilities.setCapability("appium:noReset", false);
        capabilities.setCapability("appium:fullReset", false);
        // Higher newCommandTimeout for local to allow more inactivity without session expiry
        capabilities.setCapability("appium:newCommandTimeout",
                Integer.parseInt(getProp("dp.android.new.command.timeout.local", "600")));
        capabilities.setCapability("appium:app",
                System.getProperty("user.home") + prop.getProperty("dp.android.app.local.relative.path"));
        capabilities.setCapability("appium:appPackage", prop.getProperty("dp.android.app.package"));
        // Launch AutomationActivity first so Appium's own am start carries the Teflon intent extra.
        capabilities.setCapability("appium:appActivity", prop.getProperty("dp.android.app.activity"));
        // Teflon environment injected via Appium's internal am start — no separate shell command needed.
        capabilities.setCapability("appium:optionalIntentArguments", "--es glass.auto.ServiceEnv TEFLON");
        // Wait for SplashActivity after AutomationActivity hands off before session is considered ready.
        capabilities.setCapability("appium:appWaitActivity", prop.getProperty("dp.android.app.wait.activity"));
        // Disable animations via capability so they are off from the very first frame.
        // Without this, the 3 shell calls in disableAnimations() each wait up to waitForIdleTimeout.
        capabilities.setCapability("appium:disableWindowAnimation", true);
        // Set waitForIdleTimeout to 0 upfront so the session itself and the immediately
        // following driver.setSetting() + disableAnimations() calls are not stalled by
        // UiAutomator2 waiting for idle on an animated screen (up to 4s per command).
        capabilities.setCapability("appium:settings[waitForIdleTimeout]", 0);
        capabilities.setCapability("appium:settings[waitForSelectorTimeout]", 0);
        // Limit view hierarchy depth — same as SauceLabs path
        capabilities.setCapability("appium:settings[snapshotMaxDepth]", 100);

        if (realDevice) {
            capabilities.setCapability("appium:deviceName",      prop.getProperty("dp.android.local.real.device.name"));
            capabilities.setCapability("appium:platformVersion", prop.getProperty("dp.android.local.real.device.platform.version"));
            capabilities.setCapability("appium:udid",            prop.getProperty("dp.android.local.real.device.udid"));
        } else {
            capabilities.setCapability("appium:deviceName",      prop.getProperty("dp.android.local.emulator.device.name"));
            capabilities.setCapability("appium:platformVersion", prop.getProperty("dp.android.local.emulator.platform.version"));
            capabilities.setCapability("appium:udid",            prop.getProperty("dp.android.local.emulator.udid"));
        }

        AppiumDriver driver = new AndroidDriver(new URL("http://localhost:4723/"), capabilities);

        // Enforce all settings immediately after session creation before any other command.
        // appium:settings[] caps are not guaranteed to apply before the first command
        // in Appium 2.x — calling setSetting() ensures they are active right away.
        driver.setSetting("waitForIdleTimeout", 0);
        driver.setSetting("waitForSelectorTimeout", 0);
        driver.setSetting("snapshotMaxDepth", 100);

        // Disable system animations at the OS level for complete coverage.
        // With waitForIdleTimeout=0 already active these 3 shell calls are now near-instant.
        disableAnimations(driver);

        return driver;
    }

    /**
     * Sets all three Android animation scales to 0 via shell commands.
     * This prevents UiAutomator2 from waiting for animations to complete before
     * considering the UI idle, eliminating the 10s per-call idle timeout penalty.
     */
    private void disableAnimations(AppiumDriver driver) {
        try {
            for (String setting : Arrays.asList("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
                driver.executeScript("mobile: shell", ImmutableMap.of(
                        "command", "settings",
                        "args", Arrays.asList("put", "global", setting, "0")));
            }
            Reporter.log("System animations disabled for test session");
        } catch (Exception e) {
            Reporter.log("disableAnimations failed (non-fatal): " + e.getMessage());
        }
    }

    /**
     * quitDriver method quits RemoteWebDriver session post the test case execution completion.
     *
     * @Author: Saloni Sharma
     */
    @Override
    public void quitDriver() {
        try {
            if (prop.getProperty("dp.android.network.capture") != null && prop.getProperty("dp.android.network.capture").equalsIgnoreCase("true")) {
                this.captureNetworkLogs();
            }
            AppiumDriver driver = appiumDriverThreadLocal.get();
            if (driver != null) {
                driver.quit();
            }
        } finally {
            appiumDriverThreadLocal.remove();
        }
    }

    public String takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + fileName + "_" + r.nextInt(9999) + ".png");
            org.apache.commons.io.FileUtils.copyFile(appiumDriverThreadLocal.get().getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void captureNetworkLogs() {
        List<LogEntry> logEntries = appiumDriverThreadLocal.get().manage().logs().get("logcat").getAll();
        // export log entries to a file
        StringBuilder logContent = new StringBuilder();

        // Define network-related tags (customize as needed)
        List<String> networkTags = Arrays.asList("OkHttp", "Volley", "Retrofit", "Network", "Http");
        // Exclude these tags from API logs
        List<String> excludeTags = Arrays.asList("appium", "uiautomator");
        // Store last 10 failed API logs
        List<String> failedApiLogs = new java.util.LinkedList<>();

        for (LogEntry logEntry : logEntries) {
            String message = logEntry.getMessage();
            String formattedLog = logEntry.getTimestamp() + " " + logEntry.getLevel() + " " + message + "\n\n";
            logContent.append(formattedLog);
            // Only consider logs that are network logs (by tag), contain 'graphql', and have an HTTP status code 4xx or 5xx
            boolean isNetworkLog = false;
            for (String tag : networkTags) {
                if (message.contains(tag)) {
                    isNetworkLog = true;
                    break;
                }
            }
            boolean isExcluded = false;
            for (String tag : excludeTags) {
                if (message.toLowerCase().contains(tag)) {
                    isExcluded = true;
                    break;
                }
            }
            if (isNetworkLog && !isExcluded && message.toLowerCase().contains("graphql") && message.matches(".*\\b(4[0-9]{2}|5[0-9]{2})\\b.*")) {
                if (failedApiLogs.size() == 10) {
                    failedApiLogs.remove(0);
                }
                failedApiLogs.add(formattedLog);
            }
        }

        if (!failedApiLogs.isEmpty()) {
            StringBuilder lastFailedApis = new StringBuilder();
            lastFailedApis.append("Last ").append(failedApiLogs.size()).append(" API Failure Logs:\n\n");
            for (String logLine : failedApiLogs) {
                lastFailedApis.append(logLine);
            }
          //  Reporter.logBigStatement("Last 10 max failed Network Call Logs:\n\n" + lastFailedApis.toString());
        }

        try {
            File logFile = new File(prop.getProperty("app.workingfolder_path") + "logcat_" + System.currentTimeMillis() + appiumDriverThreadLocal.get().getSessionId() + ".txt");
            org.apache.commons.io.FileUtils.writeStringToFile(logFile, logContent.toString(), "UTF-8");
            log.info("Log file created at: " + logFile.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
