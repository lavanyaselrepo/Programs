package com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class PrescriptionDetailsPage extends MobileBasePage {

    public PrescriptionDetailsPage(RemoteWebDriver driver) {

        super(driver);
    }
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_name")
    @iOSXCUITFindBy(accessibility = "PrescriptionInfoView.drugNameLabel")
    @FindBy(id = "page-heading")
    WebElement rxName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_price")
    @iOSXCUITFindBy(accessibility = "PrescriptionInfoView.priceLabel")
    @FindBy(id = "price-details")
    WebElement rxEstimatedPrice;

    @AndroidFindBy(id = "com.walmart.android.debug:id/details_heading")
    @iOSXCUITFindBy(accessibility = "PrescriptionDetailsSectionView.titleLabel")
    @FindBy(id = "prescription-details-title")
    WebElement prescriptionDetailsHeader;

    /**
     * Android: {@code detail_item_*} rows use duplicate {@code title}/{@code value} ids — scope with UiSelector
     * {@code childSelector}. iOS: {@code label} matches visible copy (see translations). Web: {@code cssSelector} on
     * stable section ids. Last-received row is not always {@code detail_item_eight}; Android uses text + one sibling xpath.
     */
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_one\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Rx#']")
    @FindBy(xpath = "//div[@id='rx#']/child::p[1]")
    WebElement rxNo;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_one\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Rx#']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='rx#']/child::p[2]")
    WebElement rxValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_two\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Patient' and @name='PrescriptionDetailsSectionItemView.titleLabel']")
    @FindBy(xpath = "//div[@id='patient']/child::p[1]")
    WebElement patientName;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_two\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Patient']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='patient']/child::p[2]")
    WebElement patientValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_three\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Prescriber' and @name='PrescriptionDetailsSectionItemView.titleLabel']")
    @FindBy(xpath = "//div[@id='prescriber']/child::p[1]")
    WebElement prescriberName;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_three\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Prescriber']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='prescriber']/child::p[2]")
    WebElement prescriberValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_four\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Prescribed on']")
    @FindBy(xpath = "//div[@id='prescribed-on']/child::p[1]")
    WebElement rxDate;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_four\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Prescribed on']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='prescribed-on']/child::p[2]")
    WebElement rxDateValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_five\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Quantity']")
    @FindBy(xpath = "//div[@id='quantity']/child::p[1]")
    WebElement quantity;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_five\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Quantity']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='quantity']/child::p[2]")
    WebElement quantityValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_six\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Supply']")
    @FindBy(xpath = "//div[@id='supply']/child::p[1]")
    WebElement supply;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_six\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Supply']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='supply']/child::p[2]")
    WebElement supplyValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_seven\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/title\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Instructions']")
    @FindBy(xpath = "//div[@id='instructions']/child::p[1]")
    WebElement instructions;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/detail_item_seven\").childSelector(new UiSelector().resourceId(\"com.walmart.android.debug:id/value\"))")
    @iOSXCUITFindBy(xpath = "//*[@label='Instructions']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='instructions']/child::p[2]")
    WebElement instructionsValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Last received\")")
    @iOSXCUITFindBy(xpath = "//*[@label='Last received']")
    @FindBy(xpath = "//div[@id='instructions']/child::p[2]")
    WebElement lastReceived;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Last received')]/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(xpath = "//*[@label='Last received']/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//div[@id='last-received']/child::p[2]")
    WebElement lastReceivedValue;

    @AndroidFindBy(id = "com.walmart.android.debug:id/medication_guide")
    @FindBy(id = "medication-guide")
    WebElement medicationGuideLink;

    @AndroidFindBy(id = "com.walmart.android.debug:id/drug_information")
    WebElement drugInfoLink;

    @FindBy(xpath = "//button[text()='Back to pharmacy']")
    WebElement backToPharmacyCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_details_warning")
    @iOSXCUITFindBy(accessibility = "PrescriptionInfoView.drugAlert")
    WebElement cancelReasonBanner;

    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_alert_text")
    @iOSXCUITFindBy(accessibility = "PrescriptionInfoView.drugAlert")
    WebElement cancelReasonText;

    public String getRxName(){return getText(rxName);}
    public String getRxEstimatedPrice(){return getText(rxEstimatedPrice);}
    public String getPrescriptionDetailsHeader(){return getText(prescriptionDetailsHeader);}
    public String getRxNoKey(){return getText(rxNo);}
    public String getRxValue(){return getText(rxValue);}
    public String getPatientNameKey(){return getText(patientName);}
    public String getPatientValue(){return getText(patientValue);}
    public String getPrescriberNameKey(){return getText(prescriberName);}
    public String getPrescriberValue(){return getText(prescriberValue);}
    public String getRxDate(){return getText(rxDate);}
    public String getRxDateValue(){return getText(rxDateValue);}
    public String getQuantityKey(){return getText(quantity);}
    public String getQuantityValue(){return getText(quantityValue);}
    public String getSupplyKey(){return getText(supply);}
    public String getSupplyValue(){return getText(supplyValue);}
    public String getInstructionsKey(){return getText(instructions);}
    public String getInstructionsValue(){return getText(instructionsValue);}
    public String getLastReceivedKey(){return getText(lastReceived);}
    public String getLastReceivedValue(){return getText(lastReceivedValue);}
    public String getMedicationGuideLinkText(){return getText(medicationGuideLink);}
    public String getDrugInfoLinkText(){return getText(drugInfoLink);}
    public void clickMedicationGuideLink(){click(medicationGuideLink);}
    public void clickDrugInfoLink(){click(drugInfoLink);}
    public void clickBackToPharmacyCTA(){click(backToPharmacyCTA);}
    public boolean isCancelReasonBannerDisplayed() { return isElementDisplayed(cancelReasonBanner); }
    public String getCancelReasonText() { return getText(cancelReasonText); }

    /**
     * RFP/ATC prescription-details screens may omit the medication guide and drug information links
     * (no {@code medication_guide} / {@code drug_information} in hierarchy). When absent, translation
     * asserts for those strings should be skipped on Android.
     */
    public boolean areMedicationGuideAndDrugInfoLinksPresent() {
        List<WebElement> mg = remoteDriver.findElements(By.id("com.walmart.android.debug:id/medication_guide"));
        List<WebElement> di = remoteDriver.findElements(By.id("com.walmart.android.debug:id/drug_information"));
        try {
            return mg.getFirst().isDisplayed() && di.getFirst().isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
