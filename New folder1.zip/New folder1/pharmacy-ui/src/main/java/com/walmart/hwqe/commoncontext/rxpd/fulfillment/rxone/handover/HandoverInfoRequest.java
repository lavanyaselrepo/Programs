package com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.handover;

public class HandoverInfoRequest {
    private String omsOrderId;
    private Integer transType;

    public String getOmsOrderId() {
        return omsOrderId;
    }

    public void setOmsOrderId(String omsOrderId) {
        this.omsOrderId = omsOrderId;
    }

    public Integer getTransType() {
        return transType;
    }

    public void setTransType(Integer transType) {
        this.transType = transType;
    }

}

