package com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice;

import com.google.api.services.gmail.Gmail;

/**
 * One-time setup script — run this MANUALLY before the first test pipeline run.
 *
 * What it does:
 *   Gmail API OAuth — opens a browser for the OAuth consent flow.
 *   After you approve, the token is saved to:
 *     pharmacy-ui/src/test/resources/google_voice/{account}/tokens/
 *   All subsequent Gmail API calls (read + send) reuse this token automatically.
 *
 * The gmail.send scope is required so that replying to Google Voice forwarding
 * emails works — Google Voice delivers the reply as an outgoing SMS.
 *
 * When to re-run:
 *   - Gmail token has expired (usually after 6 months of inactivity)
 *   - You added a new scope (e.g. gmail.send) and need to re-consent
 *
 * How to run:
 *   IntelliJ : Right-click → Run 'SaveGoogleVoiceSession.main()'
 *   Terminal : mvn exec:java -pl pharmacy-ui \
 *                -Dexec.mainClass="com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice.SaveGoogleVoiceSession"
 */
public class SaveGoogleVoiceSession {

    public static void main(String[] args) throws Exception {
        System.out.println("=================================================================");
        System.out.println("  Google Voice — Gmail API OAuth Setup");
        System.out.println("  Account: " + GoogleVoiceConfig.getEmail());
        System.out.println("=================================================================");

        System.out.println("\nA browser will open to the Google OAuth consent screen.");
        System.out.println("  Log in as: " + GoogleVoiceConfig.getEmail());
        System.out.println("  Grant BOTH permissions:");
        System.out.println("    - Read Gmail messages  (for reading SMS)");
        System.out.println("    - Send Gmail messages  (for replying to SMS)");
        System.out.println();

        try {
            Gmail gmailService = GoogleVoiceUtil.buildGmailService();
            String profile = gmailService.users().getProfile("me").execute().getEmailAddress();
            System.out.println("  Gmail API authorised for: " + profile);
            System.out.println("  Tokens saved to: " + GoogleVoiceConfig.getTokensDirPath());
        } catch (Exception e) {
            System.err.println("  Gmail API authorisation failed: " + e.getMessage());
            System.err.println("  Make sure credentials.json exists at: " + GoogleVoiceConfig.getCredentialsFilePath());
            System.exit(1);
        }

        System.out.println();
        System.out.println("=================================================================");
        System.out.println("  DONE! Setup complete.");
        System.out.println();
        System.out.println("  Both READ and SEND/REPLY SMS now use the Gmail API.");
        System.out.println("  No browser session needed — fully CI/CD safe.");
        System.out.println("=================================================================");
    }
}
