package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SelectSourceStorePage extends MobileBasePage {

    @FindBy(xpath = "//input[contains(@placeholder, 'Zip code')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND (label CONTAINS 'location' OR value CONTAINS 'location') AND visible == true")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Zip code, city or state\")")
    private WebElement inputSourceStoreZip;

    @FindBy(xpath = "//button[@aria-label='search']")
    private WebElement searchButton;

    @FindBy(xpath = "//div[@role='radiogroup']/div/div/label/input")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[@accessible='true'])[1]")
    @AndroidFindBy(className = "android.widget.RadioButton")
    private List<WebElement> sourceStoreRadioButtons;

    @FindBy(xpath = "//div[@role='radiogroup']/div/div/label/span/div/span")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[@accessible='true'])[1]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/heading")
    private List<WebElement> sourceStoreNameText;

    @FindBy(xpath = "//button[text()='Continue']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name CONTAINS 'primaryActionButton'")
    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    private WebElement continueButton;

    @FindBy(xpath = "//button[text()='No thanks']")
    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.secondaryActionButton")
    @AndroidFindBy(id = "com.walmart.android.debug:id/consent_cancel_button")
    private WebElement denyLocationPermission;

    @FindBy(xpath = "//button[@aria-label='search']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_text_input_end_icon")
    private WebElement storeSearchButton;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[@name='TextFieldStackView.textField'])[3]")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Enter a pharmacy name')]/android.widget.FrameLayout/android.widget.EditText")
    private WebElement searchByPharmacyNameField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[@accessible='true']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/heading")
    private List<WebElement> sourcePharmacyNamesList;

    public SelectSourceStorePage(RemoteWebDriver driver) {
        super(driver);
    }

    public void enterSourceStoreZip(String zipCode) {
        if (remoteDriver instanceof IOSDriver) {
            // On iOS/SauceLabs the second moveToElement in clickElementAndSendKeysUsingActionClass
            // causes XCUITest to lose field focus before the text is typed.
            moveToElementAndClick(inputSourceStoreZip, "inputSourceStoreZip");
            performSleep(1);
            inputSourceStoreZip.sendKeys(zipCode);
        } else {
            clickElementAndSendKeysUsingActionClass(inputSourceStoreZip, zipCode);
        }
    }

    public void clickFirstAvailableSourceStore() {
        click(sourceStoreRadioButtons.get(0), 5);
    }

    public String getFirstSourceStoreNameText(){
        return getText(sourceStoreNameText.get(0));
    }

    public void clickContinueButton() {
        click(continueButton);
    }

    public void clickDenyLocationPermission(){click(denyLocationPermission);}

    public void clickStoreSearchButton(){unblockingClick(storeSearchButton,10,"storeSearchButton");}

    public void enterPharmacyNameInSearchField(String pharmacyName) {
        sendText(searchByPharmacyNameField, pharmacyName, 15);
    }

    public void waitForSearchResultsToLoad(String pharmacyName) {
        new WebDriverWait(remoteDriver, Duration.ofSeconds(15))
                .until(driver -> sourcePharmacyNamesList.stream()
                        .anyMatch(el -> {
                            try { return el.getText().contains(pharmacyName); }
                            catch (Exception e) { return false; }
                        }));
    }

    public void selectSourcePharmacyByName(String pharmacyName) {
        for (WebElement pharmacyElement : sourcePharmacyNamesList) {
            if (pharmacyElement.getText().contains(pharmacyName)) {
                click(pharmacyElement);
                break;
            }
        }
    }

}
