package com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePart;
import com.google.api.services.gmail.model.MessagePartHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility for reading and replying to SMS via Google Voice, fully CI/CD safe.
 *
 * Architecture
 * ─────────────
 *   READ SMS   → Gmail API (Google Voice forwards every incoming SMS as an email to Gmail)
 *
 *   REPLY SMS  → Gmail API (replying to Google Voice's forwarding email sends the reply as an SMS)
 *                - No browser, no Playwright, no bot-detection issues
 *                - Works in headless CI/CD pipelines
 *
 * Both paths use the same OAuth credentials (credentials.json + tokens/).
 *
 * Quick start
 * ────────────
 *   1. Enable Gmail API in Google Cloud Console for normandmark268@gmail.com
 *   2. Download OAuth credentials.json → pharmacy-ui/src/test/resources/google_voice/credentials.json
 *   3. Run SaveGoogleVoiceSession once to authorise and save tokens/
 *
 * See: pharmacy-ui/src/test/resources/google_voice/README_GOOGLE_VOICE.md
 */
public class GoogleVoiceUtil {

    private static final Logger log = LogManager.getLogger(GoogleVoiceUtil.class);
    private static final String GMAIL_USER = "me";

    // ══════════════════════════════════════════════════════════════════════════
    // READ SMS — via Gmail API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Returns the plain-text body of the latest SMS forwarded from the given phone number.
     * Google Voice forwards each incoming SMS as an email from txt.voice.google.com.
     *
     * @param fromNumber phone number in any format, e.g. "(321) 732-5105" or "3217325105"
     * @return SMS body text
     */
    public static String getLatestSms(String fromNumber) throws Exception {
        Gmail service = buildGmailService();
        String query = buildSmsGmailQuery(fromNumber);
        log.info("Gmail SMS query: {}", query);

        List<Message> messages = service.users().messages()
                .list(GMAIL_USER)
                .setQ(query)
                .setMaxResults(1L)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            throw new RuntimeException("No SMS found from number: " + fromNumber);
        }

        Message full = service.users().messages()
                .get(GMAIL_USER, messages.get(0).getId())
                .setFormat("full")
                .execute();

        String body = extractTextBody(full);
        log.info("SMS received from {}: {}", fromNumber, body);
        return body;
    }

    /**
     * Polls Gmail until an SMS containing {@code expectedText} arrives, or throws on timeout.
     * Use when there is a delay between triggering an action and receiving the SMS.
     *
     * @param fromNumber      phone number the SMS is sent from
     * @param expectedText    substring to look for in the SMS body
     * @param timeoutMs       maximum wait time in milliseconds
     * @param pollIntervalMs  how often to poll in milliseconds
     * @return the full SMS body once found
     */
    public static String waitForSmsContaining(String fromNumber, String expectedText,
                                               long timeoutMs, long pollIntervalMs) throws Exception {
        log.info("Waiting up to {}ms for SMS from {} containing '{}'", timeoutMs, fromNumber, expectedText);
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            try {
                String body = getLatestSms(fromNumber);
                if (body.contains(expectedText)) {
                    log.info("SMS matched: {}", body);
                    return body;
                }
            } catch (Exception e) {
                log.debug("SMS not yet available: {}", e.getMessage());
            }
            Thread.sleep(pollIntervalMs);
        }
        throw new RuntimeException(String.format(
                "Timed out after %dms waiting for SMS containing '%s' from %s",
                timeoutMs, expectedText, fromNumber));
    }

    /**
     * Convenience overload using default timeout and poll interval from {@link GoogleVoiceConfig}.
     */
    public static String waitForSmsContaining(String fromNumber, String expectedText) throws Exception {
        return waitForSmsContaining(fromNumber, expectedText,
                GoogleVoiceConfig.DEFAULT_TIMEOUT_MS,
                GoogleVoiceConfig.DEFAULT_POLL_INTERVAL_MS);
    }

    /**
     * Extracts the first N-digit OTP code from an SMS body.
     * Useful for 6-digit verification codes sent via SMS.
     *
     * @param smsBody   raw SMS body text
     * @param digits    expected number of digits in the OTP (typically 6)
     * @return the extracted OTP string, or throws if not found
     */
    public static String extractOtpFromSms(String smsBody, int digits) {
        Pattern pattern = Pattern.compile("\\b(\\d{" + digits + "})\\b");
        Matcher matcher = pattern.matcher(smsBody);
        if (matcher.find()) {
            return matcher.group(1);
        }
        throw new RuntimeException(
                "Could not extract " + digits + "-digit OTP from SMS body: " + smsBody);
    }

    /**
     * Convenience method: wait for SMS containing a verification code and extract the OTP.
     *
     * @param fromNumber  phone number to watch
     * @param otpDigits   expected OTP length (typically 6)
     * @return the extracted OTP
     */
    public static String waitForOtp(String fromNumber, int otpDigits) throws Exception {
        String smsBody = waitForSmsContaining(fromNumber, "",
                GoogleVoiceConfig.DEFAULT_TIMEOUT_MS,
                GoogleVoiceConfig.DEFAULT_POLL_INTERVAL_MS);
        return extractOtpFromSms(smsBody, otpDigits);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REPLY / SEND SMS — via Gmail API (CI/CD safe, no browser needed)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Replies to the latest SMS from the given phone number via the Gmail API.
     * Google Voice delivers replies to its forwarding emails as outgoing SMS messages.
     *
     * This is fully CI/CD safe — no browser, no Playwright, no session files needed.
     *
     * @param toNumber  the phone number to reply to, e.g. "(321) 732-5105"
     * @param message   the SMS reply text
     */
    public static void sendSms(String toNumber, String message) throws Exception {
        replyToLatestSms(toNumber, message);
    }

    /**
     * Finds the latest Google Voice forwarding email from {@code fromNumber} and sends
     * a Gmail reply, which Google Voice delivers as an outgoing SMS.
     *
     * @param fromNumber  phone number whose conversation to reply to
     * @param replyText   the text to send as an SMS
     */
    public static void replyToLatestSms(String fromNumber, String replyText) throws Exception {
        Gmail service = buildGmailService();
        String query = buildSmsGmailQuery(fromNumber);
        log.info("Looking up conversation with {} to reply: {}", fromNumber, replyText);

        List<Message> messages = service.users().messages()
                .list(GMAIL_USER)
                .setQ(query)
                .setMaxResults(1L)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            throw new RuntimeException(
                    "No SMS conversation found from " + fromNumber + " — cannot reply");
        }

        Message original = service.users().messages()
                .get(GMAIL_USER, messages.get(0).getId())
                .setFormat("full")
                .execute();

        String replyTo = getHeader(original, "Reply-To");
        if (replyTo == null || replyTo.isBlank()) {
            replyTo = getHeader(original, "From");
        }
        String subject = getHeader(original, "Subject");
        String threadId = original.getThreadId();
        String messageId = getHeader(original, "Message-ID");

        log.info("Replying to thread={}, replyTo={}, subject={}", threadId, replyTo, subject);

        MimeMessage reply = buildReplyMimeMessage(replyTo, subject, messageId, replyText);

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        reply.writeTo(buffer);
        String encodedEmail = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(buffer.toByteArray());

        Message gmailReply = new Message();
        gmailReply.setRaw(encodedEmail);
        gmailReply.setThreadId(threadId);

        service.users().messages().send(GMAIL_USER, gmailReply).execute();
        log.info("SMS reply sent to {} via Gmail API: {}", fromNumber, replyText);
    }

    private static MimeMessage buildReplyMimeMessage(String to, String subject,
                                                      String inReplyToMessageId,
                                                      String bodyText) throws Exception {
        Session session = Session.getDefaultInstance(new Properties(), null);
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(GoogleVoiceConfig.getEmail()));
        msg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(to));
        msg.setSubject(subject != null && !subject.startsWith("Re:") ? "Re: " + subject : subject);
        if (inReplyToMessageId != null) {
            msg.setHeader("In-Reply-To", inReplyToMessageId);
            msg.setHeader("References", inReplyToMessageId);
        }
        msg.setText(bodyText, "UTF-8");
        return msg;
    }

    public static String getHeader(Message message, String headerName) {
        if (message.getPayload() == null || message.getPayload().getHeaders() == null) {
            return null;
        }
        for (MessagePartHeader header : message.getPayload().getHeaders()) {
            if (headerName.equalsIgnoreCase(header.getName())) {
                return header.getValue();
            }
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GMAIL API HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Builds an authenticated {@link Gmail} service for the default account
     * (configured via GOOGLE_VOICE_EMAIL env var or google_voice.properties).
     */
    public static Gmail buildGmailService() throws Exception {
        return buildGmailService(
                GoogleVoiceConfig.getCredentialsFilePath(),
                GoogleVoiceConfig.getTokensDirPath()
        );
    }

    /**
     * Builds an authenticated {@link Gmail} service for a specific account.
     * Loads credentials and tokens from that account's directory.
     *
     * @param account email address, e.g. "testuser42@gmail.com"
     * @return authenticated Gmail service for that account's inbox
     */
    public static Gmail buildGmailServiceForAccount(String account) throws Exception {
        return buildGmailService(
                GoogleVoiceConfig.getCredentialsFilePath(account),
                GoogleVoiceConfig.getTokensDirPath(account)
        );
    }

    private static Gmail buildGmailService(String credentialsPath, String tokensDirPath) throws Exception {
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(
                GsonFactory.getDefaultInstance(),
                new InputStreamReader(
                        new FileInputStream(credentialsPath),
                        StandardCharsets.UTF_8)
        );

        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                GsonFactory.getDefaultInstance(),
                clientSecrets,
                GoogleVoiceConfig.GMAIL_SCOPES
        )
                .setDataStoreFactory(new FileDataStoreFactory(new File(tokensDirPath)))
                .setAccessType("offline")
                .build();

        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        Credential credential = new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");

        return new Gmail.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                GsonFactory.getDefaultInstance(),
                credential
        ).setApplicationName(GoogleVoiceConfig.APP_NAME).build();
    }

    /**
     * Builds a Gmail search query that matches SMS forwarded by Google Voice from a phone number.
     * Google Voice sends these as emails with subject containing the phone number.
     */
    private static String buildSmsGmailQuery(String phoneNumber) {
        String normalized = phoneNumber.replaceAll("[^0-9]", "");
        String formatted = normalized.length() == 10
                ? String.format("(%s) %s-%s",
                        normalized.substring(0, 3),
                        normalized.substring(3, 6),
                        normalized.substring(6))
                : phoneNumber;
        return "from:txt.voice.google.com subject:\"" + formatted + "\"";
    }

    /**
     * Extracts the plain-text body from a Gmail {@link Message}, handling both
     * single-part and multi-part MIME messages.
     */
    public static String extractTextBody(Message message) throws Exception {
        if (message.getPayload() == null) return "";

        String raw;
        if (message.getPayload().getBody() != null
                && message.getPayload().getBody().getData() != null) {
            raw = decodeBase64Url(message.getPayload().getBody().getData());
        } else if (message.getPayload().getParts() != null) {
            raw = extractTextFromParts(message.getPayload().getParts());
        } else {
            return "";
        }

        return stripGoogleVoiceFooter(raw);
    }

    /**
     * Strips the Google Voice email footer that gets appended when GV forwards
     * an SMS to Gmail. The footer always starts with "YOUR ACCOUNT".
     */
    private static String stripGoogleVoiceFooter(String body) {
        int footerStart = body.indexOf("YOUR ACCOUNT");
        if (footerStart > 0) {
            return body.substring(0, footerStart).trim();
        }
        return body.trim();
    }

    private static String extractTextFromParts(List<MessagePart> parts) {
        for (MessagePart part : parts) {
            if ("text/plain".equals(part.getMimeType())
                    && part.getBody() != null
                    && part.getBody().getData() != null) {
                return decodeBase64Url(part.getBody().getData());
            }
            if (part.getParts() != null) {
                String nested = extractTextFromParts(part.getParts());
                if (!nested.isEmpty()) return nested;
            }
        }
        return "";
    }

    public static String decodeBase64Url(String encoded) {
        return new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
    }

}
