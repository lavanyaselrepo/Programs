package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PackageToteInfo {
	public String packageToteId;
    public int packageToteStatus;
    public ArrayList<OrderAndBagInfo> orderAndBagInfo;

}
