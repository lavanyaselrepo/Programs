package com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.chainOfCustody;

public class ChainOfCustodyStartRequestPayload {

    private Integer oneTimePasscode;
    private String omsOrderId;
    private Integer transType;

    public Integer getOneTimePasscode() {
        return oneTimePasscode;
    }

    public void setOneTimePasscode(Integer oneTimePasscode) {
        this.oneTimePasscode = oneTimePasscode;
    }

    public String getOmsOrderId() {
        return omsOrderId;
    }

    public void setOmsOrderId(String omsOrderId) {
        this.omsOrderId = omsOrderId;
    }

    public Integer getTransType() {
        return transType;
    }

    public void setTransType(Integer transType) {
        this.transType = transType;
    }
}

