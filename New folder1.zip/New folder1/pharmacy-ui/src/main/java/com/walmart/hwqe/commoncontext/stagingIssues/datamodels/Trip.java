package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Trip {
	public String provider;
    public String firstName;
    public String lastName;


}
