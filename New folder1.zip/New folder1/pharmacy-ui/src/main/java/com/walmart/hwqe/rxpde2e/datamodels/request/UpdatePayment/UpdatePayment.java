package com.walmart.hwqe.rxpde2e.datamodels.request.UpdatePayment;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class UpdatePayment {
    public String firstName;
    public String lastName;
    public String emailAddress;
    public String phoneNumber;
    public ArrayList<String> paymentMethods;
    public PostalAddress postalAddress;
}
