package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Manage Permissions screen (Pharmacy Account Settings → Manage Permissions).
 * Covers: (1) Manage Permissions list with Prescription delivery section and "Enable delivery" for dependents,
 * (2) Delivery enable request bottom sheet (send request form) and sent confirmation.
 * Locators verified on both Android and iOS via MCP get_page_elements.
 */
public class ManagePermissionsPage extends MobileBasePage {

    /** Page title "Manage permissions" */
    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_title")
    @iOSXCUITFindBy(accessibility = "HWSeparatorHeaderView.titleLabel")
    public WebElement managePermissionsTitle;

    /** "Enable delivery" button for adult dependent (opens request bottom sheet) */
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/option_cta' and @text='Enable delivery']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[starts-with(@name, 'enable_Button_')]")
    public WebElement enableDeliveryButtonForDependent;

    /** "Pending delivery approval" status tag icon (shown after request sent) */
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_tag_icon")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='WCPTag.iconView']")
    public WebElement pendingDeliveryApprovalTag;

    /** "Pending delivery approval" status tag text (shown after request sent) */
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_tag_message")
    @iOSXCUITFindBy(accessibility = "WCPTag.label")
    public WebElement pendingDeliveryApprovalMessage;

    /** Bottom sheet title "Permission needed for prescription delivery" */
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_bottom_sheet_toolbar_title")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.titleView")
    public WebElement deliveryEnableFormTitle;

    /** Message body on form (first static text in scroll area) */
    @AndroidFindBy(id = "com.walmart.android.debug:id/message")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView[@name='HWGenericViewController.scrollView']//XCUIElementTypeStaticText[1]")
    public WebElement deliveryEnableFormBody;

    /** "Request will be sent to:" header */
    @AndroidFindBy(id = "com.walmart.android.debug:id/request_header")
    @iOSXCUITFindBy(accessibility = "Request will be sent to:")
    public WebElement deliveryEnableRequestHeader;

    /** Dependent full name on form */
    @AndroidFindBy(id = "com.walmart.android.debug:id/fullName")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView[@name='HWGenericViewController.scrollView']//XCUIElementTypeStaticText[3]")
    public WebElement deliveryEnableFormFullName;

    /** Dependent email on form */
    @AndroidFindBy(id = "com.walmart.android.debug:id/email")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView[@name='HWGenericViewController.scrollView']//XCUIElementTypeStaticText[4]")
    public WebElement deliveryEnableFormEmail;

    /** Send request button */
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.firstButton")
    public WebElement sendRequestButton;

    /** Not now button */
    @AndroidFindBy(id = "com.walmart.android.debug:id/tertiary_button")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.secondButton")
    public WebElement cancelRequestButton;

    // Note: Only Android locators added - executed on Android only
    // TODO: Add iOS locators when flow is executed on iOS platform

    /** Account holder ecomm consent toggle switch (clickable) */
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_switch_toggle")
    public WebElement accountHolderConsentToggle;

    /** Account holder consent switch container when toggle is ON (content-desc: ", Switch, On") */
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/option_switch' and @content-desc=', Switch, On']")
    public WebElement accountHolderConsentSwitchOn;

    /** Account holder consent switch container when toggle is OFF (content-desc: ", Switch, Off") */
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/option_switch' and @content-desc=', Switch, Off']")
    public WebElement accountHolderConsentSwitchOff;

    public ManagePermissionsPage(RemoteWebDriver driver) {
        super(driver);
    }

    /**
     * Clicks the "Enable delivery" control to open the delivery enable request form.
     * On Manage Permissions list this is the "Enable delivery" button for the adult dependent.
     */
    public void clickDependentDeliveryEnable() {
        try {
            if (isElementDisplayed(enableDeliveryButtonForDependent, 10)) {
                click(enableDeliveryButtonForDependent, 10);
                Reporter.log("Clicked Enable delivery for dependent");
            } else {
                Reporter.log("Enable delivery button not found");
                throw new RuntimeException("Enable delivery button not found on Manage Permissions screen");
            }
        } catch (Exception e) {
            Reporter.log("Dependent delivery enable control not found: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Verifies all content in the delivery enable request form is displayed.
     */
    public boolean isAllDeliveryEnableRequestFormContentDisplayed() {
        return isElementDisplayed(deliveryEnableFormTitle, 5)
                && isElementDisplayed(deliveryEnableFormBody, 5)
                && isElementDisplayed(deliveryEnableRequestHeader, 5)
                && isElementDisplayed(deliveryEnableFormFullName, 5)
                && isElementDisplayed(deliveryEnableFormEmail, 5)
                && isElementDisplayed(sendRequestButton, 5);
    }

    /** Text getters for delivery enable request form (for content verification using translations + test data). */
    public String getDeliveryEnableFormTitleText() { return getText(deliveryEnableFormTitle); }
    public String getDeliveryEnableFormBodyText() { return getText(deliveryEnableFormBody); }
    public String getDeliveryEnableRequestHeaderText() { return getText(deliveryEnableRequestHeader); }
    public String getDeliveryEnableFormFullNameText() { return getText(deliveryEnableFormFullName); }
    public String getDeliveryEnableFormEmailText() { return getText(deliveryEnableFormEmail); }
    public String getSendRequestButtonText() { return getText(sendRequestButton); }
    public String getCancelRequestButtonText() { return getText(cancelRequestButton); }

    /**
     * Clicks Not now (cancel) on the delivery enable request form, closing the bottom sheet.
     */
    public void clickCancelRequest() {
        try {
            click(cancelRequestButton, 10);
            Reporter.log("Clicked Not now (cancel) on delivery enable request form");
        } catch (Exception e) {
            Reporter.log("Cancel request button not found: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Clicks Send request on the delivery enable request form.
     */
    public void clickSendRequest() {
        try {
            click(sendRequestButton, 10);
            Reporter.log("Clicked Send request");
        } catch (Exception e) {
            Reporter.log("Send request button not found: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Returns true if Manage Permissions screen (list) is displayed.
     */
    public boolean isManagePermissionsScreenDisplayed() {
        return isElementDisplayed(managePermissionsTitle, 10);
    }

    /**
     * Returns true if "Pending delivery approval" is displayed for the dependent (after request sent).
     * Uses the message element (ld_tag_message) that shows the text "Pending delivery approval".
     */
    public boolean isPendingDeliveryApprovalDisplayed() {
        return isElementDisplayed(pendingDeliveryApprovalTag,5) && isElementDisplayed(pendingDeliveryApprovalMessage, 5);
    }

    /**
     * Returns true if the account holder ecomm consent toggle is ON (, Switch, On).
     */
    public boolean isAccountHolderConsentEnabled() {
        return isElementDisplayed(accountHolderConsentSwitchOn, 5);
    }

    /**
     * Returns true if the account holder ecomm consent toggle is OFF (, Switch, Off).
     */
    public boolean isAccountHolderConsentDisabled() {
        return isElementDisplayed(accountHolderConsentSwitchOff, 5);
    }

    /**
     * Clicks the account holder ecomm consent toggle to trigger the revoke confirmation dialog.
     */
    public void clickAccountHolderConsentToggle() {
        try {
            click(accountHolderConsentToggle, 10);
            Reporter.log("Clicked account holder ecomm consent toggle");
        } catch (Exception e) {
            Reporter.log("Account holder consent toggle not found: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Confirms revoking ecomm consent by clicking "Yes, turn off" on the confirmation dialog.
     * Reuses the primary_button locator (same resource-id as sendRequestButton).
     */
    public void confirmRevokeEcommConsent() {
        try {
            click(sendRequestButton, 10);
            Reporter.log("Clicked 'Yes, turn off' to confirm ecomm consent revocation");
        } catch (Exception e) {
            Reporter.log("Confirm revoke button not found: " + e.getMessage());
            throw e;
        }
    }
}
