package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import java.time.Duration;

public class ReviewOrderPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/place_order")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='HWPrimaryAndLinkButtonWithInfoView.primaryActionButton' or @name='HWPrimaryAndLinkButtonView.primaryActionButton']")
    @FindBy(xpath = "//button[text()='Request refill']")
    public WebElement placeOrderButton;

    @iOSXCUITFindBy(accessibility = "RefillRequestConfirmationViewController.Close")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_done_button")
    public WebElement placeOrderDoneButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/payment_methods_pay_in_store_select_item")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=' Pay at store Cash, check or card accepted']")
    public WebElement payAtStoreRadioButton;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='Done']")
    public WebElement doneButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_order_confirmation_header']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Your refill request has been placed.']")
    @FindBy(xpath = "//section//h2[text()='Your refill request has been placed.']")
    public WebElement refillConfirmationMessage ;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_go_to_pharmacy_button")
    @iOSXCUITFindBy(accessibility = "Back to pharmacy")
    @FindBy(xpath = "//button[text()='Back to pharmacy']")
    public WebElement backToPharmacyCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/closeButton")
    @iOSXCUITFindBy(accessibility = "Close")
    public WebElement closeFeedbackScreen;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/connect_header']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='ConnectAccountInfoContainerView.titleLabel']")
    public WebElement connectToPharmacyHeader;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/getStartedButton']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ConnectAccountInfoContainerView.actionButton']")
    public WebElement getStartedButton;

    public ReviewOrderPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickPlaceOrderButton() {
        isElementDisplayed(placeOrderButton, 15);
        if (remoteDriver instanceof AndroidDriver) {
            AndroidDriver androidDriver = (AndroidDriver) remoteDriver;
            for (int attempt = 1; attempt <= 3; attempt++) {
                Reporter.log("Clicking Request refill button (attempt " + attempt + ")");
                androidDriver.findElement(new AppiumBy.ByAndroidUIAutomator(
                        "new UiSelector().resourceId(\"com.walmart.android.debug:id/place_order\")")).click();
                try {
                    new WebDriverWait(remoteDriver, Duration.ofSeconds(3))
                            .until(ExpectedConditions.invisibilityOf(placeOrderButton));
                    Reporter.log("Request refill button click confirmed on attempt " + attempt);
                    return;
                } catch (Exception e) {
                    Reporter.log("Button still visible after attempt " + attempt + ", retrying...");
                }
            }
            Assert.fail("Request refill button click did not trigger navigation after 3 attempts");
        } else {
            placeOrderButton.click();
        }
        Reporter.log("Clicked Request refill button");
    }

    public void clickDoneButton() {
        doneButton.click();
    }

    public void clickPayAtStoreRadioButtonWithScroll(){
        androidScrollToText(remoteDriver, "Cash, check or card accepted");
        click(payAtStoreRadioButton);
    }

    public void clickPayAtStoreRadioButton(){
        click(payAtStoreRadioButton);
    }

    public void clickPlaceOrderDoneButton(){click(placeOrderDoneButton);}

    public String getRefillOrderConfirmationMessage(){
        return getText(refillConfirmationMessage);
    }

    public void clickBackToPharmacyCTA() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Back to Pharmacy", "up");
        } else if(remoteDriver instanceof AndroidDriver){
            androidScrollToText("Back to pharmacy");
        } else {
            scrollToTextWithLoop("Give feedback");
        }
        click(backToPharmacyCTA,10);
    }

    public void closeFeedbackScreen(){
        try{
            if(isElementDisplayed(closeFeedbackScreen)){
                click(closeFeedbackScreen);
                click(placeOrderDoneButton);
            } else {
                Reporter.log("Not able to find element feedback close");
            }
        }catch (Exception e){
            Reporter.log("Feedback close button not clicked");
        }
    }

    public String getConnectToPharmacyHeaderText() {
        return getText(connectToPharmacyHeader);
    }

    public boolean isGetStartedButtonDisplayed() {
        return isElementDisplayed(getStartedButton, 10);
    }

}
