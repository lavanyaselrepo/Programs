package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class Cart{
   // public DbSessionMap dbSessionMap;
    public boolean checkoutable;
    public Cart cart;
    //public ArrayList<Item> items;
    public ArrayList<Object> errorItems;
    public long lastModifiedTime;
    public boolean fromCache;
    public int cartVersion;
    public boolean isOmniPromiseResponse;
    public ArrayList<Object> uniqueInstallationOfferIdHolder;
    public String id;
   // public Buyer buyer;
    //public AccessPoint accessPoint;
    public ArrayList<Object> storeIds;
    public int itemCount;
    public ArrayList<Object> entityErrors;
    //public Shipping shipping;
    public Summary summary;
    //public ArrayList<SuggestedSlot> suggestedSlots;
    public String currencyCode;
    public boolean preview;
    public int tenantId;
    public String tenantIdentifier;
    public int verticalId;
    public ArrayList<Object> checkoutableErrors;
    public String intent;
    //public PickupStore pickupStore;
    //public DeliveryStore deliveryStore;
   // public ArrayList<PharmacyStore> pharmacyStores;
    public ArrayList<Object> mpStores;
    //public CustomerContext customerContext;
    public ArrayList<String> memberBenefits;
   // public ArrayList<FulfillmentPlan> fulfillmentPlans;
    //public ArrayList<AccessPoint> accessPoints;
    //public ArrayList<Reservation> reservations;
    public boolean isExplicitIntent;
    public String assortmentIntent;
    public boolean hasGiftEligibleItem;
    public boolean marketPlacePickup;
    public ArrayList<Object> warnings;
    public ArrayList<Object> restrictions;
   // public AccInstallationSelection accInstallationSelection;
}
