package com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class CreateFulfillmentGroup {
    public String orderType;
    public ArrayList<Item> items;

}
