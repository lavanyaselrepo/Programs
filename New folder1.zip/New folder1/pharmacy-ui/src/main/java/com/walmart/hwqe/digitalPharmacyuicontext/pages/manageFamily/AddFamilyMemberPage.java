package com.walmart.hwqe.digitalPharmacyuicontext.pages.manageFamily;


import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class AddFamilyMemberPage extends MobileBasePage {

    RemoteWebDriver driver;

    @FindBy(xpath = "//*[text()='Prescription Information']")
    public WebElement prescriptionInfoOption;

    @FindBy(id = "fam-firstname")
    public WebElement firstNameInput;

    @FindBy(id = "fam-lastname")
    public WebElement lastNameInput;

    @FindBy(id = "fam-dob")
    public WebElement dateOfBirthInput;

    @FindBy(id = "add-fam-prescription-number")
    public WebElement prescriptionNumberInput;

    @FindBy(id = "fam-storenumber")
    public WebElement storeNumberInput;

    @FindBy(id = "pet-select")
    public WebElement petCheckbox;

    @FindBy(id = "fam-email")
    public WebElement emailAddressField;

    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continueButton;

    @FindBy(xpath = "//div[@role='radio']")
    public List<WebElement> petTypes;

    @FindBy(xpath = "//div[@role='alert']")
    public List<WebElement> errorMessages;

    public AddFamilyMemberPage(RemoteWebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    public void enterFirstName(String firstName) {
        sendText(firstNameInput, firstName, "firstName field");
    }

    public void enterLastName(String lastName) {
        sendText(lastNameInput, lastName, "lastName field");
    }

    public void enterDOB(String dob) {
        sendText(dateOfBirthInput, dob, "DOB field");
    }

    public void enterPrescriptionNumber(String prescriptionNumber) {
        sendText(prescriptionNumberInput, prescriptionNumber, "prescriptionNumber field");
    }

    public void enterStoreNumber(String storeNumber) {
        sendText(storeNumberInput, storeNumber, "Store Number field");
    }

    public void enterEmailAddress(String emailAddress) {
        sendText(emailAddressField, emailAddress, "emailAddress field");
    }

    public void clickOnPetCheckBox() {
        click(petCheckbox, "Pet Check box");
    }

    public void clickOnPetType(int petTypeIndex) {
        click(petTypes.get(petTypeIndex), "Pet Type");
    }

    public void clickOnContinueBtn() {
        click(continueButton, "Continue button");
        waitForCompletePageLoad();
    }

    public String getErrorMessage(int errorIndex) {
        return getText(errorMessages.get(errorIndex), "Error message");
    }

    public void clickOnPrescriptionInfoOption() {
        click(prescriptionInfoOption, "Prescription Information Option");
    }

    public void verifyErrorMessageInAddPatient(String expectedErrorMessage) {
        AssertUtil.assertTrue(isElementDisplayed(By.xpath("//*[contains(text(),'" + expectedErrorMessage + "')]")), expectedErrorMessage + " error message should display");
    }
}
