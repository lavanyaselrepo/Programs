package com.walmart.hwqe.digitalPharmacyuicontext.pages.forms;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.PharmacyDashboardPage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;

public class EcommAuthConsentFormPage extends PharmacyDashboardPage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/title")
    @iOSXCUITFindBy(accessibility = "EcommHipaaConsentViewController.titleLabel")
    @FindBy(xpath = "//div[@role='dialog']//h2")
    public WebElement ecommAuthHeader;

    @AndroidFindBy(id = "com.walmart.android.debug:id/form_title")
    @iOSXCUITFindBy(accessibility = "EcommHipaaConsentViewController.formHeadingLabel")
    @FindBy(xpath = "//div[@data-testid='authorization-content']/div/h3")
    public WebElement ecommFormSubHeader;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Review all terms to accept\" and @enabled='false']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=\"Review all terms to accept\" and @enabled='false']")
    @FindBy(xpath = "//button[@aria-label='Review all terms to accept' and @disabled]")
    public WebElement acceptTermsDisabled;

    @AndroidFindBy(id = "com.walmart.android.debug:id/review_negative_btn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"PrimaryAndLinkButtonView.linkButton\"]")
    @FindBy(xpath = "//button[text()='Not now']")
    public WebElement notNowCTA;

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id=\"com.walmart.android.debug:id/intro_and_consent_form\"]/android.webkit.WebView/android.webkit.WebView/android.widget.TextView[6]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, \"User accounts\")]")
    @FindBy(xpath = "//p//b[contains(text(),'User accounts')]")
    public WebElement ecommAuthUserNamesVerbiageText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, \"User accounts\")]/preceding::XCUIElementTypeOther[1]//following-sibling::XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
    public WebElement authConsentorOneName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/review_positive_btn")
    @iOSXCUITFindBy(accessibility = "Accept")
    @FindBy(xpath = "//button[@aria-label='Accept the Terms']")
    public WebElement acceptCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/intro_heading")
    @iOSXCUITFindBy(accessibility = "EcommHipaaPermissionView.titleLabel")
    @FindBy(xpath = "//div[@data-testid='authorization-content']//h3[contains(text(),'Your privacy')]")
    public WebElement ecommHippaPermissionTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/intro_body")
    @iOSXCUITFindBy(accessibility = "EcommHipaaPermissionView.subTitleLabel")
    @FindBy(xpath = "//div[@data-testid='authorization-content']//span[contains(text(),'Your permission')]")
    public WebElement ecommHippaPermissionSubTitle;

    public EcommAuthConsentFormPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getEcommAuthHeaderText() {
        return getText(ecommAuthHeader);
    }

    public String getEcommAuthSubHeaderText() {
        return getText(ecommFormSubHeader);
    }

    public boolean checkAcceptDisabled() {
        return isElementDisplayed(acceptTermsDisabled);
    }

    public boolean checkNotNowLinkVisibility() {
        return isElementDisplayed(notNowCTA);
    }

    public String getFirstAuthConsentorText(String username) {
        List<WebElement> authConsentorNames = new ArrayList<>();
        if (remoteDriver instanceof AndroidDriver) {
            authConsentorNames = getDynamicWebElementsByTagAndAttribute("android.widget.TextView", "text", username);
            return getText(authConsentorNames.get(0));
        } else if (remoteDriver instanceof IOSDriver) {
            return getText(authConsentorOneName);
        } else {
            authConsentorNames = getDynamicWebElementsByTagAndAttribute("div", "text", username);
            return getText(authConsentorNames.get(0));
        }
    }

    public boolean checkAcceptCTAVisibilityOnScrolling() {
        if (checkAcceptDisabled()) {
            if (remoteDriver instanceof IOSDriver) {
                mobileScrollToText("Accept the terms", "up");
            } else if (remoteDriver instanceof AndroidDriver) {
                androidScrollToText("Accept the terms");
            } else
                scrollToTextWithLoop("Accept");
        }
        return isElementDisplayed(acceptCTA);
    }

    public String getEcommHippaPermissionTitleText() {
        return getText(ecommHippaPermissionTitle);
    }

    public String getEcommHippaPermissionSubTitleText() {
        return getText(ecommHippaPermissionSubTitle);
    }

    public String getEcommAuthUserNamesVerbiageText() {
        return getText(ecommAuthUserNamesVerbiageText);
    }

    public void acceptEcommConsent() {
        click(acceptCTA);
    }
}