package com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class CreateOrder {
    public String customerEmailAddress;
    public String storeId;
    public String paymentType;
    public ArrayList<CreateFulfillmentGroup> fulfillmentGroups;
    public boolean resolveHolds;
    public String terminateBefore;
}
