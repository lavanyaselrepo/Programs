package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class SelectStorePage extends MobileBasePage {

    public SelectStorePage(RemoteWebDriver driver) {
        super(driver);
    }

    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/store_selector_zip_code_textinput_layout']/descendant::android.widget.EditText")
    @iOSXCUITFindBy(accessibility = "ZipCodeField.zipCodeTextField")
    @FindBy(xpath = "//input[@placeholder='Enter ZIP code']")
    public WebElement enterZipCodeInput;

    @FindBy(xpath = "//button[text()='Search']")
    public WebElement searchZipCodeButton;

    @AndroidFindBy(xpath = "(//*[contains(@text, 'Market')])[2]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@label,'Market')])[2]")
    @FindBy(xpath = "//span[text()='Location Neighborhood Market #5597']")
    public WebElement storeOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_selector_store_save_button")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Save']")
    @FindBy(xpath = "//button[text()='Select location']")
    public WebElement saveStoreButton;

    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc='Clear text']")
    // iOS: clear button inside zip code search field (executed on iOS)
    @iOSXCUITFindBy(accessibility = "ZipCodeField.clearButton")
    public WebElement clearZipCodeButton;

    public void enterZipCode() {

        sendText(enterZipCodeInput, "72719");
        hideKeyboard();
    }

    public void enterZipCode(String zipCode) {

        sendText(enterZipCodeInput, zipCode);
        if (remoteDriver instanceof AndroidDriver) {
            hideKeyboard();
        }
    }

    public void clearZipCode() {

        click(clearZipCodeButton);
    }

    public void clickSearchZipCodeButton() {

        click(searchZipCodeButton);
    }

    public void selectStoreOption() {

        click(storeOption);
    }

    public void selectStoreByName(String storeName) {
        String locator;
        if (remoteDriver instanceof AndroidDriver) {
            locator = "//android.widget.TextView[@content-desc='" + storeName + "']";
        } else if (remoteDriver instanceof IOSDriver) {
            // storeContentDesc format: "StoreName,Address, City, State Zip"
            // Extract store title (everything before the first comma followed by a digit)
            // e.g. "Bentonville, Ar Supercenter,2428 W Pinhook Rd..." → "Bentonville, Ar Supercenter"
            // iOS: executed on iOS — use StoreSelectionCell.titleLabel with extracted store name
            String storeTitle = storeName.split(",\\s*\\d")[0];
            locator = "//XCUIElementTypeStaticText[@name='StoreSelectionCell.titleLabel'][@value='" + storeTitle + "']";
        } else {
            locator = "//span[text()='" + storeName + "']";
        }
        click(remoteDriver.findElement(By.xpath(locator)));
    }

    public void clickSaveStoreButton() {

        click(saveStoreButton);
    }
}
