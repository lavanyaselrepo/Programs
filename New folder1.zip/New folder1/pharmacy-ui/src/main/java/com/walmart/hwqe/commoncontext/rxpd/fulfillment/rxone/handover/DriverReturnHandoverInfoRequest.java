package com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.handover;

public class DriverReturnHandoverInfoRequest {
    private String oneTimePasscode;
    private Integer transType;

    public String getOneTimePasscode() {
        return oneTimePasscode;
    }

    public void setOneTimePasscode(String oneTimePasscode) {
        this.oneTimePasscode = oneTimePasscode;
    }

    public Integer getTransType() {
        return transType;
    }

    public void setTransType(Integer transType) {
        this.transType = transType;
    }

}

