package com.walmart.hwqe.rxpde2e.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.walmart.hwqe.commoncontext.utils.NewERXorderDropOffUtil;
import com.walmart.hwqe.commoncontext.utils.RxPDAPIWrapper;
import com.walmart.hwqe.commoncontext.stagingIssues.wrapper.StagingIssuesAPIWrapper;
import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.CancelFill.CancelFill;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.Patient.CreatePatientResponse;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.WrapperUtils;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.datacontext.DataTable;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.accountentity.restapi.AccountEntityServiceRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.datamodels.cpr.CentralPatientSearchRequest;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.ca.restapi.CARetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.cpr.patientupdate.restapi.CprPatientUpdateRetrofit;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.Delayed;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.FillSummaryResponse;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.Filling;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.datamodels.response.ReadyForPickup;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.rxorchestrator.restapi.FillSummaryWrapper;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import com.walmart.hwqe.commons.serviceapi.rdm.centralpatient.apitests.PatientAPIWrapper;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.digitalPharmacyuicontext.constants.CommonConstants;

import com.walmart.hwqe.commons.connexuswrapperapicontext.datamodels.DropOff.Prescriber;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import org.xml.sax.SAXException;
import com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientDataForPickup.ConnexusPatientDataforPickup;
import com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientDataForPickup.Drug;
import com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder.CreateFulfillmentGroup;
import com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder.CreateOrder;
import com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder.Item;
import com.walmart.hwqe.rxpde2e.datamodels.request.InputPatientData;
import com.walmart.hwqe.rxpde2e.datamodels.request.UpdateDelivery.FulfillmentGroup;
import com.walmart.hwqe.rxpde2e.datamodels.request.UpdateDelivery.UpdateDelivery;
import com.walmart.hwqe.rxpde2e.datamodels.request.UpdatePayment.PostalAddress;
import com.walmart.hwqe.rxpde2e.datamodels.request.UpdatePayment.UpdatePayment;


import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

@lombok.Getter
@lombok.Setter
public class E2EWrapper {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReaderHelper.getInstance();
    ServiceRequest req = new ServiceRequest();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    DBUtils dbUtils = new DBUtils();
    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    ServiceResponse resp = new ServiceResponse();
    NewERXorderDropOffUtil eRxOrder = new NewERXorderDropOffUtil();
    Prescriber prescriber = new Prescriber();
    HashMap<String, String> headers = new HashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(E2EWrapper.class);
  //  HopsCosmos cosmosDB = new HopsCosmos();
 //   CosmosContext cosmosContext = AutomationManager.getInstance().getHopsDB();
    int patientId;
    CommonUtils commonUtils = new CommonUtils();
    RxPDAPIHelper rxPDAPIHelper = new RxPDAPIHelper();
    private CreatePatientResponse createPatientResponse = new CreatePatientResponse();
    private int storeId;

    private String patientFirstName;
    private String patientLastName;
    private String patientDob;
    private int numOfRxsNeeded;
    private String dotComEmail;
    private String dotComPassword;
    private List<String> dates;
    private String[] ndcList = {"00093505698", "31722070210", "68382056510", "68645055854", "53746051501", "68180046709", "29300011201", "68462022301", "43598016430", "00093505698", "31722070110"};
    private String commonCustomerAccountId = null;
    private CARetrofit caRetrofit = new CARetrofit();
    private AccountEntityServiceRetrofit accountEntityServiceRetrofit = new AccountEntityServiceRetrofit();
    private CprPatientUpdateRetrofit cprPatientUpdateRetrofit = new CprPatientUpdateRetrofit();
    PatientAPIWrapper patientAPIWrapper = new PatientAPIWrapper();
    private final ObjectMapper mapper = new ObjectMapper();
    Date date = new Date(System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000);
    private String commonDobCPRFormat = new SimpleDateFormat("yyyy-dd-MM").format(date);
    private String reqIdString = "req-id-";
    private String reqTrackingString = "req-tracking-";
    FillSummaryResponse fillSummaryResponse = new FillSummaryResponse();

    public E2EWrapper() {
        //prop.loadCustomProperties("config/sharedconfigproperties/");
    }

    public E2EWrapper(int storeId, String patientFirstName, String patientLastName, String patientDob, int numOfRxsNeeded, String dotComEmail,
                      String dotComPassword) {
        setStoreId(storeId);
        setPatientFirstName(patientFirstName);
        setPatientLastName(patientLastName);
        setPatientDob(patientDob);
        setDotComEmail(dotComEmail);
        setDotComPassword(dotComPassword);
        setNumOfRxsNeeded(numOfRxsNeeded);
        setDates(dateTimeFormatterUtil(getPatientDob()));
    }

    public HashMap<String, String> setHeaders_PatientCreationConnexus() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");

        return headers;
    }

    public HashMap<String, String> setHeaders_OrderReadyForPickup() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");

        return headers;
    }

    public HashMap<String, String> setHeaders_GetDeliveryEligible() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        return headers;
    }

    public HashMap<String, String> setHeaders_getOrderStatus() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Host","");
        return headers;
    }

    public HashMap<String, String> setHeaders_AddWalmartPlusMembership() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("version","nextgen");
        headers.put("Host","");
        headers.put("Content-Length","");
        return headers;
    }

    public HashMap<String, String> setHeaders_UpdatePayment() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        return headers;
    }

    public HashMap<String, String> setHeaders_CreateOrder() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("segment", "oaoh");
        headers.put("payment_version", "smart_allocation");
        headers.put("response_type", "omni");
        return headers;
    }

    public ServiceResponse performOrderReadyforPickup(Integer requestTypeCode, Integer priorityId, Integer dispenseType, Integer numRefills, String drugname, String ndc, Integer itemId, Integer rxProdId, Integer controlCode, Integer presMultiSrcCode, Integer onHandQty, String usualCost, String actCost, String orgUsualCost, Integer rxNbr, Integer rxFillId, Boolean allowExpiredOrder, Integer Patient_Id, Integer Site_Id, String Input_date, String Exp_date) {
        ServiceRequest req = new ServiceRequest();
        DigitalPharmacyOperationsUtil dputil = new DigitalPharmacyOperationsUtil();
        ConnexusPatientDataforPickup connexusPatientDataforPickup = new ConnexusPatientDataforPickup();
        Drug drug = new Drug();
        Prescriber prescriber = new Prescriber();
        connexusPatientDataforPickup.setRequestTypeCode(requestTypeCode);
        connexusPatientDataforPickup.setPriorityId(priorityId);
        connexusPatientDataforPickup.setDispenseType(dispenseType);
        connexusPatientDataforPickup.setPatientId(Patient_Id);
        connexusPatientDataforPickup.setSiteID(Site_Id);
        connexusPatientDataforPickup.setInputPickUpDate(Input_date);
        connexusPatientDataforPickup.setInputRxExpDate(Exp_date);
        connexusPatientDataforPickup.setNumRefills(numRefills);
        drug.setName(drugname);
        drug.setNdc(ndc);
        drug.setItemId(itemId);
        drug.setRxProdId(rxProdId);
        drug.setControlCode(controlCode);
        drug.setPresMultiSrcCode(presMultiSrcCode);
        drug.setOnHandQty(onHandQty);
        drug.setUsualCost(usualCost);
        drug.setActCost(actCost);
        drug.setOrgUsualCost(orgUsualCost);
        drug.setRxNbr(rxNbr);
        drug.setRxFillId(rxFillId);
        connexusPatientDataforPickup.setDrug(drug);
        connexusPatientDataforPickup.setAllowExpiredOrder(allowExpiredOrder);
        req.setRequestPayload(connexusPatientDataforPickup);
        req.setHeaders(setHeaders_OrderReadyForPickup());
        req.setUrl(prop.getProperty("RXPD_OrderReady_For_Pickup"));
        Reporter.log("Inside");
        Reporter.log("Request Payload" + req.getRequestPayload());
        Reporter.log("Request URL" + req.getUrl());
        Reporter.log("Request Payload" + req.getRequestPayload());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performPost(req);
        Reporter.log("Response " + response.getDataResponse());
        Reporter.log("Response " + response.getStatusCode());
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        return response;
    }

    public ServiceResponse performGEtDeliveryEligible(String careGiverEmail) throws InterruptedException {
        ServiceRequest req1 = new ServiceRequest();
        System.out.println("Inside Get Eligible Delivery");
        req.setUrl(prop.getProperty("RXPD_GetDelivery_Eligible") + careGiverEmail);
        req.setHeaders(setHeaders_GetDeliveryEligible());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performGet(req);
        System.out.println("Inside Get Delivery" + response.getDataResponse());
        System.out.println("Inside Get Delivery" + response.getStatusDesc());
        System.out.println("Inside Get Delivery"  + req.getRequestPayload());
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());

        return response;
    }

    public ServiceResponse performCreateeComCart(String caregiverEmail,String storeId,String prefId,String OrderType,Boolean isRx,String paymentType,boolean isMixedBasketOrder) throws InterruptedException {

        Boolean resolveHolds = true;
        String quantity = "1";
        ServiceRequest req = new ServiceRequest();
        CreateOrder createOrder=new CreateOrder();
        ArrayList<CreateFulfillmentGroup> fulfillmentGroups = new ArrayList<>();
        ArrayList<Item> item = new ArrayList<>();
        Item item1= new Item();
        Item item2= new Item();
        List<String> itemList = Arrays.asList("3060609341","5017285819","5017285815");
        CreateFulfillmentGroup fulfillmentGroup=new CreateFulfillmentGroup();
        createOrder.setPaymentType(paymentType);
        createOrder.setStoreId(storeId);
        createOrder.setCustomerEmailAddress(caregiverEmail);
        createOrder.setResolveHolds(resolveHolds);
        createOrder.setTerminateBefore("contractCreation");
        fulfillmentGroup.setOrderType(OrderType);
        item1.setQuantity(quantity);
        item1.setRx(isRx);
        item1.setItemId(prefId);
        item.add(item1);
        Random random = new Random();
        int randomIndex = random.nextInt(itemList.size());
        String randomElement = itemList.get(randomIndex);
        if (isMixedBasketOrder) {
            item2.setQuantity("1");
            item2.setItemId(randomElement);
            item.add(item2);
        }
        fulfillmentGroup.setItems(item);
        fulfillmentGroups.add(fulfillmentGroup);
        createOrder.setFulfillmentGroups(fulfillmentGroups);
        req.setRequestPayload(createOrder);
        req.setUrl(prop.getProperty("RXPD_Create_Order"));
        req.setHeaders(setHeaders_CreateOrder());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        System.out.println("Inside Create Cart"  + req.getRequestPayload());
        ServiceResponse response = am.getRestContext().performPost(req);
        Reporter.logJSON("HTTP Response for Create Cart : ", response.getDataResponse());
        System.out.println("Inside Create Cart" + response.getDataResponse());
        System.out.println("Inside Create Cart" + response.getStatusDesc());
        return response;
    }


    public ServiceResponse performUpdateDelivery(String Ordertype,String DeliveryStatus,String Order) throws InterruptedException {
        ServiceRequest req = new ServiceRequest();
        System.out.println("Inside update Delivery");
        UpdateDelivery updateDelivery=new UpdateDelivery();
        ArrayList<FulfillmentGroup> fulfillmentGroups = new ArrayList<>();
        req.setUrl(prop.getProperty("RXPD_Update_Delivery") + Order);
        req.setHeaders(setHeaders_GetDeliveryEligible());
        FulfillmentGroup fulfillmentGroup = new FulfillmentGroup();
        fulfillmentGroup.setStatus(DeliveryStatus);
        fulfillmentGroup.setOrderType(Ordertype);
        fulfillmentGroups.add(fulfillmentGroup);
        updateDelivery.setFulfillmentGroups(fulfillmentGroups);
        req.setRequestPayload(updateDelivery);
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performPut(req);
        System.out.println("Inside update Delivery" + response.getDataResponse());
        System.out.println("Inside update Delivery" + response.getStatusDesc());
        System.out.println("Inside update Delivery"  + req.getRequestPayload());
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        return response;
    }

    public List<String> dateTimeFormatterUtil(String dob) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        LocalDate date = LocalDate.parse(dob, inputFormatter);

        // Output formats
        DateTimeFormatter unixTimestampFormatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss");
        DateTimeFormatter yyyyMMddFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter ddMMyyyyFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss.SSS 'UTC'");
        DateTimeFormatter MMddyyyy = DateTimeFormatter.ofPattern("MMddyyyy");
        // Convert LocalDate to LocalDateTime at 00:00:00
        LocalDateTime dateTime = date.atStartOfDay();
        dateTime = dateTime.withHour(8).withMinute(0).withSecond(0).withNano(0);

        // Format output in different formats
        String unixTimestamp = dateTime.toEpochSecond(ZoneOffset.UTC) + "000"; // Unix timestamp at 00:00:00
        String formattedyyyyMMdd = dateTime.format(yyyyMMddFormatter);
        String formattedddMMyyyy = date.format(ddMMyyyyFormatter);
        String formattedCustom = dateTime.format(customFormatter);
        String formattedMMddyyyy = dateTime.format(MMddyyyy);
        List<String> dateFormatted = new ArrayList<>();
        dateFormatted.add(unixTimestamp);
        dateFormatted.add(formattedyyyyMMdd);
        dateFormatted.add(formattedddMMyyyy);
        dateFormatted.add(formattedCustom);
        dateFormatted.add(formattedMMddyyyy);
        return dateFormatted;
        //returns unix, yyyy-mm-dd, ddmmyyyy, mon dd yyyyy hh:mm:ss.sss UTC
    }

    public ServiceResponse performFetchDelivery(String Order) throws InterruptedException {
        ServiceRequest req = new ServiceRequest();
        System.out.println("Inside fetch Delivery");
        req.setUrl(prop.getProperty("RXPD_Update_Delivery") + Order);
        req.setHeaders(setHeaders_GetDeliveryEligible());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performGet(req);
        System.out.println("Inside fetch Delivery" + response.getDataResponse());
        System.out.println("Inside fetch Delivery" + response.getStatusDesc());
        System.out.println("Inside fetch Delivery"  + req.getRequestPayload());
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        return response;
    }

    public ServiceResponse getOrderStatus(String Order) throws InterruptedException {
        ServiceRequest req = new ServiceRequest();
        System.out.println("Inside fetch Delivery");
        req.setUrl(prop.getProperty("RXPD_GetOrderStatus") + Order);
        req.setHeaders(setHeaders_getOrderStatus());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performGet(req);
        System.out.println("Inside fetch Delivery" + response.getDataResponse());
        System.out.println("Inside fetch Delivery" + response.getStatusDesc());
        System.out.println("Inside fetch Delivery"  + req.getRequestPayload());
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        return response;
    }


    public ServiceResponse getCart(String emailId) throws InterruptedException {
        ServiceRequest req = new ServiceRequest();
        System.out.println("Inside Get Cart");
        req.setUrl(prop.getProperty("RXPD_Get_Cart") +emailId+ "/cart");
        req.setHeaders(setHeaders_CreateOrder());
        Reporter.log("GetCart Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performGet(req);
        System.out.println("Inside GetCart" + response.getDataResponse());
        Reporter.logJSON("HTTP Response of GetCart : ", response.getDataResponse());
        return response;
    }

    public ServiceResponse addWalmartPlusMembership(String emailId) throws InterruptedException {
        ServiceRequest req = new ServiceRequest();
        System.out.println("Inside Add Walmartplus Membership to Account");
        req.setUrl(prop.getProperty("RXPD_AddWalmartplusMembership") + emailId + "/wplus");
        req.setHeaders(setHeaders_GetDeliveryEligible());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performGet(req);
        System.out.println("Inside addWalmartPlusMembership"  + req.getRequestPayload());
        System.out.println("Inside addWalmartPlusMembership" + response.getDataResponse());
        Reporter.log(" addWalmartPlusMembership Response StatusCode : " + response.getStatusCode());
        Reporter.log("addWalmartPlusMembership Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response for addWalmartPlusMembership : ", response.getDataResponse());
        return response;
    }


    public ServiceResponse performUpdatePayment(String caregiverEmail,String caregiverFirstName,String caregiverLastName){
        ServiceRequest req1 = new ServiceRequest();
        ArrayList<String> paymentMethods= new ArrayList<>();
        UpdatePayment updatePayment=new UpdatePayment();
        PostalAddress postalAddress=new PostalAddress();
        String phoneNumber="1234567890";
        String payment="VISA";
        String address="2730 E McKellips Rd";
        String city="Mesa";
        String country="USA";
        String postalCode= "85213";
        String state="AZ";
        updatePayment.setFirstName(caregiverFirstName);
        updatePayment.setLastName(caregiverLastName);
        updatePayment.setEmailAddress(caregiverEmail);
        updatePayment.setPhoneNumber(phoneNumber);
        paymentMethods.add(payment);
        updatePayment.setPaymentMethods(paymentMethods);
        postalAddress.setAddress(address);
        postalAddress.setCity(city);
        postalAddress.setState(state);
        postalAddress.setCountry(country);
        postalAddress.setPostalCode(postalCode);
        updatePayment.setPostalAddress(postalAddress);
        req1.setRequestPayload(updatePayment);
        req1.setUrl(prop.getProperty("RXPD_Update_Payment"));
        req1.setHeaders((setHeaders_UpdatePayment()));
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        ServiceResponse response = am.getRestContext().performPost(req1);
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        System.out.println("Inside Update Payment request headers " + req.getHeaders());
        System.out.println("Inside Update Payment response data " + response.getDataResponse());
        System.out.println("Inside Update Payment status desc " + response.getStatusDesc());
        System.out.println("Inside Update Payment request payload "  + req.getRequestPayload());
        return response;
    }

    public ServiceResponse performCreateOrder(String caregiverEmail,String storeId,String prefId,String OrderType,Boolean isRx,String paymentType,boolean isMixedBasketOrder) throws InterruptedException {

        Boolean resolveHolds = true;
        String quantity = "1";
        ServiceRequest req = new ServiceRequest();
        CreateOrder createOrder=new CreateOrder();
        ArrayList<CreateFulfillmentGroup> fulfillmentGroups = new ArrayList<>();
        ArrayList<Item> item = new ArrayList<>();
        Item item1= new Item();
        Item item2= new Item();
        List<String> itemList = Arrays.asList("3060609341","5017285819","5017285815");
        CreateFulfillmentGroup fulfillmentGroup=new CreateFulfillmentGroup();
        createOrder.setPaymentType(paymentType);
        createOrder.setStoreId(storeId);
        createOrder.setCustomerEmailAddress(caregiverEmail);
        createOrder.setResolveHolds(resolveHolds);
        fulfillmentGroup.setOrderType(OrderType);
        item1.setQuantity(quantity);
        item1.setRx(isRx);
        item1.setItemId(prefId);
        item.add(item1);
        Random random = new Random();
        int randomIndex = random.nextInt(itemList.size());
        String randomElement = itemList.get(randomIndex);
        if (isMixedBasketOrder) {
            item2.setQuantity("1");
            item2.setItemId(randomElement);
            item.add(item2);
        }
        fulfillmentGroup.setItems(item);
        fulfillmentGroups.add(fulfillmentGroup);
        createOrder.setFulfillmentGroups(fulfillmentGroups);
        req.setRequestPayload(createOrder);
        req.setUrl(prop.getProperty("RXPD_Create_Order"));
        req.setHeaders(setHeaders_CreateOrder());
        Reporter.log("Environment Loaded : " + "stage");
        Reporter.log("Request endpoint : " + req.getUrl());
        System.out.println("Inside Create Order"  + req.getRequestPayload());
       ServiceResponse response = am.getRestContext().performPost(req);
        Reporter.log("Response StatusCode : " + response.getStatusCode());
        Reporter.log("Response Description : " + response.getStatusDesc());
        Reporter.logJSON("HTTP Response : ", response.getDataResponse());
        System.out.println("Inside Create Order" + req.getHeaders());
        System.out.println("Inside Create Order" + response.getDataResponse());
        System.out.println("Inside Create Order" + response.getStatusDesc());
        System.out.println("Inside Create Order"  + req.getRequestPayload());
        return response;
    }

    public List<String> dateTimeFormatterUtil1(String dob){
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        LocalDate date = LocalDate.parse(dob, inputFormatter);

        // Output formats
        DateTimeFormatter unixTimestampFormatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss");
        DateTimeFormatter yyyyMMddFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter ddMMyyyyFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss.SSS 'UTC'");

        // Convert LocalDate to LocalDateTime at 00:00:00
        LocalDateTime dateTime = date.atStartOfDay();
        dateTime = dateTime.withHour(8).withMinute(0).withSecond(0).withNano(0);

        // Format output in different formats
        String unixTimestamp = dateTime.toEpochSecond(ZoneOffset.UTC) + "000"; // Unix timestamp at 00:00:00
        String formattedyyyyMMdd = dateTime.format(yyyyMMddFormatter);
        String formattedddMMyyyy = date.format(ddMMyyyyFormatter);
        String formattedCustom = dateTime.format(customFormatter);
        List<String> dateFormatted = new ArrayList<>();   //Need to replace this with map
        dateFormatted.add(unixTimestamp);
        dateFormatted.add(formattedyyyyMMdd);
        dateFormatted.add(formattedddMMyyyy);
        dateFormatted.add(formattedCustom);
        return dateFormatted;
        //returns unix, yyyy-mm-dd, ddmmyyyy, mon dd yyyyy hh:mm:ss.sss UTC
    }

    public void generatePatient(int storeId, String firstName, String lastName, String dob, boolean isPet, String Gender, boolean isMinor){
        AddPatient addPatient = new AddPatient();
        addPatient.setSiteID(storeId);
        addPatient.setCommunicationID("7607567568");
        addPatient.setFirstName(firstName);
        addPatient.setLastName(lastName);
        addPatient.setMiddleName("");
        addPatient.setPatientName(lastName+","+firstName);
        // Format /Date(1286668800000)/
        addPatient.setDob(dob);
        addPatient.setGender("M");
        addPatient.setLanguage("101");
        addPatient.setStatus(20700);
        addPatient.setIsPatientMinor(isMinor);
        addPatient.setAddressTypeCode(3);
        addPatient.setVerifyFreCode(1);
        if(isPet)
            addPatient.setPatientTypeCode(10202);
        else
            addPatient.setPatientTypeCode(10200);
        addPatient.setUserId("VN50S29");
        addPatient.setAddressLine1("3101 SW TROON LN");
        addPatient.setAddressLine2("APT 26");
        addPatient.setCellPhone("7607567572");
        addPatient.setCity("BENTONVILLE");
        addPatient.setCountry("US");
        addPatient.setHomePhone("7607567568");
        addPatient.setState("AR");
        addPatient.setWorkPhone("7607567570");
        addPatient.setZipCode("72713");
        addPatient.setHipaaStatusCode(9510);
        connexusAPIManager.addPatientWithGenericAllParam(addPatient);
    }
    public HashMap<String, String> createAccount( String emailPhrase, String firstName, String lastName, String dob) throws InterruptedException{
        return createAccount(emailPhrase,firstName,lastName,dob,5548);
    }
    public HashMap<String, String> createAccount( String emailPhrase, String firstName, String lastName, String dob, int storeId) throws InterruptedException {
        // Connexus Actions Create Patient and Drop New RX
        List<String> dates = dateTimeFormatterUtil1(dob);
       // String[] ndcList = {"00256016501", "00496052348", "08290201044", "11161097863", "00998063006", "00093910729", "37937000338", "37937004510", "00089078521", "00089078511", "00009004902", "54000652100", "00006335671", "00015050842", "00275020001", "00395163216", "49452464001", "00904275738", "00212021151", "00591252250", "00078005304", "49452468002", "00469101000", "49452458501", "49452469002", "00703450204", "44087607503", "59930168701", "00078031190", "00904000514", "00078014923", "11161099910", "00193654621", "64011001004", "00713016612", "00054856604", "00121046230", "00089030303", "54531010001", "00597018461", "00058017004", "57664018808", "00081070901", "00225031020", "08881501210", "16110025907", "00574063216", "08881516150", "75137018305", "00045049824", "00045046302", "00122084166", "00187000101", "54274086310", "61392000539", "11845061401", "00517721025", "00536404610", "00193274121", "00517851025", "04000000139", "24385071779", "16500002502", "00009070005", "52083024015", "00003046660", "00839620667", "16837062730", "00832860316", "00182162501", "00832865216", "00781912695", "00259412615", "00015561660", "51674000707", "00555090202", "00054863211", "50486002735", "19458505702", "00536500572", "00904501835", "00536623572", "00814842314", "52735050954", "00338204948", "52544050821", "52544051021", "52544055028", "00024132304", "00047094211", "00574044025", "08225404205", "61570004710", "00033250513", "16500001020", "70501009500", "70501001330", "70501001300", "00536406801", "00223135202"};
        // int rnd = new Random().nextInt(ndcList.length);
        String emailToUse = emailPhrase;
        System.out.println(dates);
        generatePatient(storeId, firstName, lastName, "/Date("+dates.get(0)+")/", false, "M", false);
        patientId = getStorePatientIdFromCPR1(firstName, lastName, dates.get(1), "" + storeId);
        System.out.println("Patient id from store"+ patientId);
        resp=digitalPharmacyAPIManager.signUpAPI(emailToUse,"Walmart@1",firstName,lastName);
        // resp = digitalPharmacyAPIManager.createDotComAccount(emailToUse, "Test@1234", "9997801876", "Woah", "Ji");
        // Create Pharmacy Connected Account ISAC Flow
        String cid = digitalPharmacyAPIManager.getCidFromEmail(emailToUse);
        System.out.println("cid: " + cid);
        String[] cids = new String[1];
        cids[0] = cid;
        //clearAccountsCache(cids);
        System.out.println("Created Account: " + emailToUse + ", Password: Test@1234, Patient Name: " + firstName +
                ", PatientLastName: "+ lastName);
        Thread.sleep(10000);
        digitalPharmacyAPIManager.createPharmacyAccount_DPStg(cid, String.valueOf(patientId), dob, String.valueOf(storeId));
        Reporter.log("Create DpOpsUtils");
        DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtil =new DigitalPharmacyOperationsUtil();
        digitalPharmacyOperationsUtil.enableTestAccountInQa(cid, String.valueOf(storeId), String.valueOf(patientId),dob);
        HashMap<String, String> patientDetails = new HashMap<>();
        patientDetails.put("PatientId",String.valueOf(patientId));
        patientDetails.put("CID",cid);
        Reporter.log("Create account is done");
        return patientDetails;
    }
    
    public int getStorePatientIdFromCPR1(String firstName, String lastName, String dob, String storeNumber) throws InterruptedException {
        patientId = 0;
        int count = 0;
        headers.clear();
        headers.put("Authorization", prop.getProperty("cpr.static.auth"));
        headers.put("WM_SVC.NAME", prop.getProperty("cpr.wm.svc.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("cpr.wm.svc.env"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("cpr.wm.consumer.id"));
        headers.put("content-type", "application/json");
        req.setUrl(prop.getProperty("cpr.base.url") + "patient/centralSearch");
        req.setHeaders(headers);
        CentralPatientSearchRequest cprreq = new CentralPatientSearchRequest();
        cprreq.setStoreNbr(storeNumber);
        cprreq.setFirstName(firstName);
        cprreq.setLastName(lastName);
        cprreq.setBirthDate(dob);
        req.setRequestPayload(cprreq);
        Reporter.logJSON("CPR Get PatientID request Payload: ", req.getRequestPayload());
        System.out.println("CPR Get patientID request payload"+req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CPR Get PatientID Response Payload: ", resp.getDataResponse());
        System.out.println("CPR Get PatientID Response Payload" + resp.getDataResponse());
        while (resp.getStatusCode()!=200) {
            Thread.sleep(5000);
            resp = am.getRestContext().performPost(req);
            if (resp.getStatusCode()==200) {
                patientId = resp.getJsonElement("patients[0].patientId");
                break;
            }
            if (count > 3){
                break;
            }
            count++;
        }
        Reporter.logJSON("CPR Get PatientID Response Payload: ", resp.getDataResponse());
        System.out.println("patients[0].patientId" + "jsonpath");
        patientId = resp.getJsonElement("patients[0].patientId");
        Reporter.log("patientId=" + patientId);
        return patientId;
    }


    public int neweRxToPickup(int patientId, String ndc, String storeNbr) throws ParserConfigurationException, SAXException, IOException, SQLException {

        String messageId, inputPayload, drugName;
        int rxResponseId, orderId;
        List<Integer> respIds = new ArrayList<Integer>();
        File xmlData;

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNbr));

        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientId);

        //get Drug name
        drugName = eRxOrder.getDrugName(cnx, ndc);

        //get xml file to generate input payload
        xmlData = new File("src//test//resources//TestData//FomData//ERXpayload_CF1.xml");
        Reporter.log("NDC : "+ndc+" Drug name : "+drugName);

        //update the xml with required storeNbr, Date-time and a unique messageId
        messageId = UUID.randomUUID().toString().substring(0, 35);
        inputPayload = eRxOrder.updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);

        //drop ERX order and move it to Filling
        rxResponseId = eRxOrder.dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
        respIds.add(rxResponseId);
        orderId = eRxOrder.moveOrderToFilling(cnx, patientId, respIds);
       // connexusAPIManager.getOrderInfo(Integer.parseInt(storeNbr),"",1);

        //Setting Prescriber info
        prescriber.setFullname("THOMAS, WALDEN MACNAIR"); prescriber.setPhone("(898)989-8999"); prescriber.setState("CA");
        prescriber.setFirstname("WALDEN MACNAIR"); prescriber.setLastname("THOMAS"); prescriber.setPrescriberId(1105);
        prescriber.setRxClinicId(5308); prescriber.setDea("BT2413146"); prescriber.setNpi("2999997788");

       //Get FillDetails
        HashMap<String, Integer> fillDetails = new HashMap<>();
        fillDetails = getFillIdAndOrderId(cnx,rxResponseId);
        int fillId = fillDetails.get("rx_fill_id");
        int rxId = fillDetails.get("rx_id");

        //Moving order to pickup
        wrapperAPIManager.fillingToPickup(patientId,orderId,Integer.parseInt(storeNbr),fillId,rxId,0,ndc,prescriber);

        return patientId;
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = "+patientId+";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public HashMap<String, Integer> getFillIdAndOrderId(IDatabaseContext cnx, int rxResponseId) {
        String getWorkQueueQuery = "select next_work_que_code, order_id, rx_fill_id, rx_id from rx21c:informix.rx_order_detail \n" +
                "where rx_response_id in ("+rxResponseId+");";
        DataTable dt = cnx.getDataTable(getWorkQueueQuery);
        HashMap<String, Integer> fillDetails = new HashMap<>();
            DataRow row = dt.getDataRows().get(0);
            int fillId, rxId;
            //get orderId and fillId
            fillId =  row.getValue("rx_fill_id");
            rxId = row.getValue("rx_id");
        fillDetails.put("rx_fill_id", fillId);
        fillDetails.put("rx_id", rxId);
        return fillDetails;
    }

    public void getRxsInPickupAndMoveToEOD(DigitalPharmacyOperationsUtil customerObject) {

        String cid = digitalPharmacyAPIManager.getCidFromEmail(customerObject.getDotComEmail());
        FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
        com.walmart.hwqe.commons.apicontext.ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(cid);
        FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
        logger.info(fillSummaryResponse.toString());
        List<String> rxNumbers = new ArrayList<>();

        for(ReadyForPickup currentRfpRx: fillSummaryResponse.getCustomer().getFills().getReadyForPickup()){
            rxNumbers.add(currentRfpRx.getRxNbr());
        }
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(customerObject.getPatientFirstName(), customerObject.getPatientLastName(), customerObject.getDates().get(1), "" + customerObject.getStoreId());
        for (String rxNumber : rxNumbers) {

            // Get Rx Details From Rx table
            Map<String, Object> rxDetails = dbUtils.getRxTableInfo(customerObject.getStoreId(), rxNumber);
            Object rx_id = rxDetails.get("rx_id");
            Object num_fills = rxDetails.get("refills_auth_nbr");

            // Get Order (Current Fill) Details From rx_order_detail table
            Map<String, Object> rxFillId = dbUtils.getOrderDetailsFromRxId(customerObject.getStoreId(), Integer.parseInt(rx_id+""));
            Object fill_id = rxFillId.get("rx_fill_id");
            Object order_id = rxFillId.get("order_id");

            // Get NDC From DP API
            String ndc = digitalPharmacyAPIManager.getNdcForRx(cid, rxNumber);
            WrapperUtils wrapperUtils = new WrapperUtils();
            Prescriber prescriber = wrapperUtils.PrescriberDetails();

            wrapperAPIManager.moveOrderToEOD(patientId, (Integer.parseInt("" + order_id)),
                    customerObject.getStoreId(), (Integer.parseInt("" + fill_id)), (Integer.parseInt("" + rx_id)),
                    (Integer.parseInt("" + num_fills)), ndc, prescriber);
        }
    }

    private Map<String, JSONObject> getDataFromJson(String filePath) {
        CommonUtils commonUtils = new CommonUtils();
        JSONObject jsonObject = new JSONObject(commonUtils.readJsonFile(filePath));
        Map<String, JSONObject> testCasesData = new HashMap<>();
        for (Iterator<String> it = jsonObject.keys(); it.hasNext(); ) {
            String testCaseName = it.next();
            testCasesData.put(testCaseName, jsonObject.getJSONObject(testCaseName));
        }
        return testCasesData;
    }

   public void setVariables(InputPatientData.PatientRxData patientRxTestCaseData){
       setStoreId(patientRxTestCaseData.getStoreId());
       setPatientFirstName(patientRxTestCaseData.getFirstName());
       setPatientLastName(patientRxTestCaseData.getLastName());
       setPatientDob(patientRxTestCaseData.getPatientDOB());
       setDotComEmail(patientRxTestCaseData.getPatientEmail());
       setDotComPassword(patientRxTestCaseData.getPatientPassword());
       setNumOfRxsNeeded(patientRxTestCaseData.getNumOfRxsNeeded());
       setDates(dateTimeFormatterUtil(patientRxTestCaseData.getPatientDOB()));
   }

    public void createTestData(String method, String filePath) {
        InputPatientData.PatientRxData patientRxTestCaseData;
        Map<String, JSONObject> rxTestDataMapping = getDataFromJson(filePath);
        if (rxTestDataMapping.containsKey(method)) {
            Reporter.log("Creating Data for testcase :: " + method);
            patientRxTestCaseData = new Gson().fromJson(String.valueOf(rxTestDataMapping.get(method)), InputPatientData.PatientRxData.class);
            setVariables(patientRxTestCaseData);
            createDataForRxPDTestCase(patientRxTestCaseData);
            updateDataToJsonFile(filePath,method, CommonConstants.rxNumber,patientRxTestCaseData);
        }
    }

    private void createDataForRxPDTestCase(InputPatientData.PatientRxData rxDataRequirements) {
        // Deleting all fills which are in pickup queue for this user
        ArrayList<Integer> rxNumbers = new ArrayList<>();
        rxNumbers = getFillsInPickup();
        CancelFill cancelFill = new CancelFill();
        cancelFill.setSiteId(getStoreId());
        cancelFill.setRxNumbers(rxNumbers);
        wrapperAPIManager.CancelPrescriptionUsingRxNumber(cancelFill);
        if (rxNumbers.isEmpty()) {
            Reporter.log("No Prior Fills to cancel for this user :: " + getDotComEmail());
        }

        // Create Rxs in Pickup - These would be Ready For Pickup on the Pharmacy Dashboard
        List<String> createdRxNbrList = createRxForPatientInReadyForPickup();
        rxDataRequirements.setCreatedRxNbrList(createdRxNbrList);

        //Create Rx in EOD
        //Create Rx for Dependents
        //Create Rx and Move to EOD and raise refill and move to pickup
    }

    private void updateDataToJsonFile(String filePath,String method,String key,InputPatientData.PatientRxData patientRxTestCaseData){
        try {
            // 1. Read the JSON file
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(new File(filePath));
            // 2. Update the value
           String root = rootNode.path(method).path(key).toString();
           if (!root.isEmpty()){
               ( (ObjectNode)rootNode.path(method)).put(key, patientRxTestCaseData.getCreatedRxNbrList().toString());
           }
            // 3. Write the updated JSON back to the file
            objectMapper.writeValue(new File(filePath), rootNode);
            System.out.println("JSON file updated successfully.");
            Reporter.log("JSON file updated successfully for method :: " + method);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void freeCasprSlots() {
        JSONObject requestObj = new JSONObject(commonUtils.readJsonFile("src/main/resources/testData/rxpdRegression/slotCapacityRequest.json"));
        String requestBody = requestObj.toString();
        LocalDateTime localDateTime = LocalDateTime.now();
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneOffset.of("-07:00"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        String date = zonedDateTime.format(formatter);

        String resetCapacity  = "500";
        requestBody = requestBody.replaceAll("actualCapacityDateTime", date).replaceAll("capacityForSlot", resetCapacity);
        //setting slot capacity as 500
        rxPDAPIHelper.setSlotCapacity(requestBody);
    }

    public int completeStaging(int storeId, String omsOrderId) {
        /*
        OrderId that we get on the dotcom website is called as omsOrderId - From that we need to extract PurchaseOrderId - This is obtained from informix DB dispense_po_tracking
        Guide For Dispense PO Status:
        2 is order placed (dispense rq received)
        4 is popc complete.
        staging issue is 5.
        10 is canceled.
        */
        RxPDAPIWrapper rxpdApiWrapper = new RxPDAPIWrapper();
        Map<String, Object> presentDispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(storeId, omsOrderId);
        String purchaseOrderId = presentDispenseTrackingDetails.get("purchase_order_id").toString();

        Assert.assertEquals(presentDispenseTrackingDetails.get("status_code").toString(), "2", "Incorrect Dispense Status, please report");

        // Perform Assign and Fetch
        ServiceResponse response = rxpdApiWrapper.getAnFStagingInfo(storeId, purchaseOrderId);

        // Perform Staging Complete
        int stagingBagNumber = dbUtils.generateUniqueStagingBagNumber(storeId);
        int fillId = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].fills[0].rxFillId");
        String packageToteId = response.getJsonElement("packageToteInfo[0].packageToteId");
        int bagNumber = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].bagNumber");
        StagingIssuesAPIWrapper stagingIssuesAPIWrapper = new StagingIssuesAPIWrapper();
        stagingIssuesAPIWrapper.completeStaging(storeId + "", packageToteId, stagingBagNumber, bagNumber, fillId);

        // Check DB Again to Validate Successful POPC
        presentDispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(storeId, omsOrderId);
        Assert.assertEquals(presentDispenseTrackingDetails.get("status_code").toString(), "4", "There was an error in staging, please report");
        return stagingBagNumber;
    }

    public void cancelOrderFromBE(int storeId, String omsOrderId, int stagingBagNumber) {
        /*
        OrderId that we get on the dotcom website is called as omsOrderId - From that we need to extract PurchaseOrderId - This is obtained from informix DB dispense_po_tracking
        Guide For Dispense PO Status:
        2 is order placed (dispense rq received)
        4 is popc complete.
        staging issue is 5.
        10 is canceled.
        */

        RxPDAPIWrapper rxpdApiWrapper = new RxPDAPIWrapper();
        Map<String, Object> presentDispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(storeId, omsOrderId);
        String purchaseOrderId = presentDispenseTrackingDetails.get("purchase_order_id").toString();

        Assert.assertEquals(presentDispenseTrackingDetails.get("status_code").toString(), "5", "Incorrect Dispense Status, please report");

        // Perform Assign and Fetch Stage Issue
        ServiceResponse response = rxpdApiWrapper.getAnFStagedIssue(storeId, purchaseOrderId);

        // Perform Staging Issue Complete
        int fillId = response.getJsonElement("packageToteInfo[0].orderAndBagInfo[0].orderInfo[0].fills[0].rxFillId");
        String packageToteId = response.getJsonElement("packageToteInfo[0].packageToteId");
        int bagNumber = response.getJsonElement("packageToteInfo[0].orderAndBagInfo[0].bagNumber");
        StagingIssuesAPIWrapper stagingIssuesAPIWrapper = new StagingIssuesAPIWrapper();
        stagingIssuesAPIWrapper.completeStagingIssueAfterAssignAndFetchIssueInfo(storeId + "", purchaseOrderId, packageToteId, 2, stagingBagNumber, fillId, 1, bagNumber);

        // Check DB Again to Validate Order Canceled
        presentDispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(storeId, omsOrderId);
        Assert.assertEquals(presentDispenseTrackingDetails.get("status_code").toString(), "10", "There was an error in cancellation, please report");
    }

    public Integer getPatientIdFromCid() {
        int patientId = 0, counter = 0;
        if (fillSummaryResponse != null && fillSummaryResponse.getCustomer() != null && fillSummaryResponse.getCustomer().getFills() != null && fillSummaryResponse.getCustomer().getFills().getReadyForPickup()!= null) {
            while (counter<fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size()) {
                ReadyForPickup readyForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(counter);
                if (readyForPickup.getStoreId() != null && readyForPickup.getStoreId().equals(getStoreId())) {
                    patientId =  readyForPickup.getPatientId();
                    break;
                }
                counter++;
            }
        }
        return patientId;
    }

    public ArrayList<Integer> getFillsInPickup() {
        String cid = digitalPharmacyAPIManager.getCidFromEmail(getDotComEmail());
        ArrayList<Integer> rxNumber = new ArrayList<>();
        FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
        com.walmart.hwqe.commons.apicontext.ServiceResponse response = fillSummaryWrapper.getFillSummaryDetails(cid);
        fillSummaryResponse = response.getDataResponse(FillSummaryResponse.class);
        if (fillSummaryResponse != null && fillSummaryResponse.getCustomer() != null && fillSummaryResponse.getCustomer().getFills() != null && fillSummaryResponse.getCustomer().getFills().getReadyForPickup()!= null) {
            for (int i=0;i<fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size();i++) {
                ReadyForPickup readyForPickup = fillSummaryResponse.getCustomer().getFills().getReadyForPickup().get(i);
                if (readyForPickup.getStoreId() != null && readyForPickup.getStoreId().equals(getStoreId())) {
                    rxNumber.add(Integer.valueOf(readyForPickup.getRxNbr()));
                }
            }
        }
        return rxNumber;
    }

    public List<String> createRxForPatientInReadyForPickup() {
        //DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
        int patientId = getPatientIdFromCid();
        if (patientId == 0) {
            patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(getPatientFirstName(),getPatientLastName(),getDates().get(1),String.valueOf(getStoreId()));
        }
        WrapperUtils wrapperUtils = new WrapperUtils();
        Prescriber prescriber = null;
        List<String> createdRxNbrList = new ArrayList<>();
        prescriber = wrapperUtils.PrescriberDetails();
        List<ServiceResponse> responseList = new ArrayList<>();
        int rnd = new Random().nextInt(ndcList.length);
        IDatabaseContext cnx = am.getConnexusDB(storeId);
        DataRow prescriberData = dbUtils.getPrescriberInfo(cnx, prescriber.getPrescriberId());
        for (int i = 0; i < getNumOfRxsNeeded(); i++) {
            DataRow drugInfo = dbUtils.getDrugInfo(cnx, ndcList[rnd]);
            responseList.add(wrapperAPIManager.orderToPickup(getStoreId(), patientId, 21100, 1600, 1, 5, new SimpleDateFormat("MMM dd yyyy").format(new Date()) + " 08:00:00.000 UTC", 6105,
                    new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", drugInfo, prescriberData));
        }
        for (ServiceResponse currServiceResponse : responseList) {
            createdRxNbrList.add(currServiceResponse.getJsonElement("rxNbr").toString());
        }

        return createdRxNbrList;
    }

    public Boolean moveRxsFromAllStatesForDPCustomerToEOD(DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtilObject) {
        if(true) {
            String cid = digitalPharmacyAPIManager.getCidFromEmail(digitalPharmacyOperationsUtilObject.getDotComEmail());
            FillSummaryWrapper fillSummaryWrapper = new FillSummaryWrapper();
            com.walmart.hwqe.commons.apicontext.ServiceResponse serRes = fillSummaryWrapper.getFillSummaryDetails(cid);
            FillSummaryResponse fillSummaryResponse = serRes.getDataResponse(FillSummaryResponse.class);
            logger.info(fillSummaryResponse.toString());

            HashMap<String, Integer> fillIdAndStore = new LinkedHashMap<>();
            if(fillSummaryResponse.getCustomer().getFills().getFilling() != null && fillSummaryResponse.getCustomer().getFills().getFilling().size() > 0) {
                Reporter.log("Filling Rx's found in Fill Summary Response");
                for(Filling fillingRx: fillSummaryResponse.getCustomer().getFills().getFilling()) {
                    fillIdAndStore.put(fillingRx.getFillId()+"", fillingRx.getStoreId());
                }
            } else {
                Reporter.log("No Filling Rx's found in Fill Summary Response");
            }

            if(fillSummaryResponse.getCustomer().getFills().getDelayed() != null && fillSummaryResponse.getCustomer().getFills().getDelayed().size() > 0) {
                Reporter.log("Delayed Rx's found in Fill Summary Response");
                for(Delayed delayedRx: fillSummaryResponse.getCustomer().getFills().getDelayed()){
                    fillIdAndStore.put(delayedRx.getFillId()+"", delayedRx.getStoreId());
                }
            } else {
                Reporter.log("No Delayed Rx's found in Fill Summary Response");
            }

            if(fillSummaryResponse.getCustomer().getFills().getReadyForPickup() != null && fillSummaryResponse.getCustomer().getFills().getReadyForPickup().size() > 0) {
                Reporter.log("ReadyForPickup Rx's found in Fill Summary Response");
                for(ReadyForPickup currentRfpRx: fillSummaryResponse.getCustomer().getFills().getReadyForPickup()){
                    fillIdAndStore.put(currentRfpRx.getFillId()+"", currentRfpRx.getStoreId());
                }
            } else {
                Reporter.log("No ReadyForPickup Rx's found in Fill Summary Response");
            }

            if (fillIdAndStore.isEmpty()) {
                Reporter.log("No Rx's found in Fill Summary Response to move to EOD");
                return false;
            }

            for (Map.Entry<String,Integer> entry : fillIdAndStore.entrySet()) {
                Reporter.log("Moving Rx's to EOD for FillId: " + entry.getKey() + " and StoreId: " + entry.getValue());
                // Get Order Detalils
                ServiceResponse getOrderInfoResponse = wrapperAPIManager.getOrderInfo(entry.getValue(), Integer.parseInt(entry.getKey()), 2);
                String ndc = getOrderInfoResponse.getJsonElement("drug.ndc").toString();
                String orderId = getOrderInfoResponse.getJsonElement("orderId").toString();
                String patientId = getOrderInfoResponse.getJsonElement("patientId").toString();
                String rxId = getOrderInfoResponse.getJsonElement("rxId").toString();
                String numRefills = getOrderInfoResponse.getJsonElement("numRefills").toString();
                WrapperUtils wrapperUtils = new WrapperUtils();
                Prescriber prescriber = wrapperUtils.PrescriberDetails();

                wrapperAPIManager.moveOrderToEOD(Integer.parseInt(patientId), (Integer.parseInt("" + orderId)),
                        entry.getValue(), (Integer.parseInt("" + entry.getKey())), (Integer.parseInt("" + rxId)),
                        (Integer.parseInt("" + numRefills)), ndc, prescriber);
            }
            return true;
        }
        return false;
    }

    public Boolean createRFPRxForC2Drug(DigitalPharmacyOperationsUtil digitalPharmacyOperationsUtilObject) {
        try {
            int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(digitalPharmacyOperationsUtilObject.getPatientFirstName(), digitalPharmacyOperationsUtilObject.getPatientLastName(), digitalPharmacyOperationsUtilObject.getDates().get(1), "" + digitalPharmacyOperationsUtilObject.getStoreId());
            WrapperUtils wrapperUtils = new WrapperUtils();
            Prescriber prescriber = null;
            List<String> createdRxNbrList = new ArrayList<>();
            // List<InputResponse> response= connexusAPIManager.createMultiRxAndMoveToPickup(patientId, getStoreId(), 5, Arrays.asList(ndcList).subList(0, getNumOfRxsNeeded()), prescriber);
            prescriber = wrapperUtils.PrescriberDetails();
            IDatabaseContext cnx = am.getConnexusDB(digitalPharmacyOperationsUtilObject.getStoreId());
            DataRow prescriberData = dbUtils.getPrescriberInfo(cnx, prescriber.getPrescriberId());
            // ndc for Fentanyl
            DataRow drugInfo = dbUtils.getDrugInfo(cnx, "00378912198");
            for (int i = 0; i < digitalPharmacyOperationsUtilObject.getNumOfRxsNeeded(); i++) {
                wrapperAPIManager.orderToPickup(digitalPharmacyOperationsUtilObject.getStoreId(), patientId, 21100, 1600, 1, 5, new SimpleDateFormat("MMM dd yyyy").format(new Date()) + " 08:00:00.000 UTC", 6105,
                        new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", drugInfo, prescriberData);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Error while creating RFPRx for C2 Drug");
            return false;
        } catch (AssertionError arr) {
            arr.printStackTrace();
            Reporter.log("Assertion Error while creating RFPRx for C2 Drug");
            return false;
        }
    }

}

