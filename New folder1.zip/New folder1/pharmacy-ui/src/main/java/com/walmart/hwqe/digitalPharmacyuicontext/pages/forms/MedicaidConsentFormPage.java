package com.walmart.hwqe.digitalPharmacyuicontext.pages.forms;

import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class MedicaidConsentFormPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Medicaid Disclosure']")
    @FindBy(xpath = "//div[@role='dialog']//h2")
    public WebElement medicaidDisclosure;

    @AndroidFindBy(id = "com.walmart.android.debug:id/medicaid_web_view")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'I am the recipient or an authorized representative')]")
    @FindBy(xpath = "//div[@role='dialog']//p")
    public WebElement medicaidDisclosureConsentBodyText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/medicaid_web_view")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='This prescription requires you to acknowledge the following disclosure to add to cart.']")
    @FindBy(xpath = "//div[@role='dialog']//h3")
    public WebElement medicaidDisclosureAcknowledgeText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/medicaid_positive_btn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Acknowledge']")
    @FindBy(xpath = "//div[@role='dialog']//button[text()='Acknowledge']")
    public WebElement acknowledgeMedicaidSwitchToCash;

    @AndroidFindBy(id = "com.walmart.android.debug:id/medicaid_negative_btn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='PrimaryAndLinkButtonView.linkButton']")
    @FindBy(xpath = "//div[@role='dialog']//button[text()='Pick up instead']")
    public WebElement medicaidConsentPickupInstead;

    @AndroidFindBy(id = "com.walmart.android.debug:id/disclaimer")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='PrimaryAndLinkButtonView.headerLabel']")
    @FindBy(xpath = "//div[@role='dialog']//span")
    public WebElement medicaidDisclaimerText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/icon_close")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='MedicaidDisclosureViewController.Close']")
    @FindBy(xpath = "//div[@role='dialog']//button[@aria-label='Close dialog']")
    public WebElement medicaidConsentCloseIcon;

    @FindBy(xpath = "//button[contains(text(), 'Acknowledge')]")
    public WebElement medicaidDisclosureAcknowledgeCTA;

    public MedicaidConsentFormPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getMedicaidSwitchToCashTitle() {
        return getText(medicaidDisclosure);
    }

    public String getMedicaidDisclosureAcknowledgementText() {
        return getText(medicaidDisclosureAcknowledgeText);
    }

    public String getMedicaidDisclosureConsentText() {
        return getText(medicaidDisclosureConsentBodyText);
    }

    public String getMedicaidConsentDisclaimerText() {
        return getText(medicaidDisclaimerText);
    }

    public boolean checkAcknowledgeButtonVisibility() {
        return isElementDisplayed(acknowledgeMedicaidSwitchToCash);
    }

    public boolean checkPickupInsteadLinkVisibility() {
        return isElementDisplayed(medicaidConsentPickupInstead);
    }

    public boolean medicaidFormCloseIconVisibility() {
        return isElementDisplayed(medicaidConsentCloseIcon);
    }

    public void acceptMedicaidClosure(){ click(acknowledgeMedicaidSwitchToCash); }

    public void clickMedicaidDisclosureAcknowledgeCTA(){ unblockingClick(medicaidDisclosureAcknowledgeCTA, 2, "Acknowledge Medicaid Disclosure While Adding To Cart");}

}