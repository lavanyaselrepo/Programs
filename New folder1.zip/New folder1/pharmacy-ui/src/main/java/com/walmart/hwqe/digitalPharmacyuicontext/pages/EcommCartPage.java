package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class EcommCartPage extends MobileBasePage {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='CartItemTileView.remove']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/cart_remove_button")
    @FindBy(xpath = "//button[text()='Remove']")
    public WebElement removeRxFromCart;

    @iOSXCUITFindBy(accessibility = "CartHeaderCellContainer")
    @AndroidFindBy(id = "com.walmart.android.debug:id/cartItemsText")
    @FindBy(xpath = "//h1[@id='cartHeader']//following-sibling::span")
    public WebElement getEcommCartTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Prescription item']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/text")
    public WebElement prescriptionListEle;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='PrescriptionBadgeView.titleLabel'])[2]")
    @FindBy(xpath = "//i[contains(@class,'Insurance')]//following-sibling::p")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'Insurance')]")
    public WebElement insuranceTitle;

    @FindBy(xpath = "//p[contains(text(), \"No coverage applied\")]")
    public List<WebElement> insuranceTitlesForAllItems;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='CartItemTileView.fulfillmentBadge']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/item_fulfillment_badge")
    public WebElement deliveryOnlyBadge;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='FulfillmentSummaryView.titlePrefixLabel']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/fulfillment_method")
    @FindBy(xpath = "//h2[@data-testid='fulfillment-heading']")
    public WebElement deliverySectionTitle;

    @FindBy(xpath = "//label[@for='fulfillment-DELIVERY']")
    public WebElement deliveryOption;

    @FindBy(xpath = "//*[@data-testid='show-bookslot-cta']")
    public WebElement changeLnk;

    @FindBy(xpath = "//button[@aria-label='Pickup']")
    public WebElement pickupTab;

    @FindBy(xpath = "//*[@data-automation-id='bookslot-slot-list-item-0']")
    public WebElement pickupFirstSlot;

    @FindBy(xpath = "//button[text()='Reserve']")
    public WebElement reserveBtn;

    @FindBy(xpath = "//button[contains(@aria-label, 'Remove')]")
    public List<WebElement> removeButtons;

    @FindBy(xpath = "//*[text()='Curbside pickup unavailable']")
    public WebElement curbsidePickupNotAvailableTxt;

    @FindBy(xpath = "//*[text()='Save for later']")
    @iOSXCUITFindBy(accessibility = "Save for later")
    public WebElement saveForLaterLink;

    @FindBy(xpath = "//*[contains(@src, '/v1/hw-pharmacy-pill-v2.jpg')]")
    @iOSXCUITFindBy(accessibility = "CartItemTileView.productImageView.small")
    public List<WebElement> rxImages;

    @FindBy(xpath = "//*[@data-testid='recommendation-containers-group']")
    public WebElement recommendationProductsGroup;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='RxRemoveConfirmationViewController.actionButton']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/cart_pharmacy_remove_prescriptions_primary_button")
    @FindBy(xpath = "//button//span[text()='Remove from cart']")
    public WebElement confirmRemoveFromCartCTA;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/product_name' and contains(@text,'Reading Glasse for Women')]")
    @FindBy(xpath = "//a[not(contains(@href,'pharmacyRefId'))]//div[@data-testid='productName']//span")
    public WebElement getNonRxItemText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='CartItemTileView.nameLabel' and @label='Reading Glasse for Women Blue Light Blocking HD Lens Fashion Reader. Qty 1, at $12.00/per unit. Cost: $12.00.']")
    public WebElement getNonRxItemButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='CartItemTileView.nameLabel' and contains(@label,'Reading Glasse for Women Blue')]")
    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc=Reading Glasse for Women Blue Light Blocking HD Lens Fashion Reader Decrease quantity']")
    @FindBy(xpath = "//i[@class='ld ld-Minus']")
    public WebElement removeNonRxItem;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Remove Reading Glasse for Women Blue Light Blocking HD Lens Fashion Reader']")
    public WebElement removeButton;

    @AndroidFindBy(accessibility = "Go back")
    public WebElement backButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/cart_empty_title")
    @FindBy(xpath = "//h2[contains(text(),\"Your cart is empty\")]")
    public WebElement cartEmptyText;

    @FindBy(xpath = "//span[contains(text(),\"can't be delivered\")]")
    public WebElement prescriptionNotAvlForDeliveryTxt;

    @FindBy(xpath = "(//div[@data-testid='unavailable-item-group-heading']//div)[3]")
    public WebElement prescriptionCannotBeDeliveredTxt;

    @FindBy(xpath = "//button[contains(text(),\"View details\")]")
    public WebElement viewDetailsLink;

    @FindBy(xpath = "//button[contains(text(),\"Got it\")]")
    public WebElement gotItButton;

    @FindBy(xpath = "//button[contains(@class,'black pointer')]")
    public WebElement promoCodeChevronButton;

    @FindBy(xpath = "//span[contains(text(),'Promo code')]/following::input")
    public WebElement promoCodeInput;

    @FindBy(xpath = "//button[@data-test-id='apply-promo']")
    public WebElement applyPromoButton;

    @FindBy(xpath = "//span[contains(text(),'Promo code')]/following::span[2]")
    public WebElement promoCodeErrorText;

    @FindBy(xpath = "//button[@data-automation-id='fulfillment-banner']")
    public WebElement howYouWantYourItemDownChevron;

    @FindBy(xpath = "(//div[@data-automation-id='fulfillment-address'])[2]/button")
    public WebElement deliveryFromStore;

    @FindBy(xpath = "(//div[@data-automation-id='fulfillment-address'])[1]/button")
    public WebElement deliveryToAddressChevron;

    @FindBy(id = "zip-code-or-city-state")
    public WebElement zipCodeOrCityStateInput;


    @FindBy(xpath = "//button[@data-automation-id='save-label']")
    public WebElement saveNewStoreSelected;


    @FindBy(xpath = "//button[@aria-label='view details of item updates']")
    public WebElement viewDetailsButton;

    @FindBy(xpath = "//span[@class='b f6']") // Item updates text
    public WebElement itemUpdatesText;

    @FindBy(xpath ="//*[@class='w_2NhK']//section//span")
    public WebElement itemDeliveryIneligibleErrorMessage;
    @FindBy(xpath = "//button[@class='w_hhLG w_8nsR w_lgOn w_jDfj'and contains(text(),'Got it')]")
    public WebElement gotit;

    @FindBy(xpath = "//button[@aria-label='Close dialog']")
    public WebElement closeWalmartPlusTravelProgramButton;

    @FindBy(xpath = "//button[text()='Confirm address']")
    public WebElement deliveryAddressSaveButton;

    @FindBy(xpath = "//div[@role='alert']")
    public WebElement errorAlertOnStoreSave;

    @FindBy(xpath = "//button[text()='Refresh page']")
    public WebElement refreshPageCTA;

    @FindBy(xpath = "//button[contains(text(),\"Continue without Pharmacy items\")]")
    public WebElement continueWithoutPharmacyItemsButton;

      public EcommCartPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void removeRxItemFromCart() {
        click(removeRxFromCart);
    }


    public void confirmRemoveFromCart() {
                click(confirmRemoveFromCartCTA);
    }

    public String getEcommCartTitle(){ return getText(getEcommCartTitle); }

    public boolean isRecommendationProductsGroupVisible() { return isElementDisplayed(recommendationProductsGroup,2); }

    public boolean isSaveForLaterLinkVisible() { return isElementDisplayed(saveForLaterLink,2); }

    public boolean verifyPrescriptionListEleForRX() { return isElementDisplayed(prescriptionListEle); }

    public String getInsuranceTitleTextForRx() { return getText(insuranceTitle); }

    public String getDeliveryOnlyBadgeTextForRx() { return getText(deliveryOnlyBadge); }

    public void clickOnDeliveryOption() { click(deliveryOption,"Delivery Option"); }

    public void clickOnChangeLink() { click(changeLnk,"Change Link"); }

    public void clickOnPickupTab() {
          if(isElementDisplayed(pickupTab, 3))
          click(pickupTab,"Pickup Tab");
      }

    public void clearCart() {
        for(WebElement ele : removeButtons){
            click(ele,"Remove Button");
            if(isElementDisplayed(confirmRemoveFromCartCTA,1)){
                click(confirmRemoveFromCartCTA,"Remove from Cart button");
            }
        }
    }

    public void clickOnPickupFirstSlotRdoBtn() {
          scrollElementForWebAndMobile(pickupFirstSlot, "Pickup Slot", "up");
          click(pickupFirstSlot,"Pickup First Slot Radio Button");
      }

    public void clickOnReserveBtn() { click(reserveBtn,"Reserve Button"); }

    public boolean isCurbsidePickupNotAvailableTextDisplayed() { return isElementDisplayed(curbsidePickupNotAvailableTxt); }

    public String getDeliverySectionTitle() { return getText(deliverySectionTitle); }

    public String getNonRxItemText(String item) {
       // androidScrollToText(item);
        return getText(getNonRxItemText);
    }

    public boolean nonRxItemIsDisplayed() { return isElementDisplayed(getNonRxItemButton); }
    public void clickBackButton(){click(backButton);}

    public void removeNonRxItem() {
        if (isElementDisplayed(removeNonRxItem, 8)) {
            click(removeNonRxItem);
        } else {
            click(removeButton);
        }
    }

    public String getCartIsEmptyText(){
        return getText(cartEmptyText);
    }

    public int getNumberOfPrescriptionsInCart(){
        List<WebElement> prescriptionItemText = getDynamicWebElementsByIdentifier("text", "Prescription item");
        return prescriptionItemText.size();
    }

    public String getPrescriptionNotAvlForDeliveryText() { return getText(prescriptionNotAvlForDeliveryTxt); }

    public String getPrescriptionCannotBeDeliveredText() { return getText(prescriptionCannotBeDeliveredTxt); }

    public void clickOnViewDetailsLink() { unblockingClick(viewDetailsLink, 2, "viewDetailsLink"); }

    public void clickGotItButton() { click(gotItButton); }

    public void clickPromoCodeChevronButton() { scrollToElement(promoCodeChevronButton); click(promoCodeChevronButton); }

    public void inputPromoCode() { sendText(promoCodeInput,"GLS5OFF"); }

    public void clickApplyPromoCodeButton() { click(applyPromoButton); }

    public String getPromoCodeErrorText() {
        scrollToElement(promoCodeErrorText);
        return getText(promoCodeErrorText);
    }

    public void clickOnHowYouWantYourItemDownChevron() {
            click(howYouWantYourItemDownChevron, "How do you want your Items-Down Chevron to open?");
    }

    public void clickOnDeliveryFromStore() {
        click(deliveryFromStore, "Current selected Delivery From Store");
        Reporter.log("Clicked on Delivery from store address");
    }

    public void enterZipCodeOrCityState(String zipCode) {
        sendText(zipCodeOrCityStateInput, zipCode, "Zip Code");
        Reporter.log("new zipcode is entered to search for delivery from stores.");
    }

    public void clickViewDetailsButton() {
        viewDetailsButton.click();
        Reporter.log("Clicked on view details link in item ineligible for delivery message in cart page");
    }

    public String getItemErrorDetailsText() {
       return itemDeliveryIneligibleErrorMessage.getText();
    }

    public void clickSaveNewStoreSelected(){
          click(saveNewStoreSelected);
    }

    public void clickWalmartPlusTravelProgramButton() {
        try{
            if(isElementDisplayed(closeWalmartPlusTravelProgramButton)) {
                click(closeWalmartPlusTravelProgramButton);
            }
        }catch (Exception e){
            System.out.println("WalmartPlus travel program close button Not Clicked");
            e.printStackTrace();
        }
    }

    public void clickDeliveryToAddressChevron(){
        click(deliveryToAddressChevron);
    }

    public void clickDeliveryAddressSaveButton(){
        click(deliveryAddressSaveButton);
    }

    public void clickRefreshPageCTA() {
        click(refreshPageCTA);
    }

    public void clickContinueWithoutPharmacyItemsButton() {
        click(continueWithoutPharmacyItemsButton);
    }
}