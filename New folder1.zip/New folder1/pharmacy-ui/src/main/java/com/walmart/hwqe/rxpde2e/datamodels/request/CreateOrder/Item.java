package com.walmart.hwqe.rxpde2e.datamodels.request.CreateOrder;

@lombok.Getter
@lombok.Setter
public class Item {
    public String itemId;
    public boolean isRx;
    public String quantity;
}
