/**
 * DigitalPharmacyIOSPlatformManager is the implementation of ICommonDriver for the platform type "IOS".
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;


import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.webcontext.interfaces.ICommonDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.io.File;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Slf4j
public class DigitalPharmacyIOSPlatformManager implements ICommonDriver {

    private static ThreadLocal<AppiumDriver> appiumDriverThreadLocal = new ThreadLocal<>();
    PropertyReader prop = PropertyReaderHelper.getInstance();

    private String getProp(String key, String defaultValue) {
        String value = prop.getProperty(key);
        return value != null ? value : defaultValue;
    }

    public DigitalPharmacyIOSPlatformManager() {
    }

    public RemoteWebDriver getDriver() {
        return appiumDriverThreadLocal.get();
    }

    public void getSessionInformation() {
        System.out.println(appiumDriverThreadLocal.get().getCapabilities().toString());
        Reporter.log(appiumDriverThreadLocal.get().getCapabilities().toString());
    }

    /**
     * launchPlatformApp method initialises an IOSDriver instance driven entirely by
     * {@code dp.ios.run.mode} in ios-config.properties. Supported modes:
     * <ul>
     *   <li>{@code sauce.real.device} – SauceLabs cloud, physical iOS device (default)</li>
     *   <li>{@code sauce.simulator}   – SauceLabs cloud, iOS simulator</li>
     *   <li>{@code local.real.device} – Local Appium server, USB-connected physical device</li>
     *   <li>{@code local.simulator}   – Local Appium server, running iOS simulator</li>
     * </ul>
     *
     * @param testName test case name shown in SauceLabs session / reporter.
     * @return RemoteWebDriver instance.
     * @Author: Saloni Sharma
     */
    public RemoteWebDriver launchPlatformApp(String testName) {

        AppiumDriver driver = null;
        String runMode = getProp("dp.ios.run.mode", "sauce.real.device");
        boolean onSauce   = runMode.startsWith("sauce.");
        boolean simulator = runMode.endsWith(".simulator");

        log.info("iOS run mode: {}", runMode);

        try {
            if (onSauce) {
                driver = launchOnSauce(testName, simulator);
            } else {
                driver = launchLocally(simulator);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        appiumDriverThreadLocal.set(driver);
        return driver;
    }

    /**
     * Builds and starts an IOSDriver session against SauceLabs.
     * Device identity (name / platformVersion / app filename) is read from properties
     * based on whether a simulator or real device is requested.
     */
    private AppiumDriver launchOnSauce(String testName, boolean simulator) throws Exception {
        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "iOS");
        caps.setCapability("appium:automationName", "XCUITest");
        caps.setCapability("appium:bundleId", getProp("dp.ios.app.bundle.id", "com.walmart.beta.electronics"));
        caps.setCapability("appium:noReset", false);
        // autoDismissAlerts clicks "Not Now" / "Cancel" on native iOS alerts (e.g. "Save Password?"),
        // preventing credentials from being saved to Keychain and avoiding AutoFill popups on future runs.
        // Use explicit clicks in test code for permission alerts that need to be accepted.
        caps.setCapability("appium:autoDismissAlerts", true);
        // Reuse the already-compiled WDA on SauceLabs instead of rebuilding per session
        caps.setCapability("appium:usePrebuiltWDA", true);
        caps.setCapability("appium:useNewWDA", false);
        // Limit XCUITest snapshot depth — without this, every element lookup traverses
        // the full UI tree causing multi-second delays on complex screens
        caps.setCapability("appium:snapshotMaxDepth",
                Integer.parseInt(getProp("dp.ios.snapshot.max.depth", "62")));
        // Disable animations so XCUITest can settle the UI faster between actions
        caps.setCapability("appium:reduceMotion", true);
        // WDA default post-tap idle wait is 20s; 5s covers most transitions without over-waiting
        caps.setCapability("appium:waitForIdleTimeout", 0);
        // Give WDA enough time to launch and connect on real SauceLabs devices
        caps.setCapability("appium:wdaLaunchTimeout",
                Integer.parseInt(getProp("dp.ios.wda.launch.timeout", "120000")));
        caps.setCapability("appium:wdaConnectionTimeout",
                Integer.parseInt(getProp("dp.ios.wda.connection.timeout", "120000")));
        // Pass Teflon env as a proper Map — XCUITest driver reads this at app launch
        // so no mid-session environment switching is ever needed.
        caps.setCapability("appium:processArguments", buildTeflonProcessArguments());

        if (simulator) {
            caps.setCapability("appium:app",             "storage:filename=" + prop.getProperty("dp.ios.sauce.simulator.app.filename"));
            caps.setCapability("appium:deviceName",      prop.getProperty("dp.ios.sauce.simulator.device.name"));
            caps.setCapability("appium:platformVersion", prop.getProperty("dp.ios.sauce.simulator.platform.version"));
        } else {
            caps.setCapability("appium:app",             "storage:filename=" + prop.getProperty("dp.ios.sauce.real.device.app.filename"));
            caps.setCapability("appium:deviceName",      prop.getProperty("dp.ios.sauce.real.device.name"));
            caps.setCapability("appium:platformVersion", prop.getProperty("dp.ios.sauce.real.device.platform.version"));
        }

        MutableCapabilities sauceOptions = new MutableCapabilities();
        sauceOptions.setCapability("appiumVersion", "latest");
        sauceOptions.setCapability("username",  prop.getProperty("z.run.sl.un"));
        sauceOptions.setCapability("accessKey", prop.getProperty("z.run.sl.ak"));
        sauceOptions.setCapability("build", "1");
        sauceOptions.setCapability("name", testName);
        sauceOptions.setCapability("idleTimeout",
                Integer.parseInt(getProp("dp.ios.new.command.timeout.sauce", "420")));
        sauceOptions.setCapability("deviceOrientation", "PORTRAIT");
        // Automatically retry flaky tests once before marking as failed
        sauceOptions.setCapability("retryFailedTests", true);
        // Cache the installed IPA across sessions in the same build — avoids re-install overhead
        sauceOptions.setCapability("cacheId", prop.getProperty("dp.ios.sauce.cache.id"));
        // Suppress verbose iOS system log from SauceLabs recording — reduces session overhead
        sauceOptions.setCapability("showIOSLog", false);
        // Capture system-wide network traffic in SauceLabs session (visible under Network tab)
        sauceOptions.setCapability("networkCapture", true);
        // Mask credentials in SauceLabs session recordings and log output
        sauceOptions.setCapability("filterSendKeys", true);
        String dpEmail    = prop.getProperty("dp.test.email")    != null ? prop.getProperty("dp.test.email")    : "";
        String dpPassword = prop.getProperty("dp.test.password") != null ? prop.getProperty("dp.test.password") : "";
        sauceOptions.setCapability("logFilterText",
                prop.getProperty("z.run.sl.un") + "," + dpEmail + "," + dpPassword);

        caps.setCapability("sauce:options", sauceOptions);

        String hub = String.format("https://%s:%s@ondemand.us-west-1.saucelabs.com:443/wd/hub",
                prop.getProperty("z.run.sl.un"), prop.getProperty("z.run.sl.ak"));
        return new IOSDriver(new URL(hub), caps);
    }

    /**
     * Builds and starts an IOSDriver session against a local Appium server.
     * Device identity (name / platformVersion / app path) is read from properties
     * based on whether a simulator or real device is requested.
     */
    private AppiumDriver launchLocally(boolean simulator) throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "iOS");
        capabilities.setCapability("appium:automationName", "XCUITest");
        capabilities.setCapability("appium:noReset", false);
        // autoDismissAlerts clicks "Not Now" / "Cancel" on native iOS alerts (e.g. "Save Password?"),
        // preventing credentials from being saved to Keychain and avoiding AutoFill popups on future runs.
        // Use explicit clicks in test code for permission alerts that need to be accepted.
        capabilities.setCapability("appium:autoDismissAlerts", true);
        capabilities.setCapability("appium:unicodeKeyboard", true);
        capabilities.setCapability("appium:fullReset", false);
        capabilities.setCapability("appium:newCommandTimeout",
                getProp("dp.ios.new.command.timeout.local", "420"));
        // Reuse the already-compiled WDA to avoid rebuilding it on every local run
        capabilities.setCapability("appium:usePrebuiltWDA", true);
        capabilities.setCapability("appium:useNewWDA", false);
        // Limit snapshot depth — without this, every element lookup traverses the full tree
        capabilities.setCapability("appium:snapshotMaxDepth",
                Integer.parseInt(getProp("dp.ios.snapshot.max.depth", "62")));
        // Disable iOS animations so XCUITest settles the UI faster between actions
        capabilities.setCapability("appium:reduceMotion", true);
        // WDA default post-tap idle wait is 20s; 5s covers most transitions without over-waiting
        capabilities.setCapability("appium:waitForIdleTimeout", 0);
        // Give WDA enough time to launch and connect
        capabilities.setCapability("appium:wdaLaunchTimeout",
                Integer.parseInt(getProp("dp.ios.wda.launch.timeout", "120000")));
        capabilities.setCapability("appium:wdaConnectionTimeout",
                Integer.parseInt(getProp("dp.ios.wda.connection.timeout", "120000")));
        // Pass Teflon env as a proper Map — XCUITest driver reads this at app launch
        capabilities.setCapability("appium:processArguments", buildTeflonProcessArguments());

        capabilities.setCapability("appium:bundleId", getProp("dp.ios.app.bundle.id", "com.walmart.beta.electronics"));

        if (simulator) {
            capabilities.setCapability("appium:deviceName",      prop.getProperty("dp.ios.local.simulator.device.name"));
            capabilities.setCapability("appium:platformVersion", prop.getProperty("dp.ios.local.simulator.platform.version"));
            capabilities.setCapability("appium:app",
                    System.getProperty("user.home") + prop.getProperty("dp.ios.local.simulator.app.relative.path"));
        } else {
            capabilities.setCapability("appium:deviceName",      prop.getProperty("dp.ios.local.real.device.name"));
            capabilities.setCapability("appium:platformVersion", prop.getProperty("dp.ios.local.real.device.platform.version"));
            capabilities.setCapability("appium:udid",            prop.getProperty("dp.ios.local.real.device.udid"));
            capabilities.setCapability("appium:app",
                    System.getProperty("user.home") + prop.getProperty("dp.ios.local.real.device.app.relative.path"));
        }

        return new IOSDriver(new URL("http://localhost:4723/"), capabilities);
    }

    /**
     * Builds the appium:processArguments capability value that points the iOS app to the Teflon
     * environment at session start. Passed as a Map so the Appium XCUITest driver receives a
     * structured object rather than a JSON string — avoids server-side string parsing and is
     * spec-compliant (args + env keys both present).
     */
    private Map<String, Object> buildTeflonProcessArguments() {
        Map<String, Object> env = new HashMap<>();
        env.put("config", "{\"environment\": \"teflon\"}");
        Map<String, Object> processArguments = new HashMap<>();
        processArguments.put("args", Collections.emptyList());
        processArguments.put("env", env);
        return processArguments;
    }

    @Override
    public void quitDriver() {
        try {
            AppiumDriver driver = appiumDriverThreadLocal.get();
            if (driver != null) {
                driver.quit();
            }
        } finally {
            appiumDriverThreadLocal.remove();
        }
    }

    public String takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + fileName + "_" + r.nextInt(9999) + ".png");
            FileUtils.copyFile(appiumDriverThreadLocal.get().getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
