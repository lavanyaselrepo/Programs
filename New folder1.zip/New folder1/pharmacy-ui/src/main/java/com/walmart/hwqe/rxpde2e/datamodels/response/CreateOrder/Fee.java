package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;
@lombok.Getter
@lombok.Setter
public class Fee{
    public String type;
    public double amount;
}
