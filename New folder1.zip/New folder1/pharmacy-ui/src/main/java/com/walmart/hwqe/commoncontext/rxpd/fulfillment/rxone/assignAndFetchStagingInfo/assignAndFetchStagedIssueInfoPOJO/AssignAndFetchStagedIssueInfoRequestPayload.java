package com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.assignAndFetchStagingInfo.assignAndFetchStagedIssueInfoPOJO;

public class AssignAndFetchStagedIssueInfoRequestPayload {

    private String purchaseOrderId;

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

}

