package com.walmart.hwqe.rxpde2e.datamodels.request.UpdateDelivery;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class UpdateDelivery {
    public ArrayList<FulfillmentGroup> fulfillmentGroups;
}
