package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class PinCreationPages extends MobileBasePage {
    @FindBy(xpath = "//span[text()='Sign In']")
    public WebElement adHocSignInButton ;

    @FindBy(xpath = "//span[text()='Connect my account']")
    public WebElement connectMyAccountButton;

    @FindBy(xpath = "//a[text()='Setup PIN']")
    public WebElement setupPinButton;

    @FindBy(xpath = "//button[text()='Send code']")
    public WebElement sendCodeButton;

    @FindBy(xpath = "//input[@name='verificationCode']")
    public WebElement inputVerificationCode;

    @FindBy(id = "firstName")
    public WebElement inputFirstName;

    @FindBy(id = "lastName")
    public WebElement inputLastName;

    @FindBy(xpath = "//button[text()='Verify code']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    public WebElement verifyCodeButton;

    @FindBy(id = "input-verificationCode")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc, \"PIN\")]/android.widget.FrameLayout/android.widget.EditText")
    public WebElement inputPin;

    @FindBy(xpath = "//button[text()='Create PIN']")
    public WebElement createPinButton;

    @FindBy(xpath = "//button[text()='Confirm PIN']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    public WebElement confirmPinButton;

    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement pinSuccessContinueButton;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Digit 1')]")
    public WebElement enterOTPDigit1Box;

    @FindBy(xpath = "//button[text()='Verify PIN']")
    public WebElement verifyPinButton;

    @FindBy(xpath = "//button[text()='Sign in']")
    public WebElement signInButton;


    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    public WebElement resetPinContinueButton;
    public PinCreationPages(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickAdHocSignInButton() {
        click(adHocSignInButton);
    }

    public void clickConnectMyAccountButton(){
        click(connectMyAccountButton);
    }
    public void openPharmacyDashboard(){
        performSleep(3);
        remoteDriver.switchTo().newWindow(WindowType.TAB);
        remoteDriver.navigate().to("https://www-teflon.walmart.com/pharmacy/dashboard");
    }

    public void enterInputFirstName(String firstName){
        inputFirstName.clear();
        sendText(inputFirstName, firstName);
    }

    public void enterInputLastName(String lastName){
        inputLastName.clear();
        sendText(inputLastName, lastName);
    }

    public void clickSetupPinButton(){
        click(setupPinButton);
    }

    public void clickSendCodeButton(){
        click(sendCodeButton);
    }

    public void enterVerificationOTP(String otp){sendText(inputVerificationCode, otp);}

    public void clickVerifyCodeButton(){
        click(verifyCodeButton);
    }

    public void setPin(){sendText(inputPin, "1111");}

    public void clickCreatePinButton(){click(createPinButton);}

    public void clickConfirmPinButton(){click(confirmPinButton);}

    public void clickPinSuccessContinueButton(){click(pinSuccessContinueButton);}
    public void clickResetPinContinueButton(){click(resetPinContinueButton);}
    public void enterOTPEmail(String otp){sendText(enterOTPDigit1Box, otp);}

    public void clickVerifyPinButton(){click(verifyPinButton);}

    public void clickSignInButton(){click(signInButton);}

    public void emailOptNeeded(String otp) {
        boolean elementPresent = isElementDisplayed(sendCodeButton,1);
        if(elementPresent) {
            click(sendCodeButton);
            enterVerificationOTP(otp);
            click(verifyCodeButton);
        }
    }

    //clickResetPinContinueButton, enterOTPEmail, clickVerifyCodeButton, setPin, clickConfirmPinButton, setPin, clickConfirmPinButtonm, clickConfirmPinButton
}
