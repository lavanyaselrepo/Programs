package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SelectDestinationStorePage extends MobileBasePage {

    @FindBy(xpath = "//label[@data-testid=\"pharmacy-id-5548\"]/child::input")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[@accessible='true'])[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/card_item\").instance(0)")
    private WebElement destinationStoreRadioButtonSelector;

    @FindBy(xpath = "//button[text()='Continue']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name CONTAINS 'primaryActionButton'")
    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    private WebElement continueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/change_location_button")
    private WebElement changeLocationButton;

    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id=\"com.walmart.android.debug:id/enter_location_field\"]//android.widget.EditText")
    private WebElement enterLocationField;

    @AndroidFindBy(id = "com.walmart.android.debug:id/location_continue_button")
    private WebElement applyLocationButton;

    @AndroidFindBy(xpath = "//androidx.recyclerview.widget.RecyclerView[@resource-id=\"com.walmart.android.debug:id/pharmacy_list\"]/android.widget.LinearLayout[1]")
    private WebElement firstDestinationStore;

    public SelectDestinationStorePage(RemoteWebDriver driver) {
        super(driver);
    }

    public void selectDestinationStore() {
        click(destinationStoreRadioButtonSelector);
    }

    public void selectDestinationStoreByStoreNumber(String storeNumber){
        if (remoteDriver instanceof IOSDriver || remoteDriver instanceof AndroidDriver) {
            selectDestinationStore();
        } else {
            List<WebElement> storeSelectorList = this.getDynamicWebElementsByTagAndAttribute("label", "data-testid", "pharmacy-id-" + storeNumber);
            click(storeSelectorList.get(0));
        }
    }

    public void clickContinueButton() {
        click(continueButton);
    }

    public void clickChangeLocationButton() {
        click(changeLocationButton);
    }

    public void enterZipCode(String zipCode) {
        sendText(enterLocationField, zipCode);
    }

    public void clickApplyLocationButton() {
        click(applyLocationButton);
    }

    public void waitForFirstStoreResult() {
        // After applying a new zip code the pharmacy list reloads; poll until the first
        // RecyclerView item is visible before attempting to click it.
        new WebDriverWait(remoteDriver, Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(500))
                .until(driver -> {
                    try { return firstDestinationStore.isDisplayed(); }
                    catch (Exception e) { return false; }
                });
    }

    public void selectFirstDestinationStore() {
        click(firstDestinationStore);
    }

}
