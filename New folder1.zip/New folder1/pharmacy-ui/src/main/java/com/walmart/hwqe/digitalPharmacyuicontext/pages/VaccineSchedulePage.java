package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VaccineSchedulePage extends MobileBasePage {
    @FindBy(xpath = "//a[text()='Schedule now']")
    private WebElement scheduleVaccineNudge;
    @FindBy(xpath = "//span[text()='Vaccines']")
    private WebElement scheduleVaccineSideNav;

    @FindBy(xpath = "//span[text()= 'Devil Dare']//preceding::input")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'first patient')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"first patient\")]")
    private WebElement caregiverCheckBox;

    @FindBy(xpath = "//button[text()='Continue']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Continue\")]")
    private WebElement continueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_name_radio_button")
    private WebElement storeRadioButton;

    @FindBy(xpath = "//button[text()='Select an appointment']")
    private WebElement selectAppointmentButton;
    @FindBy(xpath = "//button[text()='Add a new patient']")
    private WebElement addNewPatientButton;
    @FindBy(xpath = "//input[@id='bio.firstName']")
    private WebElement firstName;
    @FindBy(xpath = "//input[@id='bio.lastName']")
    private WebElement lastName;
    @FindBy(xpath = "(//select[@id='imz-dob_input_month']/option)[2]")
    private WebElement birthMonth;
    @FindBy(xpath = "//input[@id='imz-dob_input_day']")
    private WebElement birthDay;
    @FindBy(xpath = "//input[@id='imz-dob_input_year']")
    private WebElement birthYear;
    @FindBy(xpath = "//button[text()='Add patient']")
    private WebElement addPatientButton;
    @FindBy(xpath = "//div[text()='Bud Flower must be 3 years old to receive a vaccine at Walmart.']")
    private WebElement childNotEligibleTest;
    @FindBy(xpath = "//span[text()= 'Hepatitis A']//preceding::input")
    private WebElement hepatitisVaccine;

    @FindBy(id = "imz-enter-location")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'location')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"location\")]")
    private WebElement enterLocation;

    @FindBy(xpath = "//button[text()='Find']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'find')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"find\")]")
    private WebElement findButton;

    @FindBy(xpath = "//button[text()='No Thanks']")
    private WebElement noThanksButton;
    @FindBy(xpath = "//span[text()='Bentonville Supercenter #5544']")
    private WebElement store;

    @FindBy(xpath = "//button[@data-testid='slot-time-1-0']/span")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'slot')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"slot\")]")
    private WebElement slot;

    @FindBy(xpath = "(//select[@id='demography.race']/option)[2]")
    private WebElement demogRace;
    @FindBy(xpath = "(//select[@id='demography.ethnicity']/option)[2]")
    private WebElement demogEthnicity;
    @FindBy(id = "bio.phoneNumber")
    private WebElement phoneNo;
    @FindBy(xpath = "//input[@name='Acknowledgement of notice receipt*']")
    private WebElement acknowledgeButton;
    @FindBy(xpath = "//button[text()='Confirm appointment']")
    private WebElement confirmAppointment;
    @FindBy(xpath = "//h2[text()='Your appointment is scheduled']")
    private WebElement confirmationText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Schedule Vaccine\")]")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Schedule Vaccine')]")
    private WebElement scheduleVaccineButton;

    @FindBy(xpath = "//a[contains(text(),'Who is getting vaccinated')]")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Who is getting vaccinated')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Who is getting vaccinated\")]")
    private WebElement whoIsGettingVaccinatedScreenText;

    @FindBy(xpath = "//a[contains(text(),'Select vaccines')]")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Select vaccines')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Select vaccines\")]")
    private WebElement vaccinateSelectionScreenText;

    @FindBy(xpath = "//button[contains(text(),'Recommended Vaccine']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Covid19')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Covid19 \")]")
    private WebElement recommendedVaccineScreenText;

    @FindBy(xpath = "//button[contains(text(),'Review']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Review')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Review \")]")
    private WebElement reviewPatientAndSelectAppointmentScreenText;

    @FindBy(xpath = "//button[contains(text(),'Flu']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Flu')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Flu \")]")
    private WebElement recommendedVaccineButton;

    @FindBy(xpath = "//button[contains(text(),'remove']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'remove')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"remove \")]")
    private WebElement removeButton;

    @FindBy(xpath = "//button[contains(text(),'edit']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'edit')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"edit \")]")
    private WebElement editButton;

    @FindBy(xpath = "//button[contains(text(),'add another patient']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'add another patient')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"add another patient \")]")
    private WebElement addAnotherPatientButton;

    @FindBy(xpath = "//button[contains(text(),'select an appointment']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'select an appointment')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"select an appointment \")]")
    private WebElement selectAnAppointmentButton;

    @FindBy(xpath = "//button[contains(text(),'Patient Information']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Patient Information')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Patient Information \")]")
    private WebElement patientInformationScreenText;

    @FindBy(xpath = "//button[contains(text(),'Primary care physician']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Primary care physician')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Primary care physician \")]")
    private WebElement PCPYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'Physician first name']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Physician first name')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Physician first name \")]")
    private WebElement physcianFirstName;

    @FindBy(xpath = "//button[contains(text(),'Physician last name']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Physician last name')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Physician last name \")]")
    private WebElement physcianLastName;

    @FindBy(xpath = "//button[contains(text(),'Physician phone']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Physician phone')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Physician phone \")]")
    private WebElement physcianPhoneNo;

    @FindBy(xpath = "//button[contains(text(),'authorize']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'authorize')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"authorize \")]")
    private WebElement authorizePharmacyYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'Insurance information']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Insurance information')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Insurance information \")]")
    private WebElement insuranceSectionScreenText;

    @FindBy(xpath = "//button[contains(text(),'member ID']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'member ID')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"member ID \")]")
    private WebElement memberIDOfInsuranceSection;

    @FindBy(xpath = "//button[contains(text(),'change']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'change')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"change \")]")
    private WebElement changeButton;

    @FindBy(xpath = "//button[contains(text(),'select a different insurance']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'select a different insurance')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"select a different insurance \")]")
    private WebElement selectADifferentInsuranceRadioButton;

    @FindBy(xpath = "//button[contains(text(),'save']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'save')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"save \")]")
    private WebElement saveButton;

    @FindBy(xpath = "//button[contains(text(),'add this insurance']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'add this insurance')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"add this insurance \")]")
    private WebElement addThisInsuranceInformationYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'sick or injured']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'sick or injured')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"sick or injured \")]")
    private WebElement isPatientSickOrInjuredYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'cough']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'cough')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"cough \")]")
    private WebElement coughCheckbox;

    @FindBy(xpath = "//button[contains(text(),'allergies to medications']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'allergies to medications')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"allergies to medications \")]")
    private WebElement AllergiesToMedicineYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'yeast']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'yeast')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"yeast \")]")
    private WebElement yeastCheckbox;

    @FindBy(xpath = "//button[contains(text(),'long-term health problem']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'long-term health problem')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"long-term health problem \")]")
    private WebElement longTermHealthProblemYesRadioButton;

    @FindBy(xpath = "//button[contains(text(),'diabetes']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'diabetes')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"diabetes \")]")
    private WebElement diabetes;

    @FindBy(xpath = "//button[contains(text(),'patient reaction']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'patient reaction')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"patient reaction \")]")
    private WebElement patientReactionToVaccineNoRadioButton;

    @FindBy(xpath = "//button[contains(text(),'nervous system problems']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'nervous system problems')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"nervous system problems \")]")
    private WebElement otherNervousSystemProblemsNo;

    @FindBy(xpath = "//button[contains(text(),'currently pregnant']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'currently pregnant')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"currently pregnant \")]")
    private WebElement currentlyPregnantNoRadioButton;

    @FindBy(xpath = "//button[contains(text(),'weakened immune']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'weakened immune')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"weakened immune \")]")
    private WebElement weakenedImmuneSystemNo;

    @FindBy(xpath = "//button[contains(text(),'received any vaccinations']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'received any vaccinations')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"received any vaccinations \")]")
    private WebElement receivedAnyVaccinationsPast;

    @FindBy(xpath = "//button[contains(text(),'other medications']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'other medications')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"other medications \")]")
    private WebElement onOtherMedicationsNo;

    @FindBy(xpath = "//button[contains(text(),'received transfusion']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'received transfusion')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"received transfusion \")]")
    private WebElement receivedTransfusionOfBloodNo;


    @FindBy(xpath = "//button[contains(text(),'decline']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'decline')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"decline \")]")
    private WebElement declineToAcknowledgeButton;

    @FindBy(xpath = "//button[contains(text(),'privacy notice']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'privacy notice')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"privacy notice \")]")
    private WebElement walmartPrivacyNoticeText;

    @FindBy(xpath = "//button[contains(text(),'diabetes']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'diabetes')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"diabetes \")]")
    private WebElement appointmentDetails;

    @FindBy(xpath = "//button[contains(text(),'vaccines']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'vaccines')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"vaccines \")]")
    private WebElement patientDetails;

    @FindBy(xpath = "//button[contains(text(),'acknowledgement and consents']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'acknowledgement and consents')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"acknowledgement and consents \")]")
    private WebElement acknowledgementAndConsentsText;

    @FindBy(xpath = "//button[contains(text(),'completed']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'completed')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"completed \")]")
    private WebElement CompletedText;

    @FindBy(xpath = "//button[contains(text(),'appointment scheduled']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'appointment scheduled')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"appointment scheduled \")]")
    private WebElement appointmentScheduledText;

    @FindBy(xpath = "//button[contains(text(),'add to my calender']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'add to my calender')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"add to my calender \")]")
    private WebElement addToMyCalenderText;

    @FindBy(xpath = "//button[contains(text(),'pharmacy']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'pharmacy')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"pharmacy \")]")
    private WebElement pharmacyLocationText;

    @FindBy(xpath = "//button[contains(text(),'back to pharmacy']")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'back to pharmacy')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"back to pharmacy \")]")
    private WebElement backToPharmacyButton;


    // Note: Only Android locators added below - executed on Android only
    // TODO: Add iOS locators when flow is executed on iOS platform

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Schedule an Immunization']")
    private WebElement scheduleAnImmunizationCTA;

    // ---- Screen header / subheader locators — confirmed from execution XML dumps ----

    /** "Who is getting vaccinated?" — patient selection screen heading */
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_list_heading")
    private WebElement patientListHeading;

    /** "Choose up to 4 patients per visit." — patient selection subheader */
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_list_select_text")
    private WebElement patientListSelectText;

    /** "Select vaccines for [Patient]" — vaccine selection title (dynamic text) */
    @AndroidFindBy(id = "com.walmart.android.debug:id/select_vaccine")
    private WebElement vaccineSelectionTitle;

    /** "You can select up to 4 vaccines…" — vaccine selection subtext */
    @AndroidFindBy(id = "com.walmart.android.debug:id/select_vaccine_up_to_value")
    private WebElement vaccineSelectionSubtext;

    /**
     * Shared title used by both "Tell us more about the patients" and
     * "Review and confirm the appointment" screens.
     */
    @AndroidFindBy(id = "com.walmart.android.debug:id/tell_us_title")
    private WebElement screenMainTitle;

    /** "To help us prepare…" — Tell-us-more page subtitle */
    @AndroidFindBy(id = "com.walmart.android.debug:id/appointment_subtitle")
    private WebElement tellUsMoreSubtitle;

    /** "Please check that the information is correct." — review-confirm subtitle */
    @AndroidFindBy(id = "com.walmart.android.debug:id/review_subtitle")
    private WebElement reviewConfirmSubtitle;

    /** "Patient information for [Patient]" — patient info screen header */
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_information_name")
    private WebElement patientInfoHeader;

    /** "Primary care physician information for [Patient]" — PCP screen header */
    @AndroidFindBy(id = "com.walmart.android.debug:id/heading_textview")
    private WebElement pcpScreenHeader;

    /** "Insurance information for [Patient]" — insurance screen title */
    @AndroidFindBy(id = "com.walmart.android.debug:id/insurance_header_title")
    private WebElement insuranceScreenTitle;

    /** "No, skip adding insurance information for now." — radio label used for both click & text assertion */
    @AndroidFindBy(id = "com.walmart.android.debug:id/insurance_confirmation_radio_no")
    private WebElement skipInsuranceRadio;

    /** "Patient consent for [Patient]" — consent screen header */
    @AndroidFindBy(id = "com.walmart.android.debug:id/immunization_patient_consent")
    private WebElement patientConsentHeader;

    /** "Completed" — patient summary completed state label */
    @AndroidFindBy(id = "com.walmart.android.debug:id/completed_state")
    private WebElement completedStateLabel;

    /** "Your appointment is scheduled" — appointment confirmation header */
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_message")
    private WebElement appointmentConfirmedHeader;

    /** "A confirmation has been sent to [email]" — confirmation email subtext */
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_sub_title")
    private WebElement appointmentConfirmedEmailText;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Enter zip code or city, state']/android.widget.FrameLayout/android.widget.EditText")
    private WebElement locationSearchField;

    @AndroidFindBy(id = "com.walmart.android.debug:id/immunization_location_search_button")
    private WebElement locationSearchButton;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id='com.walmart.android.debug:id/immunization_time_slot'])[1]")
    private WebElement firstAvailableTimeSlot;

    @AndroidFindBy(xpath = "//android.widget.Spinner[@resource-id='com.walmart.android.debug:id/patient_race_select']//android.widget.EditText")
    private WebElement raceDropdown;

    @AndroidFindBy(xpath = "//android.widget.Spinner[@resource-id='com.walmart.android.debug:id/patient_ethnicity_select']//android.widget.EditText")
    private WebElement ethnicityDropdown;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Phone Number*']/android.widget.FrameLayout/android.widget.EditText")
    private WebElement phoneNumberTextField;

    @AndroidFindBy(id = "com.walmart.android.debug:id/common_radio_no")
    private WebElement screenNoRadioButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/common_radio_yes")
    private WebElement screenYesRadioButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/insurance_confirmation_radio_no")
    private WebElement skipInsuranceRadioButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/immunization_rb_yes")
    private WebElement acknowledgePrivacyNoticeRadio;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='Confirm appointment']")
    private WebElement confirmAppointmentButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_message")
    private WebElement appointmentConfirmationMessage;

    WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(30));

    public VaccineSchedulePage(RemoteWebDriver driver) {
        super(driver);
    }

    public void scheduleVaccineNudge() {
        click(scheduleVaccineNudge);
    }

    public void scheduleVaccineSideNav() {
        click(scheduleVaccineSideNav);
    }

    public void selectCaregiverForVaccine() {
        click(caregiverCheckBox);
        click(continueButton);
    }

    public void validateTurnOffVaccine(List<String> turnOffList) {
        Set<String> turnOffSet = new HashSet<>(turnOffList);
        List<WebElement> availableVaccineList = listOfAvailableVaccine();
        StringBuilder errors = new StringBuilder();

        availableVaccineList.stream()
                .map(WebElement::getText)
                .forEach(vaccineText -> {
                    if (turnOffSet.stream().anyMatch(vaccineText::contains)) {
                        errors.append(String.format("Vaccine type '%s' is still available for scheduling. ",
                                turnOffSet.stream()
                                        .filter(vaccineText::contains)
                                        .findFirst()
                                        .orElse("")));
                    }
                });

        if (errors.length() > 0) {
            Assert.fail(errors.toString().trim());
        }
    }

    public void validateTurnOffVaccineForChild() {
        Assert.assertTrue(childNotEligibleTest.isDisplayed(), "Child below three years is still eligible for vaccine");
    }

    public List<WebElement> listOfAvailableVaccine() {
        List<WebElement> availableVaccineList;

        availableVaccineList = getDynamicWebElementsByTagAndAttribute("span", "class", "w_GnLN");

        return availableVaccineList;
    }

    public void addNewPatient(String year) {
        click(addNewPatientButton);
        sendText(firstName, "TestFirstName");
        sendText(lastName, "TestLastName");
        click(birthMonth);
        sendText(birthDay, "12");
        sendText(birthYear, year);
        click(addPatientButton);
        click(continueButton);
    }

    public void validateRegularFlow() {
        click(hepatitisVaccine);
        click(continueButton);
        click(noThanksButton);
        click(selectAppointmentButton);
        sendText(enterLocation, "72719");
        click(findButton);
        click(store);
        click(continueButton);
        click(slot);
        click(continueButton);
        click(demogRace);
        click(demogEthnicity);
        sendText(phoneNo, "9866547872");
        for (int i = 0; i < 13; i++) {
            click(continueButton);
        }
        click(acknowledgeButton);
        click(continueButton);
        click(confirmAppointment);
        webWait.until(ExpectedConditions.visibilityOfAllElements(confirmationText));
        Assert.assertTrue(confirmationText.isDisplayed(), "Vaccine schedule confirmation message is not displayed");
    }

    public void clickScheduleVaccineButton() {
        click(scheduleVaccineButton, 5);
    }

    public boolean isWhoIsGettingVaccinatedDisplayed() {
        return isElementDisplayed(whoIsGettingVaccinatedScreenText);
    }

    public boolean isSelectAndAddNewPatientDisplayed() {
        return isElementDisplayed(caregiverCheckBox) && isElementDisplayed(addNewPatientButton);
    }

    public boolean isVaccineSelectionScreenDisplayed() {
        return isElementDisplayed(vaccinateSelectionScreenText);
    }

    public void clickContinueButton() {
        scrollElementForWebAndMobile(continueButton, "Continue", "up");
        click(continueButton);
    }

    public boolean isRecommendedVaccineScreenDisplayed() {
        return isElementDisplayed(recommendedVaccineScreenText);
    }

    public void clickRecommendedVaccineButton() { click(recommendedVaccineButton, 5); }

    public boolean isReviewPatientAndSelectAppointmentScreenDisplayed() {
        return isElementDisplayed(reviewPatientAndSelectAppointmentScreenText);
    }

    public boolean isRemoveButtonDisplayed() {
        return isElementDisplayed(removeButton);
    }

    public boolean isEditButtonDisplayed() {
        return isElementDisplayed(editButton);
    }

    public boolean isAddAnotherPatientButtonDisplayed() {
        return isElementDisplayed(addAnotherPatientButton);
    }

    public void clickOnSelectAnAppointmentButton() { click(selectAnAppointmentButton); }

    public void enterStoreLocationAndFind(String storeId) {
        sendText(enterLocation, storeId);
        click(findButton);
        click(store);
    }

    public void selectAppointmentTimeSlot() { click(slot); }

    public boolean isPatientInformationScreenDisplayed() {
        return isElementDisplayed(patientInformationScreenText);
    }

    public void addPatientDetailsInPatientInformationScreen(String patientPhoneNo) {
        click(demogRace);
        click(demogEthnicity);
        sendText(phoneNo, patientPhoneNo);
    }

    public void validatePrimaryCarePhysicianScreen(String PCPFirstName,String PCPLastName,String PCPPhoneNo) {
        click(PCPYesRadioButton);
        sendText(physcianFirstName, PCPFirstName);
        sendText(physcianLastName, PCPLastName);
        sendText(physcianPhoneNo, PCPPhoneNo);
        click(PCPYesRadioButton);
        click(authorizePharmacyYesRadioButton);
    }

    public boolean isInsuranceSectionScreenDisplayed() {
        return isElementDisplayed(insuranceSectionScreenText);
    }

    public boolean isMemberIDOfInsuranceSectionScreenDisplayed() {
        return isElementDisplayed(memberIDOfInsuranceSection);
    }

    public void changeInsuranceForAPatientWithDifferentInsurance() {
        click(changeButton);
        click(selectADifferentInsuranceRadioButton);
        click(saveButton);
        Assert.assertTrue(memberIDOfInsuranceSection.isDisplayed(), "Insurance information of a patient is updated");
    }

    public void addThisInsuranceInformationToAppointment() { click(addThisInsuranceInformationYesRadioButton); }

    public void answerAllHealthQuestionnairesOfPatient() {
        click(isPatientSickOrInjuredYesRadioButton);
        click(coughCheckbox);
        click(AllergiesToMedicineYesRadioButton);
        click(yeastCheckbox);
        click(longTermHealthProblemYesRadioButton);
        click(diabetes);
        click(patientReactionToVaccineNoRadioButton);
        click(otherNervousSystemProblemsNo);
        click(currentlyPregnantNoRadioButton);
        click(weakenedImmuneSystemNo);
        click(receivedAnyVaccinationsPast);
        click(onOtherMedicationsNo);
        click(receivedTransfusionOfBloodNo);
    }

    public boolean verifyAcknowledgeAndDeclineToAcknowledge() {
        return isElementDisplayed(acknowledgeButton, 10) && isElementDisplayed(declineToAcknowledgeButton, 10) && isElementDisplayed(walmartPrivacyNoticeText, 10);
    }

    public void acknowledgeReceipt()  { click(acknowledgeButton); }

    public boolean verifyReviewAndConfirmAppointmentScreen() {
        return isElementDisplayed(appointmentDetails, 10) && isElementDisplayed(patientDetails, 10) && isElementDisplayed(memberIDOfInsuranceSection, 10) && isElementDisplayed(acknowledgementAndConsentsText, 10) && isElementDisplayed(editButton, 10) && isElementDisplayed(CompletedText, 10);
    }

    public void clickConfirmAppointmentAndVerifyAppointmentDetails() {
        click(confirmAppointment);
        webWait.until(ExpectedConditions.visibilityOfAllElements(confirmationText));
        Assert.assertTrue(confirmationText.isDisplayed(), "Vaccine schedule confirmation message is not displayed");
    }

    public boolean verifyAppointmentConfirmationScreen() {
        return isElementDisplayed(appointmentScheduledText, 10) && isElementDisplayed(addToMyCalenderText, 10) && isElementDisplayed(memberIDOfInsuranceSection, 10) && isElementDisplayed(patientDetails, 10) && isElementDisplayed(pharmacyLocationText, 10) && isElementDisplayed(backToPharmacyButton, 10);
    }

    public void clickScheduleAnImmunizationCTA() {
        click(scheduleAnImmunizationCTA, 10);
    }

    public void selectPatientByName(String patientName) {
        WebElement patient = remoteDriver.findElement(
                By.xpath("//android.widget.TextView[@resource-id='com.walmart.android.debug:id/immunization_patient_name' and @text='" + patientName + "']"));
        click(patient);
    }

    public void selectVaccineByName(String vaccineName) {
        androidScrollToText(vaccineName);
        WebElement vaccineCheckbox = remoteDriver.findElement(
                By.xpath("//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='" + vaccineName + "']"));
        click(vaccineCheckbox);
    }

    public void answerPreScreeningNoAndContinue() {
        click(screenNoRadioButton);
        click(continueButton);
    }

    public void answerPreScreeningYesAndContinue() {
        click(screenYesRadioButton);
        click(continueButton);
    }

    public void searchStoreByZip(String zip) {
        sendText(locationSearchField, zip);
        click(continueButton);
        click(storeRadioButton);
        click(continueButton);
    }

    public void selectFirstAvailableTimeSlot() {
        click(firstAvailableTimeSlot, 10);
    }

    public void enterPhoneNumberForPatient(String phoneNo) {
        sendText(phoneNumberTextField, phoneNo);
    }

    public void selectRace(String race) {
        selectDropdown(raceDropdown, race);
    }

    public void selectEthnicity(String ethnicity) {
       selectDropdown(ethnicityDropdown, ethnicity);
    }


    public void selectNoPrimaryCarePhysician() {
        click(screenNoRadioButton);
    }

    public void skipInsurance() {
        click(skipInsuranceRadio);
    }

    public void answerHealthQuestionnaire10QuestionsDefaultNoAndContinue() {
        for (int i = 0; i < 10; i++) {
            click(continueButton);
        }
    }

    public void acknowledgePrivacyNotice() {
        click(acknowledgePrivacyNoticeRadio);
    }

    public void clickConfirmAppointment() {
        click(confirmAppointmentButton);
    }

    public boolean verifyAppointmentScheduledConfirmationMessage() {
        wait.until(ExpectedConditions.visibilityOf(appointmentConfirmationMessage));
        return isElementDisplayed(appointmentConfirmationMessage, 15);
    }

    public void clickContinueToNextPatient(String patientFirstName) {
        WebElement continueToPatientBtn = remoteDriver.findElement(
                By.xpath("//android.widget.Button[@resource-id='com.walmart.android.debug:id/primary_button' and @text='Continue to " + patientFirstName + "']"));
        click(continueToPatientBtn);
    }

    // ---- Screen text getter methods — each returns getText() from a confirmed resource-id locator ----

    public String getPatientListHeadingText()        { return getText(patientListHeading); }
    public String getPatientListSelectText()         { return getText(patientListSelectText); }
    public String getVaccineSelectionTitleText()     { return getText(vaccineSelectionTitle); }
    public String getVaccineSelectionSubtext()       { return getText(vaccineSelectionSubtext); }
    /** Shared by "Tell us more about the patients" and "Review and confirm the appointment" screens */
    public String getScreenMainTitleText()           { return getText(screenMainTitle); }
    public String getTellUsMoreSubtitleText()        { return getText(tellUsMoreSubtitle); }
    public String getReviewConfirmSubtitleText()     { return getText(reviewConfirmSubtitle); }
    public String getPatientInfoHeaderText()         { return getText(patientInfoHeader); }
    public String getPCPScreenHeaderText()           { return getText(pcpScreenHeader); }
    public String getInsuranceScreenTitleText()      { return getText(insuranceScreenTitle); }
    public String getSkipInsuranceRadioText()        { return getText(skipInsuranceRadio); }
    public String getPatientConsentHeaderText()      { return getText(patientConsentHeader); }
    public String getCompletedStateLabelText()       { return getText(completedStateLabel); }
    public String getAppointmentConfirmedHeaderText(){ return getText(appointmentConfirmedHeader); }
    public String getAppointmentConfirmedEmailText() { return getText(appointmentConfirmedEmailText); }
}
