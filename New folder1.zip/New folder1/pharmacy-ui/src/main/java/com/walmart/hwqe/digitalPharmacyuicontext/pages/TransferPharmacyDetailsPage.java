package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class TransferPharmacyDetailsPage extends MobileBasePage {

    public TransferPharmacyDetailsPage(RemoteWebDriver driver) {
        super(driver);
    }

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_name_dropdown")
    @iOSXCUITFindBy(accessibility = "TransferRxCurrentPharmacyView.caretIconView")
    @FindBy(id = "//select[@id='react-aria-10']")
    public WebElement pharmacyNameDropDown;

    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/living_design_text_input_end_icon']/following::android.widget.TextView[1]")
    @iOSXCUITFindBy(accessibility = "Done")
    @FindBy(xpath = "//option[@value='Target']")
    public WebElement pharmacyNameOption;

    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/pharmacy_phone_number_text_field']/descendant::android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferRxCurrentPharmacyView.currentPharmacyPhone']/descendant:: XCUIElementTypeTextField")
    @FindBy(xpath = "//input[@autocomplete='tel']")
    public WebElement pharmacyPhoneNo;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_details_icon")
    @iOSXCUITFindBy(accessibility = "ChevronRight")
    @FindBy(xpath = "//span[contains(text(),'Select a Walmart pharmacy to')]")
    public WebElement transferToPharmacyOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_continue_button")
    @iOSXCUITFindBy(accessibility = "TransferPharmacyDetailsController.LinkActionView.cta")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continuePharmacyTransferButton;

    public void clickPharmacyNameDropDown() {

        click(pharmacyNameDropDown);
    }

    public void selectPharmacyName() {

        click(pharmacyNameOption);
    }

    public void enterPharmacyPhoneNo(String phoneNo) {

        sendText(pharmacyPhoneNo, phoneNo);
        hideKeyboard();
    }

    public void selectPharmacyToTransfer() {

        click(transferToPharmacyOption);
    }

    public void clickContinuePharmacyTransferButton() {

        click(continuePharmacyTransferButton);
    }

}
