package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class ReviewTransferRequestPage extends MobileBasePage {

    @FindBy(xpath = "//h3[contains(text(),'Patient details')]/following::p[1]")
    @iOSXCUITFindBy(accessibility = "TransferRxPatientDetailsView.fullNameLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    private WebElement userName;

    @FindBy(xpath = "(//div[contains(@class,'pt1')])[1]/child::p[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"TransferRxStoreDetailsView.storeNameLabel\"])[1]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_name'])[1]")
    private WebElement transferFromPharmacyName;

    @FindBy(xpath = "(//div[contains(@class,'pt1')])[2]/child::p[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"TransferRxStoreDetailsView.storeNameLabel\"])[2]")
    @AndroidFindBy(xpath = "(//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/pharmacy_info_layout'])[2]")
    private WebElement transferToPharmacyName;

    @FindBy(xpath = "//button[contains(text(),'Request Transfer')]")
    @iOSXCUITFindBy(accessibility = "HWPrimaryStickyButton.primaryActionButton")
    @AndroidFindBy(xpath = "//android.widget.Button[@text='Request transfer']")
    private WebElement requestTransferButton;

    @FindBy(xpath = "//div[@aria-label='Prescription List']/div/p[1]")
    @iOSXCUITFindBy(accessibility = "HWTitleDescriptionAndLinkButtonView.titleLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_name")
    private WebElement drugName;

    @FindBy(xpath = "//div[@aria-label='Prescription List']/div/p[2]")
    @iOSXCUITFindBy(accessibility = "HWTitleDescriptionAndLinkButtonView.descriptionLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_number")
    private WebElement rxNbr;
    public ReviewTransferRequestPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickRequestTransferButton() {
        click(requestTransferButton);
    }
    public String getUserNameText(){return getText(userName);}
    public String getTransferFromPharmacyName(){return getText(transferFromPharmacyName);}
    public String getTransferToPharmacyName(){return getText(transferToPharmacyName);}
    public String getDrugName() {
        scrollElementForWebAndMobile(drugName, "Refill your transferred","up");
        return getText(drugName);
    }
    public String getRxNbr(){return getText(rxNbr);}

}
