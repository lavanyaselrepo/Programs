package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import io.appium.java_client.ios.IOSDriver;

import java.util.List;

public class GetTransferStartedPage extends MobileBasePage {

    @FindBy(xpath = "//input[@name='profile-option-selection']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"TransferRxPatientTypeSelectionItemView.titleLabel\"]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[contains(@content-desc, 'Primary profile')]")
    private WebElement transferForPrimaryProfileOption;

    @FindBy(xpath = "//*[text()='Myself']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'Myself')]")
    @AndroidFindBy(xpath = "(//android.widget.LinearLayout[@resource-id=\"com.walmart.android.debug:id/card_item\"])[1]")
    private WebElement transferForMyselfBtn;

    // Profile cards are inside the RecyclerView - using parent LinearLayout with content-desc
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferRxPatientTypeSelectionItemView.contentStackView']/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[contains(@content-desc, 'profile')]")
    private List<WebElement> profileOptionsList;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name,'Continue') or @label='Continue']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/profile_primary_button")
    private WebElement continueButton;

    @iOSXCUITFindBy(accessibility = "TransferRxSelectProfileViewController.transferForSomeoneElseButton")
    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_for_someone")
    private WebElement transferForSomeoneElseBtn;

    public GetTransferStartedPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickPrimaryProfileOption() {
        click(transferForPrimaryProfileOption);
    }

    public void clickTransferForMyselfBtn() {
        click(transferForMyselfBtn);
    }

    public void selectFamilyMemberByName(String familyMemberName) {
        // Each profile card has content-desc with the format: "Name ProfileType, not selected"
        // e.g., "Jolene Fox Adult profile, not selected"
        // Platform-specific handling added: iOS uses "value" to fetch profile card details
        for (WebElement profileCard : profileOptionsList) {
            try {
                String contentDesc;
                if (isIOS()) {
                    contentDesc = profileCard.getAttribute("value");
                }else {
                    contentDesc = profileCard.getAttribute("content-desc");
                }

                if (contentDesc != null && contentDesc.contains(familyMemberName)) {
                    click(profileCard);
                    return;
                }
            } catch (Exception e) {
                continue;
            }
        }
        throw new RuntimeException("Family member profile not found: " + familyMemberName);
    }

    public void clickContinueButton() {
        click(continueButton);
    }

    public void clickTransferForSomeoneElseBtn() {
        click(transferForSomeoneElseBtn);
    }
}
