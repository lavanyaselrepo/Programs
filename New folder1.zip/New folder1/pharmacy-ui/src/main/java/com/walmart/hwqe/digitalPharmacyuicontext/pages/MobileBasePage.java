package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.aventstack.extentreports.Status;

import com.azure.cosmos.implementation.apachecommons.math.util.Pair;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.StringUtils;
import com.walmart.hwqe.commoncontext.models.pagemodels.common.Attribute;
import com.walmart.hwqe.commoncontext.models.pagemodels.common.ListOrientation;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public abstract class MobileBasePage {

    /**
     * When deciding if an element is "visible" for scroll-to-text, treat the bottom of the window as higher than
     * {@code height} so we keep scrolling until the match clears the fixed tab bar + home indicator (e.g. Services).
     */
    private static final int IOS_BOTTOM_TAB_OVERLAY_INSET_PX = 120;

    protected PropertyReader prop = PropertyReaderHelper.getInstance();
    public StringUtils stringUtils = new StringUtils();
    public AppiumDriver appDriver;
    public RemoteWebDriver remoteDriver;
    public WebDriverWait webWait;
    private Actions action;

    public MobileBasePage(AppiumDriver appDriver) {
        this.appDriver = appDriver;
        this.webWait = new WebDriverWait(this.appDriver,
                Duration.ofSeconds(Integer.parseInt(prop.getProperty("app.mobile_wait"))));
        this.action = new Actions(this.appDriver);
        this.remoteDriver = appDriver;
    }

    public MobileBasePage(RemoteWebDriver appDriver) {
        this.remoteDriver = appDriver;
        if (appDriver instanceof AppiumDriver) {
            this.appDriver = (AppiumDriver) appDriver;
        }
        this.webWait = new WebDriverWait(this.remoteDriver, Duration.ofSeconds(10));
        this.action = new Actions(this.remoteDriver);
        PageFactory.initElements(new AppiumFieldDecorator(this.remoteDriver, Duration.ofSeconds(10)), this);
    }

    public boolean isElementDisplayed(By elementIdentifier, int waitTimeInSeconds) {
        try {
            new WebDriverWait(this.appDriver, Duration.ofSeconds(waitTimeInSeconds)).until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public void waitForCompletePageLoad() {
        LocalDateTime startTime = LocalDateTime.now();
        try {
            new WebDriverWait(this.remoteDriver, Duration.ofMillis(5000)).until(
                    webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        long seconds = Duration.between(startTime, LocalDateTime.now()).getSeconds();
        if (seconds > 5){
        Reporter.log("page load time was : " + seconds);
        System.out.println("page load time was : " + seconds);
        }
    }

    /**
     * Wait for mobile page to load with optional stability check
     * @param waitSeconds - Initial wait time in seconds (default 3)
     * @param checkStability - Whether to check if page is stable after initial wait
     */
    public void waitForMobilePageToLoad(int waitSeconds, boolean checkStability) {
        try {
            performSleep(waitSeconds);
            if (checkStability) {
                int attempts = 0;
                while (attempts < 5 && !isPageStable()) {
                    performSleep(1);
                    attempts++;
                }
                if (attempts >= 5) {
                    Reporter.log("Warning: Page may not be fully stable after 5 attempts");
                }
            }
        } catch (Exception e) {
            Reporter.log("Error waiting for page to load: " + e.getMessage());
        }
    }

    /**
     * Wait for mobile page to load with default 3 seconds
     */
    public void waitForMobilePageToLoad() {
        waitForMobilePageToLoad(4, false);
    }

    public boolean isElementDisplayed(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public void waitUntilElementSelected(WebElement element, int waitSeconds) {
        new WebDriverWait(remoteDriver, Duration.ofSeconds(waitSeconds))
                .until(ExpectedConditions.elementToBeSelected(element));
    }

    public boolean isElementDisplayed(WebElement element) {
        try {
            // If element is visible, return true
            return element.isDisplayed();
        }  catch (StaleElementReferenceException e) {
            // case where the element has become stale, and we retry
            return false;
        } catch (NoSuchElementException e) {
            // case where the element is not found at all
            return false;
        }
    }

    public boolean isElementDisplayed(WebElement element,String locatorName) {
        try {
            webWait.until(ExpectedConditions.visibilityOf(element));
            Reporter.log(locatorName+" is visible");
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Reporter.log(locatorName+" is not visible due to error :: " + e.getMessage());
            return false;
        }
    }

    public boolean isElementDisplayed(WebElement element, int waitTime) {
        try {
            // Wait until the element is visible
            WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitTime));
            wait.until(ExpectedConditions.visibilityOf(element));

            // If element is visible, return true
            return element.isDisplayed();
        } catch (TimeoutException e) {
            // Element is not visible within the given time
            return false;
        } catch (StaleElementReferenceException e) {
            // case where the element has become stale, and we retry
            return false;
        } catch (NoSuchElementException e) {
            // case where the element is not found at all
            return false;
        }
    }

    public boolean invisibilityOfElement(WebElement element, int waitTime) {
        try {
            WebDriverWait webWait = new WebDriverWait(this.remoteDriver,Duration.ofMillis(waitTime* 1000L));
            webWait.until(ExpectedConditions.invisibilityOf(element));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Generic method to wait for loading indicators to disappear from screen
     * Checks for common loading elements like ProgressBar, loading overlays, etc.
     * @param timeoutSeconds - Maximum time to wait in seconds (default 15)
     */
    public void waitForLoadingToDisappear(int timeoutSeconds) {
        try {
            WebDriverWait wait = new WebDriverWait(this.remoteDriver, Duration.ofSeconds(timeoutSeconds));
            
            // List of common loading indicator locators
            List<By> loadingLocators = Arrays.asList(
                By.xpath("//android.widget.ProgressBar"),
                By.xpath("//*[contains(@content-desc, 'Loading')]"),
                By.xpath("//*[contains(@content-desc, 'loading')]"),
                By.xpath("//*[contains(@text, 'Loading')]"),
                By.xpath("//*[@resource-id='android:id/progress']"),
                By.className("android.widget.ProgressBar")
            );
            
            // Try to find and wait for any loading indicator to disappear
            for (By locator : loadingLocators) {
                try {
                    List<WebElement> loadingElements = remoteDriver.findElements(locator);
                    if (!loadingElements.isEmpty()) {
                        Reporter.log("Found loading indicator, waiting for it to disappear...");
                        wait.until(ExpectedConditions.invisibilityOfAllElements(loadingElements));
                        Reporter.log("Loading indicator disappeared");
                        return;
                    }
                } catch (Exception e) {
                    // Continue to next locator
                }
            }
            
            // If no loading indicator found, add small wait to ensure page is stable
            performSleep(1);
            
        } catch (Exception e) {
            Reporter.log("waitForLoadingToDisappear: " + e.getMessage());
        }
    }
    
    /**
     * Wait for loading to disappear with default timeout of 15 seconds
     */
    public void waitForLoadingToDisappear() {
        waitForLoadingToDisappear(15);
    }

    public Pair<String, String> takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            String fName = fileName + "_" + r.nextInt(9999) + ".png";
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + fName);
            FileUtils.copyFile(this.appDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return new Pair<>(fName, savedFile.getPath());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public String captureScreenShot() {
        try {
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + UUID.randomUUID() + ".png");
            FileUtils.copyFile(this.remoteDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public String takeScreenShot() {
        return captureScreenShot();
    }

    public boolean sendHotKeys(String hotKeys) {
        return this.performHotKey(hotKeys);
    }

    public boolean sendHotKeys(String commands, Keys... key) {
        commands += Keys.chord(key);
        return this.performHotKey(commands);
    }

    public WebElement getNthListElement(By list, By seekElement, int n, ListOrientation orientation) {
        List<WebElement> foundElements = appDriver.findElements(seekElement);
        Rectangle listRect = appDriver.findElements(list).get(0).getRect();
        while (foundElements.size() < n) {
            if (orientation == ListOrientation.Horizontal) {
                swipeLeft(listRect);
            } else {
                swipeUp(listRect);
            }
            for (WebElement e : appDriver.findElements(seekElement)) {
                if (!foundElements.stream().map(WebElement::getText).collect(Collectors.toList()).contains(e.getText())) {
                    foundElements.add(e);
                }
            }
        }
        return foundElements.get(n - 1);
    }

    private void swipeUp(Rectangle scrollInside) {
        int centre = scrollInside.x + (scrollInside.width / 2);
        int startPoint = scrollInside.y + scrollInside.height - 1;
        int endPoint = scrollInside.y;
        performSwipe(centre, startPoint, centre, endPoint);
    }

    private void swipeRight(Rectangle scrollInside) {
        int centre = scrollInside.y + (scrollInside.height / 2);
        int startPoint = scrollInside.x;
        int endPoint = scrollInside.x + scrollInside.width - 1;
        performSwipe(startPoint, centre, endPoint, centre);
    }

    private void swipeDown(Rectangle scrollInside) {
        int centre = scrollInside.x + (scrollInside.width / 2);
        int startPoint = scrollInside.y;
        int endPoint = scrollInside.y + scrollInside.height - 1;
        performSwipe(centre, startPoint, centre, endPoint);
    }

    private void swipeLeft(Rectangle scrollInside) {
        int centre = scrollInside.y + (scrollInside.height / 2);
        int startPoint = scrollInside.x + scrollInside.width - 1;
        int endPoint = scrollInside.x;
        performSwipe(startPoint, centre, endPoint, centre);
    }

    private void performSwipe(int startX, int startY, int endX, int endY) {
        Map<String, Object> args = new HashMap<>();
        args.put("duration", 1.0);
        args.put("fromX", startX);
        args.put("fromY", startY);
        args.put("toX", endX);
        args.put("toY", endY);
        appDriver.executeScript("mobile: dragFromToForDuration", args);
    }

    public WebElement androidScrollToText(String text) {
        WebElement webElement = null;
        AndroidDriver androidDriver = (AndroidDriver) remoteDriver;
        
        try {
            // Get screen dimensions for swipe calculation
            Dimension size = androidDriver.manage().window().getSize();
            int width = size.getWidth();
            int height = size.getHeight();
            
            // Calculate swipe coordinates (similar to TypeScript example)
            int centerX = width / 2;
            int startY = (int) (height * 0.7);  // Start from 70% of screen height
            int endY = (int) (height * 0.3);    // End at 30% of screen height
            
            // Try scrolling up to 10 times to find element
            for (int i = 0; i < 10; i++) {
                // Check if element is visible on current screen BEFORE scrolling
                // Using findElements (plural) to avoid implicit wait - returns empty list instantly if not found
                List<WebElement> elements = androidDriver.findElements(
                        new AppiumBy.ByAndroidUIAutomator("new UiSelector().text(\"" + text + "\")"));
                
                if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
                    webElement = elements.get(0);
                    if (i == 0) {
                        Reporter.log("Element already visible on screen: " + text);
                    } else {
                        Reporter.log("Found element after " + i + " scroll(s): " + text);
                    }
                    return webElement;
                }
                
                // Perform swipe gesture to scroll
                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence swipe = new Sequence(finger, 1);
                
                swipe.addAction(finger.createPointerMove(Duration.ofMillis(0),
                    PointerInput.Origin.viewport(), centerX, startY));
                swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                swipe.addAction(finger.createPointerMove(Duration.ofMillis(300),
                    PointerInput.Origin.viewport(), centerX, endY));
                swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                
                androidDriver.perform(Arrays.asList(swipe));
                performSleep(1);
            }
            
            Reporter.log("Element not found after 10 scrolls: " + text);
            
        } catch (Exception e) {
            Reporter.log("Failed to scroll to text: " + text + " - " + e.getMessage());
        }
        return webElement;
    }

    /**
     * Scrolls down to find an element by exact text and returns it.
     *
     * <p>Uses XPath rather than UiSelector because UIAutomator's UiSelector can traverse the
     * full scrollable container and return off-screen elements at their document-level Y position,
     * causing the visibility check to always fail. XPath only captures elements currently in the
     * view hierarchy snapshot (on-screen), making the stop condition reliable on both local
     * emulators and SauceLabs real/emulated devices.
     *
     * <p>Visibility bounds:
     * <ul>
     *   <li>minVisibleY (5 %) — avoids elements hidden under the status bar / toolbar.</li>
     *   <li>maxVisibleY (78 %) — conservative upper bound that accounts for the gesture nav bar
     *       AND any floating action button (e.g. "Continue") at the bottom of the screen.
     *       Using 85 % was too high: the label text could pass the check while the input field
     *       immediately below it sat behind the floating button and could not be interacted with.</li>
     * </ul>
     *
     * <p>Scroll-end detection: if an element's Y position does not change after a swipe the
     * container has reached its scroll end. The element is returned immediately rather than
     * burning up to 9 more one-second sleep iterations pointlessly.
     */
    public WebElement androidScrollDownToText(String text) {
        AndroidDriver androidDriver = (AndroidDriver) remoteDriver;
        try {
            Dimension size = androidDriver.manage().window().getSize();
            int screenHeight = size.getHeight();
            int centerX      = size.getWidth() / 2;
            int startY       = (int) (screenHeight * 0.70);
            int endY         = (int) (screenHeight * 0.40);
            int minVisibleY  = (int) (screenHeight * 0.05);
            // 0.90 catches elements on large/foldable displays (e.g. Pixel 9 Pro Fold) that appear
            // between 78–90% of screen height — leaving only the system gesture bar excluded.
            int maxVisibleY  = (int) (screenHeight * 0.90);
            // Sticky bottom nav bar (Walmart tab bar ~83dp + system gesture bar) occupies roughly
            // the bottom 22% of screen. Only return the element once its bottom edge clears this
            // zone; otherwise let the next swipe scroll it into the safe interaction area.
            int safeBottomY  = (int) (screenHeight * 0.78);

            PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
            int prevElemY = -1;

            for (int i = 0; i < 10; i++) {
                List<WebElement> found = androidDriver.findElements(
                        By.xpath("//*[@text='" + text + "']"));

                if (!found.isEmpty()) {
                    WebElement el    = found.getFirst();
                    int elemY        = el.getLocation().getY();
                    int elemBottom   = elemY + el.getSize().getHeight();

                    if (elemY >= minVisibleY && elemY < maxVisibleY && elemBottom > minVisibleY) {
                        if (elemBottom <= safeBottomY) {
                            // Element is fully above the sticky bottom nav — safe to interact with.
                            Reporter.log(i == 0
                                    ? "Element already visible: " + text
                                    : "Found element after " + i + " scroll(s): " + text);
                            return el;
                        }
                        // Element is visible but its bottom edge is behind the sticky nav bar.
                        // Do a short nudge (15% of screen) so it shifts just enough to clear the
                        // nav bar without overshooting past the top of the viewport.
                        if (elemY == prevElemY) {
                            // Scroll end reached even with nudge — return best effort.
                            Reporter.log("Scroll end reached, element behind sticky nav at Y=" + elemY + ", returning: " + text);
                            return el;
                        }
                        Reporter.log("Element may be behind sticky nav (elemBottom=" + elemBottom
                                + ") — nudging up: " + text);
                        int nudgeStartY = (int) (screenHeight * 0.60);
                        int nudgeEndY   = (int) (screenHeight * 0.45);
                        Sequence nudge = new Sequence(finger, 0);
                        nudge.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerX, nudgeStartY));
                        nudge.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                        nudge.addAction(finger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), centerX, nudgeEndY));
                        nudge.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                        androidDriver.perform(List.of(nudge));
                        performSleep(1);
                        prevElemY = elemY;
                        continue;
                    }

                    // Element Y unchanged after last swipe → scroll container hit its end.
                    // Return it regardless of position since we can't scroll further.
                    if (elemY == prevElemY) {
                        Reporter.log("Scroll end reached at Y=" + elemY + ", returning: " + text);
                        return el;
                    }
                    prevElemY = elemY;
                }

                Sequence swipe = new Sequence(finger, 0);
                swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerX, startY));
                swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                swipe.addAction(finger.createPointerMove(Duration.ofMillis(400), PointerInput.Origin.viewport(), centerX, endY));
                swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                androidDriver.perform(List.of(swipe));
                performSleep(1);
            }

            // Final check after the last swipe settles
            List<WebElement> lastCheck = androidDriver.findElements(
                    By.xpath("//*[@text='" + text + "']"));
            if (!lastCheck.isEmpty()) {
                Reporter.log("Found element on final check: " + text);
                return lastCheck.get(0);
            }

            Reporter.log("Element not found after 10 scrolls: " + text);
        } catch (Exception e) {
            Reporter.log("Error in androidScrollDownToText: " + e.getMessage());
        }
        return null;
    }

    /**
     * Scrolls down using manual PointerInput swipe gestures to find an element by text.
     * Use this on screens where androidScrollDownToText (UiScrollable) does not work
     * because it picks the wrong scrollable container — e.g. the Manage Family screen.
     * Swipe duration is 800ms so Appium registers it as a real scroll, not a tap.
     *
     * @param text - exact text of the element to scroll to
     * @return the found WebElement, or null if not found after 10 swipes
     */
    public WebElement androidManualSwipeDownToText(String text) {
        AndroidDriver androidDriver = (AndroidDriver) remoteDriver;
        try {
            Dimension size = androidDriver.manage().window().getSize();
            int centerX = size.getWidth() / 2;
            int startY  = (int) (size.getHeight() * 0.75); // finger starts near bottom
            int endY    = (int) (size.getHeight() * 0.25); // finger ends near top → scrolls content DOWN

            for (int i = 0; i < 10; i++) {
                List<WebElement> elements = androidDriver.findElements(
                        AppiumBy.androidUIAutomator("new UiSelector().text(\"" + text + "\")"));
                if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
                    Reporter.log("androidManualSwipeDownToText: found '" + text + "' after " + i + " swipe(s)");
                    return elements.get(0);
                }

                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence swipe = new Sequence(finger, 1);
                swipe.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), centerX, startY));
                swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                swipe.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), centerX, endY));
                swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                androidDriver.perform(Collections.singletonList(swipe));
                performSleep(1);
            }
            Reporter.log("androidManualSwipeDownToText: '" + text + "' not found after 10 swipes");
        } catch (Exception e) {
            Reporter.log("androidManualSwipeDownToText failed: " + e.getMessage());
        }
        return null;
    }

    public void androidScrollToTextContains(String text) {
        AndroidDriver androidDriver = (AndroidDriver) remoteDriver;
        
        try {
            // First, check if element is already visible
            try {
                WebElement element = androidDriver.findElement(new AppiumBy.ByAndroidUIAutomator(
                        "new UiSelector().textContains(\"" + text + "\")"));
                if (element != null && element.isDisplayed()) {
                    Reporter.log("Element already visible: " + text);
                    return;
                }
            } catch (Exception ignored) {
                // Element not visible, proceed to scroll
            }
            
            // Scroll with reasonable max swipes
            androidDriver.findElement(new AppiumBy.ByAndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true))" +
                    ".setMaxSearchSwipes(20)" +
                    ".scrollIntoView(new UiSelector().textContains(\"" + text + "\"))"));
            Reporter.log("Scrolled to text: " + text);
            
        } catch (Exception e) {
            Reporter.log("Failed to scroll to text: " + text);
        }
    }

    public void androidScrollToText(RemoteWebDriver driver, String text) {
        try {
            ((AndroidDriver) driver).findElement(new AppiumBy.ByAndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + text + "\").instance(0))"));
            Reporter.log("Scrolled To text : " + text);
        } catch (Exception e) {
            Reporter.log("Failed to Scroll To text : " + text);
        }
    }

    public boolean isTextDisplayedInAndroid(String text) {
        boolean status = false;
        try {
            WebElement webElement = appDriver.findElement(new AppiumBy.ByAndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + text + "\").instance(0))"));
            status = webElement.isDisplayed();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Reporter.log(text + (status ? " - text is displayed" : " - text is not displayed"));
        return status;
    }

    public boolean isTextDisplayedInIOS(String text) {
        boolean status = false;
        try {
            WebElement webElement = appDriver.findElement(
                    By.xpath("//XCUIElementTypeStaticText[contains(@label,'" + text + "') or contains(@value,'" + text + "')]"));
            status = webElement.isDisplayed();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Reporter.log(text + (status ? " - text is displayed" : " - text is not displayed"));
        return status;
    }

    public boolean sendHotKeys(Keys... key) {
        return this.performHotKey(Keys.chord(key));
    }

    public void hideKeyboard() {
        try {
            if (remoteDriver instanceof AndroidDriver) {
                ((AndroidDriver) remoteDriver).hideKeyboard();
            } else if (remoteDriver instanceof IOSDriver) {
                click(AppiumBy.iOSNsPredicateString("type == 'XCUIElementTypeButton' AND name == 'Done'"));
            }
        } catch (Exception ignored) {
            // keyboard already hidden
        }
    }

    private boolean performHotKey(String command) {
        try {
            action.sendKeys(command).build().perform();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to performHotKey " + command);
        }
        return false;
    }

    public boolean sendText(By elementIdentifier, String textValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            appDriver.findElement(elementIdentifier).sendKeys(textValue);
            Reporter.log("Sent keys " + textValue);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to sendText " + textValue);
        }
        return false;
    }

    public void sendText(WebElement el, String textValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfAllElements(el));
            el.sendKeys(textValue);
            Reporter.log("Sent keys " + textValue);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to sendText " + textValue);
        }
    }

    public void sendText(WebElement el, String textValue, int waitTime) {
        try {
            WebDriverWait localWait = new WebDriverWait(this.remoteDriver, Duration.ofSeconds(waitTime));
            localWait.until(ExpectedConditions.visibilityOf(el));
            el.sendKeys(textValue);
            Reporter.log("Sent keys " + textValue);
        } catch (Exception e){
            Reporter.log(e.getMessage());
            System.out.println(e.getMessage());
            Assert.fail("Failed to sendText " + textValue);
        }
    }

    public void sendTextOrThrowException(WebElement el, String textValue, int waitTime) {
        WebDriverWait localWait = new WebDriverWait(this.remoteDriver, Duration.ofSeconds(waitTime));
        localWait.until(ExpectedConditions.visibilityOf(el));
        el.clear();
        el.sendKeys(textValue);
        Reporter.log("Sent keys " + textValue);
    }

    public void sendDateField(WebElement element, String date) {
        // Input is raw digits e.g. "12122000" → format to "12/12/2000" before sending
        String digitsOnly = date.replaceAll("[^0-9]", "");
        String formattedDate = digitsOnly.length() == 8
                ? digitsOnly.substring(0, 2) + "/" + digitsOnly.substring(2, 4) + "/" + digitsOnly.substring(4)
                : date;
        element.click();
        element.clear();
        element.sendKeys(formattedDate);
        Reporter.log("Sent date: " + formattedDate);
    }

    public void sendTextAndPressEnter(WebElement el, String textValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfAllElements(el));
            action.sendKeys(textValue).sendKeys(Keys.ENTER).build().perform();
            Reporter.log("Sent Text" + textValue +" and clicked on enter");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to sendText And PressEnter on element " + el + " and text value " + textValue);
            throw  e;
        }
    }

    public String getText(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            String text = appDriver.findElement(elementIdentifier).getText();
            Reporter.log("Text for element " + elementIdentifier + " is " + text);
            return text;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to getText of element " + elementIdentifier);
        }
        return null;
    }

    public String getText(WebElement element) {
        try {
            webWait.until(ExpectedConditions.visibilityOf(element));
            Reporter.log("Text for element " + element + " is " + element.getText());
            return element.getText();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to getText for element " + element);
        }
        return null;
    }

    public boolean click(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            remoteDriver.findElement(elementIdentifier).click();
            Reporter.log("Clicked on element " + elementIdentifier);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to Click on element " + elementIdentifier);
        }
        return false;
    }

    public boolean click(By elementIdentifier, int waitTimeInSeconds) {
        try {
            new FluentWait<>(appDriver)
                    .withTimeout(Duration.ofSeconds(waitTimeInSeconds))
                    .pollingEvery(Duration.ofMillis(500))
                    .ignoring(NoSuchElementException.class)
                    .ignoring(ElementClickInterceptedException.class)
                    .ignoring(StaleElementReferenceException.class)
                    .until(driver -> {
                        WebElement element = driver.findElement(elementIdentifier);
                        if (element.isDisplayed() && element.isEnabled()) {
                            element.click();
                            return true;
                        }
                        return false;
                    });
            Reporter.log("Clicked on element " + elementIdentifier);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to Click on element " + elementIdentifier);
        }
        return false;
    }

    public void click(WebElement el) {
        try {
            webWait.until(ExpectedConditions.elementToBeClickable(el));
            el.click();
            Reporter.log("Clicked on element " + el);
        } catch (Exception e){
            Reporter.log(e.getMessage());
            Assert.fail("Failed to Click on element " + el);
            throw e;
        }
    }

    public void click(WebElement el, int waitTime) {
        try {
            if (!attemptFluentClick(el, waitTime)) {
                Assert.fail("Failed to Click on element " + el);
            }
            Reporter.log("Clicked on element " + el);
        } catch (Exception e) {
            Reporter.log(e.getMessage());
            Assert.fail("Failed to Click on element " + el + " due to exception: " + e.getMessage());
        }
    }

    /**
     * Polls until {@code el} is visible+enabled and clicks it, returning true on success.
     * Shared by {@link #click(WebElement, int)} and {@link #clickInterceptibleElement(WebElement, int)}.
     */
    private boolean attemptFluentClick(WebElement el, int waitTime) {
        return new FluentWait<>(remoteDriver)
                .withTimeout(Duration.ofSeconds(waitTime))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(ElementClickInterceptedException.class)
                .ignoring(StaleElementReferenceException.class)
                .ignoring(NoSuchElementException.class)
                .until(driver -> {
                    if (el.isDisplayed() && el.isEnabled()) {
                        try {
                            el.click();
                            return true;
                        } catch (ElementClickInterceptedException e) {
                            return false;
                        }
                    }
                    return false;
                });
    }

    public void waitForElementToBeClickable(By locator){
        try{
            webWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            webWait.until(ExpectedConditions.elementToBeClickable(locator));
        } catch (Exception e){
            Reporter.log(e.getMessage());
            throw e;
        }
    }

    public void waitForElementToBeClickable(WebElement elementIdentifier, String locatorName) {
        try {
            webWait.until(ExpectedConditions.elementToBeClickable(elementIdentifier));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Reporter.log("Wait for element to be clickable failed. locator " + locatorName);
        }
    }

    public String getText(WebElement element, String locatorName) {
        String text = null;
        isElementDisplayed(element,locatorName);
        try {
            text = element.getText();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to getText for locator " + locatorName);
        }
        Reporter.log("Fetched text '"+text+"' from locator "+locatorName);
        return text;
    }

    public String getText(WebElement element, String locatorName, int waitTime) {
        String text = null;
        try {
            new FluentWait<>(remoteDriver)
                    .withTimeout(Duration.ofSeconds(waitTime))
                    .pollingEvery(Duration.ofMillis(500))
                    .ignoring(StaleElementReferenceException.class)
                    .ignoring(NoSuchElementException.class)
                    .until(driver -> element.isDisplayed());
            text = element.getText();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.fail("Failed to getText for locator " + locatorName);
        }
        Reporter.log("Fetched text '"+text+"' from locator "+locatorName);
        return text;
    }

    public String getAttribute(WebElement element, Attribute attr, int waitTime) {
        String text = null;
        try {
            new FluentWait<>(remoteDriver)
                    .withTimeout(Duration.ofSeconds(waitTime))
                    .pollingEvery(Duration.ofMillis(500))
                    .ignoring(StaleElementReferenceException.class)
                    .ignoring(NoSuchElementException.class)
                    .until(driver -> element.isDisplayed());
            text = element.getAttribute(attr.name());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Reporter.log("Fetched text '"+text+"' from attribute "+attr.name());
        return text;
    }

    public String getAttribute(WebElement element, Attribute attr) {
        String text = null;
        isElementDisplayed(element);
        try {
            text = element.getAttribute(attr.name());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Reporter.log("Fetched text '"+text+"' from attribute "+attr.name());
        return text;
    }


    public void sendText(WebElement elementIdentifier,String value,String locatorName) {
        try {
            click(elementIdentifier,locatorName);
            clear(elementIdentifier,locatorName);
            elementIdentifier.sendKeys(value);
            Reporter.log("Entered "+value+" in "+locatorName+" field.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Reporter.log("Failed to enter "+value+" in "+locatorName+" field.");
            throw new RuntimeException(e);
        }
    }


    public void click(WebElement elementIdentifier, String locatorName) {
        waitForElementToBeClickable(elementIdentifier, locatorName);
        try {
            elementIdentifier.click();
            Reporter.log("Clicked on " + locatorName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Reporter.log("Failed to Click on " + locatorName);
            throw new RuntimeException(e);
        }
    }

    public void clear(WebElement elementIdentifier, String locatorName) {
        isElementDisplayed(elementIdentifier, locatorName);
        try {
            elementIdentifier.clear();
            Reporter.log("Cleared " + locatorName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Reporter.log("Failed to Clear the locator " + locatorName);
            throw new RuntimeException(e);
        }
    }
    public boolean clear(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            appDriver.findElement(elementIdentifier).clear();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By elementIdentifier, int indexOfValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            appDriver.findElement(elementIdentifier).click();
            StringBuilder keys = new StringBuilder();
            for (int i = 0; i < indexOfValue; i++)
                keys.append(Keys.ARROW_DOWN);
            keys.append(Keys.ENTER);
            performHotKey(keys.toString());
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public String getValueFromAttribute(By elementIdentifier, Attribute attr) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            // All attributes map directly to their enum name except Disabled (DOM uses lowercase "disabled")
            String attrName = (attr == Attribute.Disabled) ? "disabled" : attr.name();
            return appDriver.findElement(elementIdentifier).getAttribute(attrName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public boolean selectListItem(By elementIdentifier, String value) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            appDriver.findElement(elementIdentifier).click();
            appDriver.findElement(elementIdentifier).findElement(By.name(value)).click();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By parent, By target) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(parent));
            List<WebElement> lstelements = appDriver.findElements(parent);
            for (WebElement ele : lstelements) {
                ele.findElement(target).click();
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By parent, By targetSelector, By conditionalSelector, String conditionalValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(parent));
            List<WebElement> lstelements = appDriver.findElements(parent);
            for (WebElement ele : lstelements) {
                if (ele.findElement(conditionalSelector).getText().equalsIgnoreCase(conditionalValue)) {
                    ele.findElement(targetSelector).click();
                    break;
                }
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - getCount()
     * Description: This method is to get the count from the list of a an element
     * Inputs : elementIdentifier
     * returns: count in Int
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */
    public int getCount(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return appDriver.findElements(elementIdentifier).size();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;

    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - closeApp()
     * Description: Close the app which was provided in the capabilities at session creation and quits the session.
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public void closeAndroidApp(String appId) {
        try {
            ((AndroidDriver) appDriver).terminateApp(appId);
            Reporter.log(Status.PASS,"App successfully closed.");
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to close the app and exception is : "+e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - activateAndroidApp()
     * Description: Activates the given app if it installed, but not running or if it is running in the background.
     * Inputs : bundleId – the bundle identifier (or app id) of the app to activate.For Android, App Package
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public void activateAndroidApp(String appId) {
        try {
            ((AndroidDriver)appDriver).activateApp(appId);
            Reporter.log(Status.PASS,"App successfully Activated.");
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to activate the app and exception is : "+e.getMessage());
            throw new RuntimeException(e);        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - restartAndroidApp()
     * Description: Restarts the given app if it installed.
     * Inputs : bundleId – the bundle identifier (or app id) of the app to activate.For Android, App Package & For iOS, BundleId
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public void restartAndroidApp(String appId) {
        try {
            closeAndroidApp(appId);
            activateAndroidApp(appId);
            Reporter.log(Status.PASS,"Android App successfully Restarted.");
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to Restart the app and exception is : "+e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - installAndroidApp()
     * Description: Install an app on the mobile device.
     * Inputs : appPath – path to app to install.
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public void installAndroidApp(String appPath) {
        try {
            ((AndroidDriver)appDriver).installApp(appPath);
            Reporter.log(Status.PASS,"App successfully Installed.");
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to install the app and exception is : "+e.getMessage());
            throw new RuntimeException(e);
        }
    }
    public static void performSleep(int waitTimeInSec) {
        try {
            Thread.sleep(waitTimeInSec * 1000);
            Reporter.log(Status.PASS,"Performed Sleep in seconds : "+waitTimeInSec);
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to perform Sleep and exception is : "+e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void performSwipeAction(int startX, int startY, int endX, int endY) {
        TouchAction touchAction = new TouchAction((AndroidDriver)appDriver);
        touchAction.press(PointOption.point(startX, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                .moveTo(PointOption.point(endX, endY))
                .release()
                .perform();
    }

    public void drawSignature(By elementIdentifier){
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            Point point = appDriver.findElement(elementIdentifier).getLocation();
            performSwipeAction(point.x+50, point.y+80,point.x+80, point.y+30);
            Reporter.log(Status.PASS,"successfully signed.");
        } catch (Exception e) {
            Reporter.log(Status.FAIL,"Failed to enter signature and exception is : "+e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void isElementDisplayed(By elementIdentifier, String locatorName, int waitTimeInSeconds) {
        Assert.assertTrue(isElementDisplayed(elementIdentifier, waitTimeInSeconds), locatorName + " should be displayed");
        Reporter.log(locatorName + " is displayed");
    }

    public void isElementDisplayed(By elementIdentifier, String locatorName) {
        Assert.assertTrue(isElementDisplayed(elementIdentifier), locatorName + " should be displayed");
        Reporter.log(locatorName + " is displayed");
    }

    public void click(By elementIdentifier, String locatorName) {
        Assert.assertTrue(click(elementIdentifier), "Failed to Click on " + locatorName);
        Reporter.log("Clicked on " + locatorName);
    }

    public static void runShellScript(String command) {
        CommandLine oCmdLine = CommandLine.parse(command);
        DefaultExecutor oDefaultExecutor = new DefaultExecutor();
        oDefaultExecutor.setExitValue(0);
        try {
            oDefaultExecutor.execute(oCmdLine);
        } catch (ExecuteException e) {
            System.out.println("Fail");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Denied");
            e.printStackTrace();
        }
    }

    public void navigateBack() {
        try {
            remoteDriver.navigate().back();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getUrl(String url) {
        remoteDriver.get(url);
    }
    public void navigateUrl(String url) {
        navigateToPage(url);
    }

    public boolean mobileScrollToText(String textToFind, String direction) {
        return mobileScrollToText(textToFind, 25, direction);
    }

    /** Y coordinate below which content is considered visible (above fixed bottom chrome on iOS). */
    private int visibleViewportBottomY(Dimension screenSize) {
        int h = screenSize.getHeight();
        if (remoteDriver instanceof IOSDriver) {
            return Math.max(1, h - IOS_BOTTOM_TAB_OVERLAY_INSET_PX);
        }
        return h;
    }

    public boolean mobileScrollToText(String textToFind, int maxScrollAttempts, String direction) {
        int scrollAttempts = 0;
        Dimension screenSize = remoteDriver.manage().window().getSize();
        int viewportBottom = visibleViewportBottomY(screenSize);

        while (scrollAttempts < maxScrollAttempts) {
            try {
                WebElement element = remoteDriver.findElement(
                        AppiumBy.iOSNsPredicateString(
                                "label == '" + textToFind + "' OR value == '" + textToFind + "' OR name == '" + textToFind + "' OR " +
                                        "label CONTAINS '" + textToFind + "' OR value CONTAINS '" + textToFind + "'"
                        )
                );
                Point location = element.getLocation();
                Dimension elementSize = element.getSize();
                int elementBottom = location.getY() + elementSize.getHeight();
                // On iOS, isDisplayed() is unreliable for off-screen elements in the XCUITest
                // driver — use coordinate-based check instead to confirm true viewport visibility
                boolean isOnScreen = location.getY() >= 0 && elementBottom <= viewportBottom
                        && location.getX() >= 0 && (location.getX() + elementSize.getWidth()) <= screenSize.getWidth();
                if (isOnScreen) {
                    System.out.println("Element visible on screen after " + scrollAttempts + " scroll attempt(s).");
                    return true;
                }
            } catch (NoSuchElementException e) {
                // Element not yet in DOM — keep scrolling
            }
            mobileSwipe(direction);
            scrollAttempts++;
            if (!isPageStable()) {
                performSleep(1);
            }
        }
        System.out.println("Element not found on screen after " + maxScrollAttempts + " scroll attempt(s).");
        return false;
    }

    public WebElement iOSScrollToTextInTableCell(String label, int maxScrolls, String direction) {
        By locator = By.xpath(
                "//XCUIElementTypeCell[.//*[contains(@name,'" + label + "') or contains(@label,'" + label + "')]] | " +
                "//*[contains(@label,'" + label + "') or contains(@name,'" + label + "')]");
        return mobileScrollToLocator(locator, maxScrolls, direction);
    }

    /**
     * Scrolls until the table-cell containing {@code label} enters the viewport, then returns
     * the first child element inside that cell whose {@code @name} or {@code @label} matches.
     *
     * <p>Unlike {@link #iOSScrollToTextInTableCell(String, int, String)}, the visibility check in
     * {@link #mobileScrollToLocator} runs against the <em>child</em> text element (small, ~20 px),
     * not the whole containing cell. Large cards that span multiple prescriptions and are taller
     * than the viewport are therefore detected as visible as soon as the header text enters the
     * screen — the cell's {@code elementBottom} would exceed the screen height and fail the
     * full-containment check, whereas the child text element fits within it.
     */
    public WebElement iOSScrollToChildInCell(String label, int maxScrolls, String direction) {
        By childLocator = By.xpath(
                "//XCUIElementTypeCell[.//*[contains(@name,'" + label + "') or contains(@label,'" + label + "')]]"
                + "//*[contains(@name,'" + label + "') or contains(@label,'" + label + "')][1]");
        return mobileScrollToLocator(childLocator, maxScrolls, direction);
    }

    private WebElement mobileScrollToLocator(By locator, int maxScrolls, String direction) {
        int scrollAttempts = 0;
        Dimension screenSize = remoteDriver.manage().window().getSize();
        int viewportBottom = visibleViewportBottomY(screenSize);

        while (scrollAttempts < maxScrolls) {
            try {
                WebElement element = remoteDriver.findElement(locator);
                Point location = element.getLocation();
                Dimension elementSize = element.getSize();
                int elementBottom = location.getY() + elementSize.getHeight();
                // On iOS, isDisplayed() is unreliable for off-screen elements in the XCUITest
                // driver — use coordinate-based check instead to confirm true viewport visibility
                boolean isOnScreen = location.getY() >= 0 && elementBottom <= viewportBottom
                        && location.getX() >= 0 && (location.getX() + elementSize.getWidth()) <= screenSize.getWidth();
                if (isOnScreen) {
                    System.out.println("Element visible on screen after " + scrollAttempts + " scroll attempt(s).");
                    return element;
                }
            } catch (NoSuchElementException e) {
                // Element not yet in DOM — keep scrolling
            }
            mobileSwipe(direction);
            scrollAttempts++;
            if (!isPageStable()) {
                performSleep(1);
            }
        }
        System.out.println("Element not found on screen after " + maxScrolls + " scroll attempt(s).");
        return remoteDriver.findElement(locator);
    }

    public boolean isTextAtTop(String textToFind) {
        WebElement textElement = remoteDriver.findElement(By.xpath("//*[contains(@label, '" + textToFind + "')]"));
        Point location = textElement.getLocation();
        Dimension screenSize = remoteDriver.manage().window().getSize();
        int screenHeight = screenSize.getHeight();
        return location.getY() <= screenHeight/2;
    }

    /**
     * Computes [startX, startY, endX, endY] swipe coordinates for the given direction.
     * Light scroll uses tighter ranges; regular scroll uses the full-range defaults.
     */
    private int[] computeSwipeCoords(String direction, int width, int height, boolean isLightScroll) {
        int startX = width / 2;
        int startY = isLightScroll ? (int)(height * 0.6) : (int)(height * 0.7);
        int endX = startX;
        int endY = startY;

        switch (direction.toLowerCase()) {
            case "up":
                endY = isLightScroll ? (int)(height * 0.4) : (int)(height * 0.3);
                break;
            case "down":
                endY = isLightScroll ? (int)(height * 0.8) : (int)(height * 0.9);
                break;
            case "left":
                startX = isLightScroll ? (int)(width * 0.7) : (int)(width * 0.8);
                endX   = isLightScroll ? (int)(width * 0.3) : (int)(width * 0.2);
                break;
            case "right":
                startX = isLightScroll ? (int)(width * 0.3) : (int)(width * 0.2);
                endX   = isLightScroll ? (int)(width * 0.7) : (int)(width * 0.8);
                break;
            default:
                throw new IllegalArgumentException("Invalid swipe direction: " + direction);
        }
        return new int[]{startX, startY, endX, endY};
    }

    public void mobileSwipe(String direction, boolean... options) {
        boolean isPullDownRefreshNeeded = (options.length >= 1) && options[0];
        boolean isLightScroll = (options.length >= 2) && options[1];

        Dimension size = remoteDriver.manage().window().getSize();
        int[] coords = computeSwipeCoords(direction, size.width, size.height, isLightScroll);
        int startX = coords[0], startY = coords[1], endX = coords[2], endY = coords[3];

        if (remoteDriver instanceof AndroidDriver) {
            Map<String, Object> params = new HashMap<>();
            // For pull-down refresh, start higher and swipe further down
            if ("down".equals(direction.toLowerCase()) && isPullDownRefreshNeeded) {
                params.put("left", startX - 10);
                params.put("top", (int) (size.height * 0.2));
                params.put("width", 20);
                params.put("height", (int) (size.height * 0.6));
                params.put("direction", "down");
                params.put("percent", 0.9);
            } else {
                params.put("left", Math.min(startX, endX));
                params.put("top", Math.min(startY, endY));
                params.put("width", Math.abs(endX - startX));
                params.put("height", Math.abs(endY - startY));
                params.put("direction", direction.toLowerCase());
                params.put("percent", isLightScroll ? 0.3 : 0.75);
            }
            ((JavascriptExecutor) remoteDriver).executeScript("mobile: swipeGesture", params);
        } else {
            HashMap<String, Object> swipeObject = new HashMap<>();
            swipeObject.put("startX", startX);
            swipeObject.put("startY", startY);
            swipeObject.put("endX", endX);
            swipeObject.put("endY", endY);
            swipeObject.put("direction", direction.toLowerCase());
            swipeObject.put("velocity", isPullDownRefreshNeeded ? 1000 : (isLightScroll ? 50 : 100));
            ((JavascriptExecutor) remoteDriver).executeScript("mobile: swipe", swipeObject);
        }
    }

    public boolean scrollToTopWeb() {
        try {
            ((JavascriptExecutor) remoteDriver).executeScript("window.scrollTo(0, 0);");
            performSleep(1);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    public boolean isVisibleInViewport(WebElement element) {
        java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Point p = element.getLocation();
        return p.getX() <= screenSize.getWidth() && p.getY() <= screenSize.getHeight();
    }

    public boolean scrollToElement(WebElement element) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
            performSleep(1);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**********************************************************************************
     * getDynamicWebElementsByIdentifier gets the WebElements from attribute name and attribute value for all platforms
     * @param identifierAttribute - Attribute of the tag needed
     * @param attributeValueText - Attribute Value of the tag needed
     * @return
     */

    public List<WebElement> getDynamicWebElementsByIdentifier(String identifierAttribute, String attributeValueText){
        String xpathExpression;
        if(remoteDriver instanceof AndroidDriver || remoteDriver instanceof IOSDriver) {
            xpathExpression = String.format("//*[contains(@%s, '%s')]", identifierAttribute, attributeValueText);
        } else if (identifierAttribute.equalsIgnoreCase("text")) {
            xpathExpression = String.format("//*[contains(%s(), '%s')]", identifierAttribute, attributeValueText);
        } else {
            xpathExpression = String.format("//*[@%s = '%s']", identifierAttribute, attributeValueText);
        }
        return remoteDriver.findElements(By.xpath(xpathExpression));
    }

    /**********************************************************************************
     * getDynamicWebElementsByTagAndAttribute gets the WebElements from tag name, attribute name and attribute value for all platforms
     * Usage: getDynamicWebElementsByTagAndAttribute(remoteDriver instanceof WebDriver?"span":"*", "text", "Add to cart");
     * @param tag - tagName of desired Elements
     * @param identifierAttribute - Attribute of the tag
     * @param attributeValueText - Attribute Value of the Attribute
     * @return
     */

    public List<WebElement> getDynamicWebElementsByTagAndAttribute(String tag, String identifierAttribute, String attributeValueText){
        String xpathExpression;
        if(remoteDriver instanceof AndroidDriver || remoteDriver instanceof IOSDriver) {
            xpathExpression = String.format("//%s[contains(@%s, '%s')]", tag, identifierAttribute, attributeValueText);
        } else if (identifierAttribute.equalsIgnoreCase("text")) {
            xpathExpression = String.format("//%s[contains(%s(), '%s')]", tag, identifierAttribute, attributeValueText);
        } else {
            xpathExpression = String.format("//%s[contains(@%s , '%s')]", tag, identifierAttribute, attributeValueText);
        }
        WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(30));
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(xpathExpression)));
    }

    /**********************************************************************************
     * clickInterceptibleElement is created to handle mostly web cases where element click is usually intercepted by a bug in UI code, best practice is to report the bug
     * Usage: clickInterceptibleElement(addToCartButtons.get(i), 1000);
     * @param el - WebElement to click
     * @param waitTime - waitTime to update explicit waits
     */


    public void clickInterceptibleElement(WebElement el, int waitTime) {
        try {
            attemptFluentClick(el, waitTime);
            Reporter.log("Clicked on element " + el);
        } catch (Exception e) {
            Reporter.log(e.getMessage());
            throw e;
        }
    }

    /****
     * This method is used to sendKeys using action class for mobile in case element is not accessible via webdriver click
     * @param el
     * @param text
     */
    public void clickElementAndSendKeysUsingActionClass(WebElement el, String text) {
        Actions actions = new Actions(remoteDriver);
        actions.moveToElement(el).click().perform();
        performSleep(4);
        actions.moveToElement(el).sendKeys(text).build().perform();
        performSleep(4);
    }

    /***************************************************************************
     * This method is implemented when specifically a click not happening is supposed to not throw an exception (The regular click method is a blocker)
     * Usage : unblockingClick(deliverFromStoreCTA, 10, "deliverFromStoreCTA");
     * @param el - WebElement to click
     * @param waitTime - explicit wait multiplier in Seconds
     * @param elementName - element Name (what the webElement does)
     */

    public void unblockingClick(WebElement el, int waitTime, String elementName){
        try {
            WebDriverWait localWait = new WebDriverWait(this.remoteDriver, Duration.ofSeconds(waitTime));
            localWait.until(ExpectedConditions.elementToBeClickable(el));
            try{
                Actions actions = new Actions(remoteDriver);
                actions.moveToElement(el).click().perform();
            } catch (Exception e){
                el.click();
                e.printStackTrace();
            }
        } catch (Exception e){
            Reporter.log(elementName+"Element Not Present");
            Reporter.log(e.getMessage());
        }
    }

    public void refreshPage() {
        if (remoteDriver instanceof IOSDriver || remoteDriver instanceof AndroidDriver) {
            mobileSwipe("down", true);
        } else {
            remoteDriver.navigate().refresh();
        }
    }

    /**
     * Produces a valid XPath string literal for the given value, handling apostrophes
     * via concat() to avoid breaking the XPath parser (e.g. "We're" → concat('We',"'",'re...')).
     */
    private static String xpathStringLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        String[] parts = value.split("'", -1);
        StringBuilder sb = new StringBuilder("concat(");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append(",\"'\",");
            sb.append("'").append(parts[i]).append("'");
        }
        sb.append(")");
        return sb.toString();
    }

    public void scrollToTextWithLoop(String text) {
        scrollToTextInternal(text, 300, -1);
    }

    public void scrollUpToTextWithLoop(String text) {
        scrollToTextInternal(text, -300, 10);
    }

    /**
     * Scrolls the web page to bring {@code text} into view.
     * @param scrollStep pixels to scroll per step — positive = down, negative = up
     * @param maxAttempts maximum number of scroll steps; -1 means unlimited (scroll until found)
     */
    private void scrollToTextInternal(String text, int scrollStep, int maxAttempts) {
        JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
        int attempts = 0;
        while (maxAttempts < 0 || attempts < maxAttempts) {
            try {
                WebElement element = remoteDriver.findElement(
                        By.xpath("//*[contains(text(), " + xpathStringLiteral(text) + ")]"));
                js.executeScript("arguments[0].scrollIntoView(true);", element);
                return;
            } catch (NoSuchElementException e) {
                js.executeScript("window.scrollBy(0, " + scrollStep + ");");
                attempts++;
            }
        }
    }

    public List<WebElement> getList(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return appDriver.findElements(elementIdentifier);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /************************************************************************
     * This method is used to select value from picker class and is applicable commonly across IOS.
     * @param pickerValue - String
     */

    public void setPickerValueForIos(String pickerValue) {
        WebElement pickerElement = remoteDriver.findElement(By.className("XCUIElementTypePickerWheel"));
        sendText(pickerElement, pickerValue);
    }

    public void acceptAlertIfPresent() {
        handleAlertIfPresent(true);
    }

    public void dismissAlertIfPresent() {
        handleAlertIfPresent(false);
    }

    private void handleAlertIfPresent(boolean accept) {
        try {
            Alert alert = this.remoteDriver.switchTo().alert();
            System.out.println("Alert detected: " + alert.getText());
            if (accept) alert.accept(); else alert.dismiss();
        } catch (NoAlertPresentException e) {
            // No alert to handle, ignore
        }
    }

    /***
     *  This method is used to scroll the screen to particular text or element in mobile and WEB
     * @param ele
     * @param scrollToText
     * @param direction
     */
    public void scrollElementForWebAndMobile(WebElement ele, String scrollToText, String direction) {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText(scrollToText, direction);
        } else if(remoteDriver instanceof AndroidDriver) {
            androidScrollDownToText(scrollToText);
        } else
            scrollToElement(ele);
    }

    /***
     * Method to click done button for IOS keyboard
     */
    public void clickDoneButtonForIOSKeyboard(){
        if(remoteDriver instanceof IOSDriver)
            click(AppiumBy.iOSNsPredicateString("type == 'XCUIElementTypeButton' AND name == 'Done'"));
    }

    /***
     * Method to check if the page is stable by comparing the page source before and after a short wait
     * @return true if the page source is the same, false otherwise
     */

    public boolean isPageStable() {
        // Checking for visible loading indicators is far cheaper than calling getPageSource() twice.
        // getPageSource() dumps the entire UI tree XML — without snapshotMaxDepth capped the dump
        // can be several MB and takes multiple seconds per call. Loading indicators are a targeted
        // single-element lookup and return almost instantly when nothing is loading.
        try {
            if (remoteDriver instanceof AndroidDriver) {
                // Android: check for ProgressBar or any element with a "Loading" content description
                boolean progressBarVisible = !remoteDriver
                        .findElements(By.className("android.widget.ProgressBar")).isEmpty();
                boolean loadingTextVisible = !remoteDriver
                        .findElements(By.xpath("//*[@content-desc='Loading' or @text='Loading']")).isEmpty();
                return !progressBarVisible && !loadingTextVisible;
            } else if (remoteDriver instanceof IOSDriver) {
                // iOS: check for XCUIElementTypeActivityIndicator (spinner)
                boolean spinnerVisible = !remoteDriver
                        .findElements(By.className("XCUIElementTypeActivityIndicator")).isEmpty();
                return !spinnerVisible;
            }
        } catch (Exception e) {
            Reporter.log("isPageStable check failed (treating as stable): " + e.getMessage());
        }
        return true;
    }

    /**
     * Method to navigate to a specific URL
     * @param url - The URL to navigate to
     * Configure this method for deeplinks to make it convenient for the framework
     */

    public void navigateToPage(String url) {
        try {
            remoteDriver.navigate().to(url);
            Reporter.log("Navigated to URL: " + url);
        } catch (Exception e) {
            Reporter.log("Failed to navigate to URL: " + url + " - " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void moveToElementAndClick(WebElement element, String elementName) {
        try {
            // Ensure the driver is an instance of IOSDriver
            if (remoteDriver instanceof IOSDriver) {
                // Wait until the element is visible and clickable
                WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(10));
                wait.until(ExpectedConditions.visibilityOf(element));
                wait.until(ExpectedConditions.elementToBeClickable(element));

                // Use Actions class to move to the element and click
                Actions actions = new Actions(remoteDriver);
                actions.moveToElement(element).click().perform();

                // Log the action
                Reporter.log("Moved to and clicked on element: " + elementName);
            } else {
                Reporter.log("Driver is not an instance of IOSDriver. Action skipped for element: " + elementName);
            }
        } catch (Exception e) {
            Reporter.log("Failed to move to and click on element: " + elementName + " due to error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void lightScroll(String direction) {
        this.mobileSwipe(direction, false, true);
    }

    /**
     * Presses the Android hardware Back key and waits 1 second for the UI to settle.
     */
    public void androidPressBackKey() {
        ((AndroidDriver) remoteDriver).pressKey(new KeyEvent(AndroidKey.BACK));
        performSleep(1);
    }

    /**
     * Check if current driver is Android
     * @return true if Android driver, false otherwise
     */
    protected boolean isAndroid() {
        return remoteDriver instanceof AndroidDriver;
    }

    /**
     * Check if current driver is iOS
     * @return true if iOS driver, false otherwise
     */
    protected boolean isIOS() {
        return remoteDriver instanceof IOSDriver;
    }

    /**
     * Returns {@code true} if at least one element matching {@code resourceId} and {@code text}
     * is fully inside the physical screen viewport right now (no scrolling performed).
     *
     * <h3>Why not {@code isElementDisplayed} / {@code isDisplayed()}?</h3>
     * <p>Android's RecyclerView pre-renders items outside the visible area into the view/
     * accessibility tree. As a result, {@code element.isDisplayed()} returns {@code true} even
     * for elements that are hundreds of pixels below (or above) the bottom of the screen —
     * the driver reports them as "rendered", not "on screen". Using {@code isDisplayed()} here
     * would cause false positives: a patient-name label that has not yet been scrolled into view
     * would be accepted as visible, breaking the ordering assertion in
     * {@code verifyRfpCardsDisplayedInOrder}.</p>
     *
     * <h3>How this check works</h3>
     * <p>After finding elements by XPath, each candidate's pixel coordinates are compared
     * against the actual screen dimensions — the same approach used in
     * {@link #mobileScrollToText}:</p>
     * <pre>
     *   loc.getY() &gt;= 0                                  // top edge on screen
     *   loc.getY() + height &lt;= screen.getHeight()        // bottom edge on screen
     *   loc.getX() &gt;= 0                                  // left edge on screen
     *   loc.getX() + width  &lt;= screen.getWidth()         // right edge on screen
     * </pre>
     * <p>All four conditions must hold for an element to be considered truly visible.</p>
     *
     * <h3>XPath attribute escaping</h3>
     * <p>{@code text} values containing single quotes, double quotes, or both are handled
     * automatically via XPath {@code concat()} so the generated predicate is always valid.</p>
     *
     * @param resourceId Android {@code resource-id} of the target elements
     *                   (e.g. {@code "com.walmart.android.debug:id/pharmacy_customer_name"})
     * @param text       exact string to match against the {@code @text} attribute (case-sensitive)
     * @return {@code true} if at least one matching element is fully within the viewport;
     *         {@code false} if no match exists or all matches are off-screen
     */
    public boolean isTextOnScreen(String resourceId, String text) {
        String escaped = !text.contains("'")  ? "'" + text + "'"
                       : !text.contains("\"") ? "\"" + text + "\""
                       : "concat('" + text.replace("'", "', \"'\", '") + "')";
        Dimension screenSize = remoteDriver.manage().window().getSize();
        return remoteDriver
                .findElements(By.xpath("//*[@resource-id='" + resourceId + "' and @text=" + escaped + "]"))
                .stream()
                .anyMatch(el -> {
                    try {
                        Point     loc     = el.getLocation();
                        Dimension elSize  = el.getSize();
                        int       bottom  = loc.getY() + elSize.getHeight();
                        return loc.getY() >= 0 && bottom <= screenSize.getHeight()
                                && loc.getX() >= 0
                                && (loc.getX() + elSize.getWidth()) <= screenSize.getWidth();
                    } catch (Exception e) {
                        return false;
                    }
                });
    }

    /**
     * iOS-specific viewport check: returns {@code true} if at least one element whose
     * {@code @name} attribute equals {@code elementName} and whose {@code @label} attribute
     * contains {@code labelText} is fully within the current viewport.
     *
     * <p>Use this instead of {@link #isTextOnScreen} on iOS, where Android-only
     * {@code @resource-id} / {@code @text} XPath attributes are absent.</p>
     */
    public boolean isIosLabelOnScreen(String elementName, String labelText) {
        String escaped = !labelText.contains("'")  ? "'" + labelText + "'"
                       : !labelText.contains("\"") ? "\"" + labelText + "\""
                       : "concat('" + labelText.replace("'", "', \"'\", '") + "')";
        Dimension screenSize = remoteDriver.manage().window().getSize();
        return remoteDriver
                .findElements(By.xpath("//*[@name='" + elementName + "' and contains(@label," + escaped + ")]"))
                .stream()
                .anyMatch(el -> {
                    try {
                        Point     loc    = el.getLocation();
                        Dimension elSize = el.getSize();
                        int       bottom = loc.getY() + elSize.getHeight();
                        return loc.getY() >= 0 && bottom <= screenSize.getHeight()
                                && loc.getX() >= 0
                                && (loc.getX() + elSize.getWidth()) <= screenSize.getWidth();
                    } catch (Exception e) {
                        return false;
                    }
                });
    }

    public void selectDropdown(WebElement ele, String val) {
        if (isAndroid()) {
            ele.clear();
            sendText(ele, val);
        } else {
            click(ele);
            setPickerValueForIos(val);
        }
    }
}
