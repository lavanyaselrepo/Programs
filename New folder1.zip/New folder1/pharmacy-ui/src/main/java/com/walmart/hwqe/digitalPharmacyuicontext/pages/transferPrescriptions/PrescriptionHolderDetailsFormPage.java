package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class PrescriptionHolderDetailsFormPage extends MobileBasePage {
    @FindBy(xpath = "//*[text()='First name*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"First name*\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"First name*\"]/child::android.widget.FrameLayout/android.widget.EditText")
    private WebElement inputFirstName;

    @FindBy(xpath = "//*[text()='Last name*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Last name*\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Last name*\"]/child::android.widget.FrameLayout/android.widget.EditText")
    private WebElement inputLastName;

    @FindBy(xpath = "//*[text()='Date of birth (mm/dd/yyyy)*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Date of birth* (mm/dd/yyyy)\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Date of birth*\"]/child::android.widget.FrameLayout/android.widget.EditText")
    private WebElement inputDob;

    @FindBy(xpath = "//*[text()='Sex assigned at birth*']/parent::*/following-sibling::*/select")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"LDSelect.trailingView\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"Sex assigned at birth*, Collapsed\"]/android.widget.FrameLayout/android.widget.EditText")
    private WebElement genderDropDown;

    @FindBy(xpath = "//option[text()='Male']")
    private WebElement selectMale;

    @FindBy(xpath = "//option[text()='Female']")
    private WebElement selectFemale;

    @FindBy(xpath = "//*[text()='Street address*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label, \"Street address*\")]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Street address*\"]/child::android.widget.FrameLayout/child::android.widget.EditText")
    private WebElement inputStreetAddressLine1;

    @FindBy(xpath = "//*[text()='Street address 2']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Street address 2\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Street address 2\"]/child::android.widget.FrameLayout/child::android.widget.EditText")
    private WebElement inputStreetAddressLine2;

    @FindBy(xpath = "//*[text()='Zip code*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Zip code*\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Zip code*\"]/child::android.widget.FrameLayout/child::android.widget.EditText")
    private WebElement inputZipCode;

    @FindBy(xpath = "//*[text()='City*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"City*\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"City*\"]/child::android.widget.FrameLayout/child::android.widget.EditText")
    private WebElement inputCity;

    @FindBy(xpath = "//*[text()='State*']/following-sibling::*/select")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"LDSelect.trailingView\"])[2]")
    @AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"State*, Collapsed\"]/android.widget.FrameLayout/android.widget.EditText")
    private WebElement selectStateDropDown;

    @FindBy(xpath = "//*[text()='Phone number*']/parent::*/following-sibling::*/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Phone number*\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Phone number*\"]/child::android.widget.FrameLayout/child::android.widget.EditText")
    private WebElement inputPhoneNumber;

    @FindBy(xpath = "//button[text()='Continue']")
    @iOSXCUITFindBy(accessibility = "TransferRxProfileInfoViewController.LinkActionView.cta")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    private WebElement continueButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='icon.semantic.selectExpand']")
    private List<WebElement> iosPickerExpandIcons;

    public PrescriptionHolderDetailsFormPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void enterFirstName(String firstName) {
        sendText(inputFirstName, firstName);
    }

    public void enterLastName(String lastName) {
        scrollElementForWebAndMobile(inputLastName, "Last name*", "up");
        sendText(inputLastName, lastName);
    }

    public void enterDob(String dob) {
        hideKeyboard(); // dismiss keyboard left open by enterLastName
        scrollElementForWebAndMobile(inputDob, "Date of birth*", "up");
        sendDateField(inputDob, dob);
    }

    public void enterGender(String gender) {
        hideKeyboard(); // dismiss keyboard left open by enterDob
        gender = stringUtils.convertGender(gender);
        scrollElementForWebAndMobile(genderDropDown, "Sex assigned at birth*", "up");
        if (remoteDriver instanceof IOSDriver) {
            click(iosPickerExpandIcons.get(0));
            setPickerValueForIos(gender);
            clickDoneButtonForIOSKeyboard();
        } else if(remoteDriver instanceof AndroidDriver){
            sendText(genderDropDown, gender);
        } else {
            if (gender.contains("F") || gender.contains("f"))
                click(selectFemale);
            else
                click(selectMale);
        }
    }

    public void enterAddressLine1(String addressLine1) {
        // No hideKeyboard needed — enterGender closes the picker with Done button on iOS,
        // and Android sendText auto-dismisses. No keyboard is open at this point.
        scrollElementForWebAndMobile(inputStreetAddressLine1, "Street address*", "up");
        sendText(inputStreetAddressLine1, addressLine1);
    }

    public void enterAddressLine2(String addressLine2) {
        scrollElementForWebAndMobile(inputStreetAddressLine2, "Street address 2", "up");
        sendText(inputStreetAddressLine2, addressLine2);
    }

    public void enterZipCode(String zipCode) {
        hideKeyboard(); // dismiss keyboard left open by enterAddressLine1
        scrollElementForWebAndMobile(inputZipCode, "Zip code*", "up");
        sendText(inputZipCode, zipCode);
    }

    public void enterCity(String city) {
        hideKeyboard(); // dismiss keyboard left open by enterZipCode
        scrollElementForWebAndMobile(inputCity, "City*", "up");
        sendText(inputCity, city);
    }

    public void enterState(String stateCode) {
        hideKeyboard(); // dismiss keyboard left open by enterCity
        scrollElementForWebAndMobile(selectStateDropDown, "State*", "up");
        if (remoteDriver instanceof IOSDriver) {
            click(iosPickerExpandIcons.get(1));
            setPickerValueForIos(stateCode.toUpperCase());
            clickDoneButtonForIOSKeyboard();
        } else if(remoteDriver instanceof AndroidDriver) {
            sendText(selectStateDropDown, stateCode);
        } else {
            click(selectStateDropDown);
            List<WebElement> stateCodes = getDynamicWebElementsByIdentifier("text", stateCode);
            click(stateCodes.get(0));
        }
    }

    public void enterPhoneNumber(String phoneNumber) {
        // No hideKeyboard needed — enterState uses a dropdown, keyboard is not showing.
        scrollElementForWebAndMobile(inputPhoneNumber, "Phone number*", "up");
        sendText(inputPhoneNumber, phoneNumber);
        clickDoneButtonForIOSKeyboard();
    }

    public void clickContinueButton() {
        click(continueButton);
    }
}
