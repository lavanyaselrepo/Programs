package com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.assignAndFetchStagingInfo;

public class assignAndFetchStagingInfoRequest {
    private Boolean override;
    private String purchaseOrderId;

    public Boolean getOverride() {
        return override;
    }

    public void setOverride(Boolean override) {
        this.override = override;
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

}
