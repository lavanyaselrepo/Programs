package com.walmart.hwqe.commoncontext.utils;

import com.walmart.hwqe.commons.utilities.PropertyReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Properties;

/**
 * Helper class to load pharmacy-ui properties from both DragonLibrary and pharmacy-ui module.
 * Properties are automatically loaded via static initializer when class is first accessed.
 */
public class PropertyReaderHelper {
    private static final Logger logger = LoggerFactory.getLogger(PropertyReaderHelper.class);
    private static final HashMap<String, Boolean> cache = new HashMap<>();
    private static boolean initialized = false;

    // Auto-load properties when class is first accessed
    static {
        String env = System.getProperty("ENV", "dev").toLowerCase();
        boolean uiConfig      = loadFile("config/ui-config.properties", null);
        boolean androidConfig = loadFile("config/android-config.properties", null);
        boolean iosConfig     = loadFile("config/ios-config.properties", null);
        boolean rxone         = loadFile("config/rxonemobileapp/", env);
        boolean dpMobileTests = loadFile("config/digitalPharmacyMobileAppTests/", env);
        boolean rxpdLabel     = loadFile("config/rxpd/label/", env);
        initialized = (uiConfig || androidConfig || iosConfig || rxone || dpMobileTests || rxpdLabel);
    }

    /**
     * Load all properties (ui-config + android-config + ios-config + RXONE + rxpd.label).
     * Auto-loaded via static initializer; environment is always read from System.getProperty("ENV", "dev").
     * @param propertyReader PropertyReader instance (kept for backward compatibility)
     * @return true if loaded successfully
     */
    public static boolean loadCustomProperties(PropertyReader propertyReader) {
        if (initialized) return true;

        String environment = System.getProperty("ENV", "dev").toLowerCase();
        boolean uiConfig      = loadFile("config/ui-config.properties", null);
        boolean androidConfig = loadFile("config/android-config.properties", null);
        boolean iosConfig     = loadFile("config/ios-config.properties", null);
        boolean rxone         = loadFile("config/rxonemobileapp/", environment);
        boolean dpMobileTests = loadFile("config/digitalPharmacyMobileAppTests/", environment);
        boolean rxpdLabel     = loadFile("config/rxpd/label/", environment);

        initialized = (uiConfig || androidConfig || iosConfig || rxone || dpMobileTests || rxpdLabel);
        return initialized;
    }

    /**
     * Load custom property file from specific path.
     * Environment is always read from System.getProperty("ENV", "dev")
     * @param propertyReader PropertyReader instance
     * @param path Path to properties file
     * @return true if loaded successfully
     */
    public static boolean loadCustomProperties(PropertyReader propertyReader, String path) {
        String environment = System.getProperty("ENV", "dev").toLowerCase();
        String key = path + "_" + environment;
        if (cache.getOrDefault(key, false)) return true;
        
        boolean result = loadFile(path, environment);
        cache.put(key, result);
        return result;
    }

    /**
     * Load property file from classpath (tries pharmacy-ui first, then DragonLibrary).
     */
    private static boolean loadFile(String basePath, String env) {
        String path = basePath + (env != null ? env + ".properties" : "");
        try (InputStream stream = PropertyReaderHelper.class.getClassLoader().getResourceAsStream(path) != null ? 
                PropertyReaderHelper.class.getClassLoader().getResourceAsStream(path) :
                Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {
            
            if (stream == null) {
                return false;
            }
            
            Properties props = new Properties();
            props.load(stream);
            
            // Load into both System properties AND PropertyReader using reflection
            Field field = PropertyReader.getInstance().getClass().getDeclaredField("properties");
            field.setAccessible(true);
            Properties internal = (Properties) field.get(PropertyReader.getInstance());
            
            props.forEach((k, v) -> {
                String key = k.toString(), val = v.toString();
                System.setProperty(key, val);
                internal.setProperty(key, val);
            });
            
            return true;
        } catch (Exception e) {
            logger.error("Failed to load properties from {}: {}", path, e.getMessage());
            return false;
        }
    }

    /**
     * Returns the fully-initialized PropertyReader singleton.
     * Calling this method triggers the static initializer (if not already run),
     * ensuring all pharmacy-ui properties (ui-config, android-config, ios-config, etc.)
     * are loaded before the caller accesses any property.
     */
    public static PropertyReader getInstance() {
        return PropertyReader.getInstance();
    }

    /**
     * Check if property key exists.
     */
    public static boolean HasKey(PropertyReader propertyReader, String key) {
        try {
            String value = propertyReader.getProperty(key);
            return value != null && !value.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clear cache to allow property reloading.
     */
    public static void clearCache() {
        cache.clear();
        initialized = false;
    }

    /**
     * Check if properties from path are loaded.
     */
    public static boolean isCustomPropertiesLoaded(String path) {
        return cache.getOrDefault(path, false);
    }
}
