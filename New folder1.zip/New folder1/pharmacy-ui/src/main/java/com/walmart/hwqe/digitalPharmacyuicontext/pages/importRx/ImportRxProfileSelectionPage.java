package com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx;

import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ImportRxProfileSelectionPage extends MobileBasePage {

    @FindBy(xpath = "//input[@type='radio' and @name='familyMemberRadio']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/subheading' and @text='Primary profile']")
    @iOSXCUITFindBy(accessibility = "Primary profile")
    public List<WebElement> familyMembersRadioBtns;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/primary_button' and contains(@text, 'Continue')]")
    @iOSXCUITFindBy(accessibility = "RxPrimaryStickyButton.primaryActionButton")
    public WebElement continueBtn;

    public ImportRxProfileSelectionPage(RemoteWebDriver appDriver) {
        super(appDriver);
    }

    public ImportRxProfileSelectionPage selectProfile(int index) {
        familyMembersRadioBtns.get(index).click();
        return this;
    }

    public void clickContinueBtn() {
        click(continueBtn);
    }

}
