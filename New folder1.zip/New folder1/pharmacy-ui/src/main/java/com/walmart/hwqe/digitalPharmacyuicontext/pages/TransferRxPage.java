package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class TransferRxPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/platform_sdk_toolbar_title")
    public WebElement transferPrescriptionTitle;

    @AndroidFindBy(xpath = "//*[contains(@text, 'Date of birth')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferProfileView.dobTextField']/descendant::XCUIElementTypeTextField")
    @FindBy(xpath = "//input[@placeholder='mm/dd/yyyy']")
    public WebElement dateOfBirthInput;

    @AndroidFindBy(xpath = "//*[contains(@text, 'Phone number')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferProfileView.phoneNumberTextField']/descendant::XCUIElementTypeTextField")
    @FindBy(xpath = "//input[@autocomplete='tel']")
    public WebElement phoneNoInput;

    @AndroidFindBy(xpath = "//*[contains(@text, 'Continue')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Continue']")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_selected_button")
    @iOSXCUITFindBy(accessibility = "TransferAllChoiceView.specificButton")
    @FindBy(xpath = "//span[contains(text(),'transfer certain prescriptions')]")
    public WebElement transferIndividualRxButton;

    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/prescription_name_field']/descendant::android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferAddPrescriptionHeaderView.prescriptionNameTextField']/descendant::XCUIElementTypeTextField")
    @FindBy(id ="react-aria-16" )
    public WebElement drugName;

    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/prescription_number_field']/descendant::android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='TransferAddPrescriptionHeaderView.prescriptionNumberTextField']//descendant::XCUIElementTypeTextField")
    @FindBy(id = "react-aria-18")
    public WebElement rxNoInput;

    @AndroidFindBy(id = "com.walmart.android.debug:id/add_button")
    @iOSXCUITFindBy(accessibility = "TransferAddPrescriptionController.LinkActionView.cta")
    @FindBy(xpath = "//button[text()='Add Prescription']")
    public WebElement addRxButton;


    public TransferRxPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getTransferPrescriptionTitleText() {

        return getText(transferPrescriptionTitle);
    }

    public void enterDOBText() {

        sendText(dateOfBirthInput,"01/01/1931");
    }

    public void enterPhoneNoText() {

        phoneNoInput.sendKeys("3333333333");
    }

    public void clickContinueButton() {

        continueButton.click();
    }

    public void clickTransferIndividualRx() {

        transferIndividualRxButton.click();
    }

    public void enterDrugName() {

        sendText(drugName,"crocin");
    }

    public void enterRxNo() {

        sendText(rxNoInput,"8815000");
    }

    public void clickAddRxButton() {

        click(addRxButton);
    }


}
