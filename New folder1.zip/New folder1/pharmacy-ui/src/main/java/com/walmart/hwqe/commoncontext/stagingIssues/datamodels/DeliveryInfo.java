package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeliveryInfo {
	public String shipToName;
    public String addressLineOne;
    public String addressLineTwo;
    public String city;
    public String stateOrProvinceCode;
    public String postalCode;
    public String countryCode;
    public Trip trip;


}
