package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;

public class DigitalPharmacyAppiumServer{

    public boolean startServer() {
        try{
            Process process = Runtime.getRuntime().exec("appium --address localhost -p 4723 --relaxed-security --base-path /wd/hub");
            Thread.sleep(3000);
            System.out.println("Appium server started");
        }
        catch(Exception e){
            System.out.println("There was an Error Starting the Server");
            e.printStackTrace();
        }
        return false;
    }
    public boolean stopServer(){
        try{
            Process process = Runtime.getRuntime().exec("pkill -f appium");
            process.waitFor();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}