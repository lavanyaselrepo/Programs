package com.walmart.hwqe.commoncontext.utils;

import org.awaitility.Awaitility;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public class Poller {
    private int maxElapsedTimeLimitAllowed;
    private int pollInterval;

    public Poller(int maxElapsedTimeLimitAllowed, int pollInterval) {
        setMaxElapsedTimeLimitAllowed(maxElapsedTimeLimitAllowed); // max limit till we get a success - TimeUnit in Seconds
        setPollInterval(pollInterval); // poll interval in milliseconds - Time Unit in ms
    }

    public Poller() {
        // Default Constructor
        setMaxElapsedTimeLimitAllowed(300); // max limit till we get a success - 5 mins
        setPollInterval(500); // poll interval in milliseconds - 500 ms intervals
    }

    public void setMaxElapsedTimeLimitAllowed(int maxElapsedTimeLimitAllowed) {
        this.maxElapsedTimeLimitAllowed = maxElapsedTimeLimitAllowed;
    }

    public int getMaxElapsedTimeLimitAllowed() {
        return this.maxElapsedTimeLimitAllowed;
    }

    public void setPollInterval(int pollInterval) {
        this.pollInterval = pollInterval;
    }

    public int getPollInterval() {
        return this.pollInterval;
    }

    /**
     * Polls a given Callable action until it returns true or timeout is reached.
     *
     * @param action The callable action to poll.
     * @return true if action succeeds, false if timeout occurs.
     */
    public boolean pollForSuccess(Callable<Boolean> action) {
        try {
            // Awaitility polling configuration
            Awaitility.await()
                    .atMost(getMaxElapsedTimeLimitAllowed(), TimeUnit.SECONDS) // Timeout after 10 seconds
                    .pollInterval(getPollInterval(), TimeUnit.MILLISECONDS) // Poll every 500 ms
                    .until(action); // Until the Callable returns true

            return true; // If action succeeds within the timeout
        } catch (Exception e) {
            // Timeout or failure condition met
            return false;
        }
    }

    /**
     * Example method that could be polled.
     * This is just a placeholder for a real action.
     *
     * @return true if the action succeeds, false if it fails.
     */
    public static boolean tryAction() {
        // Replace with your action logic (e.g., network request, DB check, etc.)
        return Math.random() > 0.7;  // 30% chance to succeed
    }

    // Example Test Method
    /*@Test
    public void testFunction() {
        // Example of using the Poller utility with a custom action
        boolean success = pollForSuccess(() -> tryAction());  // Passing the method reference as a Callable

        if (success) {
            System.out.println("Action succeeded!");
        } else {
            System.out.println("Action failed or timeout reached.");
        }
    }*/
}
