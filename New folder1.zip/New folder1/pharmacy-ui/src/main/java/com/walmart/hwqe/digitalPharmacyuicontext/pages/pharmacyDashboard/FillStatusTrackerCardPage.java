package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.PharmacyDashboardPage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class FillStatusTrackerCardPage extends PharmacyDashboardPage {

    public FillStatusTrackerCardPage(RemoteWebDriver driver) {
        super(driver);
    }

    @AndroidFindBy(id = "com.walmart.android.debug:id/header_title")
    WebElement fillStatusCardHeaderText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/header_description")
    WebElement fillStatusCardSubHeaderText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    WebElement patientName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    @FindBy(xpath = "//*[contains(@id,'user-icon')]")
    WebElement petPatientIcon;

    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    WebElement humanPatientIcon;

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_details")
    WebElement fillDetailsArrowCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/drug_name")
    WebElement rxName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/price")
    WebElement rxEstimatedPrice;

    @FindBy(xpath = "//*[@class='w_hhLG w_8nsR w_jDfj']")
    WebElement acknowledgeBtn;


    public String getFillStatusCardHeaderText(){
        return getText(fillStatusCardHeaderText);
    }

    public boolean isFillStatusCardSubHeaderTextVisible(){
        return isElementDisplayed(fillStatusCardSubHeaderText);
    }

    public boolean isPetPatientIconVisible(){
        return isElementDisplayed(petPatientIcon);
    }

    public boolean isHumanPatientIconVisible(){
        return isElementDisplayed(humanPatientIcon);
    }
    public String getFillStatusCardSubHeaderText(){
        return getText(fillStatusCardSubHeaderText);
    }

    public void clickFillDetailsArrowCTA(){
        click(fillDetailsArrowCTA);
    }

    public String getRxName(){
        return getText(rxName);
    }

    public String getPatientNameOnFillTrackerCard() {return getText(patientName);}

    public String getRxNameOnFillTrackerCard() {return getText(rxName);}

    public String getRxEstimatedPrice(){
        return getText(rxEstimatedPrice);
    }

    public void clickOnAcknowledgeBtn(){
        if(isElementDisplayed(acknowledgeBtn,5)) click(acknowledgeBtn);
    }

}
