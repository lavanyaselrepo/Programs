package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class AstroDetails {
    public Customer customer;
    public ArrayList<Dependent> dependents;
    public ArrayList<Store> stores;
}
