package com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientDataForPickup;

@lombok.Getter
@lombok.Setter
public class ConnexusPatientDataforPickup {

    public int requestTypeCode;
    public int priorityId;
    public int dispenseType;
    public int patientId;
    public int siteID;
    public String inputPickUpDate;
    public String inputRxExpDate;
    public int numRefills;
    public Drug drug;
    public boolean allowExpiredOrder;
    public Prescriber prescriber;
}
