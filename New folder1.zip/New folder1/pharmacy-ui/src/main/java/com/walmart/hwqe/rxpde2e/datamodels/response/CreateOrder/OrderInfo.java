package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;
@lombok.Getter
@lombok.Setter
public class OrderInfo {
    public String orderId;
    public String status;
    public int orderVersion;
    public int amendReservationCount;
    public int amendPaymentCount;
    public String mobileNumber;
    public boolean invoiceRequired;
    public boolean onlinePaymentOnly;
}
