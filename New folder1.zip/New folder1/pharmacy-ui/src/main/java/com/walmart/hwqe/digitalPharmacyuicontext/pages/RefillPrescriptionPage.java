package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import java.util.List;

public class RefillPrescriptionPage extends MobileBasePage {

    private static final String IOS_PRICE_PENDING_XPATH = "//XCUIElementTypeStaticText[@name='RefillRequestPrescriptionInfoView.priceSubtitleLabel']";
    private static final String IOS_CHANGE_COVERAGE_BUTTON_XPATH = "//XCUIElementTypeButton[contains(@name, \"Change prescription coverage\") and contains(@name, \"%s\")]";
    private static final String ANDROID_CHANGE_COVERAGE_BUTTON_XPATH = "//android.widget.TextView[contains(@text,'%s')]/..//android.widget.TextView[@text='Change']";

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_sort_and_filter")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Prescriptions']")
    public WebElement myPrescriptionsHeaderLabel;

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_sort_and_filter")
    @iOSXCUITFindBy(accessibility = "Sort and filter")
    @FindBy(xpath = "//button[text()='Sort and filter']")
    public WebElement sortFilterOption;

    @AndroidFindBy(xpath = "//android.widget.RadioButton[@text='Active prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Active prescriptions']")
    @FindBy(xpath = "//span[text()='Active prescriptions']//preceding-sibling::input[@type='radio']")
    public WebElement activePrescriptionsFilter;

    @AndroidFindBy(id = "com.walmart.android.debug:id/apply_filters_btn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Apply']")
    @FindBy(xpath = "//button[text()='Apply']")
    public WebElement applyFilterButton;

    @iOSXCUITFindBy(accessibility = "Cancel")
    public WebElement cancelRefillAction;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/refill_checkbox\").instance(0)")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[@name='HWCheckBoxListCell'])[1]")
    @FindBy(xpath = "(//input[not(@disabled) and @type='checkbox'])[1]")
    public WebElement firstActivePrescriptionItem;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/drug_name\").instance(0)")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[@name='HWCheckBoxListCell'])[1]//XCUIElementTypeStaticText[1]")
    public WebElement firstActivePrescriptionDrugName;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id='com.walmart.android.debug:id/refill_details_fills_left_est_price'])[1]")
    public WebElement firstPrescriptionFillsAndPrice;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/refill_button']")
    @iOSXCUITFindBy(accessibility = "Continue")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continueRefillButton;

    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'Request refill')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"HWPrimaryAndLinkButtonWithInfoView.primaryActionButton\"]")
    @FindBy(xpath = "//button[text()='Request refill']")
    public WebElement requestRefillButton;

    @FindBy(xpath = "//button[text()='Back to pharmacy']")
    public WebElement backToPharmacyBtn;

    @FindBy(xpath = "//input[@type='checkbox']")
    public List<WebElement> refillCheckboxes;

    @FindBy(xpath = "//input[@type='checkbox' and @disabled]")
    public WebElement refillDisabledCheckbox;

    @AndroidFindBy(xpath = "//*[contains(@text,'Your refill request has been placed.')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Your refill request has been placed.\"]")
    @FindBy(xpath = "//*[contains(text(),'Your refill request has been placed.')]")
    public WebElement refillSuccessMsg;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Discount card\"]")
    public WebElement discountCardLabelOnReview;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, \"Due to your coverage change\")]")
    public WebElement coverageChangePricePendingMessage;

    @FindBy(xpath = "//*[contains(text(),'Estimated ready tomorrow by 2:30pm')]")
    public WebElement refillEstimateDeliveryTimeMsg;

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_family_filter")
    @FindBy(xpath = "//button[contains(@aria-label,'My family')]")
    @iOSXCUITFindBy(accessibility = "My family")
    public WebElement myFamilyFilter;

    @AndroidFindBy(id = "com.walmart.android.debug:id/reset_filters_btn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Reset all']")
    @FindBy(xpath = "//button[text()='Reset all']")
    public WebElement resetAllFiltersButton;

    public RefillPrescriptionPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickSortAndFilterButton() {
        click(sortFilterOption, 10);
    }

    public void applyActivePrescriptionsFilter() {
        activePrescriptionsFilter.click();
    }

    public void selectActivePrescriptionsFilter() {
        activePrescriptionsFilter.click();
    }

    public void applySelectedFilter() {
        applyFilterButton.click();
    }

    public void selectFirstActivePrescription() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Refill Prescriptions", "up");
        } else {
            scrollToElement(firstActivePrescriptionItem);
        }
        firstActivePrescriptionItem.click();
        waitUntilElementSelected(firstActivePrescriptionItem, 5);
    }

    public String getFirstActivePrescriptionName() {
        if (isIOS()) {
            // Cell label: "Atorvastatin 10mg TAB Last received: Apr 07, 2026, Fills left: 10  •  Last paid price: $18.77, Button"
            // The drug name precedes " Last received:" — split on that token, not on "," which appears inside the date.
            String cellLabel = firstActivePrescriptionItem.getAttribute("label");
            if (cellLabel != null && cellLabel.contains(" Last received:")) {
                return cellLabel.split(" Last received:")[0].trim();
            }
        }
        return getText(firstActivePrescriptionDrugName);
    }

    /**
     * Returns the last paid price for the first prescription row (e.g. "$18.77").
     * Android: reads from the dedicated fills-left/price TextView (resource-id based).
     * iOS: the price is embedded in the cell's accessibility label
     *      e.g. "Atorvastatin 10mg TAB …, Fills left: 10  •  Last paid price: $18.77, Button"
     *      so we read the cell label attribute and extract the token after "Last paid price:".
     */
    public String getFirstPrescriptionLastPaidPrice() {
        String fullText;
        if (isIOS()) {
            // getAttribute("label") works even when accessible=false
            fullText = firstActivePrescriptionItem.getAttribute("label");
        } else {
            fullText = getText(firstPrescriptionFillsAndPrice);
        }
        String[] parts = fullText.split("Last paid price:");
        // Strip trailing ", Button" that iOS appends to the cell label
        return parts.length > 1 ? parts[1].replaceAll(",\\s*Button.*$", "").trim() : fullText;
    }

    public void clickContinueRefillButton() {
        continueRefillButton.click();
    }

    public String getMyPrescriptionsHeaderLabel() {

        return getText(myPrescriptionsHeaderLabel);
    }

    public void clickCancelRefillAction(){click(cancelRefillAction);}

    public void selectAllRefillCheckboxes(){
        for(WebElement ele : refillCheckboxes) {
            click(ele, "Refill Checkbox");
        }
    }

    public boolean isDisabledCheckboxAvailable(int waitTime){
        return isElementDisplayed(refillDisabledCheckbox, waitTime);
    }

    public void clickRequestRefillButton() {
        click(requestRefillButton, "Request Refill Button");
    }

    public void isDisplayedRefillSuccessMsg() {
        isElementDisplayed(refillSuccessMsg,"Refill success message");
    }

    public void isDisplayedRefillDeliveryTimeMsg() {
        isElementDisplayed(refillEstimateDeliveryTimeMsg,"Refill Estimate Delivery Time Message");
    }

    public void clickMyFamilyButton() { click(myFamilyFilter); }

    public void clickResetAllFilters() {
        click(resetAllFiltersButton);
    }

    public void selectFamilyMember(String familyMemberName) {
        String firstName = familyMemberName.split(" ")[0];
        String ele = "";
        if (remoteDriver instanceof AndroidDriver)
            ele = "//android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/family_filter_item' and .//android.widget.CheckBox[contains(@text,'" + firstName + "')]]";
        else if (remoteDriver instanceof IOSDriver)
            ele = "//XCUIElementTypeStaticText[contains(@name,'" + familyMemberName + "')]";
        else ele = "//span[contains(text(),'" + familyMemberName + "')]//preceding-sibling::input[@type='checkbox']";
        click(remoteDriver.findElement(By.xpath(ele)));
    }

    public void clickOnDrug(String drugName){
       click(getDynamicWebElementsByIdentifier("text",drugName).get(0));
    }

    public boolean verifyDrugIsDisplayed(String drugName) {
        isElementDisplayed(sortFilterOption, 5);
        return isElementDisplayed(getDynamicWebElementsByIdentifier("text", drugName).get(0), 5);
    }

    /**
     * Clicks the "Change" coverage button for the given drug on the Refill Review screen.
     * iOS: the button's accessibility name includes patient name and drug name.
     * Android: finds the "Change" CTA adjacent to the drug's coverage row.
     */
    public void clickChangeCoverageForDrug(String drugName) {
        if (isIOS()) {
            remoteDriver.findElement(
                    By.xpath(String.format(IOS_CHANGE_COVERAGE_BUTTON_XPATH, drugName))).click();
        } else {
            remoteDriver.findElement(
                    By.xpath(String.format(ANDROID_CHANGE_COVERAGE_BUTTON_XPATH, drugName))).click();
        }
    }

    public boolean isDiscountCardDisplayedOnReview() {
        return isElementDisplayed(discountCardLabelOnReview, 10);
    }

    public boolean isPricePendingDisplayedOnReview() {
        // XCUITest marks this element visible=false even though it renders on screen,
        // so isDisplayed() returns false. Use findElements existence check instead.
        return !remoteDriver.findElements(By.xpath(IOS_PRICE_PENDING_XPATH)).isEmpty();
    }

    public boolean isCoverageChangePricePendingMessageDisplayed() {
        return isElementDisplayed(coverageChangePricePendingMessage, 10);
    }

    public boolean isRefillSuccessMessageDisplayed() {
        return isElementDisplayed(refillSuccessMsg, 15);
    }
}
