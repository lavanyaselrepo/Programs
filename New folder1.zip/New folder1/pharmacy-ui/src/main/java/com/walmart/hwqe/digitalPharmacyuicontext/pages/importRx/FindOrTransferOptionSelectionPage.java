package com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx;

import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class FindOrTransferOptionSelectionPage extends MobileBasePage {

    @FindBy(xpath = "//h1[contains(text(),'Find or transfer prescriptions')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/platform_sdk_toolbar_title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Find or transfer prescriptions']")
    public WebElement toolbarTitle;

    @FindBy(xpath = "//h2[contains(text(),'How would you like to add prescriptions')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/headerTitle")
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'How would you like to add prescriptions?' AND visible == 1")
    public WebElement headerTitle;

    @FindBy(xpath = "//p[contains(text(),'Select an option to continue')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/headerSubTitle")
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Select an option to continue.' AND visible == 1")
    public WebElement headerSubTitle;

    @FindBy(xpath = "//input[@type='radio' and @value='findPrescriptions']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='Find Walmart prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Find Walmart prescriptions']")
    public WebElement findWalmartPrescriptionsHeading;

    @FindBy(xpath = "//p[contains(text(),'Look up prescriptions for me')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/subheading' and contains(@text,'Look up prescriptions for me')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Look up prescriptions for me')]")
    public WebElement findWalmartPrescriptionsSubHeading;

    @FindBy(xpath = "//input[@type='radio' and @value='transferPrescriptions']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='Transfer prescriptions to Walmart']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Transfer prescriptions to Walmart']")
    public WebElement transferPrescriptionsHeading;

    @FindBy(xpath = "//p[contains(text(),'Transfer prescriptions for me')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/subheading' and contains(@text,'Transfer prescriptions for me')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Transfer prescriptions for me')]")
    public WebElement transferPrescriptionsSubHeading;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "HWPrimaryStickyButton.primaryActionButton")
    public WebElement continueBtn;

    public FindOrTransferOptionSelectionPage(RemoteWebDriver driver) {
        super(driver);
    }

    public boolean isHeaderTitleDisplayed() {
        return isElementDisplayed(headerTitle, 10);
    }

    public String getToolbarTitleText() {
        return getText(toolbarTitle);
    }

    public String getHeaderTitleText() {
        return getText(headerTitle);
    }

    public String getHeaderSubTitleText() {
        return getText(headerSubTitle);
    }

    public boolean isFindWalmartOptionDisplayed() {
        return isElementDisplayed(findWalmartPrescriptionsHeading);
    }

    public String getFindWalmartHeadingText() {
        return getText(findWalmartPrescriptionsHeading);
    }

    public String getFindWalmartSubHeadingText() {
        return getText(findWalmartPrescriptionsSubHeading);
    }

    public boolean isTransferPrescriptionsOptionDisplayed() {
        return isElementDisplayed(transferPrescriptionsHeading);
    }

    public String getTransferPrescriptionsHeadingText() {
        return getText(transferPrescriptionsHeading);
    }

    public String getTransferPrescriptionsSubHeadingText() {
        return getText(transferPrescriptionsSubHeading);
    }

    public FindOrTransferOptionSelectionPage clickFindWalmartPrescriptionsRadio() {
        click(findWalmartPrescriptionsHeading);
        return this;
    }

    public void clickContinueBtn() {
        click(continueBtn);
    }
}
