package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Reporter;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConnectMyAccount extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/phone_number_field']//android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name='TextFieldStackView.textField']")
    @FindBy(xpath = "//input[@type='tel']")
    public WebElement phoneNumberTextBox;
    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    @iOSXCUITFindBy(accessibility = "SMSIDEnterPhoneViewController.primaryAction")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continueCTA;
    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    @iOSXCUITFindBy(accessibility = "KycDemographicsFormView.ctaButton")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement experianFormContinueCTA;
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Digit')]")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    @FindBy(xpath = "//input[contains(@id,'input-verificationCode')]")
    public WebElement otpSlot1;
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "ValidateOTPView.ctaButton")
    @FindBy(xpath = "//button[text()='Verify number']")
    public WebElement otpAcceptCTA;
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "SMSIDProfileListController.primaryButton")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement continueForProfileCTA;
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "Continue")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement genderContinueCTA;
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/enter_dob']//android.widget.EditText")
    @iOSXCUITFindBy(accessibility = "TextFieldStackView.textField")
    @FindBy(xpath = "//input[@placeholder='mm/dd/yyyy']")
    public WebElement enterDobForPatient;
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirm_dob_button")
    @iOSXCUITFindBy(accessibility = "SMSIDPrimaryDOBViewController.primaryAction")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement confirmCTA;
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.android.debug:id/auth_layout_pin']//android.widget.EditText")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    public WebElement enterPin;
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "Create PIN")
    @FindBy(xpath = "//button[text()='Set up PIN']")
    public WebElement createPinCTA;
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.android.debug:id/auth_layout_pin']//android.widget.EditText")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    public WebElement reenterPin;
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "Confirm PIN")
    public WebElement confirmPinCTA;
    @iOSXCUITFindBy(accessibility = "Continue")
    public WebElement continueAfterPinCreationCTA;
    @AndroidFindBy(id="com.walmart.android.debug:id/need_more_details")
    @iOSXCUITFindBy(accessibility = "SMSIDProfileNotFoundView.headerLabel")
    @FindBy(xpath = "//h2[contains(@class,'w_kV33 w_NVP_ w_mvVb mv3')]")
    public WebElement needMoreDetailsHeader;
    @AndroidFindBy(id="com.walmart.android.debug:id/add_more_details_button")
    @iOSXCUITFindBy(accessibility = "Add more details")
    @FindBy(xpath = "//button[contains(text(),'Add more details')]")
    public WebElement addMoreDetails;
    @iOSXCUITFindBy(accessibility = "FormHeaderView.titleLabel")
    @FindBy(xpath = "//h3[contains(@class,'user-details__profileFormTitle')]")
    public WebElement experianHeader;
    @AndroidFindBy(id="com.walmart.android.debug:id/primary_info")
    @iOSXCUITFindBy(accessibility = "Continue with a primary profile")
    @FindBy(id="page-heading")
    public WebElement primaryProfileHeader;
    @AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Linked account(s) found')]")
    @iOSXCUITFindBy(accessibility = "SMSIDOtherProfileView.titleLabel")
    @FindBy(xpath = "//h3[@class='w_kV33 w_LD4J w_mvVb mb2']")
    public WebElement linkedProfileFoundHeader;
    @AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Verify your identity')]")
    @iOSXCUITFindBy(accessibility = "SMSIDOtherProfileView.subTitleLabel")
    @FindBy(xpath="//*[@class='lh-copy']")
    public WebElement verifyIdentityHeader;
    @AndroidFindBy(id="com.walmart.android.debug:id/text")
    @iOSXCUITFindBy(accessibility = "LDAlert.messageLabel")
    @FindBy(xpath="//*[contains(text(),'Please select a primary account to continue.')]")
    public WebElement selectProfileAlert;
    @AndroidFindBy(id="com.walmart.android.debug:id/dob_title")
    @iOSXCUITFindBy(accessibility = "SMSIDPrimaryDOBViewController.headerLabel")
    @FindBy(xpath="//h2[@id='page-heading']")
    public WebElement dobPageHeader;
    @AndroidFindBy(xpath = "(//android.widget.RadioButton[@resource-id='com.walmart.android.debug:id/radio_btn'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name='HnWSelectableCard.contentView'])[1]")
    @FindBy(xpath="(//input[@type='radio'])[1]")
    public WebElement firstProfile;

    @AndroidFindBy(id = "android:id/button1")
    public WebElement clickContinueAfterSMS;

    // Experian patient profile form - DOB field (distinct resource-id from SMS confirm DOB screen)
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/dob_field']//android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Date of birth (mm/dd/yyyy). required']")
    public WebElement experianDobField;

    // Experian patient profile form - phone number field (distinct from SMS initial phone entry field)
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/phone_number_field']//android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Phone number. required']")
    public WebElement experianPhoneField;

    // Experian KYC security questions submit button
    @AndroidFindBy(id = "com.walmart.android.debug:id/kyc_main_button")
    @iOSXCUITFindBy(accessibility = "KycKbaFormView.submitButton")
    public WebElement kycSubmitButton;

    // All question title labels on the KYC screen (one per question block)
    @AndroidFindBy(id = "com.walmart.android.debug:id/kyc_questions_title")
    @iOSXCUITFindBy(accessibility = "KycKbaFormQuestionView.questionLabel")
    public List<WebElement> kycQuestionTitles;

    // Gender confirmation screen
    @AndroidFindBy(id = "com.walmart.android.debug:id/female")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Female']")
    public WebElement femaleOption;
    @AndroidFindBy(id = "com.walmart.android.debug:id/male")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Male']")
    public WebElement maleOption;

    public ConnectMyAccount(RemoteWebDriver driver){super(driver);}
    public void enterPhoneNumber(String phoneNumber){
        sendText(phoneNumberTextBox, phoneNumber);
    }

    public void clickContinueCTA() {
        click(continueCTA);
    }

    public void clickExperianFormContinueCTA() {
        click(experianFormContinueCTA);
    }

    public void sendOTP(String otp) {
        webWait.until(ExpectedConditions.elementToBeClickable(this.otpSlot1));
        sendText(otpSlot1, otp);
    }

    public void clickOtpAcceptCTA() {
        click(otpAcceptCTA);
    }

    public void clickContinueForProfileCTA() {
        click(continueForProfileCTA);
    }

    public void clickGenderContinueCTA() {
        click(genderContinueCTA);
    }

    public void enterDobForPatientProfile(String dob) {
        sendDateField(enterDobForPatient, dob);
    }

    public void clickConfirmCTA() {
        click(confirmCTA);
    }

    public void enterPin(String pin) {
        sendText(enterPin, pin);
    }

    public void clickCreatePinCTA() {
        click(createPinCTA);
    }

    public void reEnterPin(String pin) {
        sendText(reenterPin, pin);
    }

    public void clickConfirmPinCTA() {
        click(confirmPinCTA);
    }

    public void clickContinueAfterPinCreationCTA() {
        click(continueAfterPinCreationCTA);
    }

    public String needMoreDetailsText() {
        return getText(needMoreDetailsHeader);
    }

    public boolean experianFlow() {
        click(addMoreDetails);
        webWait.until(ExpectedConditions.visibilityOfAllElements(experianHeader));
        return experianHeader.isDisplayed();
    }

    public List<WebElement> connectedProfileList() {
        List<WebElement> connectedProfileList;
        if (remoteDriver instanceof AndroidDriver) {
            connectedProfileList = getDynamicWebElementsByTagAndAttribute("android.widget.RadioButton", "resource-id", "com.walmart.android.debug:id/radio_btn");
        }
        else if (remoteDriver instanceof IOSDriver) {
            connectedProfileList = getDynamicWebElementsByTagAndAttribute("XCUIElementTypeButton", "name", "SMSIDStoreProfileItemView.radioButton");
        } else {
            connectedProfileList = getDynamicWebElementsByTagAndAttribute("input", "type", "radio"); //update for other platform
        }
        return connectedProfileList;
    }

    public boolean isAnyProfileEnabled() {
        List<WebElement> connectedProfileList = connectedProfileList();
        boolean flag = false;

        for (WebElement profile : connectedProfileList) {
            if (profile.isEnabled()) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    public boolean isAnyProfileEnabledinWeb() {
        List<WebElement> connectedProfileList = connectedProfileList();
        List<WebElement> radioButtonNotEnabledList;
        radioButtonNotEnabledList = getDynamicWebElementsByTagAndAttribute("div", "class", "false");
        if(radioButtonNotEnabledList.size()==connectedProfileList.size())
            return true;
        else
            return false;
    }

    public void selectProfileFromList() {
        click(firstProfile);
    }

    public String selectProfileAlertText(){ return getText(selectProfileAlert);}
    public String getValidateIdentityText(){return getText(verifyIdentityHeader);}


    public void clickContinueAfterEnteringSMSNumber(){
        if (isElementDisplayed(clickContinueAfterSMS,5)) {
            click(clickContinueAfterSMS);
        }
        webWait.until(ExpectedConditions.elementToBeClickable(this.otpSlot1));
    }
    public void clickContinueNotConnected(){
        click(continueCTA);
    }

    public void clickAddMoreDetails() {
        click(addMoreDetails);
    }

    public void fillExperianProfileForm(String dob, String phoneNo) {
        sendDateField(experianDobField, dob);
        // DOB entry opens the soft keyboard which pushes the phone number field
        // off screen. Dismiss it before attempting to interact with that field.
        hideKeyboard();
        sendText(experianPhoneField, phoneNo);
        // Phone entry re-opens the keyboard, which covers the Continue button.
        // Dismiss again so the CTA is visible and clickable.
        hideKeyboard();
    }

    /**
     * Reads each question's text on the Experian KYC screen (via resource-id
     * {@code kyc_questions_title}), resolves candidate answers from the supplied map,
     * and selects the first matching radio button.
     *
     * <p>Questions can appear in any order and the set changes on every Experian session.
     * Combined questions ("currently or previously resided") are handled by trying multiple
     * candidates. Calculated questions ("how old will you be in X years") derive the answer
     * from the patient's DOB stored in the map under key {@code "dob"} (MM/dd/yyyy).
     *
     * @param answerMap question-key → answer value; see {@link #resolveExperianAnswerCandidates}
     */
    public void answerExperianQuestions(Map<String, String> answerMap) {
        // Wait for the KYC screen to fully load before reading question texts.
        // Without this, findElements returns an empty list immediately after the
        // profile form's Continue button is tapped and no answers get selected.
        isElementDisplayed(kycQuestionTitles.getFirst(), 5);

        List<WebElement> questionTitleEls = kycQuestionTitles;

        for (WebElement titleEl : questionTitleEls) {
            String questionText = titleEl.getText();
            if (questionText == null || questionText.trim().isEmpty()) continue;

            List<String> candidates = resolveExperianAnswerCandidates(questionText.toLowerCase(), answerMap);
            boolean answered = false;

            for (String candidate : candidates) {
                if (candidate.isEmpty()) continue;
                // Scroll first: the RecyclerView only renders visible rows, so an option
                // like "GRADUATE DEGREE" won't appear in findElements until UIAutomator
                // has scrolled it into the viewport and the view is inflated into the DOM.
                List<WebElement> matching;
                if (isAndroid()) {
                    // Scroll first so off-screen RecyclerView rows are inflated into the DOM.
                    // Use contains so e.g. "FAIRFAX" matches "FAIRFAX CITY" on screen.
                    androidScrollToTextContains(candidate);
                    matching = remoteDriver.findElements(
                            By.xpath("//android.widget.RadioButton[contains(@text,'" + candidate + "')]"));
                } else {
                    // Scroll the candidate into view so off-screen iOS cells are rendered.
                    mobileScrollToText(candidate, 6,"up");
                    matching = remoteDriver.findElements(
                            By.xpath("//XCUIElementTypeButton[contains(@label,'" + candidate + "')]"));
                    if (!matching.isEmpty() && !isElementDisplayed(matching.getFirst())) {
                        // mobileScrollToText uses screen-coordinate bounds to check visibility,
                        // so it can miss elements hidden behind a sticky footer (e.g. the Submit
                        // button bar on the KYC screen). Forcing 2 scrolls
                        mobileScrollToText("rrrrr", 2, "up");
                    }
                }
                if (!matching.isEmpty()) {
                    click(matching.getFirst());
                    Reporter.log("[ExperianKYC] Selected '" + candidate + "' for: " + questionText);
                    answered = true;
                    break;
                }
            }

            if (!answered) {
                throw new AssertionError("[ExperianKYC] Could not answer question: \"" + questionText
                        + "\" | Candidates tried: " + candidates);
            }
        }
    }

    /** All known Experian question categories. */
    private enum QuestionType {
        ZODIAC, LICENSE_PLATE, SSN_STATE, SSN_LAST4, DL_STATE,
        AGE_IN_YEARS, CITY, STREET, COUNTY, YEAR_OF_BIRTH,
        EDUCATION, VEHICLE_YEAR, VEHICLE_MODEL, VEHICLE_MAKE,
        UNKNOWN
    }

    /**
     * Classifies a question by keyword matching.
     * Checks are ordered most-specific first to prevent partial-substring false matches
     * (e.g. "license plate" before "license", "vehicle year" before "vehicle").
     */
    private QuestionType classifyQuestion(String q) {
        if (q.contains("zodiac"))                                   return QuestionType.ZODIAC;
        if (q.contains("license plate"))                            return QuestionType.LICENSE_PLATE;
        if (q.contains("social security") && q.contains("state"))  return QuestionType.SSN_STATE;
        if (q.contains("last 4") || q.contains("last four"))       return QuestionType.SSN_LAST4;
        if (q.contains("driver") && q.contains("license"))         return QuestionType.DL_STATE;
        if (q.contains("how old") || q.contains("current age"))    return QuestionType.AGE_IN_YEARS;
        if (q.contains("city"))                                     return QuestionType.CITY;
        if (q.contains("street"))                                   return QuestionType.STREET;
        if (q.contains("county"))                                   return QuestionType.COUNTY;
        if (q.contains("born") || q.contains("birth"))             return QuestionType.YEAR_OF_BIRTH;
        if (q.contains("education"))                                return QuestionType.EDUCATION;
        if (q.contains("year") && q.contains("vehicle"))           return QuestionType.VEHICLE_YEAR;
        if (q.contains("model") && q.contains("vehicle"))          return QuestionType.VEHICLE_MODEL;
        if (q.contains("vehicle") || q.contains("owned"))          return QuestionType.VEHICLE_MAKE;
        return QuestionType.UNKNOWN;
    }

    /**
     * Returns an ordered list of candidate answers for a question.
     * The first candidate that matches a visible radio button will be selected.
     * City/street return both current and previous values because Experian sometimes
     * combines them into a single "currently or previously resided" question.
     */
    private List<String> resolveExperianAnswerCandidates(String q, Map<String, String> answerMap) {
        List<String> candidates = new ArrayList<>();

        switch (classifyQuestion(q)) {
            case ZODIAC:        addIfPresent(candidates, answerMap, "zodiac");         break;
            case LICENSE_PLATE: addIfPresent(candidates, answerMap, "licensePlate");   break;
            case SSN_STATE:     addIfPresent(candidates, answerMap, "ssnState");       break;
            case SSN_LAST4:     addIfPresent(candidates, answerMap, "ssnLast4");       break;
            case DL_STATE:      addIfPresent(candidates, answerMap, "dlState");        break;
            case AGE_IN_YEARS:
                String age = calculateFutureAge(q, answerMap);
                if (!age.isEmpty()) candidates.add(age);
                break;
            case CITY:
                addIfPresent(candidates, answerMap, "currentCity");
                addIfPresent(candidates, answerMap, "previousCity");
                break;
            case STREET:
                addIfPresent(candidates, answerMap, "currentStreet");
                addIfPresent(candidates, answerMap, "previousStreet");
                break;
            case COUNTY:        addIfPresent(candidates, answerMap, "county");         break;
            case YEAR_OF_BIRTH: addIfPresent(candidates, answerMap, "yearOfBirth");   break;
            case EDUCATION:     addIfPresent(candidates, answerMap, "educationLevel"); break;
            case VEHICLE_YEAR:  addIfPresent(candidates, answerMap, "vehicleYear");   break;
            case VEHICLE_MODEL: addIfPresent(candidates, answerMap, "vehicleModel");  break;
            case VEHICLE_MAKE:  addIfPresent(candidates, answerMap, "vehicleMake");   break;
            default:
                Reporter.log("[ExperianKYC] No answer mapping found for question: " + q);
        }

        return candidates;
    }

    /**
     * Calculates the patient's age on (today + N years) from the question text.
     * Parses N from patterns like "in exactly 5 years" or "in 5 years".
     * Uses {@code "dob"} (MM/dd/yyyy) for an exact result, falls back to
     * {@code "yearOfBirth"} if full DOB is not in the map.
     */
    private String calculateFutureAge(String questionText, Map<String, String> answerMap) {
        try {
            Matcher m = Pattern.compile("(?:in exactly |in )(\\d+) years?").matcher(questionText);
            int futureYears = m.find() ? Integer.parseInt(m.group(1)) : 5;

            String dobStr = answerMap.get("dob");
            if (dobStr != null && !dobStr.isEmpty()) {
                LocalDate dob = LocalDate.parse(dobStr.trim(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
                int age = Period.between(dob, LocalDate.now().plusYears(futureYears)).getYears();
                return String.valueOf(age);
            }

            String yearStr = answerMap.get("yearOfBirth");
            if (yearStr != null && !yearStr.isEmpty()) {
                int birthYear = Integer.parseInt(yearStr.trim());
                int age = LocalDate.now().getYear() + futureYears - birthYear - 1;
                return String.valueOf(age);
            }
        } catch (Exception e) {
            Reporter.log("[ExperianKYC] Failed to calculate future age: " + e.getMessage());
        }
        return "";
    }

    private void addIfPresent(List<String> list, Map<String, String> map, String key) {
        String val = map.get(key);
        if (val != null && !val.isEmpty()) list.add(val);
    }

    public void submitKycQuestions() {
        click(kycSubmitButton);
    }

    public void selectGender(String gender) {
        if (gender.equalsIgnoreCase("female")) {
            isElementDisplayed(femaleOption, 15);
            click(femaleOption);
        } else {
            isElementDisplayed(maleOption, 15);
            click(maleOption);
        }
    }

    public void scrollUp()
    {
        scrollUpToTextWithLoop("Continue with a primary profile");
    }
}