package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class Contact {
    public ArrayList<Phone> phone;
    public Object type;
}
