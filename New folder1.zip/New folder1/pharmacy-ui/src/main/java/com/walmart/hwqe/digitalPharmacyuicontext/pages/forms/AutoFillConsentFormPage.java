package com.walmart.hwqe.digitalPharmacyuicontext.pages.forms;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import org.openqa.selenium.remote.RemoteWebDriver;

public class AutoFillConsentFormPage extends MobileBasePage {
    public AutoFillConsentFormPage(RemoteWebDriver driver) {
        super(driver);
    }
}