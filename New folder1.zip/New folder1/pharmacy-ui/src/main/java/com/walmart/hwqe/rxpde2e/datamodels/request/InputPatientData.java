package com.walmart.hwqe.rxpde2e.datamodels.request;

import lombok.Data;

import java.util.List;

@Data
public class InputPatientData {

        @Data
        public static class PatientRxData {
            String firstName;
            String lastName;
            String patientDOB;
            int storeId;
            int pin;
            int numOfRxsNeeded;
            String patientEmail;
            String patientPassword;
            String rxNumber;
            List<String> createdRxNbrList;
        }

}
