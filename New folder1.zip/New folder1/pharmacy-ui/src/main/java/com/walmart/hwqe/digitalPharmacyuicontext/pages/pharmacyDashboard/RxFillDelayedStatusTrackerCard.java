package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;

import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;

import java.time.Duration;

public class RxFillDelayedStatusTrackerCard extends FillStatusTrackerCardPage {

    public RxFillDelayedStatusTrackerCard(RemoteWebDriver driver) {
        super(driver);
    }

    @FindBy(id = "heading-DELAYED")
    @AndroidFindBy(id="com.walmart.android.debug:id/header_title")
    WebElement fillStatusCardHeaderText;

    @FindBy(id = "sub-heading-DELAYED")
    @AndroidFindBy(id = "com.walmart.android.debug:id/header_description")
    WebElement fillStatusCardSubHeaderText;

    @FindBy(xpath = "//*[contains(@id,'patient-name-fill-group-delayed')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    WebElement patientName;

    @FindBy(id = "refill-button-prescription-reminders")
    WebElement petIcon;

    @FindBy(id = "refill-button-prescription-reminders")
    WebElement humanIcon;

    @FindBy(xpath = "//*[contains(@id,'prescription-label-fill-group-delayed')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_count_suffix")
    WebElement prescriptionsCount;

    @FindBy(xpath = "//*[contains(@id,'formatted-drug-name-fill-group-delayed')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/drug_name")
    WebElement rxName;

    @FindBy(xpath = "//*[contains(@id='chevron-icon-fill-group-delayed')]")
    WebElement fillDetailsArrowCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/status")
    @FindBy(xpath = "//*[contains(@id,'delayed-reason-fill-group-delayed')]")
    WebElement delayedStatusReason;

    @AndroidFindBy(id = "com.walmart.android.debug:id/status_message")
    @FindBy(xpath = "//p[contains(@id,'delayed-note-fill-group-delayed')]")
    WebElement delayedStatusMessage;

    public String getDelayedStatusReason(){
        return getText(delayedStatusReason);
    }

    public String getDelayedStatusMessage(){
        return getText(delayedStatusMessage);
    }

    public String getFillStatusCardHeaderText(){
        return getText(fillStatusCardHeaderText);
    }

    public String getFillStatusCardSubHeaderText(){
        return getText(fillStatusCardSubHeaderText);
    }

    public void clickFillDetailsArrowCTA(){
        click(fillDetailsArrowCTA);
    }

    public String getRxName(){
        return getText(rxName);
    }

    public String getPrescriptionsCount(){
        return getText(prescriptionsCount);
    }

    public String getPatientNameOnFillTrackerCard() {return getText(patientName);}

    public boolean isPetIconVisible() {
        return isElementDisplayed(petIcon);
    }

    public boolean isHumanIconVisible() {
        return isElementDisplayed(humanIcon);
    }

    public boolean isFillStatusCardHeaderVisible(){
        scrollToElement(fillStatusCardHeaderText);
        if (!isElementDisplayed(fillStatusCardHeaderText)) {
            new FluentWait<>(appDriver)
                    .withTimeout(Duration.ofSeconds(180))
                    .pollingEvery(Duration.ofSeconds(5))
                    .ignoring(NoSuchElementException.class)
                    .until(d -> {
                        refreshPage();
                        scrollToElement(fillStatusCardHeaderText);
                        return isElementDisplayed(fillStatusCardHeaderText);
                    });
        }
        return isElementDisplayed(fillStatusCardHeaderText);
    }

}
