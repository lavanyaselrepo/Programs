package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ContinueAsGuestPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_welcome_secondary_button")
    @iOSXCUITFindBy(accessibility = "Continue as guest")
    public WebElement continueAsGuestButton;

    @iOSXCUITFindBy(accessibility = "Get notifications")
    public WebElement getNotificationsButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_zip_code_button")
    @iOSXCUITFindBy(accessibility = "Enter zip code")
    public WebElement enterZipCodeLink;

    @AndroidFindBy(xpath = "//android.widget.EditText[@text=\"Enter zip code\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Enter zip code']")
    public WebElement enterZipCodeInput;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_zip_code_search_button")
    @iOSXCUITFindBy(accessibility = "Search")
    public WebElement zipCodeSearchButton;

    @iOSXCUITFindBy(accessibility = "Continue")
    public WebElement trackActivityContinueButton;

    @iOSXCUITFindBy(accessibility = "Continue")
    public WebElement shareLocationButton;

    public ContinueAsGuestPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickContinueAsGuestButton() {
        click(continueAsGuestButton);
    }

    public void clickEnterZipCodeLink() {
        click(enterZipCodeLink);
    }

    public void enterZipCode(String pinCode) {
        sendText(enterZipCodeInput, pinCode);
    }

    public void clickSearchZipCodeButton() {
        click(zipCodeSearchButton);
    }

    public void clickTrackActivityContinueButton(){
        click(trackActivityContinueButton);
    }

    public void clickGetNotificationsButton(){
        click(getNotificationsButton);
    }

    public void clickShareLocationButton(){
        click(shareLocationButton);
    }
}
