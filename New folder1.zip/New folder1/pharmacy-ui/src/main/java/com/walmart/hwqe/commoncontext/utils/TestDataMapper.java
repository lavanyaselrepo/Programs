package com.walmart.hwqe.commoncontext.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;

/**
 * Utility for mapping a {@link JSONObject} to a typed POJO using Jackson.
 *
 * <p>The target class should be annotated with
 * {@code @JsonIgnoreProperties(ignoreUnknown = true)} so that extra JSON keys
 * (e.g. dependent fields when mapping caregiver-only POJOs) are silently ignored.
 *
 * <p>Usage:
 * <pre>
 *   CaregiverData caregiver = TestDataMapper.map(testData, CaregiverData.class);
 *   DependentData dependent = TestDataMapper.map(testData, DependentData.class);
 * </pre>
 */
public class TestDataMapper {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private TestDataMapper() {
        // utility class — no instantiation
    }

    /**
     * Converts a {@link JSONObject} into an instance of {@code clazz}.
     *
     * @param testData the JSON object loaded from the test data file
     * @param clazz    the POJO class to deserialize into
     * @param <T>      the target type
     * @return a populated instance of {@code clazz}
     */
    public static <T> T map(JSONObject testData, Class<T> clazz) {
        return MAPPER.convertValue(testData.toMap(), clazz);
    }
}

