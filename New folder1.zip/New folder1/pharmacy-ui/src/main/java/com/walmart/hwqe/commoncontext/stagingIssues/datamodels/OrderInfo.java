package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderInfo {
	public int orderId;
    public ArrayList<Fill> fills;

}
