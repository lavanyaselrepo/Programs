package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Personal information page (Account settings → Personal information).
 * All locators from MCP get_page_elements on Personal information screen.
 */
public class PersonalInformationPage extends MobileBasePage {

    // ----- Page header -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_title")
    @iOSXCUITFindBy(accessibility = "HWSeparatorHeaderView.titleLabel")
    public WebElement personalInfoPageTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_description")
    @iOSXCUITFindBy(accessibility = "HWSeparatorHeaderView.descriptionLabel")
    public WebElement personalInfoDescription;

    // ----- Full name -----
    // iOS: child StaticTexts inside nameFormView are accessible="false"; XPath reaches them directly.
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_name_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.nameFormView']//XCUIElementTypeStaticText[1]")
    public WebElement fullNameLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_name")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.nameFormView']//XCUIElementTypeStaticText[2]")
    public WebElement fullNameValue;

    // ----- Date of birth -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_dob_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.dobFormView']//XCUIElementTypeStaticText[1]")
    public WebElement dateOfBirthLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_dob")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.dobFormView']//XCUIElementTypeStaticText[2]")
    public WebElement dateOfBirthValue;

    // ----- Email -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_email_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.emailFormView']//XCUIElementTypeStaticText[1]")
    public WebElement emailAddressLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_email")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.emailFormView']//XCUIElementTypeStaticText[2]")
    public WebElement emailAddressValue;

    // ----- Primary phone -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_phone_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.phoneFormView']//XCUIElementTypeStaticText[1]")
    public WebElement primaryPhoneLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_phone")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.phoneFormView']//XCUIElementTypeStaticText[2]")
    public WebElement primaryPhoneValue;

    // ----- Primary address -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_address_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.addressFormView']//XCUIElementTypeStaticText[1]")
    public WebElement primaryAddressLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_address")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.addressFormView']//XCUIElementTypeStaticText[2]")
    public WebElement primaryAddressValue;

    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_address_edit_button")
    @iOSXCUITFindBy(accessibility = "Edit, Primary address")
    public WebElement editAddressButton;

    // ----- Secondary address -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_secondary_address_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.secondaryAddressFormView']//XCUIElementTypeStaticText[1]")
    public WebElement secondaryAddressLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_secondary_address")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.secondaryAddressFormView']//XCUIElementTypeStaticText[2]")
    public WebElement secondaryAddressValue;

    // ----- Emergency contact -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_emergency_contact_label")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.emergencyContactFormView']//XCUIElementTypeStaticText[1]")
    public WebElement emergencyContactLabel;
    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_information_emergency_contact")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='PersonalInformationController.emergencyContactFormView']//XCUIElementTypeStaticText[2]")
    public WebElement emergencyContactValue;

    // ----- Edit Address bottom sheet (inner EditText: pharmacy_street_field is outer wrapper, MCP-verified) -----
    @AndroidFindBy(xpath = "//*[@resource-id='com.walmart.android.debug:id/pharmacy_street_field']//android.widget.EditText[@clickable='true']")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'TextFieldStackView.textField' AND label == 'Street address*, required'")
    public WebElement addressLine1Input;

    @AndroidFindBy(id = "com.walmart.android.debug:id/save_button")
    @iOSXCUITFindBy(accessibility = "AddOrEditAddressViewController.primaryActionView")
    public WebElement saveAddressButton;

    // ----- Unable to verify address bottom sheet (after Save when address cannot be verified). MCP-captured. -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "Continue with entered address")
    public WebElement continueWithEnteredAddressButton;

    /** Snackbar message (MCP-captured after Edit address → Save). TextView inside snackBarContainer. */
    @AndroidFindBy(id = "com.walmart.android.debug:id/message_text")
    @iOSXCUITFindBy(accessibility = "LDSnackbar.label")
    public WebElement addressUpdatedSnackbarMessage;

    public PersonalInformationPage(RemoteWebDriver driver) {
        super(driver);
    }

    public boolean isPersonalInformationPageDisplayed() {
        return isElementDisplayed(personalInfoPageTitle, 10);
    }

    public String getPageTitleText() {
        return getText(personalInfoPageTitle);
    }

    public String getDescriptionText() {
        return getText(personalInfoDescription);
    }

    public String getFullNameLabel() { return getText(fullNameLabel); }
    public String getFullNameValue() { return getText(fullNameValue); }
    public String getDateOfBirthLabel() { return getText(dateOfBirthLabel); }
    public String getDateOfBirthValue() { return getText(dateOfBirthValue); }
    public String getEmailAddressLabel() { return getText(emailAddressLabel); }
    public String getEmailAddressValue() { return getText(emailAddressValue); }
    public String getPrimaryPhoneLabel() { return getText(primaryPhoneLabel); }
    public String getPrimaryPhoneValue() { return getText(primaryPhoneValue); }
    public String getPrimaryAddressLabel() { return getText(primaryAddressLabel); }
    public String getPrimaryAddressValue() { return getText(primaryAddressValue); }
    public String getSecondaryAddressLabel() { return getText(secondaryAddressLabel); }
    public String getSecondaryAddressValue() { return getText(secondaryAddressValue); }
    public String getEmergencyContactLabel() { return getText(emergencyContactLabel); }
    public String getEmergencyContactValue() { return getText(emergencyContactValue); }

    /**
     * Clicks Edit for Primary address (opens Edit Address bottom sheet). MCP-verified.
     */
    public void clickEditAddress() {
        if (isElementDisplayed(editAddressButton, 10)) {
            click(editAddressButton, 5);
            Reporter.log("Clicked Edit (Primary address)");
        } else {
            throw new RuntimeException("Edit address button not found");
        }
    }

    /**
     * Clears and enters new street address, then clicks Save on Edit Address bottom sheet.
     * On iOS, hides the keyboard after typing to dismiss the autocomplete suggestion dropdown
     * before tapping Save.
     */
    public void enterAddressAndSave(String newAddressLine1) {
        if (!isElementDisplayed(addressLine1Input, 10)) {
            throw new RuntimeException("Edit Address form (street field) not visible");
        }
        click(addressLine1Input, 5);
        addressLine1Input.clear();
        sendText(addressLine1Input, newAddressLine1, 5);
        Reporter.log("Entered address: " + newAddressLine1);
    }

    public void clickSaveAddress() {
        click(saveAddressButton, 5);
        Reporter.log("Clicked Save");
    }

    /**
     * Returns true if the "Unable to verify address" bottom sheet is displayed (button "Continue with entered address" is visible).
     */
    public boolean isUnableToVerifyAddressSheetDisplayed() {
        try {
            if (!isElementDisplayed(continueWithEnteredAddressButton, 3)) {
                return false;
            }
            String btnText = getText(continueWithEnteredAddressButton);
            return btnText != null && btnText.contains("Continue with entered address");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clicks "Continue with entered address" on the Unable to verify address bottom sheet. Call after checking {@link #isUnableToVerifyAddressSheetDisplayed()}.
     * If button is not found, logs and returns without throwing.
     */
    public void clickContinueWithEnteredAddress() {
        if (isElementDisplayed(continueWithEnteredAddressButton, 5)) {
            click(continueWithEnteredAddressButton, 5);
            Reporter.log("Clicked Continue with entered address");
        } else {
            Reporter.log("Continue with entered address button not found; skipping click");
        }
    }

    /**
     * Returns the bottom snackbar message text after address save (MCP-captured id=message_text).
     */
    public String getAddressUpdatedSnackbarText() {
        return getText(addressUpdatedSnackbarMessage);
    }
}
