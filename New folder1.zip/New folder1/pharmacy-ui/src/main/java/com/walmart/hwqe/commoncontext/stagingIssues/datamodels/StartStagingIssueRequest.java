package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;
import lombok.*;

@Getter
@Setter
public class StartStagingIssueRequest {

    private String purchaseOrderId;
}
