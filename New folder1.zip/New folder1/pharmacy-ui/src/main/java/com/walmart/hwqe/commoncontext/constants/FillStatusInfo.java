package com.walmart.hwqe.commoncontext.constants;

public enum FillStatusInfo {
    READY_FOR_REFILL,
    READY_FOR_PICKUP,
    RECEIVED,
    DELAYED,
    FILLING,
    PAID,
    CANCELLED
}
