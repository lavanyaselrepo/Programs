package com.walmart.hwqe.rxpde2e.utils;

import com.jayway.jsonpath.JsonPath;
import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.ConnexusAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.WrapperAPIManager;
import com.walmart.hwqe.commons.connexuswrapperapicontext.utils.DBUtils;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.utils.SignGen;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;

import com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels.*;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;


import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
public class RxPDAPIHelper {
    PropertyReader prop = PropertyReaderHelper.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    WrapperAPIManager wrapperAPIManager = new WrapperAPIManager();
    DBUtils dbUtils = new DBUtils();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    AutomationManager am = AutomationManager.getInstance();
    SimpleDateFormat utctimestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    Date date = new Date();
    private SoftAssert softAssert;

    public WebDriverWait webWait;

    public RxPDAPIHelper() {
        // Properties auto-loaded by PropertyReaderHelper static initializer
        softAssert = new SoftAssert();
    }


    public int getRxReadyForPickup(int SiteId, int patientId, int priorityId, int requestTypeCode, int dispenseType, int numRefills, String inputPickupDate, String inputRxExpDate, String ndc_nbr, int prescriberId) {
        AutomationManager am = AutomationManager.getInstance();
        IDatabaseContext cnx = am.getConnexusDB(SiteId);
        ndc_nbr = ndc_nbr.replace("\"", "");
        DataRow drugInfo = dbUtils.getDrugInfo(cnx, ndc_nbr);
        DataRow prescriber = dbUtils.getPrescriberInfo(cnx, prescriberId);
        ServiceResponse resp = wrapperAPIManager.orderToPickup(SiteId, patientId, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, SiteId,
                inputRxExpDate, drugInfo, prescriber);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and dropped till pickup" + resp.getDataResponse());
        String responseBpdy = resp.getDataResponse();
        int rxNumber = JsonPath.read(responseBpdy, "$.rxNbr");
        Reporter.log("RX Number is: " + rxNumber);
        return rxNumber;
    }

    public String getSlotIdBasedOnDateAndTime(String cusEmail, int storeId, String orderType, String date) {
        ServiceRequest requestCreateSlot = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headersCreateSlot = new HashMap<>();
        headersCreateSlot.put("content-type", "application/json");
        headersCreateSlot.put("Accept", "application/json, text/plain, */*");
        headersCreateSlot.put("Connection", "keep-alive");

        requestCreateSlot.setRequestPayload("{\"customerEmailAddress\":\"" + cusEmail + "\",\"storeId\":" + storeId + ",\"orderType\":\"" + orderType + "\",\"date\":\"" + date + "\",\"accessTypes\":[\"DELIVERY_PHARMACY_INSTORE\"]}");
        requestCreateSlot.setUrl(prop.getProperty("astro.getSlotsUrl"));
        requestCreateSlot.setHeaders(headersCreateSlot);

        ServiceResponse responseCreateSlot = am.getRestContext().performPost(requestCreateSlot);
        Assert.assertEquals(responseCreateSlot.getStatusCode(), 200, "Fetch slots endpoint failed");
        Assert.assertEquals(responseCreateSlot.getStatusDesc(), "OK");

        String responseBodyCreateSlot = responseCreateSlot.getDataResponse();

        String slotId = JsonPath.read(responseBodyCreateSlot, "$.astroDetails.slotDetails.payload.slotDays[0].slots[0].slotId");
        Reporter.log("Slot ID: " + slotId);
        return slotId;
    }

    public CreateOrderRequest getCreateOrderRequestPayload(String cusEmail, String storeId, String orderType, String quantity, String paymentType, String slotId, String itemRxId, Map<String, String> groceryItemToQuantMap) {
        List<Item> groceryItemList = new ArrayList<>();
        List<Item> totalItems = new ArrayList<>();
        if (groceryItemToQuantMap != null) {
            for (Map.Entry<String, String> k : groceryItemToQuantMap.entrySet()) {
                Item groceryItem = Item.builder().itemId(k.getKey()).quantity(k.getValue()).build();
                groceryItemList.add(groceryItem);
            }
        }
        if (!groceryItemList.isEmpty()) {
            totalItems.addAll(groceryItemList);
        }
        Item rxItem = Item.builder().isRx(true).itemId(itemRxId).quantity(quantity).build();
        totalItems.add(rxItem);
        FulfillmentGroup fulfillmentGroup = FulfillmentGroup.builder().items(totalItems).orderType(orderType).build();
        return CreateOrderRequest.builder().customerEmailAddress(cusEmail).resolveHolds(true).slot(Slot.builder().slotId(slotId).build()).fulfillmentGroups(Collections.singletonList(fulfillmentGroup)).storeId(storeId).paymentType(paymentType).build();
    }

    public AddCartRequest getAddToCartRequestPayload(String cusEmail, String storeId, String orderType, String quantity, String paymentType, String itemRxId, Map<String, String> groceryItemToQuantMap) {
        List<Item> groceryItemList = new ArrayList<>();
        List<Item> totalItems = new ArrayList<>();
        if (groceryItemToQuantMap != null) {
            for (Map.Entry<String, String> k : groceryItemToQuantMap.entrySet()) {
                Item groceryItem = Item.builder().itemId(k.getKey()).quantity(k.getValue()).build();
                groceryItemList.add(groceryItem);
            }
        }
        if (!groceryItemList.isEmpty()) {
            totalItems.addAll(groceryItemList);
        }
        Item rxItem = Item.builder().isRx(true).itemId(itemRxId).quantity(quantity).build();
        totalItems.add(rxItem);
        FulfillmentGroup fulfillmentGroup = FulfillmentGroup.builder().items(totalItems).orderType(orderType).build();
        return AddCartRequest.builder().customerEmailAddress(cusEmail).resolveHolds(true).terminateBefore("contractCreation").fulfillmentGroups(Collections.singletonList(fulfillmentGroup)).storeId(storeId).paymentType(paymentType).build();
    }

    public String getPatientRxInfo(String custEmail, int rxNumber) throws InterruptedException {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();
        long startTime = System.currentTimeMillis();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        request.setHeaders(headers);

        String url = prop.getProperty("astro.getPatientRxInfoUrl") + custEmail;
        request.setUrl(url);

        List<String> prefIds = new ArrayList<>();
        while (System.currentTimeMillis() - startTime < 350000) {
            ServiceResponse response = am.getRestContext().performGet(request);
            Assert.assertEquals(response.getStatusCode(), 200, "Fetch patient RX info failed with statusCode: " + response.getStatusCode());
            Assert.assertEquals(response.getStatusDesc(), "OK");

            String responseBody = response.getDataResponse();
            Reporter.log(responseBody);

            // Extract itemId
            String jsonPathExpression = String.format("$.astroDetails.customer.fills.readyForPickup[?(@.rxNbr == %d)].pRefId", rxNumber);
            prefIds = JsonPath.read(responseBody, jsonPathExpression);

            if (!prefIds.isEmpty()) break;
            TimeUnit.MILLISECONDS.sleep(30000);
        }
        return prefIds.get(0);
    }

    public String getOrderIdFromCreateOrder(String cusEmail, String storeId, String paymentType, String orderType, String quantity, int rxNumber, Map<String, String> groceryItemQuantMap) throws InterruptedException {
        ServiceResponse response = createOrder(cusEmail, storeId, paymentType, orderType, quantity, rxNumber, groceryItemQuantMap);

        Assert.assertEquals(response.getStatusCode(), 200, response.getDataResponse());
        Assert.assertEquals(response.getStatusDesc(), "OK");
        String responseBody = response.getDataResponse();


        String orderId = JsonPath.read(responseBody, "$.astroDetails.orderSummary.orderInfo.orderId");
        Reporter.log("The order Id is: " + orderId);
        return orderId;
    }

    public ServiceResponse createOrder(String cusEmail, String storeId, String paymentType, String orderType, String quantity, int rxNumber, Map<String, String> groceryItemQuantMap) throws InterruptedException {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Accept", "application/json, text/plain, */*");
        headers.put("Connection", "keep-alive");
        headers.put("payment_version", "smart_allocation");
        headers.put("response_type", "omni");
        headers.put("segment", "oaoh");


        String itemId = getPatientRxInfo(cusEmail, rxNumber);
        LocalDate localDate = LocalDate.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String date = localDate.format(dateTimeFormatter);
        String slotId = getSlotIdBasedOnDateAndTime(cusEmail, Integer.parseInt(storeId), orderType, date);
        CreateOrderRequest createOrderRequest = getCreateOrderRequestPayload(cusEmail, storeId, orderType, quantity, paymentType, slotId, itemId, groceryItemQuantMap);
        Reporter.log(createOrderRequest.toString());
        request.setRequestPayload(createOrderRequest);
        request.setUrl(prop.getProperty("astro.createOrderUrl"));
        request.setHeaders(headers);
        Reporter.log("Request: " + request);
        Reporter.log("this is a post request for creating the order: " + request);
        return am.getRestContext().performPost(request);
    }

    public void moveOrder(String orderType, String status, String orderId) {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        request.setHeaders(headers);

        String url = prop.getProperty("astro.moveOrderUrl") + orderId;
        request.setUrl(url);
        String requestBody = "{\"fulfillmentGroups\":[{\"orderType\":\"" + orderType + "\",\"status\":\"" + status + "\"}]}";
        request.setRequestPayload(requestBody);
        Reporter.log("requestBody: " + requestBody);
        ServiceResponse response = am.getRestContext().performPut(request);
        Reporter.log("response: " + response);
        softAssert.assertEquals(response.getStatusCode(), 200);
        softAssert.assertEquals(response.getStatusDesc(), "OK");
    }

    public String getAddToCartIneligibilityReason(String custEmail, int rxNumber) throws InterruptedException {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();
        long startTime = System.currentTimeMillis();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        request.setHeaders(headers);

        String url = prop.getProperty("astro.getPatientRxInfoUrl") + custEmail;
        request.setUrl(url);
        List<String> ineligibilityReason = new ArrayList<>();

        while (System.currentTimeMillis() - startTime < 330000) {
            ServiceResponse response = am.getRestContext().performGet(request);
            Assert.assertEquals(response.getStatusCode(), 200, "Get Patient RX info API failed");
            Assert.assertEquals(response.getStatusDesc(), "OK");

            String responseBody = response.getDataResponse();
            Reporter.log(responseBody);

            // Extract itemId
            String jsonPathExpression = String.format("$.astroDetails.customer.fills.readyForPickup[?(@.rxNbr == %d)].addToCartEligibility.ineligibilityReason[0].message", rxNumber);
            ineligibilityReason = JsonPath.read(responseBody, jsonPathExpression);
            if (!ineligibilityReason.isEmpty()) break;

            TimeUnit.MILLISECONDS.sleep(30000);
        }
        return ineligibilityReason.get(0);
    }

    public void setSlotCapacity(String requestBody) {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        headers.put("WM_SVC.ENV", prop.getProperty("cart.acc.entity.service.wm.svc.env"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("cart.acc.entity.service.wm.oos.correlation.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("cart.acc.entity.service.wm.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("cart.acc.entity.service.wm.svc.name"));
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("cart.acc.entity.service.wm.sec.key.version"));
        headers.put("tenant-id", "elh9ie");
        headers.put("WM_VERTICAL_ID", "0");
        headers.put("WM_SVC.ENV", "teflon");
        headers.put("Content-Type", "application/json");

        request.setHeaders(headers);

        String url = prop.getProperty("casper.setCapacityUrl");
        request.setUrl(url);
        request.setRequestPayload(requestBody);
        Reporter.log("Request Body for Slot Capacity is: " + requestBody);

        ServiceResponse response = am.getRestContext().performPost(request);
        Reporter.log("Response for slot capacity: " + response);
        softAssert.assertEquals(response.getStatusCode(), 200);
        softAssert.assertEquals(response.getStatusDesc(), "OK");
    }

    public ServiceResponse addToCart(String cusEmail, String storeId, String paymentType, String orderType, String quantity, int rxNumber, Map<String, String> groceryItemQuantMap) throws InterruptedException {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("payment_version", "smart_allocation");
        headers.put("response_type", "omni");
        headers.put("segment", "oaoh");
        headers.put("samedayslot", "true");
        String itemId = getPatientRxInfo(cusEmail, rxNumber);
        AddCartRequest addToCartRequestPayload = getAddToCartRequestPayload(cusEmail, storeId, orderType, quantity, paymentType, itemId, groceryItemQuantMap);
        Reporter.log(addToCartRequestPayload.toString());
        request.setRequestPayload(addToCartRequestPayload);
        request.setUrl(prop.getProperty("astro.createOrderUrl"));
        request.setHeaders(headers);
        Reporter.log("Request: " + request.toString());
        Reporter.log("this is a post request for creating the order: " +  request.toString());
        return am.getRestContext().performPost(request);
    }

    public String filterObject(String responseString, String pharmacyId) {
        JSONObject jsonObject = new JSONObject(responseString);

        JSONObject cartObject = jsonObject.getJSONObject("astroDetails").getJSONObject("cart");
        if (cartObject.has("items")) {
            Object value = cartObject.get("items");
            if (value instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) value;
                System.out.println("JSONArray found: " + jsonArray.toString());
            } else System.out.println("No item present in cart");
        } else return "null";
        JSONArray itemsArray = cartObject.getJSONArray("items");

        JSONObject result = null;
        boolean flag = false;
        for (int i = 0; i < itemsArray.length(); i++) {
            JSONObject item = itemsArray.getJSONObject(i);
            if (item.getJSONObject("pharmacyPrescriptionDetails").getString("pharmacyRefId").equals(pharmacyId)) {
                result = item;
                flag = true;
                break;
            }
        }
        if (flag) return result.toString();
        else return "null";
    }

    public String checkRxIsPresentInCart(String custEmail, int rxNumber,String pharmacyRefId) throws InterruptedException {
        ServiceRequest requestGetCartItems = new ServiceRequest();
        String itemDetails = "";
        AutomationManager am = AutomationManager.getInstance();
        long startTime = System.currentTimeMillis();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        requestGetCartItems.setHeaders(headers);
        String getCartDetails = prop.getProperty("astro.cartUrl");
        getCartDetails = getCartDetails.replace("{{email}}", custEmail);
        requestGetCartItems.setUrl(getCartDetails);

        while (System.currentTimeMillis() - startTime < 600000) {
            ServiceResponse responseGetCartDetails = am.getRestContext().performGet(requestGetCartItems);
            Assert.assertEquals(responseGetCartDetails.getStatusCode(), 200);
            Assert.assertEquals(responseGetCartDetails.getStatusDesc(), "OK");

            String responseBody = responseGetCartDetails.getDataResponse();
            //String pharmacyRefId = getPatientRxInfo(custEmail, rxNumber);
            System.out.println("Pharmacy RefId: " + pharmacyRefId);

            itemDetails = filterObject(responseBody, pharmacyRefId);
            if (itemDetails.equals("null"))
                break;
           TimeUnit.MILLISECONDS.sleep(30000);
        }
        return itemDetails;
    }

    /**
     * Private helper method to get delivery address response
     */
    private String getDeliveryAddressResponse(String custEmail) {
        ServiceRequest requestGetDeliveryAddress = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headers = new HashMap<>();
        String getDeliveryAddressUrl = prop.getProperty("astro.deliveryAddressUrl");
        getDeliveryAddressUrl = getDeliveryAddressUrl.replace("{{email}}", custEmail);
        requestGetDeliveryAddress.setUrl(getDeliveryAddressUrl);
        requestGetDeliveryAddress.setHeaders(headers);

        ServiceResponse responseGetDeliveryAddress = am.getRestContext().performGet(requestGetDeliveryAddress);
        softAssert.assertEquals(responseGetDeliveryAddress.getStatusCode(), 200, "Get Delivery Address API Failed");
        softAssert.assertEquals(responseGetDeliveryAddress.getStatusDesc(), "OK");
        
        return responseGetDeliveryAddress.getDataResponse();
    }

    public String getPreferredDeliveryAddressId(String custEmail) {
        String responseBody = getDeliveryAddressResponse(custEmail);
        String deliveryAddressId = JsonPath.read(responseBody, "$.astroDetails.payload.deliveryAddressInfo[?(@.isPreferred == true)].deliveryAddressId");
        Reporter.log("Preferred Delivery Address ID: " + deliveryAddressId);
        return deliveryAddressId;
    }

    /**
     * Gets delivery address ID by searching for a specific address line one
     * @param custEmail - Customer email address
     * @param targetAddressLineOne - The address line one to search for (e.g., "Rr 3 Box 975")
     * @return deliveryAddressId if found, null otherwise
     */
    public String getDeliveryAddressIdByAddressLineOne(String custEmail, String targetAddressLineOne) {
        String responseBody = getDeliveryAddressResponse(custEmail);
        String jsonPathExpression = String.format("$.astroDetails.payload.deliveryAddressInfo[?(@.deliveryAddress.addressLineOne == '%s')].deliveryAddressId", targetAddressLineOne);
        
        try {
            List<String> deliveryAddressIds = JsonPath.read(responseBody, jsonPathExpression);
            if (!deliveryAddressIds.isEmpty()) {
                String deliveryAddressId = deliveryAddressIds.get(0);
                Reporter.log("Found delivery address ID: " + deliveryAddressId + " for address: " + targetAddressLineOne);
                return deliveryAddressId;
            }
        } catch (Exception e) {
            Reporter.log("Error parsing delivery address response: " + e.getMessage());
        }
        
        Reporter.log("No delivery address found with addressLineOne: " + targetAddressLineOne);
        return null;
    }

    public String updatePreferredDeliveryAddress(String deliveryAddressId, String custEmail, String firstName, String lastName, String addressLine1,
                                                 String phoneNumber, String city, String state, String postalCode, String addressType, boolean isPreferred) {

        ServiceRequest requestUpdateDeliveryAddress = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        headers.put("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
        headers.put("Origin", "http://localhost:3001");
        headers.put("Referer", "http://localhost:3001");
        headers.put("Accept-Language", "en-US,en;q=0.9");
        requestUpdateDeliveryAddress.setRequestPayload("{\"deliveryAddressId\":\"" + deliveryAddressId + "\",\"firstName\":\"" + firstName + "\",\"lastName\":\"" + lastName + "\",\"phoneNumber\":\"" + phoneNumber + "\",\"deliveryAddress\":{\"addressLineOne\":\"" + addressLine1 + "\",\"city\":\"" + city + "\",\"state\":\"" + state + "\",\"postalCode\":\"" + postalCode + "\",\"countryCode\":\"USA\",\"addressType\":\"" + addressType + "\",\"isLoadingDockAvailable\":false,\"isApoFpo\":false,\"isPoBox\":true,\"validationStatus\":\"PB_RECOMMENDED\",\"isLatLongInvalid\":false},\"isPreferred\":" + isPreferred + "}");
        String updateDeliveryAddressUrl = prop.getProperty("astro.deliveryAddressUrl");
        updateDeliveryAddressUrl = updateDeliveryAddressUrl.replace("{{email}}", custEmail);
        requestUpdateDeliveryAddress.setUrl(updateDeliveryAddressUrl);
        requestUpdateDeliveryAddress.setHeaders(headers);

        ServiceResponse responseUpdateDeliveryAddress = am.getRestContext().performPut(requestUpdateDeliveryAddress);
        Assert.assertEquals(responseUpdateDeliveryAddress.getStatusCode(), 200, "Update Preferred Delivery Address API Failed");
        Assert.assertEquals(responseUpdateDeliveryAddress.getStatusDesc(), "OK");

        String responseBodyUpdateDeliveryAddress = responseUpdateDeliveryAddress.getDataResponse();
        return responseBodyUpdateDeliveryAddress;
    }

    public String getOrderMoveStatus(String orderId) throws InterruptedException {
        AutomationManager am = AutomationManager.getInstance();
        ServiceRequest request = new ServiceRequest();
        Thread.sleep(60000);
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        request.setHeaders(headers);

        String url = prop.getProperty("astro.lookupOrderUrl");
        HashMap<String, String> queryParams = new HashMap<>();
        queryParams.put("orderNo", orderId);
        int pollInterval = 60000;
        request.setUrl(url, queryParams);
        int count = 0;
        do {
            ServiceResponse response = am.getRestContext().performGet(request);
            Assert.assertEquals(response.getStatusCode(), 200);
            Assert.assertEquals(response.getStatusDesc(), "OK");
            String responseBody = response.getDataResponse();
            System.out.println(responseBody);
            List<Object> fullFillments = JsonPath.read(responseBody, "$.astroDetails[0].fulfillments");
            boolean allGreenFulfillmentType2;
            boolean anyRedFulfillmentType2;
            if (fullFillments.size() > 1) {
                List<Object> eventsList2 = JsonPath.read(responseBody, "$.astroDetails[0].fulfillments[1].events");
                JSONArray eventsForFulfillmentType2 = new JSONArray(eventsList2);
                allGreenFulfillmentType2 = checkAllEventsGreen(eventsForFulfillmentType2);
                anyRedFulfillmentType2 = checkAnyEventRed(eventsForFulfillmentType2);
                if (anyRedFulfillmentType2) {
                    return extractErrorMessage(eventsForFulfillmentType2);
                }
            } else {
                allGreenFulfillmentType2 = true;
            }
            List<Object> eventsList = JsonPath.read(responseBody, "$.astroDetails[0].fulfillments[0].events");

            JSONArray eventsForFulfillmentType1 = new JSONArray(eventsList);

            boolean allGreenFulfillmentType1 = checkAllEventsGreen(eventsForFulfillmentType1);
            boolean anyRedFulfillmentType1 = checkAnyEventRed(eventsForFulfillmentType1);

            if (allGreenFulfillmentType1 && allGreenFulfillmentType2) {
                System.out.println("Passed");
                break;
            } else if (anyRedFulfillmentType1) {
                return extractErrorMessage(eventsForFulfillmentType1);
            }

            Thread.sleep(pollInterval);
            if (count > 5) {
                return "The events are not getting updated, the order is not moving, the status is gray for all";
            }
            count += 1;
        } while (true);
        return "All events are green, the order has been delivered successfully";
    }

    private boolean checkAllEventsGreen(JSONArray eventsArray) {
        for (int i = 0; i < eventsArray.length(); i++) {
            JSONObject event = eventsArray.getJSONObject(i);
            String color = event.getString("color");
            if (!"green".equalsIgnoreCase(color)) {
                return false;
            }
        }
        return true;
    }

    private boolean checkAnyEventRed(JSONArray eventsArray) {
        for (int i = 0; i < eventsArray.length(); i++) {
            JSONObject event = eventsArray.getJSONObject(i);
            String color = event.getString("color");
            if ("red".equalsIgnoreCase(color)) {
                return true;
            }
        }
        return false;
    }

    private String extractErrorMessage(JSONArray eventsArray) {
        for (int i = 0; i < eventsArray.length(); i++) {
            JSONObject event = eventsArray.getJSONObject(i);
            String color = event.getString("color");
            if ("red".equalsIgnoreCase(color)) {
                // Extract error details
                JSONArray eventErrors = event.getJSONArray("eventErrors");
                if (!eventErrors.isEmpty()) {
                    JSONObject firstError = eventErrors.getJSONObject(0);
                    return firstError.getString("description");
                } else {
                    return "Unknown error";
                }
            }
        }
        return "No red events found";
    }

    public String getCartID(String custEmail) throws InterruptedException {
        ServiceRequest requestGetCartItems = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        requestGetCartItems.setHeaders(headers);
        String getCartDetails = prop.getProperty("astro.cartUrl");
        getCartDetails = getCartDetails.replace("{{email}}", custEmail);
        requestGetCartItems.setUrl(getCartDetails);

        ServiceResponse responseGetCartDetails = am.getRestContext().performGet(requestGetCartItems);
        Assert.assertEquals(responseGetCartDetails.getStatusCode(), 200);
        Assert.assertEquals(responseGetCartDetails.getStatusDesc(), "OK");

        String responseBodyGetCart = responseGetCartDetails.getDataResponse();
        String cartId = JsonPath.read(responseBodyGetCart, "$.astroDetails.cart.cart.id");
        Reporter.log("Cart ID: " + cartId);
        return cartId;
    }

    public String updateCart(int rxNumber, String custEmail, String cartId, String deliveryAddressId, String city, String state, String postalCode, String storeId, float latitude, float longitude, long lastModifiedDate) throws InterruptedException {
        ServiceRequest requestGetCartItems = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();
        String userId = digitalPharmacyAPIManager.getCidFromEmail(custEmail);
        String itemDetail = "";

        HashMap<String, String> headers = new HashMap<>();
        SignGen generateSign = new SignGen();
        HashMap<String, String> authSign = generateSign.generateTimeBasedSignForCart(prop.getProperty("cart.acc.entity.service.wm.consumer.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("cart.acc.entity.service.wm.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("cart.acc.entity.service.wm.svc.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("cart.acc.entity.service.wm.svc.env"));
        headers.put("WM_SVC.VERSION", prop.getProperty("cart.acc.entity.service.wm.svc.version"));
        headers.put("Content-Type", "application/json");
        headers.put("x-o-segment", "oaoh");
        headers.put("WM_IFX.CLIENT_TYPE", "Java");
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("cart.acc.entity.service.wm.sec.key.version"));
        headers.put("WM_CONSUMER.IP", prop.getProperty("cart.acc.entity.service.wm.consumer.ip"));
        headers.put("WM_LOCALE_ID", "eng_USA");
        headers.put("tenant-id", "elh9ie");
        headers.put("WM_VERTICAL_ID", "0");
        headers.put("utype", "beta");
        headers.put("acc_grouping_enabled", "true");
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("cart.acc.entity.service.wm.oos.correlation.id"));
        headers.put("WM_CONSUMER.USER_TYPE", "CUSTOMER");
        headers.put("WM_CONSUMER.USER_ID", userId);
        headers.put("EXPO_EXPERIMENT_ID", "dmiH0");
        headers.put("WM_CONSUMER.INTIMESTAMP", authSign.get("Intimestamp"));
        headers.put("WM_SEC.AUTH_SIGNATURE", authSign.get("Signature"));
        requestGetCartItems.setHeaders(headers);
        System.out.println("Headers - " + headers);
        String updateCartUrl = prop.getProperty("astro.updateCart") + "/" + cartId;
        System.out.println("Url - " + updateCartUrl);
        requestGetCartItems.setUrl(updateCartUrl);

        String requestPayload = "{\"pickupStore\":{\"city\":\"" + city + "\",\"stateOrProvinceCode\":\"" + state + "\",\"countryCode\":\"USA\",\"postalCode\":\"" + postalCode + "\",\"storeId\":\"" + storeId + "\"},\"shipping\":{\"addressId\":\"" + deliveryAddressId + "\",\"lastModifiedDate\":" + lastModifiedDate + ",\"latitude\":" + latitude + ",\"longitude\":" + longitude + "},\"deliveryStore\":{\"city\":\"" + city + "\",\"stateOrProvinceCode\":\"" + state + "\",\"countryCode\":\"USA\",\"postalCode\":\"" + postalCode + "\",\"storeId\":\"" + storeId + "\"},\"fulfillmentOption\":\"DELIVERY\",\"assortmentIntent\":\"DELIVERY\"}";
        requestGetCartItems.setRequestPayload(requestPayload);

        Reporter.log("Update Cart Request Payload - " + requestPayload);
        ServiceResponse responseGetCartDetails = am.getRestContext().performPut(requestGetCartItems);
        Assert.assertEquals(responseGetCartDetails.getStatusCode(), 200, "Update Cart API Failed");
        Assert.assertEquals(responseGetCartDetails.getStatusDesc(), "OK");

        String responseBody = responseGetCartDetails.getDataResponse();
        Reporter.log("Update Cart Response - " + responseBody);
        String pharmacyRefId = getPatientRxInfo(custEmail, rxNumber);
        System.out.println("Pharmacy RefId: " + pharmacyRefId);

        JSONObject jsonObject = new JSONObject(responseBody);
        JSONArray itemsArray = jsonObject.getJSONArray("items");
        JSONObject result = null;
        for (int i = 0; i < itemsArray.length(); i++) {
            JSONObject item = itemsArray.getJSONObject(i);
            if (item.getJSONObject("pharmacyPrescriptionDetails").getString("pharmacyRefId").equals(pharmacyRefId)) {
                result = item;
                break;
            }
        }
        itemDetail = result.toString();
        return itemDetail;
    }

    public String addDeliveryPreference(String custEmail, String firstName, String lastName, String addressLine1,
                                                 String phoneNumber, String city, String state, String postalCode) {

        ServiceRequest requestAddDeliveryAddress = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        requestAddDeliveryAddress.setRequestPayload("{\"firstName\":\"" + firstName + "\",\"lastName\":\"" + lastName + "\",\"emailAddress\":\"" + custEmail + "\",\"phoneNumber\":\"" + phoneNumber + "\",\"postalAddress\":{\"address\":\"" + addressLine1 + "\",\"city\":\"" + city + "\",\"country\":\"USA\",\"postalCode\":\"" + postalCode + "\",\"state\":\"" + state + "\"}}");
        String addDeliveryAddressUrl = prop.getProperty("astro.deliveryPreferences");
        requestAddDeliveryAddress.setUrl(addDeliveryAddressUrl);
        requestAddDeliveryAddress.setHeaders(headers);

        ServiceResponse responseAddDeliveryAddress = am.getRestContext().performPost(requestAddDeliveryAddress);
        Assert.assertEquals(responseAddDeliveryAddress.getStatusCode(), 200, "Add Delivery Preferences API Failed");
        Assert.assertEquals(responseAddDeliveryAddress.getStatusDesc(), "OK");

        String responseBodyAddDeliveryAddress = responseAddDeliveryAddress.getDataResponse();
        return responseBodyAddDeliveryAddress;
    }

    public String clearCartAPI(String custEmail) throws InterruptedException {
        ServiceRequest requestGetCartItems = new ServiceRequest();
        AutomationManager am = AutomationManager.getInstance();

        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        headers.put("segment", "oaoh");
        headers.put("response_type", "omni");
        requestGetCartItems.setHeaders(headers);
        String getCartDetails = prop.getProperty("astro.clearCartAPI");
        getCartDetails = getCartDetails.replace("{{email}}", custEmail);
        requestGetCartItems.setUrl(getCartDetails);

        ServiceResponse responseGetCartDetails = am.getRestContext().performDelete(requestGetCartItems);
        softAssert.assertEquals(responseGetCartDetails.getStatusCode(), 200);
        softAssert.assertEquals(responseGetCartDetails.getStatusDesc(), "OK");

        int retryCount = 3;
        while(responseGetCartDetails.getStatusCode()!=200 && retryCount>0) {
            Reporter.log("Retrying to clear cart, remaining attempts: " + retryCount);
            responseGetCartDetails = am.getRestContext().performDelete(requestGetCartItems);
            softAssert.assertEquals(responseGetCartDetails.getStatusCode(), 200, "Clear Cart API Failed");
            softAssert.assertEquals(responseGetCartDetails.getStatusDesc(), "OK");
            retryCount--;
        }

        String responseBodyGetCart = responseGetCartDetails.getDataResponse();
        String cartId = JsonPath.read(responseBodyGetCart, "$.astroDetails.cart.id");
        Reporter.log("Cart ID: " + cartId);
        return cartId;
    }

}
