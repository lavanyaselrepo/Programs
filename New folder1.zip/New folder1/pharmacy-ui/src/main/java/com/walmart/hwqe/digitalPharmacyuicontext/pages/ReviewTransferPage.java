package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class ReviewTransferPage extends MobileBasePage {

    public ReviewTransferPage(RemoteWebDriver driver) {
        super(driver);
    }

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_prescription_name")
    public WebElement transferPrescriptionDetails;

    @AndroidFindBy(id = "com.walmart.android.debug:id/toggle")
    @iOSXCUITFindBy(accessibility = "TransferStartFillingToggleView.fillRxToggleButton")
    @FindBy(id = "react-aria-20")
    public WebElement refillTransferredPrescriptionsToggle;

    @AndroidFindBy(xpath = "//*[contains(@text, 'Submit request')]")
    @iOSXCUITFindBy(accessibility = "TransferReviewController.LinkActionView.cta")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement submitRequestButton;


    public void allowTransferredRxTobeRefilled(){

        refillTransferredPrescriptionsToggle.click();
    }

    public void clickSubmitRequestButton(){

        submitRequestButton.click();
    }
}
