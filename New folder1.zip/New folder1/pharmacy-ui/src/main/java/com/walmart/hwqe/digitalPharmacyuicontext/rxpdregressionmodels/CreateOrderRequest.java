package com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

@Data
@Builder
@ToString
@EqualsAndHashCode
public class CreateOrderRequest {
    private String customerEmailAddress;
    private String storeId;
    private String paymentType;
    private List<FulfillmentGroup> fulfillmentGroups;
    private boolean resolveHolds;
    private Slot slot;
    private String terminateBefore;
}
