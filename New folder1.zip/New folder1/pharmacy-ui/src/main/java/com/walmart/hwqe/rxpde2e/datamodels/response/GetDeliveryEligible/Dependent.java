package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class Dependent {
    public Name name;
    public Fills fills;
    public String customerId;
    public String dependentType;
}
