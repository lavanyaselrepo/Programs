package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;

public class RxReadyForRefillCardPage extends FillStatusTrackerCardPage {

    public RxReadyForRefillCardPage(RemoteWebDriver driver) {
        super(driver);
    }

    @AndroidFindBy(id = "com.walmart.android.debug:id/card_heading")
    @iOSXCUITFindBy(accessibility = "RefillsDueCardView.containerView")
    @FindBy(id = "heading-READY")
    WebElement rxReadyForFillParentCard;

    @AndroidFindBy(id = "com.walmart.android.debug:id/card_heading")
    @iOSXCUITFindBy(accessibility = "FillSectionHeaderView.headerLabel")
    @FindBy(id = "heading-READY")
    WebElement fillStatusCardHeaderText;

    @iOSXCUITFindBy(accessibility = "FillSectionHeaderView.subheaderLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/card_subheading")
    @FindBy(id = "sub-heading-READY")
    WebElement fillStatusCardSubHeaderText;

    @iOSXCUITFindBy(accessibility = "PharmacyImageWithLabelView.label")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    @FindBy(xpath = "//*[contains(@id,'patient-name-prescription-reminders')]")
    WebElement patientName;

    @iOSXCUITFindBy(accessibility = "PharmacyImageWithLabelView.label")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    @FindBy(xpath = "//*[contains(@id,'patient-name-prescription-reminders')]")
    List<WebElement> patientNames;

    @AndroidFindBy(id = "com.walmart.android.debug:id/drug_name")
    @iOSXCUITFindBy(accessibility = "RefillDuePrescriptionInfoView.titleLabel")
    @FindBy(xpath = "//*[contains(@id,'formatted-drug-name-prescription-reminders')]")
    WebElement rxName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/drug_name")
    @iOSXCUITFindBy(accessibility = "RefillDuePrescriptionInfoView.titleLabel")
    @FindBy(xpath = "//*[contains(@id,'formatted-drug-name-prescription-reminders')]")
    List<WebElement> rxNames;

    @AndroidFindBy(id = "com.walmart.android.debug:id/price")
    @iOSXCUITFindBy(xpath = "//*[@name='RefillsDueCardView.containerView']//*[@name='RefillDuePrescriptionInfoView.subtitleLabel']")
    @FindBy(xpath = "//*[contains(@id,'estimated-price-prescription-reminders')]")
    WebElement rxEstimatedPrice;

    @AndroidFindBy(id = "com.walmart.android.debug:id/item_details_chevron")
    @iOSXCUITFindBy(xpath = "//*[@name='RefillsDueCardView.containerView']//*[@name='RefillDuePrescriptionInfoView.imageView']")
    @FindBy(xpath = "//*[contains(@id,'chevron-icon-prescription-reminders')]")
    WebElement fillDetailsArrowCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescriptions_count")
    @iOSXCUITFindBy(xpath = "//*[@name='RefillsDueCardView.containerView']//*[@name='PatientFillsCountView.fillsLabel']")
    @FindBy(id = "prescription-label-prescription-reminders-1")
    WebElement prescriptionsCount;

    @AndroidFindBy(id = "com.walmart.android.debug:id/refill_button_dismiss")
    @iOSXCUITFindBy(accessibility = "Dismiss")
    @FindBy(id = "dismiss-prescription-reminders")
    WebElement dismissButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/refill_button_primary")
    @iOSXCUITFindBy(accessibility = "Select prescriptions")
    @FindBy(id = "refill-button-prescription-reminders")
    WebElement selectPrescriptionsButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/refill_button_primary")
    @iOSXCUITFindBy(accessibility = "Select prescription")
    @FindBy(id = "refill-button-prescription-reminders")
    WebElement selectPrescriptionButton;

    @FindBy(id = "refill-button-prescription-reminders")
    WebElement refillNowButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    @iOSXCUITFindBy(accessibility = "pet")
    @FindBy(id = "refill-button-prescription-reminders")
    WebElement petIcon;

    @FindBy(xpath = "//*[contains(@id,'user-icon-prescription-reminders')]")
    WebElement humanIcon;

    @AndroidFindBy(id = "com.walmart.android.debug:id/show_more_or_less_button")
    @iOSXCUITFindBy(xpath = "//*[@name='RefillsDueCardView.containerView']//*[@name='RefillsDueCustomerPrescriptionsView.expandCollapseButton']")
    @FindBy(xpath = "//*[contains(@id,'show-hide-button-prescription-reminders')]")
    WebElement showAllItemsButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/show_more_or_less_button")
    @iOSXCUITFindBy(xpath = "//*[@name='RefillsDueCardView.containerView']//*[@name='RefillsDueCustomerPrescriptionsView.expandCollapseButton']")
    @FindBy(xpath = "//*[contains(@id,'show-hide-button-prescription-reminders')]")
    WebElement hideItemsButton;

    public String getFillStatusCardHeaderText() {
        return getText(fillStatusCardHeaderText);
    }

    public String getPrescriptionsCount() {
        return getText(prescriptionsCount);
    }

    public void clickDismissButton() {
        click(dismissButton);
    }

    public void clickSelectPrescriptionsButton() {
        click(selectPrescriptionsButton);
    }

    public void clickSelectSinglePrescriptionButton() {
        click(selectPrescriptionButton);
    }

    public void clickShowAllItemsButton() {
        click(showAllItemsButton);
    }

    public void clickHideItemButton() {
        click(hideItemsButton);
    }

    public String getNumberOfItemsToHide() {
        return getText(hideItemsButton);
    }

    public List<String> getRxNamesForMultiRx() {
        List<String> rxNameList = new ArrayList<>();
        for (WebElement element : rxNames) {
            rxNameList.add(getText(element).replaceAll("\\s", "").toLowerCase());
        }
        return rxNameList;
    }

    public List<String> getSelfAndDependantPatientNames() {

        List<String> patientNames = new ArrayList<>();

        List<WebElement> elements = appDriver.findElements(By.xpath("//*[@name='RefillsDueCardView.containerView']//*[@name='RefillDuePrescriptionInfoView.titleLabel']"));
        for (WebElement element : elements) {
            patientNames.add(getText(element));
        }
        return patientNames;
    }

    public boolean isRxReadyForFillParentCardVisible() {
        return isElementDisplayed(fillStatusCardSubHeaderText);
    }

    public boolean isFillStatusCardSubHeaderTextVisible() {
        return isElementDisplayed(fillStatusCardSubHeaderText);
    }

    public String getFillStatusCardSubHeaderText() {
        return getText(fillStatusCardSubHeaderText);
    }

    public void clickFillDetailsArrowCTA() {
        click(fillDetailsArrowCTA);
    }

    public String getRxName() {
        return getText(rxName);
    }

    public String getPatientNameOnFillTrackerCard() {
        return getText(patientName);
    }

    public String getRxNameOnFillTrackerCard() {
        return getText(rxName);
    }

    public String getRxEstimatedPrice() {
        return getText(rxEstimatedPrice);
    }

    public boolean isRefillNowButtonVisible() {
        return isElementDisplayed(refillNowButton);
    }

    public void clickRefillNowButton() {
        click(refillNowButton);
    }

    public boolean isDismissButtonVisible() {
        return isElementDisplayed(dismissButton);
    }

    public boolean isPetIconVisible() {
        return isElementDisplayed(petIcon);
    }

    public boolean isHumanIconVisible() {
        return isElementDisplayed(humanIcon);
    }

    public boolean isFillDetailsArrowCTAVisible(){
        return isElementDisplayed(fillDetailsArrowCTA);
    }

    public List<String> getRxNamesForMultiRxWeb() {
        List<String> rxNamesList = new ArrayList<>();
        for (WebElement element : rxNames) {
            rxNamesList.add(getText(element));
        }
        return rxNamesList;
    }
    public List<String> getPatientNamesForMultiRxWeb() {
        List<String> patientsList = new ArrayList<>();
        for (WebElement element : patientNames) {
            patientsList.add(getText(element));
        }
        return patientsList;
    }
}
