package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class ConnectMyAccountSuccessScreen extends MobileBasePage {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Done']")
    public WebElement accountConnectedDoneButtonSecondary;
    @AndroidFindBy(id = "com.walmart.android.debug:id/fragment_module_pharmacy_success_done")
    @iOSXCUITFindBy(accessibility = "SMSIDConfirmationViewController.primaryAction")
    @FindBy(xpath = "//button[text()='Done']")
    public WebElement accountConnectedDonePrimaryButton;
    @AndroidFindBy(id = "com.walmart.android.debug:id/banner_title")
    @iOSXCUITFindBy(accessibility = "PharmacyNudgeCardView.titleLabel")
    @FindBy(xpath = "//h3[contains(text(),'Review & update')]")
    public WebElement insCardTitleHeader;
    @AndroidFindBy(id = "com.walmart.android.debug:id/banner_desc")
    @iOSXCUITFindBy(accessibility = "PharmacyNudgeCardView.descriptionLabel")
    @FindBy(xpath = "//p[contains(text(),'prescription insurance')]")
    public WebElement insCardDescription;
    @AndroidFindBy(id = "com.walmart.android.debug:id/banner_button")
    @iOSXCUITFindBy(accessibility = "Manage insurance")
    @FindBy(xpath = "//button[text()='Manage my insurance']")
    public WebElement manageInsuranceCTA;

    public ConnectMyAccountSuccessScreen(RemoteWebDriver driver){super(driver);}
    public void clickAccountConnectedDoneButtonSecondary(){click(accountConnectedDoneButtonSecondary);}
    public void clickAccountConnectedDonePrimaryButton(){click(accountConnectedDonePrimaryButton);}
    public String getInsCardTitleHeader(){return getText(insCardTitleHeader);}
    public String getInsCardDescription(){return getText(insCardDescription);}
    public void clickManageInsuranceCTA(){click(manageInsuranceCTA);}
}