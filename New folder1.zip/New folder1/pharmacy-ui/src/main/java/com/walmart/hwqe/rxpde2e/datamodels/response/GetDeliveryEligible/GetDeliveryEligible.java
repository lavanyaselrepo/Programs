package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class GetDeliveryEligible {

    public String astroStatus;
    public String astroDescription;
    public AstroDetails astroDetails;
    public Object astroInfo;
}
