package com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class StoreDetailsPage extends MobileBasePage {

    public StoreDetailsPage(RemoteWebDriver driver) {

        super(driver);
    }

    @FindBy(id = "store-display-name")
    WebElement storeHeaderText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_display_name")
    @FindBy(id = "store-display-name")
    WebElement storeName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_address")
    @FindBy(id = "store-address")
    WebElement storeAddress;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_current_open_time")
    @FindBy(id = "store-open-status")
    WebElement storeTimings;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_directions")
    @FindBy(id = "store-directions")
    WebElement getDirectionsLink;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_phone_number")
    @FindBy(id = "store-phone")
    WebElement storePhoneNo;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_page_mapview")
    @FindBy(id = "static-google-map")
    WebElement googleMap;

    public String pharmacyLocationTxt = "Pharmacy location";
    public String getDirectionsTxt = "Get directions";

    public String getStoreHeaderTxt(){return getText(storeHeaderText);}
    public String getStoreName(){return getText(storeName);}
    public String getStoreAddress(){return getText(storeAddress);}
    public String getStoreTimings(){return getText(storeTimings);}
    public String getDirectionsLinkTxt(){return getText(getDirectionsLink);}
    public void clickGetDirectionsLink(){click(getDirectionsLink);}
    public void clickStorePhoneNo(){click(storePhoneNo);}
    public String getStorePhoneNo(){return getText(storePhoneNo);}
    public void clickGoogleMap(){click(googleMap);}


}
