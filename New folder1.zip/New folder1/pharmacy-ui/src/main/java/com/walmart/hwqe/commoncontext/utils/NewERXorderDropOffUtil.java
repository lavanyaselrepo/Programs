package com.walmart.hwqe.commoncontext.utils;




import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.DataRow;
import com.walmart.hwqe.commons.datacontext.DataTable;
import com.walmart.hwqe.commons.interfaces.IDatabaseContext;

import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import org.apache.commons.io.FileUtils;
import org.assertj.core.util.DateUtil;
import org.testng.Assert;
import org.testng.Reporter;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

public class NewERXorderDropOffUtil {
	AutomationManager am = AutomationManager.getInstance();
	PropertyReader prop = PropertyReaderHelper.getInstance();
	HashMap<String, String> headers = new HashMap<>();
	ServiceRequest req = new ServiceRequest();
	ServiceResponse resp;


  public void performProcessERx() throws ParserConfigurationException, SAXException, IOException, SQLException {	
	  				
	  File xmlData;	
	  String messageId, inputPayload, ndc, drugName;
	  int rxResponseId,fillCount,index;
	  List<Integer> respIds = new ArrayList<Integer>();
	  Random random_method = new Random();
	  
	  String[] cfNdcList = prop.getProperty("cf.E2E.cfNdcList").toString().split(",");
	  String[] nonCfNdc = prop.getProperty("cf.E2E.nonCfNdc").toString().split(",");
	  
	  String[] patient_storelist = prop.getProperty("cf.E2E.patient_storelist").toString().split(",");	 
	  Reporter.log("Patient_Store List :" +prop.getProperty("cf.E2E.patient_storelist").toString());
	  	  
		for(int i=0; i<patient_storelist.length; i++) {
			String[] arrOfStr = patient_storelist[i].split("_");
			int patientId = Integer.parseInt(arrOfStr[0]);
			String storeNbr = arrOfStr[1];
			fillCount = 0;
		
		//connect to store DB
		IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(storeNbr));
		
		//get patient details
		DataRow patientInfo = getPatientInfo(cnx, patientId);
		
				
		Reporter.log("****CASE-1**** : Single Rx, CF eligible Order for "+storeNbr);
				
		//get xml file to generate input payload
		xmlData = new File("src//test//resources//TestData//FomData//ERXpayload_CF1.xml");
//		xmlData= new File(prop.getProperty("app.workingfolder_path")+"ERXpayload_CF1.xml");
		
		//get drug details
		index = random_method.nextInt(cfNdcList.length);
		ndc = cfNdcList[index];
		drugName = getDrugName(cnx, ndc);
		
		Reporter.log("NDC :"+ndc+" Drug name :"+drugName);
						
		//update the xml with required storeNbr, Date-time and a unique messageId
		messageId = UUID.randomUUID().toString().substring(0, 35);
		inputPayload = updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);
		
		//drop ERX order and move it to Filling
		rxResponseId = dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
		respIds.add(rxResponseId);
		moveOrderToFilling(cnx, patientId, respIds);
		respIds.clear();
		fillCount = fillCount+1;
		
		//introduce wait time - without this order from case 1 will be batched with next order
		am.performSleep(150);
				
		Reporter.log("****CASE-2**** : Multi Rx, CF eligible Order for "+storeNbr);
		
		//get drug details
		index = random_method.nextInt(cfNdcList.length);
		ndc = cfNdcList[index];
		drugName = getDrugName(cnx, ndc);
		
		Reporter.log("NDC :"+ndc+" Drug name :"+drugName);
		
		xmlData = new File("src//test//resources//TestData//FomData//ERXpayload_CF1.xml");
//		xmlData= new File(prop.getProperty("app.workingfolder_path")+"ERXpayload_CF1.xml");
		messageId = UUID.randomUUID().toString().substring(0, 35);
		inputPayload = updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);		
		rxResponseId = dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
		respIds.add(rxResponseId);
		
		//get drug details
		index = random_method.nextInt(cfNdcList.length);
		ndc = cfNdcList[index];
		drugName = getDrugName(cnx, ndc);
		
		Reporter.log("NDC :"+ndc+" Drug name :"+drugName);
		
		xmlData = new File("src//test//resources//TestData//FomData//ERXpayload_CF1.xml");
//		xmlData= new File(prop.getProperty("app.workingfolder_path")+"ERXpayload_CF2.xml");
		messageId = UUID.randomUUID().toString().substring(0, 35);
		inputPayload = updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);		
		rxResponseId = dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
		respIds.add(rxResponseId);	
		moveOrderToFilling(cnx, patientId, respIds);		
		respIds.clear();
		fillCount = fillCount+2;
		
		//introduce wait time - without this order from case 2 will be batched with next order
//		am.performSleep(150);
//		
//		Reporter.log("****CASE-3**** : Multi Rx, partially CF eligible Order for "+storeNbr);
//		
////		xmlData = new File("src\\test\\resources\\ERXpayload_CF1.xml");
//		xmlData= new File(prop.getProperty("app.workingfolder_path")+"ERXpayload_CF1.xml");
//		messageId = UUID.randomUUID().toString().substring(0, 35);
//		inputPayload = updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);		
//		rxResponseId = dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
//		respIds.add(rxResponseId);
//		
////		xmlData = new File("src\\test\\resources\\ERXpayload_nonCF.xml");
//		xmlData= new File(prop.getProperty("app.workingfolder_path")+"ERXpayload_nonCF.xml");
//		messageId = UUID.randomUUID().toString().substring(0, 35);
//		inputPayload = updateXML(xmlData, storeNbr, messageId, patientInfo, ndc, drugName);		
//		rxResponseId = dropERX(inputPayload, storeNbr, patientId, messageId, cnx);
//		respIds.add(rxResponseId);	
//		moveOrderToFilling(cnx, patientId, respIds);	
//		respIds.clear();
//		fillCount = fillCount+1;
		
		Reporter.log("***** Number of CF eligible fills dropped for "+storeNbr+ " is "+fillCount+ " *****");
		
		}	
  
  }
 
public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
		String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" + 
				"where patient_id = "+patientId+";";
		DataTable dt = cnx.getDataTable(getPatientInfo);
		Assert.assertEquals(dt.getRowCount(), 1);
		DataRow row = dt.getDataRows().get(0);
		return row;
	}
  
public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName) 
		throws ParserConfigurationException, SAXException, IOException {
	   
      String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
      fileContext = fileContext.replaceAll("storeNbr", storeNbr);
      fileContext = fileContext.replaceAll("messageId", messageId);
      String currentTime = getCurrentTime();
      fileContext = fileContext.replaceAll("sentTime", currentTime);
      fileContext = fileContext.replaceAll("writtenDate", currentTime);      
      fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
      fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
      fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
      fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString()); 
      fileContext = fileContext.replaceAll("drugName", drugName);
      fileContext = fileContext.replaceAll("ndc", ndc);
//      FileUtils.write(xmlData, fileContext, StandardCharsets.UTF_8);
      return fileContext;      
  }
 
public int dropERX(String inputPayload,String storeNbr, int patientId, String messageId, IDatabaseContext cnx) throws SQLException {	       
	       		
			//drop ERX via POST
			headers.put("content-type", "application/xml");
			headers.put("User-Agent", "PostmanRuntime/7.28.4");
			headers.put("Accept", "*/*");
			headers.put("Accept-Encoding", "gzip, deflate, br");	
			headers.put("Connection", "keep-alive");		
			req.setHeaders(headers);
			req.setUrl("https://rxInt-PharmacySSerxv2inboundreq-qa-edc.wal-mart.com/services/ProcessERx");
			req.setRequestPayload(inputPayload);		
			resp= am.getRestContext().performPost(req);
			
			//verify POST request is successful
			Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
			Reporter.log("ERX order posting successful for patientId = "+patientId+ " in store # "+storeNbr+
			". The resp message_id is "+messageId);
			
			// verify ERX order is created --> response_stat_code = 26005 in raw_eltnc_rx_resp table
			am.performSleep(30);
			int rxResponseId = verifyOrderCreation(cnx, messageId);	
			
			return rxResponseId;
			
} 

public int moveOrderToFilling(IDatabaseContext cnx, int patientId, List<Integer> respIds) {
	         
	// verify ERX is in 4 point-->  next_work_que_code = 5 in rx_order_detail table 
	am.performSleep(15);
	int orderId = verifyOrderWorkQueue(cnx, respIds);
				
	// update est_pickup_ts to next day 1 pm and next_work_que_code to 4  in rx_order_detail table
	updatePickUpTimeandNxtWorkQueue(cnx, orderId);	
	return orderId;
}

public String getCurrentTime() {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	String Ts = sdf.format(timestamp);
	return Ts;
}

public int verifyOrderCreation(IDatabaseContext cnx, String messageId) throws SQLException {

	String query = "select response_stat_code, rx_response_id from rx21c:informix.raw_eltnc_rx_resp where \n" +
	"resp_message_id = '"+messageId+"';";
	DataTable dt = cnx.getDataTable(query);
	DataRow row = dt.getDataRows().get(0);
	int respStatCode = (short)row.getValue("response_stat_code");
	Assert.assertEquals(respStatCode, 26005, "ERX order processing failed");
	int rxRespId=  row.getValue("rx_response_id");
	
	return rxRespId;	
}

public int verifyOrderWorkQueue(IDatabaseContext cnx, List<Integer> respIds) {
	
	int orderId = 0, fillId, rxId;
	
	String list = "";
	for(int i=0;i< respIds.size();i++){
	    list = list + respIds.get(i) + ",";
	    }
	list = list.substring(0, list.length()-1);
	
	String getWorkQueueQuery = "select next_work_que_code, order_id, rx_fill_id, rx_id from rx21c:informix.rx_order_detail \n" + 
			"where rx_response_id in ("+list+");";
	
	DataTable dt = cnx.getDataTable(getWorkQueueQuery);
	Assert.assertEquals(dt.getRowCount(), respIds.size());
	
	for (int j=0;j<respIds.size();j++) {
		
		DataRow row = dt.getDataRows().get(j);
		
		//get orderId and fillId
		orderId =  row.getValue("order_id");
		fillId =  row.getValue("rx_fill_id");
		rxId = row.getValue("rx_id");
		
		// verify workQueue = 5 (4 point)
		Assert.assertEquals((short)row.getValue("next_work_que_code"), 5, "Fill_id "+fillId+" not in 4 point queue ");
			
		//update rx_fill_txn to mimic CASH claim submission
		String updateTxnStatusCode = "update rx_fill_txn set status_code = 32673 where rx_fill_id = "+fillId+";";
		cnx.executeUpdateQuery(updateTxnStatusCode);
		
		//update rx_check_userid to mimic 4 point completion	
		String updateRxChkUserId = "update rx set rx_check_userid = 'FOMQE' where rx_id = "+rxId+";";
		cnx.executeUpdateQuery(updateRxChkUserId);
		Reporter.log("4 point check completed for orderId = " +orderId+ ", fillId = "+fillId);
		
		//update the work queue to chkDUR
		String updateWrkQue = "update rx21c:informix.rx_order_detail set next_work_que_code = 12 where rx_id = "+rxId+";";
		cnx.executeUpdateQuery(updateWrkQue);
		
		//update resolution_userid and resolution_ts to mimic chKDUR completion
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String resolutionTs = sdf.format(timestamp);		
		
		String updateResolution = "update rx21c:informix.rx_conflict set resolution_userid = 'FOMQE', \n"
				+"resolution_ts = '"+resolutionTs+"' where rx_id = "+rxId+";";
		cnx.executeUpdateQuery(updateResolution);
		Reporter.log("chkDUR completed for orderId = " +orderId+ ", fillId = "+fillId);
		am.performSleep(15);
	}	
	return orderId;
}

public void updatePickUpTimeandNxtWorkQueue(IDatabaseContext cnx, int orderId) {
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Date date = DateUtil.tomorrow();
	String tomo = sdf.format(date);
	String nextDay1pm = tomo + " 13:00:00";
	
	String updateSQandPUtimeQuery = 
			"update rx21c:informix.rx_order_detail set est_pickup_ts = '"+nextDay1pm+"'\n" + 
			"where order_id = "+orderId+";";
	cnx.executeUpdateQuery(updateSQandPUtimeQuery);
	updateNextWrkQueCd(cnx,orderId);
	am.performSleep(15);
}

public void updateNextWrkQueCd(IDatabaseContext cnx, int orderId) {
	String updatenxtWrkQueQuery = 
			"update rx21c:informix.rx_order_detail set next_work_que_code = 4, work_que_stat_code = 20200 where order_id = "+orderId+" and status_code = 20501;";
	cnx.executeUpdateQuery(updatenxtWrkQueQuery);	
	Reporter.log("orderId = "+orderId+" is now in Filling queue");
}

public String getDrugName(IDatabaseContext cnx, String ndc) {
	String drugName;
	String getDrugName = "select pp.short_name from pharmacy_offering:pharmacy_product as pp \n" + 
			"join pharmacy_offering:pharmacy_item as pi \n" + 
			"on pp.product_mds_fam_id = pi.product_mds_fam_id \n" + 
			"where pi.ndc_nbr = "+ndc+";";
	drugName = cnx.getScalar(getDrugName, String.class).trim();
	return drugName;
	
}
}
