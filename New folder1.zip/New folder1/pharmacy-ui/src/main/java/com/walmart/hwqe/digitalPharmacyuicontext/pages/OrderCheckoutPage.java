package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class OrderCheckoutPage extends MobileBasePage  {

    @AndroidFindBy(id = "com.walmart.android.debug:id/cart_continue_to_checkout_button")
    @iOSXCUITFindBy(accessibility = "CartPrimaryCTAButton")
    @FindBy(id = "Continue to checkout button")
    public WebElement continueToCheckoutCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/viewAllFooter")
    @FindBy(xpath = "//button[text()='View all']")
    public WebElement viewAllDeliverySlotButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='replaceMe']//parent::android.view.ViewGroup[contains(@resource-id,'bookslot_day_date_layout')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='replaceMe']//ancestor::XCUIElementTypeButton[@name='DaySelectionCollectionCell.circleView']")
    @FindBy(xpath = "//button/div[text()='replaceMe']")
    public WebElement selectDay;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='replaceMe']//preceding-sibling::android.widget.RadioButton[contains(@resource-id,'bookslot_slot_radio_button')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='replaceMe']//preceding-sibling::XCUIElementTypeButton[@name='SlotHoursView.radioButton']")
    @FindBy(xpath = "//div/span[text()='replaceMe']/ancestor::label/preceding-sibling::label")
    public WebElement selectTimeSlot;

    @AndroidFindBy(id = "(//android.widget.RadioButton[@resource-id='com.walmart.android.debug:id/bookslot_slot_radio_button'])[1]")
    @FindBy(xpath = "(//input[@name=\"Slot List\"])[1]")
    public WebElement selectFirstSlot;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='SlotHoursCell.slotHoursView'])[3]")
    @AndroidFindBy(xpath = "(//android.widget.RadioButton[@resource-id='com.walmart.android.debug:id/bookslot_slot_radio_button'])[3]")
    @FindBy(xpath = "(//input[@name=\"Slot List\"])[4]")
    public WebElement selectFourthSlot;

    @AndroidFindBy(id = "com.walmart.android.debug:id/bookslot_bottom_button")
    @iOSXCUITFindBy(accessibility = "Continue")
    @FindBy(xpath = "//button[text()='Reserve']")
    public WebElement bookSlotContinueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/wplus_close")
    @iOSXCUITFindBy(id="//XCUIElementTypeButton[@name='close']")
    public WebElement closeWalmartPlusPopup;

    @AndroidFindBy(id = "com.walmart.android.debug:id/change_payments_button")
    @FindBy(xpath="//button[text()='Change payment']")
    public WebElement editPaymentMethod;

    @AndroidFindBy(id = "com.walmart.android.debug:id/underline_cta")
    @FindBy(xpath="//button[text()='Edit card']")
    public WebElement editCard;

    @AndroidFindBy(id = "com.walmart.android.debug:id/payment_methods_add_cta_save")
    @FindBy(xpath="//button[text()='Save card']")
    public WebElement saveCard;

    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    @FindBy(xpath="//button[text()='Confirm']")
    public WebElement confirmPayment;

    @AndroidFindBy(id = "com.walmart.android.debug:id/cvv_input_field")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSecureTextField[@name='TextFieldStackView.textField']")
    @FindBy(id= "cvv-field")
    public WebElement cvvInputField;

    @AndroidFindBy(id = "com.walmart.android.debug:id/button_place_order")
    @iOSXCUITFindBy(accessibility = "PlaceOrderView.placeOrderButton")
    @FindBy(xpath = "//button[@data-testid='place-order-button']")
    public WebElement placeOrderButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_guided_delivery_title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Your order is confirmed']")
    @FindBy(xpath= "//h2[text()='Your order is confirmed!']")
    public WebElement orderConfirmedDeliveryBottomSheetTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_guided_delivery_close")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Close Edit Delivery Instructions']")
    @FindBy(xpath = "//button[text()='Save']")
    public WebElement closeOrderConfirmedDeliveryBottomSheet;

    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_thankyou_consolidated_textview")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='OrderConfirmationView.orderConfirmLabel']")
    @FindBy(xpath="//div[contains(text(),'your order is confirmed.')]")
    public WebElement orderConfirmationMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_order_number_textview")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='EmailView.orderNumberLabel']")
    @FindBy(xpath="//div[@class='tc mt1 f5']")
    public WebElement orderId;

    @AndroidFindBy(id = "com.walmart.android.debug:id/bookslot_second_toggle")
    @iOSXCUITFindBy(accessibility = "Delivery from store")
    @FindBy(id = "fulfillment-option-scheduled-delivery")
    public WebElement deliverFromStoreCTA;

    @FindBy(xpath = "//button[text()='Continue']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/bookslot_bottom_button")
    @iOSXCUITFindBy(accessibility = "Continue")
    public WebElement confirmAddressContinueButton;

    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement reserveSlotContinueButton;

    @FindBy(xpath = "//button[@aria-label='Review Order, Back']")
    public WebElement navigateBackButton;

    @FindBy(xpath = "//button[text()='Leave anyway']")
    public WebElement leaveAnywayButton;

    @FindBy(xpath = "//button[text()='No thanks']")
    public WebElement noThanksButtonForMembers;

    @FindBy(xpath = "//*[@data-testid='fee']/following-sibling::div/child::div")
    public WebElement minimumBasketFee;

    @FindBy(xpath = "(//div[@data-testid='fee'])[1]")
    public WebElement belowOrderMinimumFeeText;

    @FindBy(xpath = "//div[contains(@class,'strike pr2')]/parent::div")
    public WebElement belowOrderMinimumStrikedFeeValue;

    @FindBy(xpath = "//button[text()='Decline']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/wplus_splash_no_thanks_button")
    public WebElement walmartPlusMembershipPopupDeclineButton;

    @FindBy(xpath = "//button[contains(text(), 'I'll sign')]")
    @iOSXCUITFindBy(accessibility = "SignatureOnDeliveryBannerView.titleLabel")
    public WebElement signOnDeliveryCTA;

    public OrderCheckoutPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickContinueToCheckout() {
        click(continueToCheckoutCTA);
    }

    public void clickViewAllDeliverySlotButton() {
        click(viewAllDeliverySlotButton);
    }

    public void selectDay(String day) { click(appDriver.findElement(By.xpath(selectDay.toString().replace("replaceMe", day)))); }

    public void setTimeSlot(String timeSlot) {
        androidScrollToText(timeSlot);
        click(appDriver.findElement(By.xpath(selectTimeSlot.toString().replace("replaceMe", timeSlot))));
    }

    public void clickBookSlotContinueButton() { unblockingClick(bookSlotContinueButton, 2, "bookSlotContinueButton"); }

    public void closeWalmartPlusNotification() { click(closeWalmartPlusPopup); }

    public void editPaymentMethod() {click(editPaymentMethod);}

    public void editCard() {click(editCard);}

    public void saveCard() {click(saveCard);}

    public void confirmPayment() {click(confirmPayment);}

    public void enterCVVNumber(String cvv){
        if(remoteDriver instanceof AndroidDriver) {
            androidScrollToText("Please enter your CVV.");
        }
        if(cvv.length()>3) {
            Reporter.log("incorrect CVV Given");
            throw new IllegalArgumentException();
        } else {
            if(isElementDisplayed(cvvInputField, 2)){
                sendText(cvvInputField, cvv);
            }
        }
    }

    public void clickPlaceOrderCTA() { click(placeOrderButton); }

    public String verifyOrderConfirmedDeliveryBottomSheet() { return getText(orderConfirmedDeliveryBottomSheetTitle); }

    public void closeOrderConfirmedDeliveryBottomSheet() { click(closeOrderConfirmedDeliveryBottomSheet); }

    public String verifyOrderConfirmationMessage() { return getText(orderConfirmationMessage); }

    public String getOrderId() {
        String orderNumber = getText(orderId).split("#")[1];
        return orderNumber;
    }

    public void clickStoreDeliveryCTA() throws Exception{
        unblockingClick(deliverFromStoreCTA, 2, "deliverFromStoreCTA");
    }

    public void clickExpressSlot() {
        if (remoteDriver instanceof IOSDriver) {
            click(selectFirstSlot, 10);
        } else {
            scrollToElement(selectFirstSlot);
            click(selectFirstSlot, 2);
        }
    }

    public void clickSelectFirstSlot() {
        if (remoteDriver instanceof IOSDriver || remoteDriver instanceof AndroidDriver) {
            click(selectFourthSlot, 10);
        } else {
            scrollToElement(selectFourthSlot);
            click(selectFourthSlot, 2);
        }
    }

    public void clickConfirmAddressContinueButton(){unblockingClick(confirmAddressContinueButton, 2, "confirmAddressContinueButton");}

    public void clickNavigateBackButton(){click(navigateBackButton);}

    public void clickLeaveAnywayButton(){click(leaveAnywayButton);}

    public void clickNoThanksButtonForMembers(){unblockingClick(noThanksButtonForMembers, 2,
            "No Thanks Button for Reserving Express Checkout For W+ Members");}

    public String getMinimumBasketFee(){return getText(minimumBasketFee);}

    public void selectSlot(Boolean isExpressEvergreenSlot){
        if(isExpressEvergreenSlot){
            clickExpressSlot();
        } else {
            // Pick the First Available slot
            clickSelectFirstSlot();
        }
    }

    public String getBelowMinOrderWaivedFeeForPrescriptionsText() { return getText(belowOrderMinimumFeeText); }

    public String getBelowMinOrderWaivedFeeForPrescriptionsValue() { return getText(belowOrderMinimumStrikedFeeValue); }

    public void clickWalmartPlusMembershipPopupDeclineButton() { unblockingClick(walmartPlusMembershipPopupDeclineButton, 2, "Dismissing Walmart Plus Sign Up Popup");}

    public void clickSignOnDeliveryCTA() { unblockingClick(signOnDeliveryCTA, 2, "Click Sign On Delivery"); }
}
