package com.walmart.hwqe.rxpde2e.datamodels.response.ConnexusPatientDataforPickupResponse;
@lombok.Getter
@lombok.Setter
public class Prescriber {
    public String fullname;
    public String firstname;
    public String lastname;
    public Object phone;
    public String state;
    public int prescriberId;
    public int rxClinicId;
    public String dea;
    public String npi;
}
