package com.walmart.hwqe.rxpde2e.datamodels.request.UpdatePayment;
@lombok.Getter
@lombok.Setter
public class PostalAddress {

    public String address;
    public String city;
    public String country;
    public String postalCode;
    public String state;

}
