package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;

import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class InputTransferRxDetailsPage extends MobileBasePage {

    @FindBy(xpath = "//div[@data-automation-id='transfer-pd-first-name']/descendant::input")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'TextFieldStackView.textField' AND label CONTAINS 'Medication name'")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Medication name*']//android.widget.EditText")
    private WebElement drugNameInput;

    @FindBy(xpath = "//span[text()='Prescription number (optional)']/parent::*/following-sibling::div/input")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label=\"Prescription number (optional)\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Prescription number (optional)']//android.widget.EditText")
    private WebElement prescriptionNumberInput;

    @FindBy(xpath = "//button[text()='Add']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/add_button")
    private WebElement addButton;
    public InputTransferRxDetailsPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void enterDrugName(String drugName) {
        sendText(drugNameInput, drugName);
    }

    public void enterPrescriptionNumber(String prescriptionNo) {
        sendText(prescriptionNumberInput, prescriptionNo);
    }
    // Hide Keyboard in IOS
    public void clickAddEnteredPrescription(){click(addButton);}

}
