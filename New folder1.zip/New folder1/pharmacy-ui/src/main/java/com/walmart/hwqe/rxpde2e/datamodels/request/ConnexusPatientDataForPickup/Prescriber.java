package com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientDataForPickup;

@lombok.Getter
@lombok.Setter
public class Prescriber {
    public String fullname;
    public String firstname;
    public String lastname;
    public String phone;
    public String state;
    public int prescriberId;
    public int rxClinicId;
    public String dea;
    public String npi;
}
