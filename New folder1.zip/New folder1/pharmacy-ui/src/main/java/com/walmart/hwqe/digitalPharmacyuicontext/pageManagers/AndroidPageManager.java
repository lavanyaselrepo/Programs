/**
 * AndroidPageManager initialises the page manager for "ANDROID" platform.
 * It inherits BasePageApplicationManager.
 * Usage : Overridden methods for common interactions that are specific to ANDROID platform are written over here.
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.pageManagers;


import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commoncontext.models.datamodels.StoreConfig;
import com.walmart.hwqe.commoncontext.utils.Poller;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class AndroidPageManager extends BasePageApplicationManager {

    public AndroidPageManager() {
        super();
    }

    public AndroidPageManager(RemoteWebDriver driver, String platform) {
        super(driver, platform);
    }

    @Override
    public void waitForAppToLoad() {
        Reporter.log("Android: Waiting for app to load and welcome screen to appear...");
        // Poll for the sign-in button while also dismissing the location dialog each cycle.
        // The dialog appears 1-3s after the sign-in screen and causes Appium to report the
        // sign-in button as not displayed (it is covered by the overlay). Without in-loop
        // dismissal the wait spins for the full 60s timeout before falling through.
        final By signInButtonLocator = By.id("com.walmart.android.debug:id/onboarding_welcome_primary_button");
        final By continueLocationLocator = By.xpath("//*[@text='Continue sharing precise location']");
        try {
            new WebDriverWait(signInPage.remoteDriver, Duration.ofSeconds(90))
                    .pollingEvery(Duration.ofMillis(500))
                    .until(driver -> {
                        // Dismiss the location dialog if it is blocking the sign-in button.
                            List<org.openqa.selenium.WebElement> dialogs = driver.findElements(continueLocationLocator);
                            if (!dialogs.isEmpty()) {
                                try { dialogs.get(0).click(); } catch (Exception ignored) {}
                                Reporter.log("Dismissed location access dialog (Continue sharing) inside waitForAppToLoad");
                            }
                        List<org.openqa.selenium.WebElement> buttons = driver.findElements(signInButtonLocator);
                        return !buttons.isEmpty() && buttons.get(0).isDisplayed();
                    });
            Reporter.log("Android app load: Sign-in screen loaded successfully");
        } catch (TimeoutException e) {
            Reporter.log("WARNING: Sign-in button not detected after 90 seconds. App may still be loading.");
        }
    }

    public void proceedToPharmacyDashboard() {
        this.androidRestartAppToEnableDashboard();
        // "Confirm location access" dialog can appear after the app restarts on real devices
        // (noReset=true preserves location permission state). Dismiss before PIN entry.
        pharmacyDashboardPage.dismissLocationAccessDialog(5);
        pharmacyDashboardPage.enterPin();
        Reporter.log("Entered pharmacy PIN");
        // pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.acceptPrivacyPractices();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
    }

    public void proceedToPharmacyDashboardWithATCEnabled() {
        this.androidRestartAppToEnableDashboard();
        pharmacyDashboardPage.dismissLocationAccessDialog(5);
        pharmacyDashboardPage.enterPin();
        Reporter.log("Entered pharmacy PIN");
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
        pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
        Reporter.log("Denied biometrics and personalisation shopping permission");
    }

    public void proceedToPharmacyDashboardAndCloseBottomSheets() {
        this.androidRestartAppToEnableDashboard();
        pharmacyDashboardPage.dismissLocationAccessDialog(10);
        pharmacyDashboardPage.enterPin();
        Reporter.log("Entered pharmacy PIN");
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        dismissAllBottomSheets();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
        Assert.assertTrue(isPharmacyDashboardDisplayed(), "Pharmacy Dashboard should be displayed");
    }

    @Override
    public void signOut() {
        signInPage.clickOnAccount();
        pharmacyDashboardPage.androidScrollToText("Sign Out");
        signInPage.clickOnSignout();
    }


    public void proceedToPharmacyDashboardAndCloseBottomSheetsWithoutPin() {
        this.androidRestartAppToEnableDashboard();
        dismissAllBottomSheets();
        Assert.assertTrue(isPharmacyDashboardDisplayed(), "Pharmacy Dashboard should be displayed");
    }

    @Override
    public void addInsuranceFromNudgeScreen(String memberId, String bin, String pcn) {
        manageInsurancePage.addInsuranceFromNudgeScreen(memberId, bin, pcn);
    }

    public void verifyInsuranceNudgeNotVisible() {
        Assert.assertTrue(pharmacyDashboardPage.isInsuranceNudgeNotDisplayed(), "Insurance nudge should not be visible after insurance has been added");
    }

    public void addGroceryItemToCart(String item) {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickGlobalSearch();
        Reporter.log("Navigated to ecomm search page");
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSearch();
        rxReadyForPickupAndDeliveryTrackerCardPage.waitForLoadingToDisappear(15);
        rxReadyForPickupAndDeliveryTrackerCardPage.enterGroceryItems(item);
        Reporter.log("Entered Non-RX item in search and clicked enter");
        rxReadyForPickupAndDeliveryTrackerCardPage.clickGotItButton();
        Reporter.log("Accepted similar products notification");
        rxReadyForPickupAndDeliveryTrackerCardPage.waitForLoadingToDisappear(15);
        rxReadyForPickupAndDeliveryTrackerCardPage.clickAddCartButtonForNonRxItem();
        Reporter.log("Click addToCart CTA for non-RX item");
    }

    public void androidRestartAppToEnableDashboard() {
        // Dismiss any visible prompt before terminating so it doesn't interfere with relaunch.
        pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();

        String appPackage = prop.getProperty("dp.android.app.package");

        // 1. Terminate — mobile: terminateApp is a standard UIAutomator2 command that needs
        //    no --relaxed-security flag on the Appium server, unlike mobile: shell.
        //    timeout (ms) is how long UIAutomator2 waits for the process to die; the Walmart
        //    app can take >500ms (the default) on both emulators and real devices.
        //    Wrapped in try-catch: if the app is already stopped (e.g. crashed earlier),
        //    terminateApp may throw — safe to continue since the process is already gone.
        try {
            pharmacyDashboardPage.remoteDriver.executeScript("mobile: terminateApp",
                    ImmutableMap.of("appId", appPackage, "timeout", 5000));
        } catch (Exception e) {
            Reporter.log("terminateApp warning (non-fatal — app may already be stopped): " + e.getMessage());
        }

        // 2. Short fixed pause for clean process shutdown before firing the deep link.
        //    terminateApp is synchronous so a brief wait is enough.
        try { Thread.sleep(1500); } catch (InterruptedException ignored) {}

        // 3. Launch pharmacy dashboard via deep link — mobile: deepLink is a standard
        //    UIAutomator2 command, no adb_shell security flag required.
        pharmacyDashboardPage.remoteDriver.executeScript("mobile: deepLink",
                ImmutableMap.of("url", "walmart://healthandwellness/dashboard", "package", appPackage));

        // 4. Wait for a Walmart activity to reach the foreground.
        if (pharmacyDashboardPage.remoteDriver instanceof AndroidDriver) {
            try {
                new FluentWait<>((AndroidDriver) pharmacyDashboardPage.remoteDriver)
                        .withTimeout(Duration.ofSeconds(30))
                        .pollingEvery(Duration.ofMillis(500))
                        .ignoring(WebDriverException.class)
                        .until(d -> {
                            String activity = d.currentActivity();
                            return activity != null && activity.startsWith("com.walmart");
                        });
            } catch (TimeoutException ignored) {
                Reporter.log("WARNING: Walmart activity not in foreground within 30s after deep link");
            }
        }

        Reporter.log("Restarted the app to enable pharmacy dashboard");
    }

    public void dismissNotifications() {
        pharmacyDashboardPage.dismissLocationAccessDialog();
        signInPage.clickMayBeLaterNotifications();
        Reporter.log("Clicked on may be later CTA to dismiss product notification");
    }

    public void dismissAllBottomSheets() {
        signInPage.dismissAllBottomSheets();
    }

    public void proceedToPharmacyDashboardForGuestUser() {
        pharmacyDashboardPage.clickPharmacyServicesForGuestUser();
    }

    public void scanRxDetailsManually(String rxNb, String storeNb, String dob) {
        scanToRefillPage.clickAllowTakePicturesAndRecordAudio();
        super.scanRxDetailsManually(rxNb, storeNb, dob);
    }

    public void configureDebugSettings() {
        debugMenuPage.openDebugPanelAndroid();

        debugMenuPage.androidScrollToText("Authentication - Identity").click();
        am.performSleep(2);
        debugMenuPage.androidScrollToText("Skip Step up");
        debugMenuPage.enableDebugToggle("Skip Step up");
        debugMenuPage.androidPressBackKey();

        debugMenuPage.androidScrollToText("App onboarding").click();
        am.performSleep(2);
        debugMenuPage.enableDebugToggle("Onboarding completed");
        am.performSleep(1);
        debugMenuPage.androidPressBackKey();
        debugMenuPage.androidPressBackKey();

        Reporter.log("Android debug settings configured: Skip Step up + Onboarding completed = enabled");
    }

    @Override
    public void doSignInSkipOnBoardingAndStepUp(String email, String password) {
        configureDebugSettings();
        signInPage.clickSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        am.performSleep(5);
        Reporter.log("Signed-In to walmart dotcom account");
    }

    public void doSignInSkipOnBoardingAndStepUpFromPharmacyDashboard(String email, String password) {
        // Open debug panel and configure toggles before pointing to Teflon
        configureDebugSettings();
        signInPage.clickSignInButtonPharmacyDashboard();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        am.performSleep(5);
        Reporter.log("Signed-In to walmart dotcom account");

        pharmacyDashboardPage.enterPin();
        Reporter.log("Entered pharmacy PIN");
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        dismissAllBottomSheets();
        Assert.assertTrue(isPharmacyDashboardDisplayed(), "Pharmacy Dashboard should be displayed");

    }

    public void doSignIn(String email, String password) {
        // Safety net: dialog should already be gone after waitForAppToLoad() dismissed it.
        // Zero-wait check covers edge cases where it reappears before sign-in.
        pharmacyDashboardPage.dismissLocationAccessDialog();
        signInPage.dismissLocationOnboardingScreen();
        Poller poller = new Poller(30, 1000);
        Boolean success = poller.pollForSuccess(() -> signInPage.clickSignInButton());
        String pollResult = success ? "Success" : "Failed";
        Reporter.log("Android Polling for SignIn Button result: " + pollResult);
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        am.performSleep(5);
        try {
            if (signInPage.isStepUpHeaderDisplayed()) {
                if (signInPage.isStepUpEnabled()) {
                    Reporter.log("Clicking on Email Option for OTP");
                    signInPage.clickSendOtpOnEmailRadioButton();
                } else {
                    Reporter.log("Only Email Option was Available");
                }
                DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
                signInPage.clickSendcode();
                am.performSleep(4);
                String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
                signInPage.enterInputOtpValue(otp);
                signInPage.clickSignInButtonForStepUp();
            } else {
                Reporter.log("StepupDisabled");
            }
        } catch (Exception e) {
            Reporter.log("failed in Stepup flow");
            e.printStackTrace();
        }
        Reporter.log("Signed-In to walmart dotcom account");
    }

    public void verifyMedicaidConsentFormData() {
        Object medicaidFormTitleText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormTitle");
        Object medicaidFormDisclaimerText = textValidationUtils.getKeyInObject("pharmacyConsentForms", "testMedicaidConsentForm", "FormDisclaimerText");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidSwitchToCashTitle(), medicaidFormTitleText, "Form Header is Incorrect");
        Assert.assertEquals(medicaidConsentFormPage.getMedicaidConsentDisclaimerText(), medicaidFormDisclaimerText, "Form Disclaimer Text is Incorrect");
        Assert.assertTrue(medicaidConsentFormPage.checkAcknowledgeButtonVisibility());
        Assert.assertTrue(medicaidConsentFormPage.checkPickupInsteadLinkVisibility());
        Assert.assertTrue(medicaidConsentFormPage.medicaidFormCloseIconVisibility());
    }

    public void fillZipCodeDetails() {
        signInPage.fillZipCodeDetails();
        Reporter.log("Entered Zip Code Details");
        int count = 0;
        while(count<5){
            if(!signInPage.isPageStable())
                am.performSleep(3);
            else
                break;
            count++;
        }
        if (count == 5) {
            Reporter.log("Page is not stable, please check the app");
        }
    }

    public void fillLocationDetailsUsingPreciseLocation() {
        signInPage.clickSharePreciseLocationButton();
        Reporter.log("Clicked on 'Share precise location' button");
        pharmacyDashboardPage.clickOnlyThisTime();
        Reporter.log("Clicked on 'Only this time' for location permission");
        int count = 0;
        while(count<5){
            if(!signInPage.isPageStable())
                am.performSleep(3);
            else
                break;
            count++;
        }
        if (count == 5) {
            Reporter.log("Page is not stable, please check the app");
        }
    }

    public void navigateToWalmartPharmacy() {
        this.androidRestartAppToEnableDashboard();
        pharmacyDashboardPage.dismissLocationAccessDialog(5);
        pharmacyDashboardPage.waitForMobilePageToLoad(3, false);
        pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
    }

    public void navigateBackToPharmacyFromReviewConfirmation() {
        reviewOrderPage.clickBackToPharmacyCTA();
        reviewOrderPage.closeFeedbackScreen();
        dismissAllBottomSheets(); // dismiss any bottom sheets
    }

    public void addMinorFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob) {
        try {
            manageFamilyMembersPage.clickPrescriptionInformation();
            manageFamilyMembersPage.clickContinueButton();
            manageFamilyMembersPage.allowTakePictureWhileUsingTheApp();
            manageFamilyMembersPage.clickEnterManually();
            manageFamilyMembersPage.enterPrescriptionNumber(rx);
            manageFamilyMembersPage.enterStoreNumber(storeNumber);
            manageFamilyMembersPage.clickContinueButton();
            manageFamilyMembersPage.enterDateOfBirth(dob);
            manageFamilyMembersPage.clickConfirmButton();
            if (manageFamilyMembersPage.isMinorAdded()) {
                this.removeDependents();
            }
        } catch (Exception e) {
           Assert.fail("Failed to add minor");
        }
    }

    public void addPetFamilyMemberUsingRxNumber(String rx, String storeNumber) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.allowTakePictureWhileUsingTheApp();
        manageFamilyMembersPage.clickEnterManually();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.clickConfirmPet();
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isPetAdded()) {
            this.removeDependents();
        }
        else{
            Assert.fail("Failed to add pet");
        }
    }

    public void addLivestockFamilyMemberUsingRxNumber(String rx, String storeNumber) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.allowTakePictureWhileUsingTheApp();
        manageFamilyMembersPage.clickEnterManually();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        if (manageFamilyMembersPage.verifyLivestockErrorMessage()) {
            manageFamilyMembersPage.clickGoBackToManageMyFamily();
        }
        else{
            Assert.fail("Failed to verify add livestock");
        }
    }

    public void removeDependents() {
        try {
            while (manageFamilyMembersPage.isDepedentFound()) {
                manageFamilyMembersPage.androidManualSwipeDownToText("Remove");
                manageFamilyMembersPage.removeDependents();
                Reporter.log("Removed a dependent successfully");
                am.performSleep(5);
            }
            Reporter.log("All dependents removed");
        } catch (Exception e) {
            Reporter.log("Failed to remove dependents: " + e.getMessage());
        }
    }

    public void addMinorFamilyMemberUsingPhoneNumber(String phoneNumber, String email, String dob) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(email, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectMinor();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isMinorAdded()) {
            this.removeDependents();
        }
        else{
            Assert.fail("Failed to add minor");
        }
    }

    public void addPetFamilyMemberUsingPhoneNumber(String phoneNumber, String email) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(email, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectPet();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.clickConfirmPet();
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isPetAdded()) {
           Reporter.logScreenShot("Added Pet successfully", manageFamilyMembersPage.captureScreenShot());
            this.removeDependents();
        }
        else{
            Assert.fail("Failed to add pet");
        }
    }

    public void addLivestockFamilyMemberUsingPhoneNumber(String phoneNumber) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        if (manageFamilyMembersPage.verifyLivestockPhoneNumberErrorMessage()) {
            manageFamilyMembersPage.clickBackToAddFamilyMember();
        }
        else{
            Assert.fail("Failed to verify add livestock");
        }
    }

    public void navigateToManageMyFamilyPage() {
        this.clickOnManageFamilyCTA();
        pharmacyDashboardPage.waitForCompletePageLoad();
        AssertUtil.assertTrue(manageFamilyPage.isMyAccountTextDisplayed(), "Manage my family - My account text");
    }

    public void proceedToScanToRefill() {
        pharmacyDashboardPage.clickScanToRefill();
        pharmacyDashboardPage.clickOnlyThisTime();
        pharmacyDashboardPage.clickEnterManuallyBtn();
        Reporter.log("Able to click the scan to refill option");
    }

    /**
     * Validates key elements on the Refill Confirmation screen.
     */
    @Override
    public void validateRefillConfirmationScreen() {
        String headerText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "headerText").toString();
        String notificationText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "notificationText").toString();
        String deliveryUpsellText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "deliveryUpsellText").toString();
        Assert.assertEquals(
                scanToRefillPage.getRefillConfirmationHeaderText(),
                headerText,
                "Refill confirmation header text mismatch");
        Assert.assertTrue(
                scanToRefillPage.isTextDisplayedInAndroid(notificationText),
                "Notification text not shown on confirmation screen");
        Assert.assertTrue(
                scanToRefillPage.isTextDisplayedInAndroid(deliveryUpsellText),
                "Delivery upsell banner not shown on confirmation screen");
        Reporter.log("Refill confirmation screen validated successfully");
    }

    public void proceedToScanToRefillNotConnected() {
        pharmacyDashboardPage.clickScanToRefillNotConnected();
        pharmacyDashboardPage.clickOnlyThisTime();
        pharmacyDashboardPage.clickEnterManuallyBtn();
    }

    public void verifyScanToRefillMinorFlow(String RX, String strNo, String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        Reporter.log("Successfully entered the Minor details");
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        Reporter.log("Able to validate the refill  success message");
        pharmacyDashboardPage.clickCloseButton();
        pharmacyDashboardPage.clickFeedbackCloseButton();
    }

    public void verifyScanToRefillPetRxFlow(String RX, String strNo, String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        Reporter.log("Successfully entered the Minor details");
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        Reporter.log("Able to validate the refill  success message");
        pharmacyDashboardPage.clickAddFamilyMemberOptionInTheRefillPrescriptionScreen();
        pharmacyDashboardPage.clickCloseButton();
        pharmacyDashboardPage.clickFeedbackCloseButton();
        pharmacyDashboardPage.clickAddFamilyMemberOption();
        pharmacyDashboardPage.clickRemoveOption();
    }

    public void verifyScanToRefillFlowWhenAccountNotConnectedTest(String RX, String strNo, String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        Reporter.log("Successfully entered the Minor details");
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        Reporter.log("Able to validate the refill  success message");
        pharmacyDashboardPage.clickGetStartedButton();
    }

    public void generateRxMessagingPhoneOtpScanToRefillFlow(String phoneNo) {
        connectMyAccount.enterPhoneNumber(phoneNo);
        connectMyAccount.clickContinueNotConnected();
        connectMyAccount.clickContinueAfterEnteringSMSNumber();
    }

    public void scrollToFindWalmartPrescriptionsModule() {
        pharmacyDashboardPage.androidScrollDownToText("Find Walmart prescriptions");
    }

    public void selectEnterPrescriptionManually() {
        findPrescriptionsPage.selectEnterPrescriptionManuallyRadioButton().clickContinueBtn();
    }

    public void closeJoinOneProgram() {
        if (homePage.isOneFinanceBottomSheetDisplayed()) {
            homePage.clickCloseJoinOneProgramButton();
        }
    }

    public void validateExperianFlowHeader() {

    }

    public void clickOnManageFamilyCTA() {
        pharmacyDashboardPage.androidScrollToText("Manage family members");
        pharmacyDashboardPage.clickOnManageFamilyCTA();
    }

    public void addFamilyUsingPhoneNoLookup(String phoneNumber,String emailForPin) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(emailForPin, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        am.performSleep(5);
    }

    public void addAdultFamilyMemberUsingPhoneNumber(String phoneNumber, String storeNumber, String dob, String emailForPin, String email, String password, String careGiverEmail, String careGiverPassword) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(emailForPin, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectAdult();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmAdultButton();
        if (manageFamilyMembersPage.sentRequestToAdult()) {
            this.cancelRequest();
        }
        else{
            Assert.fail("Failed to send request to dependent");
        }
    }
    public void addAdultFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob, String email, String password, String careGiverEmail, String careGiverPassword) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.allowTakePictureWhileUsingTheApp();
        manageFamilyMembersPage.clickEnterManually();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmAdultButton();
        if (manageFamilyMembersPage.sentRequestToAdult()) {
            this.cancelRequest();
        }
        else{
            Assert.fail("Failed to send request to dependent");
        }
    }

    public void doSignIn(String email, String password, String phone) {
        Poller poller = new Poller(60, 500);
        Boolean success = poller.pollForSuccess(() -> signInPage.clickSignInButton());
        String pollResult = success ? "Success" : "Failed";
        Reporter.log("Android Polling for SignIn Button result: " + pollResult);
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickOnEnterPasswordRadioBtn();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");

        if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
            signInPage.clickSendcode();
            // Takes time between sending otp and astro API to receive it
            am.performSleep(5);
            DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
            String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
            if (otp == null) {
                otp = digitalPharmacyAPIManager.getOTPForPhone(email, phone);
            }
            if (otp == null) {
                Reporter.log("One time passcode is null");
                Assert.fail("Cannot get One time Passcode for this user");
            }
            Reporter.log("One time passcode is :: " + otp);
            signInPage.enterInputOtpValue(otp);
            signInPage.clickSignInButtonForStepUp();
            if (!signInPage.isSignInButtonNotDisplayed()) {
                Assert.fail("One time password Entered is wrong");
            }
        }

        Reporter.log("Logged In successfully");
    }

    public void proceedToPharmacyDashboardWithoutPinValidation() {
        this.androidRestartAppToEnableDashboard();
    }

    public void handlePharmacyPinValidation(String pin) {
        Poller poller = new Poller(60, 500);
        Boolean success = poller.pollForSuccess(() -> pharmacyDashboardPage.isVerifyInputPinVisible());
        if (success) {
            pharmacyDashboardPage.enterPharmacyPin(pin);
            Reporter.log("entered pin for PharmacyDashboard");
            // pharmacyDashboardPage.verifyPin();
        } else {
            Assert.fail("Pharmacy PIN input field is not visible, unable to proceed with pin validation. ; Test may have failed to load the pharmacy dashboard properly.");
        }
        Reporter.log("Entered pharmacy PIN and navigated to pharmacy dashboard");
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
        pharmacyDashboardPage.clickGetNotificationsMaybeLaterButton();
    }

    public void proceedToCheckoutRxsAddedToCart(String cvvNumber, Boolean isDiscardCheckout, Boolean isPlaceOrder, Boolean isExpressEvergreenSlot, boolean... isSODNeeded) throws Exception {
        orderCheckoutPage.clickContinueToCheckout();
        orderCheckoutPage.clickStoreDeliveryCTA();
        orderCheckoutPage.selectSlot(isExpressEvergreenSlot);
        orderCheckoutPage.clickConfirmAddressContinueButton();
        orderCheckoutPage.clickBookSlotContinueButton();
        // taking time for slot reservation to apply in IOS

        am.performSleep(7);
        // these banners may still be needed in the future, I have seen them pop up, in the current rendition, consistently saw them do not appear.

        // orderCheckoutPage.clickNoThanksButtonForMembers();
        // homePage.clickPersonalisationChoiceButton();
        orderCheckoutPage.clickWalmartPlusMembershipPopupDeclineButton();

        // cvv number is not required for onePayCheckout enabled accounts
        // orderCheckoutPage.enterCVVNumber(cvvNumber);

        // Commenting this because this is needed exactly once and the preference is saved
        /*boolean isDeliverySignatureNeeded = (isSODNeeded.length >= 1) ? isSODNeeded[0] : false;

        if (isDeliverySignatureNeeded) {
            orderCheckoutPage.clickSignOnDeliveryCTA();
        }*/


        if (isPlaceOrder) orderCheckoutPage.clickPlaceOrderCTA();
        else if (isDiscardCheckout) this.discardCheckoutProcess();
    }

    public String verifyCheckoutSuccessAndGetOrderId(String customerName) {
        Object orderConfirmedText = textValidationUtils.getKeyInObject("orderConfirmationPage", "orderConfirmedPartialText");
        Assert.assertEquals(orderConfirmationPage.getOrderIsConfirmedHeaderText().toLowerCase(), (customerName + orderConfirmedText.toString()).toLowerCase(), "Order Confirmation Text is incorrect");
        return orderConfirmationPage.getOrderNumber();
    }

    public void cancelOrderFromDotCom() {
        orderConfirmationPage.clickViewDetailsButton();
        orderDetailsPage.clickCancelOrderButton();
        orderDetailsPage.clickWrongPaymentMethodCancellationReason();
        orderDetailsPage.clickConfirmCancellationButton();
    }

    public void cancelRequest() {
        manageFamilyMembersPage.cancelRequest();
    }

    public void checkCompetitiveTransferSuccess(String patientName) {
        // Wait for page to reflect - The locators are same for headers on success and review transfer, unexpected element is returned.
        am.performSleep(5);
        Object orderSuccessPageHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageHeader");
        Object orderSuccessPageSubHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageSubHeader");
        Object ctTrackerCardHeading = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "competitiveTransferTrackerCard", "competitiveTransferCardHeading");
        Assert.assertEquals(transferRequestSuccessPage.getTransferRequestSuccessHeading(), orderSuccessPageHeader.toString(), "Ct Transfer Success Page Heading Mismatch");
        Assert.assertEquals(transferRequestSuccessPage.getPharmacistWillContactSubheading(), orderSuccessPageSubHeader, "Ct Transfer Success Page Subheading Mismatch");
        transferRequestSuccessPage.clickBackToPharmacyButton();
        Assert.assertEquals(competitiveTransferTrackerCardPage.getCtCardHeaderText(), ctTrackerCardHeading.toString(), "Card Header Text Mismatch");
        Assert.assertEquals(competitiveTransferTrackerCardPage.getUserNameText().toLowerCase(), patientName.toLowerCase(), "Patient UserName Incorrect");
    }

    public void selectPrimaryProfileForTransfer() {
        pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
        pharmacyDashboardPage.clickTransferSourceContinueButton();
        getTransferStartedPage.clickPrimaryProfileOption();
        getTransferStartedPage.clickContinueButton();
        Reporter.log("Verified that Account is Connected to Pharmacy");
    }

    @Override
    public void validateAddedInsuranceDetails(String memberId, String bin, String pcn) {
        manageInsurancePage.waitForLoadingToDisappear(5);
        manageInsurancePage.clickExpandInsurance();
        Assert.assertTrue(manageInsurancePage.getMemberIdText().contains(memberId), "Added Insurance Member ID is incorrect");
        Assert.assertEquals(manageInsurancePage.getBinText().toLowerCase(), ("rxbin: " + bin.toLowerCase()), "Added Insurance BIN is incorrect");
        Assert.assertEquals(manageInsurancePage.getPCNTest().toLowerCase(), ("rxpcn: " + pcn.toLowerCase()), "Added Insurance PCN is incorrect");
    }

    @Override
    public String selectAndGetFirstAvailableCompetitorStoreDetails(String sourcePharmacyName) {
        // Android: Use "Search by Name" strategy from PRD Step 3
        // Parameter is sourcePharmacyName (not destinationStoreNumber for Android)
        // Search by pharmacy name (PRD: "Search by Name - User types pharmacy name")
        selectSourceStorePage.enterPharmacyNameInSearchField(sourcePharmacyName);
        selectSourceStorePage.clickStoreSearchButton();
        selectSourceStorePage.waitForSearchResultsToLoad(sourcePharmacyName);
        selectSourceStorePage.selectSourcePharmacyByName(sourcePharmacyName);
        selectSourceStorePage.clickContinueButton();
        
        return sourcePharmacyName;
    }

    @Override
    public void selectDestinationStore(String zipCode) {
        // Android: Change location by zip code, then select first Walmart from filtered list
        // Parameter is zipCode (not storeId for Android implementation)
        selectDestinationStorePage.clickChangeLocationButton();
        // AppiumFieldDecorator implicit wait (15s) handles waiting for bottom sheet
        
        selectDestinationStorePage.enterZipCode(zipCode);
        selectDestinationStorePage.clickApplyLocationButton();
        selectDestinationStorePage.waitForFirstStoreResult();
        selectDestinationStorePage.selectFirstDestinationStore();
        selectDestinationStorePage.clickContinueButton();
    }

    @Override
    public void verifySingleRxInFilling(String patientName, String drugName, String estimatedPrice, boolean isPet) {
        Object singleRxFillingHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderText");
        Object singleRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderDescriptionText");
        rxInFillingCardPage.androidScrollToTextContains(singleRxFillingHeaderText.toString());

        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardHeaderText(1, singleRxFillingHeaderText.toString()), singleRxFillingHeaderText, "Card Header is Incorrect");
        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), singleRxFillingCardHeaderDescriptionText, "Fill status card sub header text is not visible");
        Assert.assertEquals(rxInFillingCardPage.getPatientNameOnFillTrackerCard(), patientName, "Patient name is incorrect");
        Assert.assertEquals(rxInFillingCardPage.getRxName().toUpperCase().replaceAll(" ", ""), drugName.toUpperCase().replaceAll(" ", ""), "Drug Name is incorrect");
        Assert.assertEquals(rxInFillingCardPage.getPrescriptionsCount(), rxInFillingCardPage.prescriptionCountTxt(1));
        Assert.assertTrue(rxInFillingCardPage.getEstimatedPrice().contains(estimatedPrice), "Price is incorrect");
        Assert.assertTrue(rxInFillingCardPage.isFillDetailsArrowCTAVisible(), "Chevron icon not visible in Rx row");
        if (isPet) Assert.assertTrue(rxInFillingCardPage.isPetIconVisible());
        logScreenShot("Single Rx in Filling Card Details");
    }

    @Override
    public void verifyMultiRxInFilling(List<String> patientNameList, List<String> expectedRxNames, List<String> expectedExtimatedPrices, String rxCount) {
        Object multiRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxInFilling", "CardHeaderDescriptionText");

        rxInFillingCardPage.androidScrollToTextContains("filling " + rxCount);
        Assert.assertTrue(rxInFillingCardPage.getFillStatusCardHeaderText(Integer.parseInt(rxCount), "").contains(rxCount), "RxCount is incorrect in the Header");
        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), multiRxFillingCardHeaderDescriptionText, "Filling status card sub header text is not visible");
        verifyPatientNamesForMultiRxinFilling(patientNameList);
        verifyRxNamesForMultiRxinFilling(expectedRxNames);
        verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
        if (Integer.parseInt(rxCount) > 2) {
            // Scroll to the last patient to bring off-screen prescriptions into the viewport,
            // then re-verify so rows that were not yet visible in the first pass are also covered.
            rxInFillingCardPage.androidScrollToTextContains(patientNameList.get(patientNameList.size() - 1));
            verifyPatientNamesForMultiRxinFilling(patientNameList);
            verifyRxNamesForMultiRxinFilling(expectedRxNames);
            verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
        }
    }

    @Override
    public void verifyNudgeTitle() {
        prescriptionHistoryPage.androidScrollToTextContains("Not seeing all your prescriptions");
        super.verifyNudgeTitle();
    }

    @Override
    public void navigateToPrescriptionHistory() {
        pharmacyDashboardPage.androidScrollToText("Prescription history");
        pharmacyDashboardPage.navigateToPrescriptionHistory();
    }

    @Override
    public void scrollDownToLoadPreferencesCategories() {
        communicationsPage.androidScrollToText("Clinical outreach");
    }

    @Override
    public void scrollToReceiveTextNotificationsToggle() {
        communicationsPage.androidScrollToText(communicationsPage.remoteDriver, "Receive text notifications");
    }

    @Override
    public WebElement scrollDownToText(String text) {
        return rxReadyForPickupAndDeliveryTrackerCardPage.androidScrollDownToText(text);
    }

    @Override
    public boolean isRfpPatientVisible(String patientName) {
        return rxReadyForPickupAndDeliveryTrackerCardPage.isTextOnScreen(
                "com.walmart.android.debug:id/pharmacy_customer_name", patientName);
    }

}