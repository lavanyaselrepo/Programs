/**
 * DigitalPharmacyTestBase is the super class that all test classes will inherit in order to utilise
 * the common framework for automation of UI platforms (Android/Ios/Web/Mobile Web).
 * Every test class for UI automation should extend DigitalPharmacyTestBase class.
 * This common framework has been written specifically for Digital Pharmacy and can be considered as a blueprint
 * for any other project that wishes to onboard this framework.
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */

package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;

import com.walmart.hwqe.commoncontext.utils.TextValidationUtils;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.datacontext.CommonUtils;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.digitalPharmacyuicontext.pageManagers.*;
import com.walmart.hwqe.digitalPharmacyuicontext.pages.HomePage;
import com.walmart.hwqe.webcontext.interfaces.ICommonDriver;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Listeners;

@Listeners(DigitalPharmacyFailureScreenshotListener.class)
public class DigitalPharmacyTestBase {

    public AutomationManager am = AutomationManager.getInstance();
    public PropertyReader prop = PropertyReaderHelper.getInstance();
    private static ThreadLocal<ICommonDriver> platformFactoryThreadLocal = new ThreadLocal<>();
    private static ThreadLocal<BasePageApplicationManager> basePageApplicationManagerThreadLocal = new ThreadLocal<>();

    public ICommonDriver digitalPharmacyPlatformFactory;
    public String storeId;
    public AppiumDriver appDriver;
    public RemoteWebDriver remoteWebDriver;
    public HomePage homePage;
    public DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    public BasePageApplicationManager basePageApplicationManager;
    private static ThreadLocal<TextValidationUtils> commonUtilsForData = new ThreadLocal<>();

    /**
     * getDigitalPharmacyMobileAppFactory method initialises platform factory according to the type of platform passed.
     * @param  platform : Possible values : ANDROID/ IOS/ WEB/ MOBILE_RESPONSIVE_WEB.
     * @return returns the implementation of ICommonDriver.
     *
     * @Author: Saloni Sharma
     */
    public ICommonDriver getDigitalPharmacyMobileAppFactory(String platform) {
        if (platformFactoryThreadLocal.get() == null) {
            switch (platform) {
                case "ANDROID":
                    platformFactoryThreadLocal.set(new DigitalPharmacyAndroidPlatformManager());
                    break;
                case "IOS":
                    platformFactoryThreadLocal.set(new DigitalPharmacyIOSPlatformManager());
                    break;
                case "WEB":
                    platformFactoryThreadLocal.set(new DigitalPharmacyWebPlatformManager());
                    break;
                case "MOBILE_RESPONSIVE_WEB":
                    platformFactoryThreadLocal.set(new DigitalPharmacyMobileResponsiveWebPlatformManager());
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported platform: " + platform);
            }
        }
        return platformFactoryThreadLocal.get();
    }

    /**
     * For parallel TestNG runs, avoid depending on shared instance state (like a mutable "platform" field)
     * when quitting drivers. The current thread's platform factory is stored in {@link #platformFactoryThreadLocal}.
     */
    public void quitCurrentDriver() {
        ICommonDriver factory = platformFactoryThreadLocal.get();
        if (factory != null) {
            factory.quitDriver();
        }
    }

    public TextValidationUtils getCommonUtils() {
        if (commonUtilsForData.get() == null) {
            commonUtilsForData.set(new TextValidationUtils());


        }
        return commonUtilsForData.get();
    }

    /**
     * getPageApplicationManager method initialises page factory according to the type of platform passed.
     * @param  platform : Possible values : ANDROID/ IOS/ WEB/ MOBILE_RESPONSIVE_WEB.
     * @param  driver : this is the RemoteWebDriver initialised acc to platform type.
     * @return returns BasePageApplicationManager acc to platform type.
     *
     * @Author: Saloni Sharma
     */

    public BasePageApplicationManager getPageApplicationManager(String platform, RemoteWebDriver driver) {
        if (driver == null) {
            throw new IllegalStateException("Driver is null for platform=" + platform + ". Platform launch likely failed.");
        }
        if (basePageApplicationManagerThreadLocal.get() == null) {
            BasePageApplicationManager pageManager = null;
            switch (platform) {
                case "ANDROID":
                    pageManager = new AndroidPageManager(driver, platform);
                    basePageApplicationManagerThreadLocal.set(pageManager);
                    // Automatically wait for app to load for mobile platforms
                    pageManager.waitForAppToLoad();
                    break;

                case "IOS":
                    pageManager = new IOSPageManager(driver, platform);
                    basePageApplicationManagerThreadLocal.set(pageManager);
                    // Automatically wait for app to load for mobile platforms
                    pageManager.waitForAppToLoad();
                    break;

                case "WEB":
                    basePageApplicationManagerThreadLocal.set(new WebPageManager(driver, platform));
                    break;

                case "MOBILE_RESPONSIVE_WEB":
                    basePageApplicationManagerThreadLocal.set(new MobileResponsiveWebPageManager(driver, platform));
                    break;

                default:
                    throw new IllegalArgumentException("Unsupported platform: " + platform);
            }
        }
        return basePageApplicationManagerThreadLocal.get();
    }

    public BasePageApplicationManager getBasePageApplicationManager() {
        return basePageApplicationManagerThreadLocal.get();
    }


    public void removeManagers() {
        basePageApplicationManagerThreadLocal.remove();
        platformFactoryThreadLocal.remove();
        commonUtilsForData.remove();
    }
}