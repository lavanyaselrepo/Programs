package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Fill {

	public int rxNbr;
    public String drugName;
    public int rxFillId;
    public boolean labelReprintInd;
    public int fillDispenseMethod;
    public int dispenseStatus;
    public int cancellationReason;
    public int patientId;
}
