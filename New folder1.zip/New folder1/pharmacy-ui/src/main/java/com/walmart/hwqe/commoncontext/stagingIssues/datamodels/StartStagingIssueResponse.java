package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;
import java.util.ArrayList;

import lombok.*;

@Getter
@Setter
public class StartStagingIssueResponse {

	public String omsOrderId;
    public String purchaseOrderId;
    public int phmPackageId;
    public int itemsCount;
    public int poStatus;
    public int issueTypeCode;
    public String slotDueTime;
    public String displaySlotStartTime;
    public String displaySlotEndTime;
    public String customerFirstName;
    public String customerLastName;
    public DeliveryInfo deliveryInfo;
    public ArrayList<PackageToteInfo> packageToteInfo;
    public ArrayList<RxPatientInfo> rxPatientInfo;
}
