package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;

import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class PrescriptionsToTransferDetailsPage extends MobileBasePage {

    @FindBy(xpath = "//div[contains(@class,'b f4 nowrap overflow-hidden')]")
    @iOSXCUITFindBy(accessibility = "HWTitleDescriptionAndLinkButtonView.titleLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_name")
    private WebElement drugNameToTransfer;

    @FindBy(xpath = "//span[contains(@class,'gray f6')]")
    @iOSXCUITFindBy(accessibility = "HWTitleDescriptionAndLinkButtonView.descriptionLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_number")
    private WebElement rxNoToTransfer;

    @FindBy(xpath = "//button[text()='Continue']")
    @iOSXCUITFindBy(accessibility = "HWPrimaryStickyButton.primaryActionButton")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    private WebElement continueButton;

    @FindBy(xpath = "//button[text()='Find my insurance']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=\"Find my insurance\"]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/find_my_insurance_btn")
    private WebElement findMyInsurance;

    @FindBy(xpath = "//button[text()='Skip insurance']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=\"Skip insurance\"]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/skip_insurance_btn")
    private WebElement skipInsurance;

    public PrescriptionsToTransferDetailsPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getDrugNameToTransfer() {
        return getText(drugNameToTransfer);
    }

    public String getRxNoToTransfer() {
        return getText(rxNoToTransfer);
    }

    public void clickContinueButton(){
        waitForElementToBeClickable(continueButton, "Continue button");
        click(continueButton);
    }

    public void clickFindMyInsurance(){click(findMyInsurance);}

    public void clickSkipInsurance(){ unblockingClick(skipInsurance, 2, "Skip Insurance"); }
}
