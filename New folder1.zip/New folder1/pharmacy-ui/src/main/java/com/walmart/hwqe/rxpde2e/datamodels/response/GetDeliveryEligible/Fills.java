package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class Fills {
    public ArrayList<Delayed> delayed;
    public ArrayList<ReadyForPickup> readyForPickup;
}
