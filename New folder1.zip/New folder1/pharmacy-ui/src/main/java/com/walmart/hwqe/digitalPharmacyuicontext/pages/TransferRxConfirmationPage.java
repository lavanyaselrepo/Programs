package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class TransferRxConfirmationPage extends MobileBasePage {

    public TransferRxConfirmationPage(RemoteWebDriver driver) {
            super(driver);
    }

    @AndroidFindBy(id = "com.walmart.android.debug:id/coming_soon_primary_message")
    public WebElement receivedTransferRxRequestMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_prescription_number")
    public WebElement transferredRxNo;

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_from_pharmacy_name")
    public WebElement transferFromPharmacyName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_to_pharmacy_address")
    public WebElement transferToPharmacyAddress;

    @AndroidFindBy(id = "com.walmart.android.debug:id/done_button_layout")
    @iOSXCUITFindBy(accessibility = "TransferConfirmationController.LinkActionView.cta")
    @FindBy(xpath = "//button[text()='Done']")
    public WebElement doneButton;

    public String getReceivedTransferRxRequestMessage() {

        return getText(receivedTransferRxRequestMessage);
    }

    public String getTransferredRxNo() {

        return getText(transferredRxNo);
    }

    public String getTransferFromPharmacyName() {

        return getText(transferFromPharmacyName);
    }

    public String getTransferToPharmacyAddress() {

        return getText(transferToPharmacyAddress);
    }

    public void clickDoneButton() {

       click(doneButton);
    }
}
