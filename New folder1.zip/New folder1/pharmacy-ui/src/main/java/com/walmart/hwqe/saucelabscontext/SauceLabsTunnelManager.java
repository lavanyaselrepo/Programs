/**
 * SauceLabsTunnelManager is the singleton class responsible for managing Sauce Labs tunnels.
 *
 * @Author: Rishi Pandey
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */

package com.walmart.hwqe.saucelabscontext;


import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class SauceLabsTunnelManager {
    private static SauceLabsTunnelManager instance;
    private static String sauceTunnelId;
    private static final List<String> tunnelIdentifiers = new ArrayList<>();
    private static final Object lock = new Object();
    private PropertyReader prop = PropertyReaderHelper.getInstance();
    private AutomationManager am = AutomationManager.getInstance();

    // Private constructor to prevent instantiation
    private SauceLabsTunnelManager() {}

    // Get the singleton instance
    public static SauceLabsTunnelManager getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new SauceLabsTunnelManager();
                }
            }
        }
        return instance;
    }

    // Establish a Sauce Labs tunnel and return the tunnel ID - Not local Tunnels are Deprecated
    // Get or create the Sauce Labs tunnel ID
    /*public String getSauceLabsTunnelID() {
        if (sauceTunnelId == null) {
            synchronized (lock) {
                if (sauceTunnelId == null) { // Double-checked locking
                    String tempTunnelId = "sauce-tunnel-established" + new Random().nextInt(100000);
                    AtomicBoolean tunnelUp = new AtomicBoolean(false); // Shared flag
                    try {
                        String sauceUserName = prop.getProperty("z.run.sl.un");
                        String sauceAccessKey = prop.getProperty("z.run.sl.ak");
                        String scBinaryPath = "src/main/resources/sauce-connect-5.2.3_linux.x86_64/sc";
                        String startSauceLabsTunnelCommand = scBinaryPath + " run -u " + sauceUserName + " -k " + sauceAccessKey +
                                " --region us-west --tunnel-name " + tempTunnelId;
                        Process process = Runtime.getRuntime().exec(startSauceLabsTunnelCommand);

                        // Start a thread to monitor the process output
                        new Thread(() -> {
                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    log.info(line); // Log the output
                                    if (line.contains("Sauce Connect is up, you may start your tests")) {
                                        tunnelUp.set(true); // Set the flag when the tunnel is up
                                        log.info("SauceLabsTunnel Established: " + tempTunnelId);
                                        Reporter.log("SauceLabsTunnel Established: " + tempTunnelId);
                                    }
                                }
                            } catch (IOException e) {
                                log.error("Error reading Sauce Connect process output: " + e.getMessage());
                            }
                        }).start();

                        // Wait for the tunnel to be up or timeout
                        long startTime = System.currentTimeMillis();
                        long timeout = 5 * 60 * 1000; // 5 minutes in milliseconds
                        while (!tunnelUp.get()) {
                            if (System.currentTimeMillis() - startTime > timeout) {
                                throw new RuntimeException("Timeout while waiting for Sauce Connect tunnel to establish.");
                            }
                            Thread.sleep(500); // Poll every 500ms
                        }

                        // Assign the tunnel ID after successful verification
                        sauceTunnelId = tempTunnelId;

                        // Keep the process alive in a separate thread
                        new Thread(() -> {
                            try {
                                int exitCode = process.waitFor(); // Wait for the process to complete
                                if (exitCode != 0) {
                                    log.error("Sauce Connect process exited with code: " + exitCode);
                                    Reporter.log("Sauce Connect process exited with code: " + exitCode);
                                }
                            } catch (InterruptedException e) {
                                Thread.currentThread().interrupt();
                                log.error("Sauce Connect process was interrupted: " + e.getMessage());
                                Reporter.log("Sauce Connect process was interrupted: " + e.getMessage());
                            }
                        }).start();

                        Reporter.log("Sauce Connect process is running in the background with Tunnel Id: " + sauceTunnelId);

                    } catch (IOException | InterruptedException e) {
                        throw new RuntimeException("Error while establishing Sauce Labs tunnel: " + e.getMessage(), e);
                    }
                }
            }
        }
        return sauceTunnelId;
    }*/

    // Establish a Custom Sauce Labs Tunnel and return the tunnel ID
    public String getSauceLabsTunnelID() {
        if (sauceTunnelId == null) {
            synchronized (lock) {
                if (sauceTunnelId == null) { // Double-checked locking
                    try {
                        // Read the tunnel-name from the config.yaml file
                        String configFilePath = "src/main/resources/config/config.yaml";
                        String tunnelName = null;

                        try (BufferedReader reader = new BufferedReader(new FileReader(configFilePath))) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                if (line.trim().startsWith("tunnel-name:")) {
                                    tunnelName = line.split(":", 2)[1].trim();
                                    break;
                                }
                            }
                        }

                        if (tunnelName == null || tunnelName.isEmpty()) {
                            throw new RuntimeException("tunnel-name not found in config.yaml");
                        }

                        String scriptPath = "src/main/resources/shellScripts/startTunnel.sh";

                        // Construct the command to run the script
                        String[] command = {"/bin/sh", scriptPath};

                        // Set environment variables
                        Process process = Runtime.getRuntime().exec(command, new String[] {
                            "SAUCE_USERNAME=" + prop.getProperty("z.run.sl.un"),
                            "SAUCE_ACCESS_KEY=" + prop.getProperty("z.run.sl.ak"),
                            "TUNNEL_CONFIG=src/main/resources/config/config.yaml"
                        });

                        Reporter.log("Started Sauce Connect tunnel process with command: /bin/sh " + scriptPath);

                        // Monitor the process output for 1 minute
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                            String line;
                            long startTime = System.currentTimeMillis();
                            long timeout = 60 * 1000; // 1 minute in milliseconds

                            while ((line = reader.readLine()) != null) {
                                Reporter.log(line);

                                // Check for individual tunnel running logs
                                if (line.matches("Tunnel .* is running.")) {
                                    String identifier = line.split(" ")[1];
                                    synchronized (lock) {
                                        tunnelIdentifiers.add(identifier);
                                    }
                                    Reporter.log("Tunnel Identifier Added: " + identifier);
                                }

                                // Check for all tunnels running log
                                if (line.contains("All tunnels are running.")) {
                                    synchronized (lock) {
                                        sauceTunnelId = tunnelName;
                                    }
                                    Reporter.log("SauceLabsTunnel Established with ID: " + sauceTunnelId);
                                    break;
                                }

                                // Check for timeout
                                if (System.currentTimeMillis() - startTime > timeout) {
                                    Reporter.log("Timeout reached while waiting for tunnels to be established.");
                                    process.destroy();
                                    throw new RuntimeException("Timeout while waiting for Sauce Connect tunnel to establish.");
                                }
                            }
                        }

                    } catch (IOException e) {
                        throw new RuntimeException("Error while establishing Sauce Labs tunnel: " + e.getMessage(), e);
                    }
                }
            }
        }
        return sauceTunnelId;
    }

    public List<String> getTunnelIdentifiers() {
        synchronized (lock) {
            return new ArrayList<>(tunnelIdentifiers);
        }
    }

    // clean up Sauce Labs Custom Tunnels
    public Boolean cleanUpSauceTunnels() {
        synchronized (lock) {
            if (tunnelIdentifiers.isEmpty()) {
                Reporter.log("No tunnels to clean up.");
                return false;
            }

            try {
                String scriptPath = "src/main/resources/shellScripts/stopTunnel.sh";
                String activeTunnelsPath = "src/main/resources/shellScripts/active-tunnels.txt";
                String username = prop.getProperty("z.run.sl.un");
                String accessKey = prop.getProperty("z.run.sl.ak");

                // Construct the command to run the stopTunnel.sh script
                String[] command = {"/bin/sh", scriptPath, activeTunnelsPath, username, accessKey};

                Reporter.log("Executing stopTunnel.sh script to clean up tunnels.");
                Process process = Runtime.getRuntime().exec(command);

                // Monitor the process output
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                     BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                    String line;

                    while ((line = reader.readLine()) != null) {
                        Reporter.log(line);
                    }

                    while ((line = errorReader.readLine()) != null) {
                        Reporter.log("ERROR: " + line);
                    }

                    int exitCode = process.waitFor();
                    if (exitCode == 0) {
                        Reporter.log("stopTunnel.sh executed successfully.");
                    } else {
                        Reporter.log("stopTunnel.sh exited with error code: " + exitCode);
                        return false;
                    }
                }

                // Clear the tunnel identifiers after cleanup
                tunnelIdentifiers.clear();
                sauceTunnelId = null; // Reset the tunnel ID after cleanup
                return true;

            } catch (Exception e) {
                Reporter.log("Error while executing stopTunnel.sh: " + e.getMessage());
                return false;
            }
        }
    }
}
