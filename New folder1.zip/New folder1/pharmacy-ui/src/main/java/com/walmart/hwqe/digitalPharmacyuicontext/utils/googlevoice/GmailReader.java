package com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice;

import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePartHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility for reading emails from the Gmail inbox (normandmark268@gmail.com).
 *
 * Uses the Gmail REST API with OAuth2 — no IMAP/SMTP required.
 * All methods are static and safe to call from TestNG test methods.
 *
 * Common use cases in test automation:
 * <ul>
 *   <li>Read OTP / verification codes delivered by email</li>
 *   <li>Verify registration confirmation emails were received</li>
 *   <li>Read pharmacy notification emails</li>
 *   <li>Wait for transactional emails with retry/timeout logic</li>
 * </ul>
 *
 * Prerequisites:
 * <ol>
 *   <li>Enable Gmail API in Google Cloud Console</li>
 *   <li>Place credentials.json at: pharmacy-ui/src/test/resources/google_voice/credentials.json</li>
 *   <li>Run {@link SaveGoogleVoiceSession} once to generate the OAuth token</li>
 * </ol>
 *
 * See: pharmacy-ui/src/test/resources/google_voice/README_GOOGLE_VOICE.md
 */
public class GmailReader {

    private static final Logger log = LogManager.getLogger(GmailReader.class);
    private static final String GMAIL_USER = "me";

    // ══════════════════════════════════════════════════════════════════════════
    // FIND / LIST EMAILS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Returns the most recent email matching the given Gmail search query.
     *
     * <p>Gmail query examples:
     * <ul>
     *   <li>{@code from:noreply@walmart.com subject:"Your prescription"}</li>
     *   <li>{@code subject:"verification code" is:unread}</li>
     *   <li>{@code to:normandmark268@gmail.com subject:"Welcome"}</li>
     * </ul>
     *
     * @param gmailQuery Gmail search query string
     * @return EmailMessage containing subject, body, sender, and headers
     * @throws RuntimeException if no matching email is found
     */
    public static EmailMessage getLatestEmail(String gmailQuery) throws Exception {
        Gmail service = GoogleVoiceUtil.buildGmailService();
        log.info("Gmail query: {}", gmailQuery);

        List<Message> messages = service.users().messages()
                .list(GMAIL_USER)
                .setQ(gmailQuery)
                .setMaxResults(1L)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            throw new RuntimeException("No email found matching query: " + gmailQuery);
        }

        return fetchAndBuild(service, messages.get(0).getId());
    }

    /**
     * Returns up to {@code maxResults} emails matching the given Gmail search query,
     * most recent first.
     *
     * @param gmailQuery  Gmail search query string
     * @param maxResults  maximum number of emails to return
     * @return list of matching emails, most recent first
     */
    public static List<EmailMessage> getEmails(String gmailQuery, int maxResults) throws Exception {
        Gmail service = GoogleVoiceUtil.buildGmailService();
        log.info("Gmail query (max {}): {}", maxResults, gmailQuery);

        List<Message> messages = service.users().messages()
                .list(GMAIL_USER)
                .setQ(gmailQuery)
                .setMaxResults((long) maxResults)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            log.info("No emails found matching query: {}", gmailQuery);
            return Collections.emptyList();
        }

        java.util.List<EmailMessage> result = new java.util.ArrayList<>();
        for (Message msg : messages) {
            result.add(fetchAndBuild(service, msg.getId()));
        }
        return result;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // WAIT / POLL FOR EMAIL
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Polls Gmail until an email matching the query arrives, or throws on timeout.
     *
     * @param gmailQuery      Gmail search query
     * @param timeoutMs       maximum wait time in milliseconds
     * @param pollIntervalMs  polling interval in milliseconds
     * @return the matching email once found
     */
    public static EmailMessage waitForEmail(String gmailQuery, long timeoutMs,
                                             long pollIntervalMs) throws Exception {
        log.info("Waiting up to {}ms for email matching: {}", timeoutMs, gmailQuery);
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            try {
                return getLatestEmail(gmailQuery);
            } catch (Exception e) {
                log.debug("Email not yet available: {}", e.getMessage());
            }
            Thread.sleep(pollIntervalMs);
        }
        throw new RuntimeException(String.format(
                "Timed out after %dms waiting for email matching: %s", timeoutMs, gmailQuery));
    }

    /**
     * Convenience overload using default timeouts from {@link GoogleVoiceConfig}.
     */
    public static EmailMessage waitForEmail(String gmailQuery) throws Exception {
        return waitForEmail(gmailQuery,
                GoogleVoiceConfig.DEFAULT_TIMEOUT_MS,
                GoogleVoiceConfig.DEFAULT_POLL_INTERVAL_MS);
    }

    /**
     * Waits for an email from a specific sender with a specific subject.
     *
     * @param fromAddress sender email address, e.g. "noreply@walmart.com"
     * @param subject     subject keyword or exact subject
     * @return the matching email
     */
    public static EmailMessage waitForEmailFrom(String fromAddress, String subject) throws Exception {
        String query = "from:" + fromAddress + " subject:\"" + subject + "\"";
        return waitForEmail(query);
    }

    /**
     * Waits for an email containing the given text in its body.
     *
     * @param bodyText  substring to look for in the email body
     * @return the matching email
     */
    public static EmailMessage waitForEmailContaining(String bodyText) throws Exception {
        return waitForEmail(bodyText);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // OTP / CODE EXTRACTION
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Waits for a verification / OTP email and extracts the numeric code.
     *
     * @param gmailQuery  query to find the OTP email (e.g. {@code subject:"verification code"})
     * @param digits      expected number of digits in the code (typically 6)
     * @return the extracted numeric OTP string
     */
    public static String waitForEmailOtp(String gmailQuery, int digits) throws Exception {
        EmailMessage email = waitForEmail(gmailQuery);
        return extractOtpFromText(email.getBody(), digits);
    }

    /**
     * Extracts the first occurrence of an N-digit numeric code from the given text.
     *
     * @param text    email body or subject text
     * @param digits  expected code length
     * @return the extracted code
     */
    public static String extractOtpFromText(String text, int digits) {
        Pattern pattern = Pattern.compile("\\b(\\d{" + digits + "})\\b");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        throw new RuntimeException(
                "Could not extract " + digits + "-digit code from text: " + text);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SUBJECT / SENDER HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Checks whether at least one email matching the query exists in the inbox.
     * Does not throw — returns false if no emails are found.
     */
    public static boolean emailExists(String gmailQuery) {
        try {
            getLatestEmail(gmailQuery);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the subject of the latest email matching the query.
     */
    public static String getLatestEmailSubject(String gmailQuery) throws Exception {
        return getLatestEmail(gmailQuery).getSubject();
    }

    /**
     * Returns the plain-text body of the latest email matching the query.
     */
    public static String getLatestEmailBody(String gmailQuery) throws Exception {
        return getLatestEmail(gmailQuery).getBody();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL
    // ══════════════════════════════════════════════════════════════════════════

    private static EmailMessage fetchAndBuild(Gmail service, String messageId) throws Exception {
        Message full = service.users().messages()
                .get(GMAIL_USER, messageId)
                .setFormat("full")
                .execute();

        String subject  = getHeader(full, "Subject").orElse("(no subject)");
        String from     = getHeader(full, "From").orElse("(unknown sender)");
        String date     = getHeader(full, "Date").orElse("");
        String body     = GoogleVoiceUtil.extractTextBody(full);
        long   received = full.getInternalDate() != null ? full.getInternalDate() : 0L;

        log.debug("Email fetched — From: {}, Subject: {}", from, subject);
        return new EmailMessage(messageId, from, subject, date, body, received);
    }

    private static Optional<String> getHeader(Message message, String headerName) {
        if (message.getPayload() == null || message.getPayload().getHeaders() == null) {
            return Optional.empty();
        }
        return message.getPayload().getHeaders().stream()
                .filter(h -> headerName.equalsIgnoreCase(h.getName()))
                .map(MessagePartHeader::getValue)
                .findFirst();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // VALUE OBJECT
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Immutable data object representing a fetched Gmail message.
     */
    public static final class EmailMessage {

        private final String messageId;
        private final String from;
        private final String subject;
        private final String date;
        private final String body;
        private final long receivedTimestampMs;

        public EmailMessage(String messageId, String from, String subject,
                            String date, String body, long receivedTimestampMs) {
            this.messageId = messageId;
            this.from = from;
            this.subject = subject;
            this.date = date;
            this.body = body;
            this.receivedTimestampMs = receivedTimestampMs;
        }

        public String getMessageId()          { return messageId; }
        public String getFrom()               { return from; }
        public String getSubject()            { return subject; }
        public String getDate()               { return date; }
        public String getBody()               { return body; }
        public long   getReceivedTimestampMs(){ return receivedTimestampMs; }

        /** Returns true if the body contains the given substring (case-sensitive). */
        public boolean bodyContains(String text) {
            return body != null && body.contains(text);
        }

        /** Returns true if the subject contains the given substring (case-insensitive). */
        public boolean subjectContains(String text) {
            return subject != null && subject.toLowerCase().contains(text.toLowerCase());
        }

        @Override
        public String toString() {
            return String.format("EmailMessage{from='%s', subject='%s', receivedMs=%d}",
                    from, subject, receivedTimestampMs);
        }
    }
}
