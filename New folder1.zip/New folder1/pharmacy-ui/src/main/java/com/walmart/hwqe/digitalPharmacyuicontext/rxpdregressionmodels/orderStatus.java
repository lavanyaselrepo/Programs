package com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels;

public final class orderStatus {
    public static final String popc_in_progress = "PO Pick in Progress";
    public static final String popc_complete = "PO Pick Complete";
    public static final String out_for_delivery = "PO Out for Delivery";
    public static final String delivered = "Delivered";
}
