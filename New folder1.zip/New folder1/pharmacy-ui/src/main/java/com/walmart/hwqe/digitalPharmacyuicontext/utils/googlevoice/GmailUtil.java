package com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice;

import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * General-purpose Gmail reading utility — supports multiple accounts.
 *
 * Default account methods (use the account configured in GOOGLE_VOICE_EMAIL):
 *   GmailUtil.getLatestEmail("from:walmart.com")
 *
 * Specific account methods (for multi-account CI/CD):
 *   GmailUtil.forAccount("testuser42@gmail.com").getLatestEmail("from:walmart.com")
 *
 * All methods are CI/CD safe — Gmail API only, no browser needed.
 */
public class GmailUtil {

    private static final Logger log = LogManager.getLogger(GmailUtil.class);
    private static final String GMAIL_USER = "me";

    private final Gmail service;

    private GmailUtil(Gmail service) {
        this.service = service;
    }

    /**
     * Creates a GmailUtil instance for a specific account.
     * Each account must have credentials.json and tokens/ set up in its directory.
     *
     * Usage:
     *   GmailUtil gmail = GmailUtil.forAccount("testuser42@gmail.com");
     *   String body = gmail.getLatestEmail("from:walmart.com");
     *
     * @param account email address, e.g. "testuser42@gmail.com"
     */
    public static GmailUtil forAccount(String account) throws Exception {
        Gmail service = GoogleVoiceUtil.buildGmailServiceForAccount(account);
        return new GmailUtil(service);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STATIC METHODS — use the default account
    // ══════════════════════════════════════════════════════════════════════════

    public static String getLatestEmail(String query) throws Exception {
        return fetchLatestEmail(GoogleVoiceUtil.buildGmailService(), query);
    }

    public static String getLatestPrimaryEmail() throws Exception {
        return getLatestEmail("category:primary -from:txt.voice.google.com");
    }

    public static String getLatestPrimaryEmailFrom(String fromAddress) throws Exception {
        return getLatestEmail("category:primary from:" + fromAddress);
    }

    public static String getLatestEmailFrom(String fromAddress) throws Exception {
        return getLatestEmail("from:" + fromAddress);
    }

    public static String getLatestEmailFrom(String fromAddress, String subject) throws Exception {
        return getLatestEmail("from:" + fromAddress + " subject:\"" + subject + "\"");
    }

    public static String getLatestEmailSubject(String query) throws Exception {
        return fetchLatestEmailSubject(GoogleVoiceUtil.buildGmailService(), query);
    }

    public static String waitForEmailContaining(String query, String expectedText,
                                                 long timeoutMs, long pollIntervalMs) throws Exception {
        return pollForEmail(GoogleVoiceUtil.buildGmailService(), query, expectedText, timeoutMs, pollIntervalMs);
    }

    public static String waitForEmailFromContaining(String fromAddress, String expectedText,
                                                     long timeoutMs, long pollIntervalMs) throws Exception {
        return waitForEmailContaining("from:" + fromAddress, expectedText, timeoutMs, pollIntervalMs);
    }

    public static String waitForEmailFromContaining(String fromAddress, String expectedText) throws Exception {
        return waitForEmailFromContaining(fromAddress, expectedText,
                GoogleVoiceConfig.DEFAULT_TIMEOUT_MS,
                GoogleVoiceConfig.DEFAULT_POLL_INTERVAL_MS);
    }

    public static String waitForOtp(String fromAddress, int otpDigits) throws Exception {
        String body = waitForEmailFromContaining(fromAddress, "");
        return extractOtp(body, otpDigits);
    }

    public static String waitForOtp(String query, int otpDigits,
                                     long timeoutMs, long pollIntervalMs) throws Exception {
        String body = waitForEmailContaining(query, "", timeoutMs, pollIntervalMs);
        return extractOtp(body, otpDigits);
    }

    public static String waitForLink(String fromAddress, String urlContains) throws Exception {
        String body = waitForEmailFromContaining(fromAddress, urlContains);
        return extractLink(body, urlContains);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INSTANCE METHODS — use the account specified in forAccount()
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Reads the latest email matching the query from this account's inbox.
     */
    public String readLatestEmail(String query) throws Exception {
        return fetchLatestEmail(service, query);
    }

    public String readLatestEmailFrom(String fromAddress) throws Exception {
        return readLatestEmail("from:" + fromAddress);
    }

    public String readLatestEmailFrom(String fromAddress, String subject) throws Exception {
        return readLatestEmail("from:" + fromAddress + " subject:\"" + subject + "\"");
    }

    public String readLatestPrimaryEmail() throws Exception {
        return readLatestEmail("category:primary -from:txt.voice.google.com");
    }

    public String readLatestEmailSubject(String query) throws Exception {
        return fetchLatestEmailSubject(service, query);
    }

    /**
     * Polls this account's inbox until an email containing expectedText arrives.
     */
    public String readEmailContaining(String query, String expectedText,
                                       long timeoutMs, long pollIntervalMs) throws Exception {
        return pollForEmail(service, query, expectedText, timeoutMs, pollIntervalMs);
    }

    public String readEmailFromContaining(String fromAddress, String expectedText) throws Exception {
        return readEmailContaining("from:" + fromAddress, expectedText,
                GoogleVoiceConfig.DEFAULT_TIMEOUT_MS,
                GoogleVoiceConfig.DEFAULT_POLL_INTERVAL_MS);
    }

    public String readOtp(String fromAddress, int otpDigits) throws Exception {
        String body = readEmailFromContaining(fromAddress, "");
        return extractOtp(body, otpDigits);
    }

    public String readLink(String fromAddress, String urlContains) throws Exception {
        String body = readEmailFromContaining(fromAddress, urlContains);
        return extractLink(body, urlContains);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SHARED TEXT EXTRACTION (static — work on any email body)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Extracts the first N-digit OTP code from an email body.
     */
    public static String extractOtp(String emailBody, int digits) {
        Pattern pattern = Pattern.compile("\\b(\\d{" + digits + "})\\b");
        Matcher matcher = pattern.matcher(emailBody);
        if (matcher.find()) {
            return matcher.group(1);
        }
        throw new RuntimeException(
                "Could not extract " + digits + "-digit OTP from email body: " + emailBody);
    }

    /**
     * Extracts the first URL containing the given substring from an email body.
     */
    public static String extractLink(String emailBody, String urlContains) {
        Pattern pattern = Pattern.compile("https?://[^\\s<>\"]+");
        Matcher matcher = pattern.matcher(emailBody);
        while (matcher.find()) {
            String url = matcher.group();
            if (url.contains(urlContains)) {
                return url;
            }
        }
        throw new RuntimeException(
                "No URL containing '" + urlContains + "' found in email body");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private static String fetchLatestEmail(Gmail gmail, String query) throws Exception {
        log.info("Gmail query: {}", query);

        List<Message> messages = gmail.users().messages()
                .list(GMAIL_USER)
                .setQ(query)
                .setMaxResults(1L)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            throw new RuntimeException("No email found for query: " + query);
        }

        Message full = gmail.users().messages()
                .get(GMAIL_USER, messages.get(0).getId())
                .setFormat("full")
                .execute();

        String body = GoogleVoiceUtil.extractTextBody(full);
        log.info("Email body (truncated): {}", body.length() > 200 ? body.substring(0, 200) + "..." : body);
        return body;
    }

    private static String fetchLatestEmailSubject(Gmail gmail, String query) throws Exception {
        List<Message> messages = gmail.users().messages()
                .list(GMAIL_USER)
                .setQ(query)
                .setMaxResults(1L)
                .execute()
                .getMessages();

        if (messages == null || messages.isEmpty()) {
            throw new RuntimeException("No email found for query: " + query);
        }

        Message full = gmail.users().messages()
                .get(GMAIL_USER, messages.get(0).getId())
                .setFormat("full")
                .execute();

        return GoogleVoiceUtil.getHeader(full, "Subject");
    }

    private static String pollForEmail(Gmail gmail, String query, String expectedText,
                                        long timeoutMs, long pollIntervalMs) throws Exception {
        log.info("Waiting up to {}ms for email matching '{}' containing '{}'",
                timeoutMs, query, expectedText);
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            try {
                String body = fetchLatestEmail(gmail, query);
                if (body.contains(expectedText)) {
                    log.info("Email matched: {}", expectedText);
                    return body;
                }
            } catch (Exception e) {
                log.debug("Email not yet available: {}", e.getMessage());
            }
            Thread.sleep(pollIntervalMs);
        }
        throw new RuntimeException(String.format(
                "Timed out after %dms waiting for email containing '%s' (query: %s)",
                timeoutMs, expectedText, query));
    }
}
