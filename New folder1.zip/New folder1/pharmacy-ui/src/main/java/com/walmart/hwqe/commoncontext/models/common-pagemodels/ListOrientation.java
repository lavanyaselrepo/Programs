package com.walmart.hwqe.commoncontext.models.pagemodels.common;

public enum ListOrientation {
    Vertical, Horizontal;
}