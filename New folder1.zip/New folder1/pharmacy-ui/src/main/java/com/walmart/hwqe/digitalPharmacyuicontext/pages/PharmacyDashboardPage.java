package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import java.time.Duration;
import java.util.List;

public class PharmacyDashboardPage extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Pharmacy']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Pharmacy']")
    @FindBy(xpath = "(//a[contains(text(), 'Pharmacy')])[1]")
    public WebElement pharmacyButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Popular Services']")
    public WebElement popularServicesText;

    @AndroidFindBy(accessibility = "Close, My Items information")
    public WebElement myItemsCloseButton;
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/service_item_title' and @text='Scan to refill']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Home.ServicesItemSubtitle' and @label='Scan your Walmart Rx label to refill.']")
    @FindBy(xpath = "//button[text()='Refill']")
    public WebElement scanToRefill;

    // for Web there is no 'scan to refill' so refill prescriptions tab is used
    @FindBy(xpath = "(//button[contains(text(), 'Pharmacy')])[1]")
    public WebElement pharmacyOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_cancel_button")
    public WebElement getNotificationsMaybeLaterButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_cancel_button")
    public WebElement biometricsPermissionButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/marketing_privacy_bottom_sheet_deny_btn")
    public WebElement personaliseShoppingExperienceButton;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='Accept and Continue']")
    @iOSXCUITFindBy(accessibility = "Accept and continue")
    @FindBy(xpath = "//button[text()='Accept and Continue']")
    public WebElement acceptPrivacyPracticesButton;

    // In-app location re-confirmation dialog — appears on real devices when app state is preserved (noReset=true)
    @AndroidFindBy(xpath = "//*[@text='Continue sharing precise location']")
    public WebElement continueLocationSharingButton;

    @AndroidFindBy(xpath = "//*[@text='Stop sharing precise location']")
    public WebElement stopLocationSharingButton;

    @AndroidFindBy(xpath = "//*[@text='Try again']")
    public WebElement tryAgainButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Refill Prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Refill Prescriptions']")
    @FindBy(xpath = "//button[text()='Refill']")
    public WebElement myPrescriptionsTab;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Transfer prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Transfer prescriptions']")
    @FindBy(xpath = "//*[text()='Transfer']")
    public WebElement transferPrescriptionsTab;

    // iOS: confirmed live — PIN screen uses XCUIElementTypeKey keypad, not a text field.
    @AndroidFindBy(id = "com.walmart.android.debug:id/keypadNum1")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeKey' AND name == '1'")
    @FindBy(xpath = "//input[contains(@id,'input-verificationCode')]")
    public WebElement pinInput;

    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    public WebElement inputPinText;

    @iOSXCUITFindBy(accessibility = "PINView.ctaButton")
    @FindBy(xpath = "//button[text()='Confirm PIN']")
    public WebElement confirmPin;

    @FindBy(xpath = "//input[contains(@id,'input-verificationCode')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@name,'OTPTextField.otpCell')]")
    public List<WebElement> pinInputs;

    @FindBy(xpath = "//button[text()='Verify PIN']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='PINView.ctaButton']")
    public WebElement verifyPinButton;

    @FindBy(xpath = "//button[text()='Create PIN']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='PINView.ctaButton']")
    public WebElement createPinButton;

    @FindBy(xpath = "((//span[text()='How do you want your items?'])[1]/following::i)[1]")
    public WebElement closeAddressSelectionButton;

    @FindBy(xpath = "//button[contains(text(),'Refill')]")
    public WebElement easyRefill;

    @FindBy(xpath = "//button[contains(text(),'as guest')]")
    public WebElement refillAsGuestCTA;

    @FindBy(xpath = "//span[text()='How do you want your items?'][1]")
    public WebElement minimizePickupOptionPopUp;

    @FindBy(xpath = "//span[text()='How do you want your items?'][2]")
    public WebElement minimizePickupOptionPopUp2;

    @FindBy(xpath = "//button[text()='No, refill as guest']")
    public WebElement refillAsGuest;

    @FindBy(xpath = "//button[text()='Acknowledge']")
    public WebElement acknowledgeBtn;

    @FindBy(xpath = "//div[text()='Pickup']")
    public WebElement pickupOption;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Manage insurance']")
    @iOSXCUITFindBy(accessibility = "Manage insurance. View, add & remove insurance")
    @FindBy(xpath = "//h3[text()='Manage my insurance']")
    public WebElement manageMyInsuranceCTA;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Schedule an Immunization']")
    @iOSXCUITFindBy(accessibility = "Schedule an Immunization")
    @FindBy(xpath = "//h3[text()='Schedule an Immunization']")
    public WebElement scheduleImmunizationCTA;

    //placeholder
    @iOSXCUITFindBy(accessibility = "CreateAccountConfirmationView.insuranceNudgeView")
    public WebElement addInsuranceNudgeContainer;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_card_header")
    @iOSXCUITFindBy(accessibility = "HWDashboardContainerView.titleLabel")
    @FindBy(xpath = "//h2[text()='Add your insurance']")
    public WebElement insuranceNudgeTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_card_header")
    @iOSXCUITFindBy(accessibility = "HWDashboardContainerView.titleLabel")
    @FindBy(xpath = "//div[contains(text(),'paying out')]/preceding-sibling::h2")
    public WebElement insuranceNudgeTitleDependent;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_card_body' and contains(@text,'paying out of pocket')]")
    @iOSXCUITFindBy(accessibility = "HWDashboardContainerView.descriptionLabel")
    @FindBy(xpath = "//div[contains(text(),'Add insurance')]")
    public WebElement insuranceNudgeDescription;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_card_button_primary")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='HWDashboardContainerView.primaryButton']")
    @FindBy(xpath = "//button[text()='Add insurance']")
    public WebElement addInsuranceNudgeCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_card_button_dismiss")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Dismiss']")
    @FindBy(xpath = "//button[text()='Dismiss']")
    public WebElement dismissInsuranceNudgeCTA;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='Not now']")
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonView.linkButton")
    @FindBy(xpath = "//button[text()='Close']")
    public WebElement closeDeliveryAvailablePopupButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/dismiss_btn")
    public WebElement accountBeingSetupDismissButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/atc_cta_close")
    @iOSXCUITFindBy(accessibility = "UnavailableItemsViewController.actionButton")
    WebElement atcFailureBottomSheetCloseCta;

    @AndroidFindBy(id = "com.walmart.android.debug:id/cart_summary_icon")
    @iOSXCUITFindBy(accessibility = "CartButton.buttonView")
    @FindBy(id = "cart-button-header")
    public WebElement commonCartButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/slots_recycler_view_item")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Pharmacy']")
    @FindBy(xpath = "(//a[contains(text(), 'Pharmacy')])[1]")
    public WebElement selectSlotButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/launch_action_btn")
    @iOSXCUITFindBy(accessibility = "Connect my account")
    @FindBy(xpath = "//a[text()='Connect my account']")
    public WebElement connectMyAccountCTA;

    @FindBy(xpath = "//button[text()='Close']")
    public WebElement pharmacyDeliveryAvailablePopUpCloseButton;

    @FindBy(xpath = "//*[contains(text(), 'Connect your account')]")
    @iOSXCUITFindBy(accessibility = "PharmacyAccountStatusPlaceholderView.titleLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_nudge_title")
    public WebElement accountUnconnectedHeaderText;

    @FindBy(xpath = "//h3[text()='Manage family prescriptions']")
    @AndroidFindBy(xpath = "//*[contains(@text,'Manage family members')]")
    public WebElement manageFamilyPrescriptionsHeaderText;

    @FindBy(xpath = "//button[text()='Re-send request']")
    private WebElement resendRequestBtn;

    @FindBy(xpath = "//button[text()='Cancel request']")
    private WebElement cancelRequestBtn;

    @FindBy(xpath = "//*[contains(text(),'Approval is pending for ')]")
    private WebElement approvalPendingTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Enter manually']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Enter prescription details manually']")
    private WebElement enterManuallyBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name='TextFieldStackView.textField' and @label='Prescription number* (7 digits)']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text='Prescription number (7-digits)*']")
    public WebElement prescriptionNumberTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name='TextFieldStackView.textField' and @label='Store number* (up to 5 digits)']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text='Store number (up to 4-digits)*']")
    public WebElement enterStoreDetails;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name='TextFieldStackView.textField' and @label='Date of birth* (mm/dd/yyyy)']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text='Date of birth (mm/dd/yyyy)*']")
    public WebElement enterDobDetails;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/continue_button']")
    @FindBy(xpath = "//button[text()='Continue']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Continue'])[1]")
    public WebElement clickContinue;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/continue_button']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Continue']")
    public WebElement clickContinueNotPopUp;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/continue_button']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Continue'])[2]")
    public WebElement clickContinueBtn;

    @iOSXCUITFindBy(accessibility = "Request refill")
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/place_order']")
    public WebElement clickRequestRefillButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='CheckCircle']")
    @AndroidFindBy(xpath = "//android.widget.ImageView[@resource-id='com.walmart.android.debug:id/pharmacy_order_confirmation_image']")
    public WebElement validateSuccessLogo;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Your refill request has been placed.']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_order_confirmation_header']")
    public WebElement validateSuccessText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='RefillRequestConfirmationViewController.Close']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Close button']")
    public WebElement closeButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='RefillRequestConfirmationViewController.Close']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Close button']")
    public WebElement feedbackCloseButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Close']")
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.android.permissioncontroller:id/permission_allow_one_time_button']")
    public WebElement clickOnlyThisTimeButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add Dog(P) to my account']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/add_fam_button")
    public WebElement clickAddFamilyMemberOption;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Home.ServicesItemTitle' and @label='Manage family members']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Manage family members']")
    public WebElement clickManageFamilyMember;

    @iOSXCUITFindBy(accessibility = "Remove")
    @AndroidFindBy(id = "com.walmart.android.debug:id/remove_dependent_btn")
    public WebElement clickRemoveOption;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Remove'])[2]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_cta")
    public WebElement clickRemoveButton;

    @iOSXCUITFindBy(accessibility = "ConnectAccountInfoContainerView.actionButton")
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/getStartedButton']")
    public WebElement clickGetStarted;

    @FindBy(xpath = "//a[@aria-label='Get Started to add prescriptions']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/service_item_title' and @text='Find Walmart prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Home.ServicesItemTitle' and @label='Find Walmart prescriptions']")
    public WebElement getStartedButtonForImportRx;

    @FindBy(xpath = "//h2[contains(text(), 'add prescriptions for yourself or family members')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_card_header' and contains(@text, 'importing your prescriptions to Walmart')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='PharmacyBannerContentView.titleLabel' and contains(@label, 'add prescriptions')]")
    public WebElement importRxStateModuleHeader;

    @FindBy(xpath = "//div[contains(text(), 'Find Walmart prescriptions or transfer them')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/pharmacy_card_body' and contains(@text, 'Import prescriptions for you')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='PharmacyBannerContentView.subtitleLabel' and contains(@label, 'Import prescriptions')]")
    public WebElement importRxStateModuleSubtitle;

    @FindBy(xpath = "//a[@aria-label='Get Started to add prescriptions']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Get started to add prescriptions']")
    @iOSXCUITFindBy(accessibility = "Get started")
    public WebElement getStartedButtonFromImportRxStateModule;

    @FindBy(xpath = "(//input[@name='select-transfer-options'])[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='HWRadioButtonWithVerticalAlignedView.radioButtonView' and @label='Transfer from a non - Walmart Pharmacy']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/non_walmart_pharmacy_selector")
    public WebElement transferFromNonWalmartPharmacyRadioButton;

    @FindBy(xpath = "//button[text() = 'Continue']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name CONTAINS 'primaryActionButton'")
    @AndroidFindBy(id = "com.walmart.android.debug:id/continueButton")
    public WebElement selectTransferSourceContinueButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Refill Prescriptions']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Refill Prescriptions']")
    @FindBy(xpath = "//span[text()='Refill Prescriptions']")
    public WebElement refillPrescriptionsButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Pharmacy account settings']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Pharmacy account settings']")
    public WebElement pharmacyAccountSettingsOption;

    @FindBy(xpath = "//h2[contains(text(),'Verify your address for Walmart Pharmacy')]")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.titleView")
    public WebElement verifyAddressDialogHeading;
    
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.firstButton")
    @FindBy(xpath = "//button[contains(text(),'Yes, this is correct')]")
    public WebElement confirmAddressButton;
    public static final String CANCELED_ITEM_ID = "com.walmart.android.debug:id/pharmacy_rx_to_order_level_card_view_canceled_item";
    public static final String DELAYED_FILL_ITEM_ID = "com.walmart.android.debug:id/pharmacy_rx_to_order_level_card_view_delayed_item";
    private static final String ANDROID_CARD_HEADER_XPATH =
            "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header_title'"
                    + " and contains(@text,'%s')]";
    private static final String ANDROID_CARD_SUBHEADER_XPATH = ANDROID_CARD_HEADER_XPATH
                    + "/ancestor::android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/card_parent']"
                    + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header_description']";

    // args: (headerText, patientName, itemId)
    private static final String ANDROID_PATIENT_ROW_XPATH = ANDROID_CARD_HEADER_XPATH
                    + "/ancestor::android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/card_parent']"
                    + "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/pharmacy_rx_to_order_level_card_view_body_header'"
                    + " and .//android.widget.TextView[@resource-id='com.walmart.android.debug:id/patient_name'"
                    + " and contains(@text,'%s')]]"
                    + "/following-sibling::android.view.ViewGroup[@resource-id='%s'][1]";

    /** iOS: tracker card title (cancelled / delayed) — {@code %s} = substring e.g. cancelled, delayed (lowercase match). */
    private static final String IOS_TRACKER_CARD_HEADER_XPATH =
            "//XCUIElementTypeStaticText[@name='FillSectionHeaderView.headerLabel' and contains("
                    + "translate(@label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '%s')]";
    /** iOS: subheader under the same cancel/delayed card as the matched header. */
    private static final String IOS_TRACKER_CARD_SUBHEADER_REL_XPATH =
            IOS_TRACKER_CARD_HEADER_XPATH
                    + "/ancestor::XCUIElementTypeOther[@name='DelayedOrCancelledRxCardView.containerView'][1]"
                    + "//XCUIElementTypeStaticText[@name='FillSectionHeaderView.subheaderLabel']";
    /** iOS: first Rx row under a patient — drug name (following patient label). */
    private static final String IOS_PATIENT_RX_TITLE_AFTER_LABEL =
            "//XCUIElementTypeStaticText[@name='HWImageWithLabelView.label' and @label=\"%s\"]"
                    + "/following::XCUIElementTypeStaticText[@name='DelayedOrCancelledFillInfoView.titleLabel'][1]";
    /** iOS: status line (e.g. Refill too soon) for that row. */
    private static final String IOS_PATIENT_RX_STATUS_AFTER_LABEL =
            "//XCUIElementTypeStaticText[@name='HWImageWithLabelView.label' and @label=\"%s\"]"
                    + "/following::XCUIElementTypeStaticText[@name='DelayedOrCancelledFillInfoView.subtitleLabel'][1]";
    /** iOS: chevron to open prescription details for that patient's row. */
    private static final String IOS_PATIENT_RX_ARROW_AFTER_LABEL =
            "//XCUIElementTypeStaticText[@name='HWImageWithLabelView.label' and @label=\"%s\"]"
                    + "/following::XCUIElementTypeImage[@name='DelayedOrCancelledFillInfoView.arrowImageView'][1]";


    public PharmacyDashboardPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void moveToPharmacyOptionInServices() {
        Actions actions = new Actions(remoteDriver);
        actions.moveToElement(pharmacyOption);
        actions.click().build().perform();
    }

    public void clickPharmacyServicesForGuestUser() {
        androidScrollToText("Recommended for you");
        click(pharmacyButton);
    }

    public void clickPharmacyServicesButtonForMobile() {
        mobileScrollToText("Recommended for you", "up");
        click(pharmacyButton);
    }

    public void clickPharmacyServicesButton() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Pharmacy", "up");
        } else {
            androidScrollToText("Pharmacy");
        }
        click(pharmacyButton);
    }

    public void clickScanToRefill() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Scan to refill", "up");
            click(scanToRefill);
        } else {
            WebElement scanToRefillEle = androidScrollDownToText("Scan to refill");
            click(scanToRefillEle);
        }
    }

    public void clickScanToRefillNotConnected() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Medication aids", "up");
        } else {
            androidScrollDownToText("Medication aids");
        }
        click(scanToRefill);
    }

    public void denyBiometricsPermissionButton() {
        try {
            if (isElementDisplayed(biometricsPermissionButton, 7)) {
                click(biometricsPermissionButton, 5);
            } else {
                Reporter.log("Not able to find element biometricsPermissionButton");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Biometrics permission button not clicked");
        }
    }

    public void denyShoppingPersonalizationPermissionButton() {
        try {
            if (isElementDisplayed(personaliseShoppingExperienceButton, 2)) {
                click(personaliseShoppingExperienceButton);
            }
        } catch (Exception e) {
            Reporter.log("Personalisation dialog not present, continuing");
        }
    }

    public void acceptPrivacyPractices() {
        try {
            if (isElementDisplayed(acceptPrivacyPracticesButton, 5)) {
                click(acceptPrivacyPracticesButton);
                Reporter.log("Accepted Notice of Privacy Practices");
            }
        } catch (Exception e) {
            Reporter.log("Privacy practices accept button not found or already accepted");
        }
    }

    private boolean isRunningOnSauce() {
        return Boolean.parseBoolean(prop.getProperty("dp.runOnSauce"));
    }

    public void dismissLocationAccessDialog() {
        if (!isRunningOnSauce()) return;
        try {
            // Zero-wait check — safe to call at the start of flows where dialog rarely appears.
            // findElements returns an empty list instantly when the dialog is absent.
            if (!remoteDriver.findElements(By.xpath("//*[@text='Continue sharing precise location']")).isEmpty()) {
                click(continueLocationSharingButton);
                Reporter.log("Dismissed location access dialog (Continue sharing)");
            }
        } catch (Exception e) {
            Reporter.log("Location access dialog not present, continuing");
        }
    }

    /**
     * Waits up to {@code waitSeconds} for the "Confirm location access" dialog to appear,
     * then clicks "Continue sharing precise location" to dismiss it without side effects.
     * Only active on SauceLabs real-device runs (dp.runOnSauce=true) — the dialog does
     * not appear on local devices.
     */
    public void dismissLocationAccessDialog(int waitSeconds) {
        if (!isRunningOnSauce()) return;
        try {
            if (isElementDisplayed(continueLocationSharingButton, waitSeconds)) {
                click(continueLocationSharingButton);
                Reporter.log("Dismissed location access dialog (Continue sharing)");
            }
        } catch (Exception e) {
            Reporter.log("Location access dialog not present, continuing");
        }
    }

    /**
     * Clicks "Try again" if the pharmacy error screen ("Sorry... We're having technical
     * issues") is displayed. Retries up to 3 times with a 5s gap between attempts to
     * handle cases where the first retry still fails (common on SauceLabs real devices
     * where the backend connection through the tunnel needs a moment to stabilise).
     * Safe to call on every dashboard entry — returns immediately if the error screen
     * is absent on the first check.
     */
    public void clickTryAgainIfPharmacyError() {
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                if (!isElementDisplayed(tryAgainButton, attempt == 1 ? 4 : 2)) {
                    return;
                }
                click(tryAgainButton);
                Reporter.log("Pharmacy error screen detected — clicked Try again (attempt " + attempt + "/3)");
                waitForLoadingToDisappear(15);
            } catch (Exception e) {
                Reporter.log("clickTryAgainIfPharmacyError attempt " + attempt + " exception (non-fatal): " + e.getMessage());
            }
        }
    }

    public void clickManageInsuranceTab() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Manage insurance", "up");
        } else if (remoteDriver instanceof AndroidDriver) {
            androidScrollToText("Manage insurance");
        }
        click(manageMyInsuranceCTA, 10);
    }

    public void clickScheduleImmunizationTab() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Schedule an Immunization", "up");
        } else if (remoteDriver instanceof AndroidDriver) {
            androidScrollDownToText("Schedule an Immunization");
        }
        click(scheduleImmunizationCTA, 10);
    }

    public void clickMyPrescriptionsTab() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Refill Prescriptions", "up");
        } else if (remoteDriver instanceof AndroidDriver) {
            androidScrollToText("Transfer prescriptions"); // Sometimes Refill Prescriptions tile is behind the bottom nav bar and accidentally clicks the Ask Sparky icon
        } else {
            scrollToTextWithLoop("Refill");
        }
        click(myPrescriptionsTab);
    }

    public void enterPin() {
        // SauceLabs real device needs extra time for the PIN keypad to settle after navigation.
        for (int i = 0; i < 4; i++)
            click(pinInput, 20);
    }

    public void inputPinForRefill() {
        webWait.until(ExpectedConditions.visibilityOfAllElements(pinInput));
        List<WebElement> pinInputs = remoteDriver.findElements(By.xpath("//input[contains(@id,'input-verificationCode')]"));
        for (WebElement el : pinInputs
        ) {
            el.sendKeys("1");
        }
    }

    public void enterInputPin() {
        isElementDisplayed(pinInputs.get(0), 20);
        for (WebElement el : pinInputs) {
            el.sendKeys("1");
        }
    }

    public void enterPharmacyPin(String pin) {
        if (remoteDriver instanceof IOSDriver) {
            sendText(inputPinText, pin);
            unblockingClick(confirmPin, 2, "Confirm PIN");
        } else if (remoteDriver instanceof AndroidDriver) {
            for (char c : pin.toCharArray()) {
                WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(10));
                WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("com.walmart.android.debug:id/keypadNum" + c)));
                el.click();
            }
        } else {
            int count = 0;
            for (WebElement el : pinInputs) {
                el.sendKeys(String.valueOf(pin.charAt(count)));
                count++;
            }
        }
    }

    public boolean isVerifyInputPinVisible() {
        try{
            return super.isElementDisplayed(pinInput, 5);
        }
        catch (Exception e) {
            Reporter.log("Verify Input Pin is not visible");
            return false;
        } catch (AssertionError err) {
            Reporter.log("Verify Input Pin is not visible");
            return false;
        }
    }

    public void verifyPin() {
        click(verifyPinButton);
    }

    public void createPIN() {
        click(createPinButton);
    }

    public void pharmacyDeliveryAvailablePopUp() {
        click(pharmacyDeliveryAvailablePopUpCloseButton);
    }

    public void closeAddressSelectionButton() {
        click(closeAddressSelectionButton);
    }

    public void clickGuestRefill() {

        click(easyRefill);
        click(refillAsGuest);
    }

    public void clickMinimizePickupOptionPopUp() {
        if ("How do you want your items?".equals(getText(minimizePickupOptionPopUp))) {
            click(minimizePickupOptionPopUp);
        } else {
            click(minimizePickupOptionPopUp2);
            if (pickupOption.isDisplayed()) {
                click(minimizePickupOptionPopUp2);
            }
        }
    }

    public void clickRefillAsGuest() {
        click(refillAsGuest);
        click(closeAddressSelectionButton);
    }

    public void clickMyItemsCloseButton() {
        click(myItemsCloseButton);
    }

    public void clickOnAcknowledgeBtn() {
        click(acknowledgeBtn, "Acknowledge Button");
    }

    public void clickTransferPrescriptionsTab() {
        scrollElementForWebAndMobile(transferPrescriptionsTab, "Transfer prescriptions", "up");
        click(transferPrescriptionsTab);
    }

    public void clickGetNotificationsMaybeLaterButton() {
        try {
            unblockingClick(getNotificationsMaybeLaterButton, 5, "Get Notifiations Maybe Later Button");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clickManageMyInsuranceCTA() {
        try {
            click(manageMyInsuranceCTA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isManageMyInsuranceCTAPresent() {
        return isElementDisplayed(manageMyInsuranceCTA);
    }

    public void closeDeliveryAvailablePopupButton() {
        try {
            if (isElementDisplayed(closeDeliveryAvailablePopupButton, 20)) {
                click(closeDeliveryAvailablePopupButton);
            }
        } catch (Exception e) {
            Reporter.log("closeDeliveryAvailablePopupButton not displayed — skipping");
        }
    }

    public void dismissAccountBeingSetupSheet() {
        try {
            if (isElementDisplayed(accountBeingSetupDismissButton, 5)) {
                click(accountBeingSetupDismissButton);
            }
        } catch (Exception e) {
            Reporter.log("accountBeingSetupSheet is not appeared");
        }
    }

    public void dismissUnableToAtcFailureBottomSheet() {
        try {
            if (isElementDisplayed(atcFailureBottomSheetCloseCta, 5)) {
                click(atcFailureBottomSheetCloseCta);
            }
        } catch (Exception e) {
            Reporter.log("ATC failure bottom sheet dismiss: " + e.getMessage());
        }
    }

    public boolean isAddInsuranceNudgeDisplayed() {
        return isElementDisplayed(addInsuranceNudgeContainer);
    }

    public boolean isInsuranceNudgeNotDisplayed() {
        return !isElementDisplayed(addInsuranceNudgeCTA, 5);
    }

    public boolean isInsuranceNudgeCTADisplayed() {
        return isElementDisplayed(addInsuranceNudgeCTA, 10);
    }

    public void proceedToEcommCart() {
        click(commonCartButton);
    }

    public void confirmPin(){click(confirmPin);}

    public void selectSlot() {
        click(selectSlotButton);
    }

    public void clickConnectMyAccountCTA() {
        click(connectMyAccountCTA, 5);
    }

    public Boolean isConnectMyAccountCTAPresent() {
        return isElementDisplayed(connectMyAccountCTA);
    }

    public String getInsuranceNudgeTitle() {
        return getText(insuranceNudgeTitle);
    }

    public String getInsuranceNudgeTitleForDependent(String dependentName) {
        return getText(insuranceNudgeTitleDependent);
    }

    public String getInsuranceNudgeDescription() {
        return getText(insuranceNudgeDescription);
    }

    public void clickAddInsuranceCTA() {
        click(addInsuranceNudgeCTA);
    }

    public boolean isDismissInsuranceNudgeCTADisplayed() {
        return isElementDisplayed(dismissInsuranceNudgeCTA, 20);
    }

    public String getAccountUnconnectedHeaderText() {
        return getText(accountUnconnectedHeaderText);
    }

    public void clickOnManageFamilyCTA() {
        click(manageFamilyPrescriptionsHeaderText);
    }

    public boolean isApprovalIsPendingTextPresent() {
        return isElementDisplayed(approvalPendingTxt);
    }

    public String getApprovalIsPendingText() {
        return getText(approvalPendingTxt);
    }

    public boolean isResendRequestBtnPresent() {
        return isElementDisplayed(resendRequestBtn);
    }

    public boolean isCancelRequestBtnPresent() {
        return isElementDisplayed(cancelRequestBtn);
    }

    public boolean clickEnterManuallyButton() {
        return isElementDisplayed(cancelRequestBtn);
    }

    public void clickEnterManuallyBtn() {
        try {
            if (isElementDisplayed(enterManuallyBtn, 15)) {
                click(enterManuallyBtn);
            }
        } catch (Exception e) {
            System.out.println("Enter manually Button is not appeared");
        }
    }

    public void enterPrescriptionDetails(String RX) {
        sendText(prescriptionNumberTxt, RX, 4);
    }

    public void enterStoreDetails(String strNo) {
        sendText(enterStoreDetails, strNo, 4);
    }

    public void enterDobDetails(String Dob) {
        sendText(enterDobDetails, Dob, 4);
    }

    public void clickContinue() {
        try {
            if (isElementDisplayed(clickContinue, 5)) {
                click(clickContinue);
            }
        } catch (Exception e) {
            System.out.println("Continue Button is not appeared in the refilling for someone else popup");
        }
    }

    public void clickContinueForPetPopUp() {
        try {
            if (isElementDisplayed(clickContinueBtn, 5)) {
                click(clickContinueBtn);
            }
        } catch (Exception e) {
            System.out.println("Continue Button is not appeared in the refilling for someone else popup");
        }
    }

    public void clickRequestRefill() {
        try {
            if (isElementDisplayed(clickRequestRefillButton, 10)) {
                click(clickRequestRefillButton);
            }
        } catch (Exception e) {
            System.out.println("Request Refill button is not appeared in the Refill Prescriptions Screen ");
        }
    }

    public void validateSuccessRequestRefill() {
        try {
            isElementDisplayed(validateSuccessLogo, 5);
            isElementDisplayed(validateSuccessText, 5);
        } catch (Exception e) {
            System.out.println("Refill is not placed successfully");
        }
    }

    public void clickCloseButton() {
        try {
            if (isElementDisplayed(closeButton, 5)) {
                click(closeButton);
            }
        } catch (Exception e) {
            System.out.println("close button is not appeared in the at the end ");
        }
    }

    public void clickFeedbackCloseButton() {
        try {
            if (isElementDisplayed(feedbackCloseButton, 5)) {
                click(feedbackCloseButton);
            }
        } catch (Exception e) {
            System.out.println("Feed Back Close button  is not appeared in the at the end ");
        }
    }

    public void clickOnlyThisTime() {
        try {
            if (isElementDisplayed(clickOnlyThisTimeButton, 5)) {
                click(clickOnlyThisTimeButton);
            }
        } catch (Exception e) {
            System.out.println("Only This Time Button is not appeared");
        }
    }

    public void clickAddFamilyMemberOptionInTheRefillPrescriptionScreen() {
        if (isElementDisplayed(clickAddFamilyMemberOption, 10)) {
            click(clickAddFamilyMemberOption);
        } else {
            System.out.println("click Add Family Member Option is not appeared");
        }
    }

    public void clickAddFamilyMemberOption() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Vaccine history", "up");
        } else {
            androidScrollDownToText("Vaccine history");
        }
        click(clickManageFamilyMember);
    }

    public void clickRemoveOption() {
        if (isElementDisplayed(clickRemoveOption, 8)) {
            click(clickRemoveOption);
        }
        if (isElementDisplayed(clickRemoveButton, 8)) {
            click(clickRemoveButton);
        }
    }

    public void clickGetStartedButton() {
        if (remoteDriver instanceof IOSDriver) {
            moveToElementAndClick(clickGetStarted, "Get Started");
        } else {
            click(clickGetStarted);
        }

    }

    public void navigateToFindPrescriptionsScreen() {
        click(getStartedButtonForImportRx);
    }

    public void navigateToFindPrescriptionsScreenUsingImportRxStateModule() {
        click(getStartedButtonFromImportRxStateModule);
    }

    public void importRxStateModuleIsDisplayed() {
        isElementDisplayed(importRxStateModuleHeader, 5);
        isElementDisplayed(importRxStateModuleSubtitle);
    }

    public void clickTransferFromNonWalmartPharmacy() {
        click(transferFromNonWalmartPharmacyRadioButton, 10);
    }

    public void clickTransferSourceContinueButton() {
        click(selectTransferSourceContinueButton, 4);
    }

    public void clickRefillPrescriptions() {
        click(refillPrescriptionsButton);
    }

    public void dismissAddressVerificationDialogIfPresent() {
        try {
            // Wait for dialog heading to appear
            if (isElementDisplayed(verifyAddressDialogHeading, 5)) {
                // Click "Yes, this is correct" to confirm address
                click(confirmAddressButton, 5);
                
                // Wait for dialog to disappear
                invisibilityOfElement(verifyAddressDialogHeading, 5);
            }
        } catch (Exception e) {
            // Dialog not present or already closed
        }
    }

    // Note: Only Android locators added - executed on Android only
    // TODO: Add iOS locators when flow is executed on iOS platform

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    public WebElement continueAfterPinCreationButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/fragment_module_pharmacy_success_done")
    @iOSXCUITFindBy(accessibility = "SMSIDConfirmationViewController.primaryAction")
    public WebElement doneOnSuccessScreenButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/fragment_module_pharmacy_success_done")
    @iOSXCUITFindBy(accessibility = "HWPrimaryStickyButton.primaryActionButton")
    public WebElement doneOnExperianSuccessScreenButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Pharmacy']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeNavigationBar[@name='Pharmacy']")
    public WebElement pharmacyDashboardHeader;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/service_item_title' and @text='Prescription history']")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Home.ServicesItemTitle' AND label == 'Prescription history'")
    public WebElement prescriptionHistoryOption;

    /**
     * Clicks Continue button after PIN creation success screen
     */
    public void clickContinueAfterPinCreation() {
        try {
            if (isElementDisplayed(continueAfterPinCreationButton, 5)) {
                click(continueAfterPinCreationButton);
                Reporter.log("Clicked Continue after PIN creation");
            }
        } catch (Exception e) {
            Reporter.log("Continue after PIN creation button not found");
        }
    }

    /**
     * Clicks Done button on SMS account creation success screen
     */
    public void clickDoneOnSuccessScreen() {
        try {
            if (isElementDisplayed(doneOnSuccessScreenButton, 5)) {
                click(doneOnSuccessScreenButton);
                Reporter.log("Clicked Done on success screen");
            }
        } catch (Exception e) {
            Reporter.log("Done button not found on success screen");
        }
    }

    /**
     * Clicks Done button on Experian KYC flow success screen
     */
    public void clickDoneOnExperianSuccessScreen() {
        click(doneOnExperianSuccessScreenButton);
    }

    /**
     * Verifies that Pharmacy Dashboard header is displayed
     * @return true if Pharmacy Dashboard header is displayed
     */
    public boolean isPharmacyDashboardHeaderDisplayed() {
        try {
            return isElementDisplayed(pharmacyDashboardHeader, 10);
        } catch (Exception e) {
            Reporter.log("Pharmacy Dashboard header not found");
            return false;
        }
    }

    /**
     * Navigates to Pharmacy account settings by scrolling and clicking the option
     */
    public void navigateToPharmacyAccountSettings() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Pharmacy account settings", "up");
            click(pharmacyAccountSettingsOption, 10);
        } else if(remoteDriver instanceof AndroidDriver){
            WebElement element = androidScrollDownToText("Pharmacy account settings");
            click(element);
        }
    }

    public void navigateToPrescriptionHistory() {
        click(prescriptionHistoryOption);
    }

    public void navigateToManageFamilyMembers() {
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Manage family members", "up");
            click(clickManageFamilyMember, 10);
        } else if(remoteDriver instanceof AndroidDriver){
            WebElement element = androidScrollDownToText("Manage family members");
            click(element);
        }
    }

    /** Scrolls to the tracker card only if not already visible, then waits for it to appear. */
    public boolean isTrackerCardVisible(String headerContainsText) {
        if (isAndroid()) {
            String xpath = String.format(ANDROID_CARD_HEADER_XPATH, headerContainsText);
            try {
                List<WebElement> found = remoteDriver.findElements(By.xpath(xpath));
                if (found.isEmpty() || !isElementDisplayed(found.get(0))) {
                    androidScrollToTextContains(headerContainsText);
                }
                WebElement header = remoteDriver.findElement(By.xpath(xpath));
                if (!isElementDisplayed(header)) {
                    new FluentWait<>(appDriver)
                            .withTimeout(Duration.ofSeconds(180))
                            .pollingEvery(Duration.ofSeconds(5))
                            .ignoring(NoSuchElementException.class)
                            .until(d -> {
                                refreshPage();
                                androidScrollToTextContains(headerContainsText);
                                return isElementDisplayed(remoteDriver.findElement(By.xpath(xpath)));
                            });
                }
                return isElementDisplayed(remoteDriver.findElement(By.xpath(xpath)));
            } catch (NoSuchElementException e) {
                return false;
            }
        } else if (isIOS()) {
            mobileScrollToText(headerContainsText, "up");
            String xpath = String.format(IOS_TRACKER_CARD_HEADER_XPATH, headerContainsText.toLowerCase());
            try {
                WebElement header = remoteDriver.findElement(By.xpath(xpath));
                return isElementDisplayed(header);
            } catch (NoSuchElementException e) {
                return false;
            }
        }
        return false;
    }

    /** Scrolls to the tracker card header and returns its text. */
    public String getTrackerCardHeaderText(String headerContainsText, String scrollToText) {
        if (isAndroid()) {
            String xpath = String.format(ANDROID_CARD_HEADER_XPATH, headerContainsText);
            if (!isElementDisplayed(remoteDriver.findElement(By.xpath(xpath)))) {
                androidScrollToTextContains(scrollToText);
            }
            return getText(remoteDriver.findElement(By.xpath(xpath)));
        } else if (isIOS()) {
            mobileScrollToText(scrollToText, "up");
            String xpath = String.format(IOS_TRACKER_CARD_HEADER_XPATH, headerContainsText.toLowerCase());
            return getText(remoteDriver.findElement(By.xpath(xpath)));
        }
        scrollToTextWithLoop(scrollToText);
        throw new UnsupportedOperationException("Platform not supported for tracker card header");
    }

    /** Returns the sub-header (description) text of the tracker card. */
    public String getTrackerCardSubHeaderText(String headerContainsText) {
        if (isAndroid()) {
            return getText(remoteDriver.findElement(By.xpath(
                    String.format(ANDROID_CARD_SUBHEADER_XPATH, headerContainsText))));
        }
        if (isIOS()) {
            mobileScrollToText(headerContainsText, "up");
            String xpath = String.format(IOS_TRACKER_CARD_SUBHEADER_REL_XPATH, headerContainsText.toLowerCase());
            return getText(remoteDriver.findElement(By.xpath(xpath)));
        }
        throw new UnsupportedOperationException("Platform not supported for tracker card sub-header");
    }

    /**
     * Returns {drug_name, status} for the first Rx row of the given patient.
     * Reads the container's content-desc in one attribute call to avoid a second element lookup —
     * child findElement does not respect implicit wait, so a live-refreshing UI causes NoSuchElementException.
     * content-desc format (set by Android): "drug_name, status, status_message"
     */
    public String[] getFirstRxDetails(String headerContainsText, String itemId, String patientName) {
        if (isAndroid()) {
            WebElement canceledItem = remoteDriver.findElement(By.xpath(
                    String.format(ANDROID_PATIENT_ROW_XPATH, headerContainsText, patientName, itemId)));
            String contentDesc = canceledItem.getAttribute("content-desc");
            String[] parts     = contentDesc != null ? contentDesc.split(", ", 3) : new String[0];
            String drugName    = parts.length > 0 ? parts[0] : "";
            String status      = parts.length > 1 ? parts[1] : null;
            return new String[]{drugName, status};
        }
        if (isIOS()) {
            mobileScrollToText(patientName, "up");
            String escaped = patientName.replace("\"", "\\\"");
            String drugName = getText(remoteDriver.findElement(By.xpath(
                    String.format(IOS_PATIENT_RX_TITLE_AFTER_LABEL, escaped))));
            String status = getText(remoteDriver.findElement(By.xpath(
                    String.format(IOS_PATIENT_RX_STATUS_AFTER_LABEL, escaped))));
            return new String[]{drugName, status};
        }
        throw new UnsupportedOperationException("Platform not supported for tracker card Rx details");
    }

    /** Clicks the first Rx row for the given patient on any tracker card, opening the details screen. */
    public void clickFirstRxRowForPatient(String headerContainsText, String itemId, String patientName) {
        if (isAndroid()) {
            WebElement row = remoteDriver.findElement(By.xpath(
                    String.format(ANDROID_PATIENT_ROW_XPATH, headerContainsText, patientName, itemId)));
            androidScrollToText(patientName);
            click(row);
            return;
        }
        if (isIOS()) {
            mobileScrollToText(patientName, "up");
            String escaped = patientName.replace("\"", "\\\"");
            WebElement arrow = remoteDriver.findElement(By.xpath(
                    String.format(IOS_PATIENT_RX_ARROW_AFTER_LABEL, escaped)));
            click(arrow);
            return;
        }
        throw new UnsupportedOperationException("Platform not supported for tracker card row click");
    }

    // Note: Only Android locators added for ecom nudge elements below - executed on Android only
    // TODO: Add iOS locators when flow is executed on iOS platform

    /** Dependent's "You have a pending request" ecom nudge title — visible on dependent's
     * pharmacy dashboard after caregiver sends a delivery-enable request. */
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, 'You have a pending request')]")
    public WebElement ecomPendingRequestNudgeTitle;

    /** Caregiver's rejected/cancelled nudge — visible on caregiver's pharmacy dashboard
     * after dependent revokes ecom consent. Text pattern: "{name} has rejected your request". */
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, 'rejected your request') or contains(@text, 'request has been cancelled')]")
    public WebElement requestRejectedOrCancelledNudge;

    /** "Dismiss" link on any dashboard nudge (e.g., rejection nudge, stale request nudge). */
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/dismiss_request_cta']")
    public WebElement dismissNudgeButton;

    /**
     * Returns true if the "You have a pending request" ecom delivery-enable nudge is displayed
     * on the pharmacy dashboard (dependent's view after caregiver sends the request).
     */
    public boolean isEcomPendingRequestNudgeVisible() {
        return isElementDisplayed(ecomPendingRequestNudgeTitle, 5);
    }

    /**
     * Returns true if the request rejected/cancelled nudge is displayed on the caregiver's
     * pharmacy dashboard after the dependent revokes ecom consent.
     */
    public boolean isRequestRejectedOrCancelledNudgeVisible() {
        return isElementDisplayed(requestRejectedOrCancelledNudge, 5);
    }

    /**
     * Clicks the "Dismiss" link on a dashboard nudge (e.g., stale rejection nudge).
     * Safe to call only after confirming the nudge is visible.
     */
    public void clickDismissNudge() {
        click(dismissNudgeButton, 5);
        Reporter.log("Clicked Dismiss on dashboard nudge");
    }
}
