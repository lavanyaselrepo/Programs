package com.walmart.hwqe.digitalPharmacyuicontext.pages.importRx;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class FindPrescriptionsPage extends MobileBasePage {

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "RxPrimaryStickyButton.primaryActionButton")
    public WebElement continueBtn;

    @FindBy(xpath = "//h2[contains(text(),\"We have successfully added\") and contains(text(),\"prescriptions\")]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/import_rx_confirmation_header")
    @iOSXCUITFindBy(accessibility = "SMSIDConfirmationHeaderView.headerTitle")
    public WebElement successHeading;

    @FindBy(xpath = "//span[contains(text(),'Now you can see and manage all your prescriptions in one place.')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/message_subtitle")
    @iOSXCUITFindBy(accessibility = "SMSIDConfirmationHeaderView.headerSubTitle")
    public WebElement successSubText;

    @FindBy(xpath = "//button[text()='View prescriptions']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/view_prescriptions_button")
    @iOSXCUITFindBy(accessibility = "View prescriptions")
    public WebElement viewPrescriptionsBtn;

    @FindBy(id = "page-heading")
    @AndroidFindBy(id = "com.walmart.android.debug:id/headerTitle")
    @iOSXCUITFindBy(accessibility = "ImportRxSelectionViewController<ImportRxDelinkType>.titleLabel")
    public WebElement heading;

    @FindBy(id = "DELINK-OPTION-CURRENT")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='Link my prescriptions to this account.']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Link my prescriptions to this account.']")
    public WebElement linkPrescriptionsToAccountOption;

    @FindBy(xpath = "//div[@role='dialog']//button[contains(text(),'Link current account')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/option_action_cta")
    @iOSXCUITFindBy(accessibility = "Link current account")
    public WebElement linkCurrentAccountBtn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='Enter prescription details manually']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Enter prescription details manually']")
    public WebElement enterPrescriptionManuallyRadioButton;

    public FindPrescriptionsPage(RemoteWebDriver appDriver) {
        super(appDriver);
    }

    public void clickContinueBtn() {
        click(continueBtn);
    }

    public boolean verifyImportRxConfirmation() {
        return isElementDisplayed(successHeading, 10) && isElementDisplayed(successSubText);
    }

    public void clickViewPrescriptionsBtn() {
        click(viewPrescriptionsBtn);
    }

    public String getHeadingText() {
        return getText(heading);
    }

    public FindPrescriptionsPage selectLinkPrescriptionsToThisAccountOption() {
        click(linkPrescriptionsToAccountOption);
        return this;
    }

    public void clickLinkCurrentAccountBtnInDialog() {
        click(linkCurrentAccountBtn);
    }

    public FindPrescriptionsPage selectEnterPrescriptionManuallyRadioButton() {
        click(enterPrescriptionManuallyRadioButton);
        return this;
    }
}
