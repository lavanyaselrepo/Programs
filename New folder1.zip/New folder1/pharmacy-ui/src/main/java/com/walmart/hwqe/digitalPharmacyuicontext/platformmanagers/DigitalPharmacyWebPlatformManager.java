/**
 * DigitalPharmacyWebPlatformManager is the implementation of ICommonDriver for the platform type "WEB".
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;


import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.saucelabscontext.SauceLabsTunnelManager;
import com.walmart.hwqe.webcontext.BrowserType;
import com.walmart.hwqe.webcontext.WebSiteManager;
import com.walmart.hwqe.webcontext.interfaces.ICommonDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class DigitalPharmacyWebPlatformManager extends WebSiteManager implements ICommonDriver {

    PropertyReader prop = PropertyReaderHelper.getInstance();
    private static final Logger logger = LoggerFactory.getLogger(DigitalPharmacyWebPlatformManager.class);
    private static ThreadLocal<RemoteWebDriver> remoteWebDriverThreadLocal = new ThreadLocal<>();

    public DigitalPharmacyWebPlatformManager() {
        super();
    }

    @Override
    public RemoteWebDriver getDriver() {
        return super.getDriver();
    }


    public void getSessionInformation() {
        Reporter.log(getDriver().getCapabilities().toString());
    }

    /**
     * launchPlatformApp method initialises an RemoteWebDriver instance according to the android platform config for local and saucelabs
     * and also launches the apk.
     *
     * @param testName : Possible values : test case name using the common framework for UI automation.
     * @return returns the implementation of ICommonDriver which is an instance of RemoteWebDriver.
     * @Author: Saloni Sharma
     */
    @Override
    public RemoteWebDriver launchPlatformApp(String testName) {
        RemoteWebDriver driver;

        if (Boolean.parseBoolean(prop.getProperty("dp.runOnSauce"))) {
            ChromeOptions browserOptions = new ChromeOptions();

            browserOptions.setPlatformName("Windows 11");
            browserOptions.setBrowserVersion("latest");

            Map<String, Object> sauceOptions = new HashMap<>();
            sauceOptions.put("username", prop.getProperty("z.run.sl.un"));
            sauceOptions.put("accessKey", prop.getProperty("z.run.sl.ak"));
            sauceOptions.put("build", "1");
            sauceOptions.put("name", testName);
            sauceOptions.put("idleTimeout", 420);
            browserOptions.setCapability("sauce:options", sauceOptions);

            browserOptions.addArguments("--disable-infobars", "--start-maximized", "--disable-gpu", "--no-sandbox",
                    "--disable-web-security", "--disable-features=NetworkService", "--dns-prefetch-disable", "--disable-extensions");

            browserOptions.setPageLoadStrategy(PageLoadStrategy.EAGER);

            Map<String, Object> prefs = new HashMap<>();
            prefs.put("profile.default_content_setting_values.geolocation", 2);
            browserOptions.setExperimentalOption("prefs", prefs);
            browserOptions.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);

            if (prop.getProperty("dp.run.sauce.test.with.tunnel").equalsIgnoreCase("true")) {
                /* Local Tunnels Are Deprecated
                log.info("configured tunnel name: " +SauceLabsTunnelManager.getInstance().getSauceLabsTunnelID());
                sauceOptions.put("tunnelName", SauceLabsTunnelManager.getInstance().getSauceLabsTunnelID());
                */

                // Use Centralized Sauce tunnel:
                if (prop.getProperty("dp.is.custom.tunnel.needed").equalsIgnoreCase("true")) {
                    log.info("Using Custom Sauce Tunnel for Tests");
                    sauceOptions.put("tunnelName", SauceLabsTunnelManager.getInstance().getSauceLabsTunnelID());
                    sauceOptions.put("tunnelOwner", prop.getProperty("sauce.tunnel.owner"));
                } else {
                    log.info("Using Default Sauce Tunnel for Tests");
                    sauceOptions.put("tunnelName", prop.getProperty("sauce.tunnel.name"));
                    sauceOptions.put("tunnelOwner", prop.getProperty("sauce.tunnel.owner"));
                }
            }

            try {
                String hub = String.format("https://%s:%s@ondemand.us-west-1.saucelabs.com:443/wd/hub",
                        prop.getProperty("z.run.sl.un"), prop.getProperty("z.run.sl.ak"));

                driver = new RemoteWebDriver(new URL(hub), browserOptions);
                // Ensure mod-headers are applied for Sauce runs too (via CDP if provider exposes it)
                setCustomHeaders(driver);
                driver.get(prop.getProperty("web.rxpd_expo_url"));
                driver.navigate().to(prop.getProperty("web.teflon_base_url"));
            } catch (Exception e) {
                throw new RuntimeException("Failed to initialize Sauce Labs driver: " + e.getMessage(), e);
            }

        } else {
            driver = launchWebsiteOrderToRx(
                    prop.getProperty("web.teflon_base_url"),
                    BrowserType.valueOf(prop.getProperty("web.rxpd_browser"))
            );
        }

        setDriver(driver); // store per thread (in WebSiteManager)
        return driver;
    }

    @Override
    public void quitDriver() {
        RemoteWebDriver driver = getDriver();
        if (driver != null) {
            Reporter.log("Quitting driver for session: " + driver.getSessionId());
        }
        quitWebsite(); // quits and removes ThreadLocal in base
    }

}