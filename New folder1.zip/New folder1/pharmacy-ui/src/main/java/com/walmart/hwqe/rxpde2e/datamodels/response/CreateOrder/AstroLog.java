package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;

@lombok.Getter
@lombok.Setter
public class AstroLog {
}
