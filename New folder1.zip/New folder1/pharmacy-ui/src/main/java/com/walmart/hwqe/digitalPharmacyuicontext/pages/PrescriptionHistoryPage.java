package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.ArrayList;
import java.util.List;

public class PrescriptionHistoryPage extends MobileBasePage {

    // ---- Common header ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_history_list_header")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HWSeparatorHeaderView.titleLabel' AND visible == 1")
    public WebElement pageHeader;

    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_history_list_message")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HWSeparatorHeaderView.descriptionLabel' AND visible == 1")
    public WebElement pageSubDescription;

    // ---- Filter section ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_history_showing")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HistoryFilterAndDownloadOptionsView.filterHeaderLabel' AND visible == 1")
    public WebElement showingLabel;

    @AndroidFindBy(id = "com.walmart.android.debug:id/rx_history_date_range_message")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HistoryFilterInfoView.dateLabel' AND visible == 1")
    public WebElement dateRangeMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_family_filter")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'WCPFilterChip.button' AND label BEGINSWITH 'Filter by My family' AND visible == 1")
    public WebElement familyFilterButton;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/prescription_family_filter']//android.widget.TextView[@resource-id='com.walmart.android.debug:id/btn_text']")
    @iOSXCUITFindBy(accessibility = "My family")
    public WebElement familyFilterText;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/btn_text' and @content-desc='button Past 90 days , default filter applied']")
    @iOSXCUITFindBy(accessibility = "Past 90 days")
    public WebElement defaultTimeFilterButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/downloadHistory")
    @iOSXCUITFindBy(accessibility = "HistoryFilterAndDownloadOptionsView.downloadButton")
    public WebElement downloadHistoryButton;

    // ---- Prescription list ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_list")
    public WebElement prescriptionList;

    // On iOS each prescription row is a single composite accessible element:
    // "{date}, amount {price}, {drug_name}, {owner_name}".
    // All four iOS list locators below target the same composite element;
    // the getFirst*() overrides parse individual fields from the label.
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/owner']")
    @iOSXCUITFindBy(iOSNsPredicate = "name CONTAINS 'amount' AND visible == 1")
    public List<WebElement> prescriptionOwners;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/drug_name']")
    @iOSXCUITFindBy(iOSNsPredicate = "name CONTAINS 'amount' AND visible == 1")
    public List<WebElement> prescriptionDrugNames;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/price']")
    @iOSXCUITFindBy(iOSNsPredicate = "name CONTAINS 'amount' AND visible == 1")
    public List<WebElement> prescriptionPrices;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/last_dispensed_date']")
    @iOSXCUITFindBy(iOSNsPredicate = "name CONTAINS 'amount' AND visible == 1")
    public List<WebElement> prescriptionDates;

    // ---- Total amount spent ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/total_amount_spent_message")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HistoryFilterInfoView.priceLabel' AND visible == 1")
    public WebElement totalAmountSpentMessage;

    // ---- Bottom nudge ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_nudge_title")
    @iOSXCUITFindBy(accessibility = "HWLDNudge.titleLabel")
    public WebElement nudgeTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/tv_add_prescription")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HistoryEmptyView.emptyResultDescription' AND visible == 1")
    public WebElement emptyStateHeading;

    @AndroidFindBy(xpath = "//android.widget.ScrollView[@resource-id='com.walmart.android.debug:id/pharmacy_empty_history']//android.widget.TextView[not(@resource-id)]")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'HistoryEmptyView.updateSearchDescription' AND visible == 1")
    public WebElement emptyStateSubText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/btn_prescriptions_get_started")
    @iOSXCUITFindBy(accessibility = "HistoryEmptyView.primaryButton")
    public WebElement getStartedButton;

    // ---- Family filter bottom sheet ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_bottom_sheet_toolbar_title")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeStaticText' AND name == 'Filter by family members'")
    public WebElement familyFilterBottomSheetTitle;

    @AndroidFindBy(xpath = "//androidx.recyclerview.widget.RecyclerView[@resource-id='com.walmart.android.debug:id/prescription_family_list']//android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/family_filter_item']")
    @iOSXCUITFindBy(accessibility = "HWCheckBoxListCell")
    public List<WebElement> familyFilterItems;

    @AndroidFindBy(xpath = "//androidx.recyclerview.widget.RecyclerView[@resource-id='com.walmart.android.debug:id/prescription_family_list']//android.widget.CheckBox")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[@name='HWCheckBoxListCell']//XCUIElementTypeStaticText")
    public List<WebElement> familyFilterCheckboxes;

    @AndroidFindBy(id = "com.walmart.android.debug:id/apply_filters_btn")
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonWithInfoView.primaryActionButton")
    public WebElement applyFiltersButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/reset_filters_btn")
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonWithInfoView.secondaryButton")
    public WebElement resetFiltersButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_bottom_sheet_toolbar_icon_close")
    @iOSXCUITFindBy(accessibility = "FamilyMembersViewController.Close")
    public WebElement closeFilterBottomSheetButton;

    public PrescriptionHistoryPage(RemoteWebDriver driver) {
        super(driver);
    }

    // ---- Common header ----
    public String getPageHeaderText() {
        return getText(pageHeader);
    }

    public String getPageSubDescriptionText() {
        return getText(pageSubDescription);
    }

    // ---- Filter section ----
    public String getShowingLabelText() {
        return getText(showingLabel);
    }

    public String getDateRangeText() {
        String raw = getText(dateRangeMessage);
        if (isIOS()) {
            int suffixIdx = raw.indexOf(" for selected family members");
            if (suffixIdx > 0) {
                return raw.substring(0, suffixIdx);
            }
        }
        return raw;
    }

    public String getFamilyFilterText() {
        return getText(familyFilterText);
    }

    public void clickFamilyFilter() {
        click(familyFilterButton);
    }

    public String getDefaultTimeFilterText() {
        return getText(defaultTimeFilterButton);
    }

    public String getDownloadHistoryButtonText() {
        return getText(downloadHistoryButton);
    }

    public String getDownloadHistoryButtonAttribute() {
        return downloadHistoryButton.getAttribute("label");
    }

    // ---- Total amount spent ----
    public String getTotalAmountSpentText() {
        return getText(totalAmountSpentMessage);
    }

    // ---- Prescription list ----
    public List<String> getPrescriptionOwnerNames() {
        List<String> names = new ArrayList<>();
        for (WebElement owner : prescriptionOwners) {
            names.add(getText(owner));
        }
        return names;
    }

    // ---- Bottom nudge ----
    public String getNudgeTitleText() {
        return getText(nudgeTitle);
    }

    // ---- Empty state ----
    public String getEmptyStateHeadingText() {
        return getText(emptyStateHeading);
    }

    public String getEmptyStateSubText() {
        return getText(emptyStateSubText);
    }

    public String getGetStartedButtonText() {
        return getText(getStartedButton);
    }

    public void clickGetStartedButton() {
        click(getStartedButton);
    }

    // ---- Family filter bottom sheet ----
    public String getFamilyFilterBottomSheetTitle() {
        return getText(familyFilterBottomSheetTitle);
    }

    public List<String> getFamilyFilterMemberNames() {
        List<String> names = new ArrayList<>();
        for (WebElement checkbox : familyFilterCheckboxes) {
            names.add(getText(checkbox));
        }
        return names;
    }

    public void clickFamilyFilterMemberByFirstName(String firstName) {
        for (int i = 0; i < familyFilterCheckboxes.size(); i++) {
            if (getText(familyFilterCheckboxes.get(i)).toLowerCase().contains(firstName.toLowerCase())) {
                click(familyFilterItems.get(i));
                return;
            }
        }
    }

    public String getApplyFilterButtonText() {
        return getText(applyFiltersButton);
    }

    public void clickApplyFilter() {
        click(applyFiltersButton);
    }

    public String getResetAllFilterButtonText() {
        return getText(resetFiltersButton);
    }

    public boolean isResetAllFilterEnabled() {
        return resetFiltersButton.isEnabled();
    }

    public void clickResetAllFilter() {
        click(resetFiltersButton);
    }

    public void closeFamilyFilterBottomSheet() {
        click(closeFilterBottomSheetButton);
    }

    // ---- Filtered prescription detail getters (first visible item) ----
    public String getFirstPrescriptionOwner() {
        return getText(prescriptionOwners.getFirst());
    }

    public String getFirstPrescriptionDrugName() {
        return getText(prescriptionDrugNames.getFirst());
    }

    public String getFirstPrescriptionPrice() {
        return getText(prescriptionPrices.getFirst());
    }

    public String getFirstPrescriptionDate() {
        return getText(prescriptionDates.getFirst());
    }

    /**
     * Parses an individual field from the iOS composite prescription label.
     * Label format: "{date}, amount {price}, {drug_name}, {owner_name}"
     * e.g. "Mar 09, 2026, amount $18.77, Lamotrigine 100mg TAB, Puppy(Canine) Prescription"
     */
    public String parseFieldFromCompositeLabel(String label, String field) {
        String[] splitByAmount = label.split(", amount ", 2);
        if (splitByAmount.length < 2) return label;
        String date = splitByAmount[0].trim();
        String[] rest = splitByAmount[1].split(", ", 3);
        if (rest.length < 3) return label;
        String price = rest[0].trim();
        String drug  = rest[1].trim();
        String owner = rest[2].trim();
        return switch (field) {
            case "date"  -> date;
            case "price" -> price;
            case "drug"  -> drug;
            case "owner" -> owner;
            default -> label;
        };
    }
}
