package com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientCreation;
@lombok.Getter
@lombok.Setter
public class ConnexusPatientDataRequest {

        public String firstName;
        public String lastName;
        public String inputDob;
        public int siteId;
        public int homePhone;
        public int workPhone;
        public int cellPhone;
        public boolean patientHasInsurance;
}
