package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

public class PharmacyAccountSettingsPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/account_settings_title")
    @iOSXCUITFindBy(accessibility = "Pharmacy Account Settings")
    public WebElement accountSettingsTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/personal_info_item")
    @iOSXCUITFindBy(accessibility = "AccountPreferencesController.personalInformationSelection")
    public WebElement personalInformationOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/manage_permissions_item")
    @iOSXCUITFindBy(accessibility = "AccountPreferencesController.managePermissionSelection")
    public WebElement managePermissionsOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/communications_item")
    @iOSXCUITFindBy(accessibility = "AccountPreferencesController.communicationsSelection")
    public WebElement communicationsOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/disconnect_button")
    @iOSXCUITFindBy(accessibility = "Disconnect online pharmacy account")
    public WebElement disconnectOnlinePharmacyAccountButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "Yes, disconnect")
    public WebElement disconnectConfirmationButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/secondary_button")
    @iOSXCUITFindBy(accessibility = "Cancel")
    public WebElement cancelDisconnectButton;

    public PharmacyAccountSettingsPage(RemoteWebDriver driver) {
        super(driver);
    }

    /**
     * Clicks Disconnect online pharmacy account button
     */
    public void clickDisconnectOnlinePharmacyAccountButton() {
        try {
            click(disconnectOnlinePharmacyAccountButton, 5);
            Reporter.log("Clicked Disconnect online pharmacy account button");
        } catch (Exception e) {
            Reporter.log("Disconnect button not found");
            e.printStackTrace();
        }
    }

    /**
     * Confirms pharmacy account disconnection by clicking 'Yes, disconnect' button
     * Waits for the confirmation button to be clickable before clicking
     */
    public void confirmPharmacyAccountDisconnection() {
        try {
            // Wait for confirmation button to be displayed and clickable
            // isElementDisplayed already has wait built-in
            if (isElementDisplayed(disconnectConfirmationButton, 10)) {
                click(disconnectConfirmationButton, 10);  // Increased timeout for clickability
                Reporter.log("Confirmed pharmacy account disconnection");
            } else {
                Reporter.log("Disconnect confirmation button not displayed");
            }
        } catch (Exception e) {
            Reporter.log("Failed to confirm disconnection: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Clicks Manage Permissions option to open Manage Permissions screen
     */
    public void clickManagePermissionsOption() {
        try {
            click(managePermissionsOption, 10);
            Reporter.log("Clicked Manage Permissions");
        } catch (Exception e) {
            Reporter.log("Manage Permissions option not found: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Cancels pharmacy account disconnection by clicking 'Cancel' button
     */
    public void cancelPharmacyAccountDisconnection() {
        try {
            if (isElementDisplayed(cancelDisconnectButton, 5)) {
                click(cancelDisconnectButton);
                Reporter.log("Cancelled pharmacy account disconnection");
            }
        } catch (Exception e) {
            Reporter.log("Cancel button not found");
            e.printStackTrace();
        }
    }

    /**
     * Verifies that Account Settings screen is displayed
     * @return true if Account Settings title is displayed
     */
    public boolean isAccountSettingsScreenDisplayed() {
        return isElementDisplayed(accountSettingsTitle, 10);
    }

    /**
     * Clicks Personal information option to open Personal information page.
     */
    public void clickPersonalInformationOption() {
        click(personalInformationOption, 5);
        Reporter.log("Clicked Personal information");
    }

    /**
     * Clicks Communications option to open Communications page.
     */
    public void clickCommunicationsOption() {
        click(communicationsOption, 5);
        Reporter.log("Clicked Communications");
    }
}
