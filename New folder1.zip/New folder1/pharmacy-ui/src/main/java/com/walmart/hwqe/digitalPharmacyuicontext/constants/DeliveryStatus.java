package com.walmart.hwqe.digitalPharmacyuicontext.constants;

public enum DeliveryStatus {
    ELIGIBLE,
    INELIGIBLE,
    STORE_INELIGIBLE
}
