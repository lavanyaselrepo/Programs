package com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

@Data
@Builder
@ToString
@EqualsAndHashCode
public class FulfillmentGroup {
    private String orderType;
    private List<Item> items;
}

