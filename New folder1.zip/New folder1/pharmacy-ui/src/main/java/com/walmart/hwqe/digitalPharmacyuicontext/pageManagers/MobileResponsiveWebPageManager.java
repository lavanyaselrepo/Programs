/**
 * MobileResponsiveWebPageManager initialises the page manager for "MOBILE_RESPONSIVE_WEB " platform.
 * It inherits BasePageApplicationManager.
 * Usage : Overridden methods for common interactions that are specific to MOBILE_RESPONSIVE_WEB platform are written over here.
 *
 * @Author: Saloni Sharma
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.pageManagers;

import org.openqa.selenium.remote.RemoteWebDriver;

public class MobileResponsiveWebPageManager extends BasePageApplicationManager {

    public MobileResponsiveWebPageManager(RemoteWebDriver driver, String platform) {

        super(driver, platform);


    }


}
