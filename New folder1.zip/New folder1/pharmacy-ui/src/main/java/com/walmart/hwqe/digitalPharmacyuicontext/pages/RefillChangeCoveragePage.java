package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Page Object for the Refill Coverage-Change flow screens (iOS).
 * Covers:
 *  1. "Change Prescription Coverage" screen  — select insurance type (Prescription insurance / Self pay)
 *  2. "Remove discount card?" bottom sheet   — confirmation prompt before removing discount card
 *  3. "Change Prescription Insurance" screen — shows current discount card; entry point for 270 lookup
 *  4. "Add Insurance" screen                 — 270 lookup results; select found insurance
 *  5. "Select prescription insurance" screen — choose from existing/recently-added insurance list
 * JIRA: PGSPHARM-49814
 * Note: Only iOS locators added — executed on iOS only.
 */
public class RefillChangeCoveragePage extends MobileBasePage {

    // ── Change Prescription Coverage screen ─────────────────────────────────

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name, \"Prescription insurance\")]")
    public WebElement prescriptionInsuranceOption;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=\"Continue\"]")
    public WebElement coverageTypeContinueButton;

    // ── Remove Discount Card bottom sheet ───────────────────────────────────

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Remove discount card?\"]")
    public WebElement removeDiscountCardTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"RefillRemoveCoverageConsentViewController.content\"]")
    public WebElement removeDiscountCardContent;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"HWPrimaryAndLinkButtonView.primaryActionButton\"]")
    public WebElement removeDiscountCardContinueButton;

    // ── Change Prescription Insurance screen ────────────────────────────────

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label, \"Add new insurance\")]")
    public WebElement addNewInsuranceButton;

    // ── Add Insurance screen (270 lookup results) ───────────────────────────

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"HWSeparatorHeaderView.titleLabel\" and @label=\"We found the following\"]")
    public WebElement insuranceFoundHeader;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@label, \"Member ID:\")])[1]")
    public WebElement firstFoundInsuranceOption;

    // ── Select Prescription Insurance screen ────────────────────────────────

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeCell[contains(@name, \"Member ID:\")])[1]")
    public WebElement recentlyAddedInsuranceOption;

    public RefillChangeCoveragePage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getRemoveDiscountCardTitleText() {
        return getText(removeDiscountCardTitle);
    }

    public String getRemoveDiscountCardContentText() {
        return getText(removeDiscountCardContent);
    }

    public void selectPrescriptionInsurance() {
        click(prescriptionInsuranceOption);
    }

    public void clickContinueOnCoverageTypeScreen() {
        click(coverageTypeContinueButton);
    }

    public void clickContinueOnRemoveDiscountCardPrompt() {
        click(removeDiscountCardContinueButton);
    }

    public void clickAddNewInsurance() {
        click(addNewInsuranceButton);
    }

    public void selectFirstFoundInsurance() {
        click(firstFoundInsuranceOption);
    }

    public void selectRecentlyAddedInsurance() {
        click(recentlyAddedInsuranceOption);
    }

    public boolean isInsuranceFoundScreenDisplayed() {
        return isElementDisplayed(insuranceFoundHeader, 10);
    }
}
