package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import java.util.List;

/**
 * Page Object for SMS Family Addition flow during account creation
 * Handles family member selection, DOB entry, and confirmation
 */
public class SMSFamilyAdditionPage extends MobileBasePage {
    
    // Platform-specific XPath patterns for confirmation screen sections
    private static final String ANDROID_SECTION_HEADER = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header' and @text='%s']";
    
    private static final String ANDROID_MEMBER_IN_SECTION = 
        "/parent::android.view.ViewGroup/following-sibling::android.view.ViewGroup" +
        "[not(descendant::android.widget.TextView[@resource-id='com.walmart.android.debug:id/header'])]" +
        "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and contains(@text,'%s')]";
    
    private static final String IOS_SECTION_HEADER = "//XCUIElementTypeStaticText[@name='%s']";
    
    private static final String IOS_MEMBER_IN_SECTION = "/parent::*/following-sibling::XCUIElementTypeCell" + "//XCUIElementTypeStaticText[contains(@name,'%s')]";
    
    // Platform-specific XPath patterns for selecting family members from list
    private static final String ANDROID_FAMILY_MEMBER_BY_NAME = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and contains(@text,'%s')]";
    
    private static final String IOS_FAMILY_MEMBER_BY_NAME = "//XCUIElementTypeStaticText[contains(@name,'%s')]";
    
    // XPath pattern for finding member in confirmation list
    private static final String ANDROID_MEMBER_IN_CONFIRMATION = ".//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and contains(@text,'%s')]";
    
    // Family member list screen
    @AndroidFindBy(id = "com.walmart.android.debug:id/dependent_count")
    public WebElement familyMemberCountText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/selectable_list")
    public WebElement familyMemberList;

    @AndroidFindBy(id = "com.walmart.android.debug:id/wellness_selectable_card_view")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeCell' AND name == 'HWCheckBoxListCell'")
    public List<WebElement> familyMemberCards;

    @AndroidFindBy(id = "com.walmart.android.debug:id/check_btn")
    public List<WebElement> familyMemberCheckboxes;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonView.primaryActionButton")
    public WebElement addSelectedMembersButton;

    // DOB entry screen
    @AndroidFindBy(id = "com.walmart.android.debug:id/dob_title")
    public WebElement dobTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/dob_sub_title")
    public WebElement dobSubTitle;

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/enter_dob']//android.widget.EditText")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND label CONTAINS[c] 'date of birth'")
    public WebElement dobInputField;

    @AndroidFindBy(id = "com.walmart.android.debug:id/confirm_dob_button")
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonView.primaryActionButton")
    public WebElement confirmDobButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/skip_dependent_button")
    public WebElement skipDependentButton;

    // Pet confirmation
    @AndroidFindBy(id = "com.walmart.android.debug:id/pet_consent_layout")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name CONTAINS 'I confirm this is my pet'")
    public WebElement petConsentCheckbox;

    // Adult email field
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/enter_email']//android.widget.EditText")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND label CONTAINS[c] 'email'")
    public WebElement adultEmailField;

    // Confirmation/Success screen
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"connected\")]")
    public WebElement confirmationTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_summary_list")
    public WebElement confirmationSummaryList;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header' and @text='Account holder']")
    public WebElement accountHolderHeader;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header' and @text='Added profiles']")
    public WebElement addedProfilesHeader;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header' and @text='Pending']")
    public WebElement pendingProfilesHeader;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "HWPrimaryStickyButton.primaryActionButton")
    public WebElement doneButton;

    public SMSFamilyAdditionPage(RemoteWebDriver driver) {
        super(driver);
    }

    /**
     * Select family member by name from the list
     * @param familyMemberName - Name of family member to select (e.g., "Aarav P***")
     */
    public void selectFamilyMemberByName(String familyMemberName) {
        try {
            String xpath = isAndroid()
                ? String.format(ANDROID_FAMILY_MEMBER_BY_NAME, familyMemberName)
                : String.format(IOS_FAMILY_MEMBER_BY_NAME, familyMemberName);
            
            WebElement member = remoteDriver.findElement(org.openqa.selenium.By.xpath(xpath));
            click(member);
            Reporter.log("Selected family member: " + familyMemberName);
        } catch (Exception e) {
            Reporter.log("Failed to select family member: " + familyMemberName);
            e.printStackTrace();
        }
    }

    /**
     * Select all family members from the list
     */
    public void selectAllFamilyMembers() {
        try {
            for (WebElement card : familyMemberCards) {
                if (isElementDisplayed(card, 2)) {
                    click(card);
                }
            }
            Reporter.log("Selected all family members");
        } catch (Exception e) {
            Reporter.log("Failed to select all family members");
            e.printStackTrace();
        }
    }

    /**
     * Click "Add selected member(s)" button
     */
    public void clickAddSelectedMembers() {
        click(addSelectedMembersButton, 5);
        Reporter.log("Clicked Add selected member(s) button");
    }

    /**
     * Enter date of birth for family member
     * @param dob - Date of birth in mm/dd/yyyy format
     */
    public void enterDobForFamilyMember(String dob) {
        sendDateField(dobInputField, dob);
        Reporter.log("Entered DOB: " + dob);
    }

    /**
     * Click confirm DOB button
     */
    public void clickConfirmDob() {
        click(confirmDobButton, 5);
        Reporter.log("Clicked Confirm DOB button");
    }

    /**
     * Confirm pet ownership by checking the consent checkbox
     */
    public void confirmPetOwnership() {
        try {
            click(petConsentCheckbox, 5);
            Reporter.log("Confirmed pet ownership");
        } catch (Exception e) {
            Reporter.log("Pet consent checkbox not found or not clickable");
            e.printStackTrace();
        }
    }

    /**
     * Click Done button on confirmation screen
     */
    public void clickDoneOnConfirmationScreen() {
        click(doneButton, 5);
        Reporter.log("Clicked Done on confirmation screen");
    }

    /**
     * Check if the current DOB screen is for a minor profile
     * @return true if "minor profile" text is visible on screen
     */
    public boolean isMinorDobScreen() {
        return isTextDisplayedInIOS("minor profile");
    }

    /**
     * Get confirmation title text
     * @return Confirmation title text (e.g., "You're connected!")
     */
    public String getConfirmationTitle() {
        return getText(confirmationTitle);
    }

    /**
     * Verify confirmation screen is displayed
     * @return true if confirmation screen is displayed
     */
    public boolean isConfirmationScreenDisplayed() {
        return isElementDisplayed(confirmationTitle, 10);
    }

    /**
     * Verify account holder section is displayed
     * @return true if account holder section is displayed
     */
    public boolean isAccountHolderSectionDisplayed() {
        return isElementDisplayed(accountHolderHeader, 5);
    }

    /**
     * Verify added profiles section is displayed
     * @return true if added profiles section is displayed
     */
    public boolean isAddedProfilesSectionDisplayed() {
        return isElementDisplayed(addedProfilesHeader, 5);
    }

    /**
     * Verify pending profiles section is displayed
     * @return true if pending profiles section is displayed (for adult dependents)
     */
    public boolean isPendingProfilesSectionDisplayed() {
        return isElementDisplayed(pendingProfilesHeader, 5);
    }

    /**
     * Helper method to find a family member by name in confirmation list
     * @param memberName - Name of family member to find
     * @return WebElement if found, null otherwise
     */
    private WebElement findMemberByName(String memberName) {
        try {
            return confirmationSummaryList.findElement(
                By.xpath(
                    String.format(ANDROID_MEMBER_IN_CONFIRMATION, memberName)
                )
            );
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Helper method to find member in a specific section
     * Searches for member immediately after the section header before the next section
     * @param headerText - Text of the section header ("Account holder", "Added profiles", or "Pending")
     * @param memberName - Name of family member to find
     * @param sectionName - Section name for logging
     * @return WebElement if found, null otherwise
     */
    private WebElement findMemberInSection(String headerText, String memberName, String sectionName) {
        try {
            String xpath = isAndroid()
                ? String.format(ANDROID_SECTION_HEADER, headerText) + String.format(ANDROID_MEMBER_IN_SECTION, memberName)
                : String.format(IOS_SECTION_HEADER, headerText) + String.format(IOS_MEMBER_IN_SECTION, memberName);
            
            return remoteDriver.findElement(By.xpath(xpath));
        } catch (Exception e) {
            Reporter.log("Member '" + memberName + "' not found in " + sectionName + " section: " + e.getMessage());
            return null;
        }
    }

    /**
     * Verify family member is displayed in confirmation list by name
     * @param memberName - Name of family member to verify
     * @return true if member is displayed in confirmation list
     */
    public boolean isFamilyMemberInConfirmationList(String memberName) {
        WebElement member = findMemberByName(memberName);
        return member != null && isElementDisplayed(member, 5);
    }

    /**
     * Verify family member is in "Account holder" section
     * @param memberName - Name of account holder to verify
     * @return true if member is displayed in Account holder section
     */
    public boolean isMemberInAccountHolderSection(String memberName) {
        WebElement member = findMemberInSection("Account holder", memberName, "Account holder");
        return member != null && isElementDisplayed(member, 5);
    }

    /**
     * Verify family member is in "Added profiles" section (for minor and pet)
     * @param memberName - Name of family member to verify
     * @return true if member is displayed in Added profiles section
     */
    public boolean isMemberInAddedProfilesSection(String memberName) {
        WebElement member = findMemberInSection("Added profiles", memberName, "Added profiles");
        return member != null && isElementDisplayed(member, 5);
    }

    /**
     * Verify family member is in "Pending" section (for adult dependents waiting for acceptance)
     * @param memberName - Name of family member to verify
     * @return true if member is displayed in Pending section
     */
    public boolean isMemberInPendingSection(String memberName) {
        WebElement member = findMemberInSection("Pending", memberName, "Pending");
        return member != null && isElementDisplayed(member, 5);
    }

    /**
     * Get DOB subtitle text (e.g., "Family member 1 of 3")
     * @return DOB subtitle text
     */
    public String getDobSubTitle() {
        return getText(dobSubTitle);
    }

    /**
     * Get number of family members found
     * @return Family member count text (e.g., "We found 3 family member(s)")
     */
    public String getFamilyMemberCount() {
        return getText(familyMemberCountText);
    }
}
