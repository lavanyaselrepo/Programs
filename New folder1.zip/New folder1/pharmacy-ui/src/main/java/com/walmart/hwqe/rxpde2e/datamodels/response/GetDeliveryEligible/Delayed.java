package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class Delayed {
    public String pRefId;
    public int storeId;
    public int patientId;
    public Drug drug;
    public String imageUrl;
    public int fillId;
    public int rxNbr;
    public String reason;
}
