package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.By;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class SignInPage extends MobileBasePage {

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_welcome_primary_button")
    @iOSXCUITFindBy(accessibility = "Sign in")
    @FindBy(xpath = "//div[@data-automation-id='headerSignIn']")
    public WebElement signInButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/launch_action_btn")
    @iOSXCUITFindBy(accessibility = "Sign in or create account")
    public WebElement signInButtonDFD;

    @FindBy(xpath = "//*[@data-testid='sign-in']")
    public WebElement createOrSignInButton;

    @FindBy(xpath = "//*[@id=\"__next\"]/div[1]/span/header/nav/ul/span/div[2]/div/div/div[2]/button/i")
    public WebElement closeLanguageSelectionPopup;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text,'Phone number or email') or contains(@hint,'Phone number or email')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Phone number or email' or @label='Email']")
    @FindBy(xpath = "//*[contains(@aria-label,'Phone number or email')]")
    public WebElement emailInput;

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/phone_number_field']//android.widget.EditText[@clickable='true']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Phone number or email' or @label='Email']")
    @FindBy(xpath = "//*[contains(@aria-label,'Phone number or email')]")
    public WebElement emailInputFallback;

    @AndroidFindBy(id = "com.walmart.android.debug:id/bottom_sheet_content")
    @iOSXCUITFindBy(accessibility = "BottomSheetView.primaryContainerView")
    public WebElement bottomSheetContent;

    @AndroidFindBy(id = "com.walmart.android.debug:id/titleText")
    @iOSXCUITFindBy(accessibility = "PharmacyEnableDeliveryConsentViewController.headerLabel")
    public WebElement bottomSheetTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/not_now_btn")
    @iOSXCUITFindBy(accessibility = "Not now")
    public WebElement bottomSheetNotNowButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "Continue")
    @FindBy(id = "login-continue-button")
    public WebElement continueButton;

    @FindBy(xpath = "//li[contains(@class,'dn db-hdkp ml2 relative')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Account']")
    public WebElement account;

    @FindBy(xpath = "//*[contains(@class,'ld ld-SignOut mr2')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/sign_out_text")
    public WebElement signOut;

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@content-desc='Password']//android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSecureTextField[@label ='Password']")
    @FindBy(xpath = "//input[@type='password']")
    public WebElement passwordInput;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_choice_radio_button_password")
    @iOSXCUITFindBy(accessibility = "AuthChoiceView.passwordRadioButton")
    @FindBy(xpath = "//input[@type='password']")
    public WebElement passwordOption;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_choice_radio_button_password")
    @FindBy(xpath = "//*[@name='password']")
    public WebElement passwordRadioBtn;

    @iOSXCUITFindBy(accessibility = "AuthChoiceView.emailRadioButton")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_choice_radio_button_email")
    public WebElement sendOTPOnEmail;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='AuthHeaderView.titleLabel']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_splash_small_text")
    public WebElement stepUpHeader;

    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    @AndroidFindBy(accessibility = "Digit 1. On entering code in the input fields, the focus will automatically move on to the next input fields")
    @FindBy(id = "input-verificationCode")
    public WebElement inputOtpValue;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Send code']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @FindBy(xpath = "//button[text()='Send code']")
    public WebElement sendCodeButton;

    @iOSXCUITFindBy(id = "ValidateOTPView.ctaButton")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @FindBy(xpath = "//button[text()='Sign in']")
    public WebElement signInButtonForStepUp;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "AuthChoiceView.ctaButton")
    @FindBy(id = "withpassword-sign-in-button")
    public WebElement continueSignInButton;

    @iOSXCUITFindBy(accessibility = "Maybe later")
    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_maybe_later_button")
    public WebElement getNotificationsMayBeLaterSelector;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_zip_code_button")
    @iOSXCUITFindBy(accessibility = "Enter zip code")
    public WebElement enterZipCodeLink;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_enable_location_button")
    @iOSXCUITFindBy(accessibility = "Share precise location")
    public WebElement sharePreciseLocationButton;

    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id=\"com.walmart.android.debug:id/onboarding_zip_code_textinput\"]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Enter zip code']")
    public WebElement enterZipCodeInput;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onboarding_zip_code_search_button")
    @iOSXCUITFindBy(id = "cta.continue")
    public WebElement zipCodeSearchButton;

    @FindBy(xpath = "//*[@link-identifier='getAnotherCode']")
    public WebElement getAnotherCode;

    @AndroidFindBy(xpath = "//*[contains(@text,'Sign in or create')]")
    public WebElement signInOrConnectAccount;

    @FindBy(xpath = "//a[@link-identifier='notNow']")
    public WebElement notNowButtonForPhoneVerification;

    public SignInPage(RemoteWebDriver driver) {
        super(driver);
    }

    public Boolean clickSignInButton() {
        try {
            click(signInButton, 5);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } catch (AssertionError err) {
            err.printStackTrace();
            return false;
        }
    }

    public Boolean clickSignInButtonPharmacyDashboard() {
        try {
            click(signInButtonDFD, 5);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } catch (AssertionError err) {
            err.printStackTrace();
            return false;
        }
    }

    public void closeLanguageSelection() {
        unblockingClick(closeLanguageSelectionPopup, 3, "Language Selection Pop-up on WebPage");
    }

    public void clickCreateAccountOrSignInButton() {
        click(createOrSignInButton);
    }

    public void clickContinueButton() {
        unblockingClick(continueButton, 3, "continue button after entering email");
    }

    public void enterEmail(String email) {
        Throwable lastError = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                Reporter.log("Entering email using primary locator, attempt " + attempt);
                sendTextOrThrowException(emailInput, email, 5);
                return;
            } catch (Throwable primaryEx) {
                Reporter.log("Primary locator failed on attempt " + attempt + ", trying fallback: " + primaryEx.getMessage());
                try {
                    sendTextOrThrowException(emailInputFallback, email, 5);
                    return;
                } catch (Throwable fallbackEx) {
                    lastError = fallbackEx;
                    Reporter.log("Fallback locator also failed on attempt " + attempt + ": " + fallbackEx.getMessage());
                }
            }
        }
        String pageSource = remoteDriver.getPageSource();
        Reporter.log("All email input attempts failed. Page source:\n" + pageSource);
        Assert.fail("Failed to enter email after all retries: " + lastError.getMessage());
    }

    public void clickPasswordOption() {
        unblockingClick(passwordOption, 3, "password option radio button");
    }

    public void enterPassword(String password) {
        sendText(passwordInput, password);
    }

    public void clickOnEnterPasswordRadioBtn() {
        click(passwordRadioBtn);
    }

    public void clickContinueSignInButton() {
        click(continueSignInButton);
        if (remoteDriver instanceof IOSDriver) {
            // Wait for the CTA button to disappear — signals the sign-in request has been submitted
            // and the app is transitioning. Replaces a fixed 4s sleep with a condition-based exit.
            try {
                new WebDriverWait(remoteDriver, Duration.ofSeconds(15))
                        .until(ExpectedConditions.invisibilityOfElementLocated(
                                AppiumBy.accessibilityId("AuthChoiceView.ctaButton")));
            } catch (TimeoutException ignored) {
                Reporter.log("AuthChoiceView CTA still visible after 15s — proceeding anyway");
            }
        }
    }

    public void clickMayBeLaterNotifications() {
        if (isElementDisplayed(getNotificationsMayBeLaterSelector, 5)) {
            click(getNotificationsMayBeLaterSelector);
        }
    }

    public void fillZipCodeDetails() {
        clickEnterZipCodeLink();
        enterZipCode("72719");
        clickSearchZipCodeButton();
    }

    public void clickEnterZipCodeLink() {
        click(enterZipCodeLink);
    }

    public void dismissLocationOnboardingScreen() {
        try {
            // findElements returns an empty list instantly when the screen is absent —
            // no WebDriverWait overhead. isElementDisplayed(el, 2) was costing 2s every run
            // because it polled for the full timeout before deciding the screen wasn't there.
            if (!remoteDriver.findElements(
                    By.id("com.walmart.android.debug:id/onboarding_zip_code_button")).isEmpty()) {
                click(enterZipCodeLink);
                Reporter.log("Dismissed location onboarding screen via Enter zip code");
            }
        } catch (Exception e) {
            Reporter.log("Location onboarding screen not present, continuing");
        }
    }

    public void clickSharePreciseLocationButton() {
        click(sharePreciseLocationButton);
    }

    public void enterZipCode(String pinCode) {
        sendText(enterZipCodeInput, pinCode);
    }

    public void clickSearchZipCodeButton() {
        click(zipCodeSearchButton);
    }


    public void clickSendOtpOnEmailRadioButton() {
        click(sendOTPOnEmail, 3);
    }

    public boolean isStepUpEnabled() {
        return isElementDisplayed(sendOTPOnEmail, 5);
    }

    public boolean isSendCodeForStepUpEnabledDisplayed() {
        return isElementDisplayed(sendCodeButton, 10);
    }

    public void clickSendcode() {
        click(sendCodeButton, 3);
    }

    public void enterInputOtpValue(String otp) {
        sendText(inputOtpValue, otp, 10);
    }

    public void clickSignInButtonForStepUp() {
        click(signInButtonForStepUp, 5);
    }

    public boolean isStepUpHeaderDisplayed() {
        return isElementDisplayed(stepUpHeader, 5);
    }

    public boolean isSignInButtonNotDisplayed() {
        return invisibilityOfElement(signInButtonForStepUp, 10);
    }

    public void clickOnAccount(){
        click(account);
    }

    public void clickOnSignout(){

        click(signOut);
    }

    public void clickGetAnotherCode() {
        try {
            click(getAnotherCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void clickOnSignInOrConnectAccount() {
        click(signInOrConnectAccount);
    }

    public void clickNotNowForPhoneVerification() {
        unblockingClick(notNowButtonForPhoneVerification, 4, "Not Now button for phone verification" );
    }

    public void dismissAllBottomSheets() {
        int waitTime = 6; // first bottomsheet may take time to load due to pharmacydashboard load time
        for (int i = 0; i < 5; i++) {
            if (isElementDisplayed(bottomSheetContent, waitTime)) {
                try {
                    String title = bottomSheetTitle.getText();
                    if (title != null && (title.contains("Pharmacy delivery") || title.contains("delivery consent"))) {
                        click(bottomSheetNotNowButton, 3);
                        Reporter.log("Dismissed delivery consent bottom sheet via Not now button");
                    } else {
                        remoteDriver.navigate().back();
                        Reporter.log("Dismissed bottom sheet via navigate back");
                    }
                } catch (Throwable e) {
                    if (bottomSheetContent.isDisplayed()) {
                        // check one more time if bottomsheet is still displayed
                        remoteDriver.navigate().back();
                    }
                    Reporter.log("Dismissed bottom sheet via navigate back (fallback): " + e.getMessage());
                }
                waitTime = 3;
            } else {
                if (i == 0) {
                    // handles: Encountered internal error running command: io.appium.uiautomator2.common.exceptions.StaleElementReferenceException:
                    // The element 'By.id: com.walmart.android.debug:id/bottom_sheet_content' does not exist in DOM anymore
                    performSleep(5);
                    continue;
                }
                break;
            }
        }
    }
}
