package com.walmart.hwqe.rxpde2e.datamodels.request.ConnexusPatientDataForPickup;
@lombok.Getter
@lombok.Setter
public class Drug {

    public String name;
    public String ndc;
    public int itemId;
    public int rxProdId;
    public int controlCode;
    public int presMultiSrcCode;
    public int onHandQty;
    public String gpiCode;
    public String usualCost;
    public String actCost;
    public String orgUsualCost;
    public int rxNbr;
    public int rxFillId;
}
