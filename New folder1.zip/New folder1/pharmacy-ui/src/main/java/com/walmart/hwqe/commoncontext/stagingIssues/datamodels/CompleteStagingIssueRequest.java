package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;
import java.util.ArrayList;

import lombok.*;

@Getter
@Setter
public class CompleteStagingIssueRequest {

	public String purchaseOrderId;
    public String packageToteId;
    public int issueTypeCode;
    public int stagingBagNumber;
    public ArrayList<FillAndBagInfo> fillAndBagInfo;
}
