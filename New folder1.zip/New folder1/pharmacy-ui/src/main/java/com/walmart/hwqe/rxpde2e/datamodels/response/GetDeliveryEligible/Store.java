package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class Store {
    public ArrayList<PharmacyOperatingHour> pharmacyOperatingHours;
    public int storeId;
    public String storeName;
    public String timeZone;
    public ArrayList<String> pharmacyAccessPoints;
    public double latitude;
    public double longitude;
    public Contact contact;
    public ArrayList<Address> address;
}
