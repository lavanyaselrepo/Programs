package com.walmart.hwqe.saucelabscontext;


import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.webcontext.BrowserType;

public class SaucelabsWebConfig {
    PropertyReader prop = PropertyReaderHelper.getInstance();
    private BrowserType browserType;

    public BrowserType getBrowserType() {
        if (browserType == null) {
            return BrowserType.Chrome;
        }
        return browserType;
    }

    public void setBrowserType(BrowserType browserType) {
        this.browserType = browserType;
    }

    public String getOsType() {
        if (osType == null) {
            return "Windows 11";
        }
        return null;
    }

    public void setOsType(String osType) {
        this.osType = osType;
    }


    public String getSLUserName() {
        if (slUserName == null) {
            return prop.getProperty("app.SL.id");
        }
        return slUserName;
    }

    public void setSLUserName(String plexusUserName) {
        this.slUserName = plexusUserName;
    }

    public String getSLUserKey() {
        if (slUserKey == null) {
            return prop.getProperty("app.SL.token");
        }
        return slUserKey;
    }

    public void setSLUserKey(String plexusUserKey) {
        this.slUserKey = plexusUserKey;
    }

    public String getSlTestName() {
        if (slTestName == null) {
            return "Dragon Test";
        }
        return slTestName;
    }

    public void setSlTestName(String plexusUserKey) {
        this.slTestName = slTestName;
    }

    private String osType;
    private String slUserName;
    private String slUserKey;
    private String slTestName;
}
