package com.walmart.hwqe.saucelabscontext;


import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import org.json.JSONObject;
import org.testng.Assert;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;

public class SauceLabsAPIManager {
    private AutomationManager am = AutomationManager.getInstance();
    private PropertyReader prop = PropertyReaderHelper.getInstance();
    private PropertyReader vaultKeys = PropertyReaderHelper.getInstance();
    public SauceLabsAPIManager(){}

    private HashMap<String, String> getSauceAPIHeaders(){
        HashMap<String, String> headers = new HashMap<>();

        headers.clear();
        byte[] message = (vaultKeys.getProperty("z.run.sl.un")+":"+vaultKeys.getProperty("z.run.sl.ak")).getBytes(StandardCharsets.UTF_8);
        String encoded = Base64.getEncoder().encodeToString(message);
        headers.put("Authorization","Basic "+encoded);
        return headers;
    }

    public ServiceResponse getSauceLabsJobsByUserId(){
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        HashMap<String, String> headers = getSauceAPIHeaders();
        String sauceUri = prop.getProperty("sauce.labs.base.uri");
        sauceUri = sauceUri.replace("{userName}", vaultKeys.getProperty("z.run.sl.un"));
        req.setHeaders(headers);
        req.setUrl(sauceUri);
        resp = am.getRestContext().performGet(req);

        Assert.assertEquals(resp.getStatusCode(), 200);
        return resp;
    }

    public ServiceResponse getSauceLabsJobByJobId(String jobId){
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        HashMap<String, String> headers = getSauceAPIHeaders();
        String sauceUri = prop.getProperty("sauce.labs.base.uri");
        sauceUri = sauceUri.replace("{userName}", vaultKeys.getProperty("z.run.sl.un"));
        req.setHeaders(headers);
        req.setUrl(sauceUri+"/"+jobId);
        resp = am.getRestContext().performGet(req);

        Assert.assertEquals(resp.getStatusCode(), 200);
        return resp;
    }

    public ServiceResponse updateRunStatusForTest(String jobId, Boolean passed){
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        HashMap<String, String> headers = getSauceAPIHeaders();
        String sauceUri = prop.getProperty("sauce.labs.base.uri");
        JSONObject reqBody = new JSONObject();
        reqBody.put("passed", passed);
        req.setRequestPayload(reqBody.toString());
        sauceUri = sauceUri.replace("{userName}", vaultKeys.getProperty("z.run.sl.un"));
        req.setHeaders(headers);
        req.setUrl(sauceUri+"/"+jobId);
        resp = am.getRestContext().performPut(req);

        Assert.assertEquals(resp.getStatusCode(), 200);
        return resp;
    }
}