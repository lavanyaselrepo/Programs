package com.walmart.hwqe.digitalPharmacyuicontext.dataModels.request;

import lombok.Data;

import java.util.List;

@Data
public class PatientRxTestCaseData {

    int storeId;
    String caregiverFirstName, caregiverLastName, caregiverDob, caregiverEmail, caregiverPassword, caregiverGender;
    Boolean isPatientCreationNeeded = false;
    RxData rxData;
    Boolean isDm;
    String rxMessagingPhoneNo;
    String patientId;
    List<DependentData> adultDependents;
    List<DependentData> minorDependents;
    List<DependentData> petDependents;

    @Data
    public static class DependentData {
        String dependentFirstName, dependentLastName, dependentType, dependentEmail, dependentPassword, dependentGender, dependentDob;
        RxData rxData;
        Boolean isDependentCreationNeeded = false;
        String patientId;
    }

    @Data
    public static class RxData {
        int rxInEod;
        int rxReadyForPickup;
        int rxReadyForRefill;
        int rxInFilling;
        List<String> createdRxListRFP;
        List<String> createdRxListEOD;
        List<String> createdRxListFilling;
    }
}