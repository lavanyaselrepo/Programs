package com.walmart.hwqe.digitalPharmacyuicontext.constants;

public enum FillStatusInfo {
    READY_FOR_REFILL,
    READY_FOR_PICKUP,
    RECEIVED,
    DELAYED,
    FILLING,
    PAID,
    CANCELLED
}
