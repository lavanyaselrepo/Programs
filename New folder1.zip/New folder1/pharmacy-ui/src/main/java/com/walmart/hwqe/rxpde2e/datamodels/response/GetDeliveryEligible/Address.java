package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

@lombok.Getter
@lombok.Setter
public class Address {
    public String addressLine1;
    public String city;
    public String state;
    public String type;
    public String country;
    public String postalCode;
}
