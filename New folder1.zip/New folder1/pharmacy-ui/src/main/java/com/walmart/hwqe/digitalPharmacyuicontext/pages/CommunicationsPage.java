package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

/**
 * Page Object for the Pharmacy Account Settings > Communications screen.
 * Android and iOS locators are MCP-verified.
 */
public class CommunicationsPage extends MobileBasePage {

    // ----- Page header -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/communications_title")
    @iOSXCUITFindBy(accessibility = "HWSeparatorHeaderView.titleLabel")
    public WebElement communicationsTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/communications_subtitle")
    @iOSXCUITFindBy(accessibility = "HWSeparatorHeaderView.descriptionLabel")
    public WebElement communicationsSubtitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/account_holder_name")
    @iOSXCUITFindBy(accessibility = "HWCardWithLabelsAndImageView.descriptionLabel")
    public WebElement accountHolderName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/account_type")
    @iOSXCUITFindBy(accessibility = "HWCardWithLabelsAndImageView.descriptionLabel")
    public WebElement accountTypeLabel;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_notifications_title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='HealthServiceNotificationSettingsView.titleLabel' and @value='Pharmacy and health services notifications']")
    public WebElement pharmacyNotificationsTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_notifications_description")
    @iOSXCUITFindBy(accessibility = "HealthServiceNotificationSettingsView.descriptionLabel")
    public WebElement pharmacyNotificationsDescription;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/sms_preference']//android.widget.TextView[@resource-id='com.walmart.android.debug:id/option_label']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='smsEnrollmentSwitchPharmacy and health services notifications']//XCUIElementTypeStaticText[@name='Receive text notifications']")
    public WebElement receiveTextNotificationsLabel;

    // iOS: the outer XCUIElementTypeButton wraps a label + toggle; tapping the button center
    // lands on the label and does nothing. The inner XCUIElementTypeSwitch is the interactive
    // target that triggers enrollment navigation. Predicate string is used instead of XPath
    // because nested XPath traversal on iOS adds ~2s find + ~20s post-click WDA idle wait.
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/sms_preference']//android.widget.Switch[@resource-id='com.walmart.android.debug:id/ld_switch_toggle']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeSwitch' AND name == 'HWSwitchWithVerticalAlignedView.wcpSwitch'")
    public WebElement receiveTextNotificationsToggle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/notification_category_title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='HealthServiceNotificationSettingsView.titleLabel' and not(contains(@value,'Pharmacy and health services'))]")
    public List<WebElement> notificationCategoryTitles;

    // ----- Subcategory text-notification toggles -----
    // iOS: targets the inner XCUIElementTypeSwitch inside the category button; value="1" means ON.
    //      Same pattern as receiveTextNotificationsToggle.
    // Android: anchors on notification_category_title TextView (@text), then navigates via
    //          following-sibling to text_notification_preference_category and finds the inner
    //          Switch (checked="true" when ON). Avoids content-desc on option_switch LinearLayout
    //          which is not reliably exposed by UIAutomator2 on Sauce Labs real devices.
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/notification_category_title' and @text='Prescription refill status']/following-sibling::android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/text_notification_preference_category']//android.widget.Switch[@resource-id='com.walmart.android.debug:id/ld_switch_toggle']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='smsEnrollmentSwitchPrescription refill status']//XCUIElementTypeSwitch")
    public WebElement prescriptionRefillStatusTextToggle;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/notification_category_title' and @text='Refill reminder']/following-sibling::android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/text_notification_preference_category']//android.widget.Switch[@resource-id='com.walmart.android.debug:id/ld_switch_toggle']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='smsEnrollmentSwitchRefill reminder']//XCUIElementTypeSwitch")
    public WebElement refillReminderTextToggle;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/notification_category_title' and @text='Appointment status']/following-sibling::android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/text_notification_preference_category']//android.widget.Switch[@resource-id='com.walmart.android.debug:id/ld_switch_toggle']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='smsEnrollmentSwitchAppointment status']//XCUIElementTypeSwitch")
    public WebElement appointmentStatusTextToggle;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/notification_category_title' and @text='Clinical outreach']/following-sibling::android.view.ViewGroup[@resource-id='com.walmart.android.debug:id/text_notification_preference_category']//android.widget.Switch[@resource-id='com.walmart.android.debug:id/ld_switch_toggle']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='smsEnrollmentSwitchClinical outreach']//XCUIElementTypeSwitch")
    public WebElement clinicalOutreachTextToggle;


    // ----- Toggle ON state: enrolled phone number + edit button -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/option_value")
    @iOSXCUITFindBy(accessibility = "HealthServiceNotificationSettings.phoneNumberLabel")
    public WebElement enrolledPhoneNumberLabel;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.firstButton")
    public WebElement optOutConfirmButton;


    // ----- Permissions bottom sheet (Notifications are off) -----
    // iOS: only has a single "Get notifications" primary button — no dismiss/secondary button.
    // Dismiss by navigateBack() when secondary button is absent.
    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_title")
    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.titleLabel")
    public WebElement notificationsOffTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_cancel_button")
    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.secondaryActionButton")
    public WebElement notificationsOffNoThanksButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_settings_button")
    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.primaryActionButton")
    public WebElement notificationsOffGetNotificationsButton;

    public CommunicationsPage(RemoteWebDriver driver) {
        super(driver);
    }

    public boolean isCommunicationsPageDisplayed() {
        return isElementDisplayed(communicationsTitle, 10);
    }

    public String getCommunicationsTitleText() {
        return getText(communicationsTitle);
    }

    public String getCommunicationsSubtitleText() {
        return getText(communicationsSubtitle);
    }

    public String getAccountHolderNameText() {
        String raw = getText(accountHolderName);
        return raw != null ? raw.split("\n")[0].trim() : null;
    }

    public String getAccountTypeLabelText() {
        String raw = getText(accountTypeLabel);
        return raw != null && raw.contains("\n") ? raw.split("\n")[1].trim() : raw;
    }

    public String getPharmacyNotificationsTitleText() {
        return getText(pharmacyNotificationsTitle);
    }

    public String getPharmacyNotificationsDescriptionText() {
        return getText(pharmacyNotificationsDescription);
    }

    public String getReceiveTextNotificationsLabelText() {
        return getText(receiveTextNotificationsLabel);
    }

    public boolean isReceiveTextNotificationsToggleOff() {
        return !isReceiveTextNotificationsToggleOn();
    }

    public String getCategoryTitleAt(int index) {
        try {
            return getText(notificationCategoryTitles.get(index));
        } catch (Exception e) {
            Reporter.log("Could not get category title at index " + index + ": " + e.getMessage());
            return "";
        }
    }

    /** Returns true when the SMS toggle is ON. */
    public boolean isReceiveTextNotificationsToggleOn() {
        try {
            if (isIOS()) {
                return "1".equals(receiveTextNotificationsToggle.getAttribute("value"));
            }
            return "true".equals(receiveTextNotificationsToggle.getAttribute("checked"));
        } catch (Exception e) {
            Reporter.log("Could not check text notifications toggle ON state: " + e.getMessage());
            return false;
        }
    }

    /** Returns the enrolled phone number text displayed under the toggle (toggle ON state). */
    public String getEnrolledPhoneNumberText() {
        return getText(enrolledPhoneNumberLabel);
    }

    /** Returns true if the enrolled phone number label is displayed (indicates toggle is ON). */
    public boolean isEnrolledPhoneNumberDisplayed() {
        return isElementDisplayed(enrolledPhoneNumberLabel, 5);
    }

    /** Returns true if the opt-out bottom sheet is visible. */
    public boolean isOptOutBottomSheetDisplayed() {
        return isElementDisplayed(optOutConfirmButton, 5);
    }

    /** Taps "Yes, opt out" on the opt-out bottom sheet to confirm opt-out. */
    public void confirmOptOut() {
        click(optOutConfirmButton, 5);
        Reporter.log("Confirmed opt-out from text notifications");
    }

    /**
     * Returns {@code true} when the text notification toggle for the given subcategory is ON.
     * iOS reads {@code value="1"} from the XCUIElementTypeSwitch; Android reads {@code checked="true"} from the Switch.
     *
     * @param categoryName category title as shown in UI, e.g. "Prescription refill status"
     */
    public boolean isCategoryTextNotificationToggleOn(String categoryName) {
        WebElement toggle;
        switch (categoryName) {
            case "Prescription refill status": toggle = prescriptionRefillStatusTextToggle; break;
            case "Refill reminder":            toggle = refillReminderTextToggle;            break;
            case "Appointment status":         toggle = appointmentStatusTextToggle;         break;
            case "Clinical outreach":          toggle = clinicalOutreachTextToggle;          break;
            default:
                Reporter.log("isCategoryTextNotificationToggleOn: unknown category: " + categoryName);
                return false;
        }
        try {
            if (isIOS()) {
                return "1".equals(toggle.getAttribute("value"));
            }
            return "true".equals(toggle.getAttribute("checked"));
        } catch (Exception e) {
            Reporter.log("Could not check SMS toggle for '" + categoryName + "': " + e.getMessage());
            return false;
        }
    }

    /** Taps the Receive text notifications toggle to navigate to enrollment or trigger opt-out sheet. */
    public void tapReceiveTextNotificationsToggle() {
        click(receiveTextNotificationsToggle, 5);
        Reporter.log("Tapped Receive text notifications toggle");
    }

    /**
     * Dismisses the 'Notifications are off' bottom sheet if visible.
     *
     * <p>iOS: only a "Get notifications" primary button is shown — no dismiss button.
     * Tapping it surfaces the iOS system notification permission alert ("Allow" / "Don't Allow").
     * "Allow" is tapped via coordinates since the system alert is outside WDA's app context.
     * After granting, the sheet is permanently dismissed for the simulator.
     *
     * <p>Android: tries the secondary "No thanks" button first; falls back to navigate back.
     */
    public void dismissNotificationsOffBottomSheet() {
        try {
            if (isElementDisplayed(notificationsOffNoThanksButton, 5)) {
                click(notificationsOffNoThanksButton, 2);
                Reporter.log("Dismissed 'Notifications are off' bottom sheet via No thanks button");
            } else if (isElementDisplayed(notificationsOffTitle, 2)) {
                click(notificationsOffGetNotificationsButton, 5);
                Reporter.log("Tapped 'Get notifications' on bottom sheet");
                click(notificationsOffNoThanksButton, 8);
                Reporter.log("Tapped 'Allow' on iOS notification permission alert");
            }
        } catch (Exception e) {
            Reporter.log("Error dismissing 'Notifications are off' bottom sheet: " + e.getMessage());
        }
    }
}
