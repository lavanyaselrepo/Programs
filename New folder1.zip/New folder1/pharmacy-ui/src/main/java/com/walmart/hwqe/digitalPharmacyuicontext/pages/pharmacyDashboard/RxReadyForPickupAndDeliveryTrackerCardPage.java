package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;

import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commoncontext.models.pagemodels.common.Attribute;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import lombok.Getter;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RxReadyForPickupAndDeliveryTrackerCardPage extends FillStatusTrackerCardPage {

    // Android resource IDs
    private static final String ID_CUSTOMER_NAME    = "com.walmart.android.debug:id/pharmacy_customer_name";
    private static final String ID_DRUG_NAME        = "com.walmart.android.debug:id/pharmacy_drugname";
    private static final String ID_PATIENT_DUE      = "com.walmart.android.debug:id/pharmacy_patient_due_amount";
    private static final String ID_SEE_DETAILS_BTN  = "com.walmart.android.debug:id/pharmacy_see_details_button";

    // iOS XPath locators
    private static final String IOS_XPATH_DRUG_LABEL    = ".//XCUIElementTypeStaticText[@name='RFPFillInfoView.drugLabel']";
    private static final String IOS_XPATH_PATIENT_LABEL = ".//XCUIElementTypeOther[@name='RFPPatientPharmacyImageWithLabelView']"
            + "//XCUIElementTypeStaticText[@name='HWImageWithLabelView.label']";
    private static final String IOS_XPATH_PRICE_LABEL   = ".//XCUIElementTypeStaticText[@name='RFPFillInfoContainerView.priceLabel']";
    private static final String IOS_XPATH_SEE_DETAILS_BTN_TEMPLATE =
            "//XCUIElementTypeButton[@name='RFPFillActionView.linkButton'"
            + " and contains(@label,'%s')"
            + " and contains(@label,'%s')]";

    public RxReadyForPickupAndDeliveryTrackerCardPage(RemoteWebDriver driver) {
        super(driver);
    }

    @iOSXCUITFindBy(accessibility = "RFPFillSectionHeaderView.headerLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_prescription_ready_header")
    WebElement fillStatusCardHeaderText;

    @iOSXCUITFindBy(accessibility = "RFPFillSectionHeaderView.subheaderLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_address")
    WebElement fillStatusCardSubHeaderText;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_current_open_time")
    @iOSXCUITFindBy(accessibility = "RFPInStoreInfoView.combinedAccessibilityElement")
    WebElement storeTiming;

    @iOSXCUITFindBy(accessibility = "HWImageWithLabelView.imageView")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    WebElement petPatientIcon;

    @iOSXCUITFindBy(accessibility = "HWImageWithLabelView.imageView")
    @AndroidFindBy(id = "com.walmart.android.debug:id/patient_name")
    WebElement humanPatientIcon;

    // See Details in this page is equivalent
    @iOSXCUITFindBy(accessibility = "See details")
    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_details")
    WebElement fillDetailsArrowCTA;

    @iOSXCUITFindBy(accessibility = "RFPFillInfoView.drugLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_drugname")
    WebElement rxName;

    @iOSXCUITFindBy(accessibility = "RFPFillInfoContainerView.priceLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_patient_due_amount")
    WebElement rxEstimatedPrice;

    //@FindBy(className = "w_U9_0 w_U0S3 w_fJSx f7 f4-l")
    @AndroidFindBy(id = "com.walmart.android.debug:id/feature_available_header")
    WebElement deliveryAvailableMessage;

    //@FindBy(className = "w_hhLG w_DZvO w_0_LY pa0")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_learn_more_button")
    WebElement learnMoreCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_ineligible_header")
    @FindBy(id = "prescription-ready-label-rfp-0")
    WebElement prescriptionReadyMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_address")
    @FindBy(id = "prescription-ready-label-rfp-0")
    WebElement storeAddress;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_customer_name")
    @iOSXCUITFindBy(accessibility = "HWImageWithLabelView.label")
    @FindBy(xpath = "//*[contains(@id,'patient-name-delivery-ineligible-rfp')]")
    WebElement patientName;

    @FindBy(xpath = "//*[contains(@id,'pet-icon')]")
    WebElement petIcon;

    @FindBy(xpath = "//*[contains(@id,'user-icon')]")
    WebElement humanIcon;

    @FindBy(xpath = "//*[contains(@id,'drug-image-delivery-ineligible-rfp')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_imageview")
    @iOSXCUITFindBy(accessibility = "RFPFillInfoContainerView.imageView")
    WebElement drugImage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_prescription_ready_message")
    @FindBy(id = "delivered-msg-rfp-0")
    WebElement prescriptionReadySubMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_patient_due_amount")
    @FindBy(id = "price-delivery-eligible-rfp-0-0")
    WebElement paymentAmountDue;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_see_details_button")
    @iOSXCUITFindBy(accessibility = "See details")
    @FindBy(xpath = "(//button[text()='See details'])[1]")
    WebElement seeDetails;

    @AndroidFindBy(id = "com.walmart.android.debug:id/textview_add_cart_cta")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name='stepper.addToCartButton'])[1]")
    @FindBy(xpath = "//span[text()='Add to cart']")
    WebElement addToCart;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[starts-with(@name, 'stepper.incrementButton')])[1]")
    @FindBy(xpath = "//button[contains(@aria-label, 'Increase quantity') and @aria-disabled='true']")
    WebElement increaseQuantity;

    @FindBy(xpath = "//span[text()='Add to cart']")
    List<WebElement> addToCartBtns;

    @FindBy(xpath = "//button[contains(@aria-label, 'Decrease quantity') and @aria-disabled='false']")
    WebElement decreaseQuantity;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_info_circle")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[starts-with(@name, 'RFPInStoreInfoView.infoButton')])[1]")
    @FindBy(id = "store-info-icon-rfp-0")
    WebElement infoCTA;

    // ---- Store Information bottom sheet (opened by tapping the info icon) ----
    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_bottom_sheet_toolbar_title")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Store Information' AND label == 'Store Information'")
    WebElement storeInfoSheetTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_display_name")
    @iOSXCUITFindBy(accessibility = "FillStoreHeaderView.headerLabel")
    WebElement storeInfoDisplayName;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_address")
    @iOSXCUITFindBy(accessibility = "FillStoreHeaderView.subheaderLabel")
    WebElement storeInfoAddress;

    @AndroidFindBy(id = "com.walmart.android.debug:id/store_phone_number")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='FillStoreInfoContainerView.phoneButton']//XCUIElementTypeStaticText")
    WebElement storeInfoPhoneNumber;

    // iOS: day and time are combined into a single element — getStoreInfoHoursText() handles this per platform
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_day_or_time")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='FillStoreInfoContainerView.timingView']//XCUIElementTypeStaticText")
    WebElement storeInfoHoursDay;

    // iOS: hours are combined with storeInfoHoursDay above; this locator is Android-only
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_time")
    WebElement storeInfoHoursTime;

    @AndroidFindBy(id = "com.walmart.android.debug:id/ld_bottom_sheet_toolbar_icon_close")
    @iOSXCUITFindBy(accessibility = "FillStoreInfoController.Close")
    WebElement storeInfoCloseButton;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inStorePharmacyOnlyHeaderText;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inStorePharmacyOnlyDescriptionMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement whyLink;

    @AndroidFindBy(id = "com.walmart.android.debug:id/card_header")
    @iOSXCUITFindBy(accessibility = "RFPInStoreInfoView.headerLabel")
    @FindBy(id = "store-info-icon-rfp-0")
    WebElement ratherGetThemInStoreMessage;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_address_group")
    @iOSXCUITFindBy(accessibility = "RFPInStoreInfoView.combinedAccessibilityElement")
    WebElement readyAtStoreLabel;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement storeCloseHoursTodayMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement storeAddressMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inEligiblePopupHeaderMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inEligiblePopupSubHeaderMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inEligiblePopupInfoMessage;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inEligiblePopupCloseIcon;

    @FindBy(id = "store-info-icon-rfp-0")
    WebElement inEligiblePopupCloseBtn;

    @FindBy(xpath = "//button[@class='w_hhLG w_8nsR w_jDfj'][1]")
    WebElement clickOnAddCartButton;

    @FindBy(xpath = "//div[@class='flex items-center justify-between w-100']/div")
    WebElement clickOnTheDeliveryAddressButton;

    @FindBy(xpath = "//*[text()='Pickup']")
    WebElement clickOnPickupIcon;

    @FindBy(xpath = "//button[text()='View all times']")
    WebElement clickOnViewAllTimesOption;

    @FindBy(id = "fulfillment-option-curbside-pickup")
    WebElement clickOnPickup;

    @FindBy(xpath = "//*[text()='Curbside pickup not available']")
    WebElement errorMessageCurbside;

    @FindBy(xpath = "//button[text()='Close']")
    WebElement clickClosButton;

    @FindBy(xpath = "(//input[@class='w_Vy48'])[1]")
    WebElement clickRadiobutton;

    @FindBy(xpath = "//button[text()='Reserve']")
    WebElement clickReserveButton;

    @FindBy(xpath = "//button[text()='Pick up instead']")
    WebElement clickPickupInstead;

    @FindBy(xpath = "//button[text()='See times']")
    WebElement clickSeeTimes;

    @iOSXCUITFindBy(accessibility = "Search Walmart")
    @AndroidFindBy(id = "com.walmart.android.debug:id/search_view")
    @FindBy(xpath = "//input[@name='q']")
    WebElement clickSearch;
    @iOSXCUITFindBy(accessibility = "searchmenu")
    @AndroidFindBy(xpath = "(//android.widget.ImageView[@resource-id='com.walmart.android.debug:id/navigation_bar_item_icon_view'])[3]")
    WebElement clickGlobalSearch;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_ineligible_header")
    @FindBy(xpath = "//i[@class='ld ld-Search absolute']")
    WebElement clickIcon;

    @iOSXCUITFindBy(accessibility = "WCPBadge.label")
    @FindBy(id = "cart-badge")
    WebElement cartBadge;

    // Note: Only Android locators added - executed on Android only
    // TODO: Add iOS locators when flow is executed on iOS platform
    @AndroidFindBy(id = "com.walmart.android.debug:id/button_minus")
    @FindBy(xpath = "ld ld-Minus")
    WebElement decreaseQuantityBtn;

    /** "Pending delivery approval" label shown on the ATC card after caregiver sends
     * a delivery-enable request to a dependent (replaces the "Add to cart" button area). */
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Pending delivery approval']")
    @FindBy(xpath = "//*[text()='Pending delivery approval']")
    WebElement pendingDeliveryApprovalOnATCCard;

    /** All RFP card containers on the dashboard (one per store).
     * -- GETTER --
     * Returns all card container elements for per-card child lookups.
     */
    @Getter
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_fill_card")
    List<WebElement> allRfpCards;

    /** Store address labels across all RFP cards ("Ready at the [Store Name]"). */
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_store_address_group")
    List<WebElement> allStoreAddressLabels;

    /** All drug name labels across all cards, in DOM order. */
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_drugname")
    List<WebElement> allRxNameLabels;

    /** All patient name labels across all cards, in DOM order. */
    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_customer_name")
    List<WebElement> allPatientNameLabels;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[starts-with(@name, 'stepper.decrementButton')])[1]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/textview_count")
    @FindBy(xpath = "//*[@class='ld ld-Minus']")
    WebElement max1Txt;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[starts-with(@name, 'stepper.mainButton')])[1]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/quantitystepper_root")
    @FindBy(xpath = "//button[@data-automation-id='add-to-cart']")
    WebElement clickAddCartButton;

    @iOSXCUITFindBy(accessibility = "Search Walmart")
    @AndroidFindBy(className = "android.widget.EditText")
    @FindBy(xpath = "//input[@name='q']")
    WebElement searchBar;

    @iOSXCUITFindBy(accessibility = "some id here - what is got it button?")
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/search_onboarding_bottom_sheet_button']")
    WebElement clickGotItButton;

    @FindBy(xpath = "//*[text()='Acknowledge']")
    WebElement clickAcknowledgeButton;
    @FindBy(xpath = "//*[text()='Update zip code']")
    WebElement clickUpdateZipCode;

    @FindBy(xpath = "//*[text()='Save']")
    WebElement clickSaveButton;

    @FindBy(xpath = "//button[@data-automation-id=\"atc\"]")
    List<WebElement> addToCartButtons;

    @FindBy(xpath = "//input[@placeholder='mm/dd/yyyy']")
    WebElement popupDobField;

    @FindBy(xpath = "//input[@name='sendEmail']")
    WebElement popupSendEmailCheckBox;

    @FindBy(xpath = "//button[text()='Confirm']")
    WebElement popupConfirmBtn;


    public String getDeliveryAvailableMessage(){return getText(deliveryAvailableMessage);}

    public String getLearnMoreText(){return getText(learnMoreCTA);}

    public String getInStorePharmacyOnlyHeaderText(){return getText(inStorePharmacyOnlyHeaderText);}

    public String getInStorePharmacyOnlyDescriptionText(){return getText(inStorePharmacyOnlyDescriptionMessage);}

    public String getWhyLinkText(){return getText(whyLink);}

    public String getStoreCloseHoursTodayMessageText(){return getText(storeCloseHoursTodayMessage);}

    public String getRatherGetThemInStoreText(){return getText(ratherGetThemInStoreMessage);}

    public String getStoreAddressText(){return getText(storeAddressMessage);}

    public void clickLearnMoreCTA(){click(learnMoreCTA);}

    public String getPrescriptionReadyMessage(){return getText(prescriptionReadyMessage);}

    public String getPrescriptionReadySubMessage(){return getText(prescriptionReadySubMessage);}

    public String getPaymentAmountDue(){return getText(paymentAmountDue);}

    public void clickSeeDetails(){click(seeDetails);}

    public String getSeeDetailsText(){return getText(seeDetails);}

    /**
     * Finds the bottom-most dashboard row whose patient and drug labels match, reads
     * {@code [patientName, drugName, priceText]} from that row, then taps See details.
     *
     * <p>Android: scopes lookup by resource-id containers.
     * iOS: scopes by {@code RFPFillView.infoContainerView} whose combined label includes
     * both drug name and patient name; taps the matching {@code RFPFillActionView.linkButton}.</p>
     *
     * @return three-element array: patient on row, drug on row, patient-due / price line on row
     */
    public String[] getPatientDrugPriceAndClickSeeDetailsForRow(String patientDisplayName, String drugDisplayName) {
        List<WebElement> cards = null;
        if (remoteDriver instanceof AndroidDriver) {
            String containerXpath = "//*[.//*[@resource-id='com.walmart.android.debug:id/pharmacy_customer_name' and @text='"
                    + patientDisplayName + "'] and .//*[@resource-id='com.walmart.android.debug:id/pharmacy_drugname' and @text='"
                    + drugDisplayName + "']]";
            cards = remoteDriver.findElements(By.xpath(containerXpath));
            if (cards == null || cards.isEmpty()) {
                throw new NoSuchElementException(
                        "No RFP row found for patient='" + patientDisplayName + "', drug='" + drugDisplayName + "'");
            }
            WebElement row = cards.getLast();
            String patient = row.findElement(By.id(ID_CUSTOMER_NAME)).getText();
            String drug = row.findElement(By.id(ID_DRUG_NAME)).getText();
            String price = row.findElement(By.id(ID_PATIENT_DUE)).getText();
            row.findElement(By.id(ID_SEE_DETAILS_BTN)).click();
            return new String[]{patient, drug, price};
        }
        if (remoteDriver instanceof IOSDriver) {
            // RFPFillView.infoContainerView label = "{drug}, for {patient}, {coverage}, {price}"
            String containerXpath = "//XCUIElementTypeOther[@name='RFPFillView.infoContainerView'"
                    + " and contains(@label,'" + drugDisplayName + "')"
                    + " and contains(@label,'" + patientDisplayName + "')]";
            cards = remoteDriver.findElements(By.xpath(containerXpath));
            if (cards == null || cards.isEmpty()) {
                throw new NoSuchElementException(
                        "No RFP row found for patient='" + patientDisplayName + "', drug='" + drugDisplayName + "'");
            }
            WebElement row = cards.getLast();
            String drug = row.findElement(By.xpath(IOS_XPATH_DRUG_LABEL)).getText();
            String patient = row.findElement(By.xpath(IOS_XPATH_PATIENT_LABEL)).getText();
            String price = row.findElement(By.xpath(IOS_XPATH_PRICE_LABEL)).getText();
            // See details button is a sibling of infoContainerView inside RFPFillView
            String seeDetailsBtnXpath = String.format(IOS_XPATH_SEE_DETAILS_BTN_TEMPLATE, drugDisplayName, patientDisplayName);
            remoteDriver.findElement(By.xpath(seeDetailsBtnXpath)).click();
            return new String[]{patient, drug, price};
        }
        throw new NoSuchElementException(
                "No RFP row found for patient='" + patientDisplayName + "', drug='" + drugDisplayName + "'");
    }

    public void clickAddToCart(){

         click(addToCart);}

    public void clickInfoCTA(){click(infoCTA);}

    public int getAddToCartCount(){
        if(isElementDisplayed(addToCart,10)){
            return addToCartBtns.size();
        }else{
            return 0;
        }
    }

    public String getPatientNameOnFillTrackerCard() {return getText(patientName);}

    public boolean isInfoCTAVisible() {
        return isElementDisplayed(infoCTA);
    }

    public boolean isPopupDobScreenDisplayed() {
        return isElementDisplayed(popupDobField,1);
    }

    public void clearConfirmDobPopup(String dob) {
        sendText(popupDobField, dob);
        click(popupSendEmailCheckBox);
        click(popupConfirmBtn);
    }

    public boolean isPetIconVisible() {
        return isElementDisplayed(petIcon);
    }

    public boolean isHumanIconVisible() {
        return isElementDisplayed(humanIcon);
    }

    public boolean isDrugImageVisible() {
        return isElementDisplayed(drugImage);
    }

    public void clickWhyLink(){click(whyLink);}

    public String getInEligiblePopupHeaderText(){return getText(inEligiblePopupHeaderMessage);}

    public String getInEligiblePopupSubHeaderText(){return getText(inEligiblePopupSubHeaderMessage);}

    public String getInEligiblePopupInfoText(){return getText(inEligiblePopupInfoMessage);}

    public void clickInEligiblePopupCloseBtn(){click(inEligiblePopupCloseBtn);}
    public void clickInEligiblePopupCloseIcon(){click(inEligiblePopupCloseIcon);}

    public boolean isFillStatusCardSubHeaderTextVisible(){
        return isElementDisplayed(fillStatusCardSubHeaderText);
    }

    public boolean isPetPatientIconVisible(){
        return isElementDisplayed(petPatientIcon);
    }

    public boolean isHumanPatientIconVisible(){
        return isElementDisplayed(humanPatientIcon);
    }
    public String getFillStatusCardSubHeaderText(){
        return getText(fillStatusCardSubHeaderText);
    }

    public void clickFillDetailsArrowCTA(){
        click(fillDetailsArrowCTA);
    }

    public String getRxName(){
        return getText(rxName, "rxName", 10);
    }

    public String getRxNameOnFillTrackerCard() {return getText(rxName, "rxName", 10);}

    public String getRxEstimatedPrice(){
        return getText(rxEstimatedPrice, "rxEstimatedPrice", 10);
    }

    public String getFillStatusCardHeaderText(){
        return getText(fillStatusCardHeaderText, "fillStatusCardHeaderText", 10);
    }

    public void clickSearch(){
        click(clickSearch);
    }

    public void clickGlobalSearch(){
        click(clickGlobalSearch);
    }

    public void enterGroceryItems(String item){
        sendTextAndPressEnter(searchBar, item);
    }

    public void clickSearchIcon( ){
        click(clickIcon);
    }
    public void clickAddCartButtonForNonRxItem( ){
        click(clickAddCartButton, 8);
    }

    public void clickGotItButton(){
        if (isElementDisplayed(clickGotItButton, 8)) {
            click(clickGotItButton);
        }
    }

    public void clickOnDecreaseQuantityBtn(){click(decreaseQuantityBtn,"Quantity Decrement Icon");}

    public int getCartCount() {
        String value = getAttribute(cartBadge, Attribute.innerText);
        if (value == null) {
            return 0;
        } else {
            return Integer.parseInt(value);
        }
    }

    public int getCartCount(int WaitTime){
        String value = getAttribute(cartBadge, Attribute.innerText, WaitTime);
        if (value == null){
            return 0;
        } else {
            return Integer.parseInt(value);
        }
    }

    public void clickOnTheDeliveryAddressButton() { click(clickOnTheDeliveryAddressButton); }
    public void clickOnPickupIcon() {
        boolean elementUpdateZipCode = isElementDisplayed(clickUpdateZipCode, 2);
        boolean elementSaveButton = isElementDisplayed(clickSaveButton, 2);
        boolean elementPickupIcon = isElementDisplayed(clickOnPickupIcon, 2);
        if (elementPickupIcon)
            click(clickOnPickupIcon);
        if(elementUpdateZipCode)
            click(clickUpdateZipCode);
        if(elementSaveButton)
            click(clickSaveButton);
        }

    public boolean isMax1TextVisible() {
        return isElementDisplayed(max1Txt,"Max 1 Text");
    }

    public boolean isAddToCartButtonVisible() {
        return isElementDisplayed(addToCart, 10);
    }

    /**
     * Returns true if the "Pending delivery approval" label is visible on the ATC card.
     * This state appears after a caregiver sends a delivery-enable request to a dependent.
     */
    public boolean isPendingDeliveryApprovalOnATCCardVisible() {
        return isElementDisplayed(pendingDeliveryApprovalOnATCCard, 10);
    }

    public void clickRadiobutton() { click(clickRadiobutton); }
    public void scrollToTop() { scrollToElement(clickOnPickup); }
    public void clickOnPickup() { click(clickOnPickup); }
    public void clickReserveButton() { click(clickReserveButton); }
    public String errorMessageCurbside() { return getText(errorMessageCurbside);}
    public void clickPickupInstead() {
        boolean elementPresent = isElementDisplayed(clickPickupInstead,1);
        if(elementPresent)
        {
            click(clickPickupInstead);
        }
    }

    public void clickOnViewAllTimesOption() {
        boolean elementPresent = isElementDisplayed(clickOnViewAllTimesOption, 1);
        boolean elementSeeTimes = isElementDisplayed(clickSeeTimes, 1);
        if (elementPresent) {
            click(clickOnViewAllTimesOption);
        }
        else if(elementSeeTimes)
        {
            click(clickSeeTimes);
        }
        else{
            System.out.println("technical error change the store or add slots");
        }
    }

    public boolean isIncreaseRxQuantityButtonDisabled() { return isElementDisplayed(increaseQuantity); }

    public void clickDecreaseRxQuantityButton() { click(decreaseQuantity); }

    public void clickOnAddCartButton() {click(clickOnAddCartButton);}

    /** Returns store address text from every RFP card in DOM order. */
    public List<String> getAllStoreNames() {
        return allStoreAddressLabels.stream().map(this::getText).collect(Collectors.toList());
    }

    /** Returns the number of RFP cards currently rendered on the dashboard. */
    public int getRfpCardCount() {
        return allRfpCards.size();
    }

    /** Returns the card header text ("Your prescription is ready" / "Your prescriptions are ready") for a specific card. */
    public String getCardHeaderText(WebElement card) {
        return card.findElements(By.id("com.walmart.android.debug:id/pharmacy_prescription_ready_header"))
                .stream().findFirst().map(WebElement::getText).orElse("");
    }

    /** Returns patient names inside a specific card, preserving DOM order. */
    public List<String> getPatientNamesInCard(WebElement card) {
        return card.findElements(By.id("com.walmart.android.debug:id/pharmacy_customer_name"))
                .stream().map(WebElement::getText).collect(Collectors.toList());
    }

    /** Returns drug names inside a specific card, preserving DOM order. */
    public List<String> getDrugNamesInCard(WebElement card) {
        return card.findElements(By.id("com.walmart.android.debug:id/pharmacy_drugname"))
                .stream().map(WebElement::getText).collect(Collectors.toList());
    }

    /**
     * Returns the store address text inside a specific card (e.g. "Ready at the Bentonville, Ar Supercenter #5517").
     * Tries getText() on the address group first; if that returns empty (common for ViewGroups on Android),
     * falls back to concatenating text from all text-bearing children of the group.
     */
    public String getStoreAddressInCard(WebElement card) {
        List<WebElement> groups = card.findElements(By.id("com.walmart.android.debug:id/pharmacy_store_address_group"));
        if (groups.isEmpty()) return "";
        String text = groups.getFirst().getText();
        if (!text.isEmpty()) return text;
        // ViewGroup returned empty — concatenate text from all child nodes that have non-empty text
        return groups.getFirst().findElements(By.xpath(".//*[@text]"))
                .stream()
                .map(WebElement::getText)
                .filter(t -> !t.isEmpty())
                .collect(Collectors.joining(" "));
    }

    public void clickClosButton() {
        boolean elementAcknowledgeButton = isElementDisplayed(clickAcknowledgeButton, 1);
        boolean elementClosButton = isElementDisplayed(clickClosButton, 1);
        if (elementAcknowledgeButton) {
            click(clickAcknowledgeButton);
        }
        if (elementClosButton) {
            click(clickClosButton);
        } else {
            System.out.println("Did ask Acknowledge this time");
        }
    }

    public boolean isAddToCartEnabled() {
        return isElementDisplayed(addToCart,5);
    }

    // ---- Card footer: "Rather get them in-store?" section ----

    /** Returns {@code true} if the "Rather get them in-store?" heading is visible on the card. */
    public boolean isRatherGetThemInStoreVisible() {
        return isElementDisplayed(ratherGetThemInStoreMessage, 5);
    }

    /**
     * Returns {@code true} if the "Ready at the [storeName]" label is currently within the
     * visible viewport. PageFactory resolves {@code readyAtStoreLabel} to the correct
     * platform locator — no branching required here.
     *
     * @return the visible text of the "Ready at the…" element, or {@code null} if not found
     */
    public String getReadyAtStoreText() {
        return getText(readyAtStoreLabel);
    }

    /** Returns {@code true} if the "Open until..." store hours label is visible on the card. */
    public boolean isStoreOpenTimeVisible() {
        return isElementDisplayed(storeTiming, 5);
    }

    /** Returns the store open-time label text (e.g. {@code "Open until 11:30pm today"}). */
    public String getStoreOpenTimeText() {
        return getText(storeTiming);
    }

    // ---- Store Information bottom sheet methods ----

    /** Returns {@code true} if the "Store Information" bottom sheet title is visible. */
    public boolean isStoreInfoSheetTitleVisible() {
        return isElementDisplayed(storeInfoSheetTitle, 5);
    }

    /** Returns the title text from the Store Information bottom sheet (e.g. {@code "Store Information"}). */
    public String getStoreInfoSheetTitleText() {
        return getText(storeInfoSheetTitle);
    }

    /** Returns {@code true} if the store display name label is visible in the bottom sheet. */
    public boolean isStoreInfoDisplayNameVisible() {
        return isElementDisplayed(storeInfoDisplayName, 5);
    }

    /** Returns the store name text from the Store Information bottom sheet. */
    public String getStoreInfoDisplayName() {
        return getText(storeInfoDisplayName);
    }

    /** Returns {@code true} if the store address label is visible in the Store Information sheet. */
    public boolean isStoreInfoAddressVisible() {
        return isElementDisplayed(storeInfoAddress, 5);
    }

    /** Returns the store address text from the Store Information bottom sheet. */
    public String getStoreInfoAddress() {
        return getText(storeInfoAddress);
    }

    /** Returns {@code true} if the store phone number is visible in the Store Information sheet. */
    public boolean isStoreInfoPhoneVisible() {
        return isElementDisplayed(storeInfoPhoneNumber, 5);
    }

    /** Returns the store phone number text from the Store Information sheet (e.g. {@code "479-636-8238"}). */
    public String getStoreInfoPhoneText() {
        return getText(storeInfoPhoneNumber);
    }

    /**
     * Returns the combined pharmacy hours text from the Store Information sheet.
     * Android: concatenates the day-range label and time-range label (two separate elements).
     * iOS: returns the combined element text directly (day and time are merged into one element).
     */
    public String getStoreInfoHoursText() {
        if (remoteDriver instanceof IOSDriver) {
            return getText(storeInfoHoursDay);
        }
        return getText(storeInfoHoursDay) + " " + getText(storeInfoHoursTime);
    }

    /** Closes the Store Information bottom sheet by tapping the close button. */
    public void closeStoreInfoSheet() {
        click(storeInfoCloseButton);
    }

    public void addNItemsToCart(int numberOfRxsToAddToCart) throws Exception {
        List<WebElement> addToCartButtons = new ArrayList<>();
        if (remoteDriver instanceof IOSDriver) {
            addToCartButtons = remoteDriver.findElements(By.name("stepper.addToCartButton"));
        } else if (remoteDriver instanceof AndroidDriver) {
            addToCartButtons = remoteDriver.findElements(By.id("com.walmart.android.debug:id/textview_add_cart_cta"));
        } else {
            addToCartButtons = getDynamicWebElementsByTagAndAttribute
                    (remoteDriver instanceof WebDriver ? "span" : "*", "text", "Add to cart");
        }
        if (addToCartButtons.size() >= numberOfRxsToAddToCart) {
            for (int i = 0; i < numberOfRxsToAddToCart; i++) {
                // Added Because it takes time for cart addition to reflect,
                // if another addition is done in that time we get Unable to ATC Error
                clickInterceptibleElement(addToCartButtons.get(i), 1000);
                waitForLoadingToDisappear(10);
            }
        } else {
            Reporter.log("The Number of ATC Buttons on Screen is different than Expected, Expected: " + numberOfRxsToAddToCart +
                    "Actual: " + addToCartButtons.size() + ". Please check test data or Report Mismatch in Fill Summaries API");
            throw new IllegalAccessException();
        }
    }
}
