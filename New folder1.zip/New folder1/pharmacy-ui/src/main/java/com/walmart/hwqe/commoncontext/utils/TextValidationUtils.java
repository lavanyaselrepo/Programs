package com.walmart.hwqe.commoncontext.utils;

import com.aventstack.extentreports.Status;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.json.JSONObject;

import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

public class TextValidationUtils {

    String translations;

    public TextValidationUtils(String platform) {
        switch (platform) {
            case "ANDROID" -> this.translations = this.parseJsonFile("src/test/resources/translations/translationsAndroid.json").toString();
            case "IOS" -> this.translations = this.parseJsonFile("src/test/resources/translations/translationsIOS.json").toString();
            case "WEB" -> this.translations = this.parseJsonFile("src/test/resources/translations/translationsWeb.json").toString();
        }

    }

    public TextValidationUtils() {
    }

    public JsonObject parseJsonFile(String fileName) {
        Object obj = null;

        try {
            JsonParser parser = new JsonParser();
            obj = parser.parse(new FileReader(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return (JsonObject)obj;
    }

    public String readJsonFile(String fileName) {
        return parseJsonFile(fileName).toString();
    }

    public Object getKeyInObject(Map<?, ?> objectToParse, String key) {
        return objectToParse.get(key);
    }

    public Object getKeyInObject(String screenName, String key) {
        JsonParser jsonParser = new JsonParser();
        Object value = jsonParser.parse(this.translations).getAsJsonObject().get(screenName).getAsJsonObject().get(key).getAsString();
        return value;
    }

    public Object getKeyInObject(String screenName, String subScreenName, String key) {
        JsonParser jsonParser = new JsonParser();
        Object value = jsonParser.parse(this.translations).getAsJsonObject().get(screenName).getAsJsonObject().getAsJsonObject(subScreenName).get(key).getAsString();
        return value;
    }

    public String nullStringValidation(String inputData) {
        String val = inputData;
        if (inputData.equals("null")) {
            val = null;
        } else if (inputData.equals("invalid")) {
            val = "invalid";
        }

        return val;
    }

    public JSONObject getJsonTestData(String jsonPath, String testName) {
        JSONObject jsonObject = new JSONObject(this.readJsonFile(jsonPath));
        Reporter.log("Test Name :: " + testName);
        JSONObject testInputDetails = null;
        if (jsonObject.keySet().contains(testName)) {
            testInputDetails = jsonObject.getJSONObject(testName);
        } else {
            Reporter.log(Status.FAIL, testName + " is not found in json path : " + jsonPath);
        }

        return testInputDetails;
    }
}
