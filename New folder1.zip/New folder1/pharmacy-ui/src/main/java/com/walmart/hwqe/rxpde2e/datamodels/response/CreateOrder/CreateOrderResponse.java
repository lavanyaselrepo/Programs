package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;
@lombok.Getter
@lombok.Setter
public class CreateOrderResponse {
    public String astroStatus;
    public String astroDescription;
    public AstroDetails astroDetails;
    public Object astroInfo;
}
