package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class Name {
    public String firstName;
    public String lastName;
    public String middleName;
}
