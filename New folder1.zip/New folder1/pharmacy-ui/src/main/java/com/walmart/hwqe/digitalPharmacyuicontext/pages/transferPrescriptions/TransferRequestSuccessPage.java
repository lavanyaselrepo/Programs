package com.walmart.hwqe.digitalPharmacyuicontext.pages.transferPrescriptions;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class TransferRequestSuccessPage extends MobileBasePage {

    @FindBy(id = "page-heading")
    @iOSXCUITFindBy(accessibility = "TransferRxConfirmationHeaderView.yourTransferHasBeenPlacedLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_title")
    private WebElement transferRequestSuccessHeading;

    @FindBy(xpath = "//h2[@id=\"page-heading\"]/following::h3[1]")
    @iOSXCUITFindBy(accessibility = "TransferRxConfirmationHeaderView.ourPharmacistReviewTitleLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/confirmation_subtitle")
    private WebElement pharmacistWillContactSubheading;

    @FindBy(xpath = "//button[contains(text(),\"Back to pharmacy\")]")
    @iOSXCUITFindBy(accessibility = "TransferRxConfirmationViewController.primaryButton")
    @AndroidFindBy(xpath = "//android.widget.Button[@text='Back to pharmacy']")
    private WebElement backToPharmacyButton;

    @iOSXCUITFindBy(accessibility = "TransferRxConfirmationViewController.Close")
    private WebElement screenCloseButton;

    public TransferRequestSuccessPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickBackToPharmacyButton() {
        scrollElementForWebAndMobile(backToPharmacyButton,"Back to pharmacy", "up");
        click(backToPharmacyButton);
    }
    public String getTransferRequestSuccessHeading(){return getText(transferRequestSuccessHeading);}
    public String getPharmacistWillContactSubheading(){return getText(pharmacistWillContactSubheading);}

    public void closeCurrentViewAndNavigateToPharmacy(){ click(screenCloseButton); }
}
