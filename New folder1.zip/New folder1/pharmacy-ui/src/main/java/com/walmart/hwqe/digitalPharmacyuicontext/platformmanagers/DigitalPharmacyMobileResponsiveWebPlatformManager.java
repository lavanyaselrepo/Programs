/**
 * DigitalPharmacyMobileResponsiveWebPlatformManager is the implementation of ICommonDriver for the platform type "MOBILE_RESPONSIVE_WEB".
 *
 * @Author: Ashok Gurijala
 *
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;



import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.webcontext.interfaces.ICommonDriver;
import com.walmart.hwqe.webcontext.WebSiteManager;
import org.openqa.selenium.remote.RemoteWebDriver;

public class DigitalPharmacyMobileResponsiveWebPlatformManager extends WebSiteManager implements ICommonDriver {

    PropertyReader rdr = PropertyReaderHelper.getInstance();

    @Override
    public RemoteWebDriver getDriver() {
        return super.getDriver();
    }

    public void getSessionInformation(){
        Reporter.log(getDriver().getCapabilities().toString());
    }

    @Override
    public RemoteWebDriver launchPlatformApp(String testName) {
        return launchMobileResponsiveWebsiteOrderToRx("https://www-teflon.walmart.com/");
    }

    @Override
    public void quitDriver() {
        try {
            if (getDriver() != null) {
                getDriver().close();
            }
        } finally {
            quitWebsite();
        }
    }
}
