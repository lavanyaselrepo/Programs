package com.walmart.hwqe.digitalPharmacyuicontext.dataModels.response;

import lombok.*;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PatientInfo {
    private String emailId;
    private String patientId;
    private String storeNbr;
    private String rxNbr;
}
