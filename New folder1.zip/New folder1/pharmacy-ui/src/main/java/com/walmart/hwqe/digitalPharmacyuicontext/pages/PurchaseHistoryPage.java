package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class PurchaseHistoryPage extends MobileBasePage {

    @FindBy(xpath = "//*[text()='Not eligible for substitution']")
    public WebElement notEligibleForSubstitutionText;

    @FindBy(xpath = "//*[text()='Substitutions cannot be provided for certain items, like alcohol and medication']")
    public WebElement notEligibleForSubstitutionDescriptionText;

    @FindBy(xpath = "//*[text()='Confirm cancellation']")
    public WebElement confirmCancelBtn;

    @FindBy(xpath = "//*[text()='Cancellation requested today']")
    public WebElement cancellationRequestedTodayText;

    @FindBy(xpath = "//*[text()='Reorder all']")
    public WebElement reorderAllBtn;

    @FindBy(xpath = "//*[contains(@aria-label,'Remove ')]")
    public List<WebElement> removeButtons;

    @FindBy(xpath = "//*[contains(@aria-label,'Edit items for order id ')]")
    public List<WebElement> editItemsButtons;

    @FindBy(xpath = "//*[contains(@data-testid,'radio')]")
    public List<WebElement> cancelReasonRadioButtons;

    public PurchaseHistoryPage(RemoteWebDriver driver) {
        super(driver);
    }

    public boolean isNotEligibleForSubstitutionDescriptionTextDisplayed() {
        return isElementDisplayed(notEligibleForSubstitutionDescriptionText);
    }

    public boolean isCancellationRequestedTodayTextDisplayed() {
        return isElementDisplayed(cancellationRequestedTodayText);
    }

    public boolean isNotEligibleForSubstitutionTextDisplayed() {
        return isElementDisplayed(notEligibleForSubstitutionText);
    }

    public boolean isReorderAllBtnDisplayed() {
        return isElementDisplayed(reorderAllBtn);
    }

    public void clickOnFirstEditItemsButton() {
        click(editItemsButtons.get(0),"Edit Items Button");
    }

    public void clickOnConfirmCancelBtn() {
        click(confirmCancelBtn,"Confirm cancellation button");
    }

    public void clickOnCancelReasonRadioBtn() {
        click(cancelReasonRadioButtons.get(2),"Cancel reason radio button");
    }

}
