package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.time.Duration;
import java.util.List;
import java.util.Map;

/**
 * Page object for the debug panel (accessible via swipe gesture in debug builds).
 * Encapsulates all interactions needed to configure debug toggles before running tests.
 */
public class DebugMenuPage extends MobileBasePage {

    private final AutomationManager am = AutomationManager.getInstance();

    /**
     * Landmark element that confirms the debug panel is open.
     * Android: the "Analytics" text node. iOS: the "Done" button in the panel nav bar — also
     * used to close the panel at the end of each configure method.
     */
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Analytics\")")
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Done' AND type == 'XCUIElementTypeButton'")
    public WebElement debugPanelAnchor;

    @AndroidFindBy(xpath = "//*[@text='Skip Step up']/../android.widget.Switch | //*[@text='Skip Step up']/../following-sibling::*/android.widget.Switch")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSwitch[contains(@label,'Skip Stepup at Sign In')] | //XCUIElementTypeSwitch[contains(@name,'Skip Stepup at Sign In')]")
    public WebElement skipStepUpToggle;

    @AndroidFindBy(xpath = "//*[@text='Onboarding completed']/../android.widget.Switch | //*[@text='Onboarding completed']/../following-sibling::*/android.widget.Switch")
    public WebElement onboardingCompletedToggle;

    public DebugMenuPage(RemoteWebDriver driver) {
        super(driver);
    }

    /**
     * Opens the debug panel by performing a slow right-to-left drag with a long-press hold.
     * W3C PointerInput works reliably on Android for this gesture.
     */
    public void openDebugPanelAndroid() {
        int screenWidth  = remoteDriver.manage().window().getSize().getWidth();
        int screenHeight = remoteDriver.manage().window().getSize().getHeight();
        int startX = screenWidth - 50;
        double[] yRatios = {0.22, 0.35, 0.50};

        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        for (int attempt = 1; attempt <= yRatios.length; attempt++) {
            int midY = (int)(screenHeight * yRatios[attempt - 1]);
            am.performSleep(1);

            Sequence swipe = new Sequence(finger, 0);
            swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, midY));
            swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
            swipe.addAction(new Pause(finger, Duration.ofMillis(800)));
            swipe.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), 50, midY));
            swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
            remoteDriver.perform(List.of(swipe));
            am.performSleep(2);

            if (isElementDisplayed(debugPanelAnchor)) {
                Reporter.log("Debug panel opened on attempt " + attempt);
                return;
            }
            Reporter.log("Debug panel not detected on attempt " + attempt + ", retrying...");
        }
        throw new RuntimeException("Debug panel failed to open after 3 attempts");
    }

    public void enableDebugToggle(String label) {
        WebElement toggle = switch (label) {
            case "Skip Step up", "Skip Stepup at Sign In" -> skipStepUpToggle;
            case "Onboarding completed" -> onboardingCompletedToggle;
            default -> null;
        };
        if (toggle == null) {
            Reporter.log("No toggle element defined for label: " + label);
            return;
        }
        toggle.click();
        am.performSleep(1);
    }

    /**
     * Opens the debug panel using {@code mobile: dragFromToForDuration}.
     * W3C PointerInput is silently ignored by XCUITest for edge-triggered gestures; the Appium
     * mobile script maps directly to XCUITest's {@code dragCoordinate} API.
     */
    public void openDebugPanelIOS() {
        int screenWidth  = remoteDriver.manage().window().getSize().getWidth();
        int screenHeight = remoteDriver.manage().window().getSize().getHeight();
        int startX = screenWidth - 1;
        int endX   = (int)(screenWidth * 0.2);
        double[] yRatios = {0.35, 0.50, 0.65};

        for (int attempt = 1; attempt <= yRatios.length; attempt++) {
            int midY = (int)(screenHeight * yRatios[attempt - 1]);
            am.performSleep(1);

            remoteDriver.executeScript("mobile: dragFromToForDuration", Map.of(
                    "fromX", startX, "fromY", midY,
                    "toX",   endX,   "toY",   midY,
                    "duration", 0.5
            ));
            am.performSleep(2);

            if (isElementDisplayed(debugPanelAnchor)) {
                Reporter.log("Debug panel opened on attempt " + attempt);
                return;
            }
            Reporter.log("Debug panel not detected on attempt " + attempt + ", retrying...");
        }
        throw new RuntimeException("Debug panel failed to open after 3 attempts");
    }
}
