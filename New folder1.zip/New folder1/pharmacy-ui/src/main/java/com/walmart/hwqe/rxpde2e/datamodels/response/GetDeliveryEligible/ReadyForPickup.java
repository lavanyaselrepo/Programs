package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

@lombok.Getter
@lombok.Setter
public class ReadyForPickup {
    public String pRefId;
    public int storeId;
    public int patientId;
    public Drug drug;
    public String imageUrl;
    public int fillId;
    public int rxNbr;
    public Price price;
    public AddToCartEligibility addToCartEligibility;
    public String coverageApplied;
}
