package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class PharmacyOperatingHour {
    public String day;
    public String startTime;
    public String endTime;
}
