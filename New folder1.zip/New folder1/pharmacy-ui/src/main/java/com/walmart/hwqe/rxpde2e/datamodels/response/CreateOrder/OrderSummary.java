package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;
@lombok.Getter
@lombok.Setter
public class OrderSummary {
    public String customerId;
    public String cartId;
    public OrderInfo orderInfo;
    public BuyerInfo buyerInfo;
}
