package com.walmart.hwqe.digitalPharmacyuicontext.utils.googlevoice;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Central configuration for Google Voice SMS and Gmail automation.
 *
 * Credentials are read from environment variables — never hardcoded.
 * Set these in your CI/CD pipeline secrets or local shell profile:
 *
 *   export GOOGLE_VOICE_EMAIL=normandmark268@gmail.com
 *   export GOOGLE_VOICE_PASSWORD=<your-password>
 *
 * One-time setup:
 *   1. Create a Google Cloud project and enable the Gmail API
 *   2. Download credentials.json and place it at:
 *        pharmacy-ui/src/test/resources/google_voice/credentials.json
 *   3. Run SaveGoogleVoiceSession to generate token.json (handles OAuth consent)
 *   4. For SMS send (Playwright): set GOOGLE_VOICE_EMAIL + GOOGLE_VOICE_PASSWORD env vars
 *
 * See: pharmacy-ui/src/test/resources/google_voice/README_GOOGLE_VOICE.md
 */
public class GoogleVoiceConfig {

    private static final String PROPERTIES_FILE =
            "pharmacy-ui/src/test/resources/google_voice/google_voice.properties";

    private static final String CLASSPATH_PROPERTIES = "google_voice/google_voice.properties";

    private static final Properties PROPS = loadProperties();

    private GoogleVoiceConfig() {}

    /**
     * Reads a value from env var first, falls back to google_voice.properties file.
     * Priority: env var > properties file
     * This means CI/CD uses env vars, local dev uses the properties file — no manual export needed.
     */
    private static String get(String key) {
        String envVal = System.getenv(key);
        if (envVal != null && !envVal.isBlank()) return envVal;
        return PROPS.getProperty(key, "");
    }

    private static Properties loadProperties() {
        Properties props = new Properties();
        // Try filesystem path first (works when CWD is repo root)
        try (InputStream in = new FileInputStream(PROPERTIES_FILE)) {
            props.load(in);
            return props;
        } catch (IOException ignored) { }

        // Fall back to classpath (works when CWD is module root, e.g. IntelliJ default)
        try (InputStream in = GoogleVoiceConfig.class.getClassLoader()
                .getResourceAsStream(CLASSPATH_PROPERTIES)) {
            if (in != null) {
                props.load(in);
                return props;
            }
        } catch (IOException ignored) { }

        return props;
    }

    // ── Credentials — env var takes priority, properties file is fallback ──
    public static String getEmail()       { return get("GOOGLE_VOICE_EMAIL"); }
    public static String getPassword()    { return get("GOOGLE_VOICE_PASSWORD"); }
    public static String getPhoneNumber() { return get("GOOGLE_VOICE_NUMBER"); }

    // Keep static fields for backward compatibility
    public static final String EMAIL       = get("GOOGLE_VOICE_EMAIL");
    public static final String PASSWORD    = get("GOOGLE_VOICE_PASSWORD");
    public static final String PHONE_NUMBER = get("GOOGLE_VOICE_NUMBER");

    // ── File paths — scoped per account so multiple accounts can coexist ──
    // Each account gets its own credentials, tokens and session files under
    // google_voice/<account-prefix>/  e.g. google_voice/normandmark268/
    private static final String BASE_RESOURCE_PATH =
            "pharmacy-ui/src/test/resources/google_voice";

    // Alternative base when CWD is the module directory (e.g. IntelliJ default)
    private static final String MODULE_RESOURCE_PATH =
            "src/test/resources/google_voice";

    private static String accountPrefix() {
        if (EMAIL == null || EMAIL.isBlank()) return "default";
        return toAccountPrefix(EMAIL);
    }

    /**
     * Converts an email address to its account directory prefix.
     * e.g. "normandmark268@gmail.com" → "normandmark268"
     */
    public static String toAccountPrefix(String email) {
        if (email == null || email.isBlank()) return "default";
        return email.replaceAll("@.*", "").replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    private static String resolveResourceBase() {
        java.io.File repoLevel = new java.io.File(BASE_RESOURCE_PATH);
        if (repoLevel.isDirectory()) return BASE_RESOURCE_PATH;
        java.io.File moduleLevel = new java.io.File(MODULE_RESOURCE_PATH);
        if (moduleLevel.isDirectory()) return MODULE_RESOURCE_PATH;
        return BASE_RESOURCE_PATH;
    }

    // ── Default account path resolution (uses GOOGLE_VOICE_EMAIL) ──

    public static String getCredentialsFilePath() {
        return resolveResourceBase() + "/" + accountPrefix() + "/credentials.json";
    }

    public static String getTokensDirPath() {
        return resolveResourceBase() + "/" + accountPrefix() + "/tokens";
    }

    public static String getSessionFilePath() {
        return resolveResourceBase() + "/" + accountPrefix() + "/session.json";
    }

    // ── Per-account path resolution (for multi-account support) ──

    public static String getCredentialsFilePath(String email) {
        return resolveResourceBase() + "/" + toAccountPrefix(email) + "/credentials.json";
    }

    public static String getTokensDirPath(String email) {
        return resolveResourceBase() + "/" + toAccountPrefix(email) + "/tokens";
    }

    // Keep constants as aliases for backward compatibility
    public static final String CREDENTIALS_FILE_PATH =
            BASE_RESOURCE_PATH + "/credentials.json";
    public static final String TOKENS_DIR_PATH =
            BASE_RESOURCE_PATH + "/tokens";
    public static final String SESSION_FILE_PATH =
            BASE_RESOURCE_PATH + "/session.json";

    // ── Gmail API scopes ───────────────────────────────────────────────────
    /** Gmail scopes — readonly for reading SMS, send for replying via Google Voice email relay */
    public static final List<String> GMAIL_SCOPES = Arrays.asList(
            "https://www.googleapis.com/auth/gmail.readonly",
            "https://www.googleapis.com/auth/gmail.send"
    );

    // ── Application name ───────────────────────────────────────────────────
    public static final String APP_NAME = "PharmacyTestAutomation";

    // ── Google Voice URL ───────────────────────────────────────────────────
    public static final String VOICE_URL = "https://voice.google.com";

    // ── Default timeouts ───────────────────────────────────────────────────
    /** Max time to wait for an SMS or email to arrive (ms) */
    public static final long DEFAULT_TIMEOUT_MS = 60_000;

    /** How often to poll Gmail for new messages (ms) */
    public static final long DEFAULT_POLL_INTERVAL_MS = 3_000;

    /** Playwright navigation / action timeout (ms) */
    public static final double PLAYWRIGHT_TIMEOUT_MS = 15_000;

    /** Max results returned by Gmail API per search */
    public static final long GMAIL_MAX_RESULTS = 10L;
}
