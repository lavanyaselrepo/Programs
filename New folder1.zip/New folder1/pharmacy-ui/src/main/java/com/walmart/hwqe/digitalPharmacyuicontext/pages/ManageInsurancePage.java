package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

// iOS locators verified via execution on iPhone 16 Pro (Mar 27, 2026) - testAddInsuranceAndCheckPrimaryTag
// TODO: memberIdText, binText, pcnText have no @iOSXCUITFindBy - add when validateAddedInsuranceDetails is implemented for iOS
public class ManageInsurancePage extends MobileBasePage {

    @FindBy(xpath = "//h2[text()='Manage my prescription insurance']")
    public WebElement manageInsurancePageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name, 'Primary')]")
    public WebElement primaryInsuranceTagIOS;

    @FindBy(xpath = "//button[contains(text(),'Add prescription insurance')]")
    public WebElement addInsuranceCTA;

    @AndroidFindBy(id = "com.walmart.android.debug:id/enter_insurance_manually")
    @iOSXCUITFindBy(accessibility = "Enter details manually")
    @FindBy(xpath = "//button[contains(text(),'Enter details manually')]")
    public WebElement enterDetailsManuallyCTA;

    @AndroidFindBy(id="com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "AddInsuranceManualEntryController.primaryButton")
    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    public WebElement continueButton;

    @iOSXCUITFindBy(accessibility = "Remove insurance")
    @FindBy(xpath = "//button[contains(text(),'Remove insurance')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/remove_insurance")
    public WebElement removeInsuranceCTA;

    @AndroidFindBy(id="com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(accessibility = "Back to manage my insurance")
    @FindBy(xpath = "//button[contains(text(),'Back to manage my insurance')]")
    public WebElement backToManageMyInsurancePageCTA;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Remove insurance'])[2]")
    @FindBy(xpath = "(//button[contains(text(),'Remove insurance')])[2]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_btn")
    public WebElement confirmButton;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Member ID or ID#*')]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label,'Member ID')]")
    @FindBy(xpath = "(//input[contains(@id,'react-aria')])[1]")
    public WebElement insuranceMemberId;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'RxBIN* (6–8 digits)')]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='R X Bin* 6 to 8 digits, 6 digit number, include all zeros']")
    @FindBy(xpath = "(//input[contains(@id,'react-aria')])[2]")
    public WebElement rxBin;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'RxPCN')]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='RxPCN']")
    @FindBy(xpath = "(//input[contains(@id,'react-aria')])[3]")
    public WebElement rxPCN;
    @AndroidFindBy(id="com.walmart.android.debug:id/title")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Insurance has been added']")
    @FindBy(xpath = "//*[contains(text(),'Insurance has been added')]")
    public WebElement insuranceAddedSuccessMessage;


    @AndroidFindBy(id="com.walmart.android.debug:id/insurance_info_icon")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name,'See prescription insurance details for Member ID')]")
    @FindBy(xpath = "//button/i[@class='ld ld-ChevronDown']")
    public WebElement expandInsuranceCTA;


    @AndroidFindBy(id="com.walmart.android.debug:id/member_id")
    @FindBy(xpath = "//span[@class='b dark-gray f5']")
    public WebElement memberIdText;


    @AndroidFindBy(id="com.walmart.android.debug:id/rxbin")
    @FindBy(xpath = "(//div[@class='f6']/div)[2]")
    public WebElement binText;

    @AndroidFindBy(id="com.walmart.android.debug:id/rxpcn")
    @FindBy(xpath = "(//div[@class='f6']/div)[3]")
    public WebElement pcnText;

    @AndroidFindBy(id="com.walmart.android.debug:id/rxpcn")
    @FindBy(xpath = "//div[contains(@aria-label,'RxPCN')]/span")
    public WebElement blankPCNText  ;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/ld_tag_message' and @text='Primary']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Primary']")
    @FindBy(xpath = "//*[contains(@class,'primary-tag') or text()='Primary']")
    public WebElement primaryInsuranceTag;

    @AndroidFindBy(xpath="(//android.widget.RadioButton[@resource-id='com.walmart.android.debug:id/radio_btn'])[1]")
    @iOSXCUITFindBy(accessibility = "PharmacyRadioButtonWithCustomView.radioButton")
    @FindBy(xpath = "(//input[contains(@class,'w_Vy48')])[1]")
    public WebElement bomInsuranceRadioButton;

    @iOSXCUITFindBy(accessibility = "Back")
    public WebElement backButton;
    @AndroidFindBy(id="com.walmart.android.debug:id/confirm_button")
    @iOSXCUITFindBy(accessibility = "Add and continue")
    @FindBy(xpath = "//button[contains(text(),'Add and continue')]")
    public WebElement addAndContinueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/add_insurance")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add insurance']")
    @FindBy(xpath = "//button[contains(text(),'Add insurance')]")
    public WebElement manageInsuranceHub;

    @FindBy(xpath = "//button[contains(@id,'change-insurance')]")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@content-desc,'Change prescription Coverage')]")
    public WebElement buttonChange;

    @FindBy(xpath = "//*[contains(@id,'react-aria')]/following::div[5]")
    @AndroidFindBy(id ="com.walmart.android.debug:id/rxpcn")
     public WebElement rxPCNText;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Prescription insurance']")
    @FindBy(xpath = "//*[text()='Prescription insurance']")
    WebElement radioButtonPrescriptionInsurance;

    @FindBy(xpath = "//button[text()='Add new insurance']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/add_new_insurance_button")
    WebElement buttonAddNewInsurance;

    @FindBy(xpath = "//button[text()='Enter details manually']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    WebElement buttonEnterDetailsManually;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    WebElement buttonConfirmAndContinue;

    @FindBy(xpath = "//button[text()='Save']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/save_insurance_button")
    WebElement buttonSave;

    @FindBy(xpath = "//span[text()='Price pending']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/prescription_price_pending")
    WebElement textPricePending;

    @FindBy(xpath = "//h2[contains(text(),\"We weren't able to confirm your insurance benefits\")]")
    public WebElement unableToFindInsErrorMessage;

    @FindBy(xpath = "//button[contains(text(),'Enter details manually')]")
    public WebElement enterDetailsManuallyButton;

    @FindBy(xpath = "//input[contains(@type,'radio')]")
    public WebElement insuranceRadioButton;

    @FindBy(xpath = "//*[contains(text(),'Trial card')]/following::*[contains(text(),'Continue')]")
    public WebElement removeTrialCardAndContinueButton;

    WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(30));

    public ManageInsurancePage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getManageInsuranceScreenTitle(){return getText(manageInsurancePageTitle);}

    public String getInsuranceAddedSuccessMessage(){return getText(insuranceAddedSuccessMessage);}

    public void addInsuranceWithoutBOM(String memberId, String bin, String pcn) {
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(0));
        sendText(insuranceMemberId,memberId,10);
        sendText(rxBin,bin,10);
        clickDoneButtonForIOSKeyboard();
        sendText(rxPCN,pcn,10);
        clickDoneButtonForIOSKeyboard();
        click(continueButton);
    }

    public void addInsuranceFromNudgeScreen(String memberId, String bin, String pcn) {
        wait.until(ExpectedConditions.elementToBeClickable(insuranceMemberId));
        sendText(insuranceMemberId, memberId, 10);
        sendText(rxBin, bin, 10);
        clickDoneButtonForIOSKeyboard();
        sendText(rxPCN, pcn, 10);
        clickDoneButtonForIOSKeyboard();
        click(continueButton);
    }

    public void addInsuranceWithoutPCN(String memberId, String bin) {
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(0));
        wait.until(ExpectedConditions.elementToBeClickable(insuranceMemberId));
        sendText(insuranceMemberId,memberId,10);
        sendText(rxBin,bin,10);
        clickDoneButtonForIOSKeyboard();
        click(continueButton);
    }

    public void addInsuranceWithoutBOM_Dependent(String memberId, String bin, String pcn) {
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(2));
        click(enterDetailsManuallyCTA);
        sendText(insuranceMemberId,memberId,10);
        sendText(rxBin,bin,10);
        sendText(rxPCN,pcn,10);
        clickDoneButtonForIOSKeyboard();
        click(continueButton);
    }

    public void addInsuranceWithBOM() {
        if(!(remoteDriver instanceof IOSDriver) && !(remoteDriver instanceof AndroidDriver)) {
            refreshPage();
        }
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(0));
        click(bomInsuranceRadioButton);
        click(addAndContinueButton);
    }

    public void addInsuranceWithBOM_Dependent() {
        if(!(remoteDriver instanceof IOSDriver) && !(remoteDriver instanceof AndroidDriver)) {
            refreshPage();
        }
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(2));
        click(bomInsuranceRadioButton);
        click(addAndContinueButton);
    }

    public String getMemberIdText(){
        return memberIdText.getText();}

    public String getBinText(){
        return binText.getText();}

    public String getPCNTest(){
        return blankPCNText.getText();}

    public boolean isPrimaryInsuranceTagDisplayed() {
        return isElementDisplayed(primaryInsuranceTag, 10);
    }

    public boolean isPrimaryInsuranceTagDisplayedIOS() {
        return isElementDisplayed(primaryInsuranceTagIOS, 10);
    }


    public void clickExpandInsurance(){click(expandInsuranceCTA);}


    public void goBackToManageMyInsurancePage() {
        click(backToManageMyInsurancePageCTA);
    }

    public void removeInsurance() {
        click(expandInsuranceCTA);
        waitForLoadingToDisappear(5);
        click(removeInsuranceCTA);
        waitForLoadingToDisappear(5);
        click(confirmButton);
        waitForLoadingToDisappear(5);
    }

    public void removeInsuranceIOS() {
        waitForLoadingToDisappear(5);
        click(removeInsuranceCTA);
        waitForLoadingToDisappear(5);
        click(confirmButton);
        waitForLoadingToDisappear(5);
    }


    public void clickBackButton(){
        click(backButton);
    }

    public List<WebElement> addInsuranceCTAList() {
        List<WebElement> addInsuranceCTAList;
        if (remoteDriver instanceof AndroidDriver) {
            addInsuranceCTAList = getDynamicWebElementsByTagAndAttribute("android.widget.Button", "content-desc", "Add Insurance for");
        } else if (remoteDriver instanceof IOSDriver) {
            addInsuranceCTAList = getDynamicWebElementsByTagAndAttribute("XCUIElementTypeStaticText", "name", "Add insurance");
        } else {
            addInsuranceCTAList = getDynamicWebElementsByTagAndAttribute("button", "text", "Add insurance");
        }
        return addInsuranceCTAList;
    }
    public void clickButtonChange(){
        waitForLoadingToDisappear(8);
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Change", "up");
        } else if(remoteDriver instanceof AndroidDriver){
            androidScrollToText("Change");
        } else {
            scrollToTextWithLoop("Change");
        }
        click(buttonChange);
    }
    public void selectPrescriptionInsuranceRadioButton(){
        click(radioButtonPrescriptionInsurance,5);
    }

    public void clickAddNewInsurance(){
        waitForLoadingToDisappear(8);
        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Add new insurance", "up");
        } else if(remoteDriver instanceof AndroidDriver){
            androidScrollToText("Add new insurance");
        } else {
            scrollToTextWithLoop("Add new insurance");
        }
        click(buttonAddNewInsurance);
    }
    public void clickEnterInsuranceDetailsManually(){
        click(buttonEnterDetailsManually);
    }
    public void clickSaveButton(){
        click(buttonSave,10);
    }
    public String getPricePendingText(){
       return getText(textPricePending);
    }
    public void addInsuranceWithBlankPCN(String memberId,String binNumber ){
        sendText(insuranceMemberId,memberId,5);
        sendText(rxBin,binNumber);
        click(buttonConfirmAndContinue);
    }
    public String getPCNText(){
        return getText(rxPCNText);
    }
    public  void clickContinueButton(){
        waitForLoadingToDisappear(8);
        click(continueButton);
    }
    public void clickOnInsuranceArrowDown(String memberID){
        String ele = "";
        if (remoteDriver instanceof AndroidDriver)
            ele = "(//android.widget.ImageView[@resource-id='com.walmart.android.debug:id/insurance_info_icon'])[1]";
        else if (remoteDriver instanceof IOSDriver)
            ele = "//XCUIElementTypeStaticText[contains(@name,'" + memberID + "')]";
        else ele = "//button[contains(@aria-label,'prescription insurance details for Member Id - "+memberID+"')]";
        click(remoteDriver.findElement(By.xpath(ele)));
         }
    public void clickOnInsuranceRadioButton(String memberID){
        String ele = "";
        if (remoteDriver instanceof AndroidDriver)
            ele = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/heading' and @text='Member ID: "+memberID+"']";
        else if (remoteDriver instanceof IOSDriver)
            ele = "//XCUIElementTypeStaticText[contains(@name,'" + memberID + "')]";
        else ele = "//*[contains(@aria-label,'"+memberID.toUpperCase()+"')]";
        click(remoteDriver.findElement(By.xpath(ele)),10);
    }

    public void validateAddInsuranceErrorForCaregiver(){
        click(addInsuranceCTA);
        wait.until(ExpectedConditions.visibilityOf(unableToFindInsErrorMessage));
    }

    public void addMultipleInsuranceWithBOM() {
        wait.until(ExpectedConditions.elementToBeClickable(manageInsuranceHub));
        List<WebElement> addInsuranceCTAList=addInsuranceCTAList();
        click(addInsuranceCTAList.get(0));
        click(bomInsuranceRadioButton);
        click(addAndContinueButton);
    }
public void removeTrialCardAndContinueButton(){
        click(removeTrialCardAndContinueButton);
}

    public void replaceInsuranceFromRefillReview(String memberId){
        clickButtonChange();
        selectPrescriptionInsuranceRadioButton();
        clickContinueButton();
        removeTrialCardAndContinueButton();
        clickOnInsuranceRadioButton(memberId);
        clickContinueButton();
    }
}