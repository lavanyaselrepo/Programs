/**
 * WebPageManager initialises the page manager for "WEB" platform.
 * It inherits BasePageApplicationManager.
 * Usage : Overridden methods for common interactions that are specific to WEB platform are written over here.
 *
 * @Author: Saloni Sharma
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package com.walmart.hwqe.digitalPharmacyuicontext.pageManagers;


import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.datacontext.AssertUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.DateUtils;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class WebPageManager extends BasePageApplicationManager {

    public WebPageManager(RemoteWebDriver driver, String platform) {

        super(driver, platform);
    }

    public void doSignIn() {

        signInPage.clickSignInButton();
        signInPage.clickCreateAccountOrSignInButton();
        signInPage.enterEmail("saloni.sharma@walmart.com");
        signInPage.clickContinueButton();
        signInPage.enterPassword("Walmart1234");
        signInPage.clickContinueSignInButton();
        signInPage.clickNotNowForPhoneVerification();
        // Navigate to pharmacy dashboard after sign-in
        homePage.navigateToPage(prop.getProperty("web.rxpd_base_url"));
    }

    public void doSignIn(String email, String password) {
        /* homePage.clickPersonalisationChoiceButton();
        signInPage.closeLanguageSelection();
        signInPage.clickSignInButton();
        signInPage.clickCreateAccountOrSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully"); */
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickOnEnterPasswordRadioBtn();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        signInPage.clickNotNowForPhoneVerification();

        if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
            signInPage.clickSendcode();
            // Takes time between sending otp and astro API to receive it
            am.performSleep(3);
            DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
            String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
            signInPage.enterInputOtpValue(otp);
            signInPage.clickSignInButtonForStepUp();
            am.performSleep(3);
        }
        homePage.navigateToPage(prop.getProperty("web.rxpd_base_url"));
        pharmacyDashboardPage.refreshPage();
    }

    public void validateExperianFlowHeader() {
        Assert.assertTrue(connectMyAccount.experianFlow(),"Experian flow header not displayed");
    }

    public void doSignIn(String email, String password, String phone) {
        /* homePage.clickPersonalisationChoiceButton();
        signInPage.closeLanguageSelection();
        signInPage.clickSignInButton();
        signInPage.clickCreateAccountOrSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully"); */
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickOnEnterPasswordRadioBtn();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        signInPage.clickNotNowForPhoneVerification();
        if (!pharmacyDashboardPage.isVerifyInputPinVisible()) {
            if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
                signInPage.clickSendcode();
                // Takes time between sending otp and astro API to receive it
                am.performSleep(5);
                DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
                String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
                if (otp == null) {
                    otp = digitalPharmacyAPIManager.getOTPForPhone(email, phone);
                }
                if (otp == null) {
                    Reporter.log("One time passcode is null");
                    Assert.fail("Cannot get One time Passcode for this user");
                }
                Reporter.log("One time passcode is :: " + otp);
                signInPage.enterInputOtpValue(otp);
                signInPage.clickSignInButtonForStepUp();
                if (!signInPage.isSignInButtonNotDisplayed()) {
                    Assert.fail("One time password Entered is wrong");
                }
            }
        }
        // Navigate to pharmacy dashboard after sign-in
        homePage.navigateToPage(prop.getProperty("web.rxpd_base_url"));
        Reporter.log("Logged In successfully");
    }

    public void closeJoinOneProgram() {
    }

    public void clickServicesTab() {
    }

    public void closeWalmartPlusProgramButton() {
    }

    public void proceedToPharmacyDashboard() {
        if (pharmacyDashboardPage.isVerifyInputPinVisible()) {
            pharmacyDashboardPage.enterInputPin();
            pharmacyDashboardPage.verifyPin();
            fillStatusTrackerCardPage.clickOnAcknowledgeBtn();
        }
    }

    public void proceedToMyPrescriptionsSection() {
        pharmacyDashboardPage.clickMyPrescriptionsTab();
    }

    public void continueAsGuest() {
    }

    public void proceedToPharmacyDashboardForGuestUser() {
        this.proceedToPharmacyDashboard();
    }

    public void scanRxDetailsManually(String rxNb, String storeNb, String dob) {
        scanToRefillPage.clickAddPrescription();
        scanToRefillPage.enterRxNumber(rxNb);
        scanToRefillPage.enterStoreNumber(storeNb);
        scanToRefillPage.enterDOB(dob);
        scanToRefillPage.clickConfirmAddedPrescription();
    }

    public void proceedToScanToRefill() {
        pharmacyDashboardPage.clickMinimizePickupOptionPopUp();
        super.proceedToScanToRefill();
        pharmacyDashboardPage.clickRefillAsGuest();
    }

    public void proceedToScanToRefillNotConnected() {
        pharmacyDashboardPage.clickScanToRefillNotConnected();
    }

    public void doSignInForGuest(String email, String password) {
    }

    public void verifyOneRxAdded() {
        Object value = textValidationUtils.getKeyInObject("ScannedPrescriptionPage", "AddMoreWeb");
        Assert.assertEquals(scanToRefillPage.getScanAnotherRxButtonText(), value, "The Prescription Wasn't Added");
    }

    public void selectStoreDetails() {

        selectStorePage.enterZipCode();
        selectStorePage.clickSearchZipCodeButton();
        selectStorePage.selectStoreOption();
        selectStorePage.clickSaveStoreButton();
    }

    public void verifySinglePrescriptionSeeDetailsAction() {
    }

    /**
     * Fills Summary Page Methods
     */

    public void verifyRxNamesForMultiRx(List<String> expectedRxNames) {
        List<String> visibleRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRxWeb();
        Assert.assertEquals(visibleRxNames, expectedRxNames, "The rx(s) visible for patient are not correct");
    }

    public void verifyDetailsForSelfAndDependent(List<String> expectedRxNames, List<String> expectedPatientNames, boolean isPet) {
        List<String> actualRxNames = rxReadyForRefillCardPage.getRxNamesForMultiRxWeb();
        List<String> actualPatientNames = rxReadyForRefillCardPage.getPatientNamesForMultiRxWeb();
        Assert.assertEquals(actualRxNames, expectedRxNames, "The rx(s) visible for patient are not correct");
        Assert.assertEquals(actualPatientNames, expectedPatientNames, "The patient and dependant names visible are not correct");
        Assert.assertTrue(fillStatusTrackerCardPage.isPetPatientIconVisible(), "pet icon is not visible for pet patient");
        Assert.assertTrue(fillStatusTrackerCardPage.isHumanPatientIconVisible(), "Human icon is not visible for Human patient");
    }

    public void verifySingleRxInFilling(String patientName, String drugName, String estimatedPrice, boolean isPet) {
        Object singleRxFillingHeaderText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderText");
        Object singleRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxInFilling", "CardHeaderDescriptionText");
        boolean success = rxInFillingCardPage.isFillStatusCardHeaderForFillingStatusVisible();
        if (success) {
            Assert.assertEquals(rxInFillingCardPage.getFillStatusCardHeaderText(1, singleRxFillingHeaderText.toString()), singleRxFillingHeaderText, "Card Header is Incorrect");
            Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), singleRxFillingCardHeaderDescriptionText, "Fill status card sub header text is not visible");
            Assert.assertEquals(rxInFillingCardPage.getPatientNameOnFillTrackerCard().toUpperCase(), patientName.toUpperCase(), "Patient name is incorrect");
            assertThat("drug Name on screen does not match the backend drug name", rxInFillingCardPage.getRxName().replaceAll("\\s", "").toLowerCase(), is(drugName.replaceAll("\\s", "").toLowerCase()));
            //Assert.assertEquals(rxInFillingCardPage.getRxName(), drugName, "Drug name is incorrect");
            Assert.assertEquals(rxInFillingCardPage.getPrescriptionsCount(), rxInFillingCardPage.prescriptionCountTxt(1));
            assertThat("Price is incorrect", rxInFillingCardPage.getEstimatedPrice(), containsString(estimatedPrice));
            Assert.assertTrue(rxInFillingCardPage.isFillDetailsArrowCTAVisible(), "Chevron icon not visible in Rx row");
            if (isPet) Assert.assertTrue(rxInFillingCardPage.isPetIconVisible());
            logScreenShot("Single Rx In Filling Tracker Card");
        }
    }
    public void verifySingleRxReadyForPickup(String patientName, String drugName, String drugPrice, boolean isPet) {
        if (Double.parseDouble(drugPrice) == 0) drugPrice = "0.00";
        Object value = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "SingleRxReadyForReadyForPickup", "CardHeaderText");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.isDrugImageVisible(), true, "Drug Image is not visible");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getFillStatusCardHeaderText(), value, "ReadyForPickup Card Header is Incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getPatientNameOnFillTrackerCard().toUpperCase(), patientName, "Patient name is incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxName().toUpperCase().replaceAll("\\s+", ""), drugName.replaceAll("\\s+", ""), "Drug name is incorrect");
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getRxEstimatedPrice(), "$" + drugPrice, "Drug price is incorrect");
        if (isPet) {
            Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isPetPatientIconVisible(), "pet icon is not visible for a pet patient");
        } else {
            Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isHumanIconVisible(), "Human icon is not visible for a Human patient");
        }
    }

    public void verifyRxDetailsScreenForReadyForPickup(String rxName, String rxEstimatedPrice, String rxNbr, String patName, String prescriber, String rxDate, String quantity, String supply, String instructions) {
        if (Double.parseDouble(rxEstimatedPrice) == 0) rxEstimatedPrice = "0.00";
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSeeDetails();
        Assert.assertEquals(prescriptionDetailsPage.getRxName().toUpperCase().replaceAll("\\s+", ""), rxName.replaceAll("\\s+", ""), "rxName not matching");
        Assert.assertEquals(prescriptionDetailsPage.getRxEstimatedPrice(), "Price: $" + rxEstimatedPrice, "RxExtimated Price Incorrect");
        Assert.assertEquals(prescriptionDetailsPage.getRxValue(), rxNbr, "Rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPatientValue().toUpperCase(), patName, "Patient Name not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPrescriberValue().toUpperCase(), prescriber, "Prescriber Name not matching");
        String date = DateUtils.convertFormat(rxDate, "yyyy-MM-dd", "MMM dd, yyyy");
        Assert.assertEquals(prescriptionDetailsPage.getRxDateValue(), date, "Rx Prescription Date not matching");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityValue(), quantity, "Prescription Quantity not matching");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyValue(), supply + " days", "Rx Supply not matching");
        Assert.assertEquals(prescriptionDetailsPage.getInstructionsValue().toUpperCase(), instructions, "instructions value not matching");
    }

    public void verifyRxDetailsScreenForFilling(String rxName, String rxEstimatedPrice, String rxNbr, String patName, String prescriber, String rxDate, String quantity, String supply, String lastReceived, String instructions) {
        rxInFillingCardPage.clickFillDetailsArrowCTA();
        assertThat("drug Name on screen does not match the backend drug name", prescriptionDetailsPage.getRxName().replaceAll("\\s", "").toLowerCase(), is(rxName.replaceAll("\\s", "").toLowerCase()));
        assertThat("Price is incorrect", prescriptionDetailsPage.getRxEstimatedPrice(), containsString(rxEstimatedPrice));
        Assert.assertEquals(prescriptionDetailsPage.getRxValue(), rxNbr, "Rx Number not matching");
        Assert.assertEquals(prescriptionDetailsPage.getPatientValue(), patName, "Patient Name not matching");
        String date = DateUtils.convertFormat(rxDate, "yyyy-MM-dd", "MMM dd, yyyy");
        Assert.assertEquals(prescriptionDetailsPage.getRxDateValue(), date, "Rx Prescription Date not matching");
        Assert.assertEquals(prescriptionDetailsPage.getQuantityValue(), quantity, "Prescription Quantity not matching");
        Assert.assertEquals(prescriptionDetailsPage.getSupplyValue(), supply + " days", "Rx Supply not matching");
        // Assert.assertEquals(prescriptionDetailsPage.getLastReceivedValue(), lastReceived, "Rx Last Received Value not matching");
        Assert.assertEquals((prescriptionDetailsPage.getInstructionsValue()).toUpperCase(), instructions, "rx Number not matching");
        // assertThat("Prescriber Name is not matching", prescriptionDetailsPage.getPrescriberValue(), equalToIgnoringCase(prescriber));
        //Assert.assertEquals(prescriptionDetailsPage.getPrescriberValue(), prescriber, "Prescriber name not matching");
    }

    public void proceedToPharmacyDashboardWithATCEnabled() {
        homePage.clickPersonalisationChoiceButton();
        am.performSleep(2);
        pharmacyDashboardPage.enterInputPin();
        pharmacyDashboardPage.verifyPin();
        pharmacyDashboardPage.dismissAddressVerificationDialogIfPresent();
    }

    public void addRxToCartValidationForC2() {
        Assert.assertFalse(rxReadyForPickupAndDeliveryTrackerCardPage.isAddToCartEnabled(), "AddToCart is not enabled");
    }

    public void addRxToCartValidationForMedicare() {
        Assert.assertFalse(rxReadyForPickupAndDeliveryTrackerCardPage.isAddToCartEnabled(), "AddToCart is not enabled");
    }

    public void updateCartCountToZero() {
        int cartCount = rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount();
        if (cartCount > 0) {
            for (int i = 0; i < cartCount; i++) {
                rxReadyForPickupAndDeliveryTrackerCardPage.clickOnDecreaseQuantityBtn();
            }
        }
    }

    public void handlePharmacyPinValidation(String pin) {
        if (pharmacyDashboardPage.isVerifyInputPinVisible()) {
            pharmacyDashboardPage.enterPharmacyPin(pin);
            Reporter.log("entered pin for PharmacyDashboard");
            pharmacyDashboardPage.verifyPin();
        }
        Reporter.log("Entered pharmacy PIN and navigated to pharmacy dashboard");
    }


    public void refreshpage() {
        rxReadyForRefillCardPage.refreshPage();
    }

    public void addGroceryItemToCart(String item) {
        rxReadyForPickupAndDeliveryTrackerCardPage.clickSearch();
        Reporter.log("Navigated to ecomm search page");
        rxReadyForPickupAndDeliveryTrackerCardPage.enterGroceryItems(item);
        rxReadyForPickupAndDeliveryTrackerCardPage.waitForCompletePageLoad();
        Reporter.log("Entered Non-RX item in search and clicked enter");
        am.performSleep(10);
        rxReadyForPickupAndDeliveryTrackerCardPage.clickAddCartButtonForNonRxItem();
        Reporter.log("Click addToCart CTA for non-RX item");
    }

    public void verifyRxDetailsInEcommCart(String itemCount, String insuranceTitle) {
        am.performSleep(30);
        String expectedCartTitle = "";
        if (Integer.parseInt(itemCount) > 1) expectedCartTitle = "(" + itemCount + " items)";
        else expectedCartTitle = "(" + itemCount + " item)";
        Assert.assertEquals(ecommCartPage.getEcommCartTitle(), expectedCartTitle);
        Assert.assertEquals(ecommCartPage.getInsuranceTitleTextForRx(), insuranceTitle);
    }

    public void verifyRecommendationProductsGroupVisible(boolean isRx) {
        ecommCartPage.waitForCompletePageLoad();
        if (isRx) {
            AssertUtil.assertFalse(ecommCartPage.isRecommendationProductsGroupVisible(), "Recommendation Products Group shouldn't display for RX");
        } else {
            AssertUtil.assertTrue(ecommCartPage.isRecommendationProductsGroupVisible(), "Recommendation Products Group should display for Non-Rx products");
        }
    }

    public void verifySaveForLaterLinkForRx() {
        ecommCartPage.waitForCompletePageLoad();
        AssertUtil.assertFalse(ecommCartPage.isSaveForLaterLinkVisible(), "Save for later link Shouldn't display for Rx products");
    }

    public void verifyRxImagesCount(int maxExpectedCount) {
        ecommCartPage.waitForCompletePageLoad();
        AssertUtil.assertEquals(ecommCartPage.rxImages.size(), maxExpectedCount);
    }

    public void scrollToPickup() {
        scrollToPickup();
    }

    public void verifyMaxOneQuantity() {
        Assert.assertTrue(rxReadyForPickupAndDeliveryTrackerCardPage.isMax1TextVisible(), "Max 1 text is not visible");
        Reporter.log("Assert: Max 1 quantity text is visible.");
    }

    public boolean verifyCartCount(int expectedCount) {
        int count = 0;
        while (count < 5) {
            if (rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount() == expectedCount) {
                Reporter.log("Cart badge quantity and Expected count is matching");
                return true;
            }
            Reporter.log("Cart badge quantity is " + rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount() + " But expected " + expectedCount);
            am.performSleep(2);
            count++;
        }
        Reporter.log("Cart badge quantity is not matching Expected quantity even after 10 seconds");
        return false;
    }

    public void verifyCartCount(int expectedCount, int waitTime) {
        Assert.assertEquals(rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount(waitTime), expectedCount, "Cart badge quantity is incorrect");
        Reporter.log("Assert: Cart badge quantity is " + expectedCount);
    }

    public void logScreenShot(String header) {
        Reporter.logScreenShot(header, ecommCartPage.captureScreenShot());
    }

    public void changeDeliveryToPickupFirstSlot() {
        ecommCartPage.clickOnChangeLink();
        ecommCartPage.clickOnPickupTab();
        ecommCartPage.clickOnPickupFirstSlotRdoBtn();
        ecommCartPage.clickOnReserveBtn();
    }

    public void verifyCurbSidePickupNotAvailableTxt() {
        Assert.assertTrue(ecommCartPage.isCurbsidePickupNotAvailableTextDisplayed(), "'Curbside pickup not available' text is not visible.");
        Reporter.log("'Curbside pickup not available' text is visible.");
    }

    public void clearCartAndNavigateToPharmacyDashboardPage() {
        if (rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount() > 0) {
            pharmacyDashboardPage.proceedToEcommCart();
            ecommCartPage.clearCart();
            homePage.navigateToPharmacyDashboardPage();
        }
    }

    public void clearCart() {
        if (rxReadyForPickupAndDeliveryTrackerCardPage.getCartCount() > 0) {
            pharmacyDashboardPage.proceedToEcommCart();
            ecommCartPage.clearCart();
        }
    }

    public void navigateToPharmacyDashboardPage() {
        homePage.navigateToPharmacyDashboardPage();
    }

    public void navigateToOrdersPage() {
        homePage.navigateToOrdersPage();
    }

    public void verifyRxAmendmentAndRemoveProducts() {
        orderConfirmationPage.clickAccountCta();
        orderConfirmationPage.clickPurchaseHistoryCta();
        purchaseHistoryPage.clickOnFirstEditItemsButton();
        AssertUtil.assertTrue(purchaseHistoryPage.isNotEligibleForSubstitutionDescriptionTextDisplayed(), "Not Eligible For Substitution Description Text");
        AssertUtil.assertTrue(purchaseHistoryPage.isNotEligibleForSubstitutionTextDisplayed(), "Not Eligible For Substitution Text");
        int removeButtonsCount = purchaseHistoryPage.removeButtons.size();
        for (int i = 0; i < removeButtonsCount; i++) {
            purchaseHistoryPage.click(purchaseHistoryPage.removeButtons.get(i), "Remove Button");
            if (purchaseHistoryPage.isElementDisplayed(purchaseHistoryPage.confirmCancelBtn, 1)) {
                purchaseHistoryPage.clickOnCancelReasonRadioBtn();
                purchaseHistoryPage.clickOnConfirmCancelBtn();
            }
        }
        AssertUtil.assertTrue(purchaseHistoryPage.isCancellationRequestedTodayTextDisplayed(), "Reorder All Button");
    }

    public void proceedToCheckoutRxsAddedToCart(String cvvNumber, Boolean isDiscardCheckout, Boolean isPlaceOrder) throws Exception {
        orderCheckoutPage.waitForCompletePageLoad();
        orderCheckoutPage.clickContinueToCheckout();
        orderCheckoutPage.clickStoreDeliveryCTA();
        orderCheckoutPage.waitForCompletePageLoad();
        orderCheckoutPage.clickSelectFirstSlot();
        orderCheckoutPage.clickConfirmAddressContinueButton();
        orderCheckoutPage.clickBookSlotContinueButton();
        orderCheckoutPage.enterCVVNumber(cvvNumber);
        if (isPlaceOrder) orderCheckoutPage.clickPlaceOrderCTA();
        else if (isDiscardCheckout) this.discardCheckoutProcess();
        orderCheckoutPage.waitForCompletePageLoad();
    }

    public void navigateToManageMyFamilyPage() {
        this.clickOnManageFamilyCTA();
        pharmacyDashboardPage.waitForCompletePageLoad();
        AssertUtil.assertTrue(manageFamilyPage.isMyAccountTextDisplayed(), "Manage my family - My account text");
    }

    public void verifyMyAccountInManageMyFamilyPage(String patientName, String patientDob, int prescriptionsCount) {
        try {
            patientDob = new SimpleDateFormat("MMM dd, yyyy").format(new SimpleDateFormat("MMddyyyy").parse(patientDob));
        } catch (ParseException e) {
            Reporter.log("Date format should be in 'ddMMyyyy'. Current format is " + patientDob);
            throw new RuntimeException(e);
        }
        AssertUtil.assertEquals(manageFamilyPage.getPageHeading(), "Manage my family");
        AssertUtil.assertTrue(manageFamilyPage.isManagePrescriptionTextDisplayed(), "Manage my family - sub header text");
        AssertUtil.assertTrue(manageFamilyPage.isMyAccountTextDisplayed(), "Manage my family - My account text");
        AssertUtil.assertEquals(manageFamilyPage.getPatientName(0).toUpperCase().toUpperCase(), patientName.toUpperCase());
        AssertUtil.assertEquals(manageFamilyPage.getPatientDob(0), "Date of birth: " + patientDob);
        AssertUtil.assertTrue(manageFamilyPage.isViewRxButtonDisplayed(patientName), "View RX Button");
        if (prescriptionsCount == 0) {
            AssertUtil.assertFalse(manageFamilyPage.isPrescriptionsCountTextDisplayed(0), "Prescription Count should n't display");
        } else if (prescriptionsCount == 1) {
            AssertUtil.assertEquals(manageFamilyPage.getPrescriptionsCount(0), prescriptionsCount + " prescription");
        } else {
            AssertUtil.assertEquals(manageFamilyPage.getPrescriptionsCount(0), prescriptionsCount + " prescriptions");
        }
        AssertUtil.assertTrue(manageFamilyPage.isAddFamilyMemberButtonDisplayed(), "Add family member button");
    }

    public void addFamilyDetails(boolean isAdultPatient, boolean isPet, String firstName, String lastName, String dob, String emailAddress, String prescriptionNumber, String storeNumber) {
        addFamilyMemberPage.enterFirstName(firstName);
        addFamilyMemberPage.enterLastName(lastName);
        addFamilyMemberPage.enterDOB(dob);
        if (isPet) {
            addFamilyMemberPage.clickOnPetCheckBox();
        } else if (isAdultPatient) {
            addFamilyMemberPage.enterEmailAddress(emailAddress);
        }
        addFamilyMemberPage.enterPrescriptionNumber(prescriptionNumber);
        addFamilyMemberPage.enterStoreNumber(storeNumber);
    }

    public String getTextFromPatientContainer(String expectedPatientName) {
        List<WebElement> patientLists = manageFamilyPage.patientContainers;
        AssertUtil.assertFalse(patientLists.isEmpty(), "Members List");
        for (WebElement patient : patientLists) {
            String textValue = manageFamilyPage.getText(patient);
            if (textValue.contains(expectedPatientName)) {
                return textValue;
            }
        }
        return null;
    }

    public void clickOnHowYouWantYourItemsDownChevron() {
        ecommCartPage.clickOnHowYouWantYourItemDownChevron();
    }

    public void selectDeliveryFromStoreAddress() {

        ecommCartPage.clickOnDeliveryFromStore();
    }

    public void enterZipCodeOrCityState(String zipCode) {
        ecommCartPage.enterZipCodeOrCityState(zipCode);
    }

    public void clickViewDetailsButton() {
        ecommCartPage.clickViewDetailsButton();
    }

    public void verifyItemUpdatesText(String itemUpdatesText) {
        Assert.assertTrue(ecommCartPage.itemUpdatesText.getText().contains(itemUpdatesText), "Expected item ineligible for delivery message is not displayed in item Updates.");
    }

    public void verifyItemErrorDetailsText(String expectedText) {
        Assert.assertTrue(ecommCartPage.getItemErrorDetailsText().contains(expectedText), "Expected item ineligible for delivery message is not displayed in cart page.");
    }

    public void setDeliveryFromStore(String storeID, String zipCode) {
        clickOnHowYouWantYourItemsDownChevron();
        selectDeliveryFromStoreAddress();
        enterZipCodeOrCityState(zipCode);
        if (ecommCartPage.isElementDisplayed(By.xpath("//input[contains(@id, '" + storeID + "')]"))) {
            WebElement storeToSelect = ecommCartPage.remoteDriver.findElement(By.xpath("//input[contains(@id, '" + storeID + "')]"));
            ecommCartPage.click(storeToSelect);
        } else {
            Assert.fail("Failed to identify New delivery from store");
        }
        ecommCartPage.clickSaveNewStoreSelected();
        if (ecommCartPage.isElementDisplayed(ecommCartPage.errorAlertOnStoreSave, 5)) {
            ecommCartPage.clickSaveNewStoreSelected();
        }
        Reporter.log("Store ID:" + storeID + "is selected successfully.");
    }

    public void changeDeliveryToAddress(String addressID) {
        clickOnHowYouWantYourItemsDownChevron();
        ecommCartPage.clickDeliveryToAddressChevron();
        String newDeliveryAddressXpath = "//input[@id='" + addressID + "']";
        Reporter.log("New Preferred Delivery Address xpath:" + newDeliveryAddressXpath);
        ecommCartPage.click(ecommCartPage.getDynamicWebElementsByTagAndAttribute("input", "id", addressID).get(0), 12);
        ecommCartPage.clickDeliveryAddressSaveButton();
        ecommCartPage.refreshPage();
    }


    public void moveRXsToEOD(List<Integer> rxList, int storeId) {
        try {
            for (int rxNum : rxList) {
                String rxFillIdQuery = "select rx_fill_id from rx_fill where rx_id in (SELECT rx_id FROM RX where rx_nbr in (" + rxNum + "))";
                List<Map<String, Object>> resultSet = am.getConnexusDB(storeId).executeQueryForList(rxFillIdQuery);

                //Moving Rx to EOD
                ServiceResponse resp = new DigitalPharmacyAPIManager().moveRxToEODAPI_Astro(Integer.parseInt(resultSet.get(resultSet.size() - 1).get("rx_fill_id").toString()), storeId);
                //Assert.assertEquals(resp.getStatusCode(), 200, "Move RX api failed for rxNum " + rxNum);
                if (resp.getStatusCode() != 200) {
                    Reporter.log("Move RX api failed for rxNum :: " + rxNum);
                }
                Reporter.log("RxNumber " + rxNum + " Moved to EOD");
            }
        } catch (Exception e) {
            Reporter.log("Move RX api failed with exception " + e.getMessage());
        }
    }

    public List<Integer> getAllFillsInPickupQueue(int storeId) {
        String rxFillIdQuery = "select rx_fill_id from informix.rx_order_detail where next_work_que_code= 6 and tote_nbr is not null and need_pickup_ind = \"Y\" and status_code = 20501 limit 1";
        List<Map<String, Object>> resultSet = am.getConnexusDB(storeId).executeQueryForList(rxFillIdQuery);
        List<Integer> fillIds = new ArrayList<>();
        for (Map<String, Object> fill : resultSet) {
            fillIds.add(Integer.parseInt(fill.get("rx_fill_id").toString()));
        }
        return fillIds;
    }

    /**
     * This method will move all Fills to EOD and release Bags
     */
    public boolean moveRXsToEODJob(List<Integer> fillIds, int storeId) {
        for (int fillId : fillIds) {
            try {
                //Moving Rx to EOD
                ServiceResponse resp = new DigitalPharmacyAPIManager().moveRxToEODAPI_Astro(fillId, storeId);
                //Assert.assertEquals(resp.getStatusCode(), 200, "Move RX api failed for rxNum " + rxNum);
                if (resp.getStatusCode() != 200) {
                    Reporter.log("Move RX api failed for fillId :: " + fillId);
                    Reporter.logJSON("Move RX to EOD response is :: ", resp.getDataResponse());
                } else {
                    Reporter.log("RxNumber " + fillId + " Moved to EOD");
                    Reporter.logJSON("Move RX to EOD response is :: ", resp.getDataResponse());
                }
            } catch (Exception e) {
                Reporter.log("Move RX api failed with exception " + e.getMessage());
            }
        }
        return true;
    }

    /**
     * This method will work when current page is Refill prescriptions page.
     * Before this, navigate to refill page
     */
    public void verifyRefillPageShouldNotDisplayDisabledCheckBox() {
        for (int i = 0; i < 60; i++) {
            refillPrescriptionPage.refreshPage();
            if (refillPrescriptionPage.isDisabledCheckboxAvailable(20)) {
                am.performSleep(5);
            } else {
                break;
            }
        }
    }

    public void performRefillForAllPrescriptions() {
        // Performing refill from refill prescriptions page
        refillPrescriptionPage.selectAllRefillCheckboxes();
        refillPrescriptionPage.clickContinueRefillButton();
        refillPrescriptionPage.clickRequestRefillButton();
        refillPrescriptionPage.isDisplayedRefillSuccessMsg();
        refillPrescriptionPage.isDisplayedRefillDeliveryTimeMsg();
        logScreenShot("Refill prescriptions success page");
        navigateToPharmacyDashboardPage();
    }

    public void moveRXsToPickUp(List<Integer> rxList, int storeId) {
        for (int rxNum : rxList) {
            String rxFillIdQuery = "select rx_fill_id from rx_fill where rx_id in (SELECT rx_id FROM RX where rx_nbr in (" + rxNum + "))";
            List<Map<String, Object>> resultSet = am.getConnexusDB(storeId).executeQueryForList(rxFillIdQuery);

            //Moving Rx to pickup
            ServiceResponse resp = new DigitalPharmacyAPIManager().moveRxToPickupAPI_Astro(Integer.parseInt(resultSet.get(resultSet.size() - 1).get("rx_fill_id").toString()), storeId);
            Assert.assertEquals(resp.getStatusCode(), 200, "Move RX api failed");
        }
    }

    public void verifyPickupRxsCountInDashboard(int expectedPickupRxsCount) {
        navigateToPharmacyDashboardPage();
        closeDeliveryAvailablePopup();
        boolean status = false;
        boolean popupStatus = false;
        for (int i = 0; i < 10; i++) {
            if (!(getAddToCartCount() >= expectedPickupRxsCount)) {
                Reporter.log("Waiting for 30 sec for the :: " + i + " time");
                am.performSleep(30);
                navigateToPharmacyDashboardPage();
                if (!popupStatus && pharmacyDashboardPage.isVerifyInputPinVisible()) {
                    pharmacyDashboardPage.enterInputPin();
                    pharmacyDashboardPage.verifyPin();
                    popupStatus = true;
                }
            } else {
                AssertUtil.assertTrue(true, expectedPickupRxsCount + " Add to cart buttons should display");
                status = true;
                break;
            }
        }
        AssertUtil.assertTrue(status, "Pickup orders should display.");
        if (!popupStatus) {
            if (pharmacyDashboardPage.isVerifyInputPinVisible()) {
                pharmacyDashboardPage.enterInputPin();
                pharmacyDashboardPage.verifyPin();
            }
        }
        navigateToPharmacyDashboardPage();
        closeDeliveryAvailablePopup();
    }

    public void connectToPharmacy(String otp, String dob) {
        connectMyAccount.sendOTP(otp);
        connectMyAccount.clickOtpAcceptCTA();
        am.performSleep(4);
        connectMyAccount.clickContinueForProfileCTA();
        connectMyAccount.enterDobForPatientProfile(dob);
        connectMyAccount.clickConfirmCTA();
        connectMyAccount.clickCreatePinCTA();
        pharmacyDashboardPage.enterInputPin();
        pharmacyDashboardPage.verifyPin();
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.denyBiometricsPermissionButton();
    }

    public void addMinorFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob) {
        try {
            manageFamilyMembersPage.clickPrescriptionInformation();
            manageFamilyMembersPage.clickContinueButton();
            manageFamilyMembersPage.enterPrescriptionNumber(rx);
            manageFamilyMembersPage.enterStoreNumber(storeNumber);
            manageFamilyMembersPage.clickContinueButton();
            manageFamilyMembersPage.enterDateOfBirth(dob);
            manageFamilyMembersPage.clickConfirmButton();
            if (manageFamilyMembersPage.isMinorAdded()) {
                Reporter.logScreenShot("Added minor successfully", manageFamilyMembersPage.captureScreenShot());
                this.removeDependents();
            }
        } catch (Exception e) {
            Reporter.logScreenShot("Failed to add minor", manageFamilyMembersPage.captureScreenShot());
            Assert.fail();
        }
    }

    public void addPetFamilyMemberUsingRxNumber(String rx, String storeNumber) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.clickConfirmPet();
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isPetAdded()) {
            Reporter.logScreenShot("Added Pet successfully", manageFamilyMembersPage.captureScreenShot());
            removeDependents();
        }
    }

    public void addLivestockFamilyMemberUsingRxNumber(String rx, String storeNumber) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        if (manageFamilyMembersPage.verifyLivestockErrorMessage()) {
            Reporter.logScreenShot("Livestock not supported", manageFamilyMembersPage.captureScreenShot());
        }
    }

    public void removeDependents() {
        manageFamilyMembersPage.removeDependents();
        if (manageFamilyMembersPage.isDepedentFound()) {
            Reporter.logScreenShot("Failed add remove all dependents", manageFamilyMembersPage.captureScreenShot());
        } else {
            Reporter.logScreenShot("Successfully removed all dependents", manageFamilyMembersPage.captureScreenShot());
        }
    }

    public void addMinorFamilyMemberUsingPhoneNumber(String phoneNumber, String email, String dob) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(email, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectMinor();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isMinorAdded()) {
            Reporter.logScreenShot("Added minor successfully", manageFamilyMembersPage.captureScreenShot());
            this.removeDependents();
        }
    }

    public void addPetFamilyMemberUsingPhoneNumber(String phoneNumber, String email) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(email, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectPet();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.clickConfirmPet();
        manageFamilyMembersPage.clickConfirmButton();
        if (manageFamilyMembersPage.isPetAdded()) {
            Reporter.logScreenShot("Added Pet successfully", manageFamilyMembersPage.captureScreenShot());
            this.removeDependents();
        }
    }

    public void addLivestockFamilyMemberUsingPhoneNumber(String phoneNumber) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        if (manageFamilyMembersPage.verifyLivestockPhoneNumberErrorMessage()) {
            Reporter.logScreenShot("Livestock not supported", manageFamilyMembersPage.captureScreenShot());
            //manageFamilyMembersPage.remoteDriver.navigate().back();
        }
    }

    public void addAdultFamilyMemberUsingRxNumber(String rx, String storeNumber, String dob, String email, String password, String careGiverEmail, String careGiverPassword) {
        manageFamilyMembersPage.clickPrescriptionInformation();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPrescriptionNumber(rx);
        manageFamilyMembersPage.enterStoreNumber(storeNumber);
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmAdultButton();
        if (manageFamilyMembersPage.sentRequestToAdult()) {
            Reporter.logScreenShot("Sent email request to dependent", manageFamilyMembersPage.captureScreenShot());
            signInPage.clickOnAccount();
            signInPage.clickOnSignout();
            am.performSleep(5);
            signInPage.enterEmail(email);
            signInPage.clickContinueButton();
            signInPage.enterPassword(password);
            signInPage.clickContinueSignInButton();
            am.performSleep(5);
            pinCreationPages.setPin();
            pinCreationPages.clickVerifyPinButton();
            manageFamilyMembersPage.clickAccept();
            Reporter.logScreenShot("Request accepted by dependent", manageFamilyMembersPage.captureScreenShot());
            signInPage.clickOnAccount();
            signInPage.clickOnSignout();
            am.performSleep(5);
            signInPage.enterEmail(careGiverEmail);
            signInPage.clickContinueButton();
            signInPage.clickOnEnterPasswordRadioBtn();
            signInPage.enterPassword(careGiverPassword);
            signInPage.clickContinueSignInButton();
            am.performSleep(5);
            pinCreationPages.setPin();
            pinCreationPages.clickVerifyPinButton();
            if (manageFamilyMembersPage.isAdultManageAccepted()) {
                Reporter.logScreenShot("Verified accepted by dependent", manageFamilyMembersPage.captureScreenShot());
                this.removeDependents();
            }
        }
    }

    public void addAdultFamilyMemberUsingPhoneNumber(String phoneNumber, String storeNumber, String dob, String emailForPin, String email, String password, String careGiverEmail, String careGiverPassword) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        am.performSleep(5);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(emailForPin, phoneNumber);
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
        manageFamilyMembersPage.selectAdult();
        manageFamilyMembersPage.addSelected();
        manageFamilyMembersPage.enterDateOfBirth(dob);
        manageFamilyMembersPage.clickConfirmAdultButton();
        if (manageFamilyMembersPage.sentRequestToAdult()) {
            Reporter.logScreenShot("Sent email request to dependent", manageFamilyMembersPage.captureScreenShot());
            signInPage.clickOnAccount();
            signInPage.clickOnSignout();
            am.performSleep(5);
            signInPage.enterEmail(email);
            signInPage.clickContinueButton();
            signInPage.enterPassword(password);
            signInPage.clickContinueSignInButton();
            am.performSleep(5);
            pinCreationPages.setPin();
            pinCreationPages.clickVerifyPinButton();
            manageFamilyMembersPage.clickAccept();
            Reporter.logScreenShot("Request accepted by dependent", manageFamilyMembersPage.captureScreenShot());
            signInPage.clickOnAccount();
            signInPage.clickOnSignout();
            am.performSleep(5);
            signInPage.enterEmail(careGiverEmail);
            signInPage.clickContinueButton();
            signInPage.clickOnEnterPasswordRadioBtn();
            signInPage.enterPassword(careGiverPassword);
            signInPage.clickContinueSignInButton();
            am.performSleep(5);
            pinCreationPages.setPin();
            if (manageFamilyMembersPage.isAdultManageAccepted()) {
                Reporter.logScreenShot("Verified accepted by dependent", manageFamilyMembersPage.captureScreenShot());
                this.removeDependents();
            }
        }
    }
    public void navigateBckToAddFamilyMemberScreen() {
        int i = 0;
        while (true) {
            manageFamilyPage.remoteDriver.navigate().back();
            i++;
            if (manageFamilyPage.isMyAccountTextDisplayed()) {
                break;
            } else {
                if (i == 2) {
                    break;
                }
            }
        }
    }

    public void verifyInsuranceNudgeAndClickAddInsurance(String type, String patientName) {
        Object insuranceNudgeTitle = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen","insuranceNudgeDFDScreen", "nudgeTitle");
        Object insuranceNudgeDesc = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen","insuranceNudgeDFDScreen", "nudgeDescription");
        if(type.equalsIgnoreCase("Self"))
            Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeTitle(), insuranceNudgeTitle, "Insurance Nudge Title is Incorrect");
        else
            Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeTitleForDependent(patientName), insuranceNudgeTitle.toString().replace("your", patientName + "'s"), "Insurance Nudge Title is Incorrect");

        Assert.assertEquals(pharmacyDashboardPage.getInsuranceNudgeDescription(), insuranceNudgeDesc, "Insurance Nudge Description Text is Incorrect");
        //Assert.assertTrue(pharmacyDashboardPage.isDismissInsuranceNudgeCTADisplayed());
        pharmacyDashboardPage.clickAddInsuranceCTA();
    }

    public void checkCompetitiveTransferSuccess(String patientName) {
        // Wait for page to reflect - The locators are same for headers on success and review transfer, unexpected element is returned.
        am.performSleep(5);
        Object orderSuccessPageHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageHeader");
        Object orderSuccessPageSubHeader = textValidationUtils.getKeyInObject("competitiveTransfer", "transferSuccessPage", "transferSuccessPageSubHeader");
        Object ctTrackerCardHeading = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "competitiveTransferTrackerCard", "competitiveTransferCardHeading");
        Assert.assertEquals(transferRequestSuccessPage.getTransferRequestSuccessHeading(), orderSuccessPageHeader.toString(), "Ct Transfer Success Page Heading Mismatch");
        Assert.assertEquals(transferRequestSuccessPage.getPharmacistWillContactSubheading(), orderSuccessPageSubHeader, "Ct Transfer Success Page Subheading Mismatch");
        transferRequestSuccessPage.clickBackToPharmacyButton();
        Assert.assertEquals(competitiveTransferTrackerCardPage.getCtCardHeaderText(), ctTrackerCardHeading.toString(), "Card Header Text Mismatch");
        Assert.assertEquals(competitiveTransferTrackerCardPage.getUserNameText().toLowerCase(), patientName.toLowerCase(), "Patient UserName Incorrect");
    }

    public void proceedToPharmacyDashboardWithoutPinValidation() {
    }

    public void forceNavigateToCartPage() {
        // This method is only for Web
        ecommCartPage.navigateToPage(prop.getProperty("web.cart.url"));
    }

    public void validateAddedInsuranceDetails(String memberId, String bin, String pcn) {
        manageInsurancePage.clickExpandInsurance();
        Assert.assertTrue(manageInsurancePage.getMemberIdText().contains(memberId), "Added Insurance member Id is incorrect");
        Assert.assertEquals(manageInsurancePage.getBinText().toLowerCase(), ("rxbin: " + bin.toLowerCase()), "Added Insurance bin is incorrect");
        Assert.assertEquals(manageInsurancePage.getPCNTest().toLowerCase(), ("rxpcn: " + pcn.toLowerCase()), "Added Insurance pcn is incorrect");

    }


    public void scrollToFindWalmartPrescriptionsModule() {
        pharmacyDashboardPage.scrollToTextWithLoop("Find Walmart prescriptions");
    }

    public void clickOnManageFamilyCTA() {
       pharmacyDashboardPage.clickOnManageFamilyCTA();
    }

    public void validateMultipleProfile(String otp) {
        Object multipleProfilesFoundAlertText = textValidationUtils.getKeyInObject("smsAccountCreation", "smsAccountCreationFlow", "multipleProfilesPageAlertHeader");
        connectMyAccount.sendOTP(otp);
        connectMyAccount.clickOtpAcceptCTA();
        connectMyAccount.scrollUp();
        Assert.assertTrue(connectMyAccount.primaryProfileHeader.isDisplayed());
        Assert.assertTrue(connectMyAccount.connectedProfileList().size()>1,"Multiple profiles are not connected to the phone number");
        Assert.assertTrue(connectMyAccount.isAnyProfileEnabledinWeb(),"Profiles should not be selected by default");
        connectMyAccount.clickContinueForProfileCTA();
        Assert.assertEquals(connectMyAccount.selectProfileAlertText(),multipleProfilesFoundAlertText,"Alert message mismatch");
        connectMyAccount.selectProfileFromList();
        connectMyAccount.clickContinueForProfileCTA();
        Assert.assertTrue(connectMyAccount.dobPageHeader.isDisplayed(),"DOB page is not displayed");
    }

    public void proceedToTransferPrescriptionSection() {
        pharmacyDashboardPage.clickTransferPrescriptionsTab();
        pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
        pharmacyDashboardPage.clickTransferSourceContinueButton();
    }
    public void navigateToRefillPrescriptions() {
        pharmacyDashboardPage.clickRefillPrescriptions();
    }

}