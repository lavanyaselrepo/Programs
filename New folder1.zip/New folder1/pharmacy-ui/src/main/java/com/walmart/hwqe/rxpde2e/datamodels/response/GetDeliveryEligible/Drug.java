package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;
@lombok.Getter
@lombok.Setter
public class Drug {
    public String name;
    public String ndcNumber;
}
