package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompleteStagingRequest {
    private String packageToteId;
    private int stagingBagNumber;
    private List<fillAndReleaseBagInfoList> fillAndReleaseBagInfo;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class fillAndReleaseBagInfoList {
        private int bagNumber;
        private List<String> fills;
    }
}
