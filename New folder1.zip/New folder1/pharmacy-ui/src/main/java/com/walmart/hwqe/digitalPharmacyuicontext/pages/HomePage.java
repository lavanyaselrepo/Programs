package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class HomePage extends MobileBasePage {

    RemoteWebDriver driver;

    @AndroidFindBy(accessibility = "Services")
    @iOSXCUITFindBy(accessibility = "Services")
    @FindBy(xpath = "(//*[contains(text(), 'Services')])[1]")
    public WebElement servicesButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/icon_close")
    @iOSXCUITFindBy(accessibility = "cta.continue")
    @FindBy(xpath = "//button[contains(text(), 'Accept all')]")
    public WebElement personalisationPermissionButton;

    @iOSXCUITFindBy(accessibility = "Close Walmart plus promotional pop up")
    public WebElement closeWalmartPlusBottomSheetButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/close_button")
    @iOSXCUITFindBy(accessibility = "OneFinanceSplashView.closeButton")
    public WebElement closeJoinOneProgramButton;

    @iOSXCUITFindBy(accessibility = "SparkyCalloutModalView.closeButton")
    public WebElement closeSparkyPopUpButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/onefinance_splash_bottom_sheet_container")
    public WebElement closeOneFinanceProgramBottomSheet;

    @FindBy(xpath = "//button[@aria-label='Close Walmart plus promotional pop up']")
    @iOSXCUITFindBy(accessibility = "Close Walmart plus promotional pop up")
    @AndroidFindBy(accessibility = "close walmart plus promotional pop up")
    public WebElement closeWalmartPlusProgramButton;

    @FindBy(xpath = "//button[@aria-label='Close dialog']")
    @iOSXCUITFindBy(accessibility = "TODO")
    @AndroidFindBy(accessibility = "TODO")
    public WebElement closeWalmartPlusTravelProgramButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/close_button")
    @iOSXCUITFindBy(accessibility = "OneFinanceSplashView.closeButton")
    public WebElement closeOnePayCheckout;

    @AndroidFindBy(id = "com.walmart.android.debug:id/permissions_cancel_button")
    @iOSXCUITFindBy(xpath = "///XCUIElementTypeButton[@name='Close']")
    public WebElement closeProductUpdateNotification;

    @AndroidFindBy(id = "com.walmart.android.debug:id/membership_bottom_sheet_close_button")
    public WebElement closeViewCartItems;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Ask App Not to Track']")
    public WebElement askAppNotToTrackButton;

    public HomePage(RemoteWebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    public void clickServicesButton() {
        click(servicesButton, 5);
    }

    public void clickPersonalisationChoiceButton() {
        unblockingClick(personalisationPermissionButton, 4, "Personalization Choice Button");
    }
    public void closeWalmartPlusProgramButton() {

        unblockingClick(closeWalmartPlusBottomSheetButton, 4,"Walmart+ promotional bottom sheet close button");
        Reporter.log("Closed Walmart+ promotional bottom sheet via close button");
    }

    public void clickCloseJoinOneProgramButton() {
        unblockingClick(closeJoinOneProgramButton, 4, "Dismiss Join One Program Pop-up");
    }

    public void clickCloseSparkyPopUp() {
        unblockingClick(closeSparkyPopUpButton, 5, "Dismiss Sparky pop up");
    }

    public void clickWalmartPlusProgramButton() {
        unblockingClick(closeWalmartPlusProgramButton, 7, "Dismiss Walmart Plus Program Pop up");
    }

    public void closeProductUpdateNotification() {
        try{
            if(isElementDisplayed(closeProductUpdateNotification)){
                click(closeProductUpdateNotification);
            }
        }catch (Exception e){
            System.out.println("Product Update Notification Close Icon Not Clicked");
            e.printStackTrace();
        }
    }

    public void closeOnePayVisaCheckout() {
        unblockingClick(closeOnePayCheckout, 4, "Dismiss One Pay Checkout Popup");
    }

    public void dismissAppTrackingPermissionIfPresent() {
        unblockingClick(askAppNotToTrackButton, 3, "Dismiss App Tracking Transparency permission");
    }

    public void navigateToPharmacyDashboardPage(){
        driver.navigate().to(prop.getProperty("web.rxpd_base_url"));
    }

    public void navigateToOrdersPage(){
        driver.navigate().to(prop.getProperty("web.rxpd_orders_url"));
    }

    public void clickWalmartPlusTravelProgramButton() {
       try{
                if(isElementDisplayed(closeWalmartPlusTravelProgramButton)) {
                    click(closeWalmartPlusTravelProgramButton);
                }
            }catch (Exception e){
                System.out.println("WalmartPlus travel program close button Not Clicked");
                e.printStackTrace();
            }
        }

    public void closeViewCartItems() {
        try {
            if(isElementDisplayed(closeViewCartItems)){
                click(closeViewCartItems);
            }
        } catch (Exception e){
            System.out.println("One Pay Visa Checkout Not Clicked");
            e.printStackTrace();
        }
    }

    public boolean isOneFinanceBottomSheetDisplayed() {
        // Need to close this sheet if it is displayed
        return isElementDisplayed(closeOneFinanceProgramBottomSheet, 3);
    }
}
