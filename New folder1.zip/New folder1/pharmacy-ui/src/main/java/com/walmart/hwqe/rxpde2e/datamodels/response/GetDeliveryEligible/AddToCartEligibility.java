package com.walmart.hwqe.rxpde2e.datamodels.response.GetDeliveryEligible;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class AddToCartEligibility {
    public boolean eligible;
    public ArrayList<Object> ineligibilityReason;
}
