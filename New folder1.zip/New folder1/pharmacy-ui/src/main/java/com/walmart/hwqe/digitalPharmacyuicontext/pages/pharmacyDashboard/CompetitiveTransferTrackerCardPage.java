package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.PharmacyDashboardPage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class CompetitiveTransferTrackerCardPage extends PharmacyDashboardPage {
    @FindBy(xpath = "//div[@class='pa3']/h2")
    @iOSXCUITFindBy(accessibility = "FillSectionHeaderView.headerLabel")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/header_title\").instance(0)")
    public WebElement ctCardHeader;

    @FindBy(xpath = "//*[@class='ld ld-User mr1']/following-sibling::span")
    @iOSXCUITFindBy(accessibility = "HWImageWithLabelView.label")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.walmart.android.debug:id/patient_name\").instance(0)")
    public WebElement userNameText;

    @FindBy(xpath = "//button[text()='Transfer Details']")
    @iOSXCUITFindBy(accessibility = "Transfer details")
    @AndroidFindBy(id = "com.walmart.android.debug:id/transfer_details_button")
    public WebElement transferDetailsButton;

    public CompetitiveTransferTrackerCardPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getCtCardHeaderText() {
        return getText(ctCardHeader);
    }

    public String getUserNameText() {
        return getText(userNameText);
    }

    public void clickTransferDetailsButton() {
        click(transferDetailsButton);
    }
}