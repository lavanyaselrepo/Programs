package com.walmart.hwqe.digitalPharmacyuicontext.pages;


import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ScanToRefillPage extends MobileBasePage {

    @AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_foreground_only_button")
    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.primaryActionButton")
    public WebElement allowTakePicturesAndRecordAudio;

    @iOSXCUITFindBy(accessibility = "PermissionPromptViewController.secondaryActionButton")
    public WebElement noThanks;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Enter prescription details manually']")
    @iOSXCUITFindBy(accessibility = "Enter manually")
    public WebElement enterRxManually;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Prescription number (7-digits)*, Prescription number (7-digits)*']/android.widget.FrameLayout/android.widget.EditText") 
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Prescription number* (7 digits)']")
    @FindBy(xpath = "(//input[@type='text'])[1]")
    public WebElement inputRxNumber;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Store number (up to 4-digits)*, Store number (up to 4-digits)*']/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Store number* (up to 5 digits)']")
    @FindBy(xpath = "//span[contains(text(),'Store number')]/parent::label/parent::div/div/input")
    public WebElement inputStoreNumber;

    @FindBy(xpath = "//button[contains(text(),'Add')]")
    public WebElement addPrescription;

    @FindBy(xpath = "//button[text()='Add prescription']")
    public WebElement confirmAddedPrescription;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Date of birth (mm/dd/yyyy)*, Date of birth (mm/dd/yyyy)*\"]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@label='Date of birth* (mm/dd/yyyy)']")
    @FindBy(xpath = "//span[contains(text(),'date of birth')]/parent::label/parent::div/div/input")
    public WebElement inputDOB;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/continue_btn']")
    // iOS: name attribute set by app as RxDetailsController.LinkActionView.cta (executed on iOS)
    @iOSXCUITFindBy(accessibility = "RxDetailsController.LinkActionView.cta")
    public WebElement continueButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Continue']")
    public WebElement refillingForSomeoneElseContinueButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/keypadNum1")
    public WebElement pinInput;

    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.android.debug:id/continue_button']")
    @iOSXCUITFindBy(accessibility = "ScannedPrescriptionListController.LinkActionView.cta")
    @FindBy(xpath = "//button[text()='Continue']")
    public WebElement confirmRefillContinueButton;

    @iOSXCUITFindBy(accessibility = "Done")
    public WebElement keyboardDoneButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/scan_another_prescription")
    @iOSXCUITFindBy(accessibility = "Add another prescription")
    @FindBy(xpath = "//button[text()='Add a prescription']")
    public WebElement scanAnotherRxButton;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Change store']")
    // iOS: accessibility identifier set by app as RefillRequestReviewStoreInfoView.changeStoreButton (executed on iOS)
    @iOSXCUITFindBy(accessibility = "RefillRequestReviewStoreInfoView.changeStoreButton")
    public WebElement changeStoreButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/place_order")
    // iOS: accessibility identifier set by app as HWPrimaryAndLinkButtonWithInfoView.primaryActionButton (executed on iOS)
    @iOSXCUITFindBy(accessibility = "HWPrimaryAndLinkButtonWithInfoView.primaryActionButton")
    public WebElement requestRefillButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_order_confirmation_header")
    @iOSXCUITFindBy(accessibility = "Your refill request has been placed.")
    public WebElement refillConfirmationHeader;

    @AndroidFindBy(id = "com.walmart.android.debug:id/pharmacy_go_to_pharmacy_button")
    @iOSXCUITFindBy(accessibility = "Back to pharmacy")
    public WebElement backToPharmacyButton;

    public ScanToRefillPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickAllowTakePicturesAndRecordAudio(){
        if (isElementDisplayed(allowTakePicturesAndRecordAudio, 5)) {
            click(allowTakePicturesAndRecordAudio);
            // Handle potential "No Thanks" dialog on iOS
            if (isElementDisplayed(noThanks, 5)) {
                click(noThanks);
            }
            Reporter.log("Camera permission dialog found — granted access");
        } else {
            Reporter.log("Camera permission already granted — skipping dialog");
        }
    }

    public void clickEnterRxManually(){
            click(enterRxManually);
    }

    public void enterRxNumber(String rxNb) {
        webWait.until(ExpectedConditions.elementToBeClickable(this.inputRxNumber));
        sendText(inputRxNumber, rxNb);
    }

    public void enterStoreNumber(String storeNb) {
        webWait.until(ExpectedConditions.elementToBeClickable(this.inputStoreNumber));
        sendText(inputStoreNumber, storeNb);
    }

    public void enterDOB(String dob) {
        webWait.until(ExpectedConditions.elementToBeClickable(this.inputDOB));
        sendDateField(inputDOB, dob);
    }

    public void clickContinueButton(){
        click(continueButton);
    }

    public void enterPin() {
        for (int i = 1; i < 5; i++)
            click(pinInput);
    }

    public void clickConfirmRefillContinueButton(){
        webWait.until(ExpectedConditions.elementToBeClickable(this.confirmRefillContinueButton));
        click(confirmRefillContinueButton);
    }

    public void clickRefillingForSomeoneElseContinueButton(){
        System.out.println("was refilling for someone else");
        click(refillingForSomeoneElseContinueButton);
    }

    public void hideKeyboard(){
        click(keyboardDoneButton);
    }

    public void clickAddPrescription(){
        click(addPrescription);
    }

    public void clickConfirmAddedPrescription(){
        click(confirmAddedPrescription);
    }

    public String getScanAnotherRxButtonText(){
        return getText(scanAnotherRxButton);
    }

    public void clickChangeStoreButton() {
        click(changeStoreButton);
    }

    public void clickRequestRefillButton() {
        click(requestRefillButton);
    }

    public String getRefillConfirmationHeaderText() {
        return getText(refillConfirmationHeader);
    }

    public void clickBackToPharmacyButton() {
        webWait.until(ExpectedConditions.elementToBeClickable(backToPharmacyButton));
        click(backToPharmacyButton);
    }
}
