package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Page Object for the Text Notifications enrollment flow:
 *   - Enroll phone number screen
 *   - OTP verification screen
 *   - Dependent selection screen
 * Android and iOS locators are MCP-verified.
 */
public class TextNotificationsEnrollmentPage extends MobileBasePage {

    // ----- Enrollment screen: Toolbar / Nav bar -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/platform_sdk_toolbar_title")
    @iOSXCUITFindBy(accessibility = "Text Notifications")
    public WebElement toolbarTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/closeButton")
    @iOSXCUITFindBy(accessibility = "SMSEnrollmentViewController.Close")
    public WebElement closeButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/enroll_phone_number_title")
    @iOSXCUITFindBy(accessibility = "SMSEnrollmentView.titleLabel")
    public WebElement enrollPhoneTitle;

    @AndroidFindBy(id = "com.walmart.android.debug:id/enroll_phone_number_description")
    @iOSXCUITFindBy(accessibility = "SMSEnrollmentView.descriptionLabel")
    public WebElement enrollPhoneDescription;

    @AndroidFindBy(id = "com.walmart.android.debug:id/label_required")
    @iOSXCUITFindBy(accessibility = "SMSEnrollmentView.requiredFieldsLabel")
    public WebElement requiredFieldsLabel;

    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.android.debug:id/mobile_number_field']//android.widget.EditText")
    @iOSXCUITFindBy(accessibility = "TextFieldStackView.textField")
    public WebElement mobileNumberInput;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND label == 'Enroll'")
    public WebElement enrollButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/tertiary_button")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND label == 'Cancel'")
    public WebElement cancelButton;

    // ----- OTP verification screen -----
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_enter_verification_code_description")
    @iOSXCUITFindBy(accessibility = "ValidateOTPView.messageLabel")
    public WebElement otpScreenDescription;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 1. On entering code in the input fields, the focus will automatically move on to the next input fields']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-0")
    public WebElement otpDigit1;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 2']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-1")
    public WebElement otpDigit2;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 3']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-2")
    public WebElement otpDigit3;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 4']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-3")
    public WebElement otpDigit4;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 5']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-4")
    public WebElement otpDigit5;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Digit 6']")
    @iOSXCUITFindBy(accessibility = "OTPTextField.otpCell-5")
    public WebElement otpDigit6;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_otp_send_another_code")
    @iOSXCUITFindBy(accessibility = "ValidateOTPView.getAnotherCodeButton")
    public WebElement getAnotherCodeButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "ValidateOTPView.ctaButton")
    public WebElement verifyCodeButton;

    // ----- Dependent selection screen -----
    // iOS: accessibility ID with angle-bracket characters can be unreliable; use XPath instead.
    @AndroidFindBy(id = "com.walmart.android.debug:id/dependents_list")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable[@name='HWCheckBoxListView<SMSEnrollmentPatientCell>.tableView']")
    public WebElement dependentSelectionList;

    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND label == 'Enroll'")
    public WebElement dependentSelectionSaveButton;

    public TextNotificationsEnrollmentPage(RemoteWebDriver driver) {
        super(driver);
    }

    public boolean isEnrollmentScreenDisplayed() {
        return isElementDisplayed(enrollPhoneTitle, 10);
    }

    public boolean isOtpScreenDisplayed() {
        return isElementDisplayed(otpScreenDescription, 10);
    }

    public boolean isDependentSelectionScreenDisplayed() {
        return isElementDisplayed(dependentSelectionList, 10);
    }

    public String getToolbarTitleText() {
        if (isIOS()) {
            // On iOS, element.getText() returns "" for StaticText inside a NavigationBar.
            // WDA may return null for label/value; fall back through label → value → name.
            try {
                isElementDisplayed(toolbarTitle, 5);
                String label = toolbarTitle.getAttribute("label");
                if (label != null && !label.isEmpty()) return label;
                String value = toolbarTitle.getAttribute("value");
                if (value != null && !value.isEmpty()) return value;
                String name = toolbarTitle.getAttribute("name");
                return name != null ? name : "";
            } catch (Exception e) {
                Reporter.log("Could not get toolbar title text: " + e.getMessage());
                return "";
            }
        }
        return getText(toolbarTitle);
    }

    public String getEnrollPhoneTitleText() {
        return getText(enrollPhoneTitle);
    }

    public String getEnrollPhoneDescriptionText() {
        return getText(enrollPhoneDescription);
    }

    public String getRequiredFieldsLabelText() {
        return getText(requiredFieldsLabel);
    }

    /** Enters the phone number into the Mobile Number input field and dismisses the keyboard. */
    public void enterPhoneNumber(String phoneNumber) {
        click(mobileNumberInput, 5);
        sendText(mobileNumberInput, phoneNumber, 5);
        hideKeyboard();
        Reporter.log("Entered phone number: " + phoneNumber);
    }

    /** Taps the Enroll button to submit the phone number and trigger OTP. */
    public void tapEnroll() {
        click(enrollButton, 5);
        Reporter.log("Tapped Enroll button");
    }

    /**
     * Enters the 6-digit OTP.
     * On iOS, enters each digit individually (auto-advance per cell).
     * On Android, types into the first digit cell (auto-advance through all cells).
     */
    public void enterOtp(String otp) {
        if (!isElementDisplayed(otpDigit1, 10)) {
            throw new RuntimeException("OTP digit 1 input field not visible");
        }
        if (isIOS()) {
            WebElement[] cells = {otpDigit1, otpDigit2, otpDigit3, otpDigit4, otpDigit5, otpDigit6};
            for (int i = 0; i < otp.length() && i < cells.length; i++) {
                sendText(cells[i], String.valueOf(otp.charAt(i)), 3);
            }
        } else {
            click(otpDigit1, 3);
            sendText(otpDigit1, otp, 5);
        }
        Reporter.log("Entered OTP: " + otp);
    }

    /** Taps Verify code button. */
    public void tapVerifyCode() {
        click(verifyCodeButton, 5);
        Reporter.log("Tapped Verify code button");
    }

    /** Selects a dependent by first name from the dependent selection list. */
    public void selectDependentByName(String firstName) {
        WebElement dependent;
        if (isIOS()) {
            dependent = remoteDriver.findElement(
                    org.openqa.selenium.By.xpath(
                            "//XCUIElementTypeCell[@name='HWCheckBoxListCell' and contains(@label,'" + firstName + "')]")
            );
        } else {
            dependent = remoteDriver.findElement(
                    org.openqa.selenium.By.xpath(
                            "//android.widget.CheckBox[@resource-id='com.walmart.android.debug:id/dependent_checkbox' and contains(@text, '" + firstName + "')]")
            );
        }
        click(dependent, 5);
        Reporter.log("Selected dependent: " + firstName);
    }

    /** Taps the Enroll button on the dependent selection screen to complete enrollment. */
    public void tapSaveOnDependentSelection() {
        click(dependentSelectionSaveButton, 5);
        Reporter.log("Tapped Enroll on dependent selection");
    }

    /** Returns true if a dependent with the given first name is shown in the list. */
    public boolean isDependentDisplayed(String firstName) {
        try {
            if (isIOS()) {
                return !remoteDriver.findElements(
                        org.openqa.selenium.By.xpath(
                                "//XCUIElementTypeCell[@name='HWCheckBoxListCell' and contains(@label,'" + firstName + "')]")
                ).isEmpty();
            }
            return !remoteDriver.findElements(
                    org.openqa.selenium.By.xpath(
                            "//android.widget.CheckBox[@resource-id='com.walmart.android.debug:id/dependent_checkbox' and contains(@text,'" + firstName + "')]")
            ).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /** Returns true if a dependent with the given first name is NOT in the list (already enrolled). */
    public boolean isDependentNotDisplayed(String firstName) {
        return !isDependentDisplayed(firstName);
    }
}
