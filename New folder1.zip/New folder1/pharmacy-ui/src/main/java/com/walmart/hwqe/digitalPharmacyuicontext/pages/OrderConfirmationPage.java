package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class OrderConfirmationPage extends MobileBasePage {
    @FindBy(xpath = "//*[contains(text(), 'Order #')]")
    @iOSXCUITFindBy(accessibility = "EmailView.orderNumberLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_order_number_textview")
    public WebElement orderNumberText;

    @iOSXCUITFindBy(accessibility = "OrderConfirmationView.orderConfirmLabel")
    @FindBy(xpath = "//*[contains(text(), 'your order is confirmed.')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/checkout_thankyou_consolidated_textview")
    public WebElement orderIsConfirmedHeaderText;

    @FindBy(xpath = "//a[text()='View Details']")
    @iOSXCUITFindBy(accessibility = "View Details")
    @AndroidFindBy(id = "com.walmart.android.debug:id/view_details_cta")
    public WebElement viewDetailsButton;

    @FindBy(xpath = "(//button[text()='View details'])[1]")
    public WebElement firstOrderViewDetails;

    @iOSXCUITFindBy(accessibility = "Not Now")
    @FindBy(xpath = "//*[text()='Not Right Now']")
    public WebElement declineFeedbackButton;

    @FindBy(xpath = "//div[text()='Account']")
    public WebElement accountCta;

    @FindBy(xpath = "//a[@link-identifier='Purchase History']")
    public WebElement purchaseHistoryCta;

    public OrderConfirmationPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getOrderNumberText() {
        return getText(orderNumberText);
    }

    public String getOrderNumber() {
        return getOrderNumberText().split("#")[1];
    }

    public String getOrderIsConfirmedHeaderText() {
        return getText(orderIsConfirmedHeaderText, "Header Text for Order Confirmation", 20);
    }

    public void clickViewDetailsButton() {
        if (remoteDriver instanceof IOSDriver || remoteDriver instanceof AndroidDriver) {
            mobileScrollToText("Rewards debit card", "up");
            click(viewDetailsButton, 5);
        } else if (remoteDriver instanceof WebDriver) {
            scrollToElement(viewDetailsButton);
            performSleep(4);
            try {
                Reporter.log("Checking for Feedback Pop-up interruption");
                if (isElementDisplayed(remoteDriver.findElement(By.id("kampyleInvite")))) {
                    remoteDriver.switchTo().frame(remoteDriver.findElement(By.id("kampyleInvite")));
                    clickDeclineFeedBackButton();
                    remoteDriver.switchTo().defaultContent();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void clickDeclineFeedBackButton(){ unblockingClick(declineFeedbackButton, 10, "Decline FeedBack For Order Process");}
    public void clickAccountCta() {click(accountCta);}
    public void clickPurchaseHistoryCta() {click(purchaseHistoryCta);}
    public void clickFirstOrderViewDetails(){ click(firstOrderViewDetails);}
}
