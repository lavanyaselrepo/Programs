package com.walmart.hwqe.rxpde2e.datamodels.response.ConnexusPatientDataResponse;

@lombok.Getter
@lombok.Setter
public class ConnexusPatientDataResponse {
    public int patientId;
    public int siteId;
    public String firstName;
    public String lastName;
    public String dob;
    public String homePhone;
    public String workPhone;
    public String cellPhone;
    public String inputDob;
    public String cnxUser;
    public boolean patientHasInsurance;
}
