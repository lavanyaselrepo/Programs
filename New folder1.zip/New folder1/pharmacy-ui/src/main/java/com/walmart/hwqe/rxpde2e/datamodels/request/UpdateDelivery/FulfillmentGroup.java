package com.walmart.hwqe.rxpde2e.datamodels.request.UpdateDelivery;

@lombok.Getter
@lombok.Setter
public class FulfillmentGroup {
    public String orderType;
    public String status;
}
