package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class OrderDetailsPage extends MobileBasePage {
    @FindBy(xpath = "//button[text()='Cancel order']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Cancel order']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/cancel_cta")
    public WebElement cancelOrderButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Used the wrong payment method.']")
    @FindBy(xpath = "//*[contains(text(), 'Used the wrong payment method')]//preceding-sibling::input")
    @AndroidFindBy(xpath = "//android.widget.RadioButton[@resource-id='com.walmart.android.debug:id/radiobutton_cancellation_reason' and @text='Used the wrong payment method.']")
    public WebElement wrongPaymentMethodCancellationReason;

    @iOSXCUITFindBy(accessibility = "CancellationCTAView_cta_button")
    @FindBy(xpath = "//button[text()='Confirm cancellation']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/cancellation_reason_action_button")
    public WebElement confirmCancellationButton;

    @FindBy(xpath = "//h2[text()='Cancellation requested today']")
    public WebElement cancellationRequestHeaderText;

    @FindBy(xpath = "//*[@data-testid='order-banner-message']/div/div/div/span/span")
    @iOSXCUITFindBy(accessibility = "LDAlert.messageLabel")
    @AndroidFindBy(id = "com.walmart.android.debug:id/text")
    public WebElement orderCanceledBannerText;

    public OrderDetailsPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickCancelOrderButton() {
        if(remoteDriver instanceof IOSDriver) {
            mobileScrollToText("Cancel order", "up");
            performSleep(2);
        } else if (remoteDriver instanceof AndroidDriver) {
            int i = 0;
            while(i < 20) {
                this.mobileSwipe("up");
                i++;
            }
        }
        click(cancelOrderButton);
    }

    public void clickWrongPaymentMethodCancellationReason() {
        click(wrongPaymentMethodCancellationReason);
    }

    public void clickConfirmCancellationButton() {
        click(confirmCancellationButton);
    }

    public String getCancellationRequestHeaderText() {
        return getText(cancellationRequestHeaderText);
    }

    public String getOrderCanceledBannerText(){
        return getText(orderCanceledBannerText);
    }
}
