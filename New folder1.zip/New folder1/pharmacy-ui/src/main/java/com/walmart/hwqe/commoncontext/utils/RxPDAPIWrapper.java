package com.walmart.hwqe.commoncontext.utils;

import com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.assignAndFetchStagingInfo.assignAndFetchStagedIssueInfoPOJO.AssignAndFetchStagedIssueInfoRequestPayload;
import com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.assignAndFetchStagingInfo.assignAndFetchStagingInfoRequest;
import com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.chainOfCustody.ChainOfCustodyStartRequestPayload;
import com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.handover.DriverReturnHandoverInfoRequest;
import com.walmart.hwqe.commoncontext.rxpd.fulfillment.rxone.handover.HandoverInfoRequest;
import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import org.json.JSONObject;
import java.util.HashMap;

public class RxPDAPIWrapper {
    AutomationManager am = AutomationManager.getInstance();
    ServiceRequest request = new ServiceRequest();
    PropertyReader propertyReader = PropertyReaderHelper.getInstance();
   // RxPDCommon rxPDCommon = new RxPDCommon();

    public RxPDAPIWrapper() {
        // Properties auto-loaded by PropertyReaderHelper static initializer
        this.storeNumber = propertyReader.getProperty("rxonemobileapp.store_nbr");
        this.userID = propertyReader.getProperty("rxonemobileapp.user_id");
    }
    String storeNumber;
    String userID;

    private HashMap<String, String> getHeaderForOrderInfoList() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Authorization", propertyReader.getProperty("RxPDMobileApp.Authorization"));
        headers.put("Source", "RXPDAPP");
        headers.put("StoreNumber",storeNumber);
        headers.put("UserId",userID );
        headers.put("DeviceName", propertyReader.getProperty("rxonemobileapp.api.DeviceName"));
        return headers;
    }

    public String getStagingStagingIssuesDeliveryIssuesParam(String param){
        param = param.toLowerCase();
        String queryParam;
        switch (param){
            case "s":
                queryParam = propertyReader.getProperty("RxPDMobileApp.api.StagingParam");
                break;
            case "si":
                queryParam = propertyReader.getProperty("RxPDMobileApp.api.StagedIssuesParam");
                break;
            case "di":
                queryParam = propertyReader.getProperty("RxPDMobileApp.api.DeliveryIssuesParam");
                break;
            default:
                queryParam = "Not proper parameter provided";
        }
        return queryParam;
    }

    public HashMap<String, String> getParamsForOrderInfoList(String paramSymbol) {
        HashMap<String, String> params = new HashMap<>();
        params.put("type",getStagingStagingIssuesDeliveryIssuesParam(paramSymbol));
        return params;
    }

    public ServiceResponse getOrderInfoList(String param){
        Reporter.log("creating request");
        String url= propertyReader.getProperty("RxPDMobileApp.api.OrderInfoList").replace("xxxx",storeNumber);
        request.setUrl(url,getParamsForOrderInfoList(param));
        request.setHeaders(getHeaderForOrderInfoList());
        return am.getRestContext().performGet(request);
    }

    public ServiceResponse getAnFStagingInfo(String purchaseId){
        Reporter.log("creating request");
        request.setUrl(propertyReader.getProperty("RxPDMobileApp.api.AssignAndFetchStagingInfo"));
        request.setHeaders(getHeaderForOrderInfoList());
        assignAndFetchStagingInfoRequest getAnFStagingOrderInfoReq =new assignAndFetchStagingInfoRequest();
        getAnFStagingOrderInfoReq.setPurchaseOrderId(purchaseId);
        getAnFStagingOrderInfoReq.setOverride(false);

        request.setRequestPayload(getAnFStagingOrderInfoReq);
        return am.getRestContext().performPost(request);
    }

    public ServiceResponse getAssignAndFetchStagedIssueInfo(String purchaseId){
        Reporter.log("creating request");
        request.setUrl(propertyReader.getProperty("RxPDMobileApp.api.AssignAndFetchStagedIssueInfo"));
        request.setHeaders(getHeaderChainOfCustodyStart());
        AssignAndFetchStagedIssueInfoRequestPayload requestPayload =new AssignAndFetchStagedIssueInfoRequestPayload();
        requestPayload.setPurchaseOrderId(purchaseId);
        request.setRequestPayload(requestPayload);
        return am.getRestContext().performPost(request);
    }

    public HashMap<String, String> getHeaderChainOfCustodyStart(){
        HashMap<String, String> headers = new HashMap<>();
        headers.put("StoreNumber",storeNumber);
        headers.put("UserId",userID);
        headers.put("x-hnw-rx-req-track-id",propertyReader.getProperty("RxPDMobileApp.api.x-hnw-rx-req-track-id"));
        headers.put("Source",propertyReader.getProperty("RxPDMobileApp.api.Source"));
        headers.put("DeviceName",propertyReader.getProperty("rxonemobileapp.api.DeviceName"));
        headers.put("content-type", "application/json");
        headers.put("Authorization", propertyReader.getProperty("RxPDMobileApp.Authorization"));
        return headers;
    }
    public ServiceResponse getFillAndBagInfo(Integer OTP, String omsOrderId, Integer transType){
        request.setUrl(propertyReader.getProperty("RxPDMobileApp.api.ChainOfCustodyStart").replace("xxxx", storeNumber));
        request.setHeaders(getHeaderChainOfCustodyStart());
        ChainOfCustodyStartRequestPayload payload = new ChainOfCustodyStartRequestPayload();
        payload.setOneTimePasscode(OTP);
        payload.setOmsOrderId(omsOrderId);
        payload.setTransType(transType);
        request.setRequestPayload(payload);
        return am.getRestContext().performPost(request);
    }

    public ServiceResponse getAnFHandoverInfo(String omsOrderId){
        Reporter.log("creating request");
        request.setUrl(propertyReader.getProperty("RxPDMobileApp.api.AssignAndFetchHandoverInfo").replace("xxxx", storeNumber));
        request.setHeaders(getHeaderChainOfCustodyStart());
        HandoverInfoRequest getAnFHandoverReq =new HandoverInfoRequest();
        getAnFHandoverReq.setOmsOrderId(omsOrderId);
        getAnFHandoverReq.setTransType(2);
        request.setRequestPayload(getAnFHandoverReq);
        return am.getRestContext().performPost(request);
    }

    public ServiceResponse getDriverReturnHandoverInfo(String otp){
        Reporter.log("creating request");
        request.setUrl(propertyReader.getProperty("RxPDMobileApp.api.AssignAndFetchHandoverInfo").replace("xxxx", storeNumber));
        request.setHeaders(getHeaderChainOfCustodyStart());
        DriverReturnHandoverInfoRequest getDriverReturnHandoverInfo =new DriverReturnHandoverInfoRequest();
        getDriverReturnHandoverInfo.setOneTimePasscode(otp);
        getDriverReturnHandoverInfo.setTransType(2);
        request.setRequestPayload(getDriverReturnHandoverInfo);
        return am.getRestContext().performPost(request);
    }

    public String getStoreSpecificUri(String baseUrl, int storeNumber){
        String site = ""+storeNumber;
        if(site.length()==4)
            site = "0"+site;
        baseUrl = baseUrl.replace("xxxxx", site);
        return baseUrl;
    }

    // Overridden methods for reuse

    private HashMap<String, String> getHeaderForOrderInfoList(int storeNumber) {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Authorization", propertyReader.getProperty("RxPDMobileApp.Authorization"));
        headers.put("Source", "RXPDAPP");
        headers.put("StoreNumber", storeNumber+"");
        headers.put("UserId",userID );
        headers.put("DeviceName", propertyReader.getProperty("rxonemobileapp.api.DeviceName"));
        return headers;
    }

    public ServiceResponse getAnFStagingInfo(int storeNumber, String purchaseId){
        request.setUrl(getStoreSpecificUri(propertyReader.getProperty("assignAndFetchStagingInfo.api.uri"), storeNumber));
        request.setHeaders(getHeaderForOrderInfoList(storeNumber));
        assignAndFetchStagingInfoRequest getAnFStagingOrderInfoReq = new assignAndFetchStagingInfoRequest();
        getAnFStagingOrderInfoReq.setPurchaseOrderId(purchaseId);
        getAnFStagingOrderInfoReq.setOverride(false);
        request.setRequestPayload(getAnFStagingOrderInfoReq);
        Reporter.logJSON("Assign And Fetch Info API Request Payload: ", request.getRequestPayload());
        ServiceResponse response = am.getRestContext().performPost(request);
        Reporter.logJSON("Assign And Fetch Info API Response Payload: ", response.getDataResponse());
        return response;
    }

    public ServiceResponse getAnFStagedIssue(int storeNumber, String purchaseId){
        request.setUrl(getStoreSpecificUri(propertyReader.getProperty("assignAndFetchStagedIssue.api.uri"), storeNumber));
        request.setHeaders(getHeaderForOrderInfoList(storeNumber));
        JSONObject reqBody = new JSONObject();
        reqBody.put("purchaseOrderId", purchaseId);
        request.setRequestPayload(reqBody.toString());
        Reporter.logJSON("Assign And Fetch Stage Issue Info API Request Payload: ", request.getRequestPayload());
        ServiceResponse response = am.getRestContext().performPost(request);
        Reporter.logJSON("Assign And Fetch Stage Issue Info API Response Payload: ", response.getDataResponse());
        return response;
    }

/*
     * Method to check if a bag number is already used in the database
     *
     * @param bagNumber The bag number to check
     * @return ServiceResponse containing the check-bag API response
     * Author: Prashant(vn52our)
     *//*


    public ServiceResponse checkBagNumber(int bagNumber) {
        Reporter.log("Checking bag number: " + bagNumber);
        // Load rxpd label properties to get the check-bag URL
        // Get the URL and replace store placeholder, then append bag number
        String baseUrl = propertyReader.getProperty("rxpd.checkBag.url");
        String url = baseUrl.replace("xxxx", storeNumber) + bagNumber;
        ServiceRequest req = new ServiceRequest();
        req.setUrl(url);
        req.setHeaders(getHeaderForOrderInfoList());
        Reporter.log("Check Bag API URL: " + url);
        ServiceResponse response = am.getRestContext().performGet(req);
        Reporter.log("Check Bag API Response Status Code: " + response.getStatusCode());
        Reporter.logJSON("Check Bag API Response Payload: ", response.getDataResponse());
        return response;
    }
    public ServiceResponse orderModifyLineCancellation(String omsOrderId, String poNumber, List<PoLine> poLines, int storeId) {
        OrderModifyReq OrderModifyReqLineCancellationReq = buildLineCancellation(omsOrderId, poNumber, poLines);
        String url = getStoreSpecificUri(propertyReader.getProperty("rxone.rxpd.api.dispense.ordermodify.uri") , storeId);
        return RestAPIHelper.performPost(OrderModifyReqLineCancellationReq, APIHeaders.getHeaders_Hops(storeId), url);
    }
    public static OrderModifyReq buildLineCancellation(String omsOrderId, String poNumber, List<PoLine> poLines) {
        ZonedDateTime now = ZonedDateTime.now();
        return OrderModifyReq.builder()
                .omsOrderId(omsOrderId)
                .poNumber(poNumber)
                .transType("PoCancellation")
                .slot(Slot.builder().startDateTime(DateUtils.getISODateFormat(now, DateTimeFormatter.ISO_LOCAL_DATE_TIME))
                        .endDateTime(DateUtils.getISODateFormat(now.plusHours(1), DateTimeFormatter.ISO_LOCAL_DATE_TIME)).build())
                .poLines(poLines)
                .build();
    }

    public  ServiceResponse createTrip(String tripId, String pinInfo, List<PurchaseOrder> purchaseOrders, int storeId)
    {
        request.setUrl(getStoreSpecificUri(propertyReader.getProperty("rxone.rxpd.api.dispenseTripAndDriverUpdate.uri"), storeId));
        request.setHeaders(APIHeaders.getHeaders_Hops(storeId));
        TripDriverUpdateReq tripDriverUpdateReqBody = TripDriverUpdateReq.buildWithGenericData(tripId, pinInfo, purchaseOrders);
        request.setRequestPayload(tripDriverUpdateReqBody);
        ServiceResponse response = am.getRestContext().performPost(request);
        Reporter.logJSON("HTTP Request", StringUtils.convertToJson(request));
        Reporter.logJSON("HTTP Response", StringUtils.convertToJson(response));
        Reporter.logJSON("Trip Driver Update API Response Payload: ", response.getStatusCode());
        return response;
    } */
}

