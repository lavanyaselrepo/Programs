package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderAndBagInfo {
	public int bagNumber;
    public String colorAbbr;
    public String colorCode;
    public ArrayList<OrderInfo> orderInfo;

}
