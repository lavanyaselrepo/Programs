package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RxPatientInfo {
	public int patientId;
    public String firstName;
    public String lastName;

}
