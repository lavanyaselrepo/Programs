package com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@Builder
@ToString
@EqualsAndHashCode
public class Item {
    private String itemId;
    private String quantity;
    private boolean isRx;
}

