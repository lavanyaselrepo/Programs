package com.walmart.hwqe.digitalPharmacyuicontext.rxpdregressionmodels;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

@Data
@Builder
@ToString
@EqualsAndHashCode
public class AddCartRequest {
    private String customerEmailAddress;
    private String storeId;
    private String paymentType;
    private List<FulfillmentGroup> fulfillmentGroups;
    private boolean resolveHolds;
    private String terminateBefore;
}
