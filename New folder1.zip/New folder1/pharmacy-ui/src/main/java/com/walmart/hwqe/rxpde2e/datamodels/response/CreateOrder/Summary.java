package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class Summary{
    public double subTotal;
    public double grandTotal;
    public double minimumThreshold;
    public double balanceToReachThreshold;
    public double thresholdOrderTotal;
    public double shipPriceBelowThreshold;
    public ArrayList<Discount> discounts;
    public ArrayList<Fee> fees;
    public ArrayList<Object> serviceCharges;
    public double maxOrderTotalLimit;
}
