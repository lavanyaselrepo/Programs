package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.Set;

public class ManageFamilyMembersPage extends MobileBasePage {
    
    // Platform-specific XPath patterns for dynamic locators
    private static final String ANDROID_MEMBER_CARD_BY_NAME = 
        "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/family_member_name' and contains(@text,'%s')]";
    
    private static final String ANDROID_REMOVE_BUTTON_IN_CARD = 
        "/ancestor::*[@resource-id='com.walmart.android.debug:id/user_info_container']" +
        "//android.widget.Button[@resource-id='com.walmart.android.debug:id/remove_dependent_btn']";
    
    private static final String IOS_MEMBER_CARD_BY_NAME = 
        "//XCUIElementTypeStaticText[contains(@name,'%s')]";
    
    // Button name on iOS is hash-suffixed (e.g. 'Remove a1b2c3...'); match by label prefix
    private static final String IOS_REMOVE_BUTTON_IN_CARD =
        "/ancestor::XCUIElementTypeCell//XCUIElementTypeButton[contains(@label,'Remove')]";

    private static final String IOS_CANCEL_REQUEST_BUTTON_IN_CARD =
        "/ancestor::XCUIElementTypeCell//XCUIElementTypeButton[contains(@label,'Cancel request')]";
    
    @FindBy(xpath = "//button[contains(text(),'Add a family member')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Add a family member')]")
    @iOSXCUITFindBy(accessibility = "HWSecondaryStickyButton.actionButton")
    public WebElement addFamilyMember;

    @FindBy(xpath = "//*[contains(text(),'Prescription information')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Scan a Walmart Rx barcode')]")
    public WebElement prescriptionInformation;

    @FindBy(xpath = "//*[contains(text(),'Phone number lookup')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Phone number lookup')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[contains(@name,'Phone number lookup')]")
    public WebElement phoneNumberLookup;

    @FindBy(xpath = "//*[text()='Phone number']/parent::*/following-sibling::*/input")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Phone number')]/following-sibling::*/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label,'Phone number')]")
    public WebElement enterPhoneNumber;

    @FindBy(xpath = "//*[contains(text(),'Continue')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Continue')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='HWPrimaryStickyButton.primaryActionButton' or @name='SMSIDEnterPhoneViewController.primaryAction']")
    public WebElement continueButton;

    @FindBy(xpath = "//*[contains(text(),'Confirm')]")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'Confirm')]")
    public WebElement confirmButton;

    @FindBy(xpath = "//*[contains(text(),'Send request')]")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'Send')]")
    public WebElement confirmAdultButton;

    @FindBy(xpath = "//*[contains(text(),'I confirm this is my pet')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/check_btn")
    public WebElement confirmPet;

    @FindBy(xpath = "//*[@id='add-fam-prescription-number']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Prescription number')]/following-sibling::*/android.widget.EditText")
    public WebElement rxNumber;

    @FindBy(xpath = "//*[@id='fam-storenumber']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Store number')]/following-sibling::*/android.widget.EditText")
    public WebElement storeNumber;

    @FindBy(xpath = "//*[@placeholder='mm/dd/yyyy']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'birth')]/following-sibling::*/android.widget.EditText")
    public WebElement dateOfBirth;

    @FindBy(xpath = "//*[contains(text(),'Send request')]")
    public WebElement sendEmailRequest;

    @FindBy(xpath = "//*[contains(text(), ' Minor')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Minor')]")
    public WebElement addedMinor;

    @FindBy(xpath = "//*[contains(text(), ' Pet')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Pet')]")
    public WebElement addedPet;

    @FindBy(xpath = "//*[contains(text(),'Pending approval')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Pending approval')]")
    public WebElement pendingApproval;

    @FindBy(xpath = "//span[contains(text(),'unable add this family member')]")
    public WebElement privacyWindow;

    @FindBy(xpath = "//span[contains(text(),'unable add')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/description_text")
    public WebElement livestockError;

    @FindBy(xpath = "//*[contains(text(),'We didn’t find this phone number')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'We didn’t find this phone number')]")
    public WebElement livestockPhoneNumberError;

    @FindBy(xpath = "//*[contains(text(),'Female, minor profile')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/check_btn")
    public WebElement selectMinor;

    @FindBy(xpath = "//*[contains(@type,'checkbox')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/check_btn")
    public WebElement selectAdult;

    @FindBy(xpath = "//*[contains(text(),'pet profile')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/check_btn")
    public WebElement selectPet;

    @FindBy(xpath = "//*[contains(text(),'Add selected')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_button")
    public WebElement addSelected;

    @FindBy(xpath = "//button[contains(text(),'Remove')]")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'Remove')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[starts-with(@name,'Remove')]")
    public WebElement removeDependent;

    @FindBy(xpath = "//*[contains(text(),'Cancel')]/following-sibling::button[text()='Remove']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_cta")
    @iOSXCUITFindBy(accessibility = "HWGenericViewController.firstButton")
    public WebElement removeMember;

    @FindBy(xpath = "//*[contains(text(),'Accept all')]")
    public WebElement acceptAll;

    @FindBy(xpath = "//*[contains(text(),'Accept')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/nudge_action_primary")
    public WebElement accept;


    @FindBy(xpath = "//*[contains(text(),'Verify number')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_button_main")
    @iOSXCUITFindBy(accessibility = "ValidateOTPView.ctaButton")
    public WebElement verifyNumberButton;

    @FindBy(xpath = "//*[contains(text()='Please check and re-enter the 6-digit verification code.')]")
    public WebElement invalidOtpValue;

    @FindBy(xpath = "//*[@link-identifier='getAnotherCode']")
    @AndroidFindBy(id = "com.walmart.android.debug:id/auth_otp_send_another_code")
    public WebElement getAnotherCode;

    @FindBy(xpath = "//*[contains(text(),'Request to manage accepted')]")
    public WebElement requestAccepted;

    @FindBy(xpath = "//*[contains(text(),'Manage family prescriptions')]")
    public WebElement manageFamilyPrescriptions;

    @FindBy(xpath = "//*[contains(text(),'Request to manage accepted')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/nudge_header")
    public WebElement adultManageRequestAccepted;

    @AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_foreground_only_button")
    public WebElement allowTakePictureWhileUsingApp;

    @AndroidFindBy(id = "com.walmart.android.debug:id/global_scanner_manual_entry_barcode_button")
    public WebElement enterManually;

    @AndroidFindBy(id = "com.walmart.android.debug:id/error_button")
    public WebElement backToAddFamilyMember;

    @AndroidFindBy(id="com.walmart.android.debug:id/closeButton")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='LD.NavigationBar.leftButton' or contains(@label,'Close') or contains(@label,'Back')]")
    public WebElement backButton;

    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'Cancel')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[starts-with(@name,'Cancel request')]")
    public WebElement cancelRequest;

    // Confirmation dialog elements
    @AndroidFindBy(id = "com.walmart.android.debug:id/primary_cta")
    public WebElement confirmActionButton;

    @AndroidFindBy(id = "com.walmart.android.debug:id/secondary_cta")
    public WebElement closeActionButton;

    public ManageFamilyMembersPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void clickAddFamilyMember() {
        click(addFamilyMember, 10);
    }

    public void clickPrescriptionInformation() {
        click(prescriptionInformation, 5);
    }

    public void clickPhoneNumberLookup() {
        click(phoneNumberLookup);
    }

    public void clickContinueButton() {
        click(continueButton);
    }

    public void clickConfirmButton() {
        click(confirmButton);
    }

    public void clickConfirmAdultButton() {
        click(confirmAdultButton);
    }

    public void clickConfirmPet() {
        click(confirmPet);
    }

    public void enterPrescriptionNumber(String prescriptionNumber) {
        sendText(rxNumber, prescriptionNumber);
    }

    public void enterStoreNumber(String StoreNumber) {
        sendText(storeNumber, StoreNumber);
    }

    public void enterPhoneNumber(String phoneNumber) {
        sendText(enterPhoneNumber, phoneNumber);
    }

    public void enterDateOfBirth(String DateOfBirth) {
        sendText(dateOfBirth, DateOfBirth);
    }


    public void clickSendEmailRequest() {
        click(sendEmailRequest);
    }

    public Boolean isMinorAdded() {
        return isElementDisplayed(addedMinor);
    }

    public Boolean isPetAdded() {
        return isElementDisplayed(addedPet, 3);
    }

    public Boolean sentRequestToAdult() {
        try {
            webWait.until(ExpectedConditions.visibilityOf(pendingApproval));
            Actions actions = new Actions(this.remoteDriver);
            actions.moveToElement(pendingApproval).build().perform();
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return isElementDisplayed(pendingApproval, 5);
    }

    public Boolean verifyLivestockErrorMessage() {
        return isElementDisplayed(livestockError);
    }

    public Boolean verifyLivestockPhoneNumberErrorMessage() {
        return isElementDisplayed(livestockPhoneNumberError);
    }

    public void acceptAll() {
        Set<String> windows = remoteDriver.getWindowHandles();
        if (isElementDisplayed(privacyWindow)) {
            try {
                for (String window : windows) {
                    remoteDriver.switchTo().window(window);
                    click(acceptAll);
                    remoteDriver.switchTo().defaultContent();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void removeDependents() {
        if (remoteDriver instanceof AndroidDriver) {
            WebElement removeBtn = this.androidManualSwipeDownToText("Remove");
            if (removeBtn != null) {
                click(removeBtn, 5);
                performSleep(3);
                click(removeMember, 5);
                return;
            }
        }
        // iOS or fallback
        click(removeDependent, 10);
        waitForLoadingToDisappear(8);
        click(removeMember, 5);
    }

    public boolean isDepedentFound() {
        if (remoteDriver instanceof AndroidDriver) {
            this.androidManualSwipeDownToText("Remove");
        }
        return isElementDisplayed(removeDependent);
    }

    public void clickVerifyNumberButton() {
        click(verifyNumberButton);
    }

    public void selectMinor() {
        if (isElementDisplayed(selectMinor)) {
            click(selectMinor);
        } else {
            remoteDriver.navigate().back();
            Assert.fail("Some thing went wrong during pin validate");
        }
    }

    public void selectAdult() {
        if (isElementDisplayed(selectAdult)) {
            click(selectAdult);
        } else {
            remoteDriver.navigate().back();
            Assert.fail("Some thing went wrong during pin validate");
        }
    }

    public void addSelected() {
        click(addSelected);
    }

    public void clickAccept() {
        click(accept);
    }

    public void selectPet() {
        if (isElementDisplayed(selectPet)) {
            click(selectPet);
        } else {
            Assert.fail("Some thing went wrong during pin validate");
        }
    }

    public Boolean isRequestAccepted() {
        if (isElementDisplayed(requestAccepted)) {
            return true;
        } else {
            return false;
        }
    }

    public void goToManageFamilyPrescriptions() {
        click(manageFamilyPrescriptions);
    }

    public Boolean isAdultManageAccepted() {
        if (isElementDisplayed(adultManageRequestAccepted)) {
            return true;
        } else {
            return false;
        }
    }

    public void allowTakePictureWhileUsingTheApp() {
        click(allowTakePictureWhileUsingApp);
    }

    public void clickEnterManually() {
        if(isElementDisplayed(enterManually)) {
            click(enterManually);
        }
    }

    public void clickBackToAddFamilyMember(){
        click(backToAddFamilyMember);
    }

    public void clickGoBackToManageMyFamily(){
        click(removeMember);
    }
    public void cancelRequest(){
        if (remoteDriver instanceof AndroidDriver) {
            WebElement cancelBtn = this.androidManualSwipeDownToText("Cancel request");
            if (cancelBtn != null) {
                click(cancelBtn, 5);
                click(removeMember, 5);
                return;
            }
        }
        // iOS or fallback
        if (isElementDisplayed(cancelRequest, 5)) {
            click(cancelRequest, 5);
            click(removeMember, 5);
        }
    }

    /**
     * Remove a specific family member by name
     * @param memberName - Name of family member to remove (e.g., "Aarav Patel")
     */
    public void removeFamilyMemberByName(String memberName) {
        try {
            waitForLoadingToDisappear(3);
            String xpath = isAndroid()
                ? String.format(ANDROID_MEMBER_CARD_BY_NAME + ANDROID_REMOVE_BUTTON_IN_CARD, memberName)
                : String.format(IOS_MEMBER_CARD_BY_NAME + IOS_REMOVE_BUTTON_IN_CARD, memberName);

            WebElement removeButton = remoteDriver.findElement(By.xpath(xpath));
            click(removeButton, 3);

            waitForElementToBeClickable(confirmActionButton, "Confirmation button");
            click(confirmActionButton);

            waitForLoadingToDisappear(10);
            Reporter.log("Successfully removed " + memberName + " - screen ready for next action");

        } catch (Exception e) {
            Reporter.log("Failed to remove family member: " + memberName + " - " + e.getMessage());
            throw e;
        }
    }

    /**
     * Cancel request for a pending adult family member by name
     * Note: Cancel request button uses same resource-id as Remove button on Android
     * @param memberName - Name of adult family member (e.g., "Rajesh P***")
     */
    public void cancelRequestForAdultByName(String memberName) {
        try {
            // Android uses same resource-id for both Remove and Cancel request buttons
            // iOS has different button names: 'Remove' vs 'Cancel request'
            String xpath = isAndroid()
                ? String.format(ANDROID_MEMBER_CARD_BY_NAME + ANDROID_REMOVE_BUTTON_IN_CARD, memberName)
                : String.format(IOS_MEMBER_CARD_BY_NAME + IOS_CANCEL_REQUEST_BUTTON_IN_CARD, memberName);

            WebElement cancelButton = remoteDriver.findElement(By.xpath(xpath));
            click(cancelButton, 3);

            waitForElementToBeClickable(confirmActionButton, "Confirmation button");
            click(confirmActionButton);

            waitForLoadingToDisappear(10);
            Reporter.log("Successfully cancelled request for " + memberName + " - screen ready for next action");

        } catch (Exception e) {
            Reporter.log("Failed to cancel request for: " + memberName + " - " + e.getMessage());
            throw e;
        }
    }

    /**
     * Verify family member exists on manage family screen
     * @param memberName - Name of family member to verify
     * @return true if member is displayed
     */
    public boolean isFamilyMemberDisplayed(String memberName) {
        try {
            String xpath = isAndroid()
                ? String.format(ANDROID_MEMBER_CARD_BY_NAME, memberName)
                : String.format(IOS_MEMBER_CARD_BY_NAME, memberName);
            
            WebElement member = remoteDriver.findElement(By.xpath(xpath));
            return isElementDisplayed(member, 5);
        } catch (Exception e) {
            Reporter.log("Family member not found: " + memberName);
            return false;
        }
    }

    /**
     * Navigate back to Pharmacy Dashboard from Manage family screen
     * Uses the Close button in toolbar
     */
    public void navigateBackToPharmacyDashboard() {
        try {
            click(backButton, 10);
            Reporter.log("Clicked close button to navigate back to Pharmacy Dashboard");
            performSleep(2);
        } catch (Exception e) {
            Reporter.log("Failed to navigate back: " + e.getMessage());
            throw e;
        }
    }
}

