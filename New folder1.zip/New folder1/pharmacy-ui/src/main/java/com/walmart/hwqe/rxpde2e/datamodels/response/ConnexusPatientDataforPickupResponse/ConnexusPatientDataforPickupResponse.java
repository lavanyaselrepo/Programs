package com.walmart.hwqe.rxpde2e.datamodels.response.ConnexusPatientDataforPickupResponse;

@lombok.Getter
@lombok.Setter
public class ConnexusPatientDataforPickupResponse {
    public int requestTypeCode;
    public int priorityId;
    public boolean changeMode;
    public int patientId;
    public int orderId;
    public int packId;
    public int packageId;
    public boolean visible;
    public int selectedIndex;
    public int selectedValue;
    public int tempPriority;
    public String controlDate;
    public int siteID;
    public String pickUpDate;
    public int rxFillId;
    public int rxId;
    public int orderSeqNbr;
    public int inputId;
    public int rxNbr;
    public int orgPriorityId;
    public String fillDate;
    public String rxWrittenDate;
    public int requestSeqNbr;
    public String rxExpDate;
    public String inputPickUpDate;
    public String inputRxExpDate;
    public int requestId;
    public int dispenseType;
    public boolean updateFillViaDB;
    public int toteNumber;
    public int numRefills;
    public Drug drug;
    public Prescriber prescriber;
    public boolean allowExpiredOrder;
    public int productMdsFamId;
    public String omsOfferId;
    public String omsWtxCode;
    public String omsOrderId;
    public String rxInfo;
    public String workQueue;
    public String exceptionDetails;
    public String shippingResponseData;
    public boolean orderTypeERx;
    public int rxResponseCode;
    public String  poId;
    public String futureFillDate;
    public boolean patientHasInsurance;
    public String ndcnumber;
    public boolean shippingSuccessful;
}
