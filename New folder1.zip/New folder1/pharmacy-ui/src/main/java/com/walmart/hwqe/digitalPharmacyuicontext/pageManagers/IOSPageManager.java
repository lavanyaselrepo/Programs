/**
 * IOSPageManager initialises the page manager for "IOS" platform.
 * It inherits BasePageApplicationManager.
 * Usage : Overridden methods for common interactions that are specific to IOS platform are written over here.
 *
 * @Author: Saloni Sharma
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */

package com.walmart.hwqe.digitalPharmacyuicontext.pageManagers;


import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.apimanager.DigitalPharmacyAPIManager;
import com.walmart.hwqe.commons.utilities.Reporter;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.List;

public class IOSPageManager extends BasePageApplicationManager {

    public IOSPageManager() {

        super();
    }

    public IOSPageManager(RemoteWebDriver driver, String platform) {

        super(driver, platform);
    }

    @Override
    public void waitForAppToLoad() {
        Reporter.log("iOS: Waiting for app to load and sign-in screen to appear...");
        // Base class does am.performSleep(5) — a guaranteed 5s dead wait regardless of app speed.
        // Replace with a condition-based wait that exits as soon as the sign-in button is visible.
        try {
            new WebDriverWait(signInPage.remoteDriver, Duration.ofSeconds(60))
                    .pollingEvery(Duration.ofMillis(500))
                    .until(ExpectedConditions.visibilityOfElementLocated(
                            AppiumBy.accessibilityId("Sign in")));
            Reporter.log("iOS app load: Sign-in screen loaded successfully");
        } catch (TimeoutException e) {
            Reporter.log("WARNING: Sign-in button not detected after 60 seconds. App may still be loading.");
        }
    }

    public void closeAllCampaignPopups() {

        this.continueShoppingPersonalisation();
        this.closeWalmartPlusProgramButton();
        this.clickServicesTab();
        this.closeJoinOneProgram();
    }

    public void proceedToPharmacyDashboard() {
        pharmacyDashboardPage.clickPharmacyServicesButton();
        pharmacyDashboardPage.enterPin();
        pharmacyDashboardPage.confirmPin();
    }

    @Override
    public void enterAndConfirmPin() {
        pharmacyDashboardPage.enterPin();
        pharmacyDashboardPage.confirmPin();
    }


    public void scrollToSingleRFRCard() {
        pharmacyDashboardPage.mobileScrollToText("1 prescription is ready for refill", "up");
    }

    public void dismissNotifications() {
        signInPage.clickMayBeLaterNotifications();
        Reporter.log("Clicked on may be later CTA to dismiss product notification");
    }

    public void closeJoinOneProgram() {
        homePage.clickCloseJoinOneProgramButton();
    }

    public void closeSparkyPopUp() {
        homePage.clickCloseSparkyPopUp();
    }

    public void continueShoppingPersonalisation() {
        homePage.clickPersonalisationChoiceButton();
    }

    public void continueAsGuest() {
        continueAsGuestPage.clickContinueAsGuestButton();
        continueAsGuestPage.clickGetNotificationsButton();
        continueAsGuestPage.clickEnterZipCodeLink();
        continueAsGuestPage.enterZipCode("72719");
        continueAsGuestPage.clickSearchZipCodeButton();
        continueAsGuestPage.clickTrackActivityContinueButton();
    }

    public void scanRxDetailsManually(String rxNb, String storeNb, String dob) {
        scanToRefillPage.enterRxNumber(rxNb);
        scanToRefillPage.enterStoreNumber(storeNb);
        scanToRefillPage.enterDOB(dob);
        scanToRefillPage.clickContinueButton();
    }

    public void doSignIn(String email, String password) {
        signInPage.clickSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        // Wait for the sign-in screen to transition away rather than sleeping a fixed 5s.
        // Exits as soon as the Sign In button is gone, which can be much faster than 5s.
        try {
            new WebDriverWait(signInPage.remoteDriver, Duration.ofSeconds(15))
                    .until(ExpectedConditions.invisibilityOfElementLocated(
                            AppiumBy.accessibilityId("Sign in")));
        } catch (TimeoutException ignored) {
            Reporter.log("Sign-in screen still visible after 15s — proceeding to step-up check");
        }
        try {
            if (signInPage.isStepUpHeaderDisplayed()) {
                if (signInPage.isStepUpEnabled()) {
                    Reporter.log("Clicking on Email Option for OTP");
                    signInPage.clickSendOtpOnEmailRadioButton();
                } else {
                    Reporter.log("Only Email Option was Available");
                }
                DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
                signInPage.clickSendcode();
                // Wait for the OTP API to have the code rather than sleeping a fixed 4s.
                // isStepUpHeaderDisplayed uses a 5s check; the API poll below retries on empty.
                am.performSleep(2);
                String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
                signInPage.enterInputOtpValue(otp);
                signInPage.clickSignInButtonForStepUp();
            } else {
                Reporter.log("SteupDisabled");
            }
        } catch (Exception e) {
            Reporter.log("failed in Stepup flow");
            e.printStackTrace();
        }
        Reporter.log("Signed-In to walmart dotcom account");
    }

    public void proceedToPharmacyDashboardWithATCEnabled() {
        homePage.clickPersonalisationChoiceButton();
        homePage.dismissAppTrackingPermissionIfPresent();
        Reporter.log("Denied personalisation choice popup");
        homePage.clickWalmartPlusProgramButton();
        Reporter.log("Closed walmart plus program popup");
        homePage.clickServicesButton();
        Reporter.log("Clicked on Services CTA");
        homePage.clickCloseJoinOneProgramButton();
        homePage.closeOnePayVisaCheckout();
        homePage.clickCloseSparkyPopUp();
        pharmacyDashboardPage.clickPharmacyServicesButton();
        Reporter.log("Closed join one program popup and clicked pharmacy service");
        pharmacyDashboardPage.enterInputPin();
        pharmacyDashboardPage.verifyPin();
        Reporter.log("Entered pharmacy PIN");
        pharmacyDashboardPage.denyBiometricsPermissionButton();
        pharmacyDashboardPage.denyShoppingPersonalizationPermissionButton();
        Reporter.log("Denied biometrics and personalisation shopping permission");
    }

    public void navigateToWalmartPharmacy() {
        homePage.waitForLoadingToDisappear(4);
        homePage.clickPersonalisationChoiceButton();
        homePage.dismissAppTrackingPermissionIfPresent();
        homePage.clickWalmartPlusProgramButton();
        homePage.clickServicesButton();
        homePage.clickCloseSparkyPopUp();
        homePage.clickCloseJoinOneProgramButton();
        homePage.closeOnePayVisaCheckout();
        pharmacyDashboardPage.clickPharmacyServicesButton();
    }

    public void fillZipCodeDetails() {
        signInPage.fillZipCodeDetails();
        Reporter.log("Entered Zip Code Details");
    }

    public void validateExperianFlowHeader() {
        Assert.assertTrue(connectMyAccount.experianFlow(),"Experian flow header not displayed");
    }
    public void verifyGroceryDetailsInEcommCart(String item) {
        Assert.assertTrue(ecommCartPage.nonRxItemIsDisplayed(), "Non RX item doesn't display");
        Reporter.log("Verified non-RX item details in ecomm cart page");
        ecommCartPage.removeNonRxItem();
        Reporter.log("Successfully removed non-RX item from cart");
    }

    public void proceedToScanToRefill() {
        pharmacyDashboardPage.clickScanToRefill();
        // clickAllowTakePicturesAndRecordAudio Handles camera permission popup
        scanToRefillPage.clickAllowTakePicturesAndRecordAudio();
        pharmacyDashboardPage.clickEnterManuallyBtn();
    }

    public void proceedToScanToRefillNotConnected() {
        pharmacyDashboardPage.clickScanToRefillNotConnected();
        pharmacyDashboardPage.clickOnlyThisTime();
        pharmacyDashboardPage.clickEnterManuallyBtn();
    }

    public void verifyScanToRefillMinorFlow(String RX,String strNo,String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        pharmacyDashboardPage.clickContinue();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        pharmacyDashboardPage.clickFeedbackCloseButton();
    }

    public void verifyScanToRefillPetRxFlow(String RX,String strNo,String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        pharmacyDashboardPage.clickContinueForPetPopUp();
        scanToRefillPage.clickContinueButton();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        pharmacyDashboardPage.clickAddFamilyMemberOptionInTheRefillPrescriptionScreen();
        pharmacyDashboardPage.clickCloseButton();
        pharmacyDashboardPage.clickFeedbackCloseButton();
        pharmacyDashboardPage.clickAddFamilyMemberOption();
        pharmacyDashboardPage.clickRemoveOption();
    }

    public void verifyScanToRefillFlowWhenAccountNotConnectedTest(String RX,String strNo,String Dob) {
        pharmacyDashboardPage.enterPrescriptionDetails(RX);
        pharmacyDashboardPage.enterStoreDetails(strNo);
        pharmacyDashboardPage.enterDobDetails(Dob);
        scanToRefillPage.clickContinueButton();
        pharmacyDashboardPage.clickContinueForPetPopUp();
        scanToRefillPage.clickContinueButton();
        pharmacyDashboardPage.clickRequestRefill();
        pharmacyDashboardPage.validateSuccessRequestRefill();
        pharmacyDashboardPage.clickGetStartedButton();
    }

    public void generateRxMessagingPhoneOtpScanToRefillFlow(String phoneNo) {
        connectMyAccount.enterPhoneNumber(phoneNo);
        connectMyAccount.clickContinueCTA();
    }



    public void handlePharmacyPinValidation(String pin) {
        pharmacyDashboardPage.enterPharmacyPin(pin);
        // Wait for any loading indicators to clear rather than sleeping a fixed 10s.
        // waitForLoadingToDisappear polls every ~500ms for spinners and progress bars,
        // so fast loads exit early while slow loads still get up to 10s.
        pharmacyDashboardPage.waitForLoadingToDisappear(10);
    }

    public void proceedToCheckoutRxsAddedToCart(String cvvNumber, Boolean isDiscardCheckout, Boolean isPlaceOrder, Boolean isExpressEvergreenSlot, boolean... isSODNeeded) throws Exception {
        orderCheckoutPage.clickContinueToCheckout();
        orderCheckoutPage.clickStoreDeliveryCTA();
        orderCheckoutPage.selectSlot(isExpressEvergreenSlot);
        orderCheckoutPage.clickConfirmAddressContinueButton();
        orderCheckoutPage.clickBookSlotContinueButton();
        // Wait for slot reservation to be reflected in the UI rather than sleeping a fixed 7s.
        // Polls for loading indicators to clear; exits early on fast devices.
        orderCheckoutPage.waitForLoadingToDisappear(7);
        // these banners may still be needed in the future, I have seen them pop up, in the current rendition, consistently saw them do not appear.

        // orderCheckoutPage.clickNoThanksButtonForMembers();
        // homePage.clickPersonalisationChoiceButton();
        // orderCheckoutPage.clickWalmartPlusMembershipPopupDeclineButton();

        // cvv number is not required for onePayCheckout enabled accounts
        // orderCheckoutPage.enterCVVNumber(cvvNumber);

        // Commenting this because this is needed exactly once and the preference is saved
        /*boolean isDeliverySignatureNeeded = (isSODNeeded.length >= 1) ? isSODNeeded[0] : false;

        if (isDeliverySignatureNeeded) {
            orderCheckoutPage.clickSignOnDeliveryCTA();
        }*/


        if (isPlaceOrder) orderCheckoutPage.clickPlaceOrderCTA();
        else if (isDiscardCheckout) this.discardCheckoutProcess();
    }

    public void cancelOrderFromDotCom() {
        orderConfirmationPage.clickViewDetailsButton();
        orderDetailsPage.clickCancelOrderButton();
        orderDetailsPage.clickWrongPaymentMethodCancellationReason();
        orderDetailsPage.clickConfirmCancellationButton();
    }

    public void doSignIn(String email, String password, String phone) {
        signInPage.clickSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        if (!pharmacyDashboardPage.isVerifyInputPinVisible()) {
            if (signInPage.isSendCodeForStepUpEnabledDisplayed()) {
                signInPage.clickSendcode();
                // Minimum wait for OTP email delivery before hitting the API.
                // Reduced from 5s — the API call itself has internal retry logic.
                am.performSleep(2);
                DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
                String otp = digitalPharmacyAPIManager.getOTPForEmail(email);
                if (otp == null) {
                    otp = digitalPharmacyAPIManager.getOTPForPhone(email, phone);
                }
                if (otp == null) {
                    Reporter.log("One time passcode is null");
                    Assert.fail("Cannot get One time Passcode for this user");
                }
                Reporter.log("One time passcode is :: " + otp);
                signInPage.enterInputOtpValue(otp);
                signInPage.clickSignInButtonForStepUp();
                if (!signInPage.isSignInButtonNotDisplayed()) {
                    Assert.fail("One time password Entered is wrong");
                }
            }
        } else {
            Reporter.log("Step up flow was disabled, proceeding with PIN verification");
        }
        Reporter.log("Logged In successfully");
    }

    public String verifyCheckoutSuccessAndGetOrderId(String customerName) {
        // After Checkout Page Load is slow
        orderConfirmationPage.clickDeclineFeedBackButton();
        Object orderConfirmedText = textValidationUtils.getKeyInObject("orderConfirmationPage", "orderConfirmedPartialText");
        Assert.assertEquals(orderConfirmationPage.getOrderIsConfirmedHeaderText().toLowerCase(), (customerName + orderConfirmedText.toString()).toLowerCase(), "Order Confirmation Text is incorrect");
        return orderConfirmationPage.getOrderNumber();
    }

    public void hitBackButton()
    {
        manageInsurancePage.clickBackButton();
    }

    public void validateAddedInsuranceDetails(String memberId, String bin, String pcn) {
        manageInsurancePage.clickExpandInsurance();
        String xpathExpression = String.format("//XCUIElementTypeButton[contains(@name, 'Prescription insurance details for Member ID: %s') and contains(@name,'RxBIN: %s, RxPCN: %s')]", memberId, bin, pcn);
        Assert.assertTrue(manageInsurancePage.isElementDisplayed(By.xpath(xpathExpression)), "Insurance details are not displayed correctly for Member ID: " + memberId);
    }

    public void scrollToFindWalmartPrescriptionsModule() {
        pharmacyDashboardPage.mobileScrollToText("Find Walmart prescriptions", "up");
        pharmacyDashboardPage.mobileSwipe("up"); // scrolling up one more time as element is behind the bottom navigation bar
    }

    public void selectEnterPrescriptionManually() {
        findPrescriptionsPage.selectEnterPrescriptionManuallyRadioButton().clickContinueBtn();
    }

    public void clickOnManageFamilyCTA() {
        pharmacyDashboardPage.mobileScrollToText("Manage family members", "up");
        pharmacyDashboardPage.clickOnManageFamilyCTA();
    }

    @Override
    public void selectAndAddFamilyMembersWithDOB(String minorDob, boolean hasPet, String adultDob) {
        smsFamilyAdditionPage.selectAllFamilyMembers();
        smsFamilyAdditionPage.clickAddSelectedMembers();

        // Loop through screens in whatever order the app presents them — order is non-deterministic
        // across environments (minor first on SauceLabs, adult first on local simulator).
        for (int i = 0; i < 5; i++) {
            if (smsFamilyAdditionPage.isElementDisplayed(smsFamilyAdditionPage.petConsentCheckbox, 5)) {
                Reporter.log("iOS: Confirming pet ownership");
                smsFamilyAdditionPage.confirmPetOwnership();
                smsFamilyAdditionPage.clickConfirmDob();

            } else if (smsFamilyAdditionPage.isElementDisplayed(smsFamilyAdditionPage.dobInputField, 5)) {
                if (smsFamilyAdditionPage.isMinorDobScreen()) {
                    Reporter.log("iOS: Detected minor DOB screen — entering minor DOB");
                    smsFamilyAdditionPage.enterDobForFamilyMember(minorDob);
                    smsFamilyAdditionPage.clickDoneButtonForIOSKeyboard();
                    smsFamilyAdditionPage.clickConfirmDob();
                } else {
                    Reporter.log("iOS: Detected adult DOB+email screen — entering adult DOB and sending request");
                    smsFamilyAdditionPage.enterDobForFamilyMember(adultDob);
                    smsFamilyAdditionPage.clickDoneButtonForIOSKeyboard();
                    smsFamilyAdditionPage.clickConfirmDob();
                }

            } else {
                break;
            }
        }
    }

    @Override
    public void navigateToManageMyFamilyPage() {
        pharmacyDashboardPage.navigateToManageFamilyMembers();
        Reporter.log("iOS: navigated to Manage My Family page");
    }

    @Override
    public void addFamilyUsingPhoneNoLookup(String phoneNumber, String emailForPin) {
        manageFamilyMembersPage.clickPhoneNumberLookup();
        manageFamilyMembersPage.clickContinueButton();
        manageFamilyMembersPage.enterPhoneNumber(phoneNumber);
        manageFamilyMembersPage.clickContinueButton();
        // Wait for OTP input screen to be visible before polling the API for the code
        signInPage.isElementDisplayed(signInPage.inputOtpValue, 15);
        String otp = digitalPharmacyAPIManager.getOTPForPhone(emailForPin, phoneNumber);
        // On SauceLabs real device, SMS delivery can take longer than the 15s internal wait —
        // retry once with an additional 15s gap before failing
        if (otp == null) {
            Reporter.log("iOS: OTP was null on first attempt, retrying after 15s");
            am.performSleep(15);
            otp = digitalPharmacyAPIManager.getOTPForPhone(emailForPin, phoneNumber);
        }
        signInPage.enterInputOtpValue(otp);
        manageFamilyMembersPage.clickVerifyNumberButton();
    }

    @Override
    public boolean completeSMSFamilyAddition(String minorDob, boolean hasPet, String adultDob) {
        boolean result = super.completeSMSFamilyAddition(minorDob, hasPet, adultDob);
        // Dismiss the final summary screen so we land on Manage My Family
        try {
            smsFamilyAdditionPage.clickDoneOnConfirmationScreen();
            Reporter.log("iOS: tapped Continue on SMS family addition summary screen");
        } catch (Throwable e) {
            Reporter.log("iOS: could not tap Continue on summary screen – " + e.getMessage());
        }
        return result;
    }

    @Override
    public void validatePrimaryTag() {
          Assert.assertTrue(manageInsurancePage.isPrimaryInsuranceTagDisplayedIOS(), "Primary tag is not displayed for the insurance");
    }

    @Override
    public void removeInsurance() {
        manageInsurancePage.removeInsuranceIOS();
    }

    public void configureDebugSettings() {
        debugMenuPage.openDebugPanelIOS();

        debugMenuPage.iOSScrollToTextInTableCell("Authentication Settings", 10, "up").click();
        debugMenuPage.enableDebugToggle("Skip Stepup at Sign In");
        debugMenuPage.navigateBack();

        debugMenuPage.click(debugMenuPage.debugPanelAnchor);
        Reporter.log("iOS debug settings configured: Skip Stepup at Sign In = enabled");
    }

    @Override
    public void configureDebugSettingsSkipOnboarding() {
        debugMenuPage.openDebugPanelIOS();

        debugMenuPage.iOSScrollToTextInTableCell("Onboarding cookie crisis", 10, "up").click();
        debugMenuPage.iOSScrollToTextInTableCell("Skip Onboarding", 10, "up").click();
        Reporter.log("iOS: dismissed 'Skip Notification Popup' → Yes, skip please");
    }

    @Override
    public void doSignInSkipOnBoardingAndStepUp(String email, String password) {
        configureDebugSettings();
        signInPage.clickSignInButton();
        Reporter.log("Dotcom sign-in button clicked successfully");
        signInPage.enterEmail(email);
        Reporter.log("Entered email " + email);
        signInPage.clickContinueButton();
        signInPage.clickPasswordOption();
        signInPage.enterPassword(password);
        Reporter.log("Selected password option and entered the password");
        signInPage.clickContinueSignInButton();
        Reporter.log("Signed-In to walmart dotcom account");
        am.performSleep(5);
        configureDebugSettingsSkipOnboarding();
        am.performSleep(5); // intermittently dashboard is not loading
    }

    /**
     * Relaunches app via pharmacy dashboard deep link, enters PIN, and dismisses all bottom sheets.
     * PIN screen uses a custom numeric keypad (XCUIElementTypeKey), not a text field.
     */
    @Override
    public void proceedToPharmacyDashboardAndCloseBottomSheets() {
        this.restartAppToEnableDashboard();

        // Dismiss promotional overlays that may block the PIN keypad
        homePage.closeWalmartPlusProgramButton();
        homePage.clickPersonalisationChoiceButton();
        dismissAllBottomSheets();
        homePage.clickCloseJoinOneProgramButton();
        homePage.clickWalmartPlusProgramButton();
        homePage.closeOnePayVisaCheckout();
        dismissAllBottomSheets();

        pharmacyDashboardPage.enterPin();
        pharmacyDashboardPage.confirmPin();
        Reporter.log("iOS: entered PIN 1111");

        // On SauceLabs fresh install the HIPAA/delivery-consent screen appears after PIN.
        // Uses existing try-catch guard — skips silently if the screen is not present.
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
        Reporter.log("iOS: dismissed HIPAA consent if present");

        am.performSleep(3);
        pharmacyDashboardPage.closeDeliveryAvailablePopupButton();
        dismissAllBottomSheets();

        Reporter.log("iOS: pharmacy dashboard ready");
    }

    public void proceedToPharmacyDashboardAndCloseBottomSheetsWithoutPin() {
        this.restartAppToEnableDashboard();
        homePage.clickPersonalisationChoiceButton();
        dismissAllBottomSheets();
        homePage.clickCloseJoinOneProgramButton();
        Assert.assertTrue(isPharmacyDashboardDisplayed(), "Pharmacy Dashboard should be displayed");
    }

    public void restartAppToEnableDashboard() {
        Reporter.log("iOS: relaunching via pharmacy dashboard deep link");
        String bundleId = prop.getProperty("dp.ios.app.bundle.id");
        Map<String, Object> deepLinkArgs = new HashMap<>();
        deepLinkArgs.put("url", "walmart://healthandwellness/dashboard");
        deepLinkArgs.put("package", bundleId);
        ((IOSDriver) pharmacyDashboardPage.appDriver).executeScript("mobile: deepLink", deepLinkArgs);
        Reporter.log("iOS: navigated to dashboard walmart://healthandwellness/dashboard");
        am.performSleep(5);
    }

    @Override
    public void dismissAllBottomSheets() {
        signInPage.dismissAllBottomSheets();
    }

    @Override
    public void navigateToPrescriptionHistory() {
        pharmacyDashboardPage.mobileScrollToText("Prescription history", "up");
        pharmacyDashboardPage.navigateToPrescriptionHistory();
    }

    @Override
    public void verifyFilteredPrescriptionsForEachMember(
            List<String> memberFirstNames, List<String> drugNames, List<String> prices, List<String> dates) {
        for (int i = 0; i < memberFirstNames.size(); i++) {
            String firstName = memberFirstNames.get(i);

            if (prescriptionHistoryPage.isResetAllFilterEnabled()) {
                prescriptionHistoryPage.clickResetAllFilter();
            }

            prescriptionHistoryPage.clickFamilyFilterMemberByFirstName(firstName);
            prescriptionHistoryPage.clickApplyFilter();

            String visibleOwner = prescriptionHistoryPage.parseFieldFromCompositeLabel(prescriptionHistoryPage.getFirstPrescriptionOwner(), "owner");
            Assert.assertTrue(visibleOwner.toLowerCase().contains(firstName.toLowerCase()),
                    "Owner mismatch for '" + firstName + "' | Visible owner: " + visibleOwner);
            Assert.assertEquals(prescriptionHistoryPage.parseFieldFromCompositeLabel(prescriptionHistoryPage.getFirstPrescriptionDrugName(), "drug"), drugNames.get(i),
                    "Drug name mismatch for '" + firstName + "'");
            Assert.assertEquals(prescriptionHistoryPage.parseFieldFromCompositeLabel(prescriptionHistoryPage.getFirstPrescriptionPrice(), "price"), prices.get(i),
                    "Price mismatch for '" + firstName + "'");
            Assert.assertEquals(prescriptionHistoryPage.parseFieldFromCompositeLabel(prescriptionHistoryPage.getFirstPrescriptionDate(), "date"), dates.get(i),
                    "Date mismatch for '" + firstName + "'");
            logScreenShot("Filtered prescriptions for: " + firstName);

            if (i < memberFirstNames.size() - 1) {
                prescriptionHistoryPage.clickFamilyFilter();
            }
        }

    }

    @Override
    public String getDownloadHistoryButtonAttribute() {
        return prescriptionHistoryPage.getDownloadHistoryButtonAttribute();
    }

    /**
     * Clicks Edit address, updates address line 1 to random number + addressLine1 from test data, and saves.
     * If the "Unable to verify address" bottom sheet appears, clicks "Continue with entered address".
     * @param userData test data containing "addressLine1" (e.g. "Sw Troon Ln"); default "Sw Troon Ln" if missing
     */
    @Override
    public void editAddressAndSaveWithRandomNumber(JSONObject userData) {
        String addressLine1 = userData != null ? userData.optString("addressLine1", "Sw Troon Ln") : "Sw Troon Ln";
        int randomNum = ThreadLocalRandom.current().nextInt(3101, 4001);
        String newAddress = randomNum + " " + addressLine1;
        personalInformationPage.clickEditAddress();
        personalInformationPage.enterAddressAndSave(newAddress);
        try {
            ((IOSDriver) personalInformationPage.appDriver).hideKeyboard();
            Reporter.log("Dismissed iOS keyboard/autocomplete");
        } catch (Exception e) {
            Reporter.log("hideKeyboard skipped: " + e.getMessage());
        }
        personalInformationPage.clickSaveAddress();
        Reporter.log("Updated address to: " + newAddress);
        if (personalInformationPage.isUnableToVerifyAddressSheetDisplayed()) {
            personalInformationPage.clickContinueWithEnteredAddress();
        }
    }

    @Override
    public void scrollDownToLoadPreferencesCategories() {
        communicationsPage.mobileScrollToText("Clinical outreach", "up");
    }

    @Override
    public void scrollToReceiveTextNotificationsToggle() {
        communicationsPage.mobileScrollToText("Pharmacy and health services notifications", "down");
    }

    /**
     * iOS override: validates updated store details on Refill Review screen.
     * Base implementation uses Android UiScrollable which is not available on iOS;
     * this override uses isTextDisplayedInIOS to mirror the Android pattern exactly.
     */
    @Override
    public void validateRefillReviewStoreDetails(String expectedStoreName, String expectedAddress,
                                                  String expectedCityStateZip) {
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInIOS(expectedStoreName),
            "Store name '" + expectedStoreName + "' not found on review screen");
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInIOS(expectedAddress),
            "Store address '" + expectedAddress + "' not found on review screen");
        Assert.assertTrue(
            scanToRefillPage.isTextDisplayedInIOS(expectedCityStateZip),
            "City/State/Zip '" + expectedCityStateZip + "' not found on review screen");
        Reporter.log("Refill review store details validated — Store: " + expectedStoreName);
    }

    /**
     * iOS override: validates the Refill Confirmation screen after submitting a refill request.
     * Mirrors Android implementation: fetches expected strings from textValidationUtils and asserts
     * header equality plus presence of notification and delivery upsell texts via XCUITest locators.
     */
    @Override
    public void validateRefillConfirmationScreen() {
        String headerText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "headerText").toString();
        String notificationText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "notificationText").toString();
        String deliveryUpsellText = textValidationUtils.getKeyInObject("refillConfirmationScreen", "deliveryUpsellText").toString();
        Assert.assertEquals(
                scanToRefillPage.getRefillConfirmationHeaderText(),
                headerText,
                "Refill confirmation header text mismatch");
        Assert.assertTrue(
                scanToRefillPage.isTextDisplayedInIOS(notificationText),
                "Notification text not shown on confirmation screen");
        Assert.assertTrue(
                scanToRefillPage.isTextDisplayedInIOS(deliveryUpsellText),
                "Delivery upsell banner not shown on confirmation screen");
        Reporter.log("iOS: Refill confirmation screen validated successfully");
    }

    /**
     * iOS override: scrolls to and clicks "Transfer prescriptions" card, selects
     * non-Walmart radio, and clicks Continue. Uses click(By) to bypass isEnabled=false
     * gate on XCUIElementTypeStaticText elements.
     */
    @Override
    public void proceedToTransferPrescriptionSection() {
        dismissAllBottomSheets();
        am.performSleep(2);

        pharmacyDashboardPage.iOSScrollToTextInTableCell("Transfer prescriptions", 50, "up");
        pharmacyDashboardPage.clickTransferPrescriptionsTab();

        try {
            pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
        } catch (AssertionError | Exception e) {
            Reporter.log("iOS: radio button retry after wait");
            am.performSleep(5);
            pharmacyDashboardPage.clickTransferFromNonWalmartPharmacy();
        }
        pharmacyDashboardPage.clickTransferSourceContinueButton();
    }

    @Override
    public void transferPrescriptionForSomeoneElse() {
        getTransferStartedPage.clickTransferForSomeoneElseBtn();
    }

    /**
     * iOS override: dismisses location permission, enters zip code (if present),
     * filters by pharmacy name, and selects the first matching source pharmacy.
     * The zipCode parameter is sourced from test data so each test controls its own search area.
     */
    @Override
    public String selectAndGetFirstAvailableCompetitorStoreDetails(String sourcePharmacyName, String zipCode) {
        selectSourceStorePage.clickDenyLocationPermission();
        selectSourceStorePage.enterSourceStoreZip(zipCode);
        prescriptionHolderDetailsFormPage.clickDoneButtonForIOSKeyboard();
        selectSourceStorePage.clickContinueButton();
        selectSourceStorePage.enterPharmacyNameInSearchField(sourcePharmacyName);
        prescriptionHolderDetailsFormPage.clickDoneButtonForIOSKeyboard();
        selectSourceStorePage.clickFirstAvailableSourceStore();
        String actualSourcePharmacyName = selectSourceStorePage.getFirstSourceStoreNameText();
        selectSourceStorePage.clickContinueButton();
        return actualSourcePharmacyName;
    }

    /**
     * iOS override: adds prescription and clicks Continue.
     * Skips RxNo/DrugName assertions (PharmacyTitleDescriptionAndLinkButtonView not available on iOS).
     */
    @Override
    public void addPrescriptionToTransfer(String drugName, String rxNbr, Boolean addInsurance, Boolean skipInsurance) {
        inputTransferRxDetailsPage.enterDrugName(drugName);
        inputTransferRxDetailsPage.enterPrescriptionNumber(rxNbr);
        inputTransferRxDetailsPage.clickDoneButtonForIOSKeyboard();
        inputTransferRxDetailsPage.clickAddEnteredPrescription();
        am.performSleep(3);

        prescriptionsToTransferDetailsPage.clickContinueButton();
        am.performSleep(2);

        if (!skipInsurance) {
            if (addInsurance) {
                prescriptionsToTransferDetailsPage.clickFindMyInsurance();
            } else {
                prescriptionsToTransferDetailsPage.clickSkipInsurance();
            }
        }
    }

    /**
     * iOS override: selects first available destination store and clicks Continue.
     */
    @Override
    public void selectDestinationStore(String zipCode) {
        am.performSleep(3); // allow destination store list to fully render after source pharmacy selection
        selectDestinationStorePage.selectDestinationStoreByStoreNumber(zipCode);
        selectDestinationStorePage.clickContinueButton();
    }

    /**
     * iOS override: clicks "Request transfer" on the review page.
     * Skips text assertions (base class uses getStoreZipCode which can NPE on iOS).
     */
    @Override
    public void reviewCtOrderDetailsAndPlaceOrder(String patientName, String sourcePharmacyStoreName,
                                                   String destinationStoreNumber, String drugName, String rxNbr) {
        // waitForLoadingToDisappear iterates Android-only XPath queries — use sleep on iOS.
        am.performSleep(2);
        reviewTransferRequestPage.clickRequestTransferButton();
    }

    /**
     * iOS override: navigates back to pharmacy dashboard from success screen
     * and confirms the tracker card is visible.
     */
    @Override
    public void checkCompetitiveTransferSuccess(String patientName) {
        am.performSleep(5); // wait for transfer submission to complete and success screen to appear
        transferRequestSuccessPage.clickBackToPharmacyButton();
        am.performSleep(5); // wait for pharmacy dashboard to reload and tracker card to be visible
        dismissAllBottomSheets();
        Reporter.log("iOS: competitive transfer tracker card visible for " + patientName);
    }

    public void navigateToRefillPrescriptions(){
        pharmacyDashboardPage.mobileScrollToText("Refill Prescriptions", "up");
        pharmacyDashboardPage.clickRefillPrescriptions();
    }

    /**
     * Asserts that the refill review screen shows the discount card coverage with the given member ID.
     */
    public void verifyReviewScreenShowsDiscountCard(String discountMemberId) {
        refillPrescriptionPage.waitForLoadingToDisappear(15);
        refillPrescriptionPage.mobileScrollToText(discountMemberId, "up");
        Assert.assertTrue(
                refillPrescriptionPage.isDiscountCardDisplayedOnReview(),
                "Discount card label not visible on refill review screen");
        Reporter.log("Verified: Discount card coverage shown on review screen (Member ID: " + discountMemberId + ")");
    }

    @Override
    public WebElement scrollDownToText(String text) {
        return rxReadyForPickupAndDeliveryTrackerCardPage.iOSScrollToChildInCell(text, 20, "up");
    }

    @Override
    public boolean isRfpPatientVisible(String patientName) {
        return rxReadyForPickupAndDeliveryTrackerCardPage
                .isIosLabelOnScreen("HWImageWithLabelView.label", patientName);
    }

    @Override
    public void verifyMultiRxInFilling(List<String> patientNameList, List<String> expectedRxNames, List<String> expectedExtimatedPrices, String rxCount) {
        Object multiRxFillingCardHeaderDescriptionText = textValidationUtils.getKeyInObject("pharmacyDashBoardScreen", "MultiRxInFilling", "CardHeaderDescriptionText");
        rxInFillingCardPage.mobileScrollToText("filling " + rxCount, "up");
        Assert.assertTrue(rxInFillingCardPage.getFillStatusCardHeaderText(Integer.parseInt(rxCount), "").contains(rxCount), "RxCount is incorrect in the Header");
        Assert.assertEquals(rxInFillingCardPage.getFillStatusCardSubHeaderText(), multiRxFillingCardHeaderDescriptionText, "Filling status card sub header text is not visible");
        verifyPatientNamesForMultiRxinFilling(patientNameList);
        verifyRxNamesForMultiRxinFilling(expectedRxNames);
        verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
        if (Integer.parseInt(rxCount) > 2) {
            // Scroll to the last patient to bring off-screen prescriptions into the viewport,
            // then re-verify so rows that were not yet visible in the first pass are also covered.
            rxInFillingCardPage.mobileScrollToText(patientNameList.get(patientNameList.size() - 1), "up");
            verifyPatientNamesForMultiRxinFilling(patientNameList);
            verifyRxNamesForMultiRxinFilling(expectedRxNames);
            verifyEstimatedPricesForMultiRxinFilling(expectedExtimatedPrices);
        }
    }
}
