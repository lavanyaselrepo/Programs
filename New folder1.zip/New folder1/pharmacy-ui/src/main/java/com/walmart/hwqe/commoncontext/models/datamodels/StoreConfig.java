package com.walmart.hwqe.commoncontext.models.datamodels;

public class StoreConfig {

    public static final String addressLine1 = "520 Kings Cove Cir";
    public static final String city = "Lafayette";
    public static final String zipCode = "70508";
}
