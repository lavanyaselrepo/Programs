package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FillAndBagInfo {
	public int bagNumber;
    public int action;
    public ArrayList<Integer> fills;

}
