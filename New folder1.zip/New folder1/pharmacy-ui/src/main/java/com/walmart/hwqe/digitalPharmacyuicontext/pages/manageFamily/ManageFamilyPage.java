package com.walmart.hwqe.digitalPharmacyuicontext.pages.manageFamily;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ManageFamilyPage extends MobileBasePage {

    @FindBy(id = "page-heading")
    public WebElement pageHeading;

    @FindBy(xpath = "//p[contains(text(),'Manage your loved one’s prescriptions in one place.')]")
    public WebElement managePrescriptionText;

    @FindBy(xpath = "//h2[text()='My account']")
    @AndroidFindBy(xpath = "//*[contains(@text,'My account')]")
    public WebElement myAccountHeading;

    @FindBy(xpath = "//button[contains(@aria-label,'View prescription information for family member')]")
    public List<WebElement> viewRxButtons;

    @FindBy(xpath = "//div[@class='f4']")
    public List<WebElement> patientNames;

    @FindBy(xpath = "//div[contains(text(),'Date of birth:')]")
    public List<WebElement> patientDobs;

    @FindBy(xpath = "//*[contains(@class, 'mb3 w-100 w-50-l pr3-l')]")
    public List<WebElement> patientContainers;

    @FindBy(xpath = "//button[contains(@aria-label,'Remove dependent access for')]")
    public List<WebElement> removeButtons;

    @FindBy(xpath = "//button[contains(@aria-label,'Cancel caregiver request for')]")
    public List<WebElement> cancelRequestButtons;

    @FindBy(xpath = "//button[@class='w_hhLG w_8nsR w_jDfj']")
    public WebElement popupRemoveOrCancelRequestBtn;

    @FindBy(xpath = "//button[@class='w_hhLG w_DZvO w_jDfj']")
    public WebElement popupCloseOrCancelBtn;

    @FindBy(xpath = "//button[contains(@aria-label,'Accept the request for ')]")
    public List<WebElement> acceptButtons;

    @FindBy(xpath = "//button[contains(@aria-label,'Decline the request for ')]")
    public List<WebElement> declineButtons;

    @FindBy(xpath = "//button[contains(@aria-label,'Revoke caregiver access for ')]")
    public List<WebElement> revokeButtons;

    @FindBy(xpath = "//div[contains(text(),' prescription')]")
    public List<WebElement> prescriptionCounts;

    @FindBy(xpath = "//button[text()='Add a family member']")
    public WebElement addFamilyMemberButton;

    @FindBy(xpath = "//*[text()='Prescription Information']")
    public WebElement prescriptionInfoOption;

    @FindBy(xpath = "//*[text()='Family members']")
    public WebElement familyMembersTxt;

    public ManageFamilyPage(RemoteWebDriver driver) {
        super(driver);
    }

    public String getPageHeading() {
        return getText(pageHeading, "Page Header");
    }

    public boolean isManagePrescriptionTextDisplayed() {
        return isElementDisplayed(managePrescriptionText, "Manage Prescription Text");
    }

    public boolean isPrescriptionsCountTextDisplayed(int patientIndex) {
        if (prescriptionCounts.isEmpty()) {
            return false;
        } else {
            return isElementDisplayed(prescriptionCounts.get(patientIndex), 1);
        }
    }

    public boolean isMyAccountTextDisplayed() {
        return isElementDisplayed(myAccountHeading, 15);
    }

    public boolean isAddFamilyMemberButtonDisplayed() {
        return isElementDisplayed(addFamilyMemberButton, "Add family member button");
    }

    public boolean isFamilyMembersTextDisplayed() {
        waitForCompletePageLoad();
        return isElementDisplayed(familyMembersTxt, 2);
    }

    public String getPatientName(int patientIndex) {
        return getText(patientNames.get(patientIndex), "Patient Name");
    }

    public String getPatientDob(int patientIndex) {
        return getText(patientDobs.get(patientIndex), "Patient DOB");
    }

    public String getPrescriptionsCount(int patientIndex) {
        return getText(prescriptionCounts.get(patientIndex), "Prescriptions Count");
    }

    public boolean isViewRxButtonDisplayed(String expectedPatientName) {
        for (WebElement viewRxBtn : viewRxButtons) {
            if (viewRxBtn.getAccessibleName().contains(expectedPatientName)) {
                return true;
            }
        }
        return false;
    }

    public void clickOnViewRxButton(String expectedPatientName) {
        for (WebElement viewRxBtn : viewRxButtons) {
            if (viewRxBtn.getAccessibleName().contains(expectedPatientName)) {
                click(viewRxBtn);
                break;
            }
        }
    }

    public void clickOnRemoveButton(String expectedPatientName) {
        for (WebElement removeBtn : removeButtons) {
            if (removeBtn.getAccessibleName().contains(expectedPatientName)) {
                click(removeBtn);
                break;
            }
        }
    }

    public void clearAllDependencies() {
        for (WebElement removeBtn : removeButtons) {
            click(removeBtn,"Remove Btn");
            clickOnPopupRemoveOrCancelRequestBtn();
        }
        for (WebElement cancelRequestBtn : cancelRequestButtons) {
            click(cancelRequestBtn,"CancelRequest Btn");
            clickOnPopupRemoveOrCancelRequestBtn();
        }
    }

    public void clickOnAcceptButton(String expectedPatientName) {
        for (WebElement acceptBtn : acceptButtons) {
            if (acceptBtn.getAccessibleName().contains(expectedPatientName)) {
                click(acceptBtn);
                break;
            }
        }
    }

    public void clickOnDeclineButton(String expectedPatientName) {
        for (WebElement declineBtn : declineButtons) {
            if (declineBtn.getAccessibleName().contains(expectedPatientName)) {
                click(declineBtn);
                break;
            }
        }
    }

    public void clickOnRevokeButton(String expectedPatientName) {
        for (WebElement revokeBtn : revokeButtons) {
            if (revokeBtn.getAccessibleName().contains(expectedPatientName)) {
                click(revokeBtn);
                break;
            }
        }
    }

    public void clickOnAddFamilyMemberButton() {
        click(addFamilyMemberButton, "Add family member button");
    }

    public void clickOnPopupRemoveOrCancelRequestBtn() {
        click(popupRemoveOrCancelRequestBtn, "Popup Remove/CancelRequest button");
    }

    public void clickOnPopupRemoveBtn() {
        click(popupCloseOrCancelBtn, "Popup Close/Cancel button");
    }

}
