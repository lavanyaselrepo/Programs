package com.walmart.hwqe.commoncontext.constants;

public enum DeliveryStatus {
    ELIGIBLE,
    INELIGIBLE,
    STORE_INELIGIBLE
}
