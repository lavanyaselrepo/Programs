package com.walmart.hwqe.digitalPharmacyuicontext.pages.fillDetails;

@lombok.Getter
@lombok.Setter
public class FillDetails {
    public String drugName;
    public String estimatedPrice;
    public String rxNumber;
    public String patientName;
    public String prescriberName;
    public String prescriptionDate;
    public String quantity;
    public String supply;
    public String instructions;
}
