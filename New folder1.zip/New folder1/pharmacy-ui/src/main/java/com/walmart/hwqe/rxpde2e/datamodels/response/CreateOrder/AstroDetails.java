package com.walmart.hwqe.rxpde2e.datamodels.response.CreateOrder;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class AstroDetails {
    public OrderSummary orderSummary;
    public OrderDetails orderDetails;
    public ArrayList<AstroLog> astro_logs;
    public Cart cart;
}
