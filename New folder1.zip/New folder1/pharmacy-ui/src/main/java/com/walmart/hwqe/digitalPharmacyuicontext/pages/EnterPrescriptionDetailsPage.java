package com.walmart.hwqe.digitalPharmacyuicontext.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class EnterPrescriptionDetailsPage extends MobileBasePage {
    @FindBy(id = "import-rx-prescription-number")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Prescription number')]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label,'Prescription number')]")
    public WebElement rxNumberInput;

    @FindBy(id = "import-rx-store-number")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,'Store number')]/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label,'Store number')]")
    public WebElement storeNumberInput;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/continue_button")
    @iOSXCUITFindBy(accessibility = "PrimaryAndLinkButtonView.primaryActionButton")
    public WebElement continueBtn;

    @FindBy(xpath = "//div[@role='dialog']//h2[contains(text(),'Invalid Rx and Store Number Combination.')]")
    @AndroidFindBy(id = "com.walmart.android.debug:id/alertTitle")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Invalid Rx and Store Number Combination.']")
    public WebElement invalidRxAndStoreNumberDialog;

    @FindBy(xpath = "//button[text()='OK']")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(accessibility = "OK")
    public WebElement okDialogButton;

    public EnterPrescriptionDetailsPage(RemoteWebDriver appDriver) {
        super(appDriver);
    }

    public EnterPrescriptionDetailsPage enterRxNumber(String rxNum) {
        sendText(rxNumberInput, rxNum);
        return this;
    }

    public EnterPrescriptionDetailsPage enterStoreNumber(String storeNum) {
        sendText(storeNumberInput, storeNum);
        return this;
    }

    public void clickContinueBtn() {
        click(continueBtn);
    }

    public boolean isInvalidRxAndStoreNumberDialogDisplayed() {
        return isElementDisplayed(invalidRxAndStoreNumberDialog, 5);
    }

    public void clickOkDialogButton() {
        click(okDialogButton);
    }

}
