package com.walmart.hwqe.commoncontext.stagingIssues.datamodels;
import lombok.*;

@Getter
@Setter
public class CompleteStagingIssueResponse {

	public int bagNumber;
    public String colorAbbr;
    public String colorCode;
    public int wcbDay;
    public int bagDispenseType;
}
