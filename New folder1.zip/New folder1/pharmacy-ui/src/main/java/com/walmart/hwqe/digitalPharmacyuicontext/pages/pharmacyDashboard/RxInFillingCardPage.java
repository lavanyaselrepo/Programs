package com.walmart.hwqe.digitalPharmacyuicontext.pages.pharmacyDashboard;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class RxInFillingCardPage extends FillStatusTrackerCardPage {

    public RxInFillingCardPage(RemoteWebDriver driver) {
        super(driver);
    }

    String RxInFillParentCardAccessibility = "FillingRxContainerView.stackView";

    // Differentiator: header_title containing 'filling' identifies the filling card among all card types
    // (all tracker card types share the same container resource-ids, only header_title text differs).
    // FILL_CARD navigates from that header up to card_parent, scoping all descendant locators to this card only.
    private static final String FILL_HEADER = "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header_title' and contains(@text,'filling')]";
    private static final String FILL_CARD = FILL_HEADER + "/ancestor::android.widget.LinearLayout[@resource-id='com.walmart.android.debug:id/card_parent']";

    // iOS XPath templates
    private static final String IOS_XPATH_PRICE_BY_DRUG_TEMPLATE =
            "//XCUIElementTypeButton[contains(@label,'%s')]"
            + "//XCUIElementTypeStaticText[@name='FillingInfoView.estPriceLabel']";
    private static final String IOS_XPATH_FILL_DETAILS_BTN_TEMPLATE =
            "//XCUIElementTypeButton[contains(@label,'%s')]";

    // Android XPath templates
    private static final String ANDROID_XPATH_PRICE_BY_DRUG_TEMPLATE =
            "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/drug_name'"
            + " and contains(@text,'%s')]"
            + "/..//android.widget.TextView[@resource-id='com.walmart.android.debug:id/estimated_price']";
    private static final String ANDROID_XPATH_FILL_DETAILS_BTN_TEMPLATE =
            "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/drug_name'"
            + " and contains(@text,'%s')]"
            + "/..//android.widget.ImageView[@resource-id='com.walmart.android.debug:id/prescription_details']";

    @AndroidFindBy(xpath = FILL_HEADER)
    @iOSXCUITFindBy(accessibility = "FillSectionHeaderView.headerLabel")
    @FindBy(id = "heading-FILLING")
    WebElement fillStatusCardHeaderText;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/header_description']")
    @iOSXCUITFindBy(accessibility = "FillSectionHeaderView.subheaderLabel")
    @FindBy(id = "sub-heading-FILLING")
    WebElement fillStatusCardSubHeaderText;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/patient_name']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"FillingCustomerPrescriptionsView.customerHeaderView\"]//XCUIElementTypeStaticText[@name=\"HWImageWithLabelView.label\"]")
    @FindBy(xpath = "//*[contains(@id,'patient-name-fill-group-filling')]")
    WebElement patientName;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/patient_name']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"PatientHWImageWithLabelView\"]//XCUIElementTypeStaticText[@name=\"HWImageWithLabelView.label\"]")
    @FindBy(xpath = "//*[contains(@id,'patient-name-fill-group-filling')]")
    List<WebElement> patientNames;

    @iOSXCUITFindBy(accessibility = "pet")
    @FindBy(id = "refill-button-prescription-reminders")
    WebElement petIcon;

    @FindBy(id = "refill-button-prescription-reminders")
    WebElement humanIcon;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/drug_name']")
    @iOSXCUITFindBy(accessibility = "FillingInfoView.drugNameLabel")
    @FindBy(xpath = "//*[contains(@id,'formatted-drug-name-fill-group-filling')]")
    WebElement rxName;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/drug_name']")
    @iOSXCUITFindBy(accessibility = "FillingInfoView.drugNameLabel")
    @FindBy(xpath = "//*[contains(@id,'formatted-drug-name-fill-group-filling')]")
    List<WebElement> rxNames;

    // Fixed: was incorrectly mapped to estimated_time; correct resource-id is estimated_price
    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/estimated_price']")
    @iOSXCUITFindBy(accessibility = "FillingInfoView.estPriceLabel")
    @FindBy(xpath = "//*[contains(@id,'price-fill-group-filling')]")
    WebElement estimatedPrice;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/estimated_price']")
    @iOSXCUITFindBy(accessibility = "FillingInfoView.estPriceLabel")
    @FindBy(xpath = "//*[contains(@id,'price-label-fill-group-filling')]")
    List<WebElement> rxEstimatedPrices;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/estimated_time']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"FillingEstTimePharmacyImageWithLabelView\"]//XCUIElementTypeStaticText[@name=\"HWImageWithLabelView.label\"]")
    @FindBy(xpath = "//*[contains(@id,'estimated-ready-time-fill-group-filling')]")
    WebElement estimatedTime;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.ImageView[@resource-id='com.walmart.android.debug:id/prescription_details']")
    @iOSXCUITFindBy(accessibility = "FillingInfoView.arrowImageView")
    @FindBy(xpath = "//*[contains(@id,'chevron-icon-fill-group-filling')]")
    WebElement fillDetailsArrowCTA;

    @AndroidFindBy(xpath = FILL_CARD + "//android.widget.TextView[@resource-id='com.walmart.android.debug:id/prescription_count_suffix']")
    @iOSXCUITFindBy(accessibility = "HWPatientFillsCountView.fillsLabel")
    @FindBy(xpath = "//*[contains(@id,'prescription-label-fill-group-filling')]")
    WebElement prescriptionsCount;

    public String multiRxFillingHeaderTxt(int rxCount) {
        return "filling " + rxCount + " prescriptions";
    }
    public String fillingCardHeaderDescriptionTxt = "Track the progress of your prescription refills.";

    public String prescriptionCountTxt(int rxCount) {
        return rxCount > 1 ? rxCount + " prescriptions" : rxCount + " prescription";
    }

    public String getEstimatedTime() {
        return getText(estimatedTime);
    }

    public String getEstimatedPrice() {
        return getText(estimatedPrice);
    }

    public String getFillStatusCardHeaderText(int rxCount, String singleRxFillingHeaderText) {
        String fillingStr = "";
        if(rxCount==1) fillingStr = singleRxFillingHeaderText;
        else fillingStr = multiRxFillingHeaderTxt(rxCount);

        if (remoteDriver instanceof IOSDriver) {
            mobileScrollToText(fillingStr, "up");
        } else if (remoteDriver instanceof AndroidDriver) {
            if (!isElementDisplayed(fillStatusCardHeaderText)) {
                androidScrollToTextContains(fillingStr);
            }
        } else {
            scrollToTextWithLoop(fillingStr);
        }
        return getText(fillStatusCardHeaderText);
    }

    public boolean isFillStatusCardSubHeaderTextVisible() {
        return isElementDisplayed(fillStatusCardSubHeaderText);
    }

    public String getFillStatusCardSubHeaderText() {
        return getText(fillStatusCardSubHeaderText);
    }

    public void clickFillDetailsArrowCTA() {
        click(fillDetailsArrowCTA);
    }

    public String getEstimatedPriceForDrug(String drugName) {
        if (remoteDriver instanceof IOSDriver) {
            WebElement priceEl = remoteDriver.findElement(
                    By.xpath(String.format(IOS_XPATH_PRICE_BY_DRUG_TEMPLATE, drugName)));
            return getText(priceEl);
        } else {
            WebElement priceEl = remoteDriver.findElement(
                    By.xpath(String.format(ANDROID_XPATH_PRICE_BY_DRUG_TEMPLATE, drugName)));
            return getText(priceEl);
        }
    }

    public void clickFillDetailsArrowCTAForDrug(String drugName) {
        if (remoteDriver instanceof IOSDriver) {
            WebElement rowButton = remoteDriver.findElement(
                    By.xpath(String.format(IOS_XPATH_FILL_DETAILS_BTN_TEMPLATE, drugName)));
            click(rowButton);
        } else {
            WebElement arrowEl = remoteDriver.findElement(
                    By.xpath(String.format(ANDROID_XPATH_FILL_DETAILS_BTN_TEMPLATE, drugName)));
            click(arrowEl);
        }
    }

    public String getRxName() {
        return getText(rxName);
    }

    public String getPatientNameOnFillTrackerCard() {
        return getText(patientName);
    }

    public String getRxNameOnFillTrackerCard() {
        return getText(rxName);
    }

    public String getRxEstimatedPrice() {
        return getText(rxEstimatedPrice);
    }

    public String getPrescriptionsCount() {
        return getText(prescriptionsCount);
    }

    public boolean isFillDetailsArrowCTAVisible() {
        return isElementDisplayed(fillDetailsArrowCTA);
    }

    public boolean isPetIconVisible() {
        return isElementDisplayed(petIcon);
    }

    public boolean isHumanIconVisible() {
        return isElementDisplayed(humanIcon);
    }
    public List<String> getVisibleRxNamesList(){
        List<String> rxList = new ArrayList<>();
        for (WebElement element : rxNames) {
            if (isElementDisplayed(element)) {
                rxList.add(getText(element).toLowerCase());
            }
        }
        return rxList;
    }

    public List<String> getVisibleEstimatedRxPricesList(){
        List<String> rxPriceList = new ArrayList<>();
        for (WebElement element : rxEstimatedPrices) {
            if (isElementDisplayed(element)) {
                rxPriceList.add(getText(element));
            }
        }
        return rxPriceList;
    }

    public List<String> getPatientNames(){
        super.isElementDisplayed(patientName);
        List<String> patientNameList = new ArrayList<>();
        for (WebElement element: patientNames){
            if (isElementDisplayed(element)) {
                patientNameList.add(getText(element).toUpperCase());
            }
        }
        return patientNameList;
    }
    public boolean isFillStatusCardHeaderForFillingStatusVisible(){
        scrollToElement(fillStatusCardHeaderText);
        if (!isElementDisplayed(fillStatusCardHeaderText)) {
            new FluentWait<>(appDriver)
                    .withTimeout(Duration.ofSeconds(180))
                    .pollingEvery(Duration.ofSeconds(5))
                    .ignoring(NoSuchElementException.class)
                    .until(d -> {
                        refreshPage();
                        scrollToElement(fillStatusCardHeaderText);
                        return isElementDisplayed(fillStatusCardHeaderText);
                    });
        }
        return isElementDisplayed(fillStatusCardHeaderText);
    }
}
