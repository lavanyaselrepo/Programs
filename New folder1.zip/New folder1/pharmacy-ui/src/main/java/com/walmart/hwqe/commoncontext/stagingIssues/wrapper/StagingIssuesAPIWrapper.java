package com.walmart.hwqe.commoncontext.stagingIssues.wrapper;

import com.walmart.hwqe.commoncontext.stagingIssues.datamodels.CompleteStagingIssueRequest;
import com.walmart.hwqe.commoncontext.stagingIssues.datamodels.CompleteStagingRequest;
import com.walmart.hwqe.commoncontext.stagingIssues.datamodels.FillAndBagInfo;
import com.walmart.hwqe.commoncontext.stagingIssues.datamodels.StartStagingIssueRequest;
import com.walmart.hwqe.commoncontext.utils.PropertyReaderHelper;
import com.walmart.hwqe.commons.apicontext.ServiceRequest;
import com.walmart.hwqe.commons.apicontext.ServiceResponse;
import com.walmart.hwqe.commons.basemanager.AutomationManager;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.commons.utilities.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class StagingIssuesAPIWrapper {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReaderHelper.getInstance();

    private HashMap<String, String> getHeaders(String storeNbr, String error) {
        HashMap<String, String> headers = new HashMap<>(); 
        String requestTrackingId = java.util.UUID.randomUUID().toString();
        headers.put("StoreNumber", storeNbr);
        headers.put("DeviceName", "AUTOMATION");
        headers.put("UserId","RXPDQE");        
        headers.put("x-hnw-rx-req-track-id", requestTrackingId);
        headers.put("Source","RXPDAPP");
        headers.put("Authorization", prop.getProperty("rxpd.dispenseService")); 
        headers.put("Content-Type", "application/json");
        
        if (error.equals("Unauthorized"))
        	headers.remove("Authorization");
        else if (error.equals("MissingHeader"))
        	headers.remove("StoreNumber");
        else if (error.equals("InvalidHeader"))
        	headers.put("Source","");
        else if (error.equals("ServerError"))
        	headers.put("Authorization", "Basic ===");
        else if (error.equals("Conflict"))
        	headers.put("UserId","RXPD"); 
        return headers;
    }
    
    public ServiceResponse StartStagingIssue(String storeNbr, String purchaseOrderId, String error) {
    	ServiceRequest req = new ServiceRequest();
    	StartStagingIssueRequest StartStagingIssueRequest = new StartStagingIssueRequest();
    	StartStagingIssueRequest.setPurchaseOrderId(purchaseOrderId);
    	if (error.equals("InvalidRequest")){
    		StartStagingIssueRequest.setPurchaseOrderId("");
        }
    	req.setRequestPayload(StartStagingIssueRequest);
    	
    req.setHeaders(getHeaders(storeNbr, error));
    req.setUrl(prop.getProperty("rxpd.startStagingIssue.url").replace("xxxx", storeNbr));
    Reporter.log("Request endpoint: " + req.getUrl());
    Reporter.logJSON("HTTP Request", StringUtils.convertToJson(StartStagingIssueRequest));
    ServiceResponse resp = am.getRestContext().performPost(req);
    Reporter.log("Response Status Code: " + resp.getStatusCode());
    Reporter.log("Response Status Desc: " + resp.getStatusDesc());
    Reporter.logJSON("HTTP Response", resp.getDataResponse());
    return resp;
    	
    }
    
    public ServiceResponse CompleteStagingIssue(String storeNbr, String purchaseOrderId, String packageToteId, int issueTypeCode, 
    		int stagingBagNumber, int fillId, int bagAction, int bagNumber, String error) {
    	ServiceRequest req = new ServiceRequest();
    	CompleteStagingIssueRequest CompleteStagingIssueRequest = new CompleteStagingIssueRequest();
    	CompleteStagingIssueRequest.setPurchaseOrderId(purchaseOrderId);
    	CompleteStagingIssueRequest.setPackageToteId(packageToteId);
    	CompleteStagingIssueRequest.setIssueTypeCode(issueTypeCode);
    	CompleteStagingIssueRequest.setStagingBagNumber(stagingBagNumber);
    	ArrayList<FillAndBagInfo> fillAndBagInfo = new ArrayList<FillAndBagInfo>();
    	FillAndBagInfo fillAndBagInfoItem = new FillAndBagInfo();
    	fillAndBagInfoItem.setAction(bagAction);
    	fillAndBagInfoItem.setBagNumber(bagNumber);
    	ArrayList<Integer> fills = new ArrayList<Integer>();
    	fills.add(fillId);
    	fillAndBagInfoItem.setFills(fills);
    	fillAndBagInfo.add(fillAndBagInfoItem);
    	CompleteStagingIssueRequest.setFillAndBagInfo(fillAndBagInfo);
    	if (error.equals("InvalidRequest")){
    		CompleteStagingIssueRequest.setPurchaseOrderId("");
        }
    	req.setRequestPayload(CompleteStagingIssueRequest);
    	
    req.setHeaders(getHeaders(storeNbr, error));
    req.setUrl(prop.getProperty("rxpd.completeStagingIssue.url").replace("xxxx", storeNbr));
    Reporter.log("Request endpoint: " + req.getUrl());
    Reporter.logJSON("HTTP Request", StringUtils.convertToJson(CompleteStagingIssueRequest));
    ServiceResponse resp = am.getRestContext().performPost(req);
    Reporter.log("Response Status Code: " + resp.getStatusCode());
    Reporter.log("Response Status Desc: " + resp.getStatusDesc());
    Reporter.logJSON("HTTP Response", resp.getDataResponse());
    return resp;
    	
    }

    public String getStoreSpecificUri(String baseUrl, int storeNumber){
        String site = ""+storeNumber;
        if(site.length()==4)
            site = "0"+site;
        baseUrl = baseUrl.replace("xxxxx", site);
        return baseUrl;
    }

    private HashMap<String, String> getHeadersConsistentWithAssignAndFetch(int storeNumber) {
        // these are process Headers when multiple SAPS APIs are used in conjunction to maintain data consistency.
        // Properties auto-loaded by PropertyReaderHelper static initializer
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("RxPDMobileApp.Authorization"));
        headers.put("Source", "RXPDAPP");
        headers.put("StoreNumber", storeNumber+"");
        headers.put("UserId", prop.getProperty("rxonemobileapp.user_id") );
        headers.put("DeviceName", prop.getProperty("rxonemobileapp.api.DeviceName"));
        return headers;
    }

    public ServiceResponse completeStaging(String storeNbr, String packageToteId,
                                                int stagingBagNumber, int bagNumber, int fillId) {
        ServiceRequest req = new ServiceRequest();
        CompleteStagingRequest completeStagingRequest = new CompleteStagingRequest();
        completeStagingRequest.setPackageToteId(packageToteId);
        completeStagingRequest.setStagingBagNumber(stagingBagNumber);

        CompleteStagingRequest.fillAndReleaseBagInfoList fillAndReleaseBagInfoItem = new CompleteStagingRequest.fillAndReleaseBagInfoList();
        fillAndReleaseBagInfoItem.setBagNumber(bagNumber);
        List<String> fillIdList = new ArrayList<>();
        fillIdList.add(fillId+"");
        fillAndReleaseBagInfoItem.setFills(fillIdList);

        List<CompleteStagingRequest.fillAndReleaseBagInfoList> fillAndReleaseBagInfoItemList = new ArrayList<>();
        fillAndReleaseBagInfoItemList.add(fillAndReleaseBagInfoItem);

        completeStagingRequest.setFillAndReleaseBagInfo(fillAndReleaseBagInfoItemList);

        req.setHeaders(getHeadersConsistentWithAssignAndFetch(Integer.parseInt(storeNbr)));
        req.setUrl(getStoreSpecificUri(prop.getProperty("rxpd.completeStaging.url"), Integer.parseInt(storeNbr)));
        req.setRequestPayload(completeStagingRequest);
        Reporter.log("Request endpoint: " + req.getUrl());
        Reporter.logJSON("HTTP Request", StringUtils.convertToJson(completeStagingRequest));
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.log("Response Status Code: " + resp.getStatusCode());
        Reporter.log("Response Status Desc: " + resp.getStatusDesc());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }


    public ServiceResponse completeStagingIssueAfterAssignAndFetchIssueInfo(String storeNbr, String purchaseOrderId, String packageToteId, int issueTypeCode,
                                                int stagingBagNumber, int fillId, int bagAction, int bagNumber) {
        ServiceRequest req = new ServiceRequest();
        CompleteStagingIssueRequest CompleteStagingIssueRequest = new CompleteStagingIssueRequest();
        CompleteStagingIssueRequest.setPurchaseOrderId(purchaseOrderId);
        CompleteStagingIssueRequest.setPackageToteId(packageToteId);
        CompleteStagingIssueRequest.setIssueTypeCode(issueTypeCode);
        CompleteStagingIssueRequest.setStagingBagNumber(stagingBagNumber);
        ArrayList<FillAndBagInfo> fillAndBagInfo = new ArrayList<FillAndBagInfo>();
        FillAndBagInfo fillAndBagInfoItem = new FillAndBagInfo();
        fillAndBagInfoItem.setAction(bagAction);
        fillAndBagInfoItem.setBagNumber(bagNumber);
        ArrayList<Integer> fills = new ArrayList<Integer>();
        fills.add(fillId);
        fillAndBagInfoItem.setFills(fills);
        fillAndBagInfo.add(fillAndBagInfoItem);
        CompleteStagingIssueRequest.setFillAndBagInfo(fillAndBagInfo);
        req.setRequestPayload(CompleteStagingIssueRequest);

        req.setHeaders(getHeadersConsistentWithAssignAndFetch(Integer.parseInt(storeNbr)));
        req.setUrl(getStoreSpecificUri(prop.getProperty("rxpd.completeStagingIssue.url.common"), Integer.parseInt(storeNbr)));
        Reporter.log("Request endpoint: " + req.getUrl());
        Reporter.logJSON("HTTP Request", StringUtils.convertToJson(CompleteStagingIssueRequest));
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.log("Response Status Code: " + resp.getStatusCode());
        Reporter.log("Response Status Desc: " + resp.getStatusDesc());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }
    
}
