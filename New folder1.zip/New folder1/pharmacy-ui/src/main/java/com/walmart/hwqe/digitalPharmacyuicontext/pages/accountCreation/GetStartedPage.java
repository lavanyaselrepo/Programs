package com.walmart.hwqe.digitalPharmacyuicontext.pages.accountCreation;


import com.walmart.hwqe.digitalPharmacyuicontext.pages.MobileBasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class GetStartedPage extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='Phone number']/android.widget.FrameLayout/android.widget.EditText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Pharmacy']")
    @FindBy(xpath = "(//a[contains(text(), 'Pharmacy')])[1]")
    public WebElement enterMobileInput;

    @AndroidFindBy(xpath = "com.walmart.android.debug:id/continue_button")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Pharmacy']")
    @FindBy(xpath = "(//a[contains(text(), 'Pharmacy')])[1]")
    public WebElement continueButton;

    public GetStartedPage(RemoteWebDriver driver) {
        super(driver);
    }

    public void enterPhoneNoText(String mobileNo) {

        enterMobileInput.sendKeys(mobileNo);
    }

    public void clickContinueButton() {
        click(continueButton);
    }
}
