package com.walmart.hwqe.digitalPharmacyuicontext.platformmanagers;

import com.walmart.hwqe.commons.utilities.Reporter;
import com.walmart.hwqe.digitalPharmacyuicontext.pageManagers.BasePageApplicationManager;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * Captures screenshot for failed tests before @AfterMethod cleanup executes.
 */
public class DigitalPharmacyFailureScreenshotListener implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        Object testInstance = result.getInstance();
        if (!(testInstance instanceof DigitalPharmacyTestBase)) {
            return;
        }

        DigitalPharmacyTestBase testBase = (DigitalPharmacyTestBase) testInstance;
        BasePageApplicationManager basePageApplicationManager = testBase.getBasePageApplicationManager();
        if (basePageApplicationManager == null) {
            return;
        }

        try {
            basePageApplicationManager.logScreenShot("Screen Failure");
        } catch (Exception exception) {
            Reporter.log("Failed to capture failure screenshot: " + exception.getMessage());
        }
    }
}
