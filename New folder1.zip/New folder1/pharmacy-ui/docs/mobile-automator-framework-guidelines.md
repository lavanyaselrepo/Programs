# Framework Adoption Guidelines for Mobile Test Automation

**This content is now maintained in Cursor rules and skills.** You don’t need to read or update this file for the AI; it will use the project rule and skill when working in this repo.

## For AI agents (Cursor)

- **Workflow and framework adaptation:** Use the **rule** `.cursor/rules/mobile-automator-mcp.mdc` and the **skill** `.cursor/skills/mobile-automator-mcp-workflow/` (SKILL.md + framework-patterns.md) in this repo. They define when to fetch execution guidelines, execute vs plan vs create, the post-execution pipeline, and all framework patterns.
- **Execution on device:** Fetch the MCP resource first: `fetch_mcp_resource` with `server: "mobile-automator"` (or `"user-mobile-automator"`), `uri: "guidelines://mobile-test-automation"`. That resource has baseline steps, when to ask for user data, and platform details.

## For humans

- **Execution reference:** Exposed as the MCP resource `guidelines://mobile-test-automation` (source: mobile-automator repo, `guidelines/mobile-automator-execution-guidelines.md`).
- **Framework patterns:** See this repo’s `.cursor/skills/mobile-automator-mcp-workflow/framework-patterns.md` for reusability, Page Objects, naming, test data JSON, and completion checklist.
