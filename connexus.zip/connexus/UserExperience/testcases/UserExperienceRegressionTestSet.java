package connexus.UserExperience.testcases;

import connexus.UserExperience.testscripts.UserExperienceRegressionTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceRegressionTestSet {

    UserExperienceRegressionTestScript userExperienceRegressionTestScript=new UserExperienceRegressionTestScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils=new ConnexusAppUtils();
    boolean flagUpdated = false;


    @BeforeClass
    public void performLogin(){
        System.out.println("Welcome: Before class");
        connexusAppUtils.startAppiumServer();
        CheckAndSetPreConditions();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        connexusAppUtils.updateStoreState("AR");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 27247 (Redesign Patient Maintenance Screen) to TRUE
        connexusAppUtils.readAndUpdateFlag("27247 ", "TRUE");

        //Verify and set the flag 27267 (Insulin Indicator Flag ) to TRUE
        connexusAppUtils.readAndUpdateFlag("27267 ", "TRUE");

        //Verify and set the flag 14400 (Yearly Validation ) to True
        connexusAppUtils.readAndUpdateFlag("14400 ", "TRUE");
    }


    @AfterClass
    public void tearDown(){
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
          *HWQEAUTO-10162_To validate whether by default allergy section and medical condition should be "Patient Not Present" for new patients.

          * Author: Priyanka(p0j01ks)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "To validate whether by default allergy section and medical condition should be \"Patient Not Present\" for new patients",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_345_ERX_VerifyDefaultAllergyNMedicalConditionsForeNewPatient(Map<String, String> inputData) {

        userExperienceRegressionTestScript.initializeTestCase(true);

        // Generate random patient name only (do NOT create patient in Connexus)
        userExperienceRegressionTestScript.generateRandomPatientForErx();

        // Send eRx for that patient name → Connexus receives it as a NEW patient
        userExperienceRegressionTestScript.sendErxMessage("surescriptNewRequst",inputData);

        // It should appear in orders with Resolve status and Patient Name Mismatch problem
        // Perform order search with patient name and verify queue + problem
        userExperienceRegressionTestScript.verifyErxOrderInResolveQueueWithNameMismatch();

        // Open order in resolution screen → search for patient with DOB → HOST LookUp
        userExperienceRegressionTestScript.openResolutionAndSearchPatientWithDob(inputData);

        // Validate patient name, DOB, Allergies + Medical Conditions in PMS
        userExperienceRegressionTestScript.validatePatientDetailsInPMS(inputData);

        // Back on Resolution screen: patient populated → click Use Selected Patient
        userExperienceRegressionTestScript.useSelectedPatientInResolution();

        //Check for Allergy and Disease codes in Database
        userExperienceRegressionTestScript.verifyAllergyNDiseaseDetailsInDb();

        //Check For Patient Not Present in Medical conditions in Input
        userExperienceRegressionTestScript.verifyPTMS_AllergyConditions(WorkQueue.INPUT);

        //perform Input
        userExperienceRegressionTestScript.performInput(inputData);

        //Check For Patient Not Present in Medical conditions in FourPoint
        userExperienceRegressionTestScript.verifyPTMS_AllergyConditions(WorkQueue.FOUR_POINT);

        //perform Four Point
        userExperienceRegressionTestScript.perform4Point(false);

        //Check For Patient Not Present in Medical conditions in CHK_DUR (only if queue is available)
        if (userExperienceRegressionTestScript.isRxInWorkQueue(WorkQueue.CHK_DUR)) {
            userExperienceRegressionTestScript.verifyPTMS_AllergyConditions(WorkQueue.CHK_DUR);

            //perform Check Dur
            userExperienceRegressionTestScript.performChkDUR();
        }

        userExperienceRegressionTestScript.verifyRxInFillingQueue();

        Reporter.log("Default allergy section and medical condition should be \"Patient Not Present\" for new patients is Verified");
    }

    /*----------------------------------------------------------------------------------------------------------
           *HWQEAUTO-9854_To verify that the Insulin dependent and Insulin Pump Checkboxes are not displayed in the Annual wizard Screen when

           Flag 27267 False.

           * Author: Aayushi(A0S0FQJ)
           * JIRA Testcase id : HWPHME2E-343
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "To verify that the Insulin dependent and Insulin Pump Checkboxes are not displayed in the Annual wizard Screen",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_343_tc_03_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Not_Displayed_In_Annual_Wizard(Map<String, String> inputData) {
        System.out.println("<<<tc_03_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Not_Displayed_In_Annual_Wizard>>>");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27267", "FALSE");
        userExperienceRegressionTestScript.initializeTestCase(flagUpdated);
        //Create a new patient
        userExperienceRegressionTestScript.createNewPatient(inputData);

        //Complete DropOff
        userExperienceRegressionTestScript.verifyInsulinPumpCheckboxesAreNotDisplayedInAnnualWizard();

        System.out.println("<<<tc_03_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Not_Displayed_In_Annual_Wizard>>>");

    }
    /*----------------------------------------------------------------------------------------------------------
            *HWQEAUTO-9656_To Verify that the annual validation wizard is not displayed when the flag 14400 is False.
            *

            * Author: Aayushi(A0S0FQJ)
            * JIRA Testcase id : HWPHME2E-341
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "To verify that the Patient Annual Wizard Not Displayed When FLag 14400 is False",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_341_tc_04_Verify_Patient_Annual_Wizard_Not_Displayed(Map<String, String> inputData) {
        System.out.println("<<<tc_04_Verify_Patient_Annual_Wizard_Not_Displayed>>>");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("14400", "FALSE");
        userExperienceRegressionTestScript.initializeTestCase(flagUpdated);
        //Create a new patient
        userExperienceRegressionTestScript.createNewPatient(inputData);


        //Complete DropOff
        userExperienceRegressionTestScript.verifyPatientAnnualWizardNotDisplayed();

        connexusAppUtils.readAndUpdateFlag("14400", "TRUE");
        System.out.println("<<<tc_04_Verify_Patient_Annual_Wizard_Not_Displayed>>>");

    }

    /*----------------------------------------------------------------------------------------------------------
            *HWQEAUTO-9778_To Verify that the Insulin dependent and Insulin pump check boxes are displayed and are disabled in annual validation screen for a new patient
            *
            * Author: Aayushi(A0S0FQJ)
            * HWPHME2E-342
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "To Verify that the Insulin dependent and Insulin pump check boxes are displayed and are disabled in annual validation screen for a new patient",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_342_tc_06_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Disabled(Map<String, String> inputData) {
        System.out.println("<<<tc_06_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Disabled>>>");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("27267", "TRUE");
        userExperienceRegressionTestScript.initializeTestCase(flagUpdated);
        //Create a new patient
        userExperienceRegressionTestScript.createNewPatient(inputData);
        //Complete DropOff
        userExperienceRegressionTestScript.verifyInsulinDependentInpulinPumpCheckboxesAreDisbaled();

        System.out.println("<<<tc_06_Verify_Insulin_Dependent_Insulin_Pump_Checkboxes_Are_Disabled>>>");

    }

    /*----------------------------------------------------------------------------------------------------------
            *HWQEAUTO-21299_To Verify that the Insulin dependent and Insulin pump check boxes are displayed and are disabled in annual validation screen for a new patient
            *

            * Author: Aayushi(A0S0FQJ)
            * HWPHME2E-259
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify allergy is saved to CDB when allergy is added_WKAllergy ON_NDS",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_259_tc_07_Verify_Allergy_Saved_To_CDB(Map<String, String> inputData) {
        System.out.println("<<<tc_07_Verify_Allergy_Is_Saved_To_CDB>>>");

        userExperienceRegressionTestScript.initializeTestCase(false);
        //Create a new patient
        userExperienceRegressionTestScript.createNewPatient(inputData);

        //Complete DropOff
        userExperienceRegressionTestScript.verifyPatientAllergyIsSavedToCDB();

        System.out.println("<<<tc_07_Verify_Allergy_Is_Saved_To_CDB>>>");

    }


    /*----------------------------------------------------------------------------------------------------------
     *HWQEAUTO-10132| To Validate Unnecessary central calls are not happening on clicking on Edit button and cancel button in a TP view
     *

     * Author: Rishabh Madan (R0M0F2X)
     * HWPHME2E-285
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = false, description = "To Validate Unnecessary central calls are not happening on clicking on Edit button and cancel button in a TP view",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UserExperience/UserExperienceTestBook.json", sheetName = "userExperience")
    public void HWPHME2E_285_tc_08_Validate_unnecessary_Call_To_DB(Map<String, String> inputData) {
        System.out.println("<<<tc_08_Validate_unnecessary_Call_To_DB>>>");

       userExperienceRegressionTestScript.initializeTestCase(true);
        //Create a new patient
        userExperienceRegressionTestScript.createNewPatient(inputData,1);

        //Validate Unnecessary central calls are not happening on clicking on Edit button and cancel button in a TP view.
        userExperienceRegressionTestScript.validateUnnecessaryCentralCalls();

        System.out.println("<<<ttc_08_Validate_unnecessary_Call_To_DB>>>");

    }
}



