package connexus.UserExperience.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import opticaltests.patienttests.datamodels.cosmos.PatientDB;
import org.testng.Assert;
import rdm.centralpatient.datamodels.response.patientapi.PatientInsuranceInfo;

import java.util.Map;

public class UserExperienceRegressionTestScript extends ConnexusTestScripts {
    public UserExperienceRegressionTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    String patientNotPresentSelected ="Patient Not Present Condition Selected in Allergies and Medical Conditions ";
    String patientNotPresentNotSelected ="Patient Not Present Condition Not Selected in Allergies and Medical Conditions ";


    public void CheckTabSequenceForPMSScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();

            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(name[0]+ "," + name[1]);
                patientSearchPage.inputPatientDob(inputData.get("DOB"));
                patientSearchPage.clickSearchNow();
                patientSearchPage.hostSearchPatient();
                patientSearchPage.clickNew();

                //Create Patient
                patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
                patientMaintenancePage.inputPatientMiddleName("Middle");
                //patientMaintenancePage.sendHotKeys(Keys.TAB);
                Boolean result = patientMaintenancePage.isDobSelected();
                if (result) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Date of birth field selected in Tab Sequence ");
                    softAssert.assertTrue(true, "Date Of Birth selected in Tab Sequence");
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                    softAssert.fail("Tab Sequence incorrect");
                }
                patientMaintenancePage.clickExit();
                if(patientMaintenancePage.isAbandonChangesPopUpDisplayed()){
                    patientMaintenancePage.clickYes();
                }
                patientSearchPage.clickClose();
                softAssert.assertAll();
            }
        } catch (Exception e) {
            Reporter.log("Test failed in Patient Maintenance Screen");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAllergyNDiseaseDetailsInDb() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String patientId = connexusAppUtils.getPatientId(name[0],name[1]);
        String allergyCode = connexusAppUtils.fetchAllergyCode(patientId, "allerg_class_code");
        String diseaseCode = connexusAppUtils.fetchDiseaseCode(patientId, "disease_code");
        if ("8647".equals(allergyCode) && "8646".equals(diseaseCode)) {
            Assert.assertTrue(true, "Allergy and Disease code are correct in DB. Allergy Code = " + allergyCode + "Disease Code = " + diseaseCode);
        } else {
            Assert.fail("Allergy and disease code not correct. Allergy Code = " + allergyCode + "Disease Code = " + diseaseCode);
        }
    }

    public void verifyPTMS_AllergyConditions( WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatus(name[0] + "," + name[1]);
            if(rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())){
                orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                switch (workQueue) {
                    case INPUT:
                        inputPage.clickPatientMaintenanceIconButton(1);
                        Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                                inputPage.takeScreenShot(currentStepMethodName).getValue());
                        CheckForAllergyNMC(currentStepMethodName);

                        //To close the opened PMS
                        patientMaintenancePage.clickExit();
                        patientMaintenancePage.clickYes();
                        patientMaintenancePage.clickCancel();
                        patientMaintenancePage.clickYes();
                        break;

                    case FOUR_POINT:
                        Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                                inputPage.takeScreenShot(currentStepMethodName).getValue());
                        fourPoint.clickPatientMaintenanceIconButton(0);
                        CheckForAllergyNMC(currentStepMethodName);

                        //To close the opened PMS
                        patientMaintenancePage.clickExit();
                        patientMaintenancePage.clickYes();
                        patientMaintenancePage.clickCancel();
                        patientMaintenancePage.clickYes();
                        break;
                    case CHK_DUR:
                        Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                                inputPage.takeScreenShot(currentStepMethodName).getValue());
                        chkDur.clickPatientMaintenanceIconButton(1);
                        CheckForAllergyNMC(currentStepMethodName);

                        //To close the opened PMS
                        patientMaintenancePage.clickExit();
                        patientMaintenancePage.clickYes();
                        patientMaintenancePage.clickCancel();
                        patientMaintenancePage.clickYes();
                        break;
                }
            } else{
                Reporter.log(String.format("RX is not in %s queue",workQueue.getWorkQueue()));
                Assert.fail(String.format("RX is not in %s queue",workQueue.getWorkQueue()));
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }


    }

    private void CheckForAllergyNMC(String currentStepMethodName) {
        if (patientMaintenancePage.isAllergiesNMCPatientNotPresentSelected()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log(patientNotPresentSelected);
            softAssert.assertTrue(true, patientNotPresentSelected);

        } else {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(patientNotPresentNotSelected);
        }

    }

    public void verifyPatientAnnualWizardNotDisplayed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            if (dropOffPage.isCnxMainPanelDisplayed()) {
                Assert.fail(String.format("Annual Patient Wizard is Displayed."));
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            } else {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }
            dropOffPage.clickBtnCancel();
            dropOffPage.clickOkInActivePopUp();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Drop off queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyInsulinPumpCheckboxesAreNotDisplayedInAnnualWizard() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropOff.enterPatientName(name[0] + "," + name[1]);
        dropOff.clickPatientSearch();
        if (patientMaintenancePage.isChkInsulinDependentDisabledInAllergy() ) {
            Assert.fail(String.format("Insulin Dependent Check Box is Displayed."));
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        else if(patientMaintenancePage.isChkInsulinPumpDisplayedInAllergy())
        {
            Assert.fail(String.format("Insulin Pump Check Box is Displayed."));
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        else
        {
            softAssert.assertAll();
        }
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickYesInPopUp();
    }

    public void createNewPatientWithInsulin(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);
            patient.setPatientInsulinInd(inputData.get("IS_INSULIN_SET"));
            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.performSleep(3);
                automationManager.getConnexusWorkFlow().createNewPatient(false, patient);

                Reporter.log("Patient has been created.");
            }else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyInsulinDependentInpulinPumpCheckboxesAreDisbaled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropOffPage.clickDropOffQueue();
        dropOffPage.enterPatientName(name[0] + "," + name[1]);
        dropOffPage.clickPatientSearch();
        if (!patientMaintenancePage.isChkInsulinDependentDisabledInAllergy() && !patientMaintenancePage.isInsulinDependentCheckboxEnabled()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        else
        {
            Assert.fail(String.format("Insulin Dependent Check Box is not Disbaled."));
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

        if (!patientMaintenancePage.isChkInsulinPumpDisplayedInAllergy() && !patientMaintenancePage.isInsulinPumpCheckboxEnabled()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } else {
            Assert.fail(String.format("Insulin Pump Check Box is not Disbaled."));
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        dropOffPage.handleAnnualValidatePatInfoPopUp();
        dropOffPage.clickBtnAccept();
    }

    public void verifyPatientAllergyIsSavedToCDB() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String cdbSearchPatient = "SELECT * FROM [RxPatient].[dbo].[PATIENT] WHERE LAST_NAME = '" + name[0] + "' AND FIRST_NAME = '" + name[1] + "' AND STORE_NBR = '" + propertyReader.getProperty("cnx.store") + "';";
        PatientDB item = automationManager.getCentralPatientSqlServerDBContext().executeQuery(cdbSearchPatient, PatientDB.class);
        if (item != null) {
            String dbCPI = item.getPatientId();
            String cdbSearchPatientAllergy = "SELECT * FROM [RxPatient].[dbo].[PATIENT_ALLERGY] WHERE PATIENT_ID = '" + dbCPI + "' AND STORE_NBR = '" + propertyReader.getProperty("cnx.store") + "';";
            Map<String, Object> itemCentral = automationManager.getCentralPatientSqlServerDBContext().executeQuery(cdbSearchPatientAllergy);
            if (itemCentral != null) {
                Reporter.log("Data is successfully saved in central database.");
                softAssert.assertAll();

            } else {
                isExceptionCaptured =true;
                Assert.fail(String.format("PatientAllergy Record Not Savedin Central Database."));
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }
        }
    }

    public void validateUnnecessaryCentralCalls(){
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patientSearchPage.passName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);

            String cdbSearchPatient = "SELECT * FROM [RxPatient].[dbo].[PATIENT_INSURANCE] WHERE STORE_NBR = '" + PropertyReader.getInstance().getProperty("cnx.store") + "' AND PATIENT_ID = '" + connexusAppUtils.getPatientId(name[0],name[1])+"\'"+";";
            PatientInsuranceInfo patientInfo = AutomationManager.getInstance().getCentralPatientSqlServerDBContext().executeQuery(cdbSearchPatient, PatientInsuranceInfo.class);
            patientMaintenancePage.clickOnTPInfoBtn();
            patientMaintenancePage.cilckOnEditTpBtn();

            PatientInsuranceInfo patientUpdatedInfo = AutomationManager.getInstance().getCentralPatientSqlServerDBContext().executeQuery(cdbSearchPatient, PatientInsuranceInfo.class);

            patientMaintenancePage.clickonAcceptOnThirdPartyEditBtn();
            patientMaintenancePage.clickOnCloseOnThirdPartyInformationBtn();

            patientMaintenancePage.clickOnTPInfoBtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOnCloseOnThirdPartyInformationBtn();

            PatientInsuranceInfo patientUpdatedInfo1 = AutomationManager.getInstance().getCentralPatientSqlServerDBContext().executeQuery(cdbSearchPatient, PatientInsuranceInfo.class);

            patientMaintenancePage.clickExit();
            if(patientMaintenancePage.isAbandonChangesPopUpDisplayed()) {
                patientMaintenancePage.clickYes();
            }

            if (patientInfo.getLastChangeTs().contentEquals(patientUpdatedInfo.getLastChangeTs()) && patientInfo.getLastChangeTs().contentEquals(patientUpdatedInfo1.getLastChangeTs())){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
                Assert.fail(String.format("Unnecesary central calls to DB"));
            }
        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at patient maintenance screen");
            softAssert.fail(e.toString());
        }
    }

    /**
     * Method Name: verifyErxOrderInResolveQueueWithNameMismatch
     *              Searches for the eRx order by patient name and verifies it is in
     *              RESOLVE queue with a Patient Name Mismatch problem.
     *              Reads the patient name from the temp file written by generateRandomPatientForErx().
     * arguments: No arguments required
     * Author: AKANSHA SHARMA (vn59rtq)
     */
    public void verifyErxOrderInResolveQueueWithNameMismatch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String eRxPatientName = name[0] + "," + name[1];

            Reporter.log("Searching for eRx order with patient name: " + eRxPatientName);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(eRxPatientName, SearchType.PatientRx);


            String workQueue     = orderSearch.getWorkQueue(0);
            String problemMessage = orderSearch.getProblemMessage(0);

            Reporter.log("Work Queue: " + workQueue + " | Problem: " + problemMessage);
            Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                    orderSearch.takeScreenShot(currentStepMethodName).getValue());

            // Verify order is in RESOLVE queue
            if (workQueue.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                Reporter.log(Status.PASS,"Order is in RESOLVE queue as expected");
                softAssert.assertTrue(true, "Order is in RESOLVE queue");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                        orderSearch.takeScreenShot(currentStepMethodName).getValue());
                softAssert.fail("Order is NOT in RESOLVE queue. Actual: " + workQueue);
            }

            // Verify Patient Name Mismatch problem is shown
            if (problemMessage.toLowerCase().contains("patient name mismatch")) {
                Reporter.log(Status.PASS, "Patient Name Mismatch problem displayed as expected: " + problemMessage);
                softAssert.assertTrue(true, "Patient Name Mismatch problem displayed");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                        orderSearch.takeScreenShot(currentStepMethodName).getValue());
                softAssert.fail("Patient Name Mismatch problem NOT displayed. Actual: " + problemMessage);
            }
            orderSearch.selectRowFromSearch(0);
            orderSearch.openFirstPatientRecord();
            softAssert.assertAll();

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed while verifying eRx order in RESOLVE queue with Patient Name Mismatch");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method Name: openResolutionAndSearchPatientWithDob
     *              Continues from the Resolution screen already open after verifyErxOrderInResolveQueueWithNameMismatch().
     *              Verifies Patient Mis-Match screen, opens the patient search window,
     *              enters patient name + DOB, performs local search then HOST LookUp.
     * arguments: inputData - "DOB" must be present in the associated sheet
     * Author: Akansha Sharma (vn59rtq)
     */
    public void openResolutionAndSearchPatientWithDob(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String dob    = inputData.get("DOB");

            // Verify Patient Mis-Match screen is displayed (already on Resolution screen)
            if (resolutionPage.isPatientMismatchScreen()) {
                Reporter.log("Patient Mis-Match screen is displayed as expected");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                        resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                softAssert.fail("Patient Mis-Match screen is NOT displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                        resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
                return;
            }

            // Enter patient name in mismatch search field + click btnPatientSearch → opens search window
            resolutionPage.searchPatientMisMatch(name);
            Reporter.log("Patient name entered in mismatch search: " + name[0] + "," + name[1]);

            // In search window: enter DOB then local search
            patientSearchPage.inputPatientDob(dob);
            patientSearchPage.clickSearchNow();
            Reporter.log("Searched for patient with DOB: " + dob);
            Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());

            // HOST LookUp — handles "Additional Patient Information Needed" popup automatically
            patientSearchPage.hostSearchPatient();
            Reporter.log("HOST LookUp performed — Additional Patient Information popup dismissed");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());

            // Click New to add patient as new since no HOST match found
            patientSearchPage.clickNew();
            Reporter.log("Clicked New to add patient: " + name[0] + "," + name[1]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());

            softAssert.assertAll();

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed at searching patient with DOB + HOST LookUp in Resolution screen");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method Name: validatePatientDetailsInPMS
     *              Validates patient Last Name, First Name, DOB pre-populated from eRx,
     *              and verifies both Allergies and Medical Conditions are set to "Patient Not Present"
     *              on the Patient Maintenance Screen auto-opened after HOST LookUp + New.
     * arguments: inputData - "DOB" must be present in the associated sheet
     * Author: Akansha Sharma (vn59rtq)
     */
    public void validatePatientDetailsInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name        = connexusAppUtils.readPatientNameFromFile();
            String expectedLast  = name[0];
            String expectedFirst = name[1];
            String expectedDob   = inputData.get("DOB");

            String actualLast    = patientMaintenancePage.getLastNameText().trim();
            String actualFirst   = patientMaintenancePage.getFirstNameText().toString().trim();
            String actualDob     = patientMaintenancePage.getDobText().trim();

            Reporter.log("PMS Patient → Last: " + actualLast + " | First: " + actualFirst + " | DOB: " + actualDob);

            // Validate Last Name
            softAssert.assertTrue(actualLast.equalsIgnoreCase(expectedLast),
                    "Last Name mismatch → Expected: " + expectedLast + " | Actual: " + actualLast);

            // Validate First Name
            softAssert.assertTrue(actualFirst.equalsIgnoreCase(expectedFirst),
                    "First Name mismatch → Expected: " + expectedFirst + " | Actual: " + actualFirst);

            // Validate DOB
            softAssert.assertTrue(actualDob.equalsIgnoreCase(expectedDob),
                    "DOB mismatch → Expected: " + expectedDob + " | Actual: " + actualDob);

            // Validate Allergies + Medical Conditions = Patient Not Present
            softAssert.assertTrue(
                    patientMaintenancePage.isAllergiesNMCPatientNotPresentSelected(),
                    "Allergies or Medical Conditions is NOT set to 'Patient Not Present'"
            );

            // assertAll here — if any validation above failed, test stops and Save & Close is NOT called
            softAssert.assertAll();

            // All validations passed → Save & Close PMS
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            // Save & Close — fixed to use moveToElementAndClick in PatientMaintenancePage
            Reporter.log("All PMS validations passed — saving and closing");
            patientMaintenancePage.clickSaveAndClose();

            // Address validation popup: "Save as Entered" (btnOK) appears after Save & Close
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                patientMaintenancePage.clickSaveAsEntered();
                Reporter.log("Clicked 'Save as Entered' on address validation popup");
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("PMS validation failed — Save & Close skipped");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    /**
     * Method Name: useSelectedPatientInResolution
     *              After PMS Save & Close, Connexus automatically returns to the Patient Mis-Match
     *              resolution screen with the newly created patient details populated.
     *              Verifies the resolution screen is active and clicks "Use Selected Patient"
     *              to link the new patient to the eRx order.
     * arguments: None
     * Author: Akansha Sharma (vn59rtq)
     */
    public void useSelectedPatientInResolution() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Brief wait for Resolution screen to fully load after PMS closes
            automationManager.performSleep(3);

            softAssert.assertTrue(resolutionPage.isPatientMismatchScreen(),
                    "Patient Mis-Match resolution screen is NOT displayed after patient creation in PMS");

            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Resolution screen confirmed with patient details populated");

            resolutionPage.clickUseSelectedPatient();
            Reporter.log("Clicked 'Use Selected Patient' — eRx order linked to new patient successfully");

            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to use selected patient in resolution screen");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method Name: isRxInWorkQueue
     *              Reads the patient name from file and checks the current RX work queue status
     *              against the given WorkQueue value.
     *              Unlike verifyPTMS_AllergyConditions, this method does NOT assert on failure —
     *              it returns a boolean, making it safe for conditional/optional flow branching
     *              (e.g. CHK_DUR queue may not always be present in the workflow).
     * arguments: WorkQueue workQueue - the work queue to check for (e.g. WorkQueue.CHK_DUR)
     * Author: Akansha Sharma (vn59rtq)
     */
    public boolean isRxInWorkQueue(WorkQueue workQueue) {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatus(name[0] + "," + name[1]);
            return rxStatus.equalsIgnoreCase(workQueue.getWorkQueue());
        } catch (Exception e) {
            Reporter.log("Unable to check work queue status: " + e.getMessage());
            return false;
        }
    }
}