package connexus.FillingFlows.testcases;

import connexus.FillingFlows.testscripts.FillingFlowsTestScript;
import fom.NewOrderDrop;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

public class FillingFlowsTestSet2 {

    FillingFlowsTestScript fillingFlowsTestScript = new FillingFlowsTestScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId;
    private String patientIDCF;
    private String patientIDNonCF;
    boolean relaunchConnexus = true;
    boolean flagUpdated;

    @BeforeClass
    public void performLogin() {
        connexusAppUtils.startAppiumServer();
    }

    @BeforeMethod
    public void setup() {
        connexusApiManager = new ConnexusAPIManager();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
          * HWPHME2E_600 Filling | Single Rx | Unassigned using Filling APIs
          * Author: Prashant
          ----------------------------------------------------------------------------------------------------------*/
		  
   @Test(enabled = true, description = "Filling | Single Rx | Unassigned using Filling APIs",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FillingFlows/FillingFlowsTestSet2.json", sheetName = "FillingFlows")
    public void HWPHME2E_600(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateFlagValue("17310","true");
        siteId = prop.getProperty("cnx.store");
       fillingFlowsTestScript.initializeTestCase(relaunchConnexus);
       fillingFlowsTestScript.createPatientWithOutSSN(inputData);
       fillingFlowsTestScript.performDropOff(Priority.Critical);
       fillingFlowsTestScript.performInput(inputData);
       fillingFlowsTestScript.perform4Point(false);
       fillingFlowsTestScript.performChkDUR();
       fillingFlowsTestScript.verifyRxInFillingQueue();
       fillingFlowsTestScript.verifyGetSetFillInfoUnassigned(Integer.parseInt(siteId),"UNASSIGNED", 0,false);
    }
      /*----------------------------------------------------------------------------------------------------------
       * HWPHME2E_599 Filling | Single Rx | Change NDC flow using Filling APIs
       * Author: Prashant
       * Cash and TP flow
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Filling | Cash | Single Rx | Change NDC flow using Filling APIs",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FillingFlows/FillingFlowsTestSet2.json", sheetName = "Filling599")
    public void HWPHME2E_599_Cash(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateFlagValue("17310", "TRUE");
        connexusAppUtils.updateFlagValue("31760", "FALSE");
        siteId = prop.getProperty("cnx.store");
        fillingFlowsTestScript.initializeTestCase(relaunchConnexus);
        fillingFlowsTestScript.createPatientWithOutSSN(inputData);
        fillingFlowsTestScript.performDropOff(Priority.Critical);
        fillingFlowsTestScript.performInput(inputData);
        fillingFlowsTestScript.perform4Point(false);
        fillingFlowsTestScript.performChkDUR();
        fillingFlowsTestScript.verifyRxInFillingQueue();
       // fillingFlowsTestScript.fillingusingApi();
        fillingFlowsTestScript.verifyGetSetFillInfoUnassigned(Integer.parseInt(siteId), "MODIFIED", 0, false);
        fillingFlowsTestScript.verifyGetSetFillInfoUnassigned(Integer.parseInt(siteId), "SUBMITTED", 0, false);
        fillingFlowsTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        fillingFlowsTestScript.performVisualVerify();
        fillingFlowsTestScript.performPickUp(inputData);
        fillingFlowsTestScript.performCounselling();
        fillingFlowsTestScript.performPOS();

    }

    @Test(enabled = true, description = "Filling |TP | Single Rx | Change NDC flow using Filling APIs",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FillingFlows/FillingFlowsTestSet2.json", sheetName = "Filling599")
    public void HWPHME2E_599_TP(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateFlagValue("17310", "TRUE");
        connexusAppUtils.updateFlagValue("31760", "FALSE");
        siteId = prop.getProperty("cnx.store");
        fillingFlowsTestScript.initializeTestCase(relaunchConnexus);
        fillingFlowsTestScript.createNewPatient(inputData,1);
        fillingFlowsTestScript.performDropOff(Priority.Critical);
        fillingFlowsTestScript.performInput(inputData);
        fillingFlowsTestScript.perform4Point(false);
        fillingFlowsTestScript.performChkDUR();
        fillingFlowsTestScript.verifyRxInFillingQueue();
        fillingFlowsTestScript.verifyGetSetFillInfoUnassigned(Integer.parseInt(siteId), "MODIFIED", 0, false);
        fillingFlowsTestScript.verifyGetSetFillInfoUnassigned(Integer.parseInt(siteId), "SUBMITTED", 0, false);
        fillingFlowsTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        fillingFlowsTestScript.performVisualVerify();
        fillingFlowsTestScript.performPickUp(inputData);
        fillingFlowsTestScript.performCounselling();
        fillingFlowsTestScript.performPOS();
    }
    /*----------------------------------------------------------------------------------------------------------
      * HWPHME2E_605 Filling | ERX days supply calculation , for patient with days supply <= threshold → CF and non-Cf ndc
      * Author: Prashant
      ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Filling | ERX days supply calculation , for patient with days supply <= threshold → CF and non-Cf ndc",
            enabled = true, priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FillingFlows/FillingFlowsTestSet2.json", sheetName = "FillingFlows")
    public void HWPHME2E_605(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayloadCF="src//test//resources//TestData//Connexus//FillingFlows//Test.xml";
        String xmlPayloadNonCF="src//test//resources//TestData//Connexus//FillingFlows//ERXFourPointNonCFDrug.xml";
        connexusAppUtils.updateFlagValue("9061","true");
        connexusAppUtils.updateFlagValue("9062","true");
        connexusAppUtils.updateFlagValue("31025","true");
        connexusAppUtils.restartServices();
        fillingFlowsTestScript.initializeTestCase(relaunchConnexus);
        patientIDCF = String.valueOf(fillingFlowsTestScript.createPatientWithOutSSN(inputData));
        //Send Surescript request to perform ERX
        fillingFlowsTestScript.performERXCF(inputData,xmlPayloadCF, patientIDCF);
        fillingFlowsTestScript.getRemainingDays(patientIDCF,inputData);
        fillingFlowsTestScript.puTimeCalculation();
        fillingFlowsTestScript.performChkDUR();
        fillingFlowsTestScript.performFilling();
        // For Non CF eligible ********************
        patientIDNonCF = String.valueOf(fillingFlowsTestScript.createPatientWithOutSSN(inputData));
        fillingFlowsTestScript.performERXNonCF(inputData,xmlPayloadNonCF, patientIDNonCF);
        fillingFlowsTestScript.puTimeCalculation();
        fillingFlowsTestScript.performFilling();
    }

    /*----------------------------------------------------------------------------------------------------------
          * HWPHME2E_4724 Filling | TP does not re-adjudicate when label is re-printed for fill in pick up queue
          * Author: Avantika (vn598z6)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Filling |TP | Single Rx | Re-printed label for fill in Pickup",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FillingFlows/FillingFlowsTestSet2.json", sheetName = "Filling599")
    public void HWPHME2E_4724_TP_ReprintedlabelforfillinPickup(Map<String, String>inputData) {

        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("17310", "TRUE");
        siteId = prop.getProperty("cnx.store");
        fillingFlowsTestScript.initializeTestCase(flagUpdated);
        fillingFlowsTestScript.createRxPatientAndMoveToPickup(inputData, true);
        fillingFlowsTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        fillingFlowsTestScript.GetPatientPayAmountBeforeRunningRxPrintLabelAPI(inputData);
        fillingFlowsTestScript.updatingRxFillDate(1);
        fillingFlowsTestScript.validateRxWorkQueue(inputData);
        fillingFlowsTestScript.verifyPatientAmountIsSameAfterRunningRxPrintLabelAPI(inputData);
    }
}
