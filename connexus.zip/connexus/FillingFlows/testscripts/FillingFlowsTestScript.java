package connexus.FillingFlows.testscripts;
import centralfilltests.CheckInAppDBWrapper;
import com.aventstack.extentreports.Status;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import connexus.ConnexusTestScripts;
import fillingredesign.datamodels.PrintRxLabelRequest;
import fom.FomAPIWrapper;
import fom.FomSapsFillingSetFillInfoTest;
import fom.FomUtils;
import fom.datamodels.ssoresponse.FillingGetFillInfoSapsResponse;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import io.strati.libs.joda.time.DateTime;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.GetPaymentStatus.am;

public class FillingFlowsTestScript extends ConnexusTestScripts {
    HashMap<String, String> headers = new HashMap<>();
    int patientId;
    ServiceResponse resp;
    ServiceRequest req = new ServiceRequest();
    int siteId;
    PropertyReader prop = PropertyReader.getInstance();
    FomSapsFillingSetFillInfoTest sapsSetFillInfo = new FomSapsFillingSetFillInfoTest();
    CheckInAppDBWrapper dbwrapper = new CheckInAppDBWrapper();
    int bagNbr;
    DBUtils dbUtils = new DBUtils();
    FomUtils fomUtils = new FomUtils();
    FomAPIWrapper api = new FomAPIWrapper();
    ServiceResponse sapsGetFillInforesp;
    FillingGetFillInfoSapsResponse sapsGetFillInfoResponse;
    String PatAmount;
    String PayAmount;
    private List<String> rxNum;

    public FillingFlowsTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexustestharness/");
        prop.loadCustomProperties("config/fom/");
    }

    public void verifyGetSetFillInfoUnassigned(int storeNbr, String setFillStatusInRequestList, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        bagNbr = dbwrapper.getToteNumber(storeNbr);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        Reporter.log("patient is" + patientId);
        Map<String, Object> getRxOrderDetailsFromPatientId = dbUtils.getRxOrderDetailsFromPatientId(
                siteId, String.valueOf(patientId), WorkQueueCode.FILLING.getWorkQueueCode());
        int orderId = (Integer) getRxOrderDetailsFromPatientId.get("order_id");
        fomUtils.getWorkForFill(storeNbr, bagNbr, orderId);
        int retries = 5;
        boolean success = false;
        for (int i = 0; i < retries; i++) {
            sapsGetFillInforesp = api.performSapsgetFillInfo("FillingApp", "MACADDRESS", siteId, String.valueOf(orderId), bagNbr, "WALMART20", "Y");
            if (sapsGetFillInforesp.getStatusCode() == 200) {
                success = true;
                break;
            }
        }
        Assert.assertTrue(success, "GetFillInfo Saps service never returned 200 within timeout");
        Reporter.log("getFillInfo API returned 200 as expected");
        sapsGetFillInfoResponse = sapsGetFillInforesp.getDataResponse(FillingGetFillInfoSapsResponse.class);
        sapsSetFillInfo.validateSapsSetFillInfoAPI(storeNbr, sapsGetFillInfoResponse, setFillStatusInRequestList, problemCodeForCancelFill, isRTSVialUsed);
    }

    public String performERXNonCF(Map<String, String> inputData, String xmlPath, String patientID) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);

        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);

        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("NCF_DrugName");
        drugName = inputData.get("NCF_DrugName");

        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = String.valueOf(siteId) + generatedString;
        inputPayload = updateXML(xmlData, String.valueOf(siteId), updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        dropERX(inputPayload, String.valueOf(siteId), patientID, updateMsgId);
        return updateMsgId;
    }

    public String performERXCF(Map<String, String> inputData, String xmlPath, String patientID) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);

        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);

        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = String.valueOf(siteId) + generatedString;
        inputPayload = updateXML(xmlData, String.valueOf(siteId), updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        dropERX(inputPayload, String.valueOf(siteId), patientID, updateMsgId);
        automationManager.performSleep(20);
        return updateMsgId;
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, String patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    @Override
    public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {
        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        LocalDateTime today = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = today.format(formatter);
        String currentTime = getCurrentTime();

        LocalDateTime updatedTime = today.plus(45, ChronoUnit.MINUTES);
        DateTimeFormatter formatterDateTime = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String formattedTime = updatedTime.format(formatterDateTime);
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", formattedDate);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    @Override
    public String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String Ts = sdf.format(timestamp);
        return Ts;
    }

    public void dropERX(String inputPayload, String storeNbr, String patientId, String messageId) {
        //drop ERX via POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        req.setHeaders(headers);
        req.setUrl("https://rxInt-PharmacySSerxv2inboundreq-qa.wal-mart.com/services/ProcessERx");
        req.setRequestPayload(inputPayload);
        resp = automationManager.getRestContext().performPost(req);
        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
        Reporter.log("ERX order posting successful for patientId = " + patientId + " in store # " + storeNbr +
                ". The resp message_id is " + messageId);
    }

    public int createPatientWithOutSSN(Map<String, String> inputData) {
        super.createNewPatient(inputData);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        Reporter.log("patient is" + patientId);
        return patientId;
    }

    public void puTimeCalculation() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            String priority = orderSearch.getPriorityForPatient(name[0] + "," + name[1], 0);
            Assert.assertEquals(priority, "Dr. Call In");
            Reporter.log("Priority is :" + priority);
            String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

            String query = "SELECT rod.order_id FROM rx_order_detail rod,rx rx where rx.rx_nbr = " + rxNbr + " order by order_id desc limit 1 ";
            List<Map<String, Object>> order = automationManager.getConnexusDB(siteId).executeQueryForList(query);
            int orderId = (Integer) order.get(0).get("order_id");
            System.out.println("orderId : " + orderId);

            String PU = "SELECT est_pickup_ts FROM rx_order_detail WHERE order_id = " + orderId + " ORDER BY est_pickup_ts DESC LIMIT 1";
            List<Map<String, Object>> results = automationManager.getConnexusDB(siteId).executeQueryForList(PU);

            Timestamp pickupTimestamp = (Timestamp) results.get(0).get("est_pickup_ts");
            LocalDateTime pickupTime = pickupTimestamp.toLocalDateTime();
            Reporter.log("PU time before :" + pickupTime);
            LocalDateTime result = pickupTime.plusMinutes(45);
            Reporter.log("PU Time after adding 45 min is : " + result);

            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            connexusAppUtils.writeTextToFile("Completed 4 point and the RX number is " + rxNbr, "In progress", "E2E_execution_status.txt", 40, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            connexusAppUtils.writeTextToFile("4 point Not Completed", "Failed", "E2E_execution_status.txt", 40, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }

    }

    public void getRemainingDays(String patientIDCF, Map<String, String> inputData) {

        String ndc = inputData.get("DRUG_NAME");
        try {
            String query = "select product_mds_fam_id from pharmacy_offering:pharmacy_item where ndc_nbr = " + ndc;
            List<Map<String, Object>> mds = automationManager.getConnexusDB(siteId).executeQueryForList(query);
            int productMdsFamId = (Integer) mds.get(0).get("product_mds_fam_id");

            String query2 = "select gpi_code from pharmacy_offering:product_gpi_xref where product_mds_fam_id = " + productMdsFamId;
            Map<String, Object> gpi = automationManager.getConnexusDB(siteId).executeQuery(query2);
            String gpiCode = gpi.get("gpi_code").toString();

            int remainingSupply = automationManager.getConnexusDB(siteId).getScalar("SELECT NVL(SUM(remaining_days_sply),0) FROM(SELECT CASE WHEN (DATE(rf.pos_ts) + rf.fill_days_sply_qty) - TODAY < 0 THEN 0 ELSE (DATE(rf.pos_ts) + rf.fill_days_sply_qty) - TODAY END AS remaining_days_sply FROM rx rx,rx_fill rf,pharmacy_offering:product_gpi_xref pgx WHERE rx.patient_id = " + patientIDCF +
                    "AND rx.product_mds_fam_id = " + productMdsFamId + " AND rx.product_mds_fam_id = pgx.product_mds_fam_id AND pgx.gpi_code = " + gpiCode + " AND rf.rx_id = rx.rx_id AND rf.status_code = 20401 AND rf.pos_ts IS NOT NULL AND rx.status_code = 20601 )" + ";", Integer.class);

            String query4 = "select phm_parm_value from bu_phm_parm where phm_parm_code = 31026";
            Map<String, Object> op = automationManager.getConnexusDB(siteId).executeQuery(query4);
            String threshold = op.get("phm_parm_value").toString();

            if (threshold.compareTo(String.valueOf(remainingSupply)) > 0) {
                Reporter.log("Threshold is greater than remaining day supply");
            } else {
                Reporter.log("Threshold is less than remaining day supply");
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Threshold check Point ");
            softAssert.fail(e.toString());
        }
    }

    public void GetPatientPayAmountBeforeRunningRxPrintLabelAPI(Map<String, String> inputData) {
        try {
            PayAmount = orderSearch.getPatientPayAmount(rxNbr);
            } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Patient pay not fetched");
        }
    }

    public void verifyPatientAmountIsSameAfterRunningRxPrintLabelAPI(Map<String, String> inputData) {
        try {
            PatAmount = orderSearch.getPatientPayAmount(rxNbr);
            Assert.assertEquals(PatAmount, PayAmount, " Patient pay is not matching");
            Reporter.log("Patient pay Amount is matching After Label Re-print");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Patient pay Amount is not matching After Label Re-print");
        }
    }

    public void updatingRxFillDate(int NumberOfDays) {
        int fillID = connexusAppUtils.getFillId(rxNbr);
        int updatedRecord = connexusAppUtils.updateRxFillDate(fillID, NumberOfDays);
        String fillDate = connexusAppUtils.getFillDateFromRxFillTable(fillID);
        if (updatedRecord > 0) {
            Assert.assertTrue(true);
            Reporter.log("Fill Date updated to Previous day" + fillDate);
        } else {
            Assert.fail("FillDate not updated");
        }
        RePrintRxLabel(fillID, false);
    }

    public ServiceResponse RePrintRxLabel(int fillId, boolean isTestPrint) {
        ServiceRequest req = new ServiceRequest();
        headers.put("Authorization", prop.getProperty("fom.set_fill_info"));
        headers.put("UserId", prop.getProperty("fom.UserId"));
        headers.put("StoreNumber", String.valueOf(Integer.parseInt(String.valueOf(siteId))));
        headers.put("DeviceName", prop.getProperty("fom.DeviceName"));
        headers.put("Source", prop.getProperty("fom.Source"));
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("fom.printRxLabel.url").replace("xxxxx", String.format("%05d", Integer.parseInt(prop.getProperty("cnx.store")))));
        resp = automationManager.getRestContext().performPost(req);
        PrintRxLabelRequest printRxLabelRequest = new PrintRxLabelRequest();
        printRxLabelRequest.setFillId(fillId);

        if (isTestPrint) {
            printRxLabelRequest.setTestPrint(true);
        }
        req.setRequestPayload(printRxLabelRequest);
        Reporter.log("Request endpoint: " + req.getUrl());
        Reporter.logJSON("Request payload: ", req.getRequestPayload());
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.log("Response Status Code: " + resp.getStatusCode());
        Reporter.log("Response Status Desc: " + resp.getStatusDesc());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }

    public void createRxPatientAndMoveToPickup (Map<String, String> inputData, boolean isTpRequired) {
        try {
            if (isTpRequired) {
                patientId = genericCreatePatient(inputData);
                rxNum = createRxAndMoveToPickupForTp(inputData, patientId);
            }
        } catch (Exception e) {
            Reporter.log("Failed to create  Rx patient and move till pickup");
            Assert.fail();
        }
    }
}