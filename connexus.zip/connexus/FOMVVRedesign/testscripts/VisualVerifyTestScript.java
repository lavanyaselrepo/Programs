package connexus.FOMVVRedesign.testscripts;

import centralfilltests.CheckInAppDBWrapper;
import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.walmart.hwqe.commons.utilities.PropertyReader;
import connexus.ConnexusTestScripts;
import fillingredesign.cloudPrintRxLabel.wrapper.CloudPrintRxLabelAPIWrapper;
import fillingredesign.datamodels.FillInfo.FillInfoCosmosResponse;
import fillingredesign.datamodels.FillWorkStatus.FillWorkStatusCosmosResponse;
import fom.FomAPIWrapper;
import fom.FomSapsFillingSetFillInfoTest;
import fom.FomUtils;
import fom.datamodels.ssorequests.FillingSapsModifiedFillItemContents;
import fom.datamodels.ssorequests.FillingSapsOrderLineInfoContents;
import fom.datamodels.ssorequests.FillingSapsProblemContents;
import fom.datamodels.ssorequests.FillingSapsRtsVialItemContents;
import fom.datamodels.ssorequests.FillingSapsSetFillItemContents;
import fom.datamodels.ssoresponse.*;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.fillingVisualVerify.api.pojos.RtsVialItemUsed;
import hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.fillingVisualVerify.api.wrappers.FillingVVWrapper_API;
import hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.fillingVisualVerify.api.pojos.DrugLotInfo;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import fillingredesign.UpdateFulfillmentInfoAPI.Wappers.UpdateFulfillmentInfoAPIWrapper;
import fillingredesign.datamodels.SendFulfilllmentInfoResponse;
import fillingredesign.datamodels.UpdateFulfillmentInfo.*;
import io.appium.java_client.AppiumBy;
import org.junit.platform.commons.util.StringUtils;
import org.testng.Assert;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.List;
import java.util.Map;
import java.util.Random;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import lombok.Getter;
import hwqe.baseframework.datacontext.CosmosContext;

import static com.ibm.db2.jcc.a.a.e;

public class VisualVerifyTestScript extends ConnexusTestScripts {

    // Test data fields
    // No @Getter - conflicts with parent class method
    @Getter
    private static int bagNbr;
    @Getter
    private static String encodedQrCode;
    @Getter
    private static String originalFulfillmentId;
    @Getter
    private static String deviceName;
    @Getter
    private static SendFulfilllmentInfoResponse sendFulfillmentData;
    private static FillingGetFillInfoSapsResponse sapsGetFillInfoResponse;
    @Getter
    private static List<FillingSapsRtsVialItemsContents> rtsVialItemsList;

    String userId;
    // Framework instances
    private static final AutomationManager automationManager = AutomationManager.getInstance();
    private final ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    private final FomAPIWrapper fomAPIWrapper = new FomAPIWrapper();
    private CloudPrintRxLabelAPIWrapper cloudPrintRxLabelAPIWrapper = new CloudPrintRxLabelAPIWrapper();
    private UpdateFulfillmentInfoAPIWrapper updateFulfillmentInfoWrapper = new UpdateFulfillmentInfoAPIWrapper();
    public connexus.Filling.testscripts.Filling_testscripts fillingTestscripts;
    String rxStatus;
    int patientId;
    CheckInAppDBWrapper dbwrapper = new CheckInAppDBWrapper();
    PropertyReader prop = PropertyReader.getInstance();
    FomUtils fomUtils = new FomUtils();
    FomAPIWrapper api = new FomAPIWrapper();
    ServiceResponse sapsGetFillInforesp;
    FomSapsFillingSetFillInfoTest sapsSetFillInfo = new FomSapsFillingSetFillInfoTest();
    int fillID;
    int newFillID;



    public VisualVerifyTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
        initializeDeviceName();
        // Initialize Filling_testscripts instance with the same login user type
        fillingTestscripts = new connexus.Filling.testscripts.Filling_testscripts(loginUserType);
    }

    /**
     * Initializes deviceName by querying the database first.
     * Falls back to property file if DB query returns no result.
     * Query: select wrkstatn_host_name from workstation_setting where setting_code_id in (13018);
     */
    private void initializeDeviceName() {
        if (StringUtils.isBlank(deviceName)) {
            deviceName = connexusAppUtils.getDeviceNameFromWorkstationSetting();
            if (StringUtils.isBlank(deviceName)) {
                // Fallback to property file
                deviceName = propertyReader.getProperty("fom.setDeviceName");
                Reporter.log("WARNING: Device name not found in database (workstation_setting with setting_code_id=13018). Using property file value: " + deviceName);
            }
        }
    }

    public void validateRackNumber(String rackNumber) {
        try {
            int orderId = connexusAppUtils.getOrderId(rxNbr);
            int rackNo = connexusAppUtils.getRackNumber(orderId);
            Assert.assertEquals(String.valueOf(rackNo), rackNumber, "Rack number not matching");
            Reporter.log("Validating Rack number: " + rackNo);
        } catch (Throwable e) {
            Assert.fail("Rack number Not matching - expected: " + rackNumber + ", actual: " + String.valueOf(connexusAppUtils.getRackNumber(connexusAppUtils.getOrderId(rxNbr))));
        }
    }

    public void validateFieldsInAutoVVScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.VISUAL_VERIFY.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in Visual verify queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Visual verify Queue");
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (visVerPage.isElementDisplayed(visVerPage.unableToReplenishOkBtn, 3)) {
                visVerPage.click(visVerPage.unableToReplenishOkBtn);
            }
            if (!visVerPage.isElementEnabled(visVerPage.reviewAllImages)) {
                Assert.assertTrue(true);
                Reporter.log("Review all images button disabled");
                Reporter.log("All images sent in update fulfillment info API loaded");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Review all images button not disabled");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Auto VV screen no loaded");
        }
    }

    public void selectAllImagesAndValidateAcceptButtonEnabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Robot robot = new Robot();
            for (int i = 0; i <= ConnexusConstants.IMAGE_COUNT; i++) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            }
            if (visVerPage.isElementEnabled(visVerPage.btnAccept)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Accept button is enabled");
                visVerPage.clickAccept();
            } else {
                Assert.fail("Accept button is not enabled");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            Reporter.log("Visual verifivation completed");
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    /**
     * Calls the outcomes-filling-workflow API using the previously created patient
     *
     * @param inputData - Test data containing all fields named exactly as in curl (except patientId and siteID)
     * @param storeId   - Store number (used as siteID)
     * @return ServiceResponse - The API response
     */
    public ServiceResponse outcomesFillingWorkflow(Map<String, String> inputData, int storeId) {
        ServiceResponse response = connexusAPIManager.outcomesFillingWorkflow(patientId, storeId, inputData);

        // Validate response status code
        if (response.getStatusCode() != 200 && response.getStatusCode() != 201) {
            String errorMessage = "OutcomesFillingWorkflow API failed with status: " + response.getStatusCode()
                    + " Response: " + response.getDataResponse();
            Reporter.log(errorMessage);
            throw new AssertionError(errorMessage);
        }

        // Extract rxNbr and rxFillId from response
        rxNbr = String.valueOf((int) response.getJsonElement("$.rxNbr"));
        rxFillId = response.getJsonElement("$.rxFillId");

        Reporter.log("OutcomesFillingWorkflow API called for patientId: " + patientId + ", storeId: " + storeId);
        Reporter.log("Response - rxNbr: " + rxNbr + ", rxFillId: " + rxFillId);
        return response;
    }

    // ==================== Bag Assignment Methods ====================

    public int findAndAssignWCFBag(int storeId) {
        try {
            automationManager.performSleep(5);
            // Use already-populated rxFillId and orderId from moveToFilling if available
            if (rxFillId == 0) {
                rxFillId = connexusAppUtils.getFillId(rxNbr);
            }
            if (orderId == 0) {
                orderId = connexusAppUtils.getOrderId(rxNbr);
            }

            if (rxFillId == 0) {
                throw new RuntimeException("rxFillId is 0 - unable to find rx_fill_id for rxNbr: " + rxNbr);
            }
            int bagNumber = new Random().nextInt(9000) + 1000; // Random 4-digit bag number

            String userName = propertyReader.getProperty("cnx.rph.userName");

            Reporter.log("Assigning bag to order - rxFillId: " + rxFillId + ", bagNumber: " + bagNumber +
                    ", userName: " + userName + ", deviceName: " + deviceName);

            // Assign fill using the same logic as working wrapper
            assignFill(storeId, rxFillId, userName, bagNumber);
            bagNbr = bagNumber;
            //Fill assignment successful. Waiting 10 seconds for DB committ
            automationManager.performSleep(10);

            return bagNumber;

        } catch (Exception e) {
            Reporter.log("Failed to find and assign WCF bag: " + e.getMessage());
            throw new RuntimeException("Failed to find and assign WCF bag", e);
        }
    }

    /**
     * Assigns fill to user in database - required before calling GetFillInfo API
     * Updates rx_order_detail with userId, tote_nbr, wrkstatn_host_name, and sub_que_type_code
     *
     * @param storeNo  - Store number
     * @param rxFillId - RX Fill ID
     * @param userId   - User ID
     * @param toteNbr  - Tote/Bag number
     */
    public void assignFill(int storeNo, int rxFillId, String userId, int toteNbr) {
        automationManager.getConnexusDB(storeNo)
                .executeUpdateQuery("update rx_order_detail set assigned_userid= '"
                        + userId
                        + "', "
                        + "tote_nbr= "
                        + toteNbr
                        + ", wrkstatn_host_name= 'MACADDRESS' "
                        + ", sub_que_type_code = '1' "
                        + "where rx_fill_id = "
                        + rxFillId
                        + ";");
    }

    // ==================== SAPS API Methods ====================

    /**
     * Performs SAPS getFillInfo API call
     *
     * @param storeId - Store number
     * @return ServiceResponse - The API response
     */
    public ServiceResponse performGetFillInfo(int storeId) {
        try {
            String userId = propertyReader.getProperty("cnx.rph.userName");
            //Waiting 30 seconds for order to be ready for filling.
            automationManager.performSleep(30);
            ServiceResponse sapsGetFillInfoResp = fomAPIWrapper.performSapsgetFillInfo(
                    "FillingApp",
                    deviceName,
                    storeId,
                    String.valueOf(orderId),
                    bagNbr,
                    userId,
                    "Y"
            );
            Reporter.log("SAPS getFillInfo API response status code: " + sapsGetFillInfoResp.getStatusCode());
            if (sapsGetFillInfoResp.getStatusCode() == 200) {
                sapsGetFillInfoResponse = sapsGetFillInfoResp.getDataResponse(FillingGetFillInfoSapsResponse.class);
                // Extract fulfillmentId and encodedQrCode from orderLineItem[0]
                if (sapsGetFillInfoResponse.getFillWork() != null
                        && sapsGetFillInfoResponse.getFillWork().getOrderLineItem() != null
                        && !sapsGetFillInfoResponse.getFillWork().getOrderLineItem().isEmpty()) {
                    FillingSapsorderLineItemContents orderLineItem = sapsGetFillInfoResponse.getFillWork().getOrderLineItem().get(0);
                    // Extract fulfillmentId from orderLineItem
                    originalFulfillmentId = orderLineItem.getFulfillmentId();
                    Reporter.log("Extracted fulfillmentId: " + originalFulfillmentId);
                    // Validate isEligibleForImageCapture
                    boolean isEligibleForImageCapture = orderLineItem.isEligibleForImageCapture();
                    Reporter.log("isEligibleForImageCapture: " + isEligibleForImageCapture);
                    // Extract encodedQrCode (this is the global encodedQrCode attribute as per requirement)
                    encodedQrCode = orderLineItem.getEncodedQrCode();

                    Assert.assertNotNull(encodedQrCode);
                    Assert.assertNotNull(originalFulfillmentId);
                    Assert.assertTrue(isEligibleForImageCapture);
                    Reporter.log("encodedQrCode: " + encodedQrCode);

                    // Extract rtsVialItems from fillWork for use in performSaveRtsInfo - keep only first item
                    if (sapsGetFillInfoResponse.getFillWork().getRtsVialItems() != null
                            && !sapsGetFillInfoResponse.getFillWork().getRtsVialItems().isEmpty()) {
                        int totalRtsVials = sapsGetFillInfoResponse.getFillWork().getRtsVialItems().size();
                        Reporter.log("Total rtsVialItems from getFillInfo response: " + totalRtsVials);
                        // Keep only the first RTS vial item
                        rtsVialItemsList = new ArrayList<>();
                        rtsVialItemsList.add(sapsGetFillInfoResponse.getFillWork().getRtsVialItems().get(0));
                        Reporter.log("Filtered to single RTS vial item - rtsVialId: " + rtsVialItemsList.get(0).getRtsVialId()
                                + ", itemQty: " + rtsVialItemsList.get(0).getItemQty()
                                + ", vialExpDate: " + rtsVialItemsList.get(0).getVialExpDate());
                    } else {
                        Reporter.log("RtsVialItems is null or empty in getFillInfo response");
                    }
                } else {
                    Reporter.log("Unable to extract encodedQrCode - orderLineItem is null or empty");
                }
            } else {
                Assert.fail("SAPS getFillInfo API call failed");
                Reporter.log("SAPS getFillInfo API call failed with status code: " + sapsGetFillInfoResp.getStatusCode());
            }
            return sapsGetFillInfoResp;
        } catch (Exception e) {
            Reporter.log("Failed to perform SAPS getFillInfo: " + e.getMessage());
            throw new RuntimeException("Failed to perform SAPS getFillInfo", e);
        }
    }

    public void validateNumberOfLables() {
        int noOfLables = sapsGetFillInfoResponse.getFillWork().getOrderLineItem().get(0).getNumberOfLabels();
        float fillQuantity = sapsGetFillInfoResponse.getFillWork().getOrderLineItem().get(0).getFillQty();
        float innerPackQuantity = sapsGetFillInfoResponse.getFillWork().getItemDetails().get(0).getInnerPackQty();
        float outerPackQuantity = sapsGetFillInfoResponse.getFillWork().getItemDetails().get(0).getOuterPackQty();
        String singleDispInd = sapsGetFillInfoResponse.getFillWork().getItemDetails().get(0).getSingleDispInd();
        String singleDoseInd = sapsGetFillInfoResponse.getFillWork().getItemDetails().get(0).getSingleDoseInd();
        float calculatedQuantity;
        int calculatedadjustedQuantity;
        if (("Y".equals(singleDoseInd) && "Y".equals(singleDispInd)) || ("N".equals(singleDoseInd) && "N".equals(singleDispInd))) {
            if (noOfLables == 1) {
                Assert.assertTrue(true);
                Reporter.log("Single Disp Ind : " + singleDispInd + " || Single Dose Ind : " + singleDoseInd);
                Reporter.log("No Of Labels: " + noOfLables);
            } else {
                Assert.fail("No of labels not matching");
            }
        } else if ("N".equals(singleDoseInd) && "Y".equals(singleDispInd)) {
            calculatedQuantity = fillQuantity / innerPackQuantity;
            calculatedadjustedQuantity = (int) Math.ceil(calculatedQuantity);
            if (noOfLables == calculatedadjustedQuantity) {
                Assert.assertTrue(true);
                Reporter.log("Single Disp Ind : " + singleDispInd + " || Single Dose Ind : " + singleDoseInd);
                Reporter.log("No Of Labels: " + noOfLables);
            } else {
                Assert.fail("No of labels not matching");
            }
        } else if ("Y".equals(singleDoseInd) && "N".equals(singleDispInd)) {
            calculatedQuantity = fillQuantity / (innerPackQuantity * outerPackQuantity);
            calculatedadjustedQuantity = (int) Math.ceil(calculatedQuantity);
            if (noOfLables == calculatedadjustedQuantity) {
                Assert.assertTrue(true);
                Reporter.log("Single Disp Ind : " + singleDispInd + " || Single Dose Ind : " + singleDoseInd);
                Reporter.log("No Of Labels: " + noOfLables);
            } else {
                Assert.fail("No of labels not matching");
            }
        } else {
            Assert.fail("Single disp and Single dose ind values not matching");
        }
    }

    /**
     * Performs SAPS setFillInfo API call using the stored getFillInfo response
     *
     * @param storeNbr      - Store number
     * @param setFillStatus - Status to set (e.g., "MODIFIED", "SUBMITTED", "UNASSIGNED")
     * @param problemCode   - Problem code (use 0 to skip setting problem)
     * @param isRTSVialUsed - Whether RTS vial is used
     */
    public ServiceResponse performSetFillInfo(int storeNbr, String setFillStatus, int problemCode, boolean isRTSVialUsed) {
        String techUserId = propertyReader.getProperty("cnx.rph.userName");
        int bagNbr = sapsGetFillInfoResponse.getFillWork().getOrderLineItem().get(0).getBagInfo().getBagNbr();

        ArrayList<FillingSapsOrderLineInfoContents> orderLineInfoList = new ArrayList<>();
        ArrayList<FillingSapsSetFillItemContents> fillItemList = new ArrayList<>();

        FillingSapsorderLineItemContents orderLineItem = sapsGetFillInfoResponse.getFillWork().getOrderLineItem().get(0);

        FillingSapsOrderLineInfoContents orderLineInfo = new FillingSapsOrderLineInfoContents();
        orderLineInfo.setRxId(orderLineItem.getRxId());
        orderLineInfo.setRxFillId(String.valueOf((int) orderLineItem.getRxFillId()));
        orderLineInfo.setFomId(null);
        orderLineInfo.setLabelId(null);
        orderLineInfo.setFillWorkStatus(setFillStatus);
        orderLineInfo.setOrderLineItemId(orderLineItem.getOrderLineItemId());
        orderLineInfo.setPatientId(orderLineItem.getPatientId());
        orderLineInfo.setFillSeqNbr(orderLineItem.getFillSeqNbr());
        orderLineInfo.setFillType(orderLineItem.getFillType());

        FillingSapsSetFillItemContents fillItemContents = new FillingSapsSetFillItemContents();
        fillItemContents.setItemMdsFamId(orderLineItem.getFilItem().get(0).getItemMdsFamId());
        fillItemContents.setFillItemQty(orderLineItem.getFilItem().get(0).getFillItemQty());
        fillItemContents.setItemSeqNbr(orderLineItem.getFilItem().get(0).getItemSeqNbr());
        fillItemList.add(fillItemContents);

        orderLineInfo.setFillItem(fillItemList);
        orderLineInfo.setWorkId(null);

        java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String ts = sdf.format(timestamp);
        orderLineInfo.setFillingStartTs(ts);
        orderLineInfo.setFillingCompleteTs(ts);

        if (problemCode > 0) {
            FillingSapsProblemContents problemContents = new FillingSapsProblemContents();
            problemContents.setProblemCode(problemCode);
            problemContents.setDispensedNdc(sapsGetFillInfoResponse.getFillWork().getItemDetails().get(0).getNdcNbr());
            problemContents.setRequestedNdc("50580011224");
            orderLineInfo.setProblem(problemContents);
        } else {
            orderLineInfo.setProblem(null);
        }

        if ("MODIFIED".equalsIgnoreCase(setFillStatus)) {
            int productMdsFamId = orderLineItem.getFilItem().get(0).getPrescribedProductMdsFamId();
            int currentMdsFamId = orderLineItem.getFilItem().get(0).getItemMdsFamId();
            int fillItemQty = orderLineItem.getFilItem().get(0).getFillItemQty();

            // Query DB for a different itemMdsFamId with same product_mds_fam_id
            int modifiedMdsFamId = automationManager.getConnexusDB(storeNbr).getScalar(
                    "select mds_fam_id from pharmacy_offering:pharmacy_item where product_mds_fam_id=" + productMdsFamId
                            + " and status_code=20909 and mds_fam_id !=" + currentMdsFamId
                            + " order by on_hand_qty desc limit 1", Integer.class);

            ArrayList<FillingSapsModifiedFillItemContents> modifiedFillItemList = new ArrayList<>();
            FillingSapsModifiedFillItemContents modifiedFillItem = new FillingSapsModifiedFillItemContents();
            modifiedFillItem.setProductMdsFamId(productMdsFamId);
            modifiedFillItem.setItemMdsFamId(modifiedMdsFamId);
            modifiedFillItem.setFillItemQty(fillItemQty);
            modifiedFillItem.setItemSeqNbr(1);
            modifiedFillItemList.add(modifiedFillItem);
            orderLineInfo.setModifiedFillItem(modifiedFillItemList);
        } else {
            orderLineInfo.setModifiedFillItem(null);
        }

        if (isRTSVialUsed && rtsVialItemsList != null && !rtsVialItemsList.isEmpty()) {
            ArrayList<FillingSapsRtsVialItemContents> rtsVialItems = new ArrayList<>();
            // Take only the first RTS vial item even if multiple are present
            FillingSapsRtsVialItemsContents rtsVial = rtsVialItemsList.get(0);
            FillingSapsRtsVialItemContents rtsVialItem = new FillingSapsRtsVialItemContents();
            rtsVialItem.setRtsVialId(rtsVial.getRtsVialId());
            rtsVialItem.setMdsFamId(rtsVial.getMdsFamId());
            rtsVialItem.setVialConsumed(true);
            rtsVialItem.setRtuCode(null);
            rtsVialItem.setRtuCodeDesc("");
            rtsVialItem.setItemQty(rtsVial.getItemQty());
            rtsVialItem.setItemQtyConsumed(0);
            rtsVialItem.setVialExpDate(rtsVial.getVialExpDate());
            rtsVialItems.add(rtsVialItem);
            orderLineInfo.setRtsVialItemsUsed(rtsVialItems);
        } else {
            orderLineInfo.setRtsVialItemsUsed(null);
        }
        orderLineInfoList.add(orderLineInfo);

        ServiceResponse setFillInfoResp = fomAPIWrapper.performSapssetFillInfo(
                sapsGetFillInfoResponse.getOrderId(),
                storeNbr,
                deviceName,
                techUserId,
                bagNbr,
                "EPL00074D789574",
                "N",
                orderLineInfoList,
                setFillStatus
        );

        Reporter.log("SetFillInfo API Response Status Code: " + setFillInfoResp.getStatusCode());
        Reporter.log("SetFillInfo API Response Body: " + setFillInfoResp.getDataResponse());
        Assert.assertEquals(setFillInfoResp.getStatusCode(), 200, "SetFillInfo API call failed");
        Reporter.log("SetFillInfo API completed successfully with status: " + setFillStatus);

        return setFillInfoResp;
    }

    /**
     * Performs SAPS sendFulfillment API call
     *
     * @param storeId - Store number
     * @return ServiceResponse - The API response
     */
    public ServiceResponse performSendFulfillment(String rack_name, int storeId) {
        try {
            //Waiting 10 seconds .
            automationManager.performSleep(10);
            if (encodedQrCode == null || encodedQrCode.isEmpty()) {
                Reporter.log("ERROR: encodedQrCode is null or empty. Cannot proceed with sendFulfillment.");
                throw new RuntimeException("encodedQrCode is required for sendFulfillment API call");
            }
            Reporter.log("Calling SAPS sendFulfillment API with parameters:");
            Reporter.log("  Encoded QR code: " + encodedQrCode);
            ServiceResponse sendFulfillmentResp = FillingVVWrapper_API.sendFulfillmentInfoReq(
                    encodedQrCode,
                    deviceName,
                    storeId
            );
            Reporter.log("SAPS sendFulfillment API response status code: " + sendFulfillmentResp.getStatusCode());
            if (sendFulfillmentResp.getStatusCode() == 200) {
                // Parse and store the response for use in UpdateFulfillment API
                sendFulfillmentData = sendFulfillmentResp.getDataResponse(SendFulfilllmentInfoResponse.class);

                // Filter rtsVialItems to keep only one item if multiple are present
                if (sendFulfillmentData.getFillWork() != null
                        && sendFulfillmentData.getFillWork().getOrderLineItem() != null
                        && sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems() != null
                        && sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().size() > 1) {
                    Reporter.log("Multiple RtsVialItems found (" + sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().size() + "), keeping only the first one");
                    List<SendFulfilllmentInfoResponse.RtsVialItem> singleRtsVialItem = new ArrayList<>();
                    singleRtsVialItem.add(sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().get(0));
                    sendFulfillmentData.getFillWork().getOrderLineItem().setRtsVialItems(singleRtsVialItem);
                    Reporter.log("RtsVialItems filtered to single item - rtsVialId: " + singleRtsVialItem.get(0).getRtsVialId());
                }
                String rack_number = sendFulfillmentData.getRackNo();
                Reporter.log("rack Number value is " + rack_number);
                Assert.assertEquals(rack_number,rack_name, "rack Number value not matching");
            } else {
                Assert.fail("SAPS sendFulfillment API call failed");
                Reporter.log("SAPS sendFulfillment API call failed with status code: " + sendFulfillmentResp.getStatusCode());
            }
            return sendFulfillmentResp;
        } catch (Exception e) {
            Reporter.log("Failed to perform SAPS sendFulfillment: " + e.getMessage());
            throw new RuntimeException("Failed to perform SAPS sendFulfillment", e);
        }
    }

    /**
     * Performs print rx label API call
     *
     * @param storeId - Store number
     * @return ServiceResponse - The API response
     */
    public ServiceResponse performPrintRxLabel(Map<String, String> inputData, int storeId) {
        try {
            automationManager.performSleep(10);
            if (encodedQrCode == null || encodedQrCode.isEmpty()) {
                Reporter.log("ERROR: encodedQrCode is null or empty. Cannot proceed with sendFulfillment.");
                throw new RuntimeException("encodedQrCode is required for Print RX Label API call");
            }

            Reporter.log("Calling SAPS Print RX Label API with parameters:");
            Reporter.log("  encodedQrCode: " + encodedQrCode);
            int noOfLabels = sendFulfillmentData.getFillWork().getOrderLineItem().getNumberOfLabels();

            ServiceResponse printRxLabelRes = cloudPrintRxLabelAPIWrapper.CloudPrintRxLabelResp(deviceName, encodedQrCode, inputData.get("drugExpiryDate"), inputData.get("drugLot"), noOfLabels, inputData.get("reprintInd"));

            Reporter.log("Print RX Label API response status code: " + printRxLabelRes.getStatusCode());

            if (printRxLabelRes.getStatusCode() == 200) {
                Reporter.log("Response: " + printRxLabelRes.getDataResponse());
            } else {
                Assert.fail("SAPS Print RX Label API call failed");
                Reporter.log("SAPS Print RX Label API call failed with status code: " + printRxLabelRes.getStatusCode());
            }
            return printRxLabelRes;
        } catch (Exception e) {
            Reporter.log("Failed to perform SAPS printRxLabelRes: " + e.getMessage());
            throw new RuntimeException("Failed to perform SAPS printRxLabelRes", e);
        }
    }

    /**
     * Validates the SAPS getFillInfo API response
     * Expected validations per requirements:
     * - 200 OK status and response includes below details
     * - isSingleDoseImageCapture = true
     * - isFulfillmentId = GUID
     * - encodedQRCode = Base64 encoded value of StageDoorsNoUserIdFulfillmentId
     * - numberOfLabels based on single_disp_ind and single_dose_ind logic
     *
     * @param response - The getFillInfo API response
     */
    public void validateGetFillInfoResponse(FillingGetFillInfoSapsResponse response) {
        try {
            Reporter.log("Starting validation of getFillInfo API response");

            // Validate response structure
            if (response == null) {
                Assert.fail("Validation failed: Response is null");
                Reporter.log("Validation failed: Response is null");
                return;
            }

            // Validate fillWork exists
            if (response.getFillWork() == null) {
                Reporter.log("Validation warning: fillWork is null");
                return;
            }

            FillingSapsFillWorkContents fillWork = response.getFillWork();
            Reporter.log("FillWork - PriorityId: " + fillWork.getPriorityId());

            // Validate orderLineItem exists
            if (fillWork.getOrderLineItem() == null || fillWork.getOrderLineItem().isEmpty()) {
                Reporter.log("Validation warning: orderLineItem list is null or empty");
                return;
            }

            // Process each order line item
            for (int i = 0; i < fillWork.getOrderLineItem().size(); i++) {
                FillingSapsorderLineItemContents orderLineItem = fillWork.getOrderLineItem().get(i);
                Reporter.log("--- Validating Order Line Item " + (i + 1) + " ---");
                Reporter.log("OrderLineItemId: " + orderLineItem.getOrderLineItemId());
                Reporter.log("RxFillId: " + orderLineItem.getRxFillId());
                Reporter.log("FillQty: " + orderLineItem.getFillQty());
                Reporter.log("FillType: " + orderLineItem.getFillType());
                Reporter.log("FillingStatus: " + orderLineItem.getFillingStatus());
            }

            // Validate itemDetails for single_disp_ind
            if (fillWork.getItemDetails() != null && !fillWork.getItemDetails().isEmpty()) {
                Reporter.log("--- Validating Item Details ---");
                for (int i = 0; i < fillWork.getItemDetails().size(); i++) {
                    FillingSapsItemDetailsContents itemDetail = fillWork.getItemDetails().get(i);
                    Reporter.log("Item " + (i + 1) + " - NDC: " + itemDetail.getNdcNbr() +
                            ", ProductMdsFamId: " + itemDetail.getProductMdsFamId());

                    String singleDispInd = itemDetail.getSingleDispInd();
                    Reporter.log("singleDispInd: " + singleDispInd);

                    if ("Y".equals(singleDispInd)) {
                        Reporter.log("Validation info: Single dispense indicator is Y");
                    } else if ("N".equals(singleDispInd)) {
                        Reporter.log("Validation info: Single dispense indicator is N");
                    } else {
                        Reporter.log("Validation info: Single dispense indicator is " + singleDispInd);
                    }
                }
            } else {
                Reporter.log("Validation warning: itemDetails list is null or empty");
            }

            // Validate patient info
            if (fillWork.getPatientInfo() != null && !fillWork.getPatientInfo().isEmpty()) {
                Reporter.log("--- Patient Info Available ---");
                Reporter.log("Patient info count: " + fillWork.getPatientInfo().size());
            }

            Reporter.log("Completed validation of getFillInfo API response");

        } catch (Exception e) {
            Reporter.log("Error during getFillInfo response validation: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public int getPatientId() {
        return patientId;
    }

    public ServiceResponse performUpdateFulfillment(Map<String, String> inputData, String fillWorkStatus, String rackNo) {
        Map<String, String> modifiedInputData = new HashMap<>(inputData);
        if (rackNo != null && !rackNo.isEmpty()) {
            modifiedInputData.put("RACK_NO", rackNo);
        }
        return performUpdateFulfillment(modifiedInputData, fillWorkStatus);
    }
    public ServiceResponse performUpdateFulfillment(Map<String, String> inputData, String fillWorkStatus) {
        try {
            Reporter.log("Calling UpdateFulfillmentInfo API");
             // Verify we have the SendFulfillmentInfo response data
            if (sendFulfillmentData == null) {
                Reporter.log("ERROR: SendFulfillmentInfo response data is not available. Cannot proceed with UpdateFulfillmentInfo API call.");
                throw new RuntimeException("SendFulfillmentInfo response data is null");
            }

            // Build UpdateFulfillmentInfoRequest using data from SendFulfillmentInfo response
            UpdateFulfillmentInfoRequest updateFulfillmentRequest = new UpdateFulfillmentInfoRequest();
            updateFulfillmentRequest.setFulfillmentId(encodedQrCode); // Using encoded Token same as SendFulfillmentInfo request
            updateFulfillmentRequest.setOrderId(sendFulfillmentData.getOrderId());
            if (StringUtils.isBlank(inputData.get("RACK_NO"))) {
                updateFulfillmentRequest.setRackNo(sendFulfillmentData.getRackNo());
            } else {
                updateFulfillmentRequest.setRackNo(inputData.getOrDefault("RACK_NO", sendFulfillmentData.getRackNo()));
            }
            updateFulfillmentRequest.setTechUserId(propertyReader.getProperty("cnx.rph.userName"));
            updateFulfillmentRequest.setBagNbr(sendFulfillmentData.getFillWork().getOrderLineItem().getBagInfo().getBagNbr());

            // Build OrderLineInfo using data from SendFulfillmentInfo response
            OrderLineInfo orderLineInfo = new OrderLineInfo();
            orderLineInfo.setFillWorkStatus(fillWorkStatus);
            orderLineInfo.setFillSeqInBag(sendFulfillmentData.getFillWork().getOrderLineItem().getFillSeqInBag());
            orderLineInfo.setTotalNoOfFillsInBag(sendFulfillmentData.getFillWork().getOrderLineItem().getTotalNoOfFillsInBag());
            orderLineInfo.setFillItemMdsFamId(sendFulfillmentData.getFillWork().getOrderLineItem().getFillItemMdsFamId());
            orderLineInfo.setFillQty((int) sendFulfillmentData.getFillWork().getOrderLineItem().getFillQty());
            orderLineInfo.setNumberOfStockBottleUsed(Integer.parseInt(inputData.get("BOTTLES_USED")));
            orderLineInfo.setRtsVialItemsUsed(null);
            orderLineInfo.setOverrideInd(false);
            orderLineInfo.setOverrideReason(new ArrayList<>());

            // Use overrideInd and overrideReason from inputData if provided, otherwise use defaults
            boolean overrideInd = Boolean.parseBoolean(inputData.getOrDefault("OVERRIDE_IND", "false"));
            orderLineInfo.setOverrideInd(overrideInd);

            // Parse overrideReason from inputData (comma-separated integers) or use empty list
            List<String> overrideReasonList = new ArrayList<>();
            String overrideReasonStr = inputData.get("OVERRIDE_REASON");
            if (overrideReasonStr != null && !overrideReasonStr.isEmpty()) {
                String[] reasons = overrideReasonStr.split(",");
                for (String reason : reasons) {
                    overrideReasonList.add(reason.trim());
                }
            }
            orderLineInfo.setOverrideReason(overrideReasonList);

            // Use FillingStartTs from SendFulfillment response
            String fillingStartTs = sendFulfillmentData.getFillingStartTs();
            orderLineInfo.setFillingStartTs(fillingStartTs);
            orderLineInfo.setFillingCompleteTs(fillingStartTs);
            orderLineInfo.setTotalFulfillmentImagesCaptured(Integer.parseInt(inputData.get("IMAGES_USED")));

            // Build DrugInfo list
            List<DrugInfo> drugInfoList = new ArrayList<>();
            DrugInfo drugInfo = new DrugInfo();

            // Check if RTS vial items have drug lot info
            if (sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems() != null
                    && !sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().isEmpty()
                    && sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().get(0).getDrugLotInfo() != null
                    && !sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().get(0).getDrugLotInfo().isEmpty()) {

                // Use drug lot info from SendFulfillmentInfo response
                SendFulfilllmentInfoResponse.DrugLotInfo sourceDrugLot =
                        sendFulfillmentData.getFillWork().getOrderLineItem().getRtsVialItems().get(0).getDrugLotInfo().get(0);

                drugInfo.setDrugLot(sourceDrugLot.getDrugLot());
                drugInfo.setDrugExpiryDate(sourceDrugLot.getDrugExpiryDate());
                drugInfo.setLotSeqNumber(sourceDrugLot.getLotSeqNumber());
                drugInfo.setGtin(sourceDrugLot.getGtin() != null ? sourceDrugLot.getGtin() : "");
                drugInfo.setNdc(sourceDrugLot.getNdc() != null ? sourceDrugLot.getNdc() : sendFulfillmentData.getFillWork().getItemDetails().getNdcNbr());
                drugInfo.setSerialNumber(sourceDrugLot.getSerialNumber() != null ? sourceDrugLot.getSerialNumber() : "");

            } else {
                // Fallback to inputData values (like performPrintRxLabel does)
                drugInfo.setDrugLot(inputData.get("drugLot") != null ? inputData.get("drugLot") : "162");
                drugInfo.setDrugExpiryDate(inputData.get("drugExpiryDate") != null ? inputData.get("drugExpiryDate") : "09/28/2026");
                drugInfo.setLotSeqNumber(1);
                drugInfo.setGtin("");
                drugInfo.setNdc(sendFulfillmentData.getFillWork().getItemDetails().getNdcNbr());
                drugInfo.setSerialNumber("");
            }
            drugInfoList.add(drugInfo);
            orderLineInfo.setDrugInfo(drugInfoList);

            // Get fulfillment images from wrapper - constant predefined images
            List<FulfillmentImage> fulfillmentImages = updateFulfillmentInfoWrapper.getFulfillmentImagesTobeUploaded();
            orderLineInfo.setFulfillmentImages(fulfillmentImages);
            updateFulfillmentRequest.setOrderLineInfo(orderLineInfo);

            // Call the UpdateFulfillmentInfo API
            ServiceResponse updateFulfillmentResponse = updateFulfillmentInfoWrapper.updateSendFulfillmentInfo(
                    updateFulfillmentRequest,
                    deviceName
            );

            Reporter.log("UpdateFulfillmentInfo API Response Status: " + updateFulfillmentResponse.getStatusCode());

            if (updateFulfillmentResponse.getStatusCode() == 200) {
                Reporter.log("Response: " + updateFulfillmentResponse.getDataResponse());
            } else {
                Assert.fail("UpdateFulfillmentInfo API call failed");
                Reporter.log("UpdateFulfillmentInfo API call failed with status code: " + updateFulfillmentResponse.getStatusCode());
                Reporter.log("Response: " + updateFulfillmentResponse.getDataResponse());
            }
            return updateFulfillmentResponse;
        } catch (Exception e) {
            Reporter.log("Failed to perform UpdateFulfillmentInfo: " + e.getMessage());
            throw new RuntimeException("Failed to perform UpdateFulfillmentInfo", e);
        }
    }

    /**
     * Fetches fillWorkStatus and fillInfo documents from Cosmos DB fill_info container
     * after calling save-rts-info API. Uses the fulfillmentId (GUID) from getFillInfo response.
     * Queries executed:
     * - SELECT * FROM c WHERE c.fulfillmentId = "fulfillmentId" AND c.docType = 'fillWorkStatus' ORDER BY c._ts DESC
     * - SELECT * FROM c WHERE c.fulfillmentId = "fulfillmentId" AND c.docType = 'fillInfo' ORDER BY c._ts DESC
     *
     * @return Map containing "fillWorkStatus" and "fillInfo" documents from Cosmos DB
     */
    public Map<String, Object> fetchFillInfoDocumentsFromCosmosDB(String expectedFillWorkStatus) {
        try {
            //taking time to update the status in cosmos DB.
            automationManager.performSleep(10);
            // Use fulfillmentId (GUID) for Cosmos DB query - same as used in save-rts-info
            if (originalFulfillmentId == null || originalFulfillmentId.isEmpty()) {
                Reporter.log("ERROR: fulfillmentId is null or empty. Cannot query Cosmos DB.");
                throw new RuntimeException("fulfillmentId (GUID) is required for Cosmos DB query - ensure performGetFillInfo is called first");
            }
            // Get Cosmos DB context for fill_info container
            // Using getFomFillingDb() which connects to HW_FILLING_SERVICE database with proper credentials from config/fom/
            CosmosContext cosmosContext = automationManager.getFomFillingDb();
            String containerName = "Fill_Info";

            // Query for fillWorkStatus document
            String fillWorkStatusQuery = "SELECT * FROM c WHERE c.fulfillmentId = '" + originalFulfillmentId
                    + "' AND c.docType = 'fillWorkStatus' ORDER BY c._ts DESC";

            FillWorkStatusCosmosResponse fillWorkStatusResult = cosmosContext.executeQuery(
                    containerName,
                    fillWorkStatusQuery,
                    FillWorkStatusCosmosResponse.class
            );

            // Query for fillInfo document
            String fillInfoQuery = "SELECT * FROM c WHERE c.fulfillmentId = '" + originalFulfillmentId
                    + "' AND c.docType = 'fillInfo' ORDER BY c._ts DESC";

            FillInfoCosmosResponse fillInfoResult = cosmosContext.executeQuery(
                    containerName,
                    fillInfoQuery,
                    FillInfoCosmosResponse.class
            );

            // Log results in JSON format
            Map<String, Object> results = new java.util.HashMap<>();
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT); // Pretty print JSON

            if (fillWorkStatusResult != null) {
                Reporter.log("fillWorkStatus Document Found ");
                try {
                    String fillWorkStatusJson = objectMapper.writeValueAsString(fillWorkStatusResult);
                    Reporter.log("fillWorkStatus Value: " + fillWorkStatusResult.getFillWorkStatus());
                    Assert.assertEquals(fillWorkStatusResult.getFillWorkStatus(), expectedFillWorkStatus, "Fill work status not matching");
                    Reporter.logJSON("fillWorkStatus JSON", fillWorkStatusJson);
                } catch (Exception jsonEx) {
                    Reporter.log("Error converting fillWorkStatus to JSON: " + jsonEx.getMessage());
                }
                results.put("fillWorkStatus", fillWorkStatusResult);
            } else {
                Assert.fail("No fillWorkStatus document found for fulfillmentId: " + originalFulfillmentId);
                Reporter.log("WARNING: No fillWorkStatus document found for fulfillmentId: " + originalFulfillmentId);
                results.put("fillWorkStatus", null);
            }

            if (fillInfoResult != null) {
                Reporter.log("fillInfo Document Found ");
                try {
                    String fillInfoJson = objectMapper.writeValueAsString(fillInfoResult);
                    Reporter.log("Fill work status value:" + fillInfoResult.getFillWork().getOrderLineItem().getFillWorkStatus());
                    Assert.assertEquals(fillInfoResult.getFillWork().getOrderLineItem().getFillWorkStatus(), expectedFillWorkStatus, "Fill work status not matching");
                    Reporter.logJSON("fillInfo JSON:", fillInfoJson);
                } catch (Exception jsonEx) {
                    Reporter.log("Error converting fillInfo to JSON: " + jsonEx.getMessage());
                }
                results.put("fillInfo", fillInfoResult);
            } else {
                Assert.fail("No fillInfo document found for fulfillmentId: " + originalFulfillmentId);
                Reporter.log("WARNING: No fillInfo document found for fulfillmentId: " + originalFulfillmentId);
                results.put("fillInfo", null);
            }
            return results;

        } catch (Exception e) {
            Reporter.log("Failed to fetch fill info documents from Cosmos DB: " + e.getMessage());
            throw new RuntimeException("Failed to fetch fill info documents from Cosmos DB", e);
        }
    }

    /**
     * Fetches fillWorkStatus document from Cosmos DB fill_info container
     *
     * @return FillWorkStatusCosmosResponse - The fillWorkStatus document or null if not found
     */
    public FillWorkStatusCosmosResponse fetchFillWorkStatusFromCosmosDB(String fillWorkStatus) {
        Map<String, Object> results = fetchFillInfoDocumentsFromCosmosDB(fillWorkStatus);
        return (FillWorkStatusCosmosResponse) results.get("fillWorkStatus");
    }

    /**
     * Fetches fillInfo document from Cosmos DB fill_info container
     *
     * @return FillInfoCosmosResponse - The fillInfo document or null if not found
     */
    public FillInfoCosmosResponse fetchFillInfoFromCosmosDB(String fillWorkStatus) {
        Map<String, Object> results = fetchFillInfoDocumentsFromCosmosDB(fillWorkStatus);
        return (FillInfoCosmosResponse) results.get("fillInfo");
    }

    /**
     * Converts any object to pretty-printed JSON string
     *
     * @param object - The object to convert to JSON
     * @return String - Pretty-printed JSON representation of the object
     */
    public String toJsonString(Object object) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            Reporter.log("Error converting object to JSON: " + e.getMessage());
            return object != null ? object.toString() : "null";
        }
    }

    /**
     * Check rx_fill_activity table for specific activity code
     *
     * @param activityCode The activity code to verify
     *                     USAGE: When you need both custom fill ID and custom activity code.
     *                     This is the most flexible method for different test scenarios.
     *                     Example: checkRxFillActivityForOverridePillCount(12345, 3768);
     */
    public void checkRxFillActivityForOverridePillCount(int activityCode) {
        int fillID = connexusAppUtils.getFillId(rxNbr);
        String query = "SELECT activity_code FROM informix.rx_fill_activity WHERE rx_fill_id = " + fillID + " AND activity_code = " + activityCode;
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        if (result != null && result.get("activity_code") != null) {
            int foundActivityCode = Integer.parseInt(result.get("activity_code").toString());
            Assert.assertEquals(foundActivityCode, activityCode, "Activity code mismatch");
            Reporter.log("Activity code " + activityCode + " found for rx_fill_id: " + fillID);
        } else {
            Assert.fail("Activity code " + activityCode + " not found for rx_fill_id: " + fillID);
        }
    }

    /**
     * Gets the new rxFillId from token_mapping table using originalFulfillmentId
     *
     * @return int - The related_id (new rxFillId) from token_mapping table
     */
    public int getNewRxFillIdFromTokenMapping() {
        if (originalFulfillmentId == null || originalFulfillmentId.isEmpty()) {
            Reporter.log("ERROR: originalFulfillmentId is null or empty. Cannot query token_mapping.");
            throw new RuntimeException("originalFulfillmentId is required for token_mapping query - ensure performGetFillInfo is called first");
        }
        return connexusAppUtils.getRelatedFillIdFromTokenMapping(originalFulfillmentId);
    }

    /**
     * Updates the rxFillId and resets orderId for subsequent operations after handover.
     * This should be called after performSetFillInfo when a new fill is created.
     * It queries token_mapping to get the new rxFillId and updates the orderId.
     * Validates that the new rxFillId is different from the original.
     *
     * @param storeNbr - Store number for database query
     */
    public void updateRxFillIdFromTokenMapping(int storeNbr) {
        try {
            // Store original rxFillId for validation
            int originalRxFillId = rxFillId;

            // Get new rxFillId from token_mapping using originalFulfillmentId
            int newRxFillId = getNewRxFillIdFromTokenMapping();

            // Validate that new fill ID is different from original
            Assert.assertNotEquals(newRxFillId, originalRxFillId,
                    "New rxFillId should be different from original. Original: " + originalRxFillId + ", New: " + newRxFillId);
            Reporter.log("Validated: New rxFillId (" + newRxFillId + ") is different from original (" + originalRxFillId + ")");

            Reporter.log("Updating rxFillId from " + originalRxFillId + " to " + newRxFillId);

            // Update the instance variable
            rxFillId = newRxFillId;

            // Reset orderId so it gets fetched fresh for the new fill
            orderId = 0;

            // Get the new orderId for the new rxFillId
            String orderQuery = "SELECT order_id FROM rx_order_detail WHERE rx_fill_id = " + rxFillId;
            Map<String, Object> orderResult = automationManager.getConnexusDB(storeNbr).executeQuery(orderQuery);

            if (orderResult != null && orderResult.get("order_id") != null) {
                orderId = Integer.parseInt(orderResult.get("order_id").toString());
                Reporter.log("Updated orderID with new rxFillId: " + rxFillId);
            } else {
                Reporter.log("WARNING: Could not find orderId for new rxFillId: " + rxFillId);
            }

            Reporter.log("Successfully updated rxFillId from token_mapping for handover scenario");
        } catch (Exception e) {
            Reporter.log("Failed to update rxFillId from token_mapping: " + e.getMessage());
            throw new RuntimeException("Failed to update rxFillId from token_mapping", e);
        }
    }

    /**
     * Finds and assigns WCF bag using a new rxFillId obtained from token_mapping.
     * This is used in handover scenarios where performSetFillInfo creates a new fill.
     *
     * @param storeId - Store number
     * @return int - The assigned bag number
     */
    public int findAndAssignWCFBagForNewFill(int storeId) {
        try {
            // First update rxFillId from token_mapping
            updateRxFillIdFromTokenMapping(storeId);

            // Now call the regular findAndAssignWCFBag which will use the updated rxFillId and orderId
            return findAndAssignWCFBag(storeId);
        } catch (Exception e) {
            Reporter.log("Failed to find and assign WCF bag for new fill: " + e.getMessage());
            throw new RuntimeException("Failed to find and assign WCF bag for new fill", e);
        }
    }


    public void performManualVerificationOverride() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            // Navigate to Current Rx menu and select Manual Verification Override
            // Using keyboard shortcuts: Alt+U (Current Rx menu), then (Manual Verification Override)
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U);
            for (int i = 0; i < 8; i++) {
                connexusStartPage.pressKeys(KeyEvent.VK_DOWN);
            }
            connexusStartPage.pressKeys(KeyEvent.VK_ENTER);
            Reporter.log("Selected Manual Verification Override from Current Rx menu");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (!visVerPage.isElementEnabled(visVerPage.reviewAllImages)) {
                Assert.assertTrue(true);
                Reporter.log("Review all images button disabled");
                Reporter.log("All images sent in update fulfillment info API loaded");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Review all images button not disabled");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            // Click Accept button
            visVerPage.clickAccept();
        } catch (Exception ex) {
            Reporter.log("Error in performManualVerificationOverride: " + ex.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            ex.printStackTrace();
            Assert.fail("Failed to perform Manual Verification Override: " + ex.getMessage());
        }
    }

    /**
     * Performs save-rts-info API call to save RTS vial information for filling the rx
     * Uses rtsVialItems dynamically extracted from getFillInfo response
     *
     * @param inputData - Test data containing additional RTS vial information (drugLot, drugExpiryDate, etc.)
     * @param storeId   - Store number
     * @return ServiceResponse - The API response
     */
    public ServiceResponse performSaveRtsInfo(Map<String, String> inputData, int storeId) {
        try {
            // Use originalFulfillmentId (GUID) for save-rts-info API
            if (originalFulfillmentId == null || originalFulfillmentId.isEmpty()) {
                Reporter.log("ERROR: originalFulfillmentId is null or empty. Cannot proceed with saveRtsInfo.");
                throw new RuntimeException("originalFulfillmentId (GUID) is required for save-rts-info API call");
            }

            if (rtsVialItemsList == null || rtsVialItemsList.isEmpty()) {
                Reporter.log("ERROR: rtsVialItemsList is null or empty. No RTS vials available from getFillInfo.");
                throw new RuntimeException("rtsVialItemsList is required for save-rts-info API call - ensure performGetFillInfo is called first");
            }

            String userId = propertyReader.getProperty("cnx.ho.userName");

            // Build RtsVialItemsUsed list - use only the first RTS vial item
            List<RtsVialItemUsed> rtsVialItemsUsed = new ArrayList<>();
            int scanSeqNbr = 1;

            // Take only the first RTS vial item even if multiple are present
            FillingSapsRtsVialItemsContents vialItem = rtsVialItemsList.get(0);
            Reporter.log("Using single RTS vial item (total available: " + rtsVialItemsList.size() + ")");

            // Get vialExpDate with null check - provide default if null to prevent SignatureGenerator errors
            String vialExpDate = vialItem.getVialExpDate() != null && !vialItem.getVialExpDate().isEmpty()
                    ? vialItem.getVialExpDate()
                    : new SimpleDateFormat("yyyy-MM-dd").format(
                    Date.from(LocalDate.now().plusYears(1).atStartOfDay(ZoneId.systemDefault()).toInstant()));

            // Build DrugLotInfo - use inputData for drugLot and drugExpiryDate if provided, else use defaults
            DrugLotInfo drugLotInfo = DrugLotInfo.builder()
                    .drugExpiryDate(inputData.getOrDefault("rts_drugExpiryDate", vialExpDate))
                    .drugLot(inputData.getOrDefault("rts_drugLot", "RTS1107"))
                    .lotSeqNumber(scanSeqNbr)
                    .build();

            // Build RtsVialItemUsed from getFillInfo response data
            RtsVialItemUsed rtsVialItemUsed = RtsVialItemUsed.builder()
                    .rtsVialId(vialItem.getRtsVialId())
                    .vialConsumed(Boolean.parseBoolean(inputData.getOrDefault("rts_vialConsumed", "true")))
                    .itemQty(vialItem.getItemQty())
                    .vialExpDate(vialExpDate)
                    .scanSeqNbr(scanSeqNbr)
                    .drugLotInfo(Collections.singletonList(drugLotInfo))
                    .build();

            rtsVialItemsUsed.add(rtsVialItemUsed);

            Reporter.log("Built RtsVialItemUsed from getFillInfo - rtsVialId: " + vialItem.getRtsVialId() +
                    ", itemQty: " + vialItem.getItemQty() + ", vialExpDate: " + vialExpDate);

            boolean clearRts = Boolean.parseBoolean(inputData.getOrDefault("rts_clearRts", "false"));

            Reporter.log("Calling save-rts-info API with parameters:");
            Reporter.log("  fulfillmentId (GUID): " + originalFulfillmentId);
            Reporter.log("  deviceName: " + deviceName);
            Reporter.log("  storeNbr: " + storeId);
            Reporter.log("  requestUser: " + userId);
            Reporter.log("  rtsVialItemsUsed count: " + rtsVialItemsUsed.size());
            Reporter.log("  clearRts: " + clearRts);

            ServiceResponse saveRtsInfoResp = FillingVVWrapper_API.saveRtsInfoReq(
                    originalFulfillmentId,
                    rtsVialItemsUsed,
                    clearRts,
                    deviceName,
                    userId,
                    storeId
            );

            Reporter.log("save-rts-info API response status code: " + saveRtsInfoResp.getStatusCode());
            Reporter.log("save-rts-info API response body: " + saveRtsInfoResp.getDataResponse());

            if (saveRtsInfoResp.getStatusCode() == 200) {
                Reporter.log("save-rts-info API call successful");
                // Validate that fill_info document has ONLY the rtsVialItems info sent in request
                Reporter.log("Validation: Service responded with 200 OK");
            } else {
                Reporter.log("save-rts-info API call failed with status code: " + saveRtsInfoResp.getStatusCode());
                Assert.fail("save-rts-info API call failed with status code: " + saveRtsInfoResp.getStatusCode());
            }

            return saveRtsInfoResp;

        } catch (Exception e) {
            Reporter.log("Failed to perform save-rts-info: " + e.getMessage());
            throw new RuntimeException("Failed to perform save-rts-info", e);
        }
    }

    public void validateCompoundDrugOnVVScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (name == null || name.length < 2) {
                throw new IllegalStateException("Invalid patient name data in file");
            }
            String compoundValue = inputData.get("COMPOUND");
            if (compoundValue == null) {
                throw new IllegalArgumentException("Missing required parameter 'COMPOUND' in test data");
            }

            // Verify Rx is in Visual Verify queue
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            Assert.assertEquals(rxStatus, WorkQueue.VISUAL_VERIFY.getWorkQueue(),
                    "Rx is not in Visual Verify queue. Current status: " + rxStatus);

            // Launch order search and search for the patient
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);

            // Open the patient record (force pull to VV screen)
            patientSearchPage.openFirstPatientRecord();
            String prescribedProductName = visVerPage.productPrescribedName();
            Assert.assertTrue(prescribedProductName.toUpperCase().contains(inputData.get("COMPOUND")), "Prescribed product should be 'COMPOUND' but found: " + prescribedProductName);
            Reporter.log(" Prescribed Product is :" + prescribedProductName);
            String dispensedProductname = visVerPage.productDispensedName();
            Assert.assertTrue(dispensedProductname.toUpperCase().contains(inputData.get("COMPOUND")), "Dispensed product should be 'COMPOUND' but found: " + dispensedProductname);
            Reporter.log(" Dispensed Product is :" + dispensedProductname);
            String productNDCNumber = visVerPage.getProductNDCNumber();
            Assert.assertNull(productNDCNumber, "Expected text to be null");

            visVerPage.clickRxFillHistory();
            // Validate popup
            Assert.assertTrue(visVerPage.isElementDisplayed(AppiumBy.accessibilityId("TitleBar"), 10), "Rx Fill History popup not displayed - TitleBar element not found");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log(" Rx Fill History popup opened and validated");
            // Close the popup
            visVerPage.clickCancel();

            visVerPage.clickPtFillHistory();
            Assert.assertTrue(visVerPage.isElementDisplayed(AppiumBy.accessibilityId("TitleBar"), 10), "Patient Fill History popup not displayed - TitleBar element not found");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log(" Patient Fill History popup opened and validated");
            // Close the popup
            visVerPage.clickCancel();

            visVerPage.clickViewCoflicts();
            Assert.assertTrue(visVerPage.isElementDisplayed(AppiumBy.accessibilityId("TitleBar"), 10), "DUR Conflicts popup not displayed - TitleBar element not found");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log(" DUR Conflicts popup opened and validated");
            // Close the popup
            visVerPage.clickCancel();
            // A short delay is required between cancelling the popup and opening another work queue on the same page.
            automationManager.performSleep(10);
            visVerPage.clickCounsel();
            counselPage.acceptAll();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            counselPage.clickAccept();
            Reporter.log("Counsel Completed");
            counselPage.clickAccept();

            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test validation Failed: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    visVerPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateEscapeKeyToCloseManualVVPopUpAndVVScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.VISUAL_VERIFY.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in Visual verify queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Visual verify Queue");
            }
            // Escape key to close Manual VV pop up and screen
            validateManualVVPopUpDisplayed();
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close Manual vv pop up and VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void validateF3KeyToCloseManualVVPopUpAndVVScreen() {
        try {
            // F3 key to close Manual VV pop up and screen
            validateManualVVPopUpDisplayed();
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close Manual vv pop up and VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void validateEnterAndEscapeKeysToCloseManualVVPopUpAndScreen() {
        try {
            // Press Enter key to close Manual VV pop up.
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to close Manual vv pop up.");
            validateManualVVPopUpClosed();
            //Press Escape key to close manual vv screen after closing Manual vv pop up.
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close manual VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void validateEnterAndF3KeysToCloseManualVVPopUpAndScreen() {
        try {
            // Press Enter key to close Manual VV pop up.
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to close Manual vv pop up.");
            validateManualVVPopUpClosed();
            //F3 to close VVscreen
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close Manual VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void validateF2AndEscapeKeysToCloseManualVVPopUpAndScreen() {
        try {
            // F2 key to close Manual VV pop up.
            validateManualVVPopUpDisplayed();
            pressF2Keyword();
            Reporter.log("Pressed F2 key to close Manual vv pop up.");
            validateManualVVPopUpClosed();
            //Press Escape key to close manual vv screen after closing Manual vv pop up.
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close manual VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void validateF2AndF3KeysToCloseManualVVPopUpAndScreen() {
        try {
            // F2 key to close Manual VV pop up.
            validateManualVVPopUpDisplayed();
            pressF2Keyword();
            Reporter.log("Pressed F2 key to close Manual vv pop up.");
            validateManualVVPopUpClosed();
            //F3 to close VVscreen
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close Manual VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void openAndCloseModifyDetailScreenByUsingEscapeKey() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // ESC key close Modify detail screen and VV screen.
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to close Manual vv pop up.");
            validateManualVVPopUpClosed();

            modifyDetails.launchModifyDetailScreen();
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close Modify detail screen.");
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close manual vv screen.");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void openAndCloseModifyDetailScreenByUsingF3Keys() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // F3 key to close Modify detail screen and VV screen.
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to close Manual vv pop up.");
            validateManualVVPopUpClosed();

            modifyDetails.launchModifyDetailScreen();
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close modify detail screen");
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close manual vv screen.");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void PressF2ToCompleteManualVV() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // F3 key to close Modify detail screen and VV screen.
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to close Manual vv pop up.");
            validateManualVVPopUpClosed();

            modifyDetails.launchModifyDetailScreen();
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close modify detail screen");
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();

            //Press F2 to complete manual VV.
            pressF2Keyword();
            Reporter.log("Pressed F2 key to complete manual vv.");
        } catch (Throwable e) {
            Assert.fail("Manual VV screen not closed " + e.getMessage());
        }
    }

    public void pressEnterKeyword() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void pressF3Keyword() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_F3);
            robot.keyRelease(KeyEvent.VK_F3);
            automationManager.performSleep(2);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void pressF2Keyword() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_F2);
            robot.keyRelease(KeyEvent.VK_F2);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void validateShortCutsOrHotKeysInManualVVScreen() {
        validateEscapeKeyToCloseManualVVPopUpAndVVScreen();
        validateF3KeyToCloseManualVVPopUpAndVVScreen();
        validateEnterAndEscapeKeysToCloseManualVVPopUpAndScreen();
        validateEnterAndF3KeysToCloseManualVVPopUpAndScreen();
        validateF2AndEscapeKeysToCloseManualVVPopUpAndScreen();
        validateF2AndF3KeysToCloseManualVVPopUpAndScreen();
        openAndCloseModifyDetailScreenByUsingEscapeKey();
        openAndCloseModifyDetailScreenByUsingF3Keys();
        PressF2ToCompleteManualVV();
    }

    public void validateVVScreenClosed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!visVerPage.isElementDisplayed(visVerPage.nextButton)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("VV pop up and VV Screen closed");
            } else {
                Assert.fail(" VV screen not closed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            Assert.fail("VV screen not closed " + e.getMessage());
        }
    }

    public void validateModifyDetailScreenClosed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!modifyDetails.isTxtPrescriberQtyDisplayed()) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Modify Details screen closed");
            } else {
                Assert.fail("Modify Details screen not closed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            Assert.fail("Modify Details screen not closed " + e.getMessage());
        }
    }

    public void validateManualVVPopUpClosed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (visVerPage.isElementDisplayed(visVerPage.manualVVPopUp)) {
                Assert.fail("Manual VV popup is still displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            Assert.fail("Manual VV pop up not closed " + e.getMessage());
        }
    }

    public void validateManualVVPopUpDisplayed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (visVerPage.isElementDisplayed(visVerPage.manualVVPopUp)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Manual vv pop up displayed");
            } else {
                Assert.fail("Manual VV pop up not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            Assert.fail("Manual VV pop up not displayed " + e.getMessage());
        }
    }

    /**
     * Performs Visual verify for multiple rx.
     *
     * @param
     */
    public void performMultiRxVisualVerify() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String rxStatus;
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxStatus = orderSearch.getRXStatusForPatient(multiRxNbr.get(i), 0);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue()));
            }
            rxNbr = multiRxNbr.get(0);
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            if (visVerPage.isElementDisplayed(visVerPage.fridgeTag)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Fridge tag displayed in VV screen");
            } else {
                Assert.fail("Fridge tag not displayed in VV screen");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            pressF2Keyword();

            rxNbr = multiRxNbr.get(1);
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            if (visVerPage.isElementDisplayed(visVerPage.mixTag)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Mix tag displayed in VV screen");
            } else {
                Assert.fail("Mix tag not displayed in VV screen");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            pressF2Keyword();
            Reporter.log("Visual verify completed.");
        } catch (Throwable e) {
            Reporter.log("Test failed at Visual Verify queue " + e.getMessage());
            Assert.fail("Visual verify not completed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void openRxInOrderSearchAndValidateVerificationImages(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();

            // Navigate to View > Verification Images
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_V);
            for (int i = 0; i < 10; i++) {
                connexusStartPage.pressKeys(KeyEvent.VK_DOWN);
            }
            connexusStartPage.pressKeys(KeyEvent.VK_ENTER);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.clickToValidateNextImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToValidatePreviousImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToRotateImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOKBtn();

            // Press F7 to search for Rx
            rxLookUp.launchRxLookUpPage();

            // Perform search for the Rx number in F7 screen
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            // Navigate to View > Verification Images
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_V);
            for (int i = 0; i < 9; i++) {
                connexusStartPage.pressKeys(KeyEvent.VK_DOWN);
            }
            connexusStartPage.pressKeys(KeyEvent.VK_ENTER);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.clickToValidateNextImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToValidatePreviousImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToRotateImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOKBtn();
            //To close F7 Screen
            modifyDetails.clickCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        } catch (Exception ex) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to open Verification Images: " + ex.getMessage());
        }

    }

    /**
     * Validates verification images availability for multiple fill IDs
     * This method checks that verification images are available for both fill IDs
     */
    public void validateVerificationImagesForMultipleFillIds() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Launch F7 RxLookUp screen
            rxLookUp.launchRxLookUpPage();

            // Perform search for the Rx number in F7 screen
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();

            Reporter.log("Opened F7 screen and searched for Rx: " + rxNbr);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            // Navigate to View > Verification Images to check availability
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_V);
            automationManager.performSleep(1);
            for (int i = 0; i < 9; i++) {
                connexusStartPage.pressKeys(KeyEvent.VK_DOWN);
            }
            connexusStartPage.pressKeys(KeyEvent.VK_ENTER);

            modifyDetails.clickToValidateNextImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToValidatePreviousImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickToRotateImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOKBtn();
            // Navigate and select cancel fill in rx lookup screen
            rxLookUp.selectCancelFill();
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_V);
            // Check if Verification Image option is present
            boolean isVerificationImagePresent = rxLookUp.verificationImageOption();
            Reporter.logScreenShot(isVerificationImagePresent ? Status.FAIL : Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            // Validate: PASS if NOT present, FAIL if present
            if (isVerificationImagePresent) {
                Assert.fail("Verification Image option IS present in View menu - Expected: NOT present");
            } else {
                Assert.assertTrue(true);
                Reporter.log("Verification Image option is NOT present in View menu as expected");
            }
            // Close the verification images screen
            modifyDetails.clickCancel();

        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate verification images for multiple fill IDs: " + e.getMessage());
        }
    }

    public int getRxFillId() {
        return rxFillId;
    }

    /**
     * Modifies dispensed item to move fill back to Filling queue
     * This creates a new fill ID and updates the rxFillId field
     *
     * @param inputData - Test data containing dispensed quantity
     */
    public void modifyDispensedItemAndMoveToFillingQueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("Modifying dispensed item to move fill back to Filling queue");

            int currentFillId = rxFillId;
            Reporter.log("Current Fill ID before modification: " + currentFillId);

            // Modify dispensed quantity
            modifyDetails.modifyQtyDispensed(inputData);

            modifyDetails.clickAccept();
            modifyDetails.isElementDisplayed(modifyDetails.lblMessageOnPopUp);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickYes();
            modifyDetails.isElementDisplayed(modifyDetails.lblMessageOnPopUp);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOKBtn();

            // Wait for the modification to process and new fill to be created
            automationManager.performSleep(8);

            // Add retry logic to fetch the new fill ID
            int retryCount = 0;
            int maxRetries = 3;
            boolean newFillFound = false;

            while (retryCount < maxRetries && !newFillFound) {
                // Get the new fill ID and order ID after modification in a single query
                Map<String, Object> fillOrderDetails = connexusAppUtils.getFillAndOrderIds(rxNbr);
                rxFillId = Integer.parseInt(fillOrderDetails.get("rx_fill_id").toString());
                orderId = Integer.parseInt(fillOrderDetails.get("order_id").toString());

                Reporter.log("Attempt " + (retryCount + 1) + " - New Fill ID: " + rxFillId + ", Original Fill ID: " + currentFillId);

                if (rxFillId != currentFillId && rxFillId != 0) {
                    newFillFound = true;
                } else {
                    retryCount++;
                    if (retryCount < maxRetries) {
                        Reporter.log("Fill ID not updated yet, waiting 3 more seconds before retry...");
                        automationManager.performSleep(3);
                    }
                }
            }
            Reporter.log("New Fill ID after modification: " + rxFillId);
            performChkDUR();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Filling.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.FILLING.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in Filling queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling Queue");
            }

            // Validate that a new fill ID was created
            if (rxFillId == currentFillId) {
                Reporter.log("Fill ID did not change after modification. Original: " + currentFillId + ", New: " + rxFillId);
                Assert.fail("Expected new fill ID after modification, but got the same ID: " + rxFillId);
            } else {
                Reporter.log("New fill ID created. Original: " + currentFillId + ", New: " + rxFillId);
            }
        } catch (Exception e) {
            Reporter.log("Failed to modify dispensed item and move to filling queue: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to modify dispensed item and move to filling queue", e);
        }
    }

    public void validateManualVVScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                Assert.assertTrue(true);
                Reporter.log("RX is in Visual verify queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Visual verify Queue");
            }
            validateManualVVPopUpDisplayed();
            pressEnterKeyword();
            // Take screenshot of VV screen
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressEnterKeyword();
            Reporter.log("Manual VV Completed");

        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Manual VV screen validation failed: " + e.getMessage());
        }
    }

    public void validateHazardousTag() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (visVerPage.isElementDisplayed(visVerPage.hazardousTag)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Hazardous tag displayed in VV screen");
            } else {
                Assert.fail("Hazardous tag not displayed in VV screen");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Manual VV screen validation failed: " + e.getMessage());
        }
    }

    public void verifyGetSetFillInfoUnassigned(int storeNbr, String setFillStatusInRequestList, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        bagNbr = dbwrapper.getToteNumber(storeNbr);
        patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        Reporter.log("patient is" + patientId);
        int orderId = connexusAppUtils.getOrderId(rxNbr);
        fomUtils.getWorkForFill(storeNbr, bagNbr, orderId);
        int retries = 5;
        boolean success = false;
        for (int i = 0; i < retries; i++) {
            sapsGetFillInforesp = api.performSapsgetFillInfo(prop.getProperty("fom.setSource"), prop.getProperty("fom.setDeviceName"), storeNbr, String.valueOf(orderId), bagNbr, prop.getProperty("fom.newuserId"), prop.getProperty("fom.assignedOrd"));
            if (sapsGetFillInforesp.getStatusCode() == 200) {
                success = true;
                break;
            }
        }
        Assert.assertTrue(success, "GetFillInfo Saps service never returned 200 within timeout");
        Reporter.log("getFillInfo API returned 200 as expected");
        sapsGetFillInfoResponse = sapsGetFillInforesp.getDataResponse(FillingGetFillInfoSapsResponse.class);
        sapsSetFillInfo.validateSapsSetFillInfoAPI(storeNbr, sapsGetFillInfoResponse, setFillStatusInRequestList, problemCodeForCancelFill, isRTSVialUsed);
    }


    public void verifyUpdatedFillID () {
        newFillID = connexusAppUtils.getFillId(rxNbr);
        try {
            Assert.assertNotEquals(fillID, newFillID, "Old Fill ID is not cancelled");
            Reporter.log("Old Fill ID is cancelled and a new Fill ID is created"+ newFillID);
        } catch (Throwable e) {
            Assert.fail("Old Fill ID is matching with new fill ID"+e.getMessage());
        }
    }

    public void verifyRTSlabelPopupText (Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actualPopupText = modifyDetails.getTextFromPopUp();
            if (actualPopupText.equalsIgnoreCase(inputData.get("PopUp_Message"))){
                Reporter.log("RTS label Pop up displayed with Yes and NO buttons");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickButtonYes();
            }else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("RTS Popup is not displayed");
            }
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("RTS Popup Message is not displayed" +e.getMessage());
        }
    }

    public void verifyworkQueueUpdatePopupText (Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actualPopupText = modifyDetails.getTextFromPopUp();
            if (actualPopupText.equalsIgnoreCase(inputData.get("POPUP_Message_ChkDur"))) {
                Reporter.log("WorkQueue update popup message is displayed");
                Reporter.log("Actual Popup Text is:" + actualPopupText);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickConnexusOk();
            }else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Updated WorkQueue message is not displayed");
            }
        }catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("Second popup for updated work queue is not displayed"+ e.getMessage());
        }
    }

    public void updateDispenseItemInModifyDetailPage(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            fillID = connexusAppUtils.getFillId(rxNbr);
            Reporter.log("Fill ID before updating the Dispensed Item " + fillID);
            modifyDetails.launchModifyDetailScreen();
            String ndcNumber = modifyDetails.getNdcNumber();
            Reporter.log("Before updating the Dispensed item in modify details " +  ndcNumber);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.setNdcNumber(inputData.get("New_DispensedItem"));
            String updatedNDCNumber = modifyDetails.getNdcNumber();
            if (updatedNDCNumber.equals(ndcNumber)){
                Assert.fail("Dispense Item is not updated in Modify Details Page");
            }else {
                Assert.assertTrue(true);
                Reporter.log("After updating the Dispensed item in modify details "+  updatedNDCNumber);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            modifyDetails.clickAccept();
            modifyDetails.checkAndClickWarning();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("Dispense Item is not updated in Modify Details Page"+e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void MoveRXtoFilling() {
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            Reporter.log("rxNumber : " + rxNbr);
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                perform4Point(false);
                performChkDUR();
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                performChkDUR();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("WorkQueue is not in 4 Point/CHK_DUR/FILLING");
        }
    }

    public void resetTestData() {
        rxFillId = 0;
    }

    public void validateRTSLablePopUpTextByUpdatingDispenseQuantityInModifyDetailScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            verifyRxInPickup(rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (modifyDetails.isDxCodeDisplayed()) {
                Assert.assertTrue(true);
                Reporter.log("Modify details screen displayed");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clearText(modifyDetails.dispQunatity);
                modifyDetails.enterDespQty(inputData.get("QtyDispensed"));
                Reporter.log("Updated Dispense Quantity");
                modifyDetails.clickAccept();
                modifyDetails.isElementDisplayed(modifyDetails.lblMessageOnPopUp);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(modifyDetails.getTextFromPopUp().trim(),inputData.get("RTS_POPUP_TEXT"), "Pop up text not matching");
                modifyDetails.clickYes();
                modifyDetails.isElementDisplayed(modifyDetails.lblMessageOnPopUp);
                Assert.assertEquals(modifyDetails.getTextFromPopUp().replaceAll("[\r\n]+", ""),inputData.get("DUR_POPUP_TEXT"), "Pop up text not matching");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOKBtn();
            } else {
                Assert.fail("Modify details screen not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Dispense quantity update failed"+e.getMessage());
        }
    }

    public void validatePopUpTextByUpdatingSigCodeInModifyDetailScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            verifyRxInPickup(rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (modifyDetails.isDxCodeDisplayed()) {
                Assert.assertTrue(true);
                Reporter.log("Modify details screen displayed");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clearText(modifyDetails.txtSig);
                modifyDetails.enterSig(inputData.get("SIG"));
                Reporter.log("Updated SIG Code");
                connexusStartPage.pressTabKey();
                modifyDetails.click(modifyDetails.dispQunatity);
                modifyDetails.clickAccept();
                Assert.assertEquals(modifyDetails.getTextFromPopUp().replaceAll("[\r\n]+", ""), inputData.get("FOUR_POINT_POPUP_TEXT"), "Pop up text not matching");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOKBtn();
            } else {
                Assert.fail("Modify details screen not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("SIG code update failed"+e.getMessage());
        }
    }

    public void validatePopUpTextByUpdatingDrugExpiryDateInModifyDetailScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            verifyRxInPickup(rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (modifyDetails.isDxCodeDisplayed()) {
                Assert.assertTrue(true);
                Reporter.log("Modify details screen displayed");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.drugExpiryDateSelection(-1);
                Reporter.log("Updated Drug Expiry Date");
                modifyDetails.clickAccept();
                Assert.assertEquals(modifyDetails.getTextFromPopUp().replaceAll("[\r\n]+", ""), inputData.get("VV_POPUP_TEXT"), "Pop up text not matching");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOKBtn();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.pressEnterKey();
            } else {
                Assert.fail("Modify details screen not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Drug expiry date update failed"+e.getMessage());
        }
    }

    public void validatePopUpTextByUpdatingFillDateInModifyDetailScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            verifyRxInPickup(rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (modifyDetails.isDxCodeDisplayed()) {
                Assert.assertTrue(true);
                Reporter.log("Modify details screen displayed");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.rxWrittenDateSelection(-4);
                modifyDetails.rxFillDateSelection(-1);
                Reporter.log("Updated Fill Date");
                connexusStartPage.pressTabKey();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickAccept();
                Assert.assertEquals(modifyDetails.getTextFromPopUp().replaceAll("[\r\n]+", " "), inputData.get("FOUR_POINT_POPUP_TEXT"), "Pop up text not matching");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOKBtn();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.pressEnterKey();
            } else {
                Assert.fail("Modify details screen not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Fill date update failed"+e.getMessage());
        }
    }

    public void outComesFillingAPI(Map<String, String> inputData){
        findAndAssignWCFBag(connexusAppUtils.getStoreId());
        performGetFillInfo(connexusAppUtils.getStoreId());
        validateNumberOfLables();
        performSendFulfillment(inputData.get("RACK_VALUE"), connexusAppUtils.getStoreId());
        fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        performPrintRxLabel(inputData, connexusAppUtils.getStoreId());
        fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        performUpdateFulfillment(inputData, inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
    }

    public void pressF9Keyword() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_F9);
            robot.keyRelease(KeyEvent.VK_F9);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void pressTabKeyword() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void openAutoVVScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            automationManager.performSleep(5);
            if (visVerPage.isElementDisplayed(visVerPage.unableToReplenishOkBtn, 5)) {
                visVerPage.click(visVerPage.unableToReplenishOkBtn);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Auto VV screen opened for rxNbr: " + rxNbr);
        } catch (Throwable e) {
            Assert.fail("Failed to open Auto VV screen: " + e.getMessage());
        }
    }

    public void
    validateAutoVVEscapeKeyToCloseVVScreen() {
        try {
            openAutoVVScreen();
            pressTabKeyword();
            pressTabKeyword();
            automationManager.performSleep(2);
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close Auto VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Auto VV screen not closed with Escape key: " + e.getMessage());
        }
    }

    public void validateAutoVVF3KeyToCloseVVScreen() {
        try {
            openAutoVVScreen();
            pressTabKeyword();
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close Auto VV Screen");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Auto VV screen not closed with F3 key: " + e.getMessage());
        }
    }

    public void validateAutoVVTabKeyToNavigateImagesAndAcceptButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            automationManager.performSleep(4);

            for (int i = 0; i <= ConnexusConstants.IMAGE_COUNT; i++) {
                pressTabKeyword();
            }
            Reporter.log("Pressed Tab key to navigate through images and accept button");
            if (visVerPage.isElementEnabled(visVerPage.btnAccept)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Accept button is enabled after Tab navigation");
            } else {
                Assert.fail("Accept button is not enabled after Tab navigation");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Tab key navigation failed in Auto VV: " + e.getMessage());
        }
    }


    public void validateAutoVVF9KeyToOpenModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressTabKeyword();
            automationManager.performSleep(5);
            pressF9Keyword();
            automationManager.performSleep(2);
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open with F9 key");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            automationManager.performSleep(2);
            Reporter.log("Pressed F3 key to close Modify Details");
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            connexusStartPage.pressEscapeKey();
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("F9 key did not open Modify Details: " + e.getMessage());
        }
    }

    public void validateAutoVVEscapeKeyToCloseModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressTabKeyword();
            automationManager.performSleep(5);
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close Modify Details");
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            connexusStartPage.pressEscapeKey();
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Escape key did not close Modify Details: " + e.getMessage());
        }
    }


    public void validateAutoVVEscapeKeyAfterClosingModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            connexusStartPage.pressEscapeKey();
            Reporter.log("Pressed Escape key to close VV screen after closing Modify Details");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Escape key did not close VV after Modify Details: " + e.getMessage());
        }
    }

    public void validateAutoVVF3KeyAfterClosingModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            pressF3Keyword();
            Reporter.log("Pressed F3 key to close VV screen after closing Modify Details");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("F3 key did not close VV after Modify Details: " + e.getMessage());
        }
    }

    public void validateAutoVVTabKeyAfterClosingModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            pressF3Keyword();
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            for (int i = 0; i <= ConnexusConstants.IMAGE_COUNT; i++) {
                pressTabKeyword();
            }
            Reporter.log("Pressed Tab key to navigate through images and accept button after closing Modify Details");
            if (visVerPage.isElementEnabled(visVerPage.btnAccept)) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Accept button is enabled after Tab navigation");
            } else {
                Assert.fail("Accept button is not enabled after Tab navigation");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Tab key navigation failed after closing Modify Details: " + e.getMessage());
        }
    }

    public void validateAutoVVF2KeyAfterClosingModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            connexusStartPage.pressEscapeKey();
            openAutoVVScreen();
            for (int i = 0; i <= ConnexusConstants.IMAGE_COUNT; i++) {
                pressTabKeyword();
            }
            Reporter.log("Pressed Tab key to navigate through images and accept button");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            pressF2Keyword();
            Reporter.log("Pressed F2 key to complete Auto VV after closing Modify Details");
        } catch (Throwable e) {
            Assert.fail("F2 key did not complete VV after Modify Details: " + e.getMessage());
        }
    }

    public void validateAutoVVEnterKeyAfterClosingModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openAutoVVScreen();
            automationManager.performSleep(2);
            pressF9Keyword();
            Reporter.log("Pressed F9 key to open Modify Details");
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen did not open");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressF3Keyword();
            modifyDetails.clickButtonYes();
            validateModifyDetailScreenClosed();
            for (int i = 0; i <= ConnexusConstants.IMAGE_COUNT; i++) {
                pressTabKeyword();
            }
            Reporter.log("Pressed Tab key to navigate through images and accept button");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            pressEnterKeyword();
            Reporter.log("Pressed Enter key to complete Auto VV after closing Modify Details");
            validateVVScreenClosed();
        } catch (Throwable e) {
            Assert.fail("Enter key did not complete VV after Modify Details: " + e.getMessage());
        }
    }

    public void validateShortCutsOrHotKeysInAutoVVScreen() {
        validateAutoVVEscapeKeyToCloseVVScreen();
        validateAutoVVF3KeyToCloseVVScreen();
        validateAutoVVTabKeyToNavigateImagesAndAcceptButton();
        validateAutoVVF9KeyToOpenModifyDetails();
        validateAutoVVEscapeKeyToCloseModifyDetails();
        validateAutoVVEscapeKeyAfterClosingModifyDetails();
        validateAutoVVF3KeyAfterClosingModifyDetails();
        validateAutoVVTabKeyAfterClosingModifyDetails();
        validateAutoVVF2KeyAfterClosingModifyDetails();
    }
    public void openDailyVisualVerifyReportAndShowReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.DAILY_VISUALVERIFY_CHECK, AppMenuItemsIndex.PHARMACIST_REPORTS, AppMenuSubItemsIndex.DAILY_VISUAL_VERIFY_CHECK, null);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
        menuBar.clickShowReport();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
        menuBar.click(menuBar.btnCancel);
    }
    /**
     * Performs Visual verify for multiple rx with specific VV types for each RX.
     * @param vvTypes List of VV types for each RX: "AUTO_VV", "MANUAL_VV", "MANUAL_OVERRIDE"
     */
    public void performMultiRxVisualVerify(List<String> vvTypes) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String rxStatus;
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxStatus = orderSearch.getRXStatusForPatient(multiRxNbr.get(i), 0);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue()));
            }

            for (int i = 0; i < vvTypes.size() && i < multiRxNbr.size(); i++) {
                rxNbr = multiRxNbr.get(i);
                String vvType = vvTypes.get(i);

                if ("MANUAL_OVERRIDE".equalsIgnoreCase(vvType)) {
                    performManualVerificationOverride();
                } else if ("MANUAL_VV".equalsIgnoreCase(vvType)) {
                    validateManualVVPopUpDisplayed();
                    pressEnterKeyword();
                    pressF2Keyword();
                } else {
                    // AUTO_VV - default behavior
                    validateFieldsInAutoVVScreen();
                    selectAllImagesAndValidateAcceptButtonEnabled();
                    pressEnterKeyword();
                    pressF2Keyword();
                }
            }
            Reporter.log("Visual verify completed for all RXs.");
        } catch (Throwable e) {
            Reporter.log("Test failed at Visual Verify queue " + e.getMessage());
            Assert.fail("Visual verify not completed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
}
