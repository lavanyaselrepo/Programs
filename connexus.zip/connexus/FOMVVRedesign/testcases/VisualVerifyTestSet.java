package connexus.FOMVVRedesign.testcases;

import com.fasterxml.jackson.core.JsonProcessingException;
import connexus.FOMVVRedesign.testscripts.VisualVerifyTestScript;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.clients.ServiceAdminClient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import hwqe.baseframework.AutomationManager;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class VisualVerifyTestSet {

    VisualVerifyTestScript visualVerifyTestScript= new VisualVerifyTestScript(LoginAs.userType.PHARMACIST_ADFlagOff);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager=new ConnexusAPIManager();
    ServiceAdminClient serviceAdminClient=new ServiceAdminClient();
    public boolean flagUpdated = false;
    String siteId;
    PropertyReader prop = PropertyReader.getInstance();


    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void flagsCheckUp() {

        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31780", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "STG");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Normal Drug, Multi pack, Outcomes filling, Auto VV",
     * Author: Nagarjuna
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E-5267")
    @Test(enabled = true, description = "Normal Drug, Multi pack, Outcomes filling, Auto VV",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5267_Normal_Drug_Multi_Pack_Outcomes_Filling_Auto_VV(Map<String, String> inputData) {
        Reporter.log("Validate Auto VV screen for normal drug with multi pack by using outcomes filling.");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));


        Reporter.log("Validated Auto VV screen for normal drug with multi pack by using outcomes filling.");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Normal Drug, Outcomes Handover, Change NDC from RxOne and fill in outcomes",
     * Author: Pranav (vn58m66)
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E_5266")
    @Test(enabled = true, description = "Verify Normal Drug(LIQ), Outcomes filling, Manual VV",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5266_Verify_NormalDrug_Outcomes_Filling_Manual_VV(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5266_Verify_NormalDrug_Outcomes_Filling_Manual_VV");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31780", "FALSE"); //This flag must be FALSE for LIQ/SOL dosages which come under restricted dosages
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "STG");

        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.restartConnexusService();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateManualVVScreen();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
        Reporter.log("Completed Test: HWPHME2E - 5266 Verify Normal Drug(LIQ), Outcomes filling, Manual VV");

    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Normal Drug, Outcomes Handover, Change NDC from RxOne and fill in outcomes",
     * Author: Pranav (vn58m66)
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E_5269")
    @Test(enabled = true, description = "Verify Normal Drug Outcomes Handover DOOS from RxOne",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5269_Normal_Drug_Outcomes_Handover_DOOS_from_RxOne(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5269_Verify_Normal_Drug_Outcomes_Handover_DOOS_from_RxOne");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(storeNbr);
        visualVerifyTestScript.performGetFillInfo(storeNbr);
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),storeNbr);
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.performSetFillInfo(storeNbr, inputData.get("SET_FILL_STATUS"), Integer.parseInt(inputData.get("SET_FILL_PROBLEM_CODE")), false);
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateRxProblemdescriptionInConnexus(inputData);

    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Normal Drug(Hazardous), exit from Outcomes (UNASSIGNED), fill from outcomes",
     * Author: Nagarjuna (vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E_5270")
    @Test(enabled = true, description = "Normal Drug(Hazardous), exit from Outcomes (UNASSIGNED), fill from outcomes",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5270_Normal_Drug_Exit_From_Outcomes(Map<String, String> inputData) {

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_UNASSIGNED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_UNASSIGNED"));
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.validateHazardousTag();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
    }

    //@Jira(testID = "HWPHME2E_5273")
    @Test(enabled = true, description = "Controlled Drug, Count override when filling in Outcomes, Manual VV",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5273_Controlled_Drug_Outcomes_Filling_In_Outcome(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5273_Controlled_Drug_Outcomes_Filling_In_Outcome");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.checkRxFillActivityForOverridePillCount(Integer.parseInt(inputData.get("ACTIVITY_CODE")));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateManualVVScreen();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
    }


    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Normal Drug, Outcomes Handover, Change NDC from RxOne and fill in outcomes",
     * Author: Pranav (vn58m66)
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E_5268")
    @Test(enabled = true, description = "Verify Normal Drug, Outcomes Handover, Change NDC from RxOne and fill in outcomes",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5268_Normal_Drug_Outcomes_Handover_Change_NDC_from_RxOne_and_FillIn_outcomes(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5268_Verify_Normal_Drug_Outcomes_Handover_Change_NDC_from_RxOne_and_FillIn_outcomes");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.performSetFillInfo(storeNbr, inputData.get("SET_FILL_STATUS"), Integer.parseInt(inputData.get("SET_FILL_PROBLEM_CODE")), false);
        visualVerifyTestScript.findAndAssignWCFBagForNewFill(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,"SUBMITTED");
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB("COMPLETED");
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));


    }

    //@Jira(testID = "HWPHME2E_5265")
    @Test(enabled = true, description = "Outcomes filling using RTS vials",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5265_Normal_Drug_Outcomes_Filling_Using_RTS_Vials(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5265_Normal_Drug_Outcomes_Filling_Using_RTS_Vials");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSaveRtsInfo(inputData, connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_PENDING"));
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));

    }

    //@Jira(testID = "HWPHME2E_5272")
    @Test(enabled = true, description = "Controlled Drug, Count override when filling in Outcomes, Manual VV",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5272_Normal_Drug_Outcomes_filling_RPH_Override_in_VV(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5272_Normal_Drug_Outcomes_filling_RPH_Override_in_VV");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.performManualVerificationOverride();
        visualVerifyTestScript.checkRxFillActivityForOverridePillCount(Integer.parseInt(inputData.get("ACTIVITY_CODE")));
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
    }


    @Test(enabled = true, description = "Compound Drug Filling Workflow with Visual Verify validations",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_3246_CompoundDrugFillingWorkflow(Map<String, String> inputData) {

        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "TRUE");
        visualVerifyTestScript.initializeTestCase(flagUpdated);
        siteId = String.valueOf(Integer.parseInt(prop.getProperty("cnx.store")));
        visualVerifyTestScript.createNewPatient(inputData);
        visualVerifyTestScript.performDropOff(Priority.Critical);
        // Handling input for compounded drug
        visualVerifyTestScript.performInput(inputData,"Regular",true);
        visualVerifyTestScript.perform4Point(false);
        visualVerifyTestScript.performChkDUR();
        visualVerifyTestScript.verifyRxInFillingQueue();
        //Complete filling using classic filling APIs
        visualVerifyTestScript.fillingTestscripts.submitted();
        visualVerifyTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        visualVerifyTestScript.validateCompoundDrugOnVVScreen(inputData);
    }


    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Hot keys / shortcuts validations for Rx requiring manual VV",
     * Author: Nagarjuna
     * ----------------------------------------------------------------------------------------------------------
     */

    //@Jira(testID = "HWPHME2E-5279")
    @Test(enabled = true, description = "Hot keys / shortcuts validations for Rx requiring manual VV",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5279_Hot_Keys_Shortcuts_Validations_For_Rx_Requiring_Manual_VV(Map<String, String> inputData) {
        Reporter.log("Validate Hot keys / shortcuts validations for Rx requiring manual VV");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateShortCutsOrHotKeysInManualVVScreen();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));

        Reporter.log("Validated Hot keys / shortcuts validations for Rx requiring manual VV.");
    }

    //@Jira(testID = "HWPHME2E-5274")
    @Test(enabled = true, description = "Multi Rx with Fridge Item and Mix, Outcomes filling + Classic Filling",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5274_Outcomes_Filling_And_Classic_Filling_For_Multi_Rx(Map<String, String> inputData) throws JsonProcessingException {
        Reporter.log("Validate Multi Rx with Fridge Item and Mix, Outcomes filling + Classic Filling");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31780", "FALSE"); //This flag must be FALSE for LIQ/SOL dosages which come under restricted dosages
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "STG");
        int storeNbr = connexusAppUtils.getStoreId();
        connexusAPIManager.restartConnexusService(String.valueOf(storeNbr));
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        List<InputResponse> fillIdAndOrderId=visualVerifyTestScript.moveToFillingForMultiRx(inputData,patientId,2);
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(0).getRxNbr());
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        //Complete 2nd rx filling using classic filling APIs
        visualVerifyTestScript.fillingTestscripts.classicFilling(Collections.singletonList(200),patientId);
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateRackNumber(inputData.get("MANUAL_RACK_NUMBER"));
        visualVerifyTestScript.performMultiRxVisualVerify();
        visualVerifyTestScript.moveMultiRxToEod(String.valueOf(storeNbr));

        Reporter.log("Validated Multi Rx with Fridge Item and Mix, Outcomes filling + Classic Filling");
    }

    //@Jira(testID = "HWPHME2E_5271")
    @Test(enabled = true, description = "Normal Drug, PillId override when filling in Outcomes, Manual VV",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5271_Normal_Drug_PillId_override_when_filling_in_Outcomes_ManualVV(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_5271_Normal_Drug_PillId_override_when_filling_in_Outcomes_ManualVV");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData,storeNbr,patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.checkRxFillActivityForOverridePillCount(Integer.parseInt(inputData.get("ACTIVITY_CODE")));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateManualVVScreen();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
    }

    @Test(enabled = true, description = "Verify Verification Images for multiple fill IDs after product modification",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5275_Verify_Verification_Images_Multiple_Fill_IDs(Map<String, String> inputData) {
        Reporter.log("Starting Test: Verify_Verification_Images_Multiple_Fill_IDs");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated, false);
        int patientId = visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData, storeNbr, patientId);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"), connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData, connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData, inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        // From ConnexUs Order Search, ConnexUs F7, Open the Rx and validate Verification Images
        visualVerifyTestScript.openRxInOrderSearchAndValidateVerificationImages(inputData);
        visualVerifyTestScript.modifyDispensedItemAndMoveToFillingQueue(inputData);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performSendFulfillment(inputData.get("MANUAL_RACK_VALUE"), connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData, connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData, inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateFieldsInAutoVVScreen();
        visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        visualVerifyTestScript.validateVerificationImagesForMultipleFillIds();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify Fill Modification from Modify details when in VV Queue",
     * Author: Avantika (vn598z6)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3250")
    @Test(enabled = true, description = "Verify Fill Modification from Modify details when in VV Queue",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_3250_Verify_FillModification_fromModifyDetails_inVVQueue(Map<String, String> inputData) {
        Reporter.log("Starting Test: HWPHME2E_3250_Verify_FillModification_fromModifyDetails_inVVQueue");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "FALSE");
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated, false);
        int patientId = visualVerifyTestScript.createPatientAPI(inputData);
        visualVerifyTestScript.moveToFilling(inputData, storeNbr, patientId);
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.verifyRxInFillingQueue();
        visualVerifyTestScript.verifyGetSetFillInfoUnassigned(storeNbr, inputData.get("setFillStatusInRequestList"), Integer.parseInt(inputData.get("problemCodeForCancelFill")), false);
        visualVerifyTestScript.verifyRxInVisualVerifyQueue();
        visualVerifyTestScript.updateDispenseItemInModifyDetailPage(inputData);
        visualVerifyTestScript.verifyRTSlabelPopupText(inputData);
        visualVerifyTestScript.verifyworkQueueUpdatePopupText(inputData);
        visualVerifyTestScript.verifyUpdatedFillID();
        visualVerifyTestScript.MoveRXtoFilling();
        visualVerifyTestScript.verifyRxInFillingQueue();
        visualVerifyTestScript.verifyGetSetFillInfoUnassigned(storeNbr, inputData.get("setFillStatusInRequestList"), Integer.parseInt(inputData.get("problemCodeForCancelFill")), false);
        visualVerifyTestScript.verifyRxInVisualVerifyQueue();
        visualVerifyTestScript.moveRxToEod(String.valueOf(storeNbr));
        visualVerifyTestScript.verifyRxInEOD();
        Reporter.log("=== RX Work queue status is in EOD ===");
    }

    //@Jira(testID = "HWPHME2E-5277")
    @Test(enabled = true, description = "Relabel flow | modify outcomes filled Rx, reroutes to VV , Manual VV with Label changed pop-up",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5277_Modify_Outcomes_Filled_Rx_Reroutes_To_VV_Manual_VV_With_Label_Changed_PopUp(Map<String, String> inputData) throws JsonProcessingException {
        Reporter.log("Validate Relabel flow | modify outcomes filled Rx, reroutes to VV , Manual VV with Label changed pop-up");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated, false);
        int patientId = visualVerifyTestScript.createPatientAPI(inputData);
        List<InputResponse> fillIdAndOrderId = visualVerifyTestScript.moveToFillingForMultiRx(inputData, patientId, 4);

        for (int i = 0; i < visualVerifyTestScript.multiRxNbr.size(); i++) {
            visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(i).getRxNbr());
            Reporter.log("Performing Outcomes Filling API for " + visualVerifyTestScript.rxNbr);
            visualVerifyTestScript.outComesFillingAPI(inputData);
            visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
            visualVerifyTestScript.resetTestData();
        }
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        for (int i = 0; i < visualVerifyTestScript.multiRxNbr.size(); i++) {
            visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(i).getRxNbr());
            visualVerifyTestScript.validateFieldsInAutoVVScreen();
            visualVerifyTestScript.selectAllImagesAndValidateAcceptButtonEnabled();
        }
        //RX1
        visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(0).getRxNbr());
        visualVerifyTestScript.validatePopUpTextByUpdatingSigCodeInModifyDetailScreen(inputData);
        visualVerifyTestScript.perform4Point(false);
        visualVerifyTestScript.connexusStartPage.pressEnterKey();
        visualVerifyTestScript.validateManualVVScreen();
        //RX2
        visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(1).getRxNbr());
        visualVerifyTestScript.validatePopUpTextByUpdatingDrugExpiryDateInModifyDetailScreen(inputData);
        visualVerifyTestScript.validateManualVVScreen();

        //RX3
        visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(2).getRxNbr());
        visualVerifyTestScript.validatePopUpTextByUpdatingFillDateInModifyDetailScreen(inputData);

        visualVerifyTestScript.perform4Point(false);
        visualVerifyTestScript.connexusStartPage.pressEnterKey();
        visualVerifyTestScript.validateManualVVScreen();
        //RX4
        visualVerifyTestScript.rxNbr = String.valueOf(fillIdAndOrderId.get(3).getRxNbr());
        visualVerifyTestScript.validateRTSLablePopUpTextByUpdatingDispenseQuantityInModifyDetailScreen(inputData);
        visualVerifyTestScript.performChkDUR();
        visualVerifyTestScript.rxFillId = connexusAppUtils.fetchSecondRxFillId(storeNbr, visualVerifyTestScript.rxNbr);
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("MANUAL_RACK_VALUE"), connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData, connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData, inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateRackNumber(inputData.get("MANUAL_RACK_NUMBER"));
        visualVerifyTestScript.validateManualVVScreen();
        visualVerifyTestScript.moveMultiRxToEod(String.valueOf(storeNbr));

        Reporter.log("Validated Relabel flow | modify outcomes filled Rx, reroutes to VV , Manual VV with Label changed pop-up");
    }



    //@Jira(testID = "HWPHME2E-5280")
    @Test(enabled = true, description = "Hot keys / shortcuts validations for Rx eligible for auto VV",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5280_Hot_Keys_Shortcuts_Validations_For_MultiRx_Eligible_For_AutoVV(Map<String, String> inputData) throws JsonProcessingException {
        Reporter.log("Validate Hot keys / shortcuts validations for Rx eligible for auto VV");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("31760", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31780", "FALSE"); //This flag must be FALSE for LIQ/SOL dosages which come under restricted dosages
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "STG");
        int storeNbr = connexusAppUtils.getStoreId();
        connexusAPIManager.restartConnexusService(String.valueOf(storeNbr));
        visualVerifyTestScript.initializeTestCase(flagUpdated,false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        List<InputResponse> fillIdAndOrderId=visualVerifyTestScript.moveToFillingForMultiRx(inputData,patientId,2);
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(0).getRxNbr());
        visualVerifyTestScript.orderId=fillIdAndOrderId.get(0).getOrderId();
        visualVerifyTestScript.rxFillId=fillIdAndOrderId.get(0).getRxFillId();
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateShortCutsOrHotKeysInAutoVVScreen();
        //Complete 2nd RX
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(1).getRxNbr());
        visualVerifyTestScript.rxFillId=fillIdAndOrderId.get(1).getRxFillId();
        visualVerifyTestScript.orderId=fillIdAndOrderId.get(1).getOrderId();
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.validateAutoVVEnterKeyAfterClosingModifyDetails();
        visualVerifyTestScript.moveMultiRxToEod(String.valueOf(storeNbr));

        Reporter.log("Validated Multi Rx with Fridge Item and Mix, Outcomes filling with Enter Shortcut + Outcomes filling with F2 Shortcut");
    }

    //@Jira(testID = "HWPHME2E-5276")
    @Test(enabled = true, description = "Multi Rx with Fridge Item and Mix, Outcomes filling + Classic Filling",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOMVVRedesign/FOMVisualVerify.json", sheetName = "VisualVerify")
    public void HWPHME2E_5276_Daily_VV_Report_For_All_VV_Types_For_Multi_Rx(Map<String, String> inputData) throws JsonProcessingException {
        Reporter.log("HWPHME2E_5276_Daily_VV_Report_For_All_VV_Types_For_Multi_Rx");

        flagsCheckUp();
        int storeNbr = connexusAppUtils.getStoreId();
        visualVerifyTestScript.initializeTestCase(flagUpdated, false);
        int patientId= visualVerifyTestScript.createPatientAPI(inputData);
        List<InputResponse> fillIdAndOrderId=visualVerifyTestScript.moveToFillingForMultiRx(inputData,patientId,4);
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(0).getRxNbr());
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        //Complete 2nd rx filling using Outcome filling APIs and then perform manual override in VV screen
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(1).getRxNbr());
        visualVerifyTestScript.rxFillId=fillIdAndOrderId.get(1).getRxFillId();
        visualVerifyTestScript.orderId=fillIdAndOrderId.get(1).getOrderId();
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"));
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        //Complete 3rd rx outcome filling using VV Rack in update fulfillment
        visualVerifyTestScript.rxNbr=String.valueOf(fillIdAndOrderId.get(2).getRxNbr());
        visualVerifyTestScript.rxFillId=fillIdAndOrderId.get(2).getRxFillId();
        visualVerifyTestScript.orderId=fillIdAndOrderId.get(2).getOrderId();
        visualVerifyTestScript.findAndAssignWCFBag(connexusAppUtils.getStoreId());
        visualVerifyTestScript.performGetFillInfo(connexusAppUtils.getStoreId());
        visualVerifyTestScript.validateNumberOfLables();
        visualVerifyTestScript.performSendFulfillment(inputData.get("RACK_VALUE"),connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_INPROGRESS"));
        visualVerifyTestScript.performPrintRxLabel(inputData,connexusAppUtils.getStoreId());
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_LABEL_PRINTED"));
        visualVerifyTestScript.performUpdateFulfillment(inputData,inputData.get("FILL_WORK_STATUS_SUBMITTED"),"VV Rack");
        visualVerifyTestScript.fetchFillInfoDocumentsFromCosmosDB(inputData.get("FILL_STATUS_COMPLETED"));
        visualVerifyTestScript.validateRackNumber(inputData.get("RACK_NUMBER"));
        //Complete 2nd rx filling using classic filling
        visualVerifyTestScript.fillingTestscripts.classicFilling(Collections.singletonList(200),patientId);
        visualVerifyTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        visualVerifyTestScript.performMultiRxVisualVerify(Arrays.asList("AUTO_VV", "MANUAL_OVERRIDE", "MANUAL_VV","MANUAL_VV"));
        visualVerifyTestScript.moveMultiRxToEod(String.valueOf(storeNbr));
        visualVerifyTestScript.openDailyVisualVerifyReportAndShowReport();

    }
}
