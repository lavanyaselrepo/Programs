package connexus.coretest.paymentflows;

import com.aventstack.extentreports.Status;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.CommonUtil;
import com.walmart.hwqe.commons.serviceapi.digitalpharmacyapicontext.utils.DigitalPharmacyOperationsUtil;
import fom.NewOrderDrop;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientResponse;

import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.digitalPharmacyapicontext.DigitalPharmacyAPIManager;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;
import static hwqe.baseframework.utilities.FileUtils.readFileToString;

@lombok.Getter
@lombok.Setter
public class PaymentFlowsTestScripts {
    SoftAssert softAssert = new SoftAssert();
    ConnexusStartPage connexusStartPage;
    InputPage inputPage;
    PatientMaintenancePage patientMaintenancePage;
    PatientSearchPage patientSearchPage;
    AutomationManager automationManager;
    LoginPage loginPage;
    DropOffPage dropOff;
    F6Search rxSearch;
    ProductMaintenancePage productMaintenancePage;
    ServiceResponse resp = new ServiceResponse();
    WrapperUtils wrapperUtils = new WrapperUtils();
    ConnexusAppUtils connexusAppUtils;
    AddPatient addPatient = new AddPatient();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    DigitalPharmacyAPIManager digitalPharmacyAPIManager = new DigitalPharmacyAPIManager();
    InputResponse inputResp = new InputResponse();
    DropRxModel dropRxModel;
    TascoPage tascoPage;
    ResolutionPage resolutionPage;
    ModifyDetails modifyDetails;
    private String rxNbr;
    private String rxNbr1;
    private String rxNbr2;
    F6Search orderSearch;

    AutomationManager am = AutomationManager.getInstance();
    NewOrderDrop newOrderDrop = new NewOrderDrop();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    List<String> multiRxNbr = new ArrayList<>();
    List<InputResponse> multiRxVVCompleteResp = new ArrayList<>();
    List<Integer> rxFillIdList = new ArrayList<>();
    List<Integer> rxIdList = new ArrayList<>();
    JSONArray multiRxResponse = new JSONArray();
    List<Integer> orderSeqNbrList = new ArrayList<>();
    List<String> multiRxNbrList = new ArrayList<>();
    ServiceResponse vvCompleteResp;
    Map<String, Object> values = new HashMap<>();
    Map<String, Integer> value = new HashMap<>();
    CreatePatientResponse createPatientResponse = new CreatePatientResponse();
    int storeId;
    int storeNumber;
    int patientId, numRefills;
    int siteId, rxFillId, orderId, orderSeqNbr, rxId;
    List<String> ndcList;
    String patientFirstName;
    String patientLastName;
    String patientDob;
    int numOfRxsNeeded;
    String dotComEmail;
    String dotComPassword;
    List<String> dates;
    PropertyReader vaultKeys = PropertyReader.getInstance();

    public PaymentFlowsTestScripts(int storeId, String patientFirstName, String patientLastName, String patientDob, int numOfRxsNeeded, String dotComEmail,
                                   String dotComPassword) {
        setStoreId(storeId);
        setPatientFirstName(patientFirstName);
        setPatientLastName(patientLastName);
        setPatientDob(patientDob);
        setDotComEmail(dotComEmail);
        setDotComPassword(dotComPassword);
        setNumOfRxsNeeded(numOfRxsNeeded);
        // Commonly used dates are formatted for easy access.
        setDates(dateTimeFormatterUtil(getPatientDob()));
        // pass dob in MMDDYYYY format
    }

    public PaymentFlowsTestScripts() {
    }

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        dropOff = new DropOffPage();
        inputPage = new InputPage();
        patientMaintenancePage = new PatientMaintenancePage();
        patientSearchPage = new PatientSearchPage();
        connexusStartPage = new ConnexusStartPage();
        rxSearch = new F6Search();
        productMaintenancePage = new ProductMaintenancePage();
        connexusAppUtils = new ConnexusAppUtils();
        connexusAPIManager = new ConnexusAPIManager();
        dropRxModel = new DropRxModel();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    public void createPatient(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);
        contactModel.setPatientPrimaryNumber(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientAlternateNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
        patient.setPatientIdentityModel(patientIdentityModel);
        patient.setPatientContact(contactModel);
        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
    }


    public List<String> dateTimeFormatterUtil(String dob) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        LocalDate date = LocalDate.parse(dob, inputFormatter);

        // Output formats
        DateTimeFormatter unixTimestampFormatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss");
        DateTimeFormatter yyyyMMddFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter ddMMyyyyFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss.SSS 'UTC'");

        // Convert LocalDate to LocalDateTime at 00:00:00
        LocalDateTime dateTime = date.atStartOfDay();
        dateTime = dateTime.withHour(8).withMinute(0).withSecond(0).withNano(0);

        // Format output in different formats
        String unixTimestamp = dateTime.toEpochSecond(ZoneOffset.UTC) + "000"; // Unix timestamp at 00:00:00
        String formattedyyyyMMdd = dateTime.format(yyyyMMddFormatter);
        String formattedddMMyyyy = date.format(ddMMyyyyFormatter);
        String formattedCustom = dateTime.format(customFormatter);
        List<String> dateFormatted = new ArrayList<>();
        dateFormatted.add(unixTimestamp);
        dateFormatted.add(formattedyyyyMMdd);
        dateFormatted.add(formattedddMMyyyy);
        dateFormatted.add(formattedCustom);
        return dateFormatted;
        //returns unix, yyyy-mm-dd, ddmmyyyy, mon dd yyyyy hh:mm:ss.sss UTC
    }

    public List<String> getEligibleRxsForRefillWithSameStore(String cid, int storeNumber) {
        List<String> rxNumberList = new ArrayList<>();
        resp = digitalPharmacyAPIManager.getPrescriptionsList(cid);
        System.out.println(resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject temp = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        for (int j = 0; j < temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().size(); j++) {
            JsonArray rxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().get(j).getAsJsonObject().getAsJsonArray("prescriptionList");
            for (int i = 0; i < rxList.size(); i++) {
                JsonElement currRx = rxList.get(i);
                try {
                    if (currRx.getAsJsonObject().get("storeNumber").getAsJsonObject().get("storeId").getAsString().equals("" + storeNumber)
                            && "PICKED UP".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                        if (currRx.getAsJsonObject().get("storeNumber").getAsJsonObject().get("storeId").getAsString().equals("" + storeNumber)
                                && "PICKED UP".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                            rxNumberList.add(currRx.getAsJsonObject().get("rxNumber").getAsString());
                        }
                    }
                } catch (Exception e) {
                    System.out.println("A Param was missing in Pyxis Response, please check for currRx: " + currRx.toString());
                    e.printStackTrace();
                }
            }
        }
        System.out.println(rxNumberList);
        return rxNumberList;
    }

    public void dropAnRxTillBagging(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            automationManager.performSleep(10);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            Reporter.log("RX is in Resolve queue");
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            Reporter.log("RX is in CASH queue");
            automationManager.performSleep(5);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

        if ("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }

    }


    public void createPatientWithTP(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();
        ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
        // connexusAppUtils.addRandomNamesInFile();
        // String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
        patient.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
        patient.setPatientDob(inputData.get("PAT_DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("PAT_ADDRESS_LINE1"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);
        contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
        contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);

        patient.setPatientContact(contactModel);
        thirdPartyModel.setCarrierBin(inputData.get("PAT_CARRIER"));
        thirdPartyModel.setPlan(inputData.get("PAT_PLAN"));
        thirdPartyModel.setCardId(inputData.get("PAT_CARD_ID"));
        patient.setPatientTp(thirdPartyModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);

        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(true, patient);
    }

    public int getPatientId(Map<String, String> inputData) {
        // int patientId, strNbr,priorityId,requestTypeCode,dispenseType,numRefills,prescriberId;
        //long homePhone,workPhone,cellPhone;
        ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
        ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
        InputResponse inputResp = new InputResponse();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        ServiceResponse resp;
        String firstName = name[0];
        String lastName = name[1];
        int patientId, strNbr;
        long homePhone, workPhone, cellPhone;
        strNbr = Integer.parseInt(prop.getProperty("cnx.store"));
        homePhone = Long.parseLong(inputData.get("homePhone"));
        workPhone = Long.parseLong(inputData.get("workPhone"));
        cellPhone = Long.parseLong(inputData.get("cellPhone"));

        resp = connexusAPIManager.createPatient(firstName, lastName, inputData.get("inputDob"), strNbr, homePhone, workPhone, cellPhone);
        Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());

        inputResp = resp.getDataResponse(InputResponse.class);
        patientId = inputResp.getPatientId();
        Reporter.log("patientId = " + patientId);
        System.out.println("patientId = " + patientId);
        return patientId;
    }


    public void searchPatientWithName(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            automationManager.performSleep(5);
            String patientName = inputData.get("PATIENT_NAME");
            String patientDOB = inputData.get("PAT_DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            int counter = 0;
            while (patientMaintenancePage.isGeneralInformationTabDisplayed() && counter <= 3) {
                patientMaintenancePage.clickPatientMaintenanceIcon();
                counter++;
            }
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void changeTPtoCash(String RXnumber) {
        F6Search search = new F6Search();
        search.performSearch(RXnumber, SearchType.PatientRx);
        search.selectRowFromSearch(0);
        automationManager.performSleep(5);
        modifyDetails.switchWindow();
        automationManager.performSleep(5);
        modifyDetails.clickSwitchtoCash();
        modifyDetails.clickCash();
        modifyDetails.clickAccept();
        if (modifyDetails.isNewTPreasonPopupDisplayed()) {
            modifyDetails.enterTPreason("Other");
            automationManager.performSleep(5);
            modifyDetails.enterTPcomment("QE Test");
            automationManager.performSleep(5);
        } else {

            modifyDetails.selectReasonForSwitchToCash();
        }
        automationManager.performSleep(5);
        modifyDetails.clickAccept();
        modifyDetails.checkAndClickWarning();
    }

    public void updateStoreState(Map<String, String> inputData) {
        String state = inputData.get("STATE");
        connexusAppUtils.checkCurrentStateAndupdateStoreState(state);
    }

    public void dropAnRxTillBagginSwitchToCash(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        F6Search f6Search = new F6Search();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        changeTPtoCash(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        if ("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }

    }

    public void performCounsellingForDualRx(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        try {
            String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            } else {
                Reporter.log("RX is not in Counselling queue");
                Assert.fail();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Counselling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        try {
            String rxStatus1 = rxSearch.getRXStatusForPatient(rxNbr1, 0);
            if (rxStatus1.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr1);
            } else {
                Reporter.log("RX1 is not in Counselling queue");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Counselling queue");
        }
    }

    public void performPOSForDualRX(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        String rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }
        String rxStatus1 = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 1);
        if (rxStatus1.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr1);
        }
        automationManager.performSleep(10);
        try {
            if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
            } else {
                Reporter.log("RX is not in POS queue");
                Assert.fail("RX is not in POS queue");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at POS queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        try {
            if (rxStatus1.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr1);
            } else {
                Reporter.log("RX1 is not in POS queue");
                Assert.fail("RX1 is not in POS queue");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at POS queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void drop2RXTillPickupPostRefill(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        DropRxModel dropRxModel = new DropRxModel();
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        // connexusAppUtils.readPatientNameFromFile();
        //String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr);
        }
        String rxStatus2 = rxSearch.getRXStatusForPatient(rxNbr1, 0);
        if (rxStatus2.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr1);
        }

        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }

        if (rxStatus2.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr1);
        }
        if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().performCheckDurForMultiRx(rxNbr);
        }
        if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().performCheckDurForMultiRx(rxNbr1);
        }

        if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }
        if (rxStatus2.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr1);
        }
        //automationManager.performSleep(5);
        if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        }
        if (rxStatus2.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr1);
        }
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
            patientSearchPage.openSecondPatientRecord();
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("RX is pickup queue");
        }

        /*Reporter.log("RX is pickup queue");
        if(rxStatus2.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
            patientSearchPage.openFirstPatientRecord();

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }*/
    }

    public void verifyRxInResolveStatePostRefill(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        DropRxModel dropRxModel = new DropRxModel();
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        // connexusAppUtils.readPatientNameFromFile();
        //String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxNbr1 = rxSearch.getRxNbr(2);
        System.out.println(rxNbr2);
        rxSearch.closeSearch();
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        checkRxWorkQue(rxNbr, WorkQueue.RESOLVE);
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("RX is Reslove queue");
        }
    }

    public void dropMultiRxResolvedInUI(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        DropRxModel dropRxModel = new DropRxModel();
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        // connexusAppUtils.readPatientNameFromFile();
        //String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxNbr1 = rxSearch.getRxNbr(2);
        System.out.println(rxNbr2);
        rxSearch.closeSearch();
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr1, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        }
        automationManager.performSleep(5);
        String rxStatus2 = rxSearch.getRXStatusForPatient(rxNbr2, 0);
        if (rxStatus2.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr2);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
    }

    public void performMultiChkDURInUI(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.performSleep(10);
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String name = inputData.get("PATIENT_NAME");
        // connexusAppUtils.readPatientNameFromFile();
        //String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"), SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        /*int counter = 0;
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        checkRxWorkQue(rxNbr, WorkQueue.CHK_DUR);
        while (rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.CHK_DUR.getWorkQueue())) {
            counter++;
            rxSearch.openOrderSearch();
            if (counter > 10)
                break;
        }*/
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        if(rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr);
        }
        if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().performCheckDurForMultiRx(rxNbr);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());

        String rxStatus2 = rxSearch.getRXStatusForPatient(rxNbr1, 0);
        if (rxStatus2.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolutionForMultiRx(rxNbr1);
        }
        if (rxStatus2.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().performCheckDurForMultiRx(rxNbr1);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
    }

    public void dropMultiRxFillingInUI(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String name = inputData.get("PATIENT_NAME");
        // connexusAppUtils.readPatientNameFromFile();
        //String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"), SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxNbr1 = rxSearch.getRxNbr(2);
        System.out.println(rxNbr2);
        rxSearch.closeSearch();
        int counter = 0;
        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr1, 0);
        checkRxWorkQue(rxNbr, WorkQueue.FILLING);
        while (rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.FILLING.getWorkQueue())) {
            counter++;
            rxSearch.openOrderSearch();
            if (counter > 10) {
                break;
            }
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());

        String rxStatus2 = rxSearch.getRXStatusForPatient(rxNbr2, 0);
        if (rxStatus2.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr2);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
    }

    public void multiRxVisualVerifyAndMovetoPickup(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        connexusStartPage = new ConnexusStartPage();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxNbr1 = rxSearch.getRxNbr(2);
        System.out.println(rxNbr2);
        rxSearch.closeSearch();
        String rxStatus2 = rxSearch.getRXStatusForPatient(rxNbr2, 0);
        if (rxStatus2.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr2);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
    }


    public void multiRxFillingAndMoveToPickup(Map<String, String> inputData) {
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        String currentRxNbr;
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                value = connexusAppUtils.getRxIdAndRxFillIdAndOrderSeqNbr(siteId, currentRxNbr);
                orderId = connexusAppUtils.getRxOrderIdFromTable(siteId, currentRxNbr);
                rxId = value.get("rxId");
                rxIdList.add(rxId);
                rxFillId = value.get("rxFillId");
                rxFillIdList.add(rxFillId);
                orderSeqNbr = value.get("orderSeqNbr");
                orderSeqNbrList.add(orderSeqNbr);
            }
            multiRxVVCompleteResp = connexusAPIManager.multiRxFillingToPickup(patientId, orderId, siteId, rxFillIdList, rxIdList, numRefills, ndcList, orderSeqNbrList);
        } catch (Exception e) {
            Reporter.log("Test failed at Filling and move to Pickup queue");
            softAssert.fail(e.toString());
        }
    }

    public void performMultiRxPickUpInUI(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxStatus, currentRxNbr, firstName, lastName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId, patientId);
        firstName = (String) values.get("first_name");
        lastName = (String) values.get("last_name");
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = multiRxNbr.get(i);
                multiRxNbrList.add(currentRxNbr);
                rxStatus = orderSearch.getRXStatusForPatientSelfHelp(currentRxNbr, 0, inputData);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue()));
            }
            //automationManager.getConnexusWorkFlow().completeMultiRxPickupInUI(firstName.trim(), lastName.trim(), "11/10/1998", multiRxNbrList);
        } catch (Exception e) {
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void pickupWithSingleDrugVerification(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        TascoPage tascoPage = new TascoPage();
        PatientProfileModel patientProfileModel = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        RxModel rxModel = new RxModel();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxNbr1 = rxSearch.getRxNbr(2);
        System.out.println(rxNbr2);
        rxSearch.closeSearch();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr1, WorkQueue.FILLING);
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr2, WorkQueue.PICKUP);
        tascoPage.launchTascoScreen();
        automationManager.performSleep(5);
        tascoPage.inputPatientLastName(name[0]);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(name[1]);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(inputData.get("PAT_DOB"));
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr= " + rxNbr2 + ") and next_work_que_code ='6'";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String fillId = rxInfo.get("rx_fill_id").toString();
        Log.info(fillId);
        tascoPage.scanRx("4793" + fillId + "0");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed");
    }


    public boolean checkRxWorkQue(String rxNbr, WorkQueue queue) {
        boolean isInQueue = false;
        F6Search rxSearch = new F6Search();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        if (rxSearch.getWorkQueue(0).equalsIgnoreCase(queue.getWorkQueue())) {
            isInQueue = true;

        } else {
            rxSearch.pressKeys(KeyEvent.VK_F6);
        }
        rxSearch.closeSearch();
        if (isInQueue) {
            Reporter.log("Rx is in " + queue.getWorkQueue() + " queue");
        } else {
            Reporter.log("Rx is not in " + queue.getWorkQueue() + " queue");
        }
        return isInQueue;
    }

    public void pickupWith2DrugVerification(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        TascoPage tascoPage = new TascoPage();
        PatientProfileModel patientProfileModel = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        RxModel rxModel = new RxModel();
        String[] name = {inputData.get("PATIENT_LAST_NAME"), inputData.get("PATIENT_FIRST_NAME")};
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.PICKUP);
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr1, WorkQueue.PICKUP);
        tascoPage.launchTascoScreen();
        boolean result = tascoPage.isPatientFirstNameDisplayed();
        if (result) {
            tascoPage.inputPatientLastName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PAT_DOB"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
        } else {
            tascoPage.inputPatientRxnumber(rxNbr);
        }
        tascoPage.pressKeys(KeyEvent.VK_ENTER);
        tascoPage.clickSearch();
        tascoPage.clickRow(0);
        automationManager.performSleep(5);
        tascoPage.handleOtherOrdersAvailablePopUp();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickCheckout();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());

    }

    @Test
    public List<String> createMultiRxOrdertillEOD(Map<String, String> inputData) {
        List<String> ndcList = Arrays.asList("68382056510", "43292055551");
        Reporter.log("multi Order creation");
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId, patientId);
        patientId = inputResp.getPatientId();
        //int patientId = Integer.parseInt(inputData.get("PATIENTID"));
        int numRefills = Integer.parseInt(inputData.get("REFILLS"));
        Prescriber prescriber = new Prescriber();
        prescriber.setFullname("SMITH, AARON CHRISTOPHER DO");
        prescriber.setFirstname("AARON");
        prescriber.setLastname("SMITH");
        prescriber.setDea("BT2413146");
        prescriber.setPhone("3193561616");
        prescriber.setNpi("2999997788");
        prescriber.setPrescriberId(1065);
        prescriber.setState("TX");
        prescriber.setRxClinicId(8262);

        multiRxResponse = connexusAPIManager.createNewMultiDrugOrderToEOD(patientId, siteId, numRefills, ndcList, prescriber);
        Reporter.log("order has been created");
        List<String> rxnumbers = new ArrayList<>();
        for (int i = 0; i < multiRxResponse.length(); i++) {
            org.json.JSONObject object;
            object = multiRxResponse.getJSONObject(i);
            Gson gson = new Gson();
            JsonObject json = gson.fromJson(String.valueOf(object), JsonObject.class);
            JsonArray orders = json.get("order").getAsJsonArray();
            JsonObject orderlist = orders.get(0).getAsJsonObject();
            rxNbr = orderlist.get("rxNbr").getAsString();
            Log.info("RxNbr:" + rxNbr);
            Reporter.log("RxNbr:" + rxNbr);
            rxnumbers.add(rxNbr);
        }
        return rxnumbers;
    }

    public List<String> createRxOrderForThreeRxtillEOD(Map<String, String> inputData) {
        List<String> ndcList = Arrays.asList("43292055551 ", "68382056510", "11528010516");
        Reporter.log("multi Order creation");
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId, patientId);
        patientId = inputResp.getPatientId();
        //int patientId = Integer.parseInt(inputData.get("PATIENTID"));
        int numRefills = Integer.parseInt(inputData.get("REFILLS"));
        Prescriber prescriber = new Prescriber();
        prescriber.setFullname("SMITH, AARON CHRISTOPHER DO");
        prescriber.setFirstname("AARON");
        prescriber.setLastname("SMITH");
        prescriber.setDea("BT2413146");
        prescriber.setPhone("3193561616");
        prescriber.setNpi("2999997788");
        prescriber.setPrescriberId(1065);
        prescriber.setState("TX");
        prescriber.setRxClinicId(8262);

        multiRxResponse = connexusAPIManager.createNewMultiDrugOrderToEOD(patientId, siteId, numRefills, ndcList, prescriber);
        Reporter.log("order has been created");
        List<String> rxnumbers = new ArrayList<>();
        for (int i = 0; i < multiRxResponse.length(); i++) {
            org.json.JSONObject object;
            object = multiRxResponse.getJSONObject(i);
            Gson gson = new Gson();
            JsonObject json = gson.fromJson(String.valueOf(object), JsonObject.class);
            JsonArray orders = json.get("order").getAsJsonArray();
            JsonObject orderlist = orders.get(0).getAsJsonObject();
            rxNbr = orderlist.get("rxNbr").getAsString();
            Log.info("RxNbr:" + rxNbr);
            Reporter.log("RxNbr:" + rxNbr);
            rxnumbers.add(rxNbr);
        }
        return  rxnumbers;
    }

    public void testAccountCreation() throws InterruptedException {
        // Connexus Actions Create Patient and Drop New RX
        List<String> ndcList = Arrays.asList("08290201044", "11161097863");
        int storeId = Integer.parseInt(prop.getProperty("cnx.store"));
        String emailToUse = CommonUtil.generateRandomEmailId(10);
        String firstName = CommonUtil.generateRandomFirstName(3);
        String lastName = CommonUtil.generateRandomLastName(3);

        generatePatient(storeId, firstName, lastName, "/Date(1286678400000)/", false, "M", false);
        automationManager.performSleep(10);
        int patientId = digitalPharmacyAPIManager.getStorePatientIdFromCPR(firstName, lastName, "12-12-1994", String.valueOf(storeId));
        IDatabaseContext cnx = am.getConnexusDB(storeId);
        DataRow drugInfo = null;

        resp = digitalPharmacyAPIManager.createDotComAccount(emailToUse, "Walmart@1", "9996301876", firstName, lastName);
        Log.info(resp.getDataResponse());
        automationManager.performSleep(10);
        // Create Pharmacy Connected Account ISAC Flow
        String cid = digitalPharmacyAPIManager.getCidFromEmail(emailToUse);
        System.out.println("cid: " + cid);
        String[] cids = new String[1];
        cids[0] = cid;
        digitalPharmacyAPIManager.clearAccountsCache(cids);
        String secAuthToken = digitalPharmacyAPIManager.generateSecondaryAuth(emailToUse, getDotComPassword());
        // format for CPR dob : "1981-01-01"
        System.out.println("secAuthToken: " + secAuthToken);
        String stgId = digitalPharmacyAPIManager.createIsacNewOnlineAccount(emailToUse, getPatientDob(), firstName, lastName, "5511", patientId, secAuthToken);
        // format for pyxis API : "01011981"
        am.performSleep(25);
        digitalPharmacyAPIManager.createPharmacyAccount(cid, secAuthToken, stgId, "12121994");
        System.out.println(stgId);
        System.out.println("Created Account: " + emailToUse + ", Password: " + getDotComPassword() + ", PatientFirstName: " + firstName +
                ", PatientLastName: " + lastName);
    }

    public void dotcomAccountCreation() throws IOException {
        // Scenario : Create Account -> Move Order till EOD -> Place Refill.
        Reporter.log("dotcom account creation");
        String phoneNumber = CommonUtil.generateRandomNumber(10);
        String caregiverEmail = CommonUtil.generateRandomEmailId(10);
        String caregiverFirstName = CommonUtil.generateRandomFirstName(5);
        String caregiverLastName = CommonUtil.generateRandomLastName(5);
        DigitalPharmacyOperationsUtil newObj = new DigitalPharmacyOperationsUtil(5511, caregiverFirstName, caregiverLastName, "10101998", 0, caregiverEmail, "Test@1234");
        newObj.createDigitalPharmacyConnectedStorePatientAccount(false,false);

        //digitalPharmacyAPIManager.placeOrderForRefill(getStoreId(), getPatientFirstName(), getPatientLastName(), getPatientDob(), getDotComEmail(), getDotComPassword());
        Reporter.log("Account has been created");
    }

    public void generatePatient(int storeId, String firstName, String lastName, String dob, boolean isPet, String Gender, boolean isMinor) {
        // generic helper
        AddPatient addPatient = new AddPatient();
        addPatient.setSiteID(5511);
        addPatient.setCommunicationID("7607567568");
        addPatient.setFirstName(firstName);
        addPatient.setLastName(lastName);
        addPatient.setMiddleName("Hayden");
        addPatient.setPatientName("Meow,Hayden Meow");
        addPatient.setDob("/Date(1286668800000)/");
        addPatient.setGender("M");
        addPatient.setLanguage("101");
        addPatient.setStatus(20700);
        addPatient.setIsPatientMinor(false);
        addPatient.setAddressTypeCode(3);
        addPatient.setVerifyFreCode(1);
        addPatient.setPatientTypeCode(10202);
        addPatient.setUserId("VN56K3D");
        addPatient.setAddressLine1("3101 SW TROON LN");
        addPatient.setAddressLine2("APT 26");
        addPatient.setCellPhone("7607567572");
        addPatient.setCity("BENTONVILLE");
        addPatient.setCountry("US");
        addPatient.setHomePhone("7607567568");
        addPatient.setState("AR");
        addPatient.setWorkPhone("7607567570");
        addPatient.setZipCode("72713");
        addPatient.setHipaaStatusCode(9510);
        connexusAPIManager.addPatientWithGenericAllParam(addPatient);
    }

    public void createDotcomAccountandRefillOrderforMultiRx() throws InterruptedException {
        this.testAccountCreation();
        Reporter.log("Account has been created");
    }

    @Test
    public void placeOrderForRefill(Map<String, String> inputData) {
        Reporter.log("Placing refill order");
        try {
            int storeNumber = Integer.parseInt(prop.getProperty("cnx.store"));
            String emailToUse = inputData.get("EMAILTOUSE");
            String password = inputData.get("PASSWORD");
            String patientDob = inputData.get("PAT_DOB");
            String patientFn = inputData.get("PATIENT_LAST_NAME");
            String patientLn = inputData.get("PATIENT_FIRST_NAME");
            List<String> rxNumbers = Arrays.asList("6663002", "8810023", "6663004");
            //String cid = digitalPharmacyAPIManager.getCidFromEmail(emailToUse);
            //List<String> rxNumbers = digitalPharmacyAPIManager.getEligibleRxsForRefillWithSameStore(cid, storeNumber);
            refillBatchRxs(emailToUse, password, patientDob, patientFn, patientLn, rxNumbers, storeNumber);
            System.out.println("Refill order done");
            Reporter.log("Refill order Placed ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void refillBatchRxs(String emailToUse, String dotcompass, String patientDob, String patientFirstName, String patientLastName, List<String> rxNumbers, int storeNb) {
        String cid = digitalPharmacyAPIManager.getCidFromEmail(emailToUse);
        String auth_gen = digitalPharmacyAPIManager.generateSecondaryAuth(emailToUse, dotcompass);
        digitalPharmacyAPIManager.validateSecondaryAuth(cid, auth_gen, patientDob);
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("WM_SEC.AUTH_TOKEN", auth_gen);
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");

        try {
            String file = readFileToString(prop.getProperty("pyxis.v3.refill.order.filepath"));
            DocumentContext jsonToParse = JsonPath.parse(file);
            jsonToParse.set("$.payload.pickupDateTime.pickupDate", new SimpleDateFormat("MMddyyyy").format(new Date()));
            jsonToParse.set("$.payload.customerAccountId", cid);
            jsonToParse.set("$.payload.pickupDateTime.pickupStoreNumber.USStoreId", storeNb);
            JSONArray rxArray = new JSONArray();
            for (String i : rxNumbers) {
                JSONObject rxBody = new JSONObject();
                rxBody.put("rxNumber", i);
                JSONObject storeBody = new JSONObject();
                storeBody.put("USStoreId", storeNb);
                rxBody.put("storeNumber", storeBody);
                rxArray.put(rxBody);
            }
            System.out.println(rxArray);
            List<Object> jsonObjects = rxArray.toList();
            jsonToParse.put("$.payload", "prescriptionList", jsonObjects);
            jsonToParse.set("$.payload.contactInformation.name.firstName", patientFirstName);
            jsonToParse.set("$.payload.contactInformation.name.lastName", patientLastName);

            req.setHeaders(headers);
            req.setUrl(prop.getProperty("pyxis.base.url") + "v3/pharmacy/refills");
            req.setRequestPayload(jsonToParse.jsonString());
            System.out.println("Req Payload: " + req.getRequestPayload());
            resp = am.getRestContext().performPut(req);
            System.out.println("Response For Refill: " + resp.getDataResponse());
            Reporter.log("Response For Refill: " + resp.getDataResponse());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void startAppiumServer() {
        Runtime runtime = Runtime.getRuntime();
        try {
            runtime.exec("cmd.exe /c start cmd.exe /k \"appium");
            Thread.sleep(10000);
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }

    public void killtheAppiumAndConnexusAndStartAppium() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Runtime.getRuntime().exec("TASKKILL /F /IM node.exe");
            Runtime.getRuntime().exec("TASKKILL /F /IM cmd.exe");
            Thread.sleep(10000);
            Runtime.getRuntime().exec("TASKKILL /F /IM connexus.exe");
            Thread.sleep(10000);
            runtime.exec("cmd.exe /c start cmd.exe /k \"appium");
            Thread.sleep(10000);
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }
}











