package connexus.coretest.paymentflows;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;
import java.util.Map;

public class PaymentFlowsTestSet1 {
    PaymentFlowsTestScripts paymentFlowsTestScripts = new PaymentFlowsTestScripts();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
        paymentFlowsTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "Verify the payment amount for a Refill order with Multiple Rx |Both in Pickup queue",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PaymentFlows/DoubleRxPaymentFlows.json", sheetName = "DoubleRxPaymentFlows")
    public void HWPHME2E_482(Map<String, String> inputData) throws InterruptedException, IOException, AWTException {
        System.out.println(">>>HWPHME2E_482<<<");

        connexusAppUtils.getStoreId();

        paymentFlowsTestScripts.dotcomAccountCreation();
        paymentFlowsTestScripts.createMultiRxOrdertillEOD(inputData);
        paymentFlowsTestScripts.placeOrderForRefill(inputData);
        paymentFlowsTestScripts.killtheAppiumAndConnexusAndStartAppium();
        paymentFlowsTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        paymentFlowsTestScripts.performMultiChkDURInUI(inputData);
        paymentFlowsTestScripts.dropMultiRxFillingInUI(inputData);
        paymentFlowsTestScripts.multiRxVisualVerifyAndMovetoPickup(inputData);

        System.out.println("<<<HWPHME2E_482>>>");
    }

    @Test(enabled = true, description = "Verify the payment amount for a Refill order with Multiple Rx |Both in Pickup queue,checkout only one",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PaymentFlows/DoubleRxPaymentFlows.json", sheetName = "DoubleRxPaymentFlows")
    public void HWPHME2E_480(Map<String, String> inputData) throws AWTException, IOException {
        System.out.println(">>>HWPHME2E_480<<<");

        connexusAppUtils.getStoreId();

        paymentFlowsTestScripts.dotcomAccountCreation();
        paymentFlowsTestScripts.createMultiRxOrdertillEOD(inputData);
        paymentFlowsTestScripts.placeOrderForRefill(inputData);
        paymentFlowsTestScripts.killtheAppiumAndConnexusAndStartAppium();
        paymentFlowsTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        paymentFlowsTestScripts.performMultiChkDURInUI(inputData);
        paymentFlowsTestScripts.dropMultiRxFillingInUI(inputData);
        paymentFlowsTestScripts.multiRxVisualVerifyAndMovetoPickup(inputData);
        paymentFlowsTestScripts.drop2RXTillPickupPostRefill(inputData);
        paymentFlowsTestScripts.pickupWith2DrugVerification(inputData);

        System.out.println("<<<HWPHME2E_480>>>");
    }

    @Test(enabled = true, description = "Verify the payment amount for a Refill order with Multiple Rx |One in Reslove|One is Filling|One is Pickup,checkout only one",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PaymentFlows/DoubleRxPaymentFlows.json", sheetName = "DoubleRxPaymentFlows")
    public void HWPHME2E_481(Map<String, String> inputData) throws AWTException, IOException {
        System.out.println(">>>HWPHME2E_481<<<");
        connexusAppUtils.getStoreId();

        paymentFlowsTestScripts.dotcomAccountCreation();
        //need to change the drug names for 3 rx
        paymentFlowsTestScripts.createRxOrderForThreeRxtillEOD(inputData);
        paymentFlowsTestScripts.placeOrderForRefill(inputData);
        paymentFlowsTestScripts.killtheAppiumAndConnexusAndStartAppium();
        paymentFlowsTestScripts.verifyRxInResolveStatePostRefill(inputData);
        paymentFlowsTestScripts.dropMultiRxResolvedInUI(inputData);
        paymentFlowsTestScripts.performMultiChkDURInUI(inputData);
        paymentFlowsTestScripts.dropMultiRxFillingInUI(inputData);
        paymentFlowsTestScripts.multiRxVisualVerifyAndMovetoPickup( inputData);
        paymentFlowsTestScripts.pickupWithSingleDrugVerification(inputData);

        System.out.println("<<<HWPHME2E_481>>>");
    }


}


