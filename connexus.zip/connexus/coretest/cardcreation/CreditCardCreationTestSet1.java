package connexus.coretest.cardcreation;


import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class CreditCardCreationTestSet1 {

    ConnexusAppUtils connexusAppUtils;
    CreditCardFlowsFunctions creditCardFlowsFunctions = new CreditCardFlowsFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    boolean flagUpdated = false;

    @BeforeClass
    public void performLogin() {
        System.out.println("Welcome: Before class");
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    @Test(enabled = true, description = "PMS - Add new credit card in Walmart stores on top of existing ones",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1614_tc_01_PMS_Add_new_credit_card_in_Walmart_stores(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E-1614 PMS - Add new credit card in Walmart stores>>>");

        connexusAppUtils.getStoreId();

        //Pre-Conditions
        //PMS flag 27151 and 29903 should be "TRUE"
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27151", "TRUE") || connexusAppUtils.readAndUpdateFlag("29903", "TRUE");
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);
        // Add visa card to existing patient profile with other card
        creditCardFlowsFunctions.addVisaCardInPatientProfileWithExistingPatient(inputData);

        //verify last4 digit of card displayed in screen
        creditCardFlowsFunctions.validateLastFourDigitOfCard();

        System.out.println("<<<HWPHME2E-1614 PMS - Add new credit card in Walmart stores>>>");

    }

    @Test(enabled = true, description = " HWPHME2E-1595 PMS - Verify P2PE token is shown in Easy Pay card information grid instead of XRef",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1595_tc_02_PMS_Verify_P2PE_token_is_shown_in_Easy_Pay_card_information_grid(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E-1595 PMS - Verify P2PE token is shown in Easy Pay card information grid instead of XRef>>>");

        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //PMS flag 27151 should be "False"
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27151", "FALSE");
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);
        //add master card in patient profile with new patient
        creditCardFlowsFunctions.addMasterCreditCardInPatientProfile(inputData);

        //scrolling right to cardinfo screen and verify p2p2e token it should display
        creditCardFlowsFunctions.verifyP2PETokenIsDisplayed(inputData);

        System.out.println("<<<HWPHME2E-1595 PMS - Verify P2PE token is shown in Easy Pay card information grid instead of XRef>>>");

    }

    @Test(enabled = true, description = " HWPHME2E-1597 PMS - Do not allow the user to activate 2nd card",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1597_tc_03_Do_not_allow_the_user_to_activate_2nd_card(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E-1597 PMS - Do not allow the user to activate 2nd card>>>");

        connexusAppUtils.getStoreId();
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);

        //add Master card to patient  profile
        creditCardFlowsFunctions.addMasterCreditCardInPatientProfile(inputData);

        creditCardFlowsFunctions.addVisaCardToPatientProfile(inputData);


        //try to set the active status for 2nd card and verify Active popup message
        creditCardFlowsFunctions.SettingActiveStatusAndVerifyPopupForCard(inputData);

        System.out.println("<<<HWPHME2E-1597 PMS - Do not allow the user to activate 2nd card>>>");
    }

    @Test(enabled = true, description = " HWPHME2E-1612 PMS - Add different credit card in Walmart stores. Try adding different credit card types like Amex, Discover, Visa, MasterCard etc",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1612_tc_04_Add_different_credit_card_in_Walmart_stores(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E-1612 PMS - Add different credit card in Walmart stores>>>");

        connexusAppUtils.getStoreId();
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);

        //add new discover card to patient profile
        creditCardFlowsFunctions.addDiscoverCardToPatientProfile(inputData);

        System.out.println("<<<PMS - Add different credit card in Walmart stores>>>");
    }

    @Test(enabled = true, description = " HWPHME2E-1596 PMS - Do not allow user to activate cards with invalid P2PE token",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1596_tc_05_Do_not_allow_user_to_activate_cards_with_invalid_P2PE_token(Map<String, String> inputData){
        System.out.println("<<<HWPHME2E-1596 PMS - Do not allow user to activate cards with invalid P2PE token>>>");

        connexusAppUtils.getStoreId();
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);
        //add new amex card to patientt profile
        creditCardFlowsFunctions.addAmexCardstartwith37ToPatientProfile(inputData);

        // Verify the invalid token popup is displayed or not
        creditCardFlowsFunctions.SettingEmptyTokenAndVerifyPopupForCard();
        System.out.println("<<<PMS - Do not allow user to activate cards with invalid P2PE token>>>");
    }

    @Test(enabled = true, description = " HWPHME2E-1613 PMS -Add credit card in Sam's, stores. Try adding different credit card types like Amex, Discover, Visa, MasterCard etc.",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1613_tc_06_Add_different_credit_card_in_Sams_stores(Map<String, String> inputData){
        System.out.println("<<<HWPHME2E_1613 Add credit card in Sam's, stores. Try adding different credit card types like Amex, Discover, Visa, MasterCard etc.>>>");

        connexusAppUtils.getStoreId();

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27151", "FALSE") || connexusAppUtils.readAndUpdateFlag("29903", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5323","Sam's Pharmacy");
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);
        //add new amex card to patinet profile
        creditCardFlowsFunctions.addAmexCreditCardstartwith37ToPatientProfile(inputData);

        System.out.println("<<<HWPHME2E_1613_PMS -Add credit card in Sam's, stores. Try adding different credit card types like Amex, Discover, Visa, MasterCard etc.>>>");
    }

    @Test(enabled = true, description = " HWPHME2E-1599 PMS - Edit credit card in Sam's, stores.",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CardCreation/CardCreationDataBook.json", sheetName = "CardFlows")
    public void HWPHME2E_1599_tc_07_Edit_credit_card_in_Sams_stores(Map<String, String> inputData){
        System.out.println("<<<HWPHME2E_1599 PMS  - Edit credit card in Sam's, stores.>>>");

        connexusAppUtils.getStoreId();

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27151", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("29903", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5323", "Sam's Pharmacy");
        creditCardFlowsFunctions.initializeTestCase(flagUpdated);
        //add new discover card to patient profile
        creditCardFlowsFunctions.addDiscoverCreditCardToPatientProfile(inputData);
        //edit credit card
        creditCardFlowsFunctions.editCreditCardForPatient();

        System.out.println("<<<HWPHME2E_1599 PMS - Edit credit card in Sam's, stores.>>>");
    }
}




