package connexus.coretest.cardcreation;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.connexus.PatientMedicalConditionModel;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.LoginPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class CreditCardFlowsFunctions extends ConnexusTestScripts {

    InputResponse inputResp = new InputResponse();
    ServiceResponse resp = new ServiceResponse();
    public CreditCardFlowsFunctions(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    public void addMasterCreditCardInPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patientMaintenancePage.clickTabProfile();
            String cardRefNbr = inputData.get("cardRefNbr");
            String cardHolderName =inputData.get("cardHolderName");
            String expirYearNbr = inputData.get("expirYearNbr");
            String expirMoNbr = inputData.get("expirMoNbr");
            String p2peToken = inputData.get("p2peToken");
            String startDate = inputData.get("startDate");
            String phmPymtMethod = inputData.get("phmPymtMethod");
            String cardType = "Master";
            resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr, expirYearNbr, p2peToken, startDate, phmPymtMethod);
            Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void addVisaCardToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            Boolean cardAdded = checkCardAlreadyAdded();
            if (cardAdded.equals(true)) {
                Reporter.log("Card is already added");
            } else {
                patientSearchPage.launchPatientSearchScreen();
                patientSearchPage.inputPatientName(patientName);
                patientSearchPage.clickSearchNow();
                patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
                patientMaintenancePage.clickTabProfile();
                String cardRefNbr = inputData.get("cardRefNbr1");
                String cardHolderName =inputData.get("cardHolderName1");
                String expirYearNbr = inputData.get("expirYearNbr");
                String expirMoNbr = inputData.get("expirMoNbr");
                String p2peToken = inputData.get("p2peToken1");
                String startDate = inputData.get("startDate");
                String phmPymtMethod = inputData.get("phmPymtMethod1");
                String cardType = "Visa";
                resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr,expirYearNbr, p2peToken, startDate, phmPymtMethod);
                Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
                automationManager.performSleep(10);
                patientSearchPage.clickEasyPayAccount();
                System.out.println("resp : " + resp);
                Reporter.log("New Card Added");
                Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
                Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
                Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
                Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateLastFourDigitOfCard() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            if(patientMaintenancePage.isEasyPayCardDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured= true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void getNullP2PeToken(String patient_id) {
        AutomationManager automationManager = AutomationManager.getInstance();
        String query = "select phm_pymt_acct_id from patient_payment where patient_id =" + patient_id;
        Map<String, Object> phm_pymt_acct_id = automationManager.getConnexusDB().executeQuery(query);
        Object account_ID = phm_pymt_acct_id.get("phm_pymt_acct_id");
        String value = " ";
        String query2 = "update phm_pymt_acct set p2pe_token= " + "\"  \" " + " where phm_pymt_acct_id= " + account_ID;
        automationManager.getConnexusDB().executeUpdateQuery(query2);
    }

    public void SettingActiveStatusAndVerifyPopupForCard(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.clickEasyPayAccount();
            if (patientMaintenancePage.cardIsDispalyed()) {
                patientMaintenancePage.isCardHolderNameDisplayed(1);
                patientMaintenancePage.cilckOnEditEasyPayBtn();
                patientMaintenancePage.SetStatusToActive();
                softAssert.assertTrue(patientMaintenancePage.getInactiveCardPopupText().contains("There is atleast one card active."));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
            patientMaintenancePage.clickOk();
            patientMaintenancePage.clickCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void SettingEmptyTokenAndVerifyPopupForCard() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (patientMaintenancePage.cardIsDispalyed()) {
                patientMaintenancePage.isCardHolderNameDisplayed(0);
                patientMaintenancePage.isScrollBarDisplayed();
                patientMaintenancePage.scrollRight();
                String p2petoken= patientSearchPage.getP2PETokenFromSearchGrid(0);
                Reporter.log("P2pe Token :" + p2petoken);
                patientMaintenancePage.cilckOnEditEasyPayBtn();
                patientMaintenancePage.setStatusToInactive();
                patientMaintenancePage.clickOnCloseBtn();
                String patient_id = String.valueOf(inputResp.getPatientId());
                getNullP2PeToken(patient_id);
                patientSearchPage.clickEasyPayAccount();
                patientMaintenancePage.isScrollBarDisplayed();
                patientMaintenancePage.scrollRight();
                String p2petoken1= patientSearchPage.getP2PETokenFromSearchGrid(0);
                Reporter.log("P2pe Token :" + p2petoken1);
                Reporter.log("P2pe Token gets updated to null");
                patientMaintenancePage.cilckOnEditEasyPayBtn();
                patientMaintenancePage.SetStatusToActive();
                softAssert.assertTrue(patientMaintenancePage.getInactiveCardPopupText().contains("Invalid P2PE token,"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
            patientMaintenancePage.clickOk();
            patientMaintenancePage.clickCancel();
            patientMaintenancePage.clickExit();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void addVisaCardInPatientProfileWithExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            String patientName=inputData.get("patientName");
            int siteId;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            String strNbr = String.valueOf(siteId);
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            automationManager.performSleep(6);
            patientMaintenancePage.clickTabProfile();
            String cardRefNbr = inputData.get("cardRefNbr");
            String cardHolderName =inputData.get("cardHolderName");
            String expirYearNbr = inputData.get("expirYearNbr");
            String expirMoNbr = inputData.get("expirMoNbr");
            String p2peToken = inputData.get("p2peToken");
            String startDate = inputData.get("startDate");
            String phmPymtMethod = inputData.get("phmPymtMethod");
            String patientId= inputData.get("patientId");
            String cardType = "Visa";
            resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr, expirYearNbr, p2peToken, startDate, phmPymtMethod);
            Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
            patientSearchPage.clickEasyPayAccount();
            System.out.println("resp : " + resp);
            Reporter.log("New Card Added");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void addDiscoverCreditCardToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patientMaintenancePage.clickTabProfile();
            String cardRefNbr = inputData.get("cardRefNbr");
            String cardHolderName =inputData.get("cardHolderName");
            String expirYearNbr = inputData.get("expirYearNbr");
            String expirMoNbr = inputData.get("expirMoNbr");
            String p2peToken = inputData.get("p2peToken");
            String startDate = inputData.get("startDate");
            String phmPymtMethod = inputData.get("phmPymtMethod");
            String cardType = "Discover";
            resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr, expirYearNbr, p2peToken, startDate, phmPymtMethod);
            Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
            automationManager.performSleep(10);
            patientSearchPage.clickEasyPayAccount();
            Reporter.log("New Card Added");
            Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
            Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
            Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
            Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void addDiscoverCardToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(3);
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            Boolean cardAdded = checkCardAlreadyAdded();
            if (cardAdded.equals(true)) {
                Reporter.log("Card is already added");
            } else {
                patientSearchPage.launchPatientSearchScreen();
                patientSearchPage.inputPatientName(patientName);
                patientSearchPage.clickSearchNow();
                patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
                patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
                patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
                patientMaintenancePage.clickTabProfile();
                String cardRefNbr = inputData.get("cardRefNbr");
                String cardHolderName =inputData.get("cardHolderName");
                String expirYearNbr = inputData.get("expirYearNbr");
                String expirMoNbr = inputData.get("expirMoNbr");
                String p2peToken = inputData.get("p2peToken");
                String startDate = inputData.get("startDate");
                String phmPymtMethod = inputData.get("phmPymtMethod");
                String cardType = "Discover";
                resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName,expirMoNbr,expirYearNbr, p2peToken, startDate, phmPymtMethod);
                Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
                patientSearchPage.clickEasyPayAccount();
                Reporter.log("New Card Added");
                Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
                Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
                Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
                Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickYes();
                patientMaintenancePage.clickExit();
                patientSearchPage.clickExitbutton();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public boolean checkCardAlreadyAdded() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientSearchPage.launchPatientSearchScreen();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String patientName = name[0] + "," + name[1];
        patientSearchPage.inputPatientName(patientName);
        patientSearchPage.clickSearchNow();
        patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
        patientMaintenancePage.isAllergiesNoEnabledRadioButton();
        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMaintenancePage.clickTabProfile();
        patientSearchPage.clickEasyPayAccount();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        patientSearchPage.clickExitbutton();
        patientMaintenancePage.clickSaveAndClose();
        return "Visa".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "Discover".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "Amex".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "MasterCard".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0));
    }

    public void addAmexCardstartwith37ToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            Boolean cardAdded = checkCardAlreadyAdded();
            if (cardAdded.equals(true)) {
                Reporter.log("Card is already added");
            } else {
                patientSearchPage.launchPatientSearchScreen();
                patientSearchPage.inputPatientName(patientName);
                patientSearchPage.clickSearchNow();
                patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
                patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
                patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
                patientMaintenancePage.clickTabProfile();
                String cardRefNbr = inputData.get("cardRefNbr");
                String cardHolderName = inputData.get("cardHolderName");
                String expirYearNbr = inputData.get("expirYearNbr");
                String expirMoNbr = inputData.get("expirMoNbr");
                String p2peToken = inputData.get("p2peToken");
                String startDate = inputData.get("startDate");
                String phmPymtMethod = inputData.get("phmPymtMethod");
                String cardType = "Amex";
                resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr, expirYearNbr, p2peToken, startDate, phmPymtMethod);
                Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
                patientSearchPage.clickEasyPayAccount();
                Reporter.log("New Card Added");
                Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
                Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
                Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
                Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void addAmexCreditCardstartwith37ToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            AutomationManager automationManager = AutomationManager.getInstance();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patientMaintenancePage.clickTabProfile();
            String cardRefNbr= inputData.get("cardRefNbr");
            String cardHolderName =inputData.get("cardHolderName");
            String expirYearNbr = inputData.get("expirYearNbr");
            String expirMoNbr = inputData.get("expirMoNbr");
            String p2peToken = inputData.get("p2peToken");
            String startDate = inputData.get("startDate");
            String phmPymtMethod = inputData.get("phmPymtMethod");
            String cardType = "Amex";
            resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr, expirYearNbr, p2peToken, startDate, phmPymtMethod);
            Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
            automationManager.performSleep(10);
            patientSearchPage.clickEasyPayAccount();
            Reporter.log("New  AmexCard Added");
            Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
            Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
            Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
            Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickCancel();
            patientMaintenancePage.clickExit();
        } catch (Throwable e) {
           isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyP2PETokenIsDisplayed(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.clickEasyPayAccount();
            patientMaintenancePage.isScrollBarDisplayed();
            patientMaintenancePage.scrollRight();
            String p2peToken = inputData.get("p2peToken");
            Assert.assertTrue(patientSearchPage.getP2PETokenFromSearchGrid(0).equalsIgnoreCase(p2peToken));
            if (patientMaintenancePage.isP2PETokenDisplayed(0)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickCancel();
                patientMaintenancePage.clickExit();
            }
            else {
                Reporter.log("P2PEToken no not displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void editCreditCardForPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.clickEasyPayAccount();
            if (patientMaintenancePage.cardIsDispalyed()) {
                patientMaintenancePage.isCardHolderNameDisplayed(0);
                patientMaintenancePage.cilckOnEditEasyPayBtn();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("clicked on EditBtn In EasyPayInfo");
                patientMaintenancePage.setStatusToInactive();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Status is set to Inactive");
            }
            patientMaintenancePage.clickOk();
            patientMaintenancePage.clickCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
}

