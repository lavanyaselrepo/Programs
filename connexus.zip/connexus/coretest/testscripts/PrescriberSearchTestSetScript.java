package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PrescriberSearchTestSetScript extends ConnexusTestScripts {
    public PrescriberSearchTestSetScript(LoginAs.userType loginUserType){
        super(loginUserType);
    }



    /**
     * Method to open Prescriber Search window by pressing the Keyboard shortcut CTRL+SHIFT+B
     * Author: Srinivas(vn50jui)
     * */

    public void openPrescriberSearchWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PrescriberSearchPage prescriberSearchPage = new PrescriberSearchPage();
            prescriberSearchPage.launchPrescriberSearchScreen();
            if (!prescriberSearchPage.isPrescriberSearchWindowDisplayed()) {
                prescriberSearchPage.launchPrescriberSearchScreen();
            }
            Assert.assertTrue(prescriberSearchPage.isPrescriberSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }

    /**
     * Method to close the Prescriber Search window by clicking on close button
     * Author: Srinivas(vn50jui)
     * */
    public void closePrescriberSearchWindowByClickingOnCloseButton() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            prescriberSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    /**
     * Method to enter invalid phone number in Phone field in Prescriber Search window and verify whether 'Invalid Phone Number Format' popup is displayed
     * Author: Srinivas(vn50jui)
     * */
    public void invalidPhoneNumberVerification(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isInvalidPhoneNumberFormatPopDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickOKOnInvalidPhoneNumberPopup();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify if the Prescriber Search Window is closed when the user pressed ESC button
     * Author: Srinivas(vn50jui)
     * */
    public void closePrescriberSearchWindowsByPressingEscapeButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for an Order or Patient on Order Search Window and open the order from search results
     * Author: Srinivas(vn50jui)
     */
    public void openRXinInputScreen(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.searchForPrescriber(inputData.get("PRESCRIBER_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether user able to select Prescriber who doesn't have DEA for normal drugs
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPrescriberWithoutDEAForNonControlledDrugs(Map<String, String> inputData) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNDCInProductName(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriberNameInPrescriber(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSelectButtonOnPrescriberSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            if(inputPage.isTMCodeDisplayed()){
                inputPage.selectTmCodeField(2);
            }
            if(inputPage.isDxCodeDisplayed()){
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.clickAccept();
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for the Patient on Order Search Window and verify that Prescriber details are matched
     * Author: Srinivas(vn50jui)
     * */
    public void searchForOrderAndVerifyPrescriberDetails(Map<String, String> inputData) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            Assert.assertTrue(orderSearch.getPrescriberName(0).equalsIgnoreCase(inputData.get("PRESCRIBER_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.closeSearch();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());

        }
    }

    /**
     * Method to verify whether user able to select Prescriber who doesn't have DEA for normal drugs
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPrescriberWithoutDEAForControlledDrugs(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + ","+name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNDCInProductName(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriberNameInPrescriber(inputData.get("PRESCRIBER_NAME"));
            inputPage.clickProductSearch3Dots();
            prescriberSearchPage.clickSelectButtonOnPrescriberSearch();
            softAssert.assertTrue(prescriberSearchPage.isDEAExpiredPopUpDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickOKButtonOnDEAExpiredPopUp();
            prescriberSearchPage.clickClose();
            prescriberSearchPage.clickOKButtonOnDEAExpiredPopUp();
            inputPage.clickCancel();
            inputPage.clickYes();
            softAssert.assertAll();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public List<String> getStateFromStoreDb() {
        List<String> stateColumnValues = new ArrayList<>();
        String query =
                "select distinct sp.state_prov_code from location:state_prov sp, OUTER location:state_prov_text spt where sp.country_code IN ( 'US','PR') " +
                        "and sp.country_code = spt.country_code and sp.state_prov_code = spt.state_prov_code " +
                        "and spt.language_code = 101 ORDER BY state_prov_code ASC;";

        List<Map<String, Object>> resultSet;
        resultSet = automationManager.getConnexusDB().executeQueryForList(query);
        if (resultSet != null) {
            for(Map<String,Object> row : resultSet) {
                String values = row.get("state_prov_code").toString().trim();
                stateColumnValues.add(values);
            }
        }
        Reporter.log("State list size from DB:" + stateColumnValues.size());
        return stateColumnValues;
    }

    public void createNewPrescriber(Map<String, String> inputData) {
        automationManager.getConnexusWorkFlow().createNewPrescriber(inputData);
    }

    public void enterPrescriberWithPartialName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count;
        try {
            String name = inputData.get("PRESCRIBER_NAME");
            String[] fullName = name.split(",| ");
            prescriberSearchPage.inputPrescriberName(fullName[0].substring(0,3) + "," + fullName[1].substring(0,3) + " " + fullName[2].substring(0,1));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            Assert.assertTrue(count > 0, "Record count should be greater than 0");
            Reporter.log("Record count should be greater than 0");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }

    public  void verifySearchStateDropdown(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> stateDropdownList = new ArrayList<>(prescriberSearchPage.getPrescriberStateDropdownValues());
            List<String> stateDropdownValues = new ArrayList<>(stateDropdownList);
            Collections.sort(stateDropdownValues);
            Reporter.log("SortedList:"+ stateDropdownValues);

            List<String> stateListFromDB = new ArrayList<>(getStateFromStoreDb());
            Reporter.log("stateListFromDB:"+ stateListFromDB);
            Assert.assertEquals(stateDropdownValues,stateListFromDB);
            Reporter.log("StateProvCode list matched in database");
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName,  prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public  void verifySearchDegreeDropdown(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> degreeDropdownList = prescriberSearchPage.getPrescriberDegreeDropdownValues();
            Reporter.log("Original degree dropdown Values:" +degreeDropdownList);

            //Create a copy of the original list and sort it
            List<String> sortedDropdownValues = new ArrayList<>(degreeDropdownList);
            Collections.sort(sortedDropdownValues);
            Reporter.log("Sorted degree dropdown Values:"+ sortedDropdownValues);

            //Verify that the original list is the same as the sorted list
            Assert.assertEquals(sortedDropdownValues,degreeDropdownList);
            Reporter.log("Degree dropdown list is in alphabetical order");
            Reporter.logScreenShot(Status.PASS,inputData.get("TEST_NAME") + "_" + currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClose();
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL,inputData.get("TEST_NAME") + "_" + currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }
    public void searchPrescriberWithPartialName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFileWithFullName();
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberName(name[0].substring(0,3) + "," + name[1].substring(0,3) + " " + name[2].substring(0,1));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS,inputData.get("TEST_NAME") + "_" + currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL,inputData.get("TEST_NAME") + "_" + currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }

    public void verifyNoSearchResultsWithSingleInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //invalid Name
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.INFO, "Invalid Name Search", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid NPI
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Invalid NPI Search", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid DEA
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Invalid DEA Search", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid Phone
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Invalid Phone Search", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
            //invalid FAX
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberFAX(inputData.get("PRESCRIBER_FAX"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Invalid Fax Search", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyNoSearchResultsforMultipleInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            //invalid Name
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.selectPrescriberDegree(inputData.get("PRESCRIBER_DEGREE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter Name and Degree", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
            //invalid NPI
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.selectPrescriberDegree(inputData.get("PRESCRIBER_DEGREE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter NPI and Degree", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid DEA
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.selectPrescriberDegree(inputData.get("PRESCRIBER_DEGREE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter DEA and Degree", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.selectStatePrescriber(inputData.get("PRESCRIBER_STATE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter Name and STATE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
            //invalid NPI
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.selectStatePrescriber(inputData.get("PRESCRIBER_STATE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter NPI and STATE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid DEA
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.selectStatePrescriber(inputData.get("PRESCRIBER_STATE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.Invalidsearch());
            Reporter.logScreenShot(Status.PASS, "Enter DEA and STATE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();

            //invalid Phone
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.inputPrescriberFAX(inputData.get("PRESCRIBER_FAX"));
            prescriberSearchPage.selectStatePrescriber(inputData.get("PRESCRIBER_STATE"));
            Assert.assertFalse(prescriberSearchPage.searchEnabled());
            Reporter.logScreenShot(Status.PASS, "Enter Phone, Fax and STATE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void verifyPrescriberSearchCount(String countName, int count){
        if(count>=100){
            Assert.assertTrue(count>=100, "Results shown are limited to 100. Refine search to narrow results.");
            System.out.println(countName + ":" + count);
        }else{
            Assert.assertTrue(count<100, count + "" + "record(s) found.");
            System.out.println(countName + ":" + count);
        }
    }

    public void verifySearchResultGridRecordsTextwithSingleInput(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count1,count2, count3, count4, count5;

        try {
            count1  =prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAME,inputData);
            verifyPrescriberSearchCount("count1", count1 );
            Reporter.logScreenShot(Status.PASS, "Enter Name", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count2 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NPI,inputData);
            verifyPrescriberSearchCount("count2", count2 );
            Reporter.logScreenShot(Status.PASS, "Enter NPI", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count3 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_DEA,inputData);
            verifyPrescriberSearchCount("count3", count3);
            Reporter.logScreenShot(Status.PASS, "Enter DEA", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count4 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_FAX,inputData);
            verifyPrescriberSearchCount("count4", count4 );
            Reporter.logScreenShot(Status.PASS, "Enter FAX", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count5 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_PHONE,inputData);
            verifyPrescriberSearchCount("count5", count5 );
            Reporter.logScreenShot(Status.PASS, "Enter Phone", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void verifySearchResultGridRecordsTextwithMultipleInput(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count6, count7, count8, count9, count10, count11;

        try {
            count6 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAMEANDSTATE,inputData);
            verifyPrescriberSearchCount("count6", count6 );
            Reporter.logScreenShot(Status.PASS, "Enter Name ande State", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count7 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NPIANDSTATE,inputData);
            verifyPrescriberSearchCount("count7", count7 );
            Reporter.logScreenShot(Status.PASS, "Enter NPI & State", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count8 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_DEAANDSTATE,inputData);
            verifyPrescriberSearchCount("count8", count8 );
            Reporter.logScreenShot(Status.PASS, "Enter NPI & State", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count9 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAMEANDDEGREE,inputData);
            verifyPrescriberSearchCount("count9", count9 );
            Reporter.logScreenShot(Status.PASS, "Enter Name ande Degree", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count10 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NPIANDDEGREE,inputData);
            verifyPrescriberSearchCount("count10", count10 );
            Reporter.logScreenShot(Status.PASS, "Enter NPI ande DEGREE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count11 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_DEAANDDEREE,inputData);
            verifyPrescriberSearchCount("count11", count11 );
            Reporter.logScreenShot(Status.PASS, "Enter DEA ande DEGREE", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void searchWithSingleValueforMoreThan100Records(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count1;

        try {
            count1  =prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAME,inputData);
            verifyPrescriberSearchCount("count1", count1 );
            Reporter.logScreenShot(Status.PASS, "Enter Name", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void searchWithMultiValueforMoreThan100Records(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count6,count9;

        try {
            PrescriberSearchPage prescriberSearchPage = new PrescriberSearchPage();
            count6 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAMEANDSTATE,inputData);
            verifyPrescriberSearchCount("count6", count6 );
            Reporter.logScreenShot(Status.PASS, "Enter Name ande State", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            count9 = prescriberSearchPage.recordCountValidation(PrescriberSearchModel.PrescriberInputValues.PRESCRIBER_NAMEANDDEGREE,inputData);
            verifyPrescriberSearchCount("count9", count9 );
            Reporter.logScreenShot(Status.PASS, "Enter Name ande Degree", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void searchResultGridwithSingleValueinModifyDeatils(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            orderSearch.performSearch(name, SearchType.PatientRx);
            orderSearch.performSearch(name, SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            modifyDetails.launchModifyDetailScreen();
            Reporter.logScreenShot(Status.PASS, "Open Modify Details", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clearPrescriberName();
            modifyDetails.enterPrescriberNameInPrescriberField(inputData.get("PRESCRIBER_NAME"));
            searchWithSingleValueforMoreThan100Records(inputData);
            modifyDetails.clickCancel();
            modifyDetails.exitModifyDetailsScreen();
            fourPoint.clickButtonCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void searchResultGridwithMultiValueinModifyDeatils(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            orderSearch.performSearch(name, SearchType.PatientRx);
            orderSearch.performSearch(name, SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            modifyDetails.launchModifyDetailScreen();
            modifyDetails.clearPrescriberName();
            Reporter.logScreenShot(Status.PASS, "Open Modify Details", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.enterPrescriberNameInPrescriberField(inputData.get("PRESCRIBER_NAME"));
            searchWithMultiValueforMoreThan100Records(inputData);
            modifyDetails.clickAccept();
            fourPoint.clickButtonCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void searchForPrescriberPartialNameWithoutMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String enteredName = prescriberSearchPage.getValueFromNameTextField();
            String case5 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LetterforOnlyLNFN,inputData);
            Reporter.log("enteredname:" + case5);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues4 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues4) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0].substring(0,3) + "," + gridFNMN[0].substring(0,3) + " " + gridFNMN[1].substring(0, 0);
                    Assert.assertTrue(fullDetails.contains(case5));
                    if (true) {
                        System.out.println(case5 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterthreeLetterFNLNwithOneLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case7 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LNFNand1MN,inputData);
            Reporter.log("enteredname:" + case7);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues6 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues6) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0].substring(0,3) + "," + gridFNMN[0].substring(0,3) + " " + gridFNMN[1].substring(0,1);
                    Assert.assertTrue(fullDetails.contains(case7));
                    if (true) {
                        System.out.println(case7 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterFullDetailsFNLNwithOneLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case2 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter1LetterforMN,inputData);
            Reporter.log("enteredname:" + case2);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues1 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues1) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0] + "," + gridFNMN[0] + " " + gridFNMN[1].substring(0, 1);
                    Assert.assertTrue(fullDetails.contains(case2));
                    if (true) {
                        System.out.println(case2 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterthreeLetterFNLNwithTwoLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case7 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LNFNand2MN,inputData);
            Reporter.log("enteredname:" + case7);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues6 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues6) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0].substring(0,3) + "," + gridFNMN[0].substring(0,3) + " " + gridFNMN[1].substring(0,2);
                    Assert.assertTrue(fullDetails.contains(case7));
                    if (true) {
                        System.out.println(case7 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterFullDetailsFNLNwithTwoLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case2 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter2LetterforMN,inputData);
            Reporter.log("enteredname:" + case2);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues1 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues1) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0] + "," + gridFNMN[0] + " " + gridFNMN[1].substring(0, 2);
                    Assert.assertTrue(fullDetails.contains(case2));
                    if (true) {
                        System.out.println(case2 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterthreeLetterFNLNwithThreeLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case7 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LetterforLNFNMN,inputData);
            Reporter.log("enteredname:" + case7);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues6 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues6) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0].substring(0,3) + "," + gridFNMN[0].substring(0,3) + " " + gridFNMN[1].substring(0,3);
                    Assert.assertTrue(fullDetails.contains(case7));
                    if (true) {
                        System.out.println(case7 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterFullDetailsFNLNwithThreeLetterMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case2 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LetterforMN,inputData);
            Reporter.log("enteredname:" + case2);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues1 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues1) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0] + "," + gridFNMN[0] + " " + gridFNMN[1].substring(0, 3);
                    Assert.assertTrue(fullDetails.contains(case2));
                    if (true) {
                        System.out.println(case2 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterthreeLetterFNLNwithFullMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case7 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enter3LetterforLNFN,inputData);
            Reporter.log("enteredname:" + case7);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues6 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues6) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0].substring(0,3) + "," + gridFNMN[0].substring(0,3) + " " + gridFNMN[1];
                    Assert.assertTrue(fullDetails.contains(case7));
                    if (true) {
                        System.out.println(case7 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterFullDetailsFNLNwithFullMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case2 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enterFullName,inputData);
            Reporter.log("enteredname:" + case2);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues1 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues1) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0] + "," + gridFNMN[0] + " " + gridFNMN[1];
                    Assert.assertTrue(fullDetails.contains(case2));
                    if (true) {
                        System.out.println(case2 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterFullDetailsFNLNwithoutMN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int count;
            String case6 = prescriberSearchPage.validatePrescriberNamesInResult(PrescriberSearchModel.PrescriberInputValues.SearchPrescriber_enterFullNameforLNFN,inputData);
            Reporter.log("enteredname:" + case6);
            count = prescriberSearchPage.getprescriberSearchRecordCount();
            List<String> nameListValues5 = new ArrayList<>(prescriberSearchPage.getNameRecordCountGrid());
            for (String gridName : nameListValues5) {
                Reporter.log("Gridname:" + gridName);
                String[] gridPrescriberName = gridName.split(",+ ");
                String[] gridFNMN = gridPrescriberName[1].split(" ");
                for (String FNMN : gridFNMN) {
                    String fullDetails = gridPrescriberName[0] + "," + gridFNMN[0] + " " + gridFNMN[1].substring(0, 0);
                    Assert.assertTrue(fullDetails.contains(case6));
                    if (true) {
                        System.out.println(case6 + "is presents in the names" + gridName);
                    }
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void clickClearSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(3);
            prescriberSearchPage.clickClearSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }
}