package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import java.util.Map;

public class PatientMaintenanceScreenScript extends ConnexusTestScripts {
    public PatientMaintenanceScreenScript(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    /**
     * Method to open Patient Search window by pressing the Keyboard shortcut CTRL+SHIFT+P
     * Author: Srinivas(vn50jui)
     */
    public void openPatientSearchWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            softAssert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void openPatientSearchWindowfordelContacts(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createNewPatientforDeceased(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForNullPhonenumberCheck(false, patient);
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while creating patient");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyPatientStatus(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.inputPatientStatuss(inputData.get("STATUS"));
            Reporter.log("Patient Status is Active ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while verifying patient status");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void makeStatusActive() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patientSearchPage.closePatientSearchWindowsByPressingEscButton();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.selectActiveFromStatus();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to set patient status as Active");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createLiveStockPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.LIVESTOCK);
            patient.setPetLiveStockInfo(PatientProfileModel.PetLiveStockInfo.EQUINE);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
            contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
            contactModel.setClinicalServicesNumber(inputData.get("CLINICAL_SERVICE_NUMBER"));
            patient.setPatientContact(contactModel);

            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForPetAndLiveStock(false, patient);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAllSearchResultsOnSearchResultsGrid() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            Assert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickClose();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void createPatientWithAlternateNumberOnly(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForNullPhonenumberCheck(false, patient);
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void searchForPatientAndVerifyAlternateNumber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("DOB");
            String patientAlternateNumber = inputData.get("ALTERNATE_NUMBER");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.inputPatientPhone(patientAlternateNumber);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientPhoneNumberFromSearchGrid(0).replaceAll("[()\\s-]+", "").equalsIgnoreCase(patientAlternateNumber));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void createPatientWithAllNumbers(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
            contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
            contactModel.setClinicalServicesNumber(inputData.get("CLINICAL_SERVICE_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForNullPhonenumberCheck(false, patient);
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void deleteAllNumbersFromContacts() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            String patientName1 = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName1);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.deletePrimaryPhoneNumber();
            patientMaintenancePage.deleteAlternatePhoneNumber();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientSearchPage.launchPatientSearchScreen();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.deletePrimaryPhoneNumber();
            patientMaintenancePage.deleteMessagingPhoneNumber();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.isConnexusValidationPopupDisplayed();
            patientMaintenancePage.deleteClinicalServicePhoneNumber();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.isConnexusValidationPopupDisplayed();
            patientMaintenancePage.isValidationPopupDisplayedPMS();
            patientMaintenancePage.clickSaveAndClose();
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void searchForPatientAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            String patientDOB = inputData.get("DOB");
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            softAssert.assertTrue(patientSearchPage.getPatientDOBFromSearchGrid(0).equalsIgnoreCase(patientDOB));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientSearchPage.clickClose();
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void DiscontinueThirdPartyDetailsAnReactivatingPlan(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            String patientDOB = inputData.get("DOB");
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.discontinueTpPlan();
            patientMaintenancePage.clickSaveAndClose();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.closePatientSearchWindowsByPressingEscButton();
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.ReactivatePlan();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void addAllergyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patientSearchPage.closePatientSearchWindowsByPressingEscButton();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            String patientDOB = inputData.get("DOB");
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            String allergyToBeAdded = inputData.get("ALLERGY");
            patientMaintenancePage.clickAllergyMedicalTab();
            Reporter.logScreenShot("click Allergy Medical Tab", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.addAllergy(allergyToBeAdded);
            Reporter.logScreenShot(Status.PASS, "Added Allergy details", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Allergy is added");
            patientMaintenancePage.clickSaveAndClose();
        }
        catch(Exception e){
            isExceptionCaptured = true;
            Reporter.log("Test failed while adding allergy details");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void deactivateAllergyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.closePatientSearchWindowsByPressingEscButton();
            patientSearchPage.launchPatientSearchScreenUsingShortCut();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.clickAllergyMedicalTab();
            patientMaintenancePage.clickDeactiveAllergy();
            patientMaintenancePage.deactivateAllergyReason();
            Reporter.log("Patient Allergy is deactivated");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        }
        catch(Exception e){
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAllergyDetailsInDb()
    {
        ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String patientId = connexusAppUtils.getPatientId(name[0],name[1]);
        System.out.println(patientId);
        String allergyCode = connexusAppUtils.verifyAllergyClassCode(Integer.parseInt(patientId));
        String reactionTxt = connexusAppUtils.verifyReactionTxt(Integer.parseInt(patientId));
        String allergyClassType_cd = connexusAppUtils.verifyallergyClassType(Integer.parseInt(patientId));
        Reporter.log("DB Result for allergyCode:" + allergyCode);
        Reporter.log("DB Result for reactionTxt:" + reactionTxt);
        Reporter.log("DB Result for allergyClassType:" + allergyClassType_cd);
        Reporter.log("Verified in DB");
    }

    public void checkPaymentMethodInPickup() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Payment method is TP");
            modifyDetails.clickAccept();
            inputPage.partialpopup();
            orderSearch.isConnexusPopUpDisplayed();
            orderSearch.clickOk();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void closePatientSearchWindowByClickingOnCloseButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}
