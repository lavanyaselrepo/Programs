package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.DropRxModel;
import hwqe.baseframework.models.datamodels.connexus.RxModel;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

public class InventoryManagementTestSetScripts {

    LoginPage loginPage;
    MenuBar menuBar;
    CycleCountReportPage cycleCountReportPage;
    ProductSearchPage productSearchPage;
    ItemMaintenancePage itemMaintenancePage;
    CIIDigitalLogBookPage c2DigitalLogBook;
    CIILogBookAdjustmentReasonPage c2LogBookAdjustmentReason;
    ConnexusStartPage connexusStartPage;
    ProductMaintenancePage productMaintenancePage;
    ConnexusAppUtils connexusAppUtils;
    F6Search rxSearch;
    AutomationManager automationManager;
    SoftAssert softAssert = new SoftAssert();

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        menuBar = new MenuBar();
        cycleCountReportPage = new CycleCountReportPage();
        productSearchPage = new ProductSearchPage();
        itemMaintenancePage = new ItemMaintenancePage();
        c2DigitalLogBook = new CIIDigitalLogBookPage();
        c2LogBookAdjustmentReason = new CIILogBookAdjustmentReasonPage();
        connexusStartPage = new ConnexusStartPage();
        productMaintenancePage = new ProductMaintenancePage();
        connexusAppUtils = new ConnexusAppUtils();
        rxSearch = new F6Search();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    /*----------------------------------------------------------------------------------------------------------
       * This method  fetches a non D38 drug and drop an Rx and complete till filling and the open the Rx in visual verify page.
       *
       * Author: Sugapriya S(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void dropAnRxTillVisualVerify(Map<String, String> inputData) {
        try {
            String productName = connexusAppUtils.getNonD38ProductDetailsFromDb().get("short_name").toString().trim();
            Reporter.log("product_name: " + productName);
            String packQuantity = String.valueOf(connexusAppUtils.getNonD38ProductDetailsFromDb().get("inner_pack_qty"));
            String quantity = packQuantity.replaceAll("\\.0*$", "");
            Reporter.log("inner_pack_qty: " + quantity);

            DropRxModel dropRxModel = new DropRxModel();
            RxModel rxModel = new RxModel();
            dropRxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            dropRxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.InStore);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

            rxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            rxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            rxModel.setNdc(productName);
            rxModel.setPrescribedQty(quantity);
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);

            String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"));
            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            automationManager.performSleep(5);

            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method  fetches a non D38 drug and drop an Rx and complete till Visual Verify and the open
        *  the Rx in Bagging page.
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void dropAnRxTillBagging(Map<String, String> inputData) {
        try {
            String productName = connexusAppUtils.getNonD38ProductDetailsFromDb().get("short_name").toString().trim();
            Reporter.log("product_name: " + productName);
            String packQuantity = String.valueOf(connexusAppUtils.getNonD38ProductDetailsFromDb().get("inner_pack_qty"));
            String quantity = packQuantity.replaceAll("\\.0*$", "");
            Reporter.log("inner_pack_qty: " + quantity);

            DropRxModel dropRxModel = new DropRxModel();
            RxModel rxModel = new RxModel();
            dropRxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            dropRxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.InStore);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

            rxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            rxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            rxModel.setNdc(productName);
            rxModel.setPrescribedQty(quantity);
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);
            String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"));
            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            automationManager.performSleep(5);
            automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method clicks on menu Cancel Fill->Return to stock and confirms with a yes button
        *if the prompt asked for item in unopened stock container
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void returnToStockYes() {
        try {
            menuBar.navigateToMenu(AppMenu.RETURN_TO_STOCK);
            if (itemMaintenancePage.isPopUpDisplayed()) {
                Reporter.log("Return To Stock will cancel the fill and place prescription on-hold. Continue?");
                Reporter.logScreenShot("confirmation of return to stock", itemMaintenancePage.takeScreenShot());
                itemMaintenancePage.clickYes();
                if (itemMaintenancePage.isPopUpDisplayed()) {
                    Reporter.log("Is item in an unopened stock container");
                    Reporter.logScreenShot("confirmation if item in unopened stock container", itemMaintenancePage.takeScreenShot());
                    itemMaintenancePage.clickYes();
                    if (itemMaintenancePage.isPopUpDisplayed()) {
                        Reporter.log("Item will be MTR'd back to original department");
                        Reporter.logScreenShot(Status.PASS, "Stock returned and item back to original department", itemMaintenancePage.takeScreenShot());
                        itemMaintenancePage.clickOk();
                    }
                }
            } else {
                Reporter.logScreenShot(Status.FAIL, "Popup not displayed", itemMaintenancePage.takeScreenShot());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
       * This method clicks on menu CAncel Fill->Return to stock and confirms with a yes button
       *if the prompt asked for item in unopened stock container
       *
       * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void returnToStockNoOpenStock() {
        try {
            menuBar.navigateToMenu(AppMenu.RETURN_TO_STOCK);
            if (itemMaintenancePage.isPopUpDisplayed()) {
                Reporter.log("Return To Stock will cancel the fill and place prescription on-hold. Continue?");
                Reporter.logScreenShot("confirmation of return to stock", itemMaintenancePage.takeScreenShot());
                itemMaintenancePage.clickYes();
                if (itemMaintenancePage.isPopUpDisplayed()) {
                    Reporter.log("Is item in an unopened stock container");
                    Reporter.logScreenShot("confirmation if item in unopened stock container", itemMaintenancePage.takeScreenShot());
                    itemMaintenancePage.clickNoButton();
                    if (itemMaintenancePage.isPopUpDisplayed()) {
                        Reporter.log("Do you want to print return to stock label? displayed ");
                        Reporter.logScreenShot(Status.PASS, "confirmation to print return to stock label;", itemMaintenancePage.takeScreenShot());
                        itemMaintenancePage.clickYes();
                    }
                }
            } else {
                Reporter.logScreenShot(Status.FAIL, "Popup not displayed", itemMaintenancePage.takeScreenShot());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method clicks on menu Cancel Fill->Therapy Discontinued and confirms with a yes button
        *if the prompt asked for item in unopened stock container
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void therapyDiscontinuedOpenStock() {
        try {
            menuBar.navigateToMenu(AppMenu.THERAPY_DISCONINUE);
            if (itemMaintenancePage.isPopUpDisplayed()) {
                Reporter.log("Therapy Discontinued will cancel the fill and deactivate prescription. Continue?");
                Reporter.logScreenShot("confirmation of return to stock", itemMaintenancePage.takeScreenShot());
                itemMaintenancePage.clickYes();
                if (itemMaintenancePage.isPopUpDisplayed()) {
                    Reporter.log("Is item in an unopened stock container");
                    Reporter.logScreenShot("confirmation if item in unopened stock container", itemMaintenancePage.takeScreenShot());
                    itemMaintenancePage.clickYes();
                    if (itemMaintenancePage.isPopUpDisplayed()) {
                        Reporter.log("Item will be MTR'd back to original department");
                        Reporter.logScreenShot(Status.PASS, "Therapy Discontinues and item back to original department", itemMaintenancePage.takeScreenShot());
                    }
                }
            } else {
                Reporter.logScreenShot(Status.FAIL, "Popup not displayed", itemMaintenancePage.takeScreenShot());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method verify if the pop up is displayed for clicking therapy discontinued and cliks ok on the
        * pop up saying item will be MTR'd back to original department
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void clickOkOnTherapyDiscontinued() {
        try {
            Reporter.log(" TC combined with previous case and the needed steps were obtained in @tc_03_unopened_stock_container_popup_NonD38_MTR_RTS");
            if (itemMaintenancePage.isPopUpDisplayed()) {
                Reporter.log("Item will be MTR'd back to original department");
                Reporter.logScreenShot(Status.PASS, "Therapy Discontinues and item back to original department", itemMaintenancePage.takeScreenShot());
                itemMaintenancePage.clickOk();
                Reporter.log(" Clicked on OK button");
            } else {
                Reporter.logScreenShot(Status.FAIL, "Pop up not visible", itemMaintenancePage.takeScreenShot());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method navigates to Reports -> Inventory Reports -> Cycle Count Report using navigatetoMenu()
   * and clicks on Cycle Count Reports. It looks for records in the reports appear on screen
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void openCycleCountReport() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            menuBar.navigateToMenu(AppMenu.CYCLE_COUNT);
            automationManager.performSleep(3);
            Reporter.log("Cycle count report is generated");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method clicks ndc value from Cycle count Report
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void selectNdcOnCycleCountReport() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            cycleCountReportPage.clickNdcNbr(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below generated random number including 0 and 100 and inputs the value as on-hand quantity in the
   * enter quantity field in Cycle Count Report. It clicks floating yes button on double check point pop up.
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void changeOnHandDrugQtyOnReports() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Random random = new Random();
            cycleCountReportPage.inputDrugQty(0, String.valueOf(random.nextInt(100)));
            cycleCountReportPage.pressTabKey();
            if (cycleCountReportPage.isYesDisplayed()) {
                cycleCountReportPage.clickYes();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below clicks on Hazardous waste ad adjustment reason and process the flow by clicking continue button
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void selectHazardousWaste() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReason.clickHazWasteAdjustmentReason();
            c2LogBookAdjustmentReason.clickContinue();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below looks if DEA 222 Form # pop up is displayed and inputs alphanumeric DEA number
   * and retype DEA number from Data sheet and clicks accept button to process the flow
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void verifyDEA222Form(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (c2LogBookAdjustmentReason.isDeaPopUpDisplayed()) {
                Reporter.log("DEA 222 Form# pop up is displayed");
                c2LogBookAdjustmentReason.inputDeaFormNbr(inputData.get("DEA_TEXT_BOX1"));
                c2LogBookAdjustmentReason.inputRetypeDEAFormNbr(inputData.get("DEA_TEXT_BOX2"));
                Reporter.log("Valid Entry of DEA Form Number is accepted in both the text fields");
                c2LogBookAdjustmentReason.clickAccept();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below processes the given onhand quantity for the drug and processes the cycle count
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void processCycleCount() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            cycleCountReportPage.clickProcessCycleCount();
            cycleCountReportPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below verifies that the onhand quantity and adjustment reason given for the drug in Cycle Count Report
   * is updated in phm_item_inv_adjmt_log table at the back end
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void verifyProcessedDrugQty() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            //The below query fetches the On hand quantity and adjustment reason for the drug updated in phm_item_inv_adjmt_log inner table
            String processedDrugQtyQuery = "select ndc_nbr, onhand_qty\n" +
                    "from pharmacy_offering: phm_item_inv_adjmt_log inner join pharmacy_offering: pharmacy_item\n" +
                    "on pharmacy_offering: phm_item_inv_adjmt_log.mds_fam_id = pharmacy_offering: pharmacy_item.mds_fam_id \n" +
                    "order by pharmacy_offering: phm_item_inv_adjmt_log.log_id desc limit 1";
            Map<String, Object> processedDrugQtyFromDB = automationManager.getConnexusDB().executeQuery(processedDrugQtyQuery);
            String processedDrugQty = processedDrugQtyFromDB.get("onhand_qty").toString().trim();
            String[] drugQty = processedDrugQty.split("\\.");
            Reporter.log("The new on hand qty : " + drugQty[0] + " is present in Database");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method searches C2 drug on product search screen and launches IMS screen
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void searchCIIDrugOnIMSScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.PRODUCT.getAppShortcuts());
            if (productSearchPage.productSearchFlagValueCheck()) {
                productSearchPage = new ProductSearchPage();
            }
            productSearchPage.enterProductNDC(inputData.get("NDC_NUMBER"));
            productSearchPage.clickSearchNow();
            productSearchPage.doubleClickOnSearchGridRow(0);
            productMaintenancePage.doubleClickOnItemsGridRow(0);
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method generates random number including 0 and 100 for on hand quantity and inputs Inventory Onhand
   * Quantity as Pharmacist and verifies quantity change.
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void changeOnHandDrugQtyOnIMS() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Random random = new Random();
            itemMaintenancePage.clearOnHandDrugQty();
            itemMaintenancePage.inputOnHandDrugQty(String.valueOf(random.nextInt(100)));
            itemMaintenancePage.clickAccept();
            if (itemMaintenancePage.getMessageFromPopUpDisplayed().contains("Order Point may be Zero or Null")) {
                itemMaintenancePage.clickNoButton();
            }
            if (itemMaintenancePage.getMessageFromPopUpDisplayed().contains("Order Quantity may be Zero or Null")) {
                itemMaintenancePage.clickNoButton();
            }
            itemMaintenancePage.inputRphPasswordOnRphVerifyPopUp();
            itemMaintenancePage.clickAcceptOnRphVerifyPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method verifies and validates the DEA 222 Form # pop up, its text boxes (DEA 222 Form # and Retype DEA 222 Form #)
   * and buttons (Accept and Cancel)
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateDEA222FormNumberPopUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(c2LogBookAdjustmentReason.isDeaFormNbrDisplayed());
            Reporter.log("DEA Form Number text field is displayed");
            Assert.assertTrue(c2LogBookAdjustmentReason.isAcceptDisplayed());
            Assert.assertTrue(c2LogBookAdjustmentReason.isCancelDisplayed());
            Reporter.log("Accept and cancel button is displayed");
            Assert.assertFalse(c2LogBookAdjustmentReason.isRetypeDeaFormNbrEnabled());
            Reporter.log("Retype DEA Number Field (Second Text box) is disabled initially when DEA Form 222 Pop up opens up");
            Assert.assertFalse(c2LogBookAdjustmentReason.isAcceptEnabled());
            Assert.assertTrue(c2LogBookAdjustmentReason.isCancelEnabled());
            Reporter.log("Accept button is deactivated and cancel button is activated initially when DEA Form 222 Pop up opens up");
            c2LogBookAdjustmentReason.inputDeaFormNbr(inputData.get("DEA_TEXT_BOX1"));
            Assert.assertTrue(c2LogBookAdjustmentReason.isRetypeDeaFormNbrEnabled());
            Reporter.log("Retype DEA Number field (Second Text Box) is available to reenter only after providing valid values in DEA Number field (First Text Box)");
            // to continue with next test case
            c2LogBookAdjustmentReason.inputRetypeDEAFormNbr(inputData.get("DEA_TEXT_BOX2"));
            c2LogBookAdjustmentReason.clickCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method validates the DEA 222 Form # Text Field on DEA 222 Form # pop up
   * and does not accept 8 character alpha numeric value
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateTextBox1For8CharLenInDEA222PopUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String regPatFor8DigitAphaNum = "[A-Za-z0-9]{8}";
            Assert.assertTrue(Pattern.matches(regPatFor8DigitAphaNum, inputData.get("DEA_WITH_8_CHAR_LEN")));
            c2LogBookAdjustmentReason.inputDeaFormNbr(inputData.get("DEA_WITH_8_CHAR_LEN"));
            c2LogBookAdjustmentReason.pressTabKey();
            Assert.assertFalse(c2LogBookAdjustmentReason.isRetypeDeaFormNbrEnabled());
            Reporter.log("Retype DEA Number (Textbox2) is disabled until DEA Number (Textbox1) reaches 9 characters in length");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method validates the DEA 222 Form # Text Field on DEA 222 Form # pop up
   * and accepts 9 character alpha numeric value. Also verifies Text Field 1 is starred out after moving to Text Field 2
   * Validates Text Field 2 is visible after providing same 9 character alpha numeric same as Text Field 1.
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateTextBox1For9CharLenInDEA222PopUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReason.clickDeaFormNbr();
            String regPatFor9DigitAphaNum = "[A-Za-z0-9]{9}";
            Assert.assertTrue(Pattern.matches(regPatFor9DigitAphaNum, inputData.get("DEA_TEXT_BOX1")));
            c2LogBookAdjustmentReason.inputDeaFormNbr(inputData.get("DEA_TEXT_BOX1"));
            c2LogBookAdjustmentReason.pressTabKey();
            String textBox1Value = c2LogBookAdjustmentReason.getDeaFormNbr();
            Reporter.log("DEA Number (Textbox1) text " + textBox1Value + " is starred out after providing 9 characters in length and tab pressed");
            Assert.assertTrue(c2LogBookAdjustmentReason.isRetypeDeaFormNbrEnabled());
            Reporter.log("Retype DEA Number (Textbox2) is enabled");
            c2LogBookAdjustmentReason.inputRetypeDEAFormNbr(inputData.get("DEA_TEXT_BOX2"));
            String textBox2Value = c2LogBookAdjustmentReason.getRetypeDeaFormNbr();
            Reporter.log("Retype DEA Number field (Textbox2) characters " + textBox2Value + " are visible");
            c2LogBookAdjustmentReason.clickDeaFormNbr();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method closes the DEA 222 Form # pop up to continue the flow
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void closeDEA222PopUpWithValidDeaNumber(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReason.clickDeaFormNbr();
            c2LogBookAdjustmentReason.pressTabKey();
            c2LogBookAdjustmentReason.inputDeaFormNbr(inputData.get("DEA_TEXT_BOX1"));
            c2LogBookAdjustmentReason.clickCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method validates that Liquid Check box on DEA 222 Form # Pop up is checked or unchecked
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateLiquidLossCheckBox() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (c2LogBookAdjustmentReason.isLiquidLossChecked().contains("1")) {
                Reporter.log("Liquid Loss check box is selected on DEA Form 222 Pop Up");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Liquid Loss check box is un selected on DEA Form 222 Pop Up");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The method validates DEA Number (Text Box 1) on DEA 222 Form # Pop up is not enabled
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateTextBox1OnDeaPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(c2LogBookAdjustmentReason.isDeaFormNbrEnabled());
            Reporter.log("DEA Number (Textbox1) is disabled on DEA Form 222 Pop Up");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The method validates Retype DEA Number (Text Box 2) on DEA 222 Form # Pop up is not enabled
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateTextBox2OnDeaPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(c2LogBookAdjustmentReason.isRetypeDeaFormNbrEnabled());
            Reporter.log("Retype DEA Number (Textbox2) is disabled on DEA Form 222 Pop Up");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The method validates Accept button on DEA 222 Form # Pop up is enabled or not
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateAcceptButtonOnDeaPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (c2LogBookAdjustmentReason.isAcceptEnabled()) {
                Reporter.log("Accept button is enabled on DEA Form 222 Pop Up");
            } else {
                Reporter.log("Accept button is disabled on DEA Form 222 Pop Up");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The method validates liquid loss message displayed on DEA 222 Form # Pop up
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateLiquidLossMessage() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (c2LogBookAdjustmentReason.getLiquidLossMessage().contains("DEA 222# is not required for Liquid Loss")) {
                String liquidLossMessage = c2LogBookAdjustmentReason.getLiquidLossMessage();
                Reporter.log("Message: " + liquidLossMessage + " is displayed on DEA Form 222 Pop Up");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method checks Liquid Loss check box on DEA 222 Form # pop up
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void checkLiquidLoss() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReason.clickLiquidLoss();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method clicks on Accept button on DEA 222 Form # pop up
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void clickAcceptButtonOnDeaPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReason.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, c2LogBookAdjustmentReason.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method below clicks Accept button and closes Product Screen
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void acceptProductSearch() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productMaintenancePage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method below gets the ndc number from Cycle Count Report page and process the entered Quantity for the drug
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public String processCycleCountInReport() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String ndcNbr = cycleCountReportPage.getNdcNbr(0);
            cycleCountReportPage.clickProcessCycleCount();
            cycleCountReportPage.clickClose();
            return ndcNbr;
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method below inputs the drug in C2 Digital Log book to display the c2 drug log status
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void openCIIDigitalLogBookAndVerifyDrug(String ndcNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            menuBar.navigateToMenu(AppMenu.CII_DIGITAL_LOG_BOOK);
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            c2DigitalLogBook.inputNdcNumber(ndcNbr.replaceAll("\\D+", ""));
            c2DigitalLogBook.pressEnterKey();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method below verifies the given drug is available in C2 Digital Logbook Page
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void verifyDEA222FormInCIIDigitalLogBook(String ndcNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productSearchPage.doubleClickOnSearchGridRow(0);
            if (productSearchPage.isSearchNowButtonDisplayed()) {
                productSearchPage.doubleClickOnSearchGridRow(0);
            }
            automationManager.performSleep(3);
            c2DigitalLogBook.clickSearch();
            c2DigitalLogBook.selectNdcNbr(ndcNbr);
            c2DigitalLogBook.clickSearch();
            automationManager.performSleep(2);
            if (c2DigitalLogBook.getDeaNbrColumn(0).contains("null")) {
                Reporter.log("DEA 222 form# number is not displayed in the report as there is nothing to ship back to Haz waste");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            }
            c2DigitalLogBook.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The method below validates the Adjustment reason given while changing on hand drug quantity and processing the drug
   *
   * Author: Lakshmi Priya(vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateAdjustmentReasonOnDB() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // The below query selects ndc number, onhand quantity, adjustment reason from pharmacy_item,phm_item_inv_adjmt_log,phm_item_adjmt_rsn_txt tables
            String adjmtReasonQuery = "select ndc_nbr, onhand_qty, adjmt_rsn_desc\n" +
                    "from pharmacy_offering: phm_item_inv_adjmt_log \n" +
                    "inner join pharmacy_offering: pharmacy_item \n" +
                    "on pharmacy_offering: phm_item_inv_adjmt_log.mds_fam_id = pharmacy_offering: pharmacy_item.mds_fam_id \n" +
                    "inner join pharmacy_offering: phm_item_adjmt_rsn_txt \n" +
                    "on pharmacy_offering: phm_item_inv_adjmt_log.adjmt_rsn_code = pharmacy_offering: phm_item_adjmt_rsn_txt.adjmt_rsn_code\n" +
                    "order by pharmacy_offering: phm_item_inv_adjmt_log.log_id desc limit 1";
            Map<String, Object> adjmtReasonFromDB = automationManager.getConnexusDB().executeQuery(adjmtReasonQuery);
            String adjmtReason = adjmtReasonFromDB.get("adjmt_rsn_desc").toString();
            Reporter.log("Inventory adjustment is logged for selected reason: " + adjmtReason + " in the database");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
           * This method verifies if popup is displayed on selecting full month and more C2 counts in cycle count
           * reports page
           *
           * Author: Sugapriya S(vn510of)
       ----------------------------------------------------------------------------------------------------------*/
    public void cycleCountFullMonth(Map<String, String> inputData) {
        try {
            cycleCountReportPage.clickFullMonth();
            cycleCountReportPage.clickC2Count();
            cycleCountReportPage.switchWindow();
            String popUp = cycleCountReportPage.getPopUpMessage();
            Assert.assertEquals(popUp, inputData.get("MESSAGE"));
            Reporter.logScreenShot("Error Popup ", itemMaintenancePage.takeScreenShot());
            cycleCountReportPage.clickOk();
            cycleCountReportPage.clickClose();
        }catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
           * This method search for a product and open the item maintanence page of the selected product
           *
           * Author: Sugapriya S(vn510of)
       ----------------------------------------------------------------------------------------------------------*/
    public void productSearchWithDrugName(Map<String, String> inputData) {
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.PRODUCT.getAppShortcuts());
            productSearchPage.enterProductName(inputData.get("DRUG_NAME"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot("Product Results", itemMaintenancePage.takeScreenShot());
            productSearchPage.doubleClickOnSearchGridRow(0);
            productSearchPage.doubleClickOnNDCSearchGrid(0);
            Reporter.logScreenShot("Item Maintanence Page", itemMaintenancePage.takeScreenShot());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method verifies if adjustment Reason code pop up is displayed on changing the on Hand quantity
        * if the oroduct in IMS screen, when logged in as pharmacist
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void verifyAdjustmentCodeInIMS(Map<String, String> inputData) {
        try {
            itemMaintenancePage.inputOnHandDrugQty(inputData.get("QUANTITY"));
            Reporter.logScreenShot("Accepting quantity change", itemMaintenancePage.takeScreenShot());
            itemMaintenancePage.clickAccept();
            itemMaintenancePage.switchWindow();
            Assert.assertTrue(c2LogBookAdjustmentReason.checkAllElementsInAdjustmentReason());
            Reporter.log("Adjustment Reason code is displayed on changing OnHand Quantity");
            Reporter.logScreenShot(Status.PASS, "Adjustment Reason code", itemMaintenancePage.takeScreenShot());
            c2LogBookAdjustmentReason.clickBack();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
       * This method verifies if adjustment Reason code pop up is displayed on changing the on Hand quantity
       * if the oroduct in IMS screen, when logged in as pharmacist and select the 3rd reason in popup.
       *
       * Author: Sugapriya S(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void selecting3rdAdjustmentCodeInIMS() {
        try {
            Assert.assertTrue(c2LogBookAdjustmentReason.isAdjustmentCodeDisplayed());
            Reporter.log("Adjustment Reason code is displayed on changing OnHand Quantity");
            Reporter.logScreenShot("Adjustment Reason code", itemMaintenancePage.takeScreenShot());
            c2LogBookAdjustmentReason.selectQtyDiscrepancy();
            Reporter.logScreenShot("Selecting 3rd Adjustment Code", itemMaintenancePage.takeScreenShot());
            itemMaintenancePage.clickAccept();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
       * This method verifies if adjustment Reason code pop up is displayed and pre receiving popup is not
       * displayed  on changing the on Hand quantity if the oroduct in IMS screen, when logged in as pharmacist
       *
       * Author: Sugapriya S(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void checkingForPreReceivingPopup(Map<String, String> inputData) {
        try {
            itemMaintenancePage.clearOnHandDrugQty();
            itemMaintenancePage.inputOnHandDrugQty(inputData.get("QUANTITY"));
            Reporter.logScreenShot("Item Maintanence Page", itemMaintenancePage.takeScreenShot());
            itemMaintenancePage.clickAccept();
            if (c2LogBookAdjustmentReason.checkAllElementsInAdjustmentReason()) {
                Reporter.log("Adjustment reson code is  displayed on updating on-hand quantity of non C2 drug");
                if (!itemMaintenancePage.isPreReceivingPopUpDisplayed()) {
                    Reporter.log("PRE RECEIVING POPUP is not displayed");
                    Reporter.logScreenShot("Adjustment Reason code", itemMaintenancePage.takeScreenShot());
                } else {
                    Reporter.log("Pre-Receiving popup is displayed.");
                }
            } else {
                Reporter.log("Adjustment reson code is not displayed ");
            }

            /* closing  adjustment screen without selecting any options*/
            c2LogBookAdjustmentReason.clickBack();

            /* closing item maintanence screen */
            itemMaintenancePage.clickCancelButton();
            itemMaintenancePage.switchWindow();
            itemMaintenancePage.clickYes();

            /* Exiting from product screen */
            itemMaintenancePage.clickCancelButton();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method is to verify if adjustment reason code is diplayed and select the 3rd option
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void select3rdAdjustmentCodeInCycleCount(Map<String, String> inputData) {
        try {
            String drugValue = cycleCountReportPage.readDrugSchedule(0);
            Reporter.log(" Drug schedule Value: " + drugValue);
            /*Drug schedule value 2 means C2 drug and so checking if the value equals 2 to confirm the drug is C2 drug*/
            if ("2".equals(drugValue)) {
                Reporter.log(" Drug is a controlled drug");
                Reporter.logScreenShot("Report with  controlled drug in RED", itemMaintenancePage.takeScreenShot());
                cycleCountReportPage.inputDrugQty(0, inputData.get("QUANTITY"));
                cycleCountReportPage.pressTabKey();
                if (cycleCountReportPage.isYesDisplayed()) {
                    cycleCountReportPage.clickYes();
                }
            }
            Assert.assertTrue(c2LogBookAdjustmentReason.isAdjustmentCodeDisplayed());
            Reporter.log("Adjustment reson code is  displayed on updating on-hand quantity of non C2 drug");
            Reporter.logScreenShot("Adjustment Reason code", itemMaintenancePage.takeScreenShot());
            c2LogBookAdjustmentReason.selectQtyDiscrepancy();
            Reporter.logScreenShot("Selecting 3rd Adjustment Code", itemMaintenancePage.takeScreenShot());
            cycleCountReportPage.clickProcessCycleCount();
            cycleCountReportPage.clickClose();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method verifies whether the adjustment reason code selected is reflected in database
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateReasonCodeInDb() {
        try {
            String query = "select adjmt_rsn_code from pharmacy_offering:phm_item_inv_adjmt_log " +
                    "where mds_fam_id='266950' order by adjmt_status_ts desc limit 1";
            Map<String, Object> reason = automationManager.getConnexusDB().executeQuery(query);
            String reasonCode = reason.get("adjmt_rsn_code").toString().trim();
            Reporter.log(" Adjustment Reason Code is : " + reasonCode);
            System.out.println("Adjustment Reason Code is : " + reasonCode);
            /*checks if the value is 3 refering 3rd reason code is selected */
            Assert.assertEquals(reasonCode, "3");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
      * This method drop an Non C2 drug Rx and complete till filling an the open the visual verify page
      *
      * Author: Sugapriya S(vn510of)
  ----------------------------------------------------------------------------------------------------------*/
    public void dropAnRxTillVisualVerifyForPartialFill(Map<String, String> inputData) {
        try {
            DropRxModel dropRxModel = new DropRxModel();
            RxModel rxModel = new RxModel();
            dropRxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            dropRxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.InStore);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

            rxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            rxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);

            String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"));
            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            automationManager.performSleep(5);
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
       * This method verifies if adjustment reason code popup is displayed in visual verify page, if
       * cancel fill-> Partial fill menu is chosen
       *
       * Author: Sugapriya S(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void adjustmentReasonInPartialFilling(Map<String, String> inputData) {
        try {
            menuBar.navigateToMenu(AppMenu.PARTIAL_FILL);
            if(itemMaintenancePage.isPartialFillDisplayed()) {
                itemMaintenancePage.setPartialFill(inputData.get("DRUG_SPLIT_QTY"), inputData.get("DRUG_ONHAND_QTY"));
                itemMaintenancePage.clickAccept();
                itemMaintenancePage.switchWindow();
                Assert.assertTrue(c2LogBookAdjustmentReason.checkAllElementsInAdjustmentReason());
                Reporter.log("Adjustment Reason code is displayed on changing OnHand Quantity");
                Reporter.logScreenShot(Status.PASS,"Adjustment Reason code", itemMaintenancePage.takeScreenShot());
                c2LogBookAdjustmentReason.clickBack();
                itemMaintenancePage.clickCancelPartialFill();
                itemMaintenancePage.clickCancelButton();
            }else{
                Reporter.logScreenShot(Status.FAIL,"Adjustment Reason code", itemMaintenancePage.takeScreenShot());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
           * This method is to verify if adjustment Reason code popup is generated in Cycle count reports page
           * on changingb onhand quantity
           *
           * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void verifyAdjustmentCodeInCycleCount(Map<String, String> inputData) {
        try {
            Reporter.log(" Sorting based on drugschedule to fetch non C2 drug");
            /*2 is the drug schedule for C2 drug and so validating with it and sorting to fetch Non C2 drug*/
            while ("2".equals(cycleCountReportPage.readDrugSchedule(0))) {
                cycleCountReportPage.sortByDrugSchedule();
            }
            Reporter.log(" Drug is an non C2 drug");
            Reporter.logScreenShot("Report with non C2 drug", itemMaintenancePage.takeScreenShot());
            cycleCountReportPage.inputDrugQty(0, inputData.get("QUANTITY"));
            cycleCountReportPage.pressTabKey();
            cycleCountReportPage.switchWindow();
            if (cycleCountReportPage.isPopupDisplayed()) {
                cycleCountReportPage.clickYes();
            }
            cycleCountReportPage.switchWindow();
            Assert.assertTrue(c2LogBookAdjustmentReason.checkAllElementsInAdjustmentReason());
            Reporter.log("Adjustment reson code is  displayed on updating on-hand quantity of non C2 drug");
            Reporter.logScreenShot("Adjustment Reason code", itemMaintenancePage.takeScreenShot());
            c2LogBookAdjustmentReason.clickBack();
            cycleCountReportPage.clickClose();
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method is to verify Adjustment Reason code is not displayed on changing the On hand Quantity of
     * the Non C2 drug in Cycle count report page
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void verifyAdjustmentCodeForTechnician(Map<String, String> inputData) {
        try {
            cycleCountReportPage.sortByDrugSchedule();
            String drugValue = cycleCountReportPage.readDrugSchedule(0);
            /*drug schedule for c2 drug is 2 and non controlled drug is None*/
            if (!"2".equals(drugValue) && (!"NONE".equals(drugValue))) {
                Reporter.log(" Drug is an non C2 drug");
                Reporter.logScreenShot("Report with non C2 drug", itemMaintenancePage.takeScreenShot());
                cycleCountReportPage.inputDrugQty(0, inputData.get("QUANTITY"));
                cycleCountReportPage.pressTabKey();
                Reporter.logScreenShot("See Pharmacist popup window", itemMaintenancePage.takeScreenShot());
                cycleCountReportPage.clickOk();
            }
            Assert.assertFalse(c2LogBookAdjustmentReason.checkAllElementsInAdjustmentReason());
            Reporter.log("Adjustment reson code is  not displayed on updating on-hand quantity of non C2 drug and verify is checked");
            Reporter.logScreenShot("Validate box is Checked without Reason Code", itemMaintenancePage.takeScreenShot());
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method verifies if C2 drug detail is visible in Cycle count report if logged in as Technician
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void verifyC2DrugInvisibleForTechnician() {
        try {
            int value = 0;
            while (value <= 2) {
                String drugValue = cycleCountReportPage.readDrugSchedule(0);
                Reporter.log(" Drug schedule Value: " + drugValue);
                /*Drug schedule for C2 drug is 2 and verifies if the value matches 2 */
                if ("2".equals(drugValue)) {
                    Reporter.log("C2 drug is visble");
                    Reporter.logScreenShot(Status.FAIL, "Report witho C2 drugs", cycleCountReportPage.takeScreenShot());
                    break;
                }
                cycleCountReportPage.sortByDrugSchedule();
                value++;
            }
            Reporter.log("C2 drug is not visible for Technician");
            Reporter.logScreenShot(Status.PASS, "Report without C2 drugs", cycleCountReportPage.takeScreenShot());
            cycleCountReportPage.clickClose();
            cycleCountReportPage.switchWindow();
            cycleCountReportPage.clickYes();
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method verifies if the On-Hand quantity field in item Maintanence page is disabled if logged in
        *  as technician
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public void verifyQuantityDisabledForTechnician() {
        try {
            Assert.assertFalse(itemMaintenancePage.isOnHandQtyEnabled());
            Reporter.log(" Onhand Quantity of the selected C2 drug is disabled");
            Reporter.logScreenShot(Status.PASS, "ON hand QTY DISABLED", itemMaintenancePage.takeScreenShot());
            /* Closing the item Maintenance Window*/
            itemMaintenancePage.clickCancelButton();
            itemMaintenancePage.clickYes();
            /*Closing the Product information Window*/
            itemMaintenancePage.clickCancelButton();
        } catch (Exception e) {
            softAssert.fail(e.toString());
        }
    }
}