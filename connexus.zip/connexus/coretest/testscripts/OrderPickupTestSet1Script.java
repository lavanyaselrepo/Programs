package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openqa.selenium.Keys;
import org.testng.asserts.SoftAssert;

import java.awt.event.KeyEvent;
import java.util.Map;

public class OrderPickupTestSet1Script {
    LoginPage loginPage;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    TascoPage tascoPage;
    ModifyDetails modifyDetails;
    PropertyReader prop ;
    private  String  rxNbr;
    private  String rxNbr1;
    F6Search orderSearch;
    public SoftAssert softAssert = new SoftAssert();
    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
        tascoPage = new TascoPage();
        modifyDetails =new ModifyDetails();
        prop = PropertyReader.getInstance();
        orderSearch = new F6Search();
        loginPage.loginConnexus(userType);
    }

    public void createPatient(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);
        contactModel.setPatientPrimaryNumber(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientAlternateNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
        patient.setPatientIdentityModel(patientIdentityModel);
        patient.setPatientContact(contactModel);
        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
    }

    public void dropAnRxTillBagging(Map<String, String> inputData) {
        DropRxModel dropRxModel =new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            automationManager.performSleep(10);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            Reporter.log("RX is in Resolve queue");
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            Reporter.log("RX is in CASH queue");
            automationManager.performSleep(5);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

        if("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())){
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }

    }

    public void  pseSearch(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            PatientProfileModel patientProfileModel = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            RxModel rxModel = new RxModel();
            tascoPage.launchTascoScreen();
            tascoPage.launchTascoPseudophedrineScreen();
            tascoPage.clickPatientProfileInPseudophedrine();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            tascoPage.enterIssuer(inputData.get("ISSUER"));
            tascoPage.pressKeys(KeyEvent.VK_TAB);
            tascoPage.clickSubmitIDDetails();
            tascoPage.inputPatientLastName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDobPseudoPherderine(inputData.get("DOB"));
            tascoPage.enterAddress(inputData.get("ADDRESS"));
            tascoPage.enterCity(inputData.get("CITY"));
            tascoPage.entryState(inputData.get("STATE"));
            tascoPage.enterZipCode(inputData.get("ZIP_CODE"));
            tascoPage.enterIdNumber(inputData.get("CARDID"));
            tascoPage.clickNoExpiration();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickAccept();
            tascoPage.clickExitTascoHIPAAPseudophedrine();
            tascoPage.clickExitInTasco();
            tascoPage.clickSignOff();
        }
        catch (Exception  e){
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL,  currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void createPatientAllRequiredFields(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();
        ThirdPartyModel thirdPartyModel = new ThirdPartyModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
        patient.setPatientAddress(addressModel);

        //Primary phone number
        contactModel.setPatientPrimaryNumber(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
        patient.setPatientContact(contactModel);

        thirdPartyModel.setCarrierBin(inputData.get("BIN"));
        thirdPartyModel.setPlan(inputData.get("PLAN"));
        thirdPartyModel.setCardId(inputData.get("CARDID"));

        patient.setPatientTp(thirdPartyModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);

        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(true, patient);
    }

    public void changeTPtoCash(String  RXnumber){
        F6Search search = new F6Search();
        search.performSearch(RXnumber, SearchType.PatientRx);
        search.selectRowFromSearch(0);
        automationManager.performSleep(5);
        modifyDetails.switchWindow();
        automationManager.performSleep(5);
        modifyDetails.clickSwitchtoCash();
        modifyDetails.clickCash();
        modifyDetails.clickAccept();
        if(modifyDetails.isNewTPreasonPopupDisplayed()){
            modifyDetails.enterTPreason("Other");
            automationManager.performSleep(5);
            modifyDetails.enterTPcomment("QE Test");
            automationManager.performSleep(5);
        }else {

            modifyDetails.selectReasonForSwitchToCash();
        }
        automationManager.performSleep(5);
        modifyDetails.clickAccept();
        modifyDetails.checkAndClickWarning();
    }

    public void updateStoreState(Map<String, String> inputData){
        String state = inputData.get("STATE");
        connexusAppUtils.checkCurrentStateAndupdateStoreState(state);
    }


    public void dropAnRxTillEodSwitchToCash(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.DUR.getWorkQueue())) {
            automationManager.performSleep(10);
        }
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
             automationManager.performSleep(10);
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }
        rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                 automationManager.performSleep(10);
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            automationManager.performSleep(10);
        }
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
           // automationManager.performSleep(10);
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }

        changeTPtoCash(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        if("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }
        automationManager.getConnexusWorkFlow().completePickup(name[1],name[0],inputData.get("DOB"),rxNbr);
        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
        automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
        }
    }

    public void dropAnRxTillPos(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                // automationManager.performSleep(10);
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

        if("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())){
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                // automationManager.performSleep(10);
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            automationManager.performSleep(10);
        automationManager.getConnexusWorkFlow().completePickup(name[1],name[0],inputData.get("DOB"),rxNbr);
        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
    } catch (Throwable e) {
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        softAssert.fail(e.toString());
    }
    }

    public void  POS_ModifyCurrentRx_OrderDetails(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
        String[] name = connexusAppUtils.readPatientNameFromFile();
        F6Search search = new F6Search();
        search.performSearch(name[0]+","+name[1], SearchType.PatientRx);
        Reporter.logScreenShot(Status.PASS,  currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        search.selectRowFromSearch(0);
        modifyDetails.clickOrderDetails();
        Reporter.logScreenShot(Status.PASS,  currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        modifyDetails.clickCancel();
        modifyDetails.clickFloatingOkButton();
        modifyDetails.clickYes();
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
        }
    }

    public void csidPickup(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
        TascoPage tascoPage = new TascoPage();
        PatientProfileModel patientProfileModel = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        RxModel rxModel = new RxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        automationManager.performSleep(2);
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr,WorkQueue.PICKUP);
        tascoPage.launchTascoScreen();
        tascoPage.launchTascoPseudophedrineScreen();
        tascoPage.clickPatientProfileInPseudophedrine();
        tascoPage.enterIssuer(inputData.get("ISSUER"));
        tascoPage.clickSubmitIDDetails();
        tascoPage.inputPatientLastName(name[0]);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(name[1]);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDobPseudoPherderine(inputData.get("DOB"));
        tascoPage.enterAddress(inputData.get("ADDRESS"));
        tascoPage.enterCity(inputData.get("CITY"));
        tascoPage.entryState(inputData.get("STATE"));
        tascoPage.enterZipCode(inputData.get("ZIP_CODE"));
        tascoPage.enterIdNumber(inputData.get("CARDID"));
        tascoPage.clickNoExpiration();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickAccept();
        tascoPage.clickExitTascoHIPAAPseudophedrine();
        boolean result = tascoPage.isPatientFirstNameDisplayed();
        if (result) {
            tascoPage.inputPatientLastName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
        } else {
            tascoPage.inputPatientRxnumber(rxNbr);
        }

        tascoPage.pressKeys(KeyEvent.VK_ENTER);
       // tascoPage.clickSearch();
        tascoPage.clickRow(0);
        tascoPage.clickCheckout();
        if(tascoPage.isCashPaypriceDisplayed()){
            Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickPayCashPrice();
        }
        tascoPage.clickOk();
        tascoPage.clickCancelPayCashPrice();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr = "+rxNbr+")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String fillId = rxInfo.get("rx_fill_id").toString();
        System.out.println(fillId);
        String siteId = prop.getProperty("cnx.store");
        tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
        tascoPage.pressTabKey();
        tascoPage.handleCheckoutPopUpForTp();
        automationManager.performSleep(5);
        if(!tascoPage.isAcceptButtonEnabled())
        {
            tascoPage.scanRx("4793" + fillId + "0");
            tascoPage.pressTabKey();
        }
        automationManager.performSleep(5);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickSignOff();
        Reporter.log("CSID pickup Completed");
    } catch (Throwable e) {
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        softAssert.fail(e.toString());
    }
    }

    public void  completeCounselAndEod(){

        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);

        automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
    }

    public void dropAnRxTillBagginSwitchToCash(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
        DropRxModel dropRxModel = new DropRxModel();
        F6Search f6Search = new F6Search();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        changeTPtoCash(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        if("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
        }

    }

    public void pickupCancelpayCash(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String[] name = connexusAppUtils.readPatientNameFromFile();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr,WorkQueue.PICKUP);

        PatientProfileModel patientProfileModel = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        RxModel rxModel = new RxModel();
        tascoPage.launchTascoScreen();
        boolean result = tascoPage.isPatientFirstNameDisplayed();
            if (result) {
                tascoPage.inputPatientLastName(name[1]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientFirstName(name[0]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientDob(inputData.get("DOB"));
                tascoPage.pressTabKey();
                tascoPage.pressTabKey();
            } else {
                tascoPage.inputPatientRxnumber(rxNbr);
            }
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickCheckout();
        if(tascoPage.isCashPaypriceDisplayed()){
            Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickCancelPayCashPrice();
        }
        Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickSignOffButton();
    }

    public void pickupWith2Drug(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        TascoPage tascoPage = new TascoPage();
        PatientProfileModel patientProfileModel = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        RxModel rxModel = new RxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr,WorkQueue.PICKUP);
        automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr1,WorkQueue.PICKUP);

        tascoPage.launchTascoScreen();
        boolean result = tascoPage.isPatientFirstNameDisplayed();
        if (result) {
            tascoPage.inputPatientLastName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
        } else {
            tascoPage.inputPatientRxnumber(rxNbr);
        }
        tascoPage.pressKeys(KeyEvent.VK_ENTER);
        //  tascoPage.clickSearch();
        tascoPage.clickRow(0);
        Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickCheckout();
        tascoPage.clickOk();
        tascoPage.clickCancelPayCashPrice();
        if(tascoPage.isCashPaypriceDisplayed()){
            Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickPayCashPrice();
        }

        String query1 = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr = "+rxNbr+")";
        Map<String, Object> rxInfo  = automationManager.getConnexusDB().executeQuery(query1);
        String fillId =rxInfo.get("rx_fill_id").toString();
        tascoPage.scanRx("4793" + fillId + "0");
        tascoPage.pressTabKey();
        String query2 = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr = "+rxNbr1+")";
        Map<String, Object> rxInfo1  = automationManager.getConnexusDB().executeQuery(query2);
        String fillId1 =rxInfo1.get("rx_fill_id").toString();
        tascoPage.scanRx("4793" + fillId1 + "0");
        tascoPage.pressTabKey();
        Reporter.logScreenShot(Status.PASS,  currentStepMethodName,tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed for 2  RX");
    }

    public void dropOffWith2Drug(String patientName, Priority priority, int noOfRx, String pickupTime){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        automationManager.performSleep(3);
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        automationManager.performSleep(3);
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        automationManager.performSleep(3);
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();

        //2nd RX  :

        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode1 = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode1);
        Reporter.log("New barcode entered " + barCode1);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        automationManager.performSleep(3);
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();
        automationManager.performSleep(1);
        dropOff.addNoOfRx(barCode1, noOfRx);


        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        dropOff.clickBtnAccept();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performInput2ndRX(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        F6Search rxSearch = new F6Search();
        InputPage inputPage = new InputPage();
        rxSearch.performSearch(patientName, SearchType.PatientRx);
        rxSearch.selectRowFromSearch(1);
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.selectDAW(1);
        inputPage.enterPrescriber(prescriberName);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAccept();
        inputPage.sendHotKeys(Keys.ENTER);
        Reporter.log("Input completed for 2nd RX");
    }

    public String performFourPoint2ndRX(String patNameOrRxNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(patNameOrRxNbr,WorkQueue.FOUR_POINT);
        FourPoint fourpoint = new FourPoint();
        F6Search rxSearch = new F6Search();
        rxSearch.performSearch(patNameOrRxNbr, SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        Reporter.log("Rx number is " + rxNbr1);
        while ("DUR".equalsIgnoreCase(rxSearch.getWorkQueue(1))) {
            rxSearch.pressKeys(KeyEvent.VK_F6);
        }
        rxSearch.selectRowFromSearch(1);
        fourpoint.chkName();
        fourpoint.chkPrescribed();
        if (fourpoint.ischkStrength()) {
            fourpoint.chkStrength();
        }
        fourpoint.chkSIG();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        fourpoint.clickAccept();
        Reporter.log("4 point completed");
        ChkDur dur = new ChkDur();
        if (dur.isChkDurOpen()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("CheckDUR " + dur.takeScreenShot("CheckDUR").getKey());
            dur.selectCheckBoxes();
            dur.clickAccept();
        }
        return rxNbr1;
    }

    public void  drop2RXTillBagging(Map<String, String> inputData) {

            String currentStepMethodName = new Object() {
            }.getClass().getEnclosingMethod().getName();
            try{
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();

        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        dropOffWith2Drug(name[0] + "," + name[1], Priority.Critical, 1, "12:30");

        automationManager.performSleep(5);
        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);

        performInput2ndRX(name[0] + "," + name[1], inputData.get("DRUG_NAME"), inputData.get("QUANTITY"), inputData.get("SIG"), inputData.get("REFILLS"), inputData.get("PRESCRIBER_NAME"));

        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        rxNbr1 = performFourPoint2ndRX(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr1);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr1);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr1);
        if ("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr1);
        }
            } catch (Throwable e) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
                loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
                softAssert.fail(e.toString());
            }
    }
}