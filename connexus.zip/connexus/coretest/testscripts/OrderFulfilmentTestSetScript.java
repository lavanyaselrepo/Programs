package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Map;

public class OrderFulfilmentTestSetScript {

    LoginPage loginPage;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    F6Search f6Search;
    RxLookUp rxLookUp;
    MenuBar menuBar;
    TascoPage tascoPage;
    InputPage inputPage;
    FourPoint fourPoint;
    DropOffPage dropOffPage;
    ConnexusStartPage connexusStartPage;
    SoftAssert softAssert;

    public void loginConnexus(LoginAs.userType userType) {
        connexusAppUtils = new ConnexusAppUtils();
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        f6Search = new F6Search();
        softAssert = new SoftAssert();
        rxLookUp = new RxLookUp();
        menuBar = new MenuBar();
        tascoPage = new TascoPage();
        inputPage = new InputPage();
        fourPoint = new FourPoint();
        dropOffPage = new DropOffPage();
        connexusStartPage = new ConnexusStartPage();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method creates a new patient in ptms screen and adds both patient rx in Drop Off Queue in single order
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void createPatientForSplitBag(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);

        contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
        contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientPhoneNumber2(inputData.get("PHONE_NUMBER2"));
        contactModel.setPatientPhoneNumber3(inputData.get("PHONE_NUMBER3"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGE"));
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.ALTERNATE_NUMBER);

        patient.setPatientContact(contactModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);

        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);

        //performs Drop off for the patient
        dropOffPage.clickDropOffQueue();
        automationManager.performSleep(3);
        dropOffPage.passName(name[0] + "," + name[1]);
        dropOffPage.clickPatientSearch();
        dropOffPage.handleAnnualValidatePatInfoPopUp();
        dropOffPage.clickScanNewRx();
        String barCode = dropOffPage.generateRxBarCode();
        dropOffPage.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOffPage.clickBtnAccept();
        dropOffPage.clickVerifyBarCode();
        automationManager.performSleep(3);
        dropOffPage.selectRxOrigin();
        dropOffPage.clickBtnAccept();
        automationManager.performSleep(1);
        dropOffPage.addNoOfRx(barCode, 1);
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method completes drop off and processes Work Queue: Input, 4 point, Check DUR, Filling, Vis Ver,
     * Bagging and moves to Pick Up Queue for 2 rx in Single Order
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void dropRxTillBaggingForSplitBag(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();

        // Clicks on the Rx Information in Order Information Table and gets first Patient name
        dropOffPage.clickRxInformation(0);
        String[] patient1Name = dropOffPage.getEnteredPatientName().split(",");

        // Completes drop off for two different patient in single order
        dropRxModel.setPriority(Priority.Critical);
        dropOffPage.selectPriority(String.valueOf(Priority.Critical));
        if (String.valueOf(Priority.Critical).equalsIgnoreCase(String.valueOf(Priority.Future))) {
            dropOffPage.selectPickupTime("");
        }
        dropOffPage.clickBtnAccept();
        dropOffPage.checkAndClickDropOffStation();
        Reporter.log("Rx for the 2 patient in same order is dropped off");

        rxModel.setPatientLastName(patient1Name[0]);
        rxModel.setPatientFirstName(patient1Name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME1"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        automationManager.performSleep(2);
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);

        String[] patient2Name = connexusAppUtils.readPatientNameFromFile();
        rxModel.setPatientLastName(patient2Name[0]);
        rxModel.setPatientFirstName(patient2Name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME2"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        automationManager.performSleep(2);
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        Reporter.log("Input for both RX is completed");

        automationManager.performSleep(5);
        String rxNbr1 = automationManager.getConnexusWorkFlow().performFourPoint(patient1Name[0] + "," + patient1Name[1]);
        String rxNbr2 = automationManager.getConnexusWorkFlow().performFourPoint(patient2Name[0] + "," + patient2Name[1]);
        Reporter.log("4 point for both RX is completed");

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr1);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr2);
        Reporter.log("Check DUR for both RX is completed");

        if(automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr1, WorkQueue.RESOLVE)){
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr1);
        }
        if(automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr2, WorkQueue.RESOLVE)){
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr2);
        }

        automationManager.performSleep(5);
        // The below Query selects the Order Number from rx_order_detail table for both Rx having same Order Number
        Map<String, Object> orderInfo = automationManager.getConnexusDB().executeQuery("select order_id from rx_order_detail where rx_id in\n" +
                "(select rx_id from rx where rx_nbr = " + rxNbr1 + ")");
        // The below Query selects first Rx number of the order created from order Detail and Rx tables that is present in Filling Work Queue
        Map<String, Object> rxInfo1 = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod left join rx rx \n" +
                "on rx.rx_id=rod.rx_id where rod.next_work_que_code=4 and rod.order_id=" + orderInfo.get("order_id") + "order by order_seq_nbr");
        // The below Query selects second Rx number of the order created from order Detail and Rx tables that is present in Filling Work Queue
        Map<String, Object> rxInfo2 = automationManager.getConnexusDB().executeQuery("select order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod left join rx rx \n" +
                "on rx.rx_id=rod.rx_id where rod.next_work_que_code=4 and rod.order_id=" + orderInfo.get("order_id") + "order by order_seq_nbr desc limit 1");
        if (rxInfo1 != null && StringUtils.isNotNullOrEmpty(rxInfo1.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo1.get("rx_fill_id").toString())
                && rxInfo2 != null && StringUtils.isNotNullOrEmpty(rxInfo2.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo2.get("rx_fill_id").toString())) {
            int toteNbr = connexusAppUtils.getAvailableToteNbr();
            Reporter.log("The Bag Number generated for the Order " + orderInfo.get("order_id") + "is " + toteNbr + " ");
            int res1 = 0;
            int res2 = 0;
            // The below 2 Queries updates tech_of_rec_userid as 'System' in rx_fill table for single order having 2 different rx fill ids in filling queue
            res1 = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo1.get("rx_fill_id"));
            res2 = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo2.get("rx_fill_id"));
            if (res1 > 0 && res2 > 0) {
                // The below 2 Queries updates same bag number for the single order having 2 different rx in rx_order_detail table
                res1 = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo1.get("rx_fill_id"));
                res2 = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo2.get("rx_fill_id"));
                if (res1 > 0 && res2 > 0) {
                    // The below 2 Queries inserts records into rx_fill_activity table for different Rx with different fill ids
                    res1 = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo1.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo1.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    res2 = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo2.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo2.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    if (res1 > 0 && res2 > 0) {
                        // The below 2 Queries completes filling for same order having 2 different rx values
                        automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo1.get("order_id") + "," + rxInfo1.get("order_seq_nbr") + ")", String.class);
                        automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo2.get("order_id") + "," + rxInfo2.get("order_seq_nbr") + ")", String.class);
                    }
                }
            }
        }
        Reporter.log("Filling for both RX is completed");

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr1);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr2);
        Reporter.log("Visual Verify for both RX is completed");

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeBagging(rxNbr1);
        automationManager.getConnexusWorkFlow().completeBagging(rxNbr2);
        Reporter.log("Bagging for both RX is completed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method searches patient by giving patient mandatory details in Tasco page and opens Checkout screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openCheckOutScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            //The below Query selects the first patient rx number present in pick up queue from rx and rx_order_detail tables
            Map<String, Object> rxNumber1 = automationManager.getConnexusDB().executeQuery("select rx_nbr from rx rx, rx_order_detail od where rx.rx_id = od.rx_id and od.status_code=20501 \n" +
                    "and od.next_work_que_code = 6 and od.order_seq_nbr=1 order by rx.rx_nbr desc limit 1");
            f6Search.performSearch(rxNumber1.get("rx_nbr").toString().trim(), SearchType.PatientRx);
            String patientName = f6Search.getPatientName(0);
            String[] patient1Name = patientName.split(",");
            f6Search.closeSearch();
            tascoPage.launchTascoScreen();
            tascoPage.inputPatientLastName(patient1Name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(patient1Name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method selects and check out one rx from order having 2 rx
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void splitBagAndCheckOutOneRx(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            tascoPage.clickRow(0);
            if (tascoPage.isPopUpInfoDisplayed()) {
                tascoPage.clickOk();
            }
            tascoPage.clickRow(2);
            tascoPage.clickCheckout();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method assigns new bag number to checked out rx and splits the bag to two different bag number
     * and moves the order to bagging queue
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void assignBagSplitOrder(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String bagNumber = null;
            while (tascoPage.isAcceptDisplayed()) {
                bagNumber = String.valueOf(connexusAppUtils.getAvailableToteNbr());
                if (tascoPage.getBagNumber() != null) {
                    tascoPage.clearBagNumber();
                    tascoPage.inputBagNumber(bagNumber);
                } else {
                    tascoPage.inputBagNumber(bagNumber);
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
                tascoPage.clickAccept();
                if (tascoPage.isPopUpInfoDisplayed()) {
                    tascoPage.clickOk();
                }
            }
            Reporter.log("The New Bag Number assigned to Rx 1 after Split Bag is : " + bagNumber + "");
            tascoPage.clickExitInTasco();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    /*----------------------------------------------------------------------------------------------------------
     * This method verifies the old and new bag number assigned to 2 rx are different and
     * moves 2 rx to pick up after bagging for 2 rx is completed
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyRxSplitAndCompleteBagging(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patient2Name = connexusAppUtils.readPatientNameFromFile();
            f6Search.performSearch(patient2Name[0] + "," + patient2Name[1], SearchType.PatientRx);
            String oldBagNbr = f6Search.getBagNbr(0);
            String rxNumber2 = f6Search.getRxNbr(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            f6Search.closeSearch();
            automationManager.performSleep(3);
            // The below Query selects order id from rx_order_detail table for assigned old Bag number
            Map<String, Object> orderInfo = automationManager.getConnexusDB().executeQuery("select order_id from rx_order_detail where tote_nbr= " + oldBagNbr);
            // The below Query selects first rx number of the order from rx table using Order id in rx_order_detail table
            Map<String, Object> rxNumber1 = automationManager.getConnexusDB().executeQuery("select rx_nbr from rx where rx_id in \n" +
                    "(select rx_id from rx_order_detail where order_id=" + orderInfo.get("order_id") + "and order_seq_nbr=1)");
            f6Search.performSearch(rxNumber1.get("rx_nbr").toString().trim(), SearchType.PatientRx);
            String newBagNbr = f6Search.getBagNbr(0);
            f6Search.closeSearch();
            automationManager.performSleep(3);
            Assert.assertNotEquals(newBagNbr, oldBagNbr);
            Reporter.log("The Order is split into two bags Bag Number 1: " + newBagNbr + " and Bag Number 2: " + oldBagNbr + " ");
            automationManager.getConnexusWorkFlow().completeBagging(rxNumber1.toString().trim());
            automationManager.getConnexusWorkFlow().completeBagging(rxNumber2);
            Reporter.log("The Bagging for both Rx is completed after split bag");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method takes the rx from pick up queue and opens the rx in rx look up page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterRxIntoRxLookUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            f6Search.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            String rxNumber = f6Search.getRxNbr(0);
            f6Search.closeSearch();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNumber);
            rxLookUp.clickSearch();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method verifies that the Scan Tag Receipt label is enabled for the rx
     * Menu Bar: File -> Print -> Scan Tag Receipt
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyScanTagReceiptEnabled(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (menuBar.verifyScanTagReceiptEnabled()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            }
            menuBar.clickExit();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes the RX look up page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeRxLookUpPage(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            rxLookUp.closeSearch();
            rxLookUp.clickSubmit();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method drops a rx for patient and processes  Dropoff, Input, 4 point, Check DUR, Filling
     * Vis Ver, Bagging and moves the queue to pickup
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void dropRxTillBagging(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();

        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME1"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);

        automationManager.performSleep(5);
        String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

        if(automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.RESOLVE)){
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        Reporter.log("Rx is completed till Bagging");
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method selects the rx created for the patient in Pick up Queue
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyRxInPickUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // The below selects the recently created rx in Pick up Queue from rx and rx_order_detail tables
            Map<String, Object> rxNumber = automationManager.getConnexusDB().executeQuery("select rx_nbr from rx rx, rx_order_detail od where rx.rx_id = od.rx_id and od.status_code=20501 \n" +
                    "and od.next_work_que_code = 6 order by rx.rx_nbr desc limit 1");
            Reporter.log("The RX " + rxNumber + " is present in Pick Up Queue");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

}
