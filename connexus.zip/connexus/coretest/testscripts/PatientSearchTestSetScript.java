package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import java.util.*;


public class PatientSearchTestSetScript extends ConnexusTestScripts {

    public PatientSearchTestSetScript(){
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
    }
    public PatientSearchTestSetScript(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    /**
     * Method to open Patient Search window by pressing the Keyboard shortcut CTRL+SHIFT+P
     * Author: Srinivas(vn50jui)
     * */
    public void openPatientSearchWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(menuBar.validateConnexusWorkSpace());
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.moveToElementAndClick(patientSearchPage.txtPatientName);
           Assert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, "Patient Search window is opened", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("Patient search window not opened");
        }
    }

    /**
     * Method to open DropOff screen by pressing the Keyboard shortcut CTRL+SHIFT+D
     * Author: Srinivas(vn50jui)
     * */
    public void openRxLookUpScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchRxLookUpPage();
            Assert.assertTrue(rxLookUp.isRxLookUpOpened());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a patient and verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPatientAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientName = inputData.get("PATIENT_NAME");
            String patientDOB = inputData.get("PATIENT_DOB");
            String patientPhone = inputData.get("PATIENT_PHONE");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.inputPatientPhone(patientPhone);
            patientSearchPage.clickSearchNow();
            Assert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).replaceAll(", ", ",").equalsIgnoreCase(patientName));
            Assert.assertTrue(patientSearchPage.getPatientDOBFromSearchGrid(0).equalsIgnoreCase(patientDOB));
            Assert.assertTrue(patientSearchPage.getPatientPhoneNumberFromSearchGrid(0).replaceAll("[()\\s-]+", "") .equalsIgnoreCase(patientPhone));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Close the Patient Search window by clicking on close button
     * Author: Srinivas(vn50jui)
     * */
    public void closePatientSearchWindowByClickingOnCloseButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEscapeKey();
            patientSearchPage.clickClose();
            patientSearchPage.clickClosebutton();
        } catch (Exception e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
        }
    }

    /**
     * Method to enter a patient name (that does not exist in current store) and verify if the Search Now button is enabled
     * Click on Search Now button and verify if the empty search results grid is displayed
     * Author: Srinivas(vn50jui)
     * */
    public void enterPatientNameAndVerifyEmptySearchResultsGrid(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientName = inputData.get("PATIENT_NAME");
            patientSearchPage.inputPatientName(patientName);
            softAssert.assertTrue(patientSearchPage.isSearchNowButtonEnabled());
            patientSearchPage.clickSearchNow();
            softAssert.assertFalse(patientSearchPage.isPatientRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter patient details on Patient Search and click on Search Now
     * Verify that search results are found in search grid and compare with the given input details
     * Author: Srinivas(vn50jui)
     * */
    public void verifyAllSearchResultsOnSearchResultsGrid(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientName = inputData.get("PATIENT_NAME");
            String patientDOB = inputData.get("PATIENT_DOB");
            String patientPhone = inputData.get("PATIENT_PHONE");
            String patientAddress = inputData.get("PATIENT_ADDRESS");
            String patientCity = inputData.get("PATIENT_CITY");
            String patientState = inputData.get("PATIENT_STATE");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.inputPatientPhone(patientPhone);
            patientSearchPage.clickSearchNow();
            Assert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Assert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patientName));
            Assert.assertTrue(patientSearchPage.getPatientDOBFromSearchGrid(0).equalsIgnoreCase(patientDOB));
            Assert.assertTrue(patientSearchPage.getPatientAddressFromSearchGrid(0).equalsIgnoreCase(patientAddress));
            Assert.assertTrue(patientSearchPage.getPatientCityFromSearchGrid(0).equalsIgnoreCase(patientCity));
            Assert.assertTrue(patientSearchPage.getPatientStateFromSearchGrid(0).equalsIgnoreCase(patientState));
            Assert.assertTrue(patientSearchPage.getPatientPhoneNumberFromSearchGrid(0).replaceAll("[()\\s-]+", "") .equalsIgnoreCase(patientPhone));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            // softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at verifyAllSearchResultsOnSearchResultsGrid");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether search results grid is cleared on clicking New Search with OK button
     * Author: Srinivas(vn50jui)
     * */
    public void verifySearchResultsClearedOnClickingNewSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.clickNewSearch();
            patientSearchPage.clickOKOnClearSearchDialog();
            softAssert.assertFalse(patientSearchPage.isPatientRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether Patient Maintenance screen is displayed on double clicking on patient search result on Patient Search window
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPMSDisplayedOnDoubleClickingPatientDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            softAssert.assertTrue(patientMaintenancePage.isPatientMaintenanceScreenDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
            if(patientMaintenancePage.isAbandonChangesPopUpDisplayed()){
                patientMaintenancePage.clickYes();
            }
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    /**
     * Method to close Connexus
     **/
    public void closeConnexus(){
        //loginPage.closeAppKeyCombo();
    }

    /**
     * Method to Search for a Patient on Patient Search Window and then create a new patient with Messaging number only
     * Author: Srinivas(vn50jui)
     */
    public void createPatientWithMessagingNumberOnly(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("PATIENT_DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("PATIENT_ADDRESS"));
            addressModel.setPatientCity(inputData.get("PATIENT_CITY"));
            addressModel.setPatientState(inputData.get("PATIENT_STATE"));
            addressModel.setPatientZipCode(inputData.get("PATIENT_ZIP"));
            addressModel.setPatientCountry(inputData.get("PATIENT_COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForNullPhonenumberCheck(false, patient);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a patient and verify if the Phone Number is empty in the search results on Patient Search window
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPatientAndVerifyIfPhoneNumberIsEmpty(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("PATIENT_DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            softAssert.assertEquals(patientSearchPage.getPatientPhoneNumberFromSearchGrid(0), "(null)");
            Reporter.log("Phone Number is empty on the search grid");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a patient and verify whether the address selected as primary address is displayed on search screen
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPrimaryAddressDisplayedOnPatientSearch(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            softAssert.assertEquals(patientSearchPage.getPatientAddressFromSearchGrid(0), inputData.get("PATIENT_ADDRESS"));
            Reporter.log("Patient address displayed on Search Results Grid is Primary Address");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a patient and verify whether last modified details are display when user modified any details on Patient Maintenance
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherModifiedDetailsDisplayedOnPatientSearch(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("PATIENT_DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.clearAddressLine1forPatient();
            patientMaintenancePage.inputAddressLine1(inputData.get("MODIFY_ADDRESS"));
            patientMaintenancePage.clickSaveAndClose();
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()){
                patientMaintenancePage.clickSaveAsEntered();
            }
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientAddressFromSearchGrid(0).equalsIgnoreCase(inputData.get("MODIFY_ADDRESS")));
            Reporter.log("Patient address displayed on Search Results Grid is a Modified Address");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether the user able not able to see RX number field without entering Name
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherRxNbrAndStoreNbrTextFieldIsNotDisplayedOnPatientSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            softAssert.assertFalse(patientSearchPage.isStoreNbrTextFieldDisplayed());
            softAssert.assertFalse(patientSearchPage.isRxNbrTextFieldDisplayed());
            Reporter.log("Store number and RX Number text fields are not displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether the user able able to see RX number field after searching for a patient
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherRxNbrAndStoreNbrTextFieldIsDisplayedOnPatientSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.isStoreNbrTextFieldDisplayed());
            softAssert.assertTrue(patientSearchPage.isRxNbrTextFieldDisplayed());
            Reporter.log("Store number and RX Number text fields are displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether "Please use the following format "MM/DD/YYYY"pop up box message should be displayed when enter DD/MM/YYYY format at DOB field
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherInvalidDOBPopUpDisplayedWhenSearchedWithInvalidDate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(inputData.get("INVALID_DOB"));
            patientSearchPage.clickSearchNow();
            Assert.assertTrue(patientSearchPage.isErrorPopUpDisplayed());
            Reporter.log("Invalid Date \"MM/DD/YYYY\" pop up message is displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickOKOnErrorPopUp();
            patientSearchPage.clearTextInDOBforPatient();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("Invalida DOB pop up not displayed");
        }
    }

    /**
     * Method to Search for a Patient on Patient Search Window and then create a new patient with Primary Number
     * Author: Srinivas(vn50jui)
     */
    public void createPatientWithPrimaryPhoneNumber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("PATIENT_DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("PATIENT_ADDRESS"));
            addressModel.setPatientCity(inputData.get("PATIENT_CITY"));
            addressModel.setPatientState(inputData.get("PATIENT_STATE"));
            addressModel.setPatientZipCode(inputData.get("PATIENT_ZIP"));
            addressModel.setPatientCountry(inputData.get("PATIENT_COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatientForNullPhonenumberCheck(false, patient);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("Patient not created");
        }
    }

    /**
     * Method to verify whether Patient Search window is displayed
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPatientSearchWindowDisplayed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("patient search window not displayed");
        }
    }

    /**
     * Method to verify whether error popup displayed if the user enter alphabets in phone number field
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherInvalidPhoneNumberFormatPopUpDisplayedWhenSearchedWithAlphabets(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientPhone(inputData.get("PATIENT_PHONE"));
            patientSearchPage.clickSearchNow();
            Assert.assertTrue(patientSearchPage.isErrorPopUpDisplayed());
            Reporter.log("Invalid Phone Number Format pop up message is displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickOKOnErrorPopUp();
            patientSearchPage.clearTextInPhone();
            patientSearchPage.clickSearchNow();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether Store Number and RX Number text fields allows only numbers but not alphabets
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherStoreNumberAndRXNumberFieldsAllowsOnlyNumbers(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.inputStoreNumber(inputData.get("STORE_NUMBER"));
            patientSearchPage.inputRXNumber(inputData.get("RX_NUMBER"));
            Assert.assertTrue(patientSearchPage.getStoreNumberTextValue().isEmpty());
            Assert.assertTrue(patientSearchPage.getRXNumberTextValue().isEmpty());
            Reporter.log("Store Number and RX Number text fields are not allowing alphabets");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether Store Number text field allows only 5 digits
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherStoreNumberAllowsGreaterThan5Digits(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            //Enter a store number which is having greater than 5 digits
            patientSearchPage.inputStoreNumber(inputData.get("STORE_NUMBER"));
            patientSearchPage.clickSearchNow();
            softAssert.assertEquals(patientSearchPage.getStoreNumberTextValue().length(), 5);
            Reporter.log("Store Number text field allowed only 5 digits");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether RX Number text field allows only 10 digits
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherRXNumberAllowsGreaterThan10Digits(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            //Enter a RX Number which is having greater than 10 digits
            patientSearchPage.inputRXNumber(inputData.get("RX_NUMBER"));
            patientSearchPage.clickSearchNow();
            softAssert.assertEquals(patientSearchPage.getRXNumberTextValue().length(), 10);
            Reporter.log("RX Number text field allowed only 10 digits");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether Patient Search window opens on clicking Find button (3 dots) in DropOff screen
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPatientSearchOpensOnClickingFindButtonInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickPatientSearch();
            softAssert.assertTrue(patientSearchPage.isPatientSearchWindowDisplayed());
            Reporter.log("Patient Search window opened from DropOff screen on clicking find button");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickClose();
            dropOffPage.clickBtnCancel();
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    /**
     * Method to verify whether the Patient details displayed on clicking the patient search button from RX lookup Screen
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPatientDetailsDisplayedOnRxLookUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            rxLookUp.clickSearch();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            softAssert.assertTrue(rxLookUp.getPatientNameFromRxLookUp().replaceAll(" ","").equalsIgnoreCase(patientName));
            Reporter.log("Patient details displayed on clicking the patient search button from RX lookup Screen.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickClosebuttonInCaeErrorPopUp();
            patientSearchPage.clickClosebutton();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("Patient details not loaded");
        }
    }

    /**
     * Method to verify whether the user able to Search for Patient with Special Characters except( , . )
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPatientSearchAllowsSpecialCharacters(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.inputPatientName(inputData.get("PATIENT_NAME"));
            softAssert.assertTrue("(),.".equalsIgnoreCase(patientSearchPage.getValueFromName()));
            Reporter.log("Patient Search allows only (),. characters");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether the user able to search for a patient with maximum characters in Name
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherUserAbleToSearchForAPatientNameWithMaximumCharacters(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.inputPatientName(inputData.get("PATIENT_NAME"));
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getValueFromName().length() > 100);
            Reporter.log("User is able to search for a patient with maximum characters in Name");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    /**
     * Method to verify if the Patient Search Window is closed when the user pressed ESC button
     * Author: Srinivas(vn50jui)
     * */
    public void closePatientSearchWindowsByPressingEscapeButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.closePatientSearchWindowsByPressingEscButton();
            Reporter.log("User is able to close the Patient Search window by pressing ESC button in keyboard");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a patient which is created by a previous method and verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPatientOnFileAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("PATIENT_DOB");
            String patientPhone = inputData.get("PATIENT_PHONE");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.inputPatientPhone(patientPhone);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).replaceAll(", ", ",") .equalsIgnoreCase(patientName));
            softAssert.assertTrue(patientSearchPage.getPatientDOBFromSearchGrid(0).equalsIgnoreCase(patientDOB));
            softAssert.assertTrue(patientSearchPage.getPatientPhoneNumberFromSearchGrid(0).replaceAll("[()\\s-]+", "") .equalsIgnoreCase(patientPhone));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether No Records Found pop up is displayed when patient not found on Searching with Name and DOB
     * Author: Srinivas(vn50jui)
     * */
    public void verifyNoRecordsFoundPopUpWhenNoResultsFound(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientName =  inputData.get("PATIENT_NAME");
            String patientDOB = inputData.get("PATIENT_DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.clickSearchHost();
            softAssert.assertTrue(patientSearchPage.isNoMatchingResultsFoundPopUpDisplayed());
            Reporter.log("Popup displayed with No Records Found message is displayed when patient not found on Searching with Name and DOB");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickOKOnErrorPopUp();
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether No Records Found popup is displayed when no record found on searching with Store and RX number
     * Author: Srinivas(vn50jui)
     * */
    public void verifyNoRecordsFoundPopUpWhenNoResultsFoundWithStoreAndRX(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientName = inputData.get("PATIENT_NAME");
            String storeNumber = inputData.get("STORE_NUMBER");
            String rxNumber = inputData.get("RX_NUMBER");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.inputStoreNumber(storeNumber);
            patientSearchPage.inputRXNumber(rxNumber);
            patientSearchPage.clickSearchNow();
            patientSearchPage.clickSearchHost();
            softAssert.assertTrue(patientSearchPage.isNoMatchingResultsFoundPopUpDisplayed());
            Reporter.log("Popup displayed with No Records Found message is displayed when patient not found on Searching with Name and DOB");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickOKOnErrorPopUp();
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify search history in Name text field on Patient Search
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPatientNameSearchHistory(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            do {
                patientSearchPage.pressDownArrowKeyInProductName();
            } while (!patientName.equalsIgnoreCase(patientSearchPage.getValueFromName()));
            softAssert.assertTrue(patientSearchPage.getValueFromName().equalsIgnoreCase(patientName));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    //Nanthini

    public void addAdditionalMedications(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTabProfile();
            patientMaintenancePage.clickOtherMedication();
            enterProductforMedications(inputData);
            patientMaintenancePage.inputStartDate(inputData.get("INVALID_STARTDATE"));
            patientMaintenancePage.inputEndDate(inputData.get("INVALID_ENDDATE"));
            patientMaintenancePage.clickAddMedicationButton();
            Assert.assertTrue(patientMaintenancePage.isinvalidStartdatePopupDisplayed());
            Reporter.logScreenShot(Status.PASS, "validation popup displayed for entering invalid start Date", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.closeStartDatePopUp();
            patientMaintenancePage.clickACancelMedicationButton();
            enterProductforMedications(inputData);
            patientMaintenancePage.inputStartDate(inputData.get("INVALID_STARTDATE1"));
            patientMaintenancePage.inputEndDate(inputData.get("INVALID_ENDDATE1"));
            patientMaintenancePage.clickAddMedicationButton();
            Assert.assertTrue(patientMaintenancePage.isinvalidEnddatePopupDisplayed());
            Reporter.logScreenShot(Status.PASS, "validation popup displayed for entering invalid end Date", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.closeStartDatePopUp();
            patientMaintenancePage.clickACancelMedicationButton();
            enterProductforMedications(inputData);
            patientMaintenancePage.inputStartDate(inputData.get("VALID_STARTDATE"));
            patientMaintenancePage.inputEndDate(inputData.get("VALID_ENDDATE"));
            patientMaintenancePage.clickAddMedicationButton();
            Assert.assertTrue(patientMaintenancePage.isAMedicatiionRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, "Medication is added for Patient", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickAcceptMedication();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            Reporter.log("Medication details are saved and PMS screen is closed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void enterProductforMedications(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.enterMedicationName(inputData.get("PRODUCT_NAME"));
            productSearchPage.clickSearchNow();
            productSearchPage.doubleClickOnSearchGridRow(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void addPatienTPreference(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            Assert.assertTrue(patientMaintenancePage.isPatientMaintenanceScreenDisplayed());
            patientMaintenancePage.clickPatientDAW();
            Reporter.logScreenShot(Status.PASS, "Patient Preference is selected", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }


    public void openRXinInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(menuBar.validateConnexusWorkSpace());
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0]+ ","+name[1]);
            patientSearchPage.openFirstPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(orderSearch.isInputPageDisplayed());
            Assert.assertTrue(inputPage.patientPreferText());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Prefers Brand (DAW-2) is displayed on Input Screen ");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void closeInputScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.exitInputScreen();
            inputPage.clickYesOnAbondonPopup();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }



    public void openPatientRecord(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(menuBar.validateConnexusWorkSpace());
            patientSearchPage.launchPatientSearchScreen();
            Assert.assertTrue(patientSearchPage.verifyPatientSearchScreen());
            Reporter.logScreenShot(Status.PASS, "Patient Search window is opened", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            Reporter.log("Patient Record is opened");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void openAllergyMedicalConditions(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAllergyMedicalTab();
            String allergyToBeAdded = inputData.get("ALLERGY");
            patientMaintenancePage.addAllergy(allergyToBeAdded);
            Reporter.logScreenShot(Status.PASS, "Added Allergy", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.addMedicalCondition();
            patientMaintenancePage.clickAddMedicalConditionbtn();
            Assert.assertTrue(patientMaintenancePage.isMedicaconditionNameDisplayed(0));
            Assert.assertTrue(patientMaintenancePage.isMedicalCondtionAddedDateDisplayed(0));
            Reporter.logScreenShot(Status.PASS, "Added Medical Conditon", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void deActivateMedicalConditions(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAllergyMedicalTab();
            String deActivateMedicalCondition = inputData.get("Reason");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.addReasonforDeactivation(deActivateMedicalCondition);
            Reporter.logScreenShot(Status.PASS, "Deactivated Medical condition", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
        }
    }

    public void addMiscPersonalInfo(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTabProfile();
            patientMaintenancePage.enterEthnicity();
            patientMaintenancePage.enterRace();
            patientMaintenancePage.enterMaidenName(inputData.get("MAIDEN_NAME"));
            Reporter.logScreenShot(Status.PASS, "Adding Misc Personal Info", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());

        }
    }

    public void addPrimaryPrescriber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTabProfile();
            patientMaintenancePage.clickProductSearch3Dots();
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, "Prescriber record is displayed", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.doubleClickOnSearchGridRow(0);
            Reporter.logScreenShot(Status.PASS, "added Primary Prescriber details", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(patientMaintenancePage.isSaveEnabled());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void selectNoPrescriber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTabProfile();
            Reporter.logScreenShot(Status.PASS, "Navigated to Profile/Other Tab", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.checkPrescriberNone();
            Assert.assertEquals(patientMaintenancePage.getTextfromPrescriberName(),"");
            Assert.assertEquals(patientMaintenancePage.getTextfromPrescriberAddress(),"");
            Reporter.logScreenShot(Status.PASS, "clicked checkbox for Selecting None", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public  void verifyEthnicityDropdown(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTabProfile();
            Reporter.logScreenShot(Status.PASS, "Navigated to Profile/Other Tab", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            List<String> ethnicityDropdownList = new ArrayList<>(patientMaintenancePage.getEthnicityValues());
            List<String> ethnicityDropdownValues = new ArrayList<>(ethnicityDropdownList);
            Collections.sort(ethnicityDropdownValues);
            Reporter.log("ethnicityDropdownValues:"+ ethnicityDropdownValues);
            System.out.println(ethnicityDropdownValues);

            List<String> RaceDropdownList = new ArrayList<>(patientMaintenancePage.getRaceValues());
            List<String> raceDropdownValues = new ArrayList<>(RaceDropdownList);
            Collections.sort(RaceDropdownList);
            Reporter.log("RaceDropdownList:"+ RaceDropdownList);
            System.out.println(RaceDropdownList);
            Reporter.logScreenShot(Status.PASS, "Verified List of Values for Ethnicity and Race", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,  patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public boolean clickOnMailingAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickMailingAddressTab();
            Reporter.logScreenShot(Status.PASS, "clicked Mailing Address Tab", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        return false;
    }

    public Boolean selectMailingAddressAsPrimary(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS_LINE_1"));
            patientMaintenancePage.inputCity(inputData.get("CITY"));
            patientMaintenancePage.selectState(inputData.get("STATE"));
            patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.selectCountry(inputData.get("COUNTRY"));
            Assert.assertTrue(patientMaintenancePage.checkSetAsPrimaryMailing());
            Reporter.logScreenShot(Status.PASS, "Selected Mailing address as Primary Address", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        return false;
    }

    public boolean clickOnTemporaryAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTemporaryAddressTab();
            Reporter.logScreenShot(Status.PASS, "clicked on Temporary Address Tab", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        return false;
    }

    public boolean selectTempAddressAsPrimary(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS_LINE_1"));
            patientMaintenancePage.inputCity(inputData.get("CITY"));
            patientMaintenancePage.selectState(inputData.get("STATE"));
            patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.selectCountry(inputData.get("COUNTRY"));
            Assert.assertTrue(patientMaintenancePage.checkSetAsPrimaryTemp());
            Reporter.logScreenShot(Status.PASS, "Selected Temp Address as a Primary address", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return false;
    }

    public void addSecondaryThirdPartyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(patientMaintenancePage.isBtnTpEnabled());
            String patCarrier = inputData.get("TP_CARRIER_BIN");
            String patPlan = inputData.get("TP_PLAN");
            String patCardId = inputData.get("TP_CARD_ID");
            patientMaintenancePage.addAdditionalTPPlan(patCarrier, patPlan, patCardId);
            Reporter.logScreenShot(Status.PASS, "Added Third party Details", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void unCheckTPEligibility() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.unCheckEligible();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.closeThirdPartyWindow();
            patientMaintenancePage.clickSaveAndClose();
            Assert.assertTrue(menuBar.validateConnexusWorkSpace());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void checkCashPaymentMethodInPickup(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            Assert.assertEquals(modifyDetails.getPaymentText(),"CASH");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Payment method is Cash");
            modifyDetails.clickAccept();
            orderSearch.isConnexusPopUpDisplayed();
            orderSearch.clickOk();
            if(orderSearch.isConnexusPopUpDisplayed()){
            orderSearch.clickOk();}
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void logStoreNumberandState(){
        int siteId;
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
         String stateId = propertyReader.getProperty("cnx.state");
        Reporter.log(" Logged Store Id : " + siteId +  "and " + "State : " + stateId);
    }

}