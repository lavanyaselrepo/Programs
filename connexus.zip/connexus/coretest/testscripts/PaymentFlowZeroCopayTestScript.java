package connexus.coretest.testscripts;


import com.aventstack.extentreports.Status;
import connexus.OrderCreation.PayloadResource;
import connexus.coretest.testcases.PaymentFlowZeroCopay;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class PaymentFlowZeroCopayTestScript {
    HashMap<String, String> headers = new HashMap<>();
    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    TascoPage tascoPage;
    PatientMaintenancePage patientMaintenancePage;
    DropOffPage dropOffPage;
    F6Search orderSearch;
    FourPoint fourPoint;
    InputPage inputPage;
    RxLookUp rxLookUp;
    ModifyDetails modifyDetails;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    DropRxModel dropRxModel;
    RxModel rxModel;
    SoftAssert softAssert = new SoftAssert();
    PayloadResource payloadResource = new PayloadResource();
    String rxNbr = null;
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
    F6Search rxSearch;


    private String rxNbr1;
    public  PaymentFlowZeroCopayTestScript() {
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
        int siteId;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        prop.loadCustomProperties("config/connexus/");
    }
    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        tascoPage = new TascoPage();
        patientMaintenancePage = new PatientMaintenancePage();
        dropOffPage = new DropOffPage();
        orderSearch = new F6Search();
        fourPoint = new FourPoint();
        inputPage = new InputPage();
        modifyDetails = new ModifyDetails();
        connexusAppUtils = new ConnexusAppUtils();
        dropRxModel = new DropRxModel();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        automationManager = AutomationManager.getInstance();
        rxSearch = new F6Search();
        loginPage.loginConnexus(userType);
    }

    public void performCounselling(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())){
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            }
            else{
                Reporter.log("RX is not in Counselling queue");
                Assert.fail();
            }
        }catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyRxInPickUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // The below selects the recently created rx in Pick up Queue from rx and rx_order_detail tables
            Map<String, Object> rxNumber = automationManager.getConnexusDB().executeQuery("select rx_nbr from rx rx, rx_order_detail od where rx.rx_id = od.rx_id and od.status_code=20501 \n" +
                    "and od.next_work_que_code = 6 order by rx.rx_nbr desc limit 1");
            Reporter.log("The RX " + rxNumber + " is present in Pick Up Queue");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void drop2RXTillVisualVerify(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        dropOffWith2Drug(name[0] + "," + name[1], Priority.Critical, 1, "12:30");

        automationManager.performSleep(2);
        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("PRODUCT_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);

        performInput2ndRX(name[0] + "," + name[1], inputData.get("PRODUCT_NAME"), inputData.get("QUANTITY"), inputData.get("SIG"), inputData.get("REFILLS"), inputData.get("PRESCRIBER_NAME"));

        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        String rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        String rxStatus2 = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 1);
        automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
        this.performFourPoint2ndRX(name[0] + "," + name[1]);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr1);
        automationManager.performSleep(5);
        this.completeFillingFor1rx();
        this.completeFillingFor2rx(rxNbr1);
        automationManager.performSleep(5);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr1);

    }
    public void dropOffWith2Drug(String patientName, Priority priority, int noOfRx, String pickupTime) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        automationManager.performSleep(3);
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        automationManager.performSleep(3);
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        automationManager.performSleep(3);
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();

        //2nd RX  :

        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode1 = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode1);
        Reporter.log("New barcode entered " + barCode1);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        automationManager.performSleep(3);
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();
        automationManager.performSleep(1);
        dropOff.addNoOfRx(barCode1, noOfRx);


        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        dropOff.clickBtnAccept();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performInput2ndRX(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        F6Search rxSearch = new F6Search();
        InputPage inputPage = new InputPage();
        rxSearch.performSearch(patientName, SearchType.PatientRx);
        rxSearch.selectRowFromSearch(1);
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.selectDAW(1);
        inputPage.enterPrescriber(prescriberName);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAccept();
        inputPage.pressKeys(KeyEvent.VK_ENTER);
        Reporter.log("Input completed for 2nd RX");
    }

    public String performFourPoint2ndRX(String patNameOrRxNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(patNameOrRxNbr, WorkQueue.FOUR_POINT);
        FourPoint fourpoint = new FourPoint();
        F6Search rxSearch = new F6Search();
        rxSearch.performSearch(patNameOrRxNbr, SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        Reporter.log("Rx number is " + rxNbr1);
        while ("DUR".equalsIgnoreCase(rxSearch.getWorkQueue(1))) {
            rxSearch.pressKeys(KeyEvent.VK_F6);
        }
        rxSearch.selectRowFromSearch(1);
        fourpoint.chkName();
        fourpoint.chkPrescribed();
        if (fourpoint.ischkStrength()) {
            fourpoint.chkStrength();
        }
        fourpoint.chkSIG();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        fourpoint.clickAccept();
        Reporter.log("4 point completed");
        ChkDur dur = new ChkDur();
        if (dur.isChkDurOpen()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("CheckDUR " + dur.takeScreenShot("CheckDUR").getKey());
            dur.selectCheckBoxes();
            dur.clickAccept();
        }
        return rxNbr1;
    }

    public boolean completeFillingFor1rx() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=4 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo.get("rx_fill_id").toString())) {
            int toteNbr = connexusAppUtils.getAvailableToteNbr();
            int res = 0;
            res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo.get("rx_fill_id"));
            if (res > 0) {
                res = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo.get("rx_fill_id"));
                if (res > 0) {
                    res = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    if (res > 0) {
                        String retVal = automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ")", String.class);

                    }
                    res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set patient_due_amt = \"0\" where rx_fill_id =" + rxInfo.get("rx_fill_id") );
                }
            }
        }

        return false;

    }
    public boolean completeFillingFor2rx(String rxNbr) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(1);

        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=4 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo.get("rx_fill_id").toString())) {
            int toteNbr = connexusAppUtils.getAvailableToteNbr();
            int res = 0;
            res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo.get("rx_fill_id"));
            if (res > 0) {
                res = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo.get("rx_fill_id"));
                if (res > 0) {
                    res = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    if (res > 0) {
                        String retVal = automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ")", String.class);

                    }
                    res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set patient_due_amt = \"0\" where rx_fill_id =" + rxInfo.get("rx_fill_id") );
                }
            }
        }

        return false;


    }


    public void performDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("PRODUCT_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0]+","+name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void perform4Point() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void workQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        F6Search rxSearch = new F6Search();
        boolean isInQueue = false;
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.openSearch();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            for (int i = 0; i < 4; i++) {
                if (rxSearch.getWorkQueue(0).replace(" ", "").equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                    isInQueue = true;
                    break;
                } else {
                    Assert.fail("Rx not in 4point");
                }
            }
            rxSearch.closeSearch();
        } catch (Exception e) {
            Reporter.log("Test failed rx not in 4point");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void performChkDUR() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performFilling() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        Map<String, Object> rx_id = automationManager.getConnexusDB().executeQuery("select rx_id from rx where rx_nbr=" + rxNbr);
        Map<String, Object> rx_fill_id = automationManager.getConnexusDB().executeQuery("select rx_fill_id from rx_fill where rx_id =" + rx_id);
        Map<String, Object> rxInfo1 = automationManager.getConnexusDB().executeQuery("update rx_fill set patient_due_amt = 0 where rx_fill_id =" + rx_fill_id );
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=4 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo.get("rx_fill_id").toString())) {
            int toteNbr = connexusAppUtils.getAvailableToteNbr();
            int res = 0;
            res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo.get("rx_fill_id"));
            if (res > 0) {
                res = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo.get("rx_fill_id"));
                if (res > 0) {
                    res = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    if (res > 0) {
                        String retVal = automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ")", String.class);

                    }
                }
            }
        }

    }

    public void performVisualVerify() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performPickUp(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())){
                automationManager.getConnexusWorkFlow().completePickup(name[1],name[0],inputData.get("DOB"),rxNbr);
            }
            else{
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        }catch (Exception e) {
            Reporter.log("Test failed at PickUp queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performPOS() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
            } else {
                Reporter.log("RX is not in POS queue");
                Assert.fail("RX is not in POS queue");
            }
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            System.out.println(name[1] + "," + name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.getConnexusWorkFlow().createNewPatient(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }

        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createNewPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

            Reporter.log("Patient has been created.");
        } catch (Throwable e) {
            loginConnexus(PaymentFlowZeroCopay.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createNewPatientWith2TPPlans(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            thirdPartyModel.setCarrierBin2(inputData.get("TP_CARRIER_BIN_2"));
            thirdPartyModel.setPlan2(inputData.get("TP_PLAN_2"));
            thirdPartyModel.setCardId2(inputData.get("TP_CARD_ID_2"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

            Reporter.log("Patient has been created.");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropOffForARXWithNoRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            softAssert.assertTrue(dropOffPage.getTextFromRefillRequestPopup().contains("The Prescription is Out Of Refills"));
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            softAssert.assertTrue(dropOffPage.isFaxSendPopUpDisplayed());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropOffForRXWithRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.checkAndClickDropOffStation();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyIfRxIsInResolutionQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            softAssert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue());
            softAssert.assertEquals(orderSearch.getProblemMessage(0), "Need to Call Doctor for Refills");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            orderSearch.closeSearch();
            Reporter.log("RX is in Resolution Queue");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void switchToCASHFromTP() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                modifyDetails.selectClaimsDropDown();
                modifyDetails.clickCash();
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                modifyDetails.OkWarningClick();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being reprocessed");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Visual verify queue");
                Assert.fail("RX is not in Visual verify queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void switchToTPFromTP(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                automationManager.performSleep(5);
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                System.out.println("Plan name " + planName);
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Filling queue");
                Assert.fail("RX is not in Filling queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(WorkQueue workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            orderSearch.performSearch(rxNbr, SearchType.PatientRx);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                Reporter.log("RX is in Visual Verify queue");
            } else {
                Reporter.log("RX is in Visual Verify queue");
                Assert.fail("RX is in Visual Verify queue");
            }
        } catch (Exception e) {
            Reporter.log("RX is in Visual Verify queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(String workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            F6Search search = new F6Search();
            automationManager.performSleep(2);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = search.getRXStatus(name[0] + "," + name[1]);
            if (rxStatus.equalsIgnoreCase(workQueue)) {
                Assert.assertTrue(true, "Workqueue Matched");
            } else {

                Assert.fail("Workqueue not Matched, current work queue is " + rxStatus);
            }
        } catch (Exception e) {
            softAssert.fail(workQueue + " " + "not matched");
            Reporter.log(workQueue + " " + "not matched");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

}