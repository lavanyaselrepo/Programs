package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.openqa.selenium.Keys;
import org.testng.Assert;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegressionTestSetScript extends ConnexusTestScripts {

     /*----------------------------------------------------------------------------------------------------------

     * The below method navigates to Resolution Settings and validates if the resolution options are enabled
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/

    public void navigateToResolutionSettingsAndValidateResolutionOptions(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.openResolutionSettingsFromMenu();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(menuBar.validateTpCheckBoxInResolutionSettings());
            Assert.assertTrue(menuBar.validateContactCustomerInResolutionSettings());
            Assert.assertTrue(menuBar.validateContactPrescriberInResolutionSettings());
            Assert.assertTrue(menuBar.validateAllOtherInResolutionSettings());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------

    * The below method validates the field sig whether it accepts numerical, special characters or description of length 255 characters
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateExtendedSig(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(patientName);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String actual = inputData.get("TEXT_TO_COMPARE");
            String[] data = actual.split(";");
            String numericalValue = data[0];
            String specialCharacters = data[1];
            String description = data[2];
            String descriptionModified = data[3];
            int count = Integer.parseInt(inputData.get("CHARACTER_COUNT"));
            String regex = "[0-9]+";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(numericalValue);
            Assert.assertTrue(m.matches());
            Reporter.log("Numerical value is verified");
            inputPage.inputExpandedSig(numericalValue);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.sendHotKeys(Keys.TAB);
            inputPage.clearExtendedSig();
            String specialCharacterRegex = "[^a-zA-Z0-9]+";
            Pattern q = Pattern.compile(specialCharacterRegex);
            Matcher n = p.matcher(numericalValue);
            Assert.assertTrue(m.matches());
            Reporter.log("Special characters are verified");
            inputPage.inputExpandedSig(specialCharacters);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.sendHotKeys(Keys.TAB);
            inputPage.clearExtendedSig();
            Assert.assertEquals(description.length(), count);
            Reporter.log("Description with length 255 is verified");
            Reporter.log("Description with length " + descriptionModified.length() + " is being entered");
            inputPage.inputExpandedSig(description);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.sendHotKeys(Keys.TAB);
            inputPage.clearExtendedSig();
            inputPage.inputExpandedSig(descriptionModified);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            int actiualLength = inputPage.getExtendedSigDescription().length();
            Assert.assertNotEquals(descriptionModified.length(), actiualLength);
            inputPage.exitInputScreen();

        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------

        * The below method validates all the priority options with respective to their Date or Read By times field whether they are enabled or
        * change in minutes of Read By time generated according to the Priority option selected
        * Author: Tarun(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    public void validatePriority(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String priority = inputData.get("TEXT_NOTE");
            String timeVal = inputData.get("TIME_VALIDATION");
            String[] priorityList = priority.split(";");
            String[] timeValidation = timeVal.split(";");
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickScanNewRx();
            dropOffPage.switchWindow();
            String barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            dropOffPage.clickBtnAccept();
            dropOffPage.switchWindow();
            dropOffPage.clickVerifyBarCode();
            dropOffPage.selectRxOrigin();
            dropOffPage.clickBtnAccept();
            dropOffPage.addNoOfRx(barCode, 1);
            dropOffPage.selectPriority(priorityList[0]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(priorityList[0], dropOffPage.getSelectedPriority());
            String inStoreExpectedTime = dropOffPage.getTimeInStore("h:mm a", Integer.parseInt(timeValidation[0]));
            System.out.println("inStoreExpectedTime :" +inStoreExpectedTime );
            Assert.assertEquals(dropOffPage.getReadyByTimeInStore(), inStoreExpectedTime);
            dropOffPage.selectPriority(priorityList[1]);
            Assert.assertEquals(priorityList[1], dropOffPage.getSelectedPriority());
            Assert.assertTrue(dropOffPage.validateReadyByFieldEnabled());
            dropOffPage.selectReadyByTimeToday();
            Assert.assertNotNull(dropOffPage.getReadyByTime());
            dropOffPage.selectPriority(priorityList[2]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(priorityList[2], dropOffPage.getSelectedPriority());
            String drCalllInExpectedTime = dropOffPage.getTimeDrCallIn("h:mm a", Integer.parseInt(timeValidation[2]));
            Assert.assertEquals(dropOffPage.getReadyByTimeDrCallIn(), drCalllInExpectedTime);
            dropOffPage.selectPriority(priorityList[4]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(priorityList[4], dropOffPage.getSelectedPriority());
            Assert.assertTrue(dropOffPage.validateReadyByFieldEnabled());
            Assert.assertTrue(dropOffPage.validateDateFieldEnabled());
            String date = DateFormat.MMddYYYY.toString();
            String dateFormat = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4);
            dropOffPage.inputDate(dropOffPage.getFutureDate(dateFormat, Integer.parseInt(timeValidation[4])));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.selectReadyByTimeFuture();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String FutureTime = dropOffPage.getTimeFuture("h:mm a", Integer.parseInt(timeValidation[5]));
            Assert.assertEquals(dropOffPage.getReadyByTimeFuture(), FutureTime);
            dropOffPage.selectPriority(priorityList[5]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(priorityList[5], dropOffPage.getSelectedPriority());
            String criticalExpectedTime = dropOffPage.getTimeCritical("h:mm a", Integer.parseInt(timeValidation[5]));
            Assert.assertEquals(dropOffPage.getReadyByTimeCritical(), criticalExpectedTime);
            dropOffPage.clickBtnCancel();
            dropOffPage.clickYesInPopUp();

        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    enum DateFormat {
        MMddYYYY
    }
}
