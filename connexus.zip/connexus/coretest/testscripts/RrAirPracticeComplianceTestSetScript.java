package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.*;

public class RrAirPracticeComplianceTestSetScript extends ConnexusTestScripts {

    public RrAirPracticeComplianceTestSetScript(LoginAs.userType loginUserType) {
        super(loginUserType);
        connexusAppUtils = new ConnexusAppUtils();
        dropRxModel = new DropRxModel();
        automationManager = AutomationManager.getInstance();
    }

    public void openTascoScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.launchTascoScreen();
            tascoPage.switchWindow();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateText(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String lblRequired = tascoPage.getTextFromTascoSearchRequirementsMessage();
            Assert.assertEquals(inputData.get("TEXT_TO_COMPARE"), lblRequired.trim());
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickCancelPayCashPrice();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateCheckBoxEnabledLastName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.inputPatientLastName(inputData.get("LAST_NAME_2"));
            if (tascoPage.getFnLnChkBoxCompleteValue().equals("Last Name is  \n" +
                    "Complete") || "Last Name is Complete".equals(tascoPage.getFnLnChkBoxCompleteValue())) {
                Assert.assertTrue(tascoPage.validateCheckBoxField());
                Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.assertTrue(tascoPage.validateCheckBoxField());
                Reporter.logScreenShot(Status.INFO, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateCheckBoxDisabledLastName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            Assert.assertFalse(tascoPage.validateCheckBoxField());
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateCheckBoxEnabledFirstName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("FIRST_NAME_2"));
            if (tascoPage.getFnLnChkBoxCompleteValue().equals("First Name is  \n" +
                    "Complete") || "First Name is Complete".equals(tascoPage.getFnLnChkBoxCompleteValue())) {
                Assert.assertTrue(tascoPage.validateCheckBoxField());
                Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.assertTrue(tascoPage.validateCheckBoxField());
                Reporter.logScreenShot(Status.INFO, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateCheckBoxDisabledFirstName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            Assert.assertFalse(tascoPage.validateCheckBoxField());
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------

     * The below method changes the state of the store to the provided Pre condition state.
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public void updateStoreState(String state) {
        connexusAppUtils.updateStoreState(state);
    }

    /*----------------------------------------------------------------------------------------------------------
      * The below method updates the flag restriction of the respective state with issue agency code of the respective state mentioned in the input.
      * Author: Tarun(vn510o1)
      ----------------------------------------------------------------------------------------------------------*/
    public void updateDxCodeFlagCondition(String issueAgencyCode) {
        connexusAppUtils.updateDxCodeFlagRestriction(issueAgencyCode);
    }

    /*----------------------------------------------------------------------------------------------------------
         * The below method inputs the mandatory fields of the product
         * Author: Tarun(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    public void inputPrescribedProduct(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
          * The below method checks if Dx code is displayed
          * Author: Tarun(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    public void validateIsDxCodeDisplayed() {
        Assert.assertTrue(inputPage.isDxCodeDisplayed());
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method navigates to PMS screen from Input page , modifies age and Click on Save and Close in the PMS screen
    * It then revalidated the modified age accordingly in Input screen
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public void modifyAgeFromInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                System.out.println("Patient Name" + patient.getPatientLastName() + "," + patient.getPatientFirstName());
                patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
                System.out.println("DOB" + patient.getPatientDob());
                patientSearchPage.inputPatientDob(patient.getPatientDob());
                patientSearchPage.clickSearchNow();
                patientSearchPage.selectRowFromSearch(0);
            }

            int counter = 0;
            while (patientMaintenancePage.isGeneralInformationTabDisplayed() && counter <= 3) {
                patientMaintenancePage.switchWindow();
                counter++;
            }
            String age = patientMaintenancePage.getAgeFromPatientMaintenanceScreen();
            patientMaintenancePage.modifyBirthDateField(1);
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.switchWindow();
            patientMaintenancePage.inputCommentInConsolidatedNotesWindow(inputData.get("MESSAGE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSave();
            patientMaintenancePage.switchWindow();
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.clickOk();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(patientName);
            patientSearchPage.openFirstPatientRecord();
            String modifiedAge = inputPage.getAgeInInputScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Modified age appearing on Input screen " + modifiedAge + " is different from the previous age available " + age);
            Assert.assertNotEquals(age, modifiedAge);
            inputPage.exitInputScreen();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method performs Input work queue
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public void performInputandValidateDXCode(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (isOrderInInputQueueDB(name[0], name[1], 1)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                inputPage.enterNdc(inputData.get("DRUG_NAME"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
                inputPage.enterSigCode(inputData.get("SIG"));
                inputPage.enterRefillQty(inputData.get("REFILLS"));
                inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
                if (inputPage.isTriplicateDisplayed()) {
                    inputPage.inputTriplicateNumber();
                }
                if (inputPage.isDxCodeDisplayed()) {
                    inputPage.inputDxCode(inputData.get("DXCODE"));
                    Reporter.log("DX Code is displayed at input screen ");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    Reporter.log("DX Code is not displayed at input screen ");
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                }
                if (inputPage.checkIfDaysFillPopUpIsDisplayed()) {
                    Reporter.log("Days of Supply is not valid message has been displayed ");
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    Reporter.log("Days of Supply is not valid message has not been displayed which has been successfully validated");
                }
                Assert.assertFalse(inputPage.checkIfEarliestFillDateIsSelected());
            }
            inputPage.clickAccept();
            if (inputPage.isOkDisplayed()) {
                inputPage.clickOK();
            }
            if (inputPage.isValidateRXPopUpDisplayed()) {
                inputPage.clickYesOnValidateRxPopUp();
                inputPage.clickAccept();
                if (inputPage.isOkDisplayed()) {
                    inputPage.clickOK();
                }
            }
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            Reporter.log("Input completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method validates the DX code field visibility in Modify details section of 4 point
    * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    public void validateDxCodeFieldInFourPointScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.FOUR_POINT.getWorkQueue(), currentStepMethodName, Status.PASS);
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue");
            }
            if (modifyDetails.isDxCodeDisplayed()) {
                Reporter.log("Diagnosis code is displayed at modify screen opened from 4 point screen");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Diagnosis code is not displayed at modify screen");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            }
            modifyDetails.exitModifyDetailsScreen();
            fourPoint.exitFourPoint();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------

        * The below method validates the expiration date of RX is within 180 days when C3 Drug is provided in TX state
        * Author: Tarun(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    public void validateC3ExpirationDate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String date = DateFormat.MMddyyyy.toString();
            String dateFormat = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4);
            org.junit.Assert.assertEquals(dropOffPage.getFutureDate(dateFormat, Integer.parseInt(inputData.get("DAYS_COUNT"))), inputPage.getExpirationDate());
            inputPage.exitInputScreen();
            inputPage.clickYesOnAbondonPopup();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method changes the Earliest fill date to 21 Days prior to the current date and validates whether the Expiration date is 21 days from the EFD
   * when C2 drug is provided in Input and State is set to TX
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/

    public void validatePastDropOffExpirationDate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            rxModel.setPrescriberDeaType(PrescriberDeaType.ALL_DRUG.getPrescriberDeaType());
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String date = DateFormat.MMddyyyy.toString();
            String dateFormat = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4);
            String earliestfillDateMonth = connexusAppUtils.modifyDateToFuture(dateFormat, 22);
            String earliestfillDate = connexusAppUtils.modifyDateToFuture(dateFormat, 22);
            Reporter.log("earlist fill date set to 22 days from expiration date");
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.pressKeys(KeyEvent.VK_RIGHT);
            inputPage.inputEarliestFillDate(earliestfillDateMonth);
            inputPage.pressKeys(KeyEvent.VK_RIGHT);
            inputPage.inputEarliestFillDate(earliestfillDate);
            inputPage.clickExpirationDate();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String efd = inputPage.getEarliestFillDate();
            String validateDate = connexusAppUtils.getFutureDateFromProvidedDate(efd, dateFormat, 30);
            String expectedDate = inputPage.getExpirationDate();
            org.junit.Assert.assertEquals(validateDate, expectedDate);
            Reporter.log("Validate and expected date difference id 30 days");
            inputPage.enterPrescriber(rxModel.getPrescriberDeaType());
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method updates the TM flag code of the repective state when the issue agency code  of state is provided as input
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    public void updateTmFlagRestriction(String issueAgencyCode) {
        connexusAppUtils.updateTmCodeFlagRestriction(issueAgencyCode);
    }

    public void launchConnexusAndValidateStandingOrderProtocolPopup() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            loginPage = new LoginPage(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            loginPage.clickloginScreenUserNameTextField();
            loginPage.inputHoUserNameAndPassword();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.clickHomeOfficeCheckBox();
            loginPage.clickAccept();
            loginPage.clickSecurityWarningAccept();
            loginPage.handelInitialOKLoginPopUps();
            if (loginPage.getErrorPopUpText().contains("Standing Order / Protocol is expired")) {
                Reporter.log(" Standing order Warning message after logging in has been validated. Test case HWRPDRES-6684 with TX state");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickOk();
            } else {
                Reporter.log(" Standing order Warning message after logging in has not been displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
       * The below method validates the expiration date of RX is within 180 days when C3 Drug is provided in TX state
       * Author: Tarun(vn510o1)
       ----------------------------------------------------------------------------------------------------------*/
    public void validateControlDrugExpirationDate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String date = DateFormat.MMddyyyy.toString();
            String dateFormat = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4);
            Assert.assertEquals(dropOffPage.getFutureDate(dateFormat, Integer.parseInt(inputData.get("DAYS_COUNT"))), inputPage.getExpirationDate());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method enters the prescriber and validates the Invalid diagnosis code popup when field is empty and clicks on Accept after updating dx code
    * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    public void enterPrescriberAndAccept(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxModel.setPrescriberDeaType(PrescriberDeaType.ALL_DRUG.getPrescriberDeaType());
            inputPage.enterPrescriber(rxModel.getPrescriberDeaType());
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(inputPage.checkIfDaysFillPopUpIsDisplayed());
            String text = inputPage.getInvalidDaysErrorMessageText();
            Assert.assertTrue(text.contains(inputData.get("TEXT_TO_COMPARE")));
            inputPage.clickButtonOk();
            inputPage.inputDxCode(inputData.get("TEXT_NOTE"));
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickButtonOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method validates the Invalid days of supply popup error message
     * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public void validateInvalidDaysOfSupplyErrorMessage(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Navigate — shared helper replaces the duplicated search/open block
            navigateToPatientInputRecord();

            // Prescriber uses DEA type, not PRESCRIBER_NAME from inputData
            rxModel.setPrescriberDeaType(PrescriberDeaType.ALL_DRUG.getPrescriberDeaType());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(rxModel.getPrescriberDeaType());
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.inputDxCode(inputData.get("TEXT_NOTE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
            if (inputPage.checkIfDaysFillPopUpIsDisplayed() && inputPage.getInvalidDaysErrorMessageText().contains(inputData.get("TEXT_TO_COMPARE"))) {
                inputPage.clickButtonOk();
                inputPage.clickWrittenDate();
                inputPage.pressKeys(KeyEvent.VK_TAB);
                inputPage.pressKeys(KeyEvent.VK_SPACE);
                inputPage.clickAccept();
                inputPage.clickOnOutofStockPopupOk();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(inputPage.checkIfDaysFillPopUpIsDisplayed());
            Assert.assertEquals(inputData.get("MESSAGE").trim(), inputPage.getInvalidDaysErrorMessageText());
            inputPage.clickButtonOk();
            inputPage.exitInputScreen();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    enum DateFormat {
        MMddyyyy,
        yyyyMMddHHmm
    }

    public void validateDxCodeFieldInFourPointScreenForControlledDrug() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            String productName = orderSearch.getProductName(0);
            FourPoint fourpoint = new FourPoint();
            F6Search rxSearch = new F6Search();
            rxNbr = rxSearch.getRxNbr(0);
            orderSearch.openFirstPatientRecord();
            if (fourpoint.isElementDisplayed(fourpoint.cmbDrugReEntry, 30)) {
                Assert.assertFalse(fourpoint.isElementEnabled(fourpoint.btnValidateReEntry));
                Reporter.log("index number" + fourpoint.getDrugReleaseType(productName));
                fourpoint.selectValueFromTheListBasedOnIndex(fourpoint.cmbDrugReEntry, fourpoint.getDrugReleaseType(productName));
                fourpoint.click(fourpoint.btnValidateReEntry);
            }
            modifyDetails.launchModifyDetailScreen();
            if (modifyDetails.isDxCodeDisplayed()) {
                Reporter.log("Diagnosis code is displayed at modify screen opened from 4 point screen");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Diagnosis code is not displayed at modify screen");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            }
            modifyDetails.exitModifyDetailsScreen();
            fourPoint.exitFourPoint();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            throw new RuntimeException(e);
        }
    }

    public void editingWeightField() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date today = new Date();
            String formattedDate = sdf.format(today);
            patientMaintenancePage.clearDobField();
            patientMaintenancePage.inputDOB(formattedDate);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWeightField() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.isWeightEnabled();
            patientMaintenancePage.inputWeight("10");
            patientMaintenancePage.clearWeight();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void selectingPatientTypeHumanDropOffQueue(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Search for Patient");
            dropOffPage.switchWindow();
            dropOffPage.enterPatientName("MKT,NKT");
            dropOffPage.clickPatientSearch();
            patientSearchPage.inputPatientDob("11/12/1992");
            patientSearchPage.inputPatientPhone(inputData.get("PHONE_NUMBER1"));
            patientSearchPage.inputPatientZip(inputData.get("ZIP_CODE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.clickNew();
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Type is Selected as HUMAN");
            patientMaintenancePage.isFirstNameEnabled();
            Reporter.log("Patient Profile is Editable ");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateTmFieldForNonOpiodDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.clearPrescribedProduct();
            inputPage.enterNdc(inputData.get("NON_OPIOID_DRUG"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOnTMCodeDropDown();
            org.junit.Assert.assertEquals(inputData.get("TEXT_TO_COMPARE"), inputPage.getTmCodeFieldValue());
            inputPage.hoverOnTmCodeField();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.assertEquals(inputData.get("TEXT_TO_COMPARE"), inputPage.getTmCodeFieldValue());
            inputPage.exitInputScreen();
            inputPage.clickYesOnAbondonPopup();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateTmFieldForOpiodDrug() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String opioidDrugTmFieldValue = inputPage.getTmCodeFieldValue();
            org.junit.Assert.assertEquals(opioidDrugTmFieldValue, "");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void validateTmCodeDropDownValuesByChangingNonOpioidToOpioidDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actual = inputData.get("TEXT_NOTE");
            String[] arr = actual.split(";");
            org.junit.Assert.assertEquals(inputData.get("TEXT_TO_COMPARE"), inputPage.getTmCodeFieldValue());
            Reporter.log("TM code filed value is be 99");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clearPrescribedProduct();
            inputPage.enterNdc(inputData.get("OPIOID_DRUG"));
            inputPage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String opioidDrugTmFieldValue = inputPage.getTmCodeFieldValue();
            org.junit.Assert.assertEquals(opioidDrugTmFieldValue, "");
            Reporter.log("TM code filed value is blank");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            if(inputPage.isTMCodeDisplayed()){
                String expctedTmDropdownList= inputData.get("TM_CODE_VALUES");
                List<String> TMCodeValues = new ArrayList<>(Arrays.asList(expctedTmDropdownList.split(",")));
                List<String> tmDropdownList = inputPage.getPrescriberDegreeDropdownValues();
                System.out.println("List 1"+TMCodeValues);
                System.out.println("List 2"+tmDropdownList);
                Assert.assertEquals(TMCodeValues, tmDropdownList,"TM code values are not matching");
                Assert.assertTrue(true, "TM code displayed in Input screen for Opioid drug");
                Reporter.log("TM code displayed in Input screen");
            }else{
                Assert.fail("TM code not displayed in Input screen.");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void openPseudoephedrine(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.launchTascoPseudophedrineScreen();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void clickExitHIPAA(Map<String, String> inputData) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            tascoPage.clickExitTascoHIPAAPseudophedrine();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured=true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void clickExitInTasco(Map<String, String> inputData) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            tascoPage.clickExitInTasco();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
}
