package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderCreationTestSetScript extends ConnexusTestScripts {
    public OrderCreationTestSetScript(LoginAs.userType loginUserType){
        super(loginUserType);
    }


    String productName=null;
    String barCode;

    /*
     * Method to click the drop off icon and validate drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickAndValidateDropOffScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            Assert.assertTrue(dropOffPage.isPatientRxTextBoxDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To enter the patient name in DOb/Rx/PatientName text box in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void inputPatientNameInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Validate the entered patient details from database in Drop Off Screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validatePatientDetailsInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patient = "select * from patient p inner join subject_address sa on p.patient_id=sa.subject_id " +
                    "where p.last_name=\"" + name[0].toUpperCase() + "\" and p.first_name = \"" + name[1].toUpperCase() + "\"";
            Map<String, Object> patientDetails = automationManager.getConnexusDB().executeQuery(patient);
            String birthDateFromDB = patientDetails.get("birth_date").toString().trim();
            String address = patientDetails.get("address_line_1").toString().trim();
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yyyy");
            String birthDate = format2.format(format1.parse(birthDateFromDB));
            Assert.assertEquals(name[0].toUpperCase() + ", " + name[1].toUpperCase() + " ", dropOffPage.getEnteredPatientName());
            Assert.assertEquals(birthDate, dropOffPage.getPatientBirthDate());
            Assert.assertEquals(address, dropOffPage.getPatientAddress());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Click on NewScanRx and validate the scanRx window in Drop Off Screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateScanRxWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickScanNewRx();
            Assert.assertEquals("Please Enter the four-digit BarCode number from the label.", dropOffPage.enterBarCodeLabel());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Enter the barcode in ScanRX window and validate the entered barcode in the confirmation bar code popup in Drop Off Screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void enterBarCodeAndValidateText(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            dropOffPage.clickBtnAccept();
            Reporter.log("Enter barcode pop navigated to confirm barcode pop up");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            String actualBarCodeMsg = "You Entered Bar Code " + barCode + ". Is This correct?";
            Assert.assertEquals(actualBarCodeMsg, dropOffPage.getVerifyEnteredBarCodeValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Click yes in confirmation barcode pop up in Drop Off Screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickYesInVerifyBarCodePopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickVerifyBarCode();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Validate the RxOrigin Type window in Drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateRxOriginTypeWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> originRxTypeValue = new ArrayList<>(dropOffPage.getOriginRxTypeValues());
            if (originRxTypeValue.contains("ORIGINAL RX") && originRxTypeValue.contains("PHONE (Prescriber Only)") &&
                    originRxTypeValue.contains("FAX (Prescriber Only)") && originRxTypeValue.contains("PHARMACY (Transfer/RPH NPI)")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Click yes in Rx Origin Type Window and validate whether pop up is closed in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickAcceptInRxOriginType() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickBtnAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Select Priority and click accept in Drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void selectPriorityTimeAndClickAccept() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.selectPriority(Priority.InStore.getPriority());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Search patient in Order Search screen(using F6)
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void searchPatientAfterDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            if (orderSearch.getPatientName(0).equals(name[0] + "," + name[1]) && "Input".equals(orderSearch.getWorkQueue(0))) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Validate the order information grid in Drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateOrderInformationScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Assert.assertTrue(dropOffPage.getRxInformation(0).contains(name[0].toUpperCase()));
            Assert.assertTrue(dropOffPage.getRxInformation(0).contains(barCode));
            Assert.assertEquals(1, dropOffPage.validateRxCount(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Select the OriginRx as Phone and check the EmergencyRx checkbox in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void selectRxTypeAsPhoneAndCheckEmergencyRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.selectRxOriginType(2);
            if(!dropOffPage.isChkBoxTamperResistantEnabled()){
                Assert.assertTrue(true);
                Reporter.log("Tamper Resistant checkbox disabled");
            }
            dropOffPage.clickEmergencyRxCheckBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method clicks on Visual verify work queue on left bar and verifies if the Technician is not able to
     * open the work queue
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void validateVisualVerifyForTechnician() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.log("Technician is not able to open Visual Verify and could not complete Visual Verify");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            //clicking on visual verify link again to unselect that tab.
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method clicks on 4 point work queue on left bar and verifies if the Technician is not able to
     * open the work queue
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void validateFourPointForTechnician() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues())) {
                Reporter.log("Technician is not able to open Four Point and could not complete Four Point");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            //clicking on 4 point link again to unselect that tab.
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method clicks on Counselling work queue on left bar and verifies if the Technician is not able to
     * open the work queue
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void validateCounsellingForTechnician() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.log("Technician is not able to open Counseling and could not complete Counseling");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            //clicking on counseling link again to unselect that tab
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
        } catch (Throwable e) {
            isExceptionCaptured =true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //Test Steps
    //1.b Click on Drop off icon.
    /*
     * Method to click the drop off icon and validate drop off screen
     *
     * Author: Charles Allensworth ( vn50vo7 ) from Keerthana Jayaraman( vn82865 )
     * */
    public void clickAndValidateDropOffScreenWithQuickNote() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);
            Assert.assertTrue(dropOffPage.isPatientRxTextBoxDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //2. Click on F8 ( hit f8 on the keyboard ).
    //Author: Charles Allensworth ( vn50vo7 )
    public void openQuickQuote() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log(currentStepMethodName + "Opening Quick Quote in drop off.");
            dropOffPage.pressKeys(KeyEvent.VK_F8);
            boolean quickQuoteOpenCheck = dropOffPage.isQuickQuoteOpen();
            Assert.assertTrue(quickQuoteOpenCheck);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //3. Enter the Drug ndc and quantity and click on Price.
    //Author: Charles Allensworth ( vn50vo7 )
    public void enterDrugNDC_And_ClickPrice(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String drugNDC = inputData.get("DRUG_NAME");
            Reporter.log(currentStepMethodName + ": entering NDC# " + drugNDC);
            dropOffPage.enterNDCinQQDrugNameField(drugNDC);
            dropOffPage.pressKeys(KeyEvent.VK_TAB);
            String quantity = inputData.get("QUANTITY");
            Reporter.log(currentStepMethodName + "entering quantity : " + quantity);
            dropOffPage.enterQtyOfDrugInQQ(quantity);
            Reporter.log(currentStepMethodName + "clicking price");
            dropOffPage.clickPriceButtonInQQ();
            String[] descNDCTarget = getDescAndNDC(inputData.get("TEXT_TO_COMPARE"));
            String[] descNDCReal = getDescAndNDC(dropOffPage.getQuickQuoteResults_L1());
            boolean isdesReal = descNDCTarget[0].equals(descNDCReal[0]);
            boolean isNDCReal = descNDCTarget[1].equals(descNDCReal[1]);
            Reporter.log(currentStepMethodName + "desc from pulled drug is \"" + descNDCReal[0] + ", " + descNDCReal[1] + "\"");
            Assert.assertTrue(isdesReal && isNDCReal);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //4.a Click on Close.
    //Author: Charles Allensworth ( vn50vo7 )
    public void clickToCloseQuickPrice() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log(currentStepMethodName + "Exiting Quick Price");
            dropOffPage.closeQuickQuote();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnCancel();
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Pull the description and ndc and
     * return as an String[2]
     *
     * Author: Charles Allensworth ( vn50vo7 )
     * */
    public String[] getDescAndNDC(String input) {
        //the string specified
        String[] retThis = new String[2];
        //position of first and last characters for the ndc
        int ndcEnd = input.length();
        int ndcStart = ndcEnd - 16;

        //place the strings in their respective cells
        retThis[0] = input.substring(0, 23);
        retThis[1] = input.substring(ndcStart, ndcEnd);

        //return the array
        return retThis;
    }

    /*----------------------------------------------------------------------------------------------------------
      * The below method performs Fax DropOff
      * Author: Tarun(vn510o1)
      ----------------------------------------------------------------------------------------------------------*/
    public void dropOffPatientWithFax() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(patientName);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickScanNewRx();
            String barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            dropOffPage.clickBtnAccept();
            dropOffPage.clickVerifyBarCode();
            dropOffPage.selectRxOriginAsFax();
            dropOffPage.clickBtnAccept();
            dropOffPage.addNoOfRx(barCode, 1);
            dropOffPage.selectPriority(Priority.InStore.getPriority());
            if (dropRxModel.getPriority() == Priority.Future) {
                dropOffPage.selectPickupTime("");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method provides all mandatory fields in Input and send Input to Manual Resolution
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public void sendInputToManualResolution(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            orderSearch.performSearch(patientName, SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            inputPage.sendRxToManualResolution(inputData.get("MESSAGE"), InputPage.ManualResolutionType.CONTACT_PRESCRIBER);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOK();
            Reporter.log("Pharmacist sending Input to Manual resolution queue");
        } catch (Exception e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method validates the error message if technician triies to open the Resolution related to Pharmacist
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateTechnicianOpeningResolutionRx(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            ResolutionPage resolution = new ResolutionPage();
            orderSearch.performSearch(patientName, SearchType.PatientRx);
            Reporter.log("Login as a Technician and validating the Work queue should be Resolve");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.selectRowFromSearch(0);
            resolution.checkErrorTextExist();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String errorMessage = resolution.getTextErrorMessage();
            Reporter.log("Validating error text while trying to resolve the queue."+errorMessage);
            Assert.assertEquals(inputData.get("POPUP"),errorMessage);
            resolution.clikOKOnPopup();
            resolution.clickCancel();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method launches and opens the rx in the 4 point work queue
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void launchAndVerify4PointScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            F6Search orderSearch = new F6Search();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())){
                takeScreenShotRXStatus(rxNbr,WorkQueue.FOUR_POINT.getWorkQueue(),currentStepMethodName,Status.PASS);
                Assert.assertTrue(true);
                orderSearch.launchOrderSearchScreen();
                productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                if (!orderSearch.isFourPointPageDisplayed()) {
                    Reporter.logScreenShot(Status.PASS,currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                }
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the vertical position of rx image box, Acute and Non acute radio buttons on the screen
     * and compares the y position. Comparing the y position of all the elements indicate that the elements on screen are
     * placed one below other
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyAcuteAndNonAcutePositionOn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int rxImagePosition = fourPoint.getYPositionOfRxImage();
            int acuteRdbBtnPosition = fourPoint.getYPositionOfAcuteRadioButton();
            int nonAcuteRdbBtnPosition = fourPoint.getYPositionOfNonAcuteRadioButton();
            if (acuteRdbBtnPosition > rxImagePosition && (nonAcuteRdbBtnPosition > rxImagePosition)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Acute and Non Acute Radio Buttons are displayed below Rx Image on 4 point Screen");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the vertical position of Initial Fill Label, Acute Yes initial fill and Acute no radio buttons on the screen
     * and compares the y position. Comparing y position of all the elements indicate that the elements on screen are
     * placed one below other
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyInitialFillPositionOn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int acuteRdbBtnPosition = fourPoint.getYPositionOfAcuteRadioButton();
            int lblInitialFillPosition = fourPoint.getYPositionOfInitialFillLabel();
            int acuteYesRdbBtnPosition = fourPoint.getYPositionOfAcuteYes();
            int acuteNoRdbBtnPosition = fourPoint.getYPositionOfAcuteNo();
            if ((lblInitialFillPosition > acuteRdbBtnPosition) && (acuteYesRdbBtnPosition > acuteRdbBtnPosition) &&
                    (acuteNoRdbBtnPosition > acuteRdbBtnPosition)) {
                Reporter.log("Initial Fill Label is displayed below Acute Radio Button on 4 point Screen");
                Reporter.log("Acute Yes and No radio buttons are displayed below Acute Radio Button on 4 point");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Acute Radio button on 4 point
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickAcuteRadioButtonOn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.click(fourPoint.rdbAcute);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on cancel button on 4 point
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickButtonCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method selects the checkboxes on 4 point Name, prescribed, strength, sig and dea checkboxes on 4 point
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void selectCheckBoxesOn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if(fourPoint.isElementDisplayed(fourPoint.txtDrugReEntry,10)){
                fourPoint.enterDrugName(productName);
                fourPoint.click(fourPoint.btnValidateReEntry);
            }
            if (fourPoint.isNameChkBoxDisplayed()) {
                fourPoint.chkName();
                fourPoint.chkPrescribed();
                if (fourPoint.ischkStrength()) {
                    fourPoint.chkStrength();
                }
                fourPoint.chkSIG();
            }
            if (fourPoint.isDeaChkBoxDisplayed()) {
                fourPoint.chkDEA();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Initial acute fill Yes radio button on 4 point
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickInitialFillYes4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickAcuteYesRdbButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method accepts the 4 point screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void accept4PointScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method modifies the new controlled prescriber name for the rx in filling queue
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void modifyPrescriberInFilling(String newPrescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ModifyDetails modifyDetails = new ModifyDetails();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            modifyDetails.clearPrescriberName();
            modifyDetails.enterPrescriberName(newPrescriberName);
            modifyDetails.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOnConnexusPopUp();
            modifyDetails.checkAndClickWarning();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method verifies the Request to Send [RTS] pop up is displayed when prescriber name is modified
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyRequestToSend4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            if (modifyDetails.getLabelMessageOnFloatingPopUp().contains("changes made to this fill")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}