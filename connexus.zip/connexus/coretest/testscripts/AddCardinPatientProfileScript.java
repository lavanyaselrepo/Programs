package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CardDetailsResponse;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import java.util.Map;


public class AddCardinPatientProfileScript {

    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    PatientMaintenancePage patientMaintenancePage;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    SoftAssert softAssert = new SoftAssert();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    ServiceResponse resp = new ServiceResponse();
    InputResponse inputResp = new InputResponse();

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        patientMaintenancePage = new PatientMaintenancePage();
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
        prop.loadCustomProperties("config/connexus/");
        patientMaintenancePage = new PatientMaintenancePage();
        loginPage.loginConnexus(userType);
        softAssert = new SoftAssert();
    }

    public void addVisaCardToPatient(Map<String, String> inputData) {
        addCardToPatient(inputData, "Visa");
    }


    public void addDiscoverCardToPatient(Map<String, String> inputData) {
        addCardToPatient(inputData, "Discover");
    }


    public void addMasterCardToPatient(Map<String, String> inputData) {
        addCardToPatient(inputData, "Mastercard");
    }


    public void addAmexCardstartwith37ToPatient(Map<String, String> inputData) {
        addCardToPatient(inputData, "Amex");
    }

    public void addCardToPatient(Map<String, String> inputData, String cardType) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            String firstName = name[0];
            String secondName = name[1];
            int patientID, siteId;
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("homePhone"));
            workPhone = Long.parseLong(inputData.get("workPhone"));
            cellPhone = Long.parseLong(inputData.get("cellPhone"));
            resp = connexusAPIManager.createPatient(secondName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientID = inputResp.getPatientId();
            Reporter.log("patientId = " + patientID);
            String patientId = String.valueOf(patientID);
            String strNbr = String.valueOf(siteId);
            Reporter.log("Patient has been created.");
            resp = connexusAPIManager.getCardDetails(patientId, strNbr);
            if (resp != null && resp.getStatusCode() == 200 && !resp.getDataResponse().isEmpty()) {
                CardDetailsResponse inputResp = resp.getDataResponse(CardDetailsResponse.class);

                String cardName = inputResp.getPatientPaymentInfo()
                        .get(0)
                        .getPhmPaymentAcctInfo()
                        .getCreditCardName()
                        .trim();

                if ("Visa".equalsIgnoreCase(cardName) ||
                        "MasterCard".equalsIgnoreCase(cardName) ||
                        "Amex".equalsIgnoreCase(cardName) ||
                        "Discover".equalsIgnoreCase(cardName)) {

                    Reporter.log("Card already exists with type: " + cardType);
                    return;
                }
            }

            //Add new card using UI actions
            Reporter.log("No card found. Proceeding to add a new card...");
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.clickTabProfile();
            String cardRefNbr = inputData.get("cardRefNbr");
            String cardHolderName =inputData.get("cardHolderName");
            String expirYearNbr = inputData.get("expirYearNbr");
            String expirMoNbr = inputData.get("expirMoNbr");
            String p2peToken = inputData.get("p2peToken");
            String startDate = inputData.get("startDate");
            String phmPymtMethod = inputData.get("phmPymtMethod");
            resp = connexusAPIManager.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirMoNbr,expirYearNbr, p2peToken, startDate, phmPymtMethod);
            Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
            automationManager.performSleep(10);
            patientSearchPage.clickEasyPayAccount();
            System.out.println("resp : " + resp);
            Reporter.log("New Card Added");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(patientSearchPage.getCardHolderNameFromSearchGrid(0).equalsIgnoreCase(cardHolderName));
            Assert.assertTrue(patientSearchPage.getExpiryYearFromSearchGrid(0).equalsIgnoreCase(expirYearNbr));
            Assert.assertTrue(patientSearchPage.getExpiryMonthFromSearchGrid(0).equalsIgnoreCase(expirMoNbr));
            Assert.assertTrue(patientSearchPage.getCardTypeFromSearchGrid(0).equalsIgnoreCase(cardType));
            patientSearchPage.clickCancel();
            patientMaintenancePage.clickSaveAndClose();
            if(patientMaintenancePage.isValidationDisplayed()) {
                patientSearchPage.clickasEnteredOK();
                patientMaintenancePage.clickGeneralInformationTab();
                patientMaintenancePage.isAllergiesNoEnabledRadioButton();
                patientMaintenancePage.clickSaveAndClose();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void closeWindowByClickingOnCloseButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.clickExitbutton();
            automationManager.performSleep(5);
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //UI flow to check card is already added
    public boolean checkCardAlreadyAdded(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        patientSearchPage.launchPatientSearchScreen();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String patientName = name[0] + "," + name[1];
        patientSearchPage.inputPatientName(patientName);
        patientSearchPage.clickSearchNow();
        patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
        automationManager.performSleep(10);
        patientMaintenancePage.isAllergiesNoEnabledRadioButton();
        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        automationManager.performSleep(6);
        patientMaintenancePage.clickTabProfile();
        patientSearchPage.clickEasyPayAccount();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        patientSearchPage.clickExitbutton();
        patientMaintenancePage.clickSaveAndClose();
        return "Visa".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "Discover".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "Amex".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0)) ||
                "MasterCard".equalsIgnoreCase(patientSearchPage.getCardTypeFromSearchGrid(0));
    }

    public void closeConnexus() {
        //loginPage.closeAppKeyCombo();
    }
}
