package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.Narxcare_testcases.testcases.Logicoy_Testcases;
import connexus.coretest.testcases.ProductSearchTestSet;
import connexus.e2e.testcases.E2E_TestCases;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import opticaltests.eligibilitytests.datamodels.spectera.Product;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Map;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;

public class ProductSearchTestSetScript extends ConnexusTestScripts {
    public ProductSearchTestSetScript(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    /**
     * Method to Open Product Search Window by pressing the Keyboard shortcut CTRL+SHIFT+D
     * Author: Srinivas(vn50jui)
     * */
    public void openProductSearchWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        productSearchPage = new ProductSearchPage();
        try {
            productSearchPage.launchProductSearchScreen();
            Assert.assertTrue(productSearchPage.isProductNameComboBoxDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter text in all fields on Product Search and to validate search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchProductWithAllFields(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductStrength(inputData.get("PRODUCT_STRENGTH"));
            productSearchPage.enterProductForm(inputData.get("PRODUCT_FORM"));
            productSearchPage.enterProductGenericName(inputData.get("PRODUCT_GENERIC_NAME"));
            productSearchPage.enterProductNDC(inputData.get("PRODUCT_NDC"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isSearchNowButtonDisplayed());
            Assert.assertTrue(productSearchPage.isNewSearchButtonDisplayed());
            Assert.assertTrue(productSearchPage.isHostLookUpButtonDisplayed());
            Assert.assertTrue(productSearchPage.isCloseButtonDisplayed());
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_STRENGTH")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_FORM")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn(0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify Data in Search results from host are displayed in columns Short name and Generic Drug Name when click on Host Look Up
     * Also verify if the Host Look Up, Search Now, New Search and Close buttons are displayed
     * Author: Srinivas(vn50jui)
     * */
    public void productSearchHostSearchResultsValidation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, "Search Product", productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickHostLookUp();
            Reporter.log("clicked host lookup");
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            System.out.println("verified product name");
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn (0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
            System.out.println("verified product generic name");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify search history in all text fields on Product Search and validate search results
     * It selects the previous search values in text fields and then perform Search
     * Author: Srinivas(vn50jui)
     * */
    public void checkProductSearchHistory(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            do {
                productSearchPage.pressDownArrowKeyInProductName();
            } while (!inputData.get("PRODUCT_NAME").equalsIgnoreCase(productSearchPage.getValueFromName()));

            do {
                productSearchPage.pressDownArrowKeyInProductStrength();
            } while (!inputData.get("PRODUCT_STRENGTH").equalsIgnoreCase(productSearchPage.getValueFromStrength()));

            do {
                productSearchPage.pressDownArrowKeyInProductForm();
            } while (!inputData.get("PRODUCT_FORM").equalsIgnoreCase(productSearchPage.getValueFromForm()));

            do {
                productSearchPage.pressDownArrowKeyInProductGenericName();
            } while (!inputData.get("PRODUCT_GENERIC_NAME").equalsIgnoreCase(productSearchPage.getValueFromGenericName()));

            do {
                productSearchPage.pressDownArrowKeyInProductNDC();
            } while (!inputData.get("PRODUCT_NDC").equalsIgnoreCase(productSearchPage.getValueFromNDC()));

            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_STRENGTH")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_FORM")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn(0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to click on Input left bar icon to open Input work queue and click on it back to disable it
     * Author: Srinivas(vn50jui)
     */
    public void clickInputFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter a drug name in Prescribed Product text field and search in Input screen
     * Author: Srinivas(vn50jui)
     * */
    public void enterProductAndSearchInInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.enterProductNameInPrescribedProduct(inputData.get("PRODUCT_NAME"));
            Assert.assertTrue(productSearchPage.isProductNameComboBoxDisplayed());
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify if the Product Search Window is closed when the user pressed ESC button in Input screen
     * Author: Srinivas(vn50jui)
     * */
    public void closeProductSearchWindowsByPressingEscapeButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.closeProductSearchWindowsByPressingEscButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close the Input screen
     * Author: Srinivas(vn50jui)
     */
    public void closeInputScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.clickCancel();
            connexusStartPage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter a drug name in Prescribed Product text field and search in Modify Details screen
     * Verify if the searched product details matched with the given Product details.
     * Author: Srinivas(vn50jui)
     * */
    public void enterProductAndSearchInModifyDetailsScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            System.out.println("Rx status" + rxStatus);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.enterProductNameInPrescribedProduct(inputData.get("PRODUCT_NAME"));
                productSearchPage.enterProductStrength(inputData.get("PRODUCT_STRENGTH"));
                productSearchPage.enterProductForm(inputData.get("PRODUCT_FORM"));
                productSearchPage.enterProductGenericName(inputData.get("PRODUCT_GENERIC_NAME"));
                productSearchPage.enterProductNDC(inputData.get("PRODUCT_NDC"));
                productSearchPage.clickSearchNow();
                Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
                Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
                Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_STRENGTH")));
                Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_FORM")));
                Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn(0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                productSearchPage.closeProductSearchWindowsByPressingEscButton();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close the Modify Details screen
     * Author: Srinivas(vn50jui)
     */
    public void closeModifyDetailsScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.clickCancel();
            connexusStartPage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /**
     * Method to close the Product Search Window by clicking on Close button
     * Author: Srinivas(vn50jui)
     * */
    public void closeProductSearchWindowsByClickingOnCloseButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify Product Search results with DB results
     * Author: Srinivas(vn50jui)
     * */
    public void verifyProductSearchResultAgainstDB(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {

            Map<String, Object> productResultsFromDB = automationManager.getConnexusDB().executeQuery("select trim(short_name) as short_name from pharmacy_offering:pharmacy_product where product_name in ('"+ inputData.get("PRODUCT_NAME")+"')limit 1;");
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.clickSearchNow();
            String queryResult = productResultsFromDB.toString();
            System.out.println(queryResult);
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(productResultsFromDB.get("short_name").toString()));
            Reporter.log("Assertion Pass : Displayed Product name is matching with DB result");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Click on New Search Button on Product Search window
     * Click on OK button on the popup "This will clear your current search"
     * Author: Srinivas(vn50jui)
     * */
    public void clickOnNewSearchClearsSearchResults() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.clickNewSearch();
            Assert.assertTrue(productSearchPage.isClearSearchPopUpDisplayed());
            Reporter.logScreenShot(Status.PASS, "clear search popup is displayed", productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickOKButtonOnClearSearchPopUp();
            Reporter.logScreenShot(Status.PASS, "Cleared search", productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(productSearchPage.isProductNameDisplayed(), "");
            Assert.assertTrue(productSearchPage.isProductFormDisplayed(), "");
            Assert.assertTrue(productSearchPage.isProductGenericNameDisplayed(), "");
            Assert.assertTrue(productSearchPage.isProductStrengthDisplayed(), "");
            Assert.assertTrue(productSearchPage.isProductNdcDisplayed(), "");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter text in Name and Strength fields on Product Search and to validate search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchWithNameAndStrengthFieldsAndVerifyResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //Below String is to construct the full form of Drug Short Name
            String product_short_name = inputData.get("PRODUCT_NAME") + " " + inputData.get("PRODUCT_STRENGTH") + "MG";
            Map<String, Object> productResultsFromDB = automationManager.getConnexusDB().executeQuery("select first 1trim(short_name) as short_name from pharmacy_offering:pharmacy_product where product_name in ('"+ inputData.get("PRODUCT_NAME") + "') and trim(short_name) like ('" + product_short_name + "%')  order by short_name asc;");
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductStrength(inputData.get("PRODUCT_STRENGTH"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Reporter.log("Assertion Pass: Product Record is displayed");
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(productResultsFromDB.get("short_name").toString()));
            Assert.assertTrue(productResultsFromDB.get("short_name").toString().toLowerCase().contains(product_short_name.toLowerCase()));
            Assert.assertTrue(productResultsFromDB.get("short_name").toString().contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productResultsFromDB.get("short_name").toString().contains(inputData.get("PRODUCT_STRENGTH")));
            Reporter.log("Assertion Pass: Displayed Product name is matching with DB result");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /**
     * Method to enter combination of Search fields - Name and Strength on Product Search window and to verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void productSearchCombineNameAndStrengthSearchFieldsAndValidateResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openProductSearchWindow();
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductStrength(inputData.get("PRODUCT_STRENGTH"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_STRENGTH")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /**
     * Method to enter combination of Search fields - Name and Form on Product Search window and to verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void productSearchCombineNameAndFormSearchFieldsAndValidateResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openProductSearchWindow();
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductForm(inputData.get("PRODUCT_FORM"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_FORM")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter combination of Search fields - Name and Generic Name on Product Search window and to verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void productSearchCombineNameAndGenericNameFieldsAndValidateResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openProductSearchWindow();
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductGenericName(inputData.get("PRODUCT_GENERIC_NAME"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn(0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter combination of Search fields - Name and NDC on Product Search window and to verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void productSearchCombineNameAndNDCFieldsAndValidateResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openProductSearchWindow();
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductNDC(inputData.get("PRODUCT_NDC"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter text in Form and Generic Name fields on Product Search and to validate search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchWithFormAndGenericNameFieldsAndVerifyResults(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //Below String is to construct the full form of Drug Short Name
            String product_short_name = inputData.get("PRODUCT_NAME") + " " + inputData.get("PRODUCT_STRENGTH") + "MG" + "     " + inputData.get("PRODUCT_FORM");
            Map<String, Object> productResultsFromDB = automationManager.getConnexusDB().executeQuery("select DISTINCT trim(short_name) as short_name from pharmacy_offering:pharmacy_product where product_name in ('"+ inputData.get("PRODUCT_NAME")+"') and trim(short_name) in ('" + product_short_name + "');");
            Reporter.log("Entered the product name : "+inputData.get("PRODUCT_NAME"));
            Reporter.log("Entered the product form : "+inputData.get("PRODUCT_FORM"));
            Reporter.log("Entered the product generic name : "+inputData.get("PRODUCT_GENERIC_NAME"));
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductForm(inputData.get("PRODUCT_FORM"));
            productSearchPage.enterProductGenericName(inputData.get("PRODUCT_GENERIC_NAME"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Reporter.log("Assertion Pass: Product Record is displayed");
            Assert.assertTrue(product_short_name.equalsIgnoreCase(productResultsFromDB.get("short_name").toString()));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_FORM")));
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridGenericDrugNameColumn(0).contains(inputData.get("PRODUCT_GENERIC_NAME")));
            Reporter.log("Assertion Pass: Displayed product record is matching with DB result");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            System.out.println("catch failure");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter empty product search results grid on Product Search window when there are no results found
     * Author: Srinivas(vn50jui)
     * */
    public void emptySearchResultsVerificationOnProductSearch(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductGenericName(inputData.get("PRODUCT_GENERIC_NAME"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isProductRecordNotDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
    * Method validate editing of single dose and single dispense check boxes in item maintenance screen
    * */
    public void validateEditingOfSingleDispenseAndSingleDose(Map<String, String>inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //Searching for the product in product search and launching product screen
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.clickSearchNow();
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, "ProductSearchScreen", productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickProductOnSearchGrid(0);
            productSearchPage.isElementDisplayed(productSearchPage.acceptBtn);
            Reporter.logScreenShot(Status.PASS, "ProductScreen", productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            //Updating Single dispense and dose for first time
            productSearchPage.launchingItemMaintenanceScreenAndUpdatingSingleDoseAndDipense(0);
            //Updating Single dispense and dose for second time
            productSearchPage.launchingItemMaintenanceScreenAndUpdatingSingleDoseAndDipense(0);
            //closing product screen
            productSearchPage.clickCancelButton();
        }catch (Exception e){
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to validate editing of single dispense and single dose in product maintenance screen" + e.getMessage());
            softAssert.fail();
        }
    }
}
