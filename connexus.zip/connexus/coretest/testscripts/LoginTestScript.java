package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;


public class LoginTestScript extends ConnexusTestScripts {

    String userDetails;

    /**
     * Method to generate 4 digit SSN number for temp user creation
     * Author: Aparna(vn50izt)
     */
    public String generateSSN() {
        return String.valueOf(ThreadLocalRandom.current().nextInt(1000, 10000));
    }

    /**
     * Method to launch connexus
     * Author: Aparna(vn50izt)
     */
    public void launchConnexusLogin(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
    }

    /**
     * Method to launch Add temp user panel and create temp user
     * Author: Aparna(vn50izt)
     */
    public String launchAddTempUser(String role, Map<String, String> inputData) {

        try {
            Reporter.log("Creating temp user for "+role);
            automationManager = AutomationManager.getInstance();
            inputData.put("SSN", generateSSN());
            loginPage.launchTempUserCreation();
            userDetails = loginPage.updateTempUserDetails(role, inputData);
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Failed to create temp user for "+role);
        }
        return userDetails;
    }
    /**
     * Method to check if newly created user data is available in database
     * Author: Aparna(vn50izt)
     */
    public void validateDBData(String userId) {
        try {
            userDetails = userId;
            if (userDetails != null && !userDetails.isEmpty())  {
                Reporter.log("Successfully created temporary user " + userDetails);
                boolean elementExist = loginPage.checkIfUserExists(userDetails);
                Assert.assertTrue(elementExist, "User details are not inserted in database");
                Reporter.log("User data has been inserted into database successfully");
            } else {
                Assert.fail("User profile has not been created");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to login to connexus with temp user credentials without resetting password
     * Author: Aparna(vn50izt)
     */
    public void loginAsTempUserWithoutPasswordReset(LoginAs.userType userType, String userId, String pwd) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        loginPage.loginAsRPHTemp(userType, userId, pwd);
        if (loginPage.checkTempUserSetupPanelExists()) {
            Reporter.logScreenShot("Add Temp User view after providing temp user credentials", loginPage.takeScreenShot());
            Reporter.log("Skipping the new password setup by clicking on cancel");
            loginPage.clickCancelButton();
        }

        loginPage.validateConnexusLaunch();
        Reporter.logScreenShot(Status.PASS, "Connexus has launched successfully with temp user credentials without updating password", loginPage.takeScreenShot(currentStepMethodName).getValue());
    }

    /**
     * Method to login to connexus with temp user credentials in another store
     * Author: Aparna(vn50izt)
     */
    public void loginAsTempUserWithoutPasswordResetInAnotherStore(LoginAs.userType userType, String userId, String pwd, String store_number) {

        loginPage.loginAsRPHTempWithChangeSToreNumber(userType, userId, pwd, store_number);
        boolean isPopUpVisible = loginPage.isTempUserNotAllowedPopUpVisible();
        if(isPopUpVisible) {
            Reporter.logScreenShot("Popup when we try to login with temp user credential in storeB which is created in storeA", loginPage.takeScreenShot());
            loginPage.clickOk();
            loginPage.clickCancelButton();
        }
        Assert.assertTrue(isPopUpVisible,"Temporary users may only access the store they were created in. Please create a new Temp User for the current store pop Up should be visible");
    }

    /**
     * Validating claim details screen is loading
     */
    public void validateClaimDetailsScreen(String rxNbr, String searchType) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            claimPage.launchClaimPage();
            claimPage.performClaimSearch(rxNbr, searchType);
            Reporter.logScreenShot(Status.PASS, "Claim Search", claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(loginPage.validateClaimDetailsPageIsLaunched());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            claimPage.closeClaimDetailsScreen();
        }catch(Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Claim detail page is not validated");
        }
    }

    /**
     * Verify Tp extra info screen is launched and Qlfr is spelled correctly
     **/
    public void verifyVerbiageOfIdQlfr(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            loginPage.launchThirdPartyInfoScreen();
            Assert.assertTrue(loginPage.isTpScreenDisplayed());
            Assert.assertEquals(loginPage.PayerIdQlfr(), inputData.get("EXPECTED_TEXT"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.closeTpInfoScreen();
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("QlOther Payer Id Qlfr is not displayed");
        }
    }
}