package connexus.coretest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserExperienceTestSetScript extends ConnexusTestScripts {

    private boolean deaClassValueSetFlag;

    public UserExperienceTestSetScript(LoginAs.userType loginUserType) {
        super(loginUserType);
        propertyReader.loadCustomProperties("config/connexus/");
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
    }


    @Override
    public void searchPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickExitPMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickExit();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }

    }
    public void handleControlIdSubstanceForControlledDrugPopup(){
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
    }

    public void clickExitPMSWithAbondonPopUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickExit();
            if (patientMaintenancePage.isYesDisplayed()) {
                patientMaintenancePage.clickYes();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void openTascoPage(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            tascoPage.launchTascoScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void searchPatientInTasco(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            tascoPage.inputPatientLastName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.pressKeys(KeyEvent.VK_ENTER);
            tascoPage.clickSearchOnTascoPage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void patientProfileInTascoPage(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            tascoPage.clickSubRow();
            tascoPage.clickMenuPatientProfile();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void mandatoryFieldsGeneralInformation(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertNotNull(patientMaintenancePage.getLastNameText());
            Assert.assertNotNull(patientMaintenancePage.getFirstNameText());
            Assert.assertNotNull(patientMaintenancePage.getDobText());
            Assert.assertNotNull(patientMaintenancePage.getStateText());
            Assert.assertNotNull(patientMaintenancePage.getAddressLineText());
            Assert.assertNotNull(patientMaintenancePage.getCityText());
            Assert.assertNotNull(patientMaintenancePage.getZipText());
            Assert.assertNotNull(patientMaintenancePage.getLanguageText());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void lastNameDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            Assert.assertFalse(patientMaintenancePage.isLastNameEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void firstNameDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isFirstNameEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void middleNameDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isMiddleNmaeEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void dateOfBirthDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isDobEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void genderDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isFemaleRadioButtonEnabled());
            Assert.assertFalse(patientMaintenancePage.isMaleRadioButtonEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void weightDisabledPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isWeightEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void allergyRadioButtonsDisabled(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isAllergiesYesEnabled());
            Assert.assertFalse(patientMaintenancePage.isAllergiesNoEnabled());
            Assert.assertFalse(patientMaintenancePage.isAllergiesPatientNotPresentEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void medicalRadioButtonsDisabled(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertFalse(patientMaintenancePage.isMCyesRadioEnabled());
            Assert.assertFalse(patientMaintenancePage.isMCnoRadioEnabled());
            Assert.assertFalse(patientMaintenancePage.isMCpatientNotPresentEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void otherMedicationsDisabledInProfile(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickTabProfile();
            Assert.assertFalse(patientMaintenancePage.isServiceDetailsEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void serviceDetailsDisabledInClinicalServices(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickClinicalServicesTab();
            Assert.assertFalse(patientMaintenancePage.isServiceDetailsEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void allergyDisabledInAlleryMedicalConditions(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickAllergyMedicalTab();
            Assert.assertFalse(patientMaintenancePage.isAllergyGridEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void medicalDisabledInAlleryMedical(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickAllergyMedicalTab();
            Assert.assertFalse(patientMaintenancePage.isMedicalGridEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void openHIPAAPage(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            tascoPage.launchTascoHippaScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void patProfileInHIPAA(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            tascoPage.clickSubRow();
            tascoPage.clickHippaPatProfile();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void dropAnRxTillPickUp(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();

        String[] name = connexusAppUtils.readPatientNameFromFile();

        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);


        String rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
    }

    public void patientProfileInPseudophedrine(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(2);
            tascoPage.clickPatientProfileInPseudophedrine();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateAbandonPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.isTitleDisplayed();
            if (patientMaintenancePage.isYesDisplayed()) {
                Reporter.log("Unexpected Pop Ups appeared on Screen");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickYes();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void searchPatientInDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusStartPage.getTextFromAppTitleBar(0).contains("Connexus");
            automationManager.performSleep(2);
            dropOffPage.dropOffSearchShortCutKeys();
            dropOffPage.dropOffSearchPatientName(inputData);
            automationManager.performSleep(5);
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void clickFolderIconInDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            dropOffPage.clickPatientMaintenanceIcon();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void closeDropOffScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(2);
            dropOffPage.clickBtnCancel();
            dropOffPage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to search the rx in search window and click on fourpoint queue
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */

    public void selectFourPointRxInSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            int counter = 0;
            do {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                counter++;
            }
            while ("DUR".equalsIgnoreCase(orderSearch.getWorkQueue(0)) && counter <= 4);
            if (orderSearch.getPatientName(0).equals(name[0] + "," + name[1]) && "4 Point".equals(orderSearch.getWorkQueue(0))) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + orderSearch.getWorkQueue(0), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured= true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName + " " + orderSearch.getWorkQueue(0), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to navigate to Current Rx->Rx Notes... in fourpoint screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void navigateToRxNotesInFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToRxNotesMenuItem();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to click and clear the text in rx notes in fourpoint screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickAndClearRxSearchTextInFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickRxSearchTextBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clearRxSearchTextBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to press tab get the value of rx notes in fourpoint screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateRxTextBoxInFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.pressTabKey();
            fourPoint.rxSearchTextBoxValue();
            if ("Keyword, Product Name, Date, Rx# . . .".equals(fourPoint.rxSearchTextBoxValue())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + fourPoint.rxSearchTextBoxValue(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName + " " + fourPoint.rxSearchTextBoxValue(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to click Exit in  rx notes window of fourpoint screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickExitInRxNotesOfFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickButtonCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to click cancel in fourpoint screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickCancelInFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fourPoint.clickButtonCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate both the insulin dependent and insulinPump checkboxes are not present in Allergy tab of PMS screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateNoInsulinCheckBoxesInPMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAllergyMedicalTab();
            Assert.assertFalse(patientMaintenancePage.isChkInsulinDependentDisabledInAllergy());
            Assert.assertFalse(patientMaintenancePage.isChkInsulinPumpDisplayedInAllergy());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate common_seq_nbr column contains 1,2,10,20
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateCommSeqNbrForPhone1InDb() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastName = name[0];
            String firstName = name[1];
            String query = "select * from subject_comm sub inner join patient pat on sub.subject_id = pat.patient_id  where\n" +
                    "last_Name =\"" + lastName + "\" and first_name= \"" + firstName + "\"";
            List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
            for (Map<String, Object> resultMap : resultSet) {
                if (resultMap.get("comm_seq_nbr").toString().matches("1|2|10|20")) {
                    Reporter.log(resultMap.get("comm_seq_nbr").toString());
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate phone1 is displayed in search grid
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validatePhone1InPatientSearch(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actualPhone = patientSearchPage.getPhoneNbrFromSearchGrid(0);
            actualPhone = actualPhone.replaceAll("[^0-9]+", "");
            String expected=inputData.get("PRIMARY_NUMBER");
            Assert.assertEquals(actualPhone, expected);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to click Save and Close button in PMS screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickSaveAndCloseInPMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to enter mobile number in messaging field in PMS screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void enterNumberInMessagingSelectTextPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.inputMessaging(inputData.get("TEXT_MESSAGING_NUMBER"));
            patientMaintenancePage.clickMessagingTextRdBtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the  pop up message "You have selected to enroll this number into text messaging. Please enter a valid mobile number."
     * for valid landline number
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateTextMessagingValidLandlinePopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(patientMaintenancePage.getInvalidSsnPopupText(), "You have selected to enroll this number into text messaging. Please enter a valid mobile number.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    

    /*
     * Method to validate the  pop up message "You have selected to enroll this number into text messaging. Please enter a valid mobile number."
     * for valid landline number
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateTextMessagingInvalidLandlinePopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(patientMaintenancePage.getInvalidSsnPopupText(), "Invalid number. Please provide a valid phone number.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the  activity_comment column  containing AuditEntry Name=Patient ID" Value="117355" /><AuditEntry Name="Validate Landline in PMS" Value="3109974177" /
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void validateXmlOfActivityColumnInDb(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String textMessagingNumber = inputData.get("TEXT_MESSAGING_NUMBER");
            String userId = propertyReader.getProperty("cnx.ho.userName").toUpperCase();
            String query = "select * from error_and_audit:appl_activity where userid='" + userId
                    + "' and activity_comment like '%Validate Landline in PTMS%'"
                    + " order by 1 desc limit 1";
            Reporter.log("DB validation query: " + query);

            boolean landlineAuditFound = false;
            int maxRetries = 3;
            for (int attempt = 1; attempt <= maxRetries; attempt++) {
                List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
                Reporter.log("Attempt " + attempt + ": found " + resultSet.size() + " rows");

                for (Map<String, Object> resultMap : resultSet) {
                    String activityComment = resultMap.get("activity_comment").toString();
                    if (activityComment.contains(textMessagingNumber)) {
                        Reporter.log("Landline validation audit entry found: " + activityComment);
                        landlineAuditFound = true;
                        break;
                    }
                }

                if (landlineAuditFound) {
                    break;
                }
                if (attempt < maxRetries) {
                    Reporter.log("Audit entry not found yet, retrying in 5 seconds...");
                    automationManager.performSleep(5);
                }
            }

            if (!landlineAuditFound) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.fail("Landline validation audit entry not found in DB for user: " + userId
                        + " with TEXT_MESSAGING_NUMBER: " + textMessagingNumber
                        + " after " + maxRetries + " attempts");
            }
            softAssert.assertAll();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
  * This method presses f6 key and selects Four Point Search Type in Order search dropdown
  *
  * Author: Lakshmi Priya(vn510nm)
  ----------------------------------------------------------------------------------------------------------*/
    public void open4PointOrderSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.FourPoint);
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            softAssert.assertAll();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method double clicks on first rx in Order search
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void selectRxFromSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.performSleep(10);
        try {
            orderSearch.openFirstPatientRecord();
            automationManager.performSleep(5);
            orderSearch.clickYes();
            if (orderSearch.isAddressValidateViewPopUpDisplayed()) {
                orderSearch.clickAccept();
                orderSearch.isValidationPopUPDisplayed();
            }
            if (orderSearch.isConnexusPopUpDisplayed()) {
                inputPage.clickButtonOk();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on view patient information folder icon in four point screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnFolderIconOn4Point(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            fourPoint.clickPatientMaintenanceIcon();
            patientMaintenancePage.isGeneralInfoTabDisplayed();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Exit button in ptms screen. It handles floating pop ups in ptms screen,
     * if patient profile does not have preferred phone number or Allergic conditions selected already.
     * It exits from four point screen by clicking cancel button on screen.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void exitPatientMaintenance(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickExit();
            if (patientMaintenancePage.isYesDisplayed()) {
                patientMaintenancePage.clickYes();
            }
            fourPoint.clickButtonCancel();
            fourPoint.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*---------------------------------------------------------------------------------------------------------
     * This method presses f6 key and selects Filling Search Type in Order search dropdown
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openFillingOrderSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.Filling);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * This method clicks on view patient information folder icon in modified details screen
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void clickOnFolderModifiedDetails(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.performSleep(2);
        try {
            modifyDetails.clickPatientMaintenanceIcon();
            patientMaintenancePage.isGeneralInfoTabDisplayed();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Exit button in ptms screen. It handles floating pop ups in ptms screen
     * if patient profile does not have preferred phone number or Allergic conditions selected already.
     * It exits from Modified Details screen by pressing Escape Keys
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void exitPatientMaintenanceUsingExitBtn(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(2);
            patientMaintenancePage.clickExit();
            if (patientMaintenancePage.isNoDisplayed()) {
                patientMaintenancePage.clickNo();
                patientMaintenancePage.exitFromScreenUsingEscape();
                patientMaintenancePage.clickNo();
            }
            modifyDetails.exitFromScreen();
            modifyDetails.clickYes();
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*---------------------------------------------------------------------------------------------------------
     * This method presses f6 key and selects Visual Verify Search Type in Order search dropdown
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openVisVerOrderSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.VisualVerify);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------

  * The below method validates the SSN which starts from the range 900-999 entered in the SSN input field in PMS screen
  * The method validates whether on entering the SSN with the precondition value displays the appropriate Error popup message
  * Invalid social security number.Please re-enter.
  * Author: Tarun(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    public void patientMaintenancePageSsnValidation(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String actualmessage = inputData.get("MESSAGE");
            String regex = "^[9]{1}[0-9]{8}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(inputData.get("FSN"));
            Assert.assertTrue(m.matches());
            Reporter.log("SSN starts with 9 an first three digits is in between 900-999");
            long ssn = Long.parseLong(inputData.get("FSN"));
            patientIdentityModel.setPatientSSNNumber(ssn);
            patientProfileModel.setPatientIdentityModel(patientIdentityModel);
            patientMaintenancePage.inputSsn(patient);
            automationManager.performSleep(5);
            String popupmessage = patientMaintenancePage.getInvalidSsnPopupText();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(popupmessage, actualmessage);
            Reporter.log("Invalid SSN message is being displayed and has been successfully validated");
            patientMaintenancePage.clickOk();
            Assert.assertTrue(patientMaintenancePage.hasKeyboardFocusOnSSNField());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * This method clicks on view patient information folder icon in Visual Verify screen
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void clickOnFolderIconOnVisVer(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            visVerPage.clickPatientMaintenanceIcon();
            patientMaintenancePage.isGeneralInfoTabDisplayed();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method presses Escape Keys to exit from ptms scren. It handles floating pop ups in ptms screen,
     * if patient profile does not have preferred phone number or Allergic conditions selected already.
     * It exits from Modified Details screen by pressing Escape Keys
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void exitFromPatientMaintenanceUsingEscKeys(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickTxtLastName();
            automationManager.performSleep(5);
            patientMaintenancePage.exitFromScreenUsingEscape();
            patientMaintenancePage.isValidationPopup();
            automationManager.performSleep(5);
            modifyDetails.exitFromScreen();
            modifyDetails.clickYes();
            automationManager.performSleep(10);
            visVerPage.clickCancel();
            visVerPage.clickYes();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------

 * The below method validates the SSN which starts with the first 3 Digits as 6 when entered in the SSN input field in PMS screen
 * The method validates whether on entering the SSN with the precondition value displays the appropriate Error popup message
 * Invalid social security number.Please re-enter.
 * Author: Tarun (vn510o1)
 ----------------------------------------------------------------------------------------------------------*/
    public void patientSearchPageSsnValidationFirst3Digits(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String actualmessage = inputData.get("MESSAGE");
            String regex = "^[6]{3}[0-9]{6}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(inputData.get("FSN1"));
            Assert.assertTrue(m.matches());
            Reporter.log("SSN starts with three 6 digit followed by six number of any of the digits between 0-9");
            String pmshometext = patientMaintenancePage.getPmsScreenHeaderText();
            String expected = inputData.get("HEADER_TEXT");
            Assert.assertEquals(expected, pmshometext);
            Reporter.log("PMS home page is displayed");
            long ssn = Long.parseLong(inputData.get("FSN1"));
            patientIdentityModel.setPatientSSNNumber(ssn);
            patientProfileModel.setPatientIdentityModel(patientIdentityModel);
            patientMaintenancePage.inputSsn(patient);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String popupmessage = patientMaintenancePage.getInvalidSsnPopupText();
            Assert.assertEquals(popupmessage, actualmessage);
            Reporter.log("Invalid SSN message is being displayed and has been successfully validated");
            patientMaintenancePage.clickOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method presses Alt+E Keys to exit from ptms screen.
     * It exits from Modified Details screen by pressing Escape Keys
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void exitPatientMaintenanceUsingAltEKeys(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickTxtLastName();
           // automationManager.performSleep(2);
            connexusStartPage.inputShortcutKeysForPMS();
            if (patientMaintenancePage.isYesDisplayed()) {
                patientMaintenancePage.clickYes();
            }
            modifyDetails.exitFromScreen();
            modifyDetails.clickYes();
            inputPage.clickCancel();
            inputPage.clickYes();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*---------------------------------------------------------------------------------------------------------
     * This method presses f6 key and selects PickUp Search Type in Order search dropdown
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openPickUpOrderSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.PickUp);
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void searchForPOSOrders(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.Pos);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at POS order search");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*---------------------------------------------------------------------------------------------------------
     * This method presses f6 key and selects Input Search Type in Order search dropdown
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openInputOrderSearch(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            orderSearch.performSearch("", SearchType.Input);
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------

   * The below method validates the SSN which has 00 in between the SSN when the value has been inserted in the SSN input  field in PMS screen
   * The method validates whether on entering the SSN with the precondition value displays the appropriate Error popup message
   * Invalid social security number.Please re-enter.
   * Author: Suga Priya(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void verifyInvalidSSN(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String message = inputData.get("MESSAGE");
        try {
            String regex = "^[0-9]{3}[0]{2}[0-9]{4}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(inputData.get("FSN2"));
            Assert.assertTrue(m.matches());
            Reporter.log("SSN with middle to digit as '00'");
            String pmshometext = patientMaintenancePage.getPmsScreenHeaderText();
            String expected = inputData.get("HEADER_TEXT");
            Assert.assertEquals(expected, pmshometext);
            Reporter.log("PMS home page is displayed");
            long ssn = Long.parseLong(inputData.get("FSN2"));
            patientIdentityModel.setPatientSSNNumber(ssn);
            patientProfileModel.setPatientIdentityModel(patientIdentityModel);
            patientMaintenancePage.inputSsn(patient);
            String messageLabel = patientMaintenancePage.getInvalidSsnPopupText();
            Reporter.log(messageLabel);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(message, messageLabel);
            Reporter.log("Invalid SSN message is being displayed and has been successfully validated");
            patientMaintenancePage.clickOk();
            Assert.assertTrue(patientMaintenancePage.hasKeyboardFocusOnSSNField());
            Reporter.log("Cursor is at SSN field");

        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * This method clicks on view patient information folder icon in Input screen
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void clickOnFolderIconOnInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickPatientMaintenanceIcon();
            patientMaintenancePage.isGeneralInfoTabDisplayed();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
    * This method validates the Patient License Number and License Date on ptms screen across DL records in Database tables
    *
    * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    public void validatePatientLicenseInDB(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(5);
            String licenseQuery = "select patient_reference.patient_id, patient_reference.reference_nbr, patient_reference.expiration_date " +
                    "from patient_reference inner join patient on patient_reference.patient_id=patient.patient_id " +
                    "where last_name=\"" + name[0].toUpperCase() + "\" and first_name=\"" + name[1].toUpperCase() + "\" order by patient_id desc limit 1";
            Map<String, Object> patientDetails = automationManager.getConnexusDB().executeQuery(licenseQuery);
            String actualLicenseNOFromDB = patientDetails.get("reference_nbr").toString().trim();
            Assert.assertEquals(actualLicenseNOFromDB, inputData.get("LICENSE_NUMBER"));
            String licenseDateFromDB = patientDetails.get("expiration_date").toString();
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-mm-dd");
            SimpleDateFormat format2 = new SimpleDateFormat("dd/mm/yyyy");
            String actualLicenseDateFromDB = format2.format(format1.parse(licenseDateFromDB));
            Assert.assertEquals(actualLicenseDateFromDB, inputData.get("LICENSE_EXPIRATION_DATE"));
            Reporter.log("Patient Expected License Number : " + inputData.get("LICENSE_NUMBER"));
            Reporter.log("Patient Actual License Number : " + actualLicenseNOFromDB);
            Reporter.log("Patient Expected License Expiry Date : " + inputData.get("LICENSE_EXPIRATION_DATE"));
            Reporter.log("Patient Actual License Expiry Date : " + actualLicenseDateFromDB);
            Reporter.log("Patient License details are validated");
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------

   * The below method validates the SSN which ends with 0000, when the value has been inserted in the SSN input field in PMS screen
   * The method validates whether on entering the SSN with the precondition value displays the appropriate Error popup message
   * Invalid social security number.Please re-enter.
   * Author: Suga Priya(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
    public void verifyLastInvalidSSN(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String message = inputData.get("MESSAGE");
        try {
            String regex = "^[0-9]{5}[0]{4}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(inputData.get("FSN3"));
            Assert.assertTrue(m.matches());
            Reporter.log("SSN ends with '0000'");
            String pmshometext = patientMaintenancePage.getPmsScreenHeaderText();
            String expected = inputData.get("HEADER_TEXT");
            Assert.assertEquals(expected, pmshometext);
            Reporter.log("PMS home page is displayed");
            long ssn = Long.parseLong(inputData.get("FSN3"));
            patientIdentityModel.setPatientSSNNumber(ssn);
            patientProfileModel.setPatientIdentityModel(patientIdentityModel);
            patientMaintenancePage.inputSsn(patient);
            String messageLabel = patientMaintenancePage.getInvalidSsnPopupText();
            Reporter.log(messageLabel);
            Assert.assertEquals(message, messageLabel);
            Reporter.log("Invalid SSN message is being displayed and has been successfully validated");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
            Assert.assertTrue(patientMaintenancePage.hasKeyboardFocusOnSSNField());
            Reporter.log("Cursor is at SSN field");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Mailing Address Tab on Patient maintenance Screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public boolean clickOnMailingAddressTab() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickMailingAddressTab();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return false;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Temporary Address Tab on Patient maintenance Screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public boolean clickOnTemporaryAddressTab() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTemporaryAddressTab();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            return true;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return false;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Shipping Address Tab on Patient maintenance Screen
     * Note: Shipping Address tab is present only on mail order stores
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public boolean clickOnShippingAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (patientMaintenancePage.isShippingAddressTab()) {
                patientMaintenancePage.clickShippingAddressTab();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                return true;
            } else {
                return false;
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return false;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters address of the patient on Patient maintenance Screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterPatientAddress(Map<String, String> inputData, boolean flag) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (flag) {
                patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS"));
                patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
                if (patientMaintenancePage.isOkDisplayed()) {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                    patientMaintenancePage.clickOk();
                    Reporter.log("On Selecting Zip code City and State arent auto populated and validation service found to be down");
                    patientMaintenancePage.inputCity(inputData.get("CITY"));
                    patientMaintenancePage.selectState(inputData.get("STATE"));
                    patientMaintenancePage.selectCountry(inputData.get("COUNTRY"));
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes Patient maintenance Screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closePatientMaintenance() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientMaintenancePage.clickSaveAndClose();
            int counter = 0;
            while (patientMaintenancePage.isSaveAsEnteredDisplayed() && counter < 3) {
                patientMaintenancePage.clickSaveAsEntered();
                counter++;
            }
            if (patientSearchPage.isPatientRecordDisplayed(0)) {
                patientSearchPage.clickClose();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters details of Shipping Address and Payment Method in Order Details Window once rx is dropped off.
     * Order Details information given in drop off is specific to on Mailing Order stores only.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void completeAndValidateShippingPaymentOrder(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (orderDetailsPage.isShippingInfoLabelDisplayed()) {
                orderDetailsPage.selectShippingAddress(0);
                orderDetailsPage.selectCheckPaymentType();
                orderDetailsPage.inputCheckNumber(inputData.get("CHECK_NUMBER"));
                orderDetailsPage.inputCheckAmount(inputData.get("CHECK_AMOUNT"));
                orderDetailsPage.clickAccept();
                String[] name = connexusAppUtils.readPatientNameFromFile();
                String createdPatientName = name[0] + "," + name[1];
                Map<String, Object> orderDetails = automationManager.getConnexusDB().executeQuery("select * from phm_pk_shipping where ship_to_name=\"" + createdPatientName + "\"");
                String[] patientNameFromDB = orderDetails.get("ship_to_name").toString().split(",");
                Reporter.log("The Shipping Order for the Patient " + patientNameFromDB[1] + " " + patientNameFromDB[0] + " is created successfully in mail order store");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderDetailsPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Store selected for Shipping Order must be mail order store");
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, orderDetailsPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderDetailsPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the ndc number of the drug having compound drug type from sheet for the column NDC_NUMBER2
     * and returns in string
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String setCompoundDrugType(Map<String, String> inputData) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            return inputData.get("NDC_NUMBER2");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderDetailsPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the ndc number of the drug having Normal drug type from sheet for the column NDC_NUMBER1
     * and returns in string
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String setNormalDrugType(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            return inputData.get("NDC_NUMBER1");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderDetailsPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method inputs ndc number of any drug type, quantity, Sig Code, refills from Data Sheet for rx present
     * in Connexus Application
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void performInputForRx(Map<String, String> inputData, String drugName) {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(drugName);
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while performing input ");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets drug name on Consolidated Notes window from 4 point screen by navigating to Current rx -> Rx Notes
     * in menu bar for any random number 0, 1.
     * 0-> Launch 4 point for Normal Drug ;  1 -> Launch 4 point for Compound Drug
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void launch4PointAndValidateRxNotes() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String  rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                orderSearch.openSecondPatientRecord();
                Reporter.log("Rx for Compound Drug is opened in 4 point");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                menuBar.launchRxNotesScreen();
                String compoundDrugName = consolidatedNotesPage.getDrugName();
                String compoundTextFromCompoundDrug = compoundDrugName.substring(0, 8);
                Reporter.log("Complete Dispensed drug name: " + compoundTextFromCompoundDrug + " is displayed for the drug " + compoundDrugName + " on the RX Note on Consolidated Notes Screen");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while launching Rx Notes");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes Consolidated Notes window and 4 point Screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeRxNotesAnd4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            consolidatedNotesPage.clickCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, consolidatedNotesPage.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickButtonCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, consolidatedNotesPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while closing Rx Notes or four point");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, consolidatedNotesPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the random controlled drug name from pharmacy product and pharmacy item tables for the respective
     * controlled drug class 2/3/4/5. Returns the drug name
     *
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String getControlledDrugName() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String drugName = "";
        try {
            Random random = new Random();
            int action = random.nextInt(4);
            switch (action) {
                case 0:
                    //gets drug name details for c2 drug type
                    Map<String, Object> c2DrugDetails = automationManager.getConnexusDB().executeQuery("select ndc_nbr, on_hand_qty, product_name, short_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: pharmacy_item pi \n" +
                            "where pp.product_mds_fam_id=pi.product_mds_fam_id and drug_control_code=2300 \n" +
                            "limit 1");
                    drugName = c2DrugDetails.get("short_name").toString().trim();
                    break;
                case 1:
                    //gets drug name details for c3 drug type
                    Map<String, Object> c3DrugDetails = automationManager.getConnexusDB().executeQuery("select ndc_nbr, on_hand_qty, product_name, short_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: pharmacy_item pi \n" +
                            "where pp.product_mds_fam_id=pi.product_mds_fam_id and drug_control_code=2301 \n" +
                            "limit 1");
                    drugName = c3DrugDetails.get("short_name").toString().trim();
                    break;
                case 2:
                    //gets drug name details for c4 drug type
                    Map<String, Object> c4DrugDetails = automationManager.getConnexusDB().executeQuery("select ndc_nbr, on_hand_qty, product_name, short_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: pharmacy_item pi \n" +
                            "where pp.product_mds_fam_id=pi.product_mds_fam_id and drug_control_code=2302 \n" +
                            "limit 1");
                    drugName = c4DrugDetails.get("short_name").toString().trim();
                    break;
                case 3:
                    //gets drug name details for c5 drug type
                    Map<String, Object> c5DrugDetails = automationManager.getConnexusDB().executeQuery("select ndc_nbr, on_hand_qty, product_name, short_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: pharmacy_item pi \n" +
                            "where pp.product_mds_fam_id=pi.product_mds_fam_id and drug_control_code=2303 \n" +
                            "limit 1");
                    drugName = c5DrugDetails.get("short_name").toString().trim();
                    break;
            }
            return drugName;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    public String getDrugName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String drugName = inputData.get("DRUG_NAME");
            return drugName;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method sets the restrict_type_val = ‘Y’ in agency_rqmt_parm table where restrict_type_code=2579 in local store DB
     * for the current store state.
     * This is applicable for only for tc_04_Authentication_Pop_up_is_displayed_on_modifying_the_Controlled_on_hand_quantity_by_Pharmacist_Temp_Pharmacist
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void setPreconditionOnAgencyReqParmTable() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // Pre condition 1/2: Step3: for tc_04_Authentication_Pop_up_is_displayed_on_modifying_the_Controlled_on_hand_quantity_by_Pharmacist_Temp_Pharmacist
            // gets agency Requirement table details for restrict type code = 2579 for the current State Code
            Map<String, Object> agencyRqmtDetails = automationManager.getConnexusDB().executeQuery("select * from agency_rqmt_parm where restrict_type_code = 2579 and issue_agency_code =\n" +
                    "(select issue_agency_code from issuing_agency where issue_agency_abbr = (select state from bus_unit_addr));");
            String restrictTypeValue = agencyRqmtDetails.get("restrict_type_val").toString();
            if (!"Y".equalsIgnoreCase(restrictTypeValue)) {
                automationManager.getConnexusDB().executeUpdateQuery("update agency_rqmt_parm set restrict_type_val=\"Y\" where restrict_type_code =2579 and issue_agency_code =\n" +
                        "(select issue_agency_code from issuing_agency where issue_agency_abbr = (select state from bus_unit_addr))");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method launches the product search screen on application
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void launchProductSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
               productSearchPage.launchProductSearchScreen();
               if (productSearchPage.productSearchFlagValueCheck()) {
                productSearchPage = new ProductSearchPage();
               }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method inputs the drug name into product search screen and opens the product maintenance screen for the selected drug.
     * It validates the dea class of the drug across db and on the product maintenance screen.
     * Input: drug name from getControlledDrugName()
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void InputDrugInProductScreenAndValidateDea(Map<String, String> inputData, String drugNameFromDb) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String newDrugName = inputData.get("DRUG_NAME1");
            // if randomly selected 'drugName' from getControlledDrugName() available in DB is not available in store
            // then below method will get the drugname that is commonly available in all stores from "DRUG_NAME1" in Data Sheet
            while (!productMaintenancePage.isAcceptDisplayed()) {
                if (!productSearchPage.getProductSearchResult().contains("0 record")) {
                    productSearchPage.enterProductName(drugNameFromDb);
                    productSearchPage.clickSearchNow();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    productSearchPage.clearProductName();
                    productSearchPage.enterProductName(newDrugName);
                    productSearchPage.clickSearchNow();
                    drugNameFromDb = newDrugName;
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                }
                productSearchPage.doubleClickOnSearchGridRow(0);
            }
            // The below query gets the drug class value for the drug generated randomly from getControlledDrugName()
            Map<String, Object> getDrugDetailsFromDb = automationManager.getConnexusDB().executeQuery("select dc.drug_control_abbr, pp.product_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: drug_control_text dc \n" +
                    "where pp.drug_control_code=dc.drug_control_code and pp.short_name=\"" + drugNameFromDb + "\" limit 1");
            String drugDeaClass = getDrugDetailsFromDb.get("drug_control_abbr").toString().trim();
            String drugName = getDrugDetailsFromDb.get("product_name").toString().trim();
            Reporter.log("Drug class of the Product " + drugName + " is: " + drugDeaClass);
            String DEAValueUi=productMaintenancePage.getDEAValue();
            if (DEAValueUi.equalsIgnoreCase(drugDeaClass)) {
                deaClassValueSetFlag = true;
            }
            if (deaClassValueSetFlag) {
                Reporter.log("The expected DEA class " + drugDeaClass + " of the Product " + drugName + " is available in Product Maintenance Screen");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets onhand drug quantity available in product maintenance screen; returns on hand quantity value
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String getOnHandDrugQtyFromProductMaintenance() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String onHandDrugQty;
        try {
            onHandDrugQty = productMaintenancePage.getOnHandDrugQuantityFromItemSearchGrid(0);
            Reporter.log("The On hand Quantity of the drug is " + onHandDrugQty);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            return onHandDrugQty;
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method double clicks the drug on product maintenance screen and launches Item maintenance screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void openItemMaintenanceScreen() {
        productMaintenancePage.openItemMaintenanceScreen();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method changes the on hand drug quantity on IMS screen. It verifies the rph authentication pop up
     * and authenticates the drug quantity change
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void changeOnHandDrugQtyOnIMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Random random = new Random();
        try {
            ItemMaintenancePage itemMaintenancePage = new ItemMaintenancePage();
            itemMaintenancePage.clickOnItemsGridRow(0);     // was: ClickOnItemsGridRow
            itemMaintenancePage.clearOnHandDrugQty();
            itemMaintenancePage.inputOnHandDrugQty(String.valueOf(random.nextInt(10000)));
            itemMaintenancePage.clickAccept();

            // NOTE:
            // 28750 flag is deprecated, so credential selection is user-based now.
            // We can rely on `this.loginUserType` (set in loginConnexus(userType)).
            // Without updating loginUserType during re-login, the flow may incorrectly use HO password.
            if (this.loginUserType == LoginAs.userType.PHARMACIST_ADFlagOn) {
                // Pharmacist session -> use RPH password
                itemMaintenancePage.inputRphPasswordOnRphVerifyPopUp();
                itemMaintenancePage.inputStoreNumOnRphVerifyPopUp();
            } else if (this.loginUserType == LoginAs.userType.HOMEOFFICE_ADFlagOn) {
                // Home Office session -> use HO password
                itemMaintenancePage.inputHoPasswordOnRphVerifyPopUp();
                itemMaintenancePage.inputStoreNumOnRphVerifyPopUp();
            } else {
                Assert.fail("Unexpected loginUserType '" + this.loginUserType
                        + "' on RPH verify popup. Use PHARMACIST_ADFlagOn or HOMEOFFICE_ADFlagOn.");
            }
            itemMaintenancePage.clickAcceptOnRphVerifyPopUp();


            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Hazardous waste adjustment reason to change the drug quantity
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void handleAdjustmentReasonForRph() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            c2LogBookAdjustmentReasonPage.clickHazWasteAdjustmentReason();
            c2LogBookAdjustmentReasonPage.clickContinue();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * Home Office users are not authenticated to change the on hand drug quantity. This method handles the rph
     * authentication pop up for Home office Users
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void handleAdjustmentReasonForHomeOffice() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.log("Home User is not allowed to modify On hand drug Quantity");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            itemMaintenancePage.clickOk();
            itemMaintenancePage.closeRphPopUp();
            itemMaintenancePage.clickOk();
            itemMaintenancePage.clickCancelButton();
            itemMaintenancePage.clickYes();
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes the product maintenance screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeProductMaintenanceScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productMaintenancePage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the change in on hand drug quantity by the pharmacist
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateChangeInOnHandDrugQuantity(String oldDrugQty, String newDrugQty) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertNotEquals(oldDrugQty, newDrugQty);
            Reporter.log("Product Screen is displayed with the new on hand Drug Quantity " + newDrugQty + " in On-Hand field");
            c2LogBookAdjustmentReasonPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates on hand drug quantity text box is disabled for the Technician
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyDisabledOnHandDrugQuantity() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertFalse(itemMaintenancePage.isOnHandDrugQuantityEnabled());
            Reporter.log("On-Hand quantity field on Item Maintenance Page is disabled for the Pharmacist");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes the Item maintenance screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeItemMaintenance() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            itemMaintenancePage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createPatientFromDropoffScreen(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName("");
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.clickNew();
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
            patientMaintenancePage.selectGender(PatientProfileModel.PatientGender.MALE);
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS"));
            patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.inputPrimaryPhoneNumber(inputData.get("PHONE_NUMBER1"));
            patientMaintenancePage.setPatientAllergy(PatientMedicalConditionModel.Allergies.NO);
            patientMaintenancePage.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.clickSaveAsEntered();
    }catch (Throwable e){
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public  void dropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            DropRxModel dropRxModel = new DropRxModel();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickScanNewRx();
            String barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            dropOffPage.clickBtnAccept();
            dropOffPage.clickVerifyBarCode();
            dropOffPage.selectListItemfromRxOriginType();
            dropOffPage.clickBtnAccept();
            dropOffPage.addNoOfRx(barCode, 1);
            dropOffPage.selectPriority(Priority.Critical.getPriority());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        }catch (Throwable e){
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void updatePatientLS_FS_DOB_SSN(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0]+","+name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            connexusAppUtils.addRandomNamesInFile();
            String[] updateName = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.updatePatientLastname(updateName[1]);
            patientSearchPage.updatePatientFirstname(updateName[0]);
            patientSearchPage.updatePatientSSN(inputData.get("Updated_SSN"));
            patientSearchPage.clickOKOnErrorPopUp();
            patientSearchPage.updatePatientSSN(inputData.get("Updated_SSN"));
            patientSearchPage.updatePatientDOBNew(inputData.get("Updated_DOB"));
            patientSearchPage.clickSaveAndClose();
            patientMaintenancePage.clickSaveAsEntered();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }
    public void enterConsolidatedNote(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
           patientMaintenancePage.inputCommentInConsolidatedNotesWindow(inputData.get("Update_Comment"));
           patientMaintenancePage.clickSave();
            Reporter.logScreenShot(currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }
    public void verifyPatient_LS_FN_DOB_SSN_Updated(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name1 = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name1[1]+","+name1[0]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            if(patientSearchPage.getPatientLastname().equalsIgnoreCase(name1[1])){
                Reporter.log("LN matched");
            }else{
                Reporter.log("LN not matched");
                Assert.fail("LN not matched");
            }
            if( patientSearchPage.getPatientFirstname().equalsIgnoreCase(name1[0])){
                Reporter.log("FN matched");
            }else{
                Reporter.log("FN not matched");
                Assert.fail("FN not matched");
            }
            if(inputData.get("Updated_SSN").contains(patientSearchPage.getPatientSSN())){
                Reporter.log("SSN matched");
            }else{
                Reporter.log("SSN matched");
                Assert.fail("SSN not matched");
            }
            String str1 = inputData.get("Updated_DOB").replaceAll("[^a-zA-Z0-9]", "");
            String str2= patientSearchPage.getUpdatedPatientDOB().replaceAll("[^a-zA-Z0-9]", "");
            if(str1.equals(str2)){
                Reporter.log("DOB matched");
            }
            else{
                Reporter.log("DOB matched");
                Assert.fail("DOB not matched");
            }
            Reporter.logScreenShot(currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickSaveAndClose();
            patientMaintenancePage.clickSaveAsEntered();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void verifyConsidatedNotes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name1 = connexusAppUtils.readPatientNameFromFile();
        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name1[1]+","+name1[0]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickNotesButton();
            String conNotes = "";
            for (int j = 0; j <= patientMaintenancePage.getNotesCount().size() - 1; j++) {
                String notes = patientMaintenancePage.getNotesCount().get(j).getAttribute("Value.Value");
                conNotes = conNotes + notes;
            }
            String consolidatedNotes = conNotes.toLowerCase().trim();
            Reporter.logScreenShot(currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (consolidatedNotes.contains(inputData.get("Update_Comment").toLowerCase())) {
                Reporter.log("Notes matched");
            } else {
                Reporter.log("Notes matched");
                Assert.assertFalse(false, "Notes not matched");
            }
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickCancel();
            patientMaintenancePage.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log(e.getLocalizedMessage());
            Reporter.logScreenShot(currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void selectRxFromSearchForPOS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            //f6Search.openFirstPatientRecordForPOS();
            orderSearch.openFirstPatientRecord();
            automationManager.performSleep(5);
            if(orderSearch.isAddressValidateViewPopUpDisplayed()){
                orderSearch.clickAccept();
            }
            if(orderSearch.isConnexusPopUpDisplayed()){
                inputPage.clickButtonOk();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method searches the Patient with Last Name, First Name which has been already created
     * by clicking on CONTROL+SHIFT+P and Search Now Button
     * It then navigates to the Patient Maintenance screen by double clicking on the found record
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void searchPatientWithName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            int counter = 0;
            while (patientMaintenancePage.isGeneralInformationTabDisplayed() && counter <= 3) {
                patientMaintenancePage.clickPatientMaintenanceIcon();
                counter++;
            }
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void openPseudoephedrine(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.launchTascoPseudophedrineScreen();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void clickExitHIPAA(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.clickExitTascoHIPAAPseudophedrine();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured= true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void clickExitInTasco(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.clickExitInTasco();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
}
