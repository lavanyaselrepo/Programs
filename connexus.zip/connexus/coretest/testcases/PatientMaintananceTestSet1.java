package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintananceTestSet1 {
    PatientSearchTestSetScript patientSearchTestSetScript = new PatientSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Brand Only Patient Preference
     * JIRA: HWPHME2E-2260
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "\"Validate Brand Only Patient Preference\"",
            enabled = true, priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
        public void HWPHME2E_2260_validate_Brand_Only_Patient_Preference(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientSearchWindow();

        patientSearchTestSetScript.addPatienTPreference(inputData);

        patientSearchTestSetScript.performDropOff(Priority.InStore);
        patientSearchTestSetScript.openRXinInputScreen(inputData);

        patientSearchTestSetScript.closeInputScreen();

        Reporter.log("Validation is successfully completed for Brand Only Patient Preference");

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate adding Additional Medications Patient is Taking on PTMS
     * JIRA: HWPHME2E-2264
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate adding Additional Medications Patient is Taking on PTMS",
            enabled = true,  priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2262_validate_adding_Additional_Medications_Patient_is_Taking_on_PTMS(Map<String, String> inputData) {
        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.addAdditionalMedications(inputData);

        Reporter.log("Validation is successfully completed for adding Additional Medications Patient is Taking on PTMS");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate adding Medical Condition on the Patient Profile & deactivating the Medical Condition
     * JIRA: HWPHME2E-2264
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate adding Medical Condition on the Patient Profile & deactivating the Medical Condition",
            enabled = true,  priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2264_adding_deactivating_medical_condition(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);
        patientSearchTestSetScript.openAllergyMedicalConditions(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.deActivateMedicalConditions(inputData);

        Reporter.log("Validation is successfully completed for adding Medical Condition on the Patient Profile & deactivating the Medical Condition");
    }
    /**----------------------------------------------------------------------------------------------------------
     * Test Description:add ethnicity/race/mothers maiden name on the Patient Profile
     * JIRA: HWPHME2E-2259
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/


    @Test(description = "add ethnicity/race/mothers maiden name on the Patient Profile",
            enabled = true,  priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2259_add_ethnicity_race_mothers_maiden_name_on_the_Patient_Profile(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.verifyEthnicityDropdown(inputData);

        patientSearchTestSetScript.addMiscPersonalInfo(inputData);

        Reporter.log("Validation is successfully completed for add ethnicity/race/mothers maiden name on the Patient Profile");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Adding Primary Prescriber on the Patient Profile
     * JIRA: HWPHME2E-2261
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Adding Primary Prescriber on the Patient Profile",
            enabled = true,  priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2261_Validate_Adding_Primary_Prescriber_on_the_Patient_Profile(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();

        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.addPrimaryPrescriber(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.selectNoPrescriber(inputData);

        Reporter.log("Validation is successfully completed for Adding Primary Prescriber on the Patient Profile");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate the Address Type Modification / Primary Address Setup on PTMS
     * JIRA: HWPHME2E-2254
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Validate the Address Type Modification / Primary Address Setup on PTMS",
            enabled = true,  priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2254_Validate_Primary_Address_Setup(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.clickOnMailingAddressTab();

        patientSearchTestSetScript.selectMailingAddressAsPrimary(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.clickOnTemporaryAddressTab();
        patientSearchTestSetScript.selectTempAddressAsPrimary(inputData);

        Reporter.log("Validation is successfully completed for Address Type Modification / Primary Address Setup on PTMS");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Deactivating Third Party on Patient Profile
     * JIRA: HWPHME2E-2252
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Deactivating Third Party on Patient Profile",
            enabled = true,  priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintananceDataBook.json", sheetName = "PatientMaintanance")
    public void HWPHME2E_2252_Validate_Deactivating_Third_Party_on_Patient_Profile(Map<String, String> inputData) {

        patientSearchTestSetScript.logStoreNumberandState();
        patientSearchTestSetScript.initializeTestCase(false);

        patientSearchTestSetScript.createNewPatient(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.addSecondaryThirdPartyDetails(inputData);

        patientSearchTestSetScript.openPatientRecord(inputData);

        patientSearchTestSetScript.unCheckTPEligibility();

        patientSearchTestSetScript.performDropOff(Priority.InStore);

        patientSearchTestSetScript.performInput(inputData);

        patientSearchTestSetScript.perform4Point(false,false);
        patientSearchTestSetScript.performFilling();

        patientSearchTestSetScript.performVisualVerify();

        patientSearchTestSetScript.checkCashPaymentMethodInPickup(inputData);

        Reporter.log("Validation is successfully completed for Deactivating Third Party on Patient Profile");
    }
}