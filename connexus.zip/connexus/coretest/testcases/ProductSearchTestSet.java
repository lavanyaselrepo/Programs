package connexus.coretest.testcases;

import connexus.coretest.testscripts.ProductSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import io.strati.libs.joda.time.DateTime;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class ProductSearchTestSet {

    ProductSearchTestSetScript productSearchTestSetScript = new ProductSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }
    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Product Search History is displayed when user clicks on the Search text boxes on Product Search window
     * JIRA: HWCNXCLD-16180
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Product Search History is displayed when user clicks on the Search text boxes on Product Search window",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_583_Product_Search_History_Verification(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_583_Product_Search_History_Verification<<<");

        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Enter Product Name, Strength, Form, Generic Name and NDC and then click on Search Now button
        //   b. Verify the search results with the given inputs.
        productSearchTestSetScript.searchProductWithAllFields(inputData);

        //4. Click on Close Button on Product Search window
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();

        //5.Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //6. a. Go to each text field in Product Search window and check if it has previous Search History displayed
        //   b. In each Text Field/Dropdown, press Down Arrow Key to select the value
        //   c. Click on Search Now button
        //   d. Verify the search results matched with the given inputs.
        productSearchTestSetScript.checkProductSearchHistory(inputData);

        Reporter.log("<<<HWPHME2E_583_Product_Search_History_Verification>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Product Search screen is closed when Press ESC button in Input screen
     * JIRA: HWCNXCLD-16130
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Product Search screen is closed when Press ESC button in Input screen",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_585_Input_Screen_Product_Search_Press_Esc_Button_Closes_Window(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_585_Input_Screen_Product_Search_Press_Esc_Button_Closes_Window<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Click on Input on the left side menu bar
        productSearchTestSetScript.clickInputFromLeftBar();

        //2. Enter a drug name in Prescribed Product text field and search in Input screen
        productSearchTestSetScript.enterProductAndSearchInInputScreen(inputData);

        //3. Close the Product Search window by pressing Escape button
        productSearchTestSetScript.closeProductSearchWindowsByPressingEscapeButton();

        //4. Close the opened Input Screen to continue the rest of the test case execution
        productSearchTestSetScript.closeInputScreen();

        Reporter.log("<<<HWPHME2E_585_Input_Screen_Product_Search_Press_Esc_Button_Closes_Window>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the product search results on entering data from Input screen and clicking search
     * JIRA: HWCNXCLD-10239
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify the product search results on entering data from Input screen and clicking search",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void tc03_Input_Screen_Verify_Product_Search_Results(Map<String, String> inputData) {
        Reporter.log(">>>tc03_Input_Screen_Verify_Product_Search_Results<<<");

        //1. Create a new patient
        productSearchTestSetScript.createPatient(inputData);

        //2. DropOff an RX for the above created patient
        productSearchTestSetScript.performDropOffForNewPatient();

        //3. Search for the Patient/RX on the Order Search Window and open on Input screen
        productSearchTestSetScript.openRXinInputScreen();

        //4. Enter a drug name in Prescribed Product text field and search in Input screen
        productSearchTestSetScript.enterProductAndSearchInInputScreen(inputData);

        //5. Close the Product Search window by pressing Escape button
        productSearchTestSetScript.closeProductSearchWindowsByPressingEscapeButton();

        //6. Close the opened Input Screen to continue the rest of the test case execution
        productSearchTestSetScript.closeInputScreen();

        Reporter.log("<<<tc03_Input_Screen_Verify_Product_Search_Results>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the product search results on entering data from Modify Details screen
     * JIRA: HWCNXCLD-15593
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the product search results on entering data from Modify Details screen",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_584_Modify_Details_Screen_Verify_Product_Search_Results(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_584_Modify_Details_Screen_Verify_Product_Search_Results<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        productSearchTestSetScript.createNewPatient(inputData);
        //2. DropOff an RX for the above created patient
        productSearchTestSetScript.performDropOff(Priority.Critical);
        productSearchTestSetScript.performInput(inputData);
        productSearchTestSetScript.perform4Point(false);
        productSearchTestSetScript.enterProductAndSearchInModifyDetailsScreen(inputData);
        //4. Close the Modify details screen
        productSearchTestSetScript.closeModifyDetailsScreen();
        Reporter.log("<<<HWPHME2E_584_Modify_Details_Screen_Verify_Product_Search_Results>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify product search results gr ARid is displayed when search with product details on Host look up button
     * JIRA: HWCNXCLD-10863F
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify product search results grid is displayed when search with product details on Host look up button ",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_581_Product_Search_Host_Search_Results_Verification(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_581_Product_Search_Host_Search_Results_Verification<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Verify the Data in Search results from Host are displayed in columns Short name and Generic Drug Name when clicked on Host Look Up
        //   b. Verify if the Host Look Up, Search Now, New Search and Close buttons are displayed
        productSearchTestSetScript.productSearchHostSearchResultsValidation(inputData);

        Reporter.log("<<<HWPHME2E_581_Product_Search_Host_Search_Results_Verification>>>");
        Log.info("<<<HWPHME2E_581_Product_Search_Host_Search_Results_Verification>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify product search results grid is displayed when search with product details on Search now
     * JIRA: HWCNXCLD-10862
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify product search results grid is displayed when search with product details on Search now",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
        public void tc06_Product_Search_Local_Search_Results_Verification(Map<String, String> inputData) {
        Reporter.log(">>>tc06_Product_Search_Local_Search_Results_Verification<<<");

        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Verify the Data in Search results from local are displayed in columns Short name and Generic Drug Name when clicked on Search Now button
        //   b. Verify if the Host Look Up, Search Now, New Search and Close buttons are displayed
        productSearchTestSetScript.productSearchLocalSearchNowResultsValidation(inputData);

        Reporter.log("<<<tc06_Product_Search_Local_Search_Results_Verification>>>");
        Log.info("<<<tc06_Product_Search_Local_Search_Results_Verification>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the product search results on entering data from Input screen and clicking search
     * JIRA: HWCNXCLD-10239
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify the product search results on entering data from Input screen and clicking search",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void tc07_Product_Search_Input_Screen_Local_Search_Results_Verification(Map<String, String> inputData) {
        Reporter.log(">>>tc07_Product_Search_Input_Screen_Local_Search_Results_Verification<<<");

        //1. Create a new patient
        productSearchTestSetScript.createPatient(inputData);

        //2. DropOff an RX for the newly created Patient
        productSearchTestSetScript.performDropOffForNewPatient();

        //3. Search for the Patient/RX on the Order Search Window and open on Input screen
        productSearchTestSetScript.openRXinInputScreen();

        //4. Enter a drug name in Prescribed Product text field and search in Input screen
        productSearchTestSetScript.productSearchInInputScreenAndValidateResults(inputData);

        //6. Close the opened Input Screen to continue the rest of the test case execution
        productSearchTestSetScript.closeInputScreen();

        Reporter.log("<<<tc07_Product_Search_Input_Screen_Local_Search_Results_Verification>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the product search in combination of search
     * JIRA: HWCNXCLD-10235
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the product search in combination of search",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_577_Product_Search_Combination_Search_Results_Verification(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_577_Product_Search_Combination_Search_Results_Verification<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Search with Name and Strength text fields and verify search results
        productSearchTestSetScript.productSearchCombineNameAndStrengthSearchFieldsAndValidateResults(inputData);

        //2. Search with Name and Form text fields and verify search results
        productSearchTestSetScript.productSearchCombineNameAndFormSearchFieldsAndValidateResults(inputData);

        //3. Search with Name and Generic Name text fields and verify search results[
        productSearchTestSetScript.productSearchCombineNameAndGenericNameFieldsAndValidateResults(inputData);

        //4. Search with Name and NDC text fields and verify search results
        productSearchTestSetScript.productSearchCombineNameAndNDCFieldsAndValidateResults(inputData);

        Reporter.log("<<<HWPHME2E_577_Product_Search_Combination_Search_Results_Verification>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the product search results from Search menu
     * JIRA: HWCNXCLD-10234
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the product search results from Search menu",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_574_Product_Search_Verify_Results_With_DB_Results(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_574_Product_Search_Verify_Results_With_DB_Results<<<");

        flagUpdated = connexusAppUtils.readAndUpdateFlag("2809", "TRUE");
        productSearchTestSetScript.initializeTestCase(flagUpdated);
        connexusAppUtils.getStoreId();
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2.Verify Product Search results against Database results
        productSearchTestSetScript.verifyProductSearchResultAgainstDB(inputData);

        //3. Close Product Search Window.
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();

        Reporter.log("<<<HWPHME2E_574_Product_Search_Verify_Results_With_DB_Results>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the screen is navigated to Input screen on clicking close button in Product Search window
     * JIRA: HWCNXCLD-10233
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Sriniva
     * s(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether the screen is navigated to Input screen on clicking close button in Product Search window",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void tc10_Product_Search_Input_Screen_Close_Window_Navigate_Back_to_Input(Map<String, String> inputData) {
        Reporter.log(">>>tc10_Product_Search_Input_Screen_Close_Window_Navigate_Back_to_Input<<<");

        //1. Click on Input on the left side menu bar
        productSearchTestSetScript.clickInputFromLeftBar();

        //2. a. Enter a drug name in Prescribed Product text field and search in Product Search Window in Input screen
        //   b. Verify the Product Search Results.
        //   c. Close the product search window and verify if the screen is navigated back to Input screen.
        productSearchTestSetScript.navigateBackToInputScreenAfterClosingProductSearchWindow(inputData);

        //5. Close the opened Input Screen to continue the rest of the test case execution
        productSearchTestSetScript.closeInputScreen();

        Reporter.log("<<<tc10_Product_Search_Input_Screen_Close_Window_Navigate_Back_to_Input>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether search results grid is cleared on clicking New Search button by clicking OK in pop-up
     * JIRA: HWCNXCLD-10232
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether search results grid is cleared on clicking New Search button by clicking OK in pop-up",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_579_Product_Search_New_Search_Button_Clear_Results(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_579_Product_Search_New_Search_Button_Clear_Results<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Enter Product Name, Strength, Form, Generic Name and NDC and then click on Search Now button
        //   b. Verify the search results with the given inputs.
        productSearchTestSetScript.searchProductWithAllFields(inputData);

        //3. Click on New Search button and verify if the search results are cleared
        productSearchTestSetScript.clickOnNewSearchClearsSearchResults();

        //4. Close Product Search window
        productSearchTestSetScript.closeProductSearchWindowsByPressingEscapeButton ();
        Reporter.log("<<<HWPHME2E_579_Product_Search_New_Search_Button_Clear_Results>>>");
        Log.info("<<<HWPHME2E_579_Product_Search_New_Search_Button_Clear_Results>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the search results on searching in fields - Form and Generic Name
     * JIRA: HWCNXCLD-10227
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the search results on searching in fields - Form and Generic Name",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_576_Product_Search_Verify_Results_For_Form_And_GenericName_Fields(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_576_Product_Search_Verify_Results_For_Form_And_GenericName_Fields<<<");
        Log.info(">>>HWPHME2E_576_Product_Search_Verify_Results_For_Form_And_GenericName_Fields<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();
        //2. a. Enter Form and Generic Name and then click on Search Now button
        //   b. Verify the search results with the given inputs.
        productSearchTestSetScript.searchWithFormAndGenericNameFieldsAndVerifyResults(inputData);
        //3. Close Product Search Window.
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();
        Reporter.log("<<<HWPHME2E_576_Product_Search_Verify_Results_For_Form_And_GenericName_Fields>>>");
        Log.info("<<<HWPHME2E_576_Product_Search_Verify_Results_For_Form_And_GenericName_Fields>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the search results on searching in fields - Name and Strength
     * JIRA: HWQEAUTO-8612
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the search results on searching in fields - Name and Strength",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_580_Product_Search_Verify_Results_For_Name_And_Strength_Fields(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_580_Product_Search_Verify_Results_For_Name_And_Strength_Fields<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Enter Form and Generic Name and then click on Search Now button
        //   b. Verify the search results with the given inputs.
        productSearchTestSetScript.searchWithNameAndStrengthFieldsAndVerifyResults(inputData);

        //3. Close Product Search Window.
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();

        System.out.println("<<<HWPHME2E_580_Product_Search_Verify_Results_For_Name_And_Strength_Fields>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether empty search results grid is displayed when no records found
     * JIRA: HWQEAUTO-8693
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether empty search results grid is displayed when no records found",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_575_Product_Search_Verify_Empty_Results_Grid_When_No_Results_Found(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_575_Product_Search_Verify_Empty_Results_Grid_When_No_Results_Found<<<");
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Enter search data which does not give any search results and then click on Search Now button
        //   b. Verify the search results grid is empty and no results should be found.
        productSearchTestSetScript.emptySearchResultsVerificationOnProductSearch(inputData);

        //3. Close Product Search Window.
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();

        System.out.println("<<<HWPHME2E_575_Product_Search_Verify_Empty_Results_Grid_When_No_Results_Found>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify Product Search results on entering data from Search screen and clicking Search Now button
     * JIRA: HWCNXCLD-10224
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify Product Search results on entering data from Search screen and clicking Search Now button",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void tc15_Product_Search_Verify_Search_Results_Regular_Search(Map<String, String> inputData) {
        System.out.println(">>>tc15_Product_Search_Verify_Search_Results_Regular_Search<<<");

        //1. Open Product Search by pressing Keyboard shortcut CTRL + SHIFT + D  | Product Search screen is displayed
        productSearchTestSetScript.openProductSearchWindow();

        //2. a. Enter product name in Name field and then click on Search Now button
        //   b. Verify the search results with the given inputs.
        productSearchTestSetScript.searchWithNameAndVerifyResults(inputData);

        //3. Close Product Search Window.
        productSearchTestSetScript.closeProductSearchWindowsByClickingOnCloseButton();

        System.out.println("<<<tc15_Product_Search_Verify_Search_Results_Regular_Search>>>");
    }*/


    /*---------------------------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_5244 Validate Editing of Single Dispense & Single Dose in Item Maintenance Screen
    *
    * Pre-Conditions:  User is logged into Connexus
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/ProductSearchDataBook.json", sheetName = "ProductSearch")
    public void HWPHME2E_5244_Validate_Editing_Of_Single_Dispense_And_Single_Dose(Map<String, String>inputData){
        connexusAppUtils.getStoreId();
        productSearchTestSetScript.initializeTestCase(false);
        productSearchTestSetScript.openProductSearchWindow();
        productSearchTestSetScript.validateEditingOfSingleDispenseAndSingleDose(inputData);
        Reporter.log("Validated the editing of Single Dispense and Single Dose in Item Maintenance Screen");
    }
}
