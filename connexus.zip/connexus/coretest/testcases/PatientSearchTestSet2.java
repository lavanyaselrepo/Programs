package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.Map;

public class PatientSearchTestSet2 {

    PatientSearchTestSetScript patientSearchTestSetScript = new PatientSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    public boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        AutomationManager.getInstance().performSleep(5);

    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify pop up box should be closed and its navigate back to patient search screen when clicking "OK"button
     * JIRA: HWQEAUTO-8733
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify pop up box should be closed and its navigate back to patient search screen when clicking \"OK\"button",
            enabled = true,  priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button(Map<String, String> inputData) {

        //Pre-Condition: Check Flag 26849 and set it to true and restart Connexus.
        //Adding comment for Relogin scenario.
       /* if (connexusAppUtils.readFlagValue("26849").get(0).get("phm_parm_value").toString().trim().equals("false")) {
            patientSearchTestSetScript.closeConnexus();
            connexusAppUtils.readAndUpdateFlag("26849", "true");
        }*/
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "true");
        patientSearchTestSetScript.initializeTestCase(flagUpdated);

        //1. Create a new patient
        patientSearchTestSetScript.createPatientWithPrimaryPhoneNumber(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for a patient with an invalid date in DOB field and verify whether an error message displayed and this method also closes the Patient Search window
        patientSearchTestSetScript.verifyWhetherInvalidDOBPopUpDisplayedWhenSearchedWithInvalidDate(inputData);

        //4. Verify whether the Patient Search window is showing on closing the Invalid DOB Error popup
        patientSearchTestSetScript.verifyWhetherPatientSearchWindowDisplayed();

        //5. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Patient with Invalid date in DOB field shows error message and pop is closed by clicking close button");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether pop up should be displayed when enter alphabetical characters in the phone number field
     * JIRA: HWQEAUTO-8719
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-381 , Duplicate will be covered in TC 377
  /*  @Test(description = "To verify whether pop up should be displayed when enter alphabetical characters in the phone number field",
            enabled = true,   priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", dependsOnMethods = "tc16_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc17_Patient_Search_Verify_Whether_Invalid_Phone_Number_Popup_Displayed_When_Entered_Alphabets(Map<String, String> inputData) {
        System.out.println(">>>tc17_Patient_Search_Verify_Whether_Invalid_Phone_Number_Popup_Displayed_When_Entered_Alphabets");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a patient by entering alphabets in phone number field and verify whether an error message displayed
        patientSearchTestSetScript.verifyWhetherInvalidPhoneNumberFormatPopUpDisplayedWhenSearchedWithAlphabets(inputData);

        //3. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc17_Patient_Search_Verify_Whether_Invalid_Phone_Number_Popup_Displayed_When_Entered_Alphabets");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify pop up box should be closed and its navigate back to patient search screen when clicking "OK"button
     * JIRA: HWQEAUTO-8633
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify pop up box should be closed and its navigate back to patient search screen when clicking \"OK\"button",
            enabled = true,  priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_377_Patient_Search_Verify_Whether_Invalid_Phone_Number_Popup_Closed_On_Clicking_OK_Button(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a patient by entering alphabets in phone number field and verify whether an error message displayed
        patientSearchTestSetScript.verifyWhetherInvalidPhoneNumberFormatPopUpDisplayedWhenSearchedWithAlphabets(inputData);

        //3. Verify whether the Patient Search window is showing on closing the Invalid Phone Number Format popup
        patientSearchTestSetScript.verifyWhetherPatientSearchWindowDisplayed();

        //3. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("On entering invalid phone number error message is displayed");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user should be able to enter only the numeric value in the Store number and RX number fields
     * JIRA: HWQEAUTO-8616
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether user should be able to enter only the numeric value in the Store number and RX number fields",
            enabled = true,  priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_384_Patient_Search_Verify_Whether_StoreNumber_And_RXNumber_Accepts_Only_Numbers(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Enter characters in Store Number and rx Number text fields and verify if it is allowing.
        patientSearchTestSetScript.verifyWhetherStoreNumberAndRXNumberFieldsAllowsOnlyNumbers(inputData);

        //3. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Verified RX Number and Store Number is allowed in text fields");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to enter numeric value greater than 5-Digit in the Store Nbr field
     * JIRA: HWQEAUTO-8787
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the user able to enter numeric value greater than 5-Digit in the Store Nbr field",
            enabled = false,  priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_379_Patient_Search_Verify_Whether_StoreNumber_Allows_GreaterThan_5_Digits(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Enter a Store Number with greater than 5 digits and verify that it should not allow.
        patientSearchTestSetScript.verifyWhetherStoreNumberAllowsGreaterThan5Digits(inputData);

        //3. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Store Number with greater than 5 digits is not allowed in the Store Nbr field");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user able to enter numeric value greater than 10-Digit in the 'RX Nbr' field
     * JIRA: HWQEAUTO-8621
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether user able to enter numeric value greater than 10-Digit in the 'RX Nbr' field",
            enabled = false,    priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_394_Patient_Search_Verify_Whether_RXNumber_Allows_GreaterThan_10_Digits(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Enter a RX Number with greater than 10 digits and verify that it should not allow.
        patientSearchTestSetScript.verifyWhetherRXNumberAllowsGreaterThan10Digits(inputData);

        //3. Close Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("RX Number with greater than 10 digits is not allowed");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the patient search screen is displayed when user click find button on drop-off screen without entering data in search field
     * JIRA: HWQEAUTO-8595
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-392 , Duplicate covered in drop off flow.
    /*@Test(description = "To verify whether the patient search screen is displayed when user click find button on drop-off screen without entering data in search field",
            enabled = true,    priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc22_Patient_Search_Verify_Whether_DropOff_FindButton_Opens_Patient_Search(Map<String, String> inputData) {
        System.out.println(">>>tc22_Patient_Search_Verify_Whether_DropOff_FindButton_Opens_Patient_Search");

        //1. Open DropOff screen by pressing the keyboard shortcut key CTRL  D
        patientSearchTestSetScript.openDropOffScreen();

        //2. Click on Find Button beside patient search field in DropOff screen and verify whether patient search window opened.
        patientSearchTestSetScript.verifyWhetherPatientSearchOpensOnClickingFindButtonInDropOff();

        System.out.println("<<<tc22_Patient_Search_Verify_Whether_DropOff_FindButton_Opens_Patient_Search");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Patient search screen is displayed when user press Enter on drop-off screen without entering data in search field
     * JIRA: HWQEAUTO-8598
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-393, Duplicate covered in drop off flow.
  /*  @Test(description = "To verify whether the Patient search screen is displayed when user press Enter on drop-off screen without entering data in search field",
            enabled = true,  priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc23_Patient_Search_Verify_Whether_DropOff_PressEnter_Opens_Patient_Search(Map<String, String> inputData) {
        System.out.println(">>>tc23_Patient_Search_Verify_Whether_DropOff_PressEnter_Opens_Patient_Search");

        //1. Open DropOff screen by pressing the keyboard shortcut key CTRL + SHIFT + D
        patientSearchTestSetScript.openDropOffScreen();

        //2. Press Enter in patient search field in DropOff screen and verify whether patient search window opened.
        patientSearchTestSetScript.verifyWhetherPatientSearchOpensOnPressingEnterInDropOff();

        System.out.println("<<<tc23_Patient_Search_Verify_Whether_DropOff_PressEnter_Opens_Patient_Search");
    }*/

    /**----------------------------------------------------------------------------------------------------------[
     * Test Description:To verify whether the Patient details displayed on clicking the patient search button from RX lookup Screen
     * JIRA: HWQEAUTO-6912
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Patient details displayed on clicking the patient search button from RX lookup Screen",
            enabled = true,   priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_386_Patient_Search_Verify_Whether_Patient_Details_displayed_In_RxLookUp(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open DropOff screen by pressing the keyboard shortcut key CTRL + SHIFT + R
        patientSearchTestSetScript.openRxLookUpScreen();

        //2. Verify whether the Patient details displayed on clicking the patient search button from RX lookup Screen
        patientSearchTestSetScript.verifyWhetherPatientDetailsDisplayedOnRxLookUp();

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to Search for a pet patient
     * JIRA: HWQEAUTO-6930
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the user able to Search for a pet patient",
            enabled = true,   priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_389_Patient_Search_Verify_Whether_User_Able_To_Search_Pet_Patient(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Pet Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Search for a Pet Patient and verify the search results on Patient Search window is verified");
    }

   /* *//**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to Search for a Patient with Numbers
     * JIRA: HWQEAUTO-6926
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(description = "To verify whether the user able to Search for a Patient with Numbers",
            enabled = true,   priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_382_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Closed_On_Clicking_OK_Button")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_388_Patient_Search_Verify_Whether_User_Able_To_Search_Patient_With_Numbers(Map<String, String> inputData) {

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient with numbers and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientOnFileAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Search for a Patient with numbers is verifed on Patient Search window");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to Search for a livestock patient
     * JIRA: HWQEAUTO-6934
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the user able to Search for a livestock patient",
            enabled = false,   priority = 31, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_390_Patient_Search_Verify_Whether_User_Able_To_Search_LiveStock_Patient(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a LiveStock Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Search for a LiveStock Patient is verified on Patient Search window");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to Search for Patient with Special Characters except( , . )
     * JIRA: HWQEAUTO-6954
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the user able to Search for Patient with Special Characters except( , . )",
            enabled = true,   priority = 28, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_391_Patient_Search_Verify_Whether_User_Able_To_Search_With_Special_Characters(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. verify whether the user able to Search for Patient with Special Characters except( , . )
        patientSearchTestSetScript.verifyWhetherPatientSearchAllowsSpecialCharacters(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to search for a patient with maximum characters in Name
     * JIRA: HWQEAUTO-6910
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-385 , Duplicate will be covered in TC 2452
  /*  @Test(description = "To verify whether the user able to search for a patient with maximum characters in Name",
            enabled = true,  priority = 29, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc29_Patient_Search_Verify_Whether_User_Able_To_Search_For_A_PatientName_With_Max_Characters(Map<String, String> inputData) {
        System.out.println(">>>tc29_Patient_Search_Verify_Whether_User_Able_To_Search_For_A_PatientName_With_Max_Characters");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the user able to search for a patient with maximum characters in Name
        patientSearchTestSetScript.verifyWhetherUserAbleToSearchForAPatientNameWithMaximumCharacters(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc29_Patient_Search_Verify_Whether_User_Able_To_Search_For_A_PatientName_With_Max_Characters");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Patient search result displayed with middle name when Patient having Middle name
     * JIRA: HWQEAUTO-6922
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Patient search result displayed with middle name when Patient having Middle name",
            enabled = true,   priority = 30, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_387_Patient_Search_Verify_Search_Results_With_Middle_Name(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient including middle name and verify the search results must show the middle name on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Search for a Patient including middle name is verified on Patient Search window");
    }

}
