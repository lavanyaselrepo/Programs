package connexus.coretest.testcases.cp2.userexperience;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class UserExperienceTestSet1 {

    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    public void updateFlags(){
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27247", "TRUE");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26862", "FALSE");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
    }

    /*----------------------------------------------------------------------------------------------------------
     * To verify whether the tool tip text 'Customer phone # is ENROLLED, messages should be sending' appears when Patient opted-in and responded to Welcome Text
     * Jira Id HWQEAUTO-10720
     * Pre-Conditions:
     * 1. New PMS flag(27247) should be TRUE
     *
     * Author: narayanaswamy (n0s06rk)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether the tool tip text 'Customer phone # is ENROLLED, messages should be sending' appears when Patient opted-in and responded to Welcome Text",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void CP2_HWQEAUTO_10720(Map<String, String> inputData) {

        //This Test case oboselete or not valid functionality is rewritten-HWPHME2E-2244

        System.out.println(">>>To verify whether the tool tip text 'Customer phone # is ENROLLED, messages should be sending' appears when Patient opted-in and responded to Welcome Text<<<");
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");
        connexusAppUtils.readAndUpdateFlag("26862", "FALSE");
        connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.createPatient(inputData);
        userExperienceTestSetScript.verifyRxMessagingEnroll(inputData);
        System.out.println("<<<To verify whether the tool tip text 'Customer phone # is ENROLLED, messages should be sending' appears when Patient opted-in and responded to Welcome Text>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * CRP ON_PMS ON_New search screen ON_Integration Testing_TC_006
     * Pre-Conditions:
     * Author: narayanaswamy (n0s06rk)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-353")
    @Test(description = "CRP ON_PMS ON_New search screen ON_Integration Testing_TC_006",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void CP2_HWPHME2E_353(Map<String, String> inputData) {
        System.out.println(">>>CRP ON_PMS ON_New search screen ON_Integration Testing_TC_006<<<");
        connexusAppUtils.getStoreId();
        updateFlags();
        userExperienceTestSetScript.initializeTestCase(true);
        userExperienceTestSetScript.createPatientFromDropoffScreen(inputData);
        userExperienceTestSetScript.dropOff();
        userExperienceTestSetScript.performInput(inputData);
        userExperienceTestSetScript.perform4Point(false);
        System.out.println("<<<CRP ON_PMS ON_New search screen ON_Integration Testing_TC_006>>>");
    }
}