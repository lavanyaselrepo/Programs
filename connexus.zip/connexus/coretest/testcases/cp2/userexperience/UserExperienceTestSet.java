package connexus.coretest.testcases.cp2.userexperience;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceTestSet {
    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Store selected must be mail order store. Login to connexus with valid credentials.
     * Pre Condition:
     * 1. Should be executed in store: 5586/5587
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-349")
    @Test(description = "Store selected must be mail order store. Login to connexus with valid credentials.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void HWPHME2E_349_tc_01_Verify_the_entry_in_phm_pk_shipping_table(Map<String, String> inputData) {
        System.out.println(">>>tc_01_Verify_the_entry_in_phm_pk_shipping_table<<<");

        //pre-condition
        //1. Should be executed in store: 5586/5587
        connexusAppUtils.getStoreId();
        userExperienceTestSetScript.initializeTestCase(true);
        //1. Create/search for an existing patient from drop-off | User should able to create/ search for patient
        userExperienceTestSetScript.createNewPatient(inputData);

        //2. In PTMS add all the 4 address fields | User should able to add address in Home, Mailing, Temporary, Facility fields.
        userExperienceTestSetScript.searchPatient();
        boolean flagCheckForMailingAddress = userExperienceTestSetScript.clickOnMailingAddressTab();
        userExperienceTestSetScript.enterPatientAddress(inputData, flagCheckForMailingAddress);
        boolean flagCheckForTemporaryAddress = userExperienceTestSetScript.clickOnTemporaryAddressTab();
        userExperienceTestSetScript.enterPatientAddress(inputData, flagCheckForTemporaryAddress);
        boolean flagCheckForShippingAddress = userExperienceTestSetScript.clickOnShippingAddressTab();
        userExperienceTestSetScript.enterPatientAddress(inputData, flagCheckForShippingAddress);
        userExperienceTestSetScript.closePatientMaintenance();

        //3. In drop-off, Scan new Rx and provide required fields in drop-off | Should able to fill all fields in drop-off
        //4. Click on Accept to complete drop-off | Order details screen should open
        userExperienceTestSetScript.performDropOff(Priority.Critical);

        //5. Select the shipping address and payment method | Should able to see selected shipping address populated in shiping information grid
        //6. Check phm_pk_shipping table such that a new entry is recorded select * from phm_pk_shipping where ship_to_name=<LN,FN>; | A new entry should be recorded when the shipping address is selected
        userExperienceTestSetScript.completeAndValidateShippingPaymentOrder(inputData);

        System.out.println("<<<tc_01_Verify_the_entry_in_phm_pk_shipping_table>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Complete Dispensed drug name is displaying under the RX Note of
     * consolidated notes screen.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-332")
    @Test(description = "To verify whether Complete Dispensed drug name is displaying under the RX Note of consolidated notes screen.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void HWPHME2E_332_tc_02_Complete_Dispensed_drug_name_is_displaying_under_the_RX_Note_in_consolidated_Note_view_window(Map<String, String> inputData) {
        System.out.println(">>>tc_02_Complete_Dispensed_drug_name_is_displaying_under_the_RX_Note_in_consolidated_Note_view_window<<<");

        //1. Login to connexus with valid credentials | User should be able to login
        //2. Drop an RX for any patient profile | User should be able to drop rx for the patient.
        //3. Process the RX with any drug or Compound drug and complete Input | User should be able to complete input for the rx and rx should move to 4 point work queue.
        connexusAppUtils.getStoreId();
        userExperienceTestSetScript.initializeTestCase(false);
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.performDropOff(Priority.Critical);

        //The rx dropped in tc_01_Verify_the_entry_in_phm_pk_shipping_table is utilised to input compound drug
        String compoundDrug = userExperienceTestSetScript.setCompoundDrugType(inputData);
        userExperienceTestSetScript.performInputForRx(inputData, compoundDrug);

        userExperienceTestSetScript.performDropOff(Priority.Critical);
        String normalDrug = userExperienceTestSetScript.setNormalDrugType(inputData);
        userExperienceTestSetScript.performInputForRx(inputData, normalDrug);

        //4. In 4 point go to menu and select Current RX --> RX Notes | Consolidated Note view window should be displayed.
        //5. Verify the RX notes | Complete Dispensed drug name should be displayed on the RX Note on consolidated notes screen. In case of Compound drug it should display "Compound"
        userExperienceTestSetScript.launch4PointAndValidateRxNotes();

        //to continue the flow
        userExperienceTestSetScript.closeRxNotesAnd4Point();

        System.out.println("<<<tc_02_Complete_Dispensed_drug_name_is_displaying_under_the_RX Note_in_consolidated_Note_view_window>>>");
    }

    // OBSOLETE TESTCASE

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"To verify that the Patient Maintenance screen is not displayed on searching with the existing
     * patient name/Pet Patient/livestock name in the Drop-off screen for other than Oklohoma State"
     * Pre Condition:
     * Condition1:
     * 1. Set the State=’SC’ in bus_unit_addr table.
     * 2. Select the existing Patients from the Patient table where patient_type_code=10200
     * 3. Launch the Connexsus and login to the application
     *
     * Condition2:
     * 1. Select the existing Pet Patients from the Patient table where patient_type_code=10202
     *
     * Condition3:
     * 1. Select the existing Livestock Patients from the Patient table where patient_type_code=10201
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*//*
    //@Jira(testID = "HWPHME2E-351")
    @Test(description = "To verify that the Patient Maintenance screen is not displayed on searching with the existing\n" +
            "patient name/Pet Patient/livestock name in the Drop-off screen for other than Oklohoma State",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void HWPHME2E_351_tc_03_PMS_and_PET_Wizard_Screens_are_not_displayed_for_existing_Human_Pet_Livestock_Patient_for_State_other_than_Oklohoma(Map<String, String> inputData) {
        System.out.println(">>>tc_03_PMS_and_PET_Wizard_Screens_are_not_displayed_for_existing_Human_Pet_Livestock_Patient_for_State_other_than_Oklohoma<<<");

        //Pre Condition:
        //Condition1:
        //1. Set the State=’SC’ in bus_unit_addr table.
        //2. Select the existing Patients from the Patient table where patient_type_code=10200
        //3. Launch the Connexsus and login to the application

        //Condition2:
        //1. Select the existing Pet Patients from the Patient table where patient_type_code=10202

        //Condition3:
        //1. Select the existing Livestock Patients from the Patient table where patient_type_code=10201

        if (connexusAppUtils.updateStateValue(inputData.get("STATE"))) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1. Search with Patient name as mentioned in the above condition from the Drop-off Screen and Verify that Patient Maintenance Screen and Pet Wizard screen is not displayed.
        // Repeat the Step 1 for the all the conditions mentioned above| Patient Maintenance Screen and Pet Wizard screen is not displayed.

        //Step for Condition 1:
        String humanName = userExperienceTestSetScript.getHumanDetails();
        userExperienceTestSetScript.validatePtmsAndPetWizardOnDropOff(humanName);
        userExperienceTestSetScript.closeDropOffScreenByAcceptClick();

        //Step for Condition 2:
        String petName = userExperienceTestSetScript.getPetDetails();
        userExperienceTestSetScript.validatePtmsAndPetWizardOnDropOff(petName);
        userExperienceTestSetScript.closeDropOffScreenByAcceptClick();

        //Step for Condition 3:
        String liveStockName = userExperienceTestSetScript.getLivestockDetails();
        userExperienceTestSetScript.validatePtmsAndPetWizardOnDropOff(liveStockName);
        userExperienceTestSetScript.closeDropOffScreenByAcceptClick();

        System.out.println("<<<tc_03_PMS_and_PET_Wizard_Screens_are_not_displayed_for_existing_Human_Pet_Livestock_Patient_for_State_other_than_Oklohoma>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"To verify that the authentication pop-up is displayed when the pharmacist/temporary pharmacist
     * modifies the controlled on-hand quantity when restrict_type_val=’Y’ in agency_rqmt_parm table for restrict_type_code=2579."
     * Pre Condition:
     * Condition1:
     * 1.Set the 28750 Flag-On
     * 2.Select any control drug having drug_control_code (2300, 2301, 2302, 2303) from pharmacy_offering:pharmacy_product table in the local store DB.
     * 3. Set the restrict_type_val = ‘Y’ in agency_rqmt_parm table where restrict_type_code=2579 in local store DB.
     *
     * Condition2:
     * 1. Set the 28750 Flag-Off
     * 2. Select any control drug having drug_control_code (2300, 2301, 2302, 2303) from pharmacy_offering:pharmacy_product table in the local store DB.
     * 3. Set the restrict_type_val = ‘Y’ in agency_rqmt_parm table where restrict_type_code=2579 in local store DB.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-468")
    @Test(description = "To verify that the authentication pop-up is displayed when the pharmacist/temporary pharmacist modifies " +
            "the controlled on-hand quantity when restrict_type_val=’Y’ in agency_rqmt_parm table for restrict_type_code=2579.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void HWPHME2E_468_tc_04_Authentication_Pop_up_is_displayed_on_modifying_the_Controlled_on_hand_quantity_by_Pharmacist_Temp_Pharmacist(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_468_Authentication_Pop_up_is_displayed_on_modifying_the_Controlled_on_hand_quantity_by_Pharmacist_Temp_Pharmacist<<<");
        Reporter.log("<<<HWPHME2E_468 Validating Pharmacist is able to update the on hand quantity for controlled drug>>>");

        //Pre Condition:
        //Condition1:
        //1.Set the 28750 Flag-On
        //2.Select any control drug having drug_control_code (2300, 2301, 2302, 2303) from pharmacy_offering:pharmacy_product table in the local store DB.
        //3. Set the restrict_type_val = ‘Y’ in agency_rqmt_parm table where restrict_type_code=2579 in local store DB.

        //For Condition 1:
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
//        userExperienceTestSetScript.initializeTestCase(flagUpdated);
        userExperienceTestSetScript.initializeTestCase(false);
        String getDrugForHO = userExperienceTestSetScript.getDrugName(inputData);
        userExperienceTestSetScript.setPreconditionOnAgencyReqParmTable();

        //1. Launch the Connexus application and login into application as Pharmacist. | Login is successful.
        //2. Select Product from the Search dropdown and specify the Control drug in the name field and hit enter. Select and double click the controlled drug from the displayed drug list.
        // | Product Screen is displayed with product description.
        //3. Check the DEA class value is 2/3/4/5 and select and double click on the required brand from the item list displayed. | Item Maintenance Screen is displayed with Product information
        userExperienceTestSetScript.launchProductSearch();
        userExperienceTestSetScript.InputDrugInProductScreenAndValidateDea(inputData, getDrugForHO);

        //4. Edit On-Hand field in Inventory and Click on Accept. Verify that the authentication pop-up is displayed. | Password authentication pop up is displayed.
        userExperienceTestSetScript.getOnHandDrugQtyFromProductMaintenance();
        userExperienceTestSetScript.changeOnHandDrugQtyOnIMS();

        //5. Authorize with Pharmacist credentials and select the adjustment reason from the list and click continue. | Product Screen is displayed with the new changes in On-Hand field.
        userExperienceTestSetScript.handleAdjustmentReasonForHomeOffice();

        //Condition2:
        //1. Set the 28750 Flag-Off
        //2. Select any control drug having drug_control_code (2300, 2301, 2302, 2303) from pharmacy_offering:pharmacy_product table in the local store DB.
        //3. Set the restrict_type_val = ‘Y’ in agency_rqmt_parm table where restrict_type_code=2579 in local store DB.

        //For Condition 2:
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        userExperienceTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOn);

        String getDrugForRph = userExperienceTestSetScript.getDrugName(inputData);
        userExperienceTestSetScript.setPreconditionOnAgencyReqParmTable();

        //1. Launch the Connexus application and login into application as Pharmacist. | Login is successful.
        //2. Select Product from the Search dropdown and specify the Control drug in the name field and hit enter. Select and double click the controlled drug from the displayed drug list.
        // | Product Screen is displayed with product description.
        //3. Check the DEA class value is 2/3/4/5 and select and double click on the required brand from the item list displayed. | Item Maintenance Screen is displayed with Product information
        userExperienceTestSetScript.launchProductSearch();
        userExperienceTestSetScript.InputDrugInProductScreenAndValidateDea(inputData, getDrugForRph);

        //4. Edit On-Hand field in Inventory and Click on Accept. Verify that the authentication pop-up is displayed. | Password authentication pop up is displayed.
        String onHandDrugQtyBeforeChangeForRph = userExperienceTestSetScript.getOnHandDrugQtyFromProductMaintenance();
        userExperienceTestSetScript.changeOnHandDrugQtyOnIMS();

        //5. Authorize with Pharmacist credentials and select the adjustment reason from the list and click continue. | Product Screen is displayed with the new changes in On-Hand field.
        userExperienceTestSetScript.handleAdjustmentReasonForRph();
        String onHandQuantityAfterChange = userExperienceTestSetScript.getOnHandDrugQtyFromProductMaintenance();
        userExperienceTestSetScript.validateChangeInOnHandDrugQuantity(onHandDrugQtyBeforeChangeForRph, onHandQuantityAfterChange);
        userExperienceTestSetScript.closeProductMaintenanceScreen();

        Reporter.log("<<<HWPHME2E_468 Validating Pharmacist is able to update the on hand quantity for controlled drug>>>");
        System.out.println("<<<HWPHME2E_468_Authentication_Pop_up_is_displayed_on_modifying_the_Controlled_on_hand_quantity_by_Pharmacist_Temp_Pharmacist>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"To verify that the on-hand quantity field is disabled upon control drug selection for
     * technician/temporary technician on given below test conditions"
     * Pre Condition:
     * Condition 1:
     * Set phm_parm_value=’T’ in bu_phm_parm table where bu_phm_code =11914
     * Select a control drug having drug_control_code (2300,2301,2302,2303) by joining two tables pharmacy_offering:pharmacy_item and pharmacy_offering:pharmacy_product on product_mds_fam_id
     * Set the 28750 Flag-On
     * Pharmacist/temporary Pharmacist should login prior to technician.
     *
     * Condition 2:
     * Set phm_parm_value=’T’ in bu_phm_parm table where bu_phm_code =11914
     * Select a control drug having drug_control_code (2300,2301,2302,2303) by joining two tables pharmacy_offering:pharmacy_item and pharmacy_offering:pharmacy_product on product_mds_fam_id
     * Set the 28750 Flag-Off.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-469")
    @Test(description = "To verify that the on-hand quantity field is disabled upon control drug selection for " +
            "technician/temporary technician on given below test conditions",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void HWPHME2E_469_tc_05_On_hand_Quantity_is_disabled_upon_control_drug_selection_for_technician_temp_technician(Map<String, String> inputData) {
        System.out.println(">>>tc_05_On_hand_Quantity_is_disabled_upon_control_drug_selection_for_technician_temp_technician<<<");

        //Pre Condition:
        //Condition 1:
        //1. Set phm_parm_value=’T’ in bu_phm_parm table where bu_phm_code =11914
        //2. Select a control drug having drug_control_code (2300,2301,2302,2303) by joining two tables pharmacy_offering:pharmacy_item and pharmacy_offering:pharmacy_product on product_mds_fam_id
        //3. Pharmacist/temporary Pharmacist should login prior to technician.
        //4. The Technician is permitted to login to store only when Flag 28750 OFF. When Flag 28750 is ON, Technician does not have authorization to login connexus application
        //userExperienceTestSetScript.validateTechnicianLogin();

        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("11914", "TRUE") || connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("11914", "TRUE");
        userExperienceTestSetScript.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        String getDrugFromDbForTechnician = userExperienceTestSetScript.getControlledDrugName();

        //1. Launch the Connexus application and login into application as Technician/temporary technician | Login is successful
        //2. Select Product from the Search dropdown and specify the Control drug in the name field and hit enter. Select and double click the controlled drug from the displayed drug list | Product Screen is displayed with product description.
        userExperienceTestSetScript.launchProductSearch();

        //3. Check whether DEA class is set to 2/3/4/5 and select and double click on the required brand from the item list. Verify that the On-hand Quantity Field is disabled. Repeat Step 2 through Step 3 for each pre- condition mentioned above
        // | Item Maintenance Screen is displayed with On-Hand quantity field disabled.
        userExperienceTestSetScript.InputDrugInProductScreenAndValidateDea(inputData, getDrugFromDbForTechnician);
        userExperienceTestSetScript.openItemMaintenanceScreen();
        userExperienceTestSetScript.verifyDisabledOnHandDrugQuantity();
        userExperienceTestSetScript.closeItemMaintenance();
        userExperienceTestSetScript.closeProductMaintenanceScreen();

        System.out.println("<<<tc_05_On_hand_Quantity_is_disabled_upon_control_drug_selection_for_technician_temp_technician>>>");
    }


    // DUPLICATE TESTCASE

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"The patient's modified and previous LN and FN in PMS displays on the consolidated notes view"
     * HWQEAUTO-19400
     * Author: Rishabh Madan(r0m0f2x)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test( description = "Store selected must be mail order store. Login to connexus with valid credentials.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp2/UserExperience/CP2UserExperienceDataBook.json", sheetName = "userExperienceCP2DataSheet")
    public void tc_06_Modify_LN_FN(Map<String, String> inputData) {
        System.out.println(">>>tc_06_Modify_LN_FN<<<");

        //1. Create/search for an existing patient from drop-off | User should able to create/ search for patient
        userExperienceTestSetScript.createPatient(inputData);
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);
        userExperienceTestSetScript.modifyPatientLnFnInPMSAndValidate(inputData);

        System.out.println("<<<tc_06_Modify_LN_FN>>>");
    }*/
}