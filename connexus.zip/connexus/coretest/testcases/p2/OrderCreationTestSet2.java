package connexus.coretest.testcases.p2;

import connexus.coretest.testscripts.OrderCreationTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderCreationTestSet2 {

    OrderCreationTestSetScript OrderCreationTestSetScript = new OrderCreationTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    ConnexusAPIManager connexusAPIManager;
    PropertyReader prop = PropertyReader.getInstance();
    boolean flagUpdated = false;
    boolean relaunchConnexus;
    String siteId =prop.getProperty("cnx.store");
    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }
    @BeforeMethod
    public void setup() {
        connexusAPIManager = new ConnexusAPIManager();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void restartConnexusService(){
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteId);
            relaunchConnexus = true;
        } else {
            Reporter.log("No flags updated, skipping Connexus service restart");
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether “Initial Fill?” text and "Yes" "No" radio buttons are populated below
     * the Acute Condition Area upon clicking on "Acute Condition" radio button at 4 Point for new rx with C4 opioid drug.
     * Pre-Conditions:
     * 1. Drop an Rx for a patient and process till 4 point using C4 opioid controlled drug.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-205")
    @Test(description = "To verify whether “Initial Fill?” text and Yes or No radio buttons are populated below the Acute Condition Area upon " +
            "clicking on Acute Condition radio button at 4 Point for new rx with C4 opioid drug.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/orderCreationP2DataBook.json", sheetName = "orderCreationP2DataSheet")
    public void HWPHME2E_205_Tc_13_opioid_acute_non_acute_C4_initial_fill_Yes_No_4point(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_205_Tc_13_opioid_acute_non_acute_C4_initial_fill_Yes_No_4point<<<");

        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        restartConnexusService();
        OrderCreationTestSetScript.initializeTestCase(flagUpdated);

        //Pre-Condition
        //1.Drop an Rx for a patient and process till 4 point using C4 opioid controlled drug.
        OrderCreationTestSetScript.createNewPatient(inputData);
        OrderCreationTestSetScript.performDropOff(Priority.Critical);
        connexusAppUtils.getOpioidControlledDrugNames(inputData.get("DRUG_CLASS"));
        OrderCreationTestSetScript.performInput(inputData);
        //1. Open the Rx which is 4 point mentioned in pre-condition | 4 point screen should be displayed.
        OrderCreationTestSetScript.launchAndVerify4PointScreen();

        //2. Verify Acute and Non-Acute radio buttons are displayed below Rx image | Acute and Non-Acute radio buttons should be displayed.
        OrderCreationTestSetScript.verifyAcuteAndNonAcutePositionOn4Point();

        //3. Click on Acute radio button and verify “Initial Fill?” text and "Yes" "No" radio buttons are populated below the Acute Condition Area | “Initial Fill?” text and "Yes" "No" radio buttons should be populated below the Acute Condition Area
        OrderCreationTestSetScript.clickAcuteRadioButtonOn4Point();
        OrderCreationTestSetScript.verifyInitialFillPositionOn4Point();

        //To continue the flow
        OrderCreationTestSetScript.closeFourPoint();
        System.out.println("<<<HWPHME2E_205_Tc_13_opioid_acute_non_acute_C4_initial_fill_Yes_No_4point>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether “Initial Fill?” text and "Yes" "No" radio buttons are populated below the
     * Acute Condition Area upon clicking on "Acute Condition" radio button at 4 Point for new rx with C5 opioid drug
     * Pre-Conditions:
     * 1. Drop an Rx for a patient and process till 4 point using C5 opioid controlled drug.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-206")
    @Test(description = "To verify whether “Initial Fill?” text and Yes or No radio buttons are populated below the Acute Condition Area upon clicking on Acute Condition radio button at 4 Point for new rx with C5 opioid drug.",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"HWPHME2E_205_Tc_13_opioid_acute_non_acute_C4_initial_fill_Yes_No_4point"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/orderCreationP2DataBook.json", sheetName = "orderCreationP2DataSheet")
    public void HWPHME2E_206_Tc_14_opioid_acute_non_acute_C5_initial_fill_YES_No_4point(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_206_Tc_14_opioid_acute_non_acute_C5_initial_fill_YES_No_4point<<<");

        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        OrderCreationTestSetScript.initializeTestCase(flagUpdated);
        //Pre-Condition
        //1. Drop an Rx for a patient and process till 4 point using C5 opioid controlled drug.
        OrderCreationTestSetScript.performDropOff(Priority.Critical);
        connexusAppUtils.getOpioidControlledDrugNames(inputData.get("DRUG_CLASS"));
        OrderCreationTestSetScript.performInput(inputData);

        //1. Open the Rx which is 4 point mentioned in pre-condition | 4 point screen should be displayed.
        OrderCreationTestSetScript.launchAndVerify4PointScreen();

        //2. Verify Acute and Non-Acute radio buttons are displayed below Rx image | Acute and Non-Acute radio buttons should be displayed.
        OrderCreationTestSetScript.verifyAcuteAndNonAcutePositionOn4Point();

        //3. Click on Acute radio button and verify “Initial Fill?” text and "Yes" "No" radio buttons are populated below the Acute Condition Area | “Initial Fill?” text and "Yes" "No" radio buttons should be populated below the Acute Condition Area
        OrderCreationTestSetScript.clickAcuteRadioButtonOn4Point();
        OrderCreationTestSetScript.verifyInitialFillPositionOn4Point();

        //To continue the flow
        OrderCreationTestSetScript.closeFourPoint();

        System.out.println("<<<HWPHME2E_206_Tc_14_opioid_acute_non_acute_C5_initial_fill_YES_No_4point>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Rx moves to 4 point and Acute and non-acute buttons are displayed in 4 point when prescriber
     * is changed at Filling where Acute is selected and processed.
     * Pre-Conditions:
     * 1. Drop an Rx and process till Filing with opioid control drug and Acute button should be selected for the RX.
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-191")
    @Test(description = "To verify whether Rx moves to 4 point and Acute and non-acute buttons are displayed in 4 point when prescriber is " +
            "changed at Filling where Acute is selected and processed.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"HWPHME2E_205_Tc_13_opioid_acute_non_acute_C4_initial_fill_Yes_No_4point"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/orderCreationP2DataBook.json", sheetName = "orderCreationP2DataSheet")
    public void HWPHME2E_191_Tc_15_Acute_non_acute_Modify_Prescriber_change_Filling(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_191_Tc_15_Acute_non_acute_Modify_Prescriber_change_Filling<<<");

        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        OrderCreationTestSetScript.initializeTestCase(flagUpdated);

        //Pre-Condition
        //Drop an Rx and process till Filing with opioid control drug and Acute button should be selected for the RX.
        OrderCreationTestSetScript.performDropOff(Priority.Critical);

        //As the precondition does not specify any class for Controlled Opioid Drug, processing c5 Opioid Drug
       connexusAppUtils.getOpioidControlledDrugNames(inputData.get("DRUG_CLASS"));

        //perform input for Controlled drug
        OrderCreationTestSetScript.performInput(inputData);
        //perform 4 point point for controlled drug rx
        OrderCreationTestSetScript.launchAndVerify4PointScreen();
        OrderCreationTestSetScript.clickAcuteRadioButtonOn4Point();
        OrderCreationTestSetScript.selectCheckBoxesOn4Point();
        OrderCreationTestSetScript.clickInitialFillYes4Point();
        OrderCreationTestSetScript.accept4PointScreen();
        OrderCreationTestSetScript.performChkDUR();
        OrderCreationTestSetScript.verifyRxInFillingQueue();
        //1.Open the Rx which is in Filling and modify the Prescriber and Accept | RTS should be reprinted pop up should be displayed.
        //2.Click on Ok and verify Rx moves to 4 point | Rx should move back to 4 point.
        OrderCreationTestSetScript.modifyPrescriberInFilling(inputData.get("PRESCRIBER_DEA"));
        OrderCreationTestSetScript.verifyRequestToSend4Point();

        OrderCreationTestSetScript.verifyRxIn4PointQueue();

        //3.Open the rx in 4 point and verify Acute an Non-acute button are displayed below the Rx image in  4 point screen | Acute and Non-acute button should be displayed.
        OrderCreationTestSetScript.launchAndVerify4PointScreen();
        OrderCreationTestSetScript.verifyAcuteAndNonAcutePositionOn4Point();
        OrderCreationTestSetScript.closeFourPoint();

        System.out.println("<<<HWPHME2E_191_Tc_15_Acute_non_acute_Modify_Prescriber_change_Filling>>>");
    }
}
