package connexus.coretest.testcases.p3;

import connexus.coretest.testscripts.OrderCreationTestSetScript;
import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class OrderCreationTestSet1 {

    OrderCreationTestSetScript orderCreationTestSetScript = new OrderCreationTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    ConnexusAPIManager connexusAPIManager;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAPIManager = new ConnexusAPIManager();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

     /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Verify that the quick quote if getting displayed on clicking on the F8 key
     *
     * Jira No. : HWORDCR-1899
     *
     * Pre-Conditions:
     * User is logged into Connexus
     *
     * Additional preconditions by author:
     *  Only testing a feature in the drop-off screen.  no new patient, etc.
     *
     *  Cancel the Drop Off process.
     *      Not actually performing a drop off, return state to main menue.
     *
     * Test Steps (Algorithm)
     *
     * START
     *
     * 1.a Connexus starts sucessfully as H&W user
     *
     * 1.b Click on Drop off icon.
     * 	    Drop off-screen should display.
     *
     * 2. Click on F8 (hit f8 on the keyboard)
     *      Quick quote screen should display.
     *
     * 3. Enter the Drug ndc and quantity and click on Price.
     *      Price should display.
     *
     * 4.a Click on Close.
     * 	    Quick quote screen should close.
     *
     * 4.b Close DropOff menue.
     *
     * END
     *
     * Author: Charles Allensworth(vn50vo7)
     *
     * JIRA Testcase id : HWPHME2E-571
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "To Verify that the quick quote if getting displayed on clicking on the F8 key",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP3DataBook.json", sheetName = "OrderCreationP3")
    public void HWPHME2E_571_tc_2_UAT_DROP_OFF_Quickquote(Map<String, String> inputData) {
        System.out.println(">>>START: tc_2_UAT_DROP_OFF_Quickquote<<<");
        //Pre-Conditions
        // 1.a Connexus starts sucessfully as H&W user
        //handled in BeforeClass directive

        //Test Steps
        //1.b Click on Drop off icon.
        orderCreationTestSetScript.clickAndValidateDropOffScreenWithQuickNote();
        //2. Click on F8 (hit f8 on the keyboard).
        orderCreationTestSetScript.openQuickQuote();
        //3. Enter the Drug ndc and quantity and click on Price.
        orderCreationTestSetScript.enterDrugNDC_And_ClickPrice(inputData);
        //4. Click on Close.
        orderCreationTestSetScript.clickToCloseQuickPrice();
        System.out.println("<<<END: tc_2_UAT_DROP_OFF_Quickquote>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:To verify that Technician will not be able to open the pharmacist resolution Rx for a FAX.
   *
   * Pre-Conditions:
   * 1.Pharmacist should be logged into Connexus
   * 2.Create a patient and process FAX Rx till input
   * JIRA Testcase id : HWPHME2E-208
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify that Technician will not be able to open the pharmacist resolution Rx for a FAX.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP3DataBook.json", sheetName = "OrderCreationP3")
    public void HWPHME2E_208_tc_11_HWORDCR_2044_OPT_Resolution_019(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_208 initially logged in as a Pharmacist and sending Input to manual resolution and login as as a Technician and validating the work queue status.<<<");
        Reporter.log("<<<HWPHME2E_208 initially logged in as a Pharmacist and sending Input to manual resolution and login as as a Technician and validating the work queue status.>>>");
        // Pre-Conditions
        //1.Pharmacist should be logged into Connexus
        //2.Create a patient and process FAX Rx till input
        orderCreationTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationTestSetScript.createNewPatient(inputData);
        orderCreationTestSetScript.dropOffPatientWithFax();
        //1.Search for the patient by clicking F6.| Rx will be in input work queue.
        //2.At input, send Rx to RPH only resolution to contact prescriber | Rx will go to RPH only Resolution for Contact Prescriber.
        orderCreationTestSetScript.sendInputToManualResolution(inputData);
        //3.Login as technician and search for the Rx | Rx should be in Resolution screen.
        //4.double click on the search result | Technician will not able to open the rx pop up should display(Authorization Error).
        orderCreationTestSetScript.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        orderCreationTestSetScript.validateTechnicianOpeningResolutionRx(inputData);
        Reporter.log("<<<HWPHME2E_208 Logged in as Technician and validating error message when i am trying to resolve the queue>>>");
        System.out.println("<<<HWPHME2E_208 initially logged in as a Pharmacist and sending Input to manual resolution and login as as a Technician and validating the work queue status.>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
  * Test Description:To verify when an Rx is pending in MN double 4 point and patient marked as deceased the Rx moves to patient deceased resolution.
  *
  * Pre-Conditions:
  * 1.User should be logged into Connexus
  * 2. Login in as a Pharmacist and Drop an Rx and take it fourpoint
  * 3. Rx should be in 4 point.
  * 4.State should be configured as MN
  * JIRA Testcase id - HWPHME2E-212
  * Author: Tarun(vn510o1)
  * Marked testcase as obsolete as discussed with Sandhya
  ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify when an Rx is pending in MN double 4 point and patient marked as deceased the Rx moves to patient deceased resolution.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP3DataBook.json", sheetName = "OrderCreationP3")
    public void HWPHME2E_212_tc_16_HWORDCR_2058_Deceased_Patient_MN(Map<String, String> inputData) {
        System.out.println(">>>tc_16_HWORDCR_2058_Deceased_Patient_MN<<<");

        // Pre-Conditions
        // 1.User should be logged into Connexus
        // 2. Login in as a Pharmacist and Drop an Rx and take it fourpoint
        // 3. Rx should be in 4 point.
        // 4.State should be configured as MN
        tearDown();

        orderCreationTestSetScript.updateStoreState(inputData.get("STATE"));
        String siteId =prop.getProperty("cnx.store");
        connexusAPIManager.restartConnexusService(siteId);
        orderCreationTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //1.Hit Ctrl+D ,search for the patient and drop an Rx|  Rx should be pending in Input.
        orderCreationTestSetScript.createPatient(inputData);
        orderCreationTestSetScript.dropOffAnRx();
        orderCreationTestSetScript.performInput(inputData);
        orderCreationTestSetScript.perform4Point();
        orderCreationTestSetScript.performChkDUR();
        orderCreationTestSetScript.performFilling();
        orderCreationTestSetScript.performVisualVerify();
        orderCreationTestSetScript.performPickUp(inputData);
        orderCreationTestSetScript.performCounselling();
        orderCreationTestSetScript.performPOS();
        tearDown();
        orderCreationTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationTestSetScript.performDouble4Point();

        //2.Move the Rx till double 4point | Rx should be pending  in MN Double 4 point
        //3.Click on the folder icon and mark the patient as deceased | Patient should get updated as deceased
        //4.Verify the status of the Rx | Rx should be pending in patient deceased resolution
        orderCreationTestSetScript.validateRxResolutionPatientDeceased();
        orderCreationTestSetScript.validateResolutionMessage(inputData);
        System.out.println("<<<tc_16_HWORDCR_2058_Deceased_Patient_MN>>>");
    }*/
}
