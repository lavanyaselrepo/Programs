package connexus.coretest.testcases;

import bom.tests.WrapperTestScript;
import connexus.coretest.testscripts.LoginTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.*;

import java.util.Map;



public class LoginTestSet {

    ConnexusAppUtils connexusUtils;
    LoginTestScript loginScript;

    @BeforeClass
    public void startAppium() {
        connexusUtils = new ConnexusAppUtils();
        connexusUtils.startAppiumServer();
    }

    @BeforeMethod
    public void performLogin() {
        loginScript = new LoginTestScript();
        loginScript.siteId = connexusUtils.getStoreId();
        loginScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterMethod
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();

    }

    @AfterClass
    public void closeAppium() {
        connexusUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the creation of temp user Technician by creating temp user(Tools -> Temp User Setup) and check if user data is available in database
     *
     * Pre-Conditions:  Homeoffice/Pharmacist login
     *
     * Author: Aparna(vn50izt)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Verify the creation of temp user Technician",
            enabled = true, priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginDataBook.json", sheetName = "TechDetails")
    public void HWPHME2E_1829_create_temp_user_technician(Map<String, String> inputData) {
        String userDetails = loginScript.launchAddTempUser("TECHNICIAN", inputData);
        loginScript.validateDBData(userDetails);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the creation of temp user Pharmacist by creating temp user(Tools->Temp User Setup) and check if user data is available in database
     *
     * Pre-Conditions:  Homeoffice/Pharmacist login
     *
     * Author: Aparna(vn50izt)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Verify the creation of temp user Pharmacist",
            enabled = true, priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginDataBook.json", sheetName = "TechDetails")
    public void HWPHME2E_4477_create_temp_user_pharmacist(Map<String, String> inputData) {
        String userDetails = loginScript.launchAddTempUser("PHARMACIST", inputData);
        loginScript.validateDBData(userDetails);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the creation of temp user Technician and login without resetting password
     *
     * Pre-Conditions:  Homeoffice/Pharmacist login
     *
     * Author: Aparna(vn50izt)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Verify the creation of temp user Technician and login without resetting password",
            enabled = true, priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginDataBook.json", sheetName = "TechDetails")
    public void HWPHME2E_1326_create_temp_user_and_skip_password(Map<String, String> inputData) {
        String userDetails = loginScript.launchAddTempUser("TECHNICIAN", inputData);
        closeConnexus();
        loginScript.launchConnexusLogin(LoginAs.userType.TECHNICIAN_ADFlagOff);
        loginScript.loginAsTempUserWithoutPasswordReset(LoginAs.userType.TECHNICIAN_ADFlagOff, userDetails, userDetails);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Create temp user in storeA and try to login with same credential in storeB(technician and pharmacist)
     *
     * Pre-Conditions:  Temp USer login
     *
     * Author: Aparna(vn50izt)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To create temp user in storeA and try to login with same credential in storeB",
            enabled = true, priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginDataBook.json", sheetName = "TechDetails")
    public void HWPHME2E_1325_loginTempUser_in_store(Map<String, String> inputData) {
        closeConnexus();
        String userDetails = inputData.get("USERID_TECHNICIAN");
        String storeNumber = inputData.get("CHANGE_STORE_NUMBER");
        Reporter.log("Logging into connexus with Temp user Technician credentials");
        loginScript.launchConnexusLogin(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        loginScript.loginAsTempUserWithoutPasswordResetInAnotherStore(LoginAs.userType.TECHNICIAN_ADFlagOff, userDetails, userDetails, storeNumber);
        Reporter.log("Logging into connexus with Temp Pharmacist credentials");
        userDetails = inputData.get("USERID_PHARMACIST");
        loginScript.launchConnexusLogin(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        loginScript.loginAsTempUserWithoutPasswordResetInAnotherStore(LoginAs.userType.TECHNICIAN_ADFlagOff, userDetails, userDetails, storeNumber);
    }

     /*----------------------------------------------------------------------------------------------------------
     * Test Description: HWPHME2E_1408_Verifying claim details screen in launched
     *
     * Pre-Conditions:  Homeoffice/Pharmacist login
     *
     * Author: Diya(vn58o0i)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "To validate claim detail screen is loading in connexus", enabled = true, priority = 2,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginTestDataBook.json", sheetName = "BOMData")
    public void HWPHME2E_1408_validate_claim_detail_screen_is_loading(Map<String, Object> inputData){
        Reporter.log("Validate claim detail screen is loading");

        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_1408 - To validate claim detail screen is loading in connexus");

        String rxNbr = String.valueOf(stagedClaimData.getRxNbr());
        loginScript.validateClaimDetailsScreen(rxNbr, "rx");
        Reporter.log("Validation is done for HWPHME2E-1408");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: HWPHME2E_1410_Validate TP Extra Info screen loading
   *
   * Pre-Conditions:  Homeoffice/Pharmacist login
   *
   * Author: Diya(vn58o0i)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate TP Extra Info screen loading in Connexus", enabled = true, priority = 1,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/LoginTestDataBook.json", sheetName = "Testdata")
    public void HWPHME2E_1410_validate_TP_extra_info_screen_is_loading(Map<String, String> inputData){
        Reporter.log("Validate TP Extra Info screen is loading");
        connexusUtils.getStoreId();
        loginScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        loginScript.createNewPatient(inputData,1);
        loginScript.performDropOff(Priority.Critical);
        loginScript.performInput(inputData);
        loginScript.verifyRxIn4PointQueue();
        loginScript.verifyVerbiageOfIdQlfr(inputData);
        Reporter.log("Validation is done for HWPHME2E-1410");
    }
}