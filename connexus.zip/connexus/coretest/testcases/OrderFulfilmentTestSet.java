package connexus.coretest.testcases;

import connexus.coretest.testscripts.OrderFulfilmentTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderFulfilmentTestSet {

    OrderFulfilmentTestSetScript orderFulfilmentTestSetScript;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
        orderFulfilmentTestSetScript = new OrderFulfilmentTestSetScript();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that Leaflet and Med guide will not be printed and only STR  will be printed when Fill Date is changed when Rx Splited at Pickup work queue
     *
     * Pre-Conditions:
     * 1. 2 New different Patient profile should be available in ConnexUs
     * 2. User should be able to process an Rx for the 2 patient in same order and it should be in pickup work queue
     *
     * Author: Lakshmi Priya(vn510nm)
     * * INVALID TESTCASE -> Marking this test case as Invalid as currently bagging is disabled across the chain of store.
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify that Leaflet and Med guide will not be printed and only STR " +
            "will be printed when Fill Date is changed when Rx Splited at Pickup work queue",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/orderFulfilmentDataBook.json", sheetName = "orderFulfilmentDataSheet")
    public void tc_01_148757_HWOF_STR_Rebill_Split_Bagging(Map<String, String> inputData) {
        System.out.println(">>>tc_01_148757_HWOF_STR_Rebill_Split_Bagging<<<");

        //pre-conditions
        //1. 2 New different Patient profile should be available in ConnexUs
        //2. User should be able to process an Rx for the 2 patient in same order and it should be in pickup work queue
        orderFulfilmentTestSetScript.createPatientForSplitBag(inputData);

        //createPatient method is implemented twice to create 2 different patient
        orderFulfilmentTestSetScript.createPatientForSplitBag(inputData);
        orderFulfilmentTestSetScript.dropRxTillBaggingForSplitBag(inputData);

        //1.Login to Connexus | User should be able to login to Connexus
        //2.Search for the Rx in F6 search screen | Rx should be available in pickup work queue
        //3.Hit F11,search for the 1st patient and click on search | In check out screen both the Rx should be displayed
        orderFulfilmentTestSetScript.openCheckOutScreen(inputData);

        //4.Check one Rx and process checkout | System should prompt to enter new bag number for the checked Rx
        orderFulfilmentTestSetScript.splitBagAndCheckOutOneRx(inputData);

        //5.Verify the Rx get split with new and old bag numbers | Rx should be splinted and New bag number and Old bag number should be tagged to the respective rx's
        orderFulfilmentTestSetScript.assignBagSplitOrder(inputData);

        //6.Hit F6, Search for the Rx and Complete bagging for the Rx | User should be able to complete bagging for the Rx
        orderFulfilmentTestSetScript.verifyRxSplitAndCompleteBagging(inputData);

        //7.Verify STR is printed after bagging is completed | STR should be printed
        orderFulfilmentTestSetScript.enterRxIntoRxLookUp(inputData);
        orderFulfilmentTestSetScript.verifyScanTagReceiptEnabled(inputData);
        orderFulfilmentTestSetScript.closeRxLookUpPage(inputData);

        System.out.println("<<<tc_01_148757_HWOF_STR_Rebill_Split_Bagging>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify 'Scan Tag Receipt' option is enabled in the Print menu under File menu when Rx is searched using F7 when the Rx is in Pickup Work Queue
     *
     * Pre-Conditions:
     * 1. Pharmacy Associate logged into the Connexus Application
     * 2. Pharmacy Associate created an Rx and completed bagging
     * 3. Rx is in Pickup Work Queue
     * JIRA Id : HWPHME2E-189
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify 'Scan Tag Receipt' option is enabled in the Print menu under File menu " +
            "when Rx is searched using F7 when the Rx is in Pickup Work Queue",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/orderFulfilmentDataBook.json", sheetName = "orderFulfilmentDataSheet")
    public void HWPHME2E_189_TC_40145_Bagging_ON_Print_Scan_Tag_Receipt(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_189_TC_40145_Bagging_ON_Print_Scan_Tag_Receipt<<<");

        //pre-conditions
        //1. Pharmacy Associate logged into the Connexus Application
        //2. Pharmacy Associate created an Rx and completed bagging
        //3. Rx is in Pickup Work Queue

        // Since flag 28750 is now deprecated, this entire conditional login dance is unnecessary. The test needs Pharmacist login directly.
        // Before:
//        orderFulfilmentTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
//        if(connexusAppUtils.readAndUpdateFlag("28750","FALSE")) {
//            tearDown();
//            orderFulfilmentTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
//        }
        // AFTER:
        orderFulfilmentTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);


        orderFulfilmentTestSetScript.createPatientForSplitBag(inputData);
        orderFulfilmentTestSetScript.dropRxTillBagging(inputData);
        orderFulfilmentTestSetScript.verifyRxInPickUp(inputData);

        //1.Press F7 button | RX Look-Up screen should get opened
        //2.Enter Rx number or Patient Name or Date of birth or Phone Number and click on Search Now | Search results should be displayed based on the Search Criteria
        //3.Select the Rx in Search Results | Rx should get selected
        orderFulfilmentTestSetScript.enterRxIntoRxLookUp(inputData);

        //4.Go to File Menu and click on Print Option | Print Option should be enabled and it should display the option available on the right hand side of the print menu
        //5.Check 'Scan Tag receipt' option is enabled on the Print menu | 'Scan Tag receipt' option should be enabled on the print menu
        orderFulfilmentTestSetScript.verifyScanTagReceiptEnabled(inputData);

        //To continue the flow
        orderFulfilmentTestSetScript.closeRxLookUpPage(inputData);

        System.out.println("<<<HWPHME2E_189_TC_40145_Bagging_ON_Print_Scan_Tag_Receipt>>>");
    }
}
