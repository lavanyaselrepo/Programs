package connexus.coretest.testcases;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceTestSet2 {

    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    AutomationManager automationManager = AutomationManager.getInstance();

    @BeforeClass
    public void performlogin() {
        automationManager.performSleep(10);
        connexusAppUtils.startAppiumServer();
        userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from Input work queue and press Alt+E
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-590")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from Input work queue and press Alt+E",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_590_tc_19_Remove_Cancel_Popup_Input(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_590_tc_19_Remove_Cancel_Popup_Input<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till Input | Rx should be in Input work queue
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.openInputOrderSearch(inputData);

        //3. Select the Rx and press Enter | Input screen should be displayed
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to Name field in the Patient section on the 4 point Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderIconOnInput(inputData);

        //5. Press Alt+E button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitPatientMaintenanceUsingAltEKeys(inputData);

        System.out.println("<<<HWPHME2E_590_tc_19_Remove_Cancel_Popup_Input>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from 4 Point work queue and click on the Exit button
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-591")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from 4 Point work queue and click on the Exit button",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_591_tc_20_Remove_Cancel_Popup_4_Point(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_591_tc_20_Remove_Cancel_Popup_4_Point<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till 4 Point | Rx should be in 4 point work queue
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.open4PointOrderSearch(inputData);

        //3. Select the Rx and double click on it | 4 Point screen should be displayed
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to Name field in the Patient section on the 4 point Screen | General Information tab of New PMS should be displayed.
        userExperienceTestSetScript.clickOnFolderIconOn4Point(inputData);

        //5. Click on Exit button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed.
        userExperienceTestSetScript.exitPatientMaintenance(inputData);

        System.out.println("<<<HWPHME2E_591_tc_20_Remove_Cancel_Popup_4_Point>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from Filling work queue and click on the Exit button
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-592")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from Filling work queue and click on the Exit button",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_592_tc_21_Remove_Cancel_Popup_Filling(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_592_tc_21_US_390315_Remove_Cancel_Popup_Filling<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till Filling | Rx should be in filling work queue
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.openFillingOrderSearch(inputData);

        //3. Select the Rx and double click on it | Modify details screen should be displayed
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to patient Name field on the Modify details Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderModifiedDetails(inputData);

        //5. Click on Exit button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitPatientMaintenanceUsingExitBtn(inputData);

        System.out.println("<<<HWPHME2E_592_tc_21_Remove_Cancel_Popup_Filling>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from visual verify work queue and press ESC button
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-593")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from visual verify work queue and press ESC button",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_593_tc_22_Remove_Cancel_Popup_Viusual_Verify(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_593_tc_22_Remove_Cancel_Popup_Viusual_Verify<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till Visual Verify | Rx should be in visual verify work queue
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.openVisVerOrderSearch(inputData);

        //3. Select the Rx and press Enter | Modify details screen should be displayed
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to patient Name field on the visual verify Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderIconOnVisVer(inputData);

        //5. Press Esc button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitFromPatientMaintenanceUsingEscKeys(inputData);

        System.out.println("<<<HWPHME2E_593_tc_22_Remove_Cancel_Popup_Viusual_Verify>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from bagging work queue and press Alt+E
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    // tc_23 - Bagging is disabled in all the stores, ignore it.
  /*  @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from bagging work queue and press Alt+E",
            priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_23_US_390315_Remove_Cancel_Popup_Bagging(Map<String, String> inputData) {
        System.out.println(">>>tc_23_US_390315_Remove_Cancel_Popup_Bagging<<<");

        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till bagging | Rx should be in bagging  work queue
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.openBaggingOrderSearch(inputData);

        //3. Select the Rx and double click on it | Modify details screen should be displayed.
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to patient Name field on the Modify details Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderModifiedDetails(inputData);

        //5. Press Alt+E button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitPatientMaintenanceUsingAltEKeys(inputData);

        System.out.println("<<<tc_23_US_390315_Remove_Cancel_Popup_Bagging>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from pick up work queue and press ESC button
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-594")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from pick up work queue and press ESC button",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_594_tc_24_Remove_Cancel_Popup_Pickup(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_594_tc_24_Remove_Cancel_Popup_Pickup<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1. Drop an rx and process it till pick up | Rx should be in pick up  work queue.
        //2. Press F6 and search for the Rx | Search result should be displayed
        userExperienceTestSetScript.openPickUpOrderSearch(inputData);

        //3. Select the Rx and Press Enter | Modify details screen should be displayed.
        userExperienceTestSetScript.selectRxFromSearch(inputData);

        //4. Click on the folder icon, next to patient Name field on the Modify details Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderModifiedDetails(inputData);

        //5. Press Esc button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitFromPatientMaintenanceUsingEscKeys(inputData);

        System.out.println("<<<HWPHME2E_594_tc_24_Remove_Cancel_Popup_Pickup>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from POS work queue  and press ESC button
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE
     * 2. Patient profile should exist in the Store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-595")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  doesn't make any changes in the Patient profile from POS work queue  and press ESC button.",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_595_tc_25_Remove_Cancel_Popup_POS(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_595_tc_25_Remove_Cancel_Popup_POS<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");
        //1. Press F6
        //2. Select POS from the drop down and click on Search Now
        userExperienceTestSetScript.searchForPOSOrders(inputData);

        //3. Select the Rx and Press Enter | Modify details screen should be displayed.
        userExperienceTestSetScript.selectRxFromSearchForPOS(inputData);

        //4. Click on the folder icon, next to patient Name field on the Modify details Screen | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.clickOnFolderModifiedDetails(inputData);

        //5. Press Esc button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed
        userExperienceTestSetScript.exitFromPatientMaintenanceUsingEscKeys(inputData);

        System.out.println("<<<HWPHME2E_595_tc_25_Remove_Cancel_Popup_POS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that DL information are saved into Database tables.
     *
     * Pre-Conditions:
     * 1. User Should be logged in to the connexus
     * 2. PMS Flag 27247 should be "TRUE"
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-589")
    @Test(description = "To verify that DL information are saved into Database tables",
            priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_589_tc_26_US_HappyPathAutomation(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_589_tc_26_US_HappyPathAutomation<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //New Patient was already created as part of tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName
        //1.Login to Connexus and Search for a patient | Search result should not be displayed
        userExperienceTestSetScript.createNewPatient(inputData);
        //2.Click on Host Look up | Search result should not be displayed
        //3.Click on New | General Information tab of new PMS should be displayed
        //4.Enter all the mandatory details in general information tab of new PMS | User should be able to enter all the details
        //5.Validate that user is able to provide the patient DL details | User should be able to provide the patient  DL details
        //6.Validate the database tables having DL records | Records should be present in the database tables
        userExperienceTestSetScript.validatePatientLicenseInDB(inputData);

        System.out.println("<<<HWPHME2E_589_tc_26_US_HappyPathAutomation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that Complete information in patient maintenance screen and create a profile with all possible fields entered
     *
     * Pre-Conditions:
     * 1. User Should be logged in to the connexus
     * 2. PMS Flag 27247 should be "TRUE"
     *
     * Author: Lakshmi Priya(vn510nm)
     // Below scenario is already covered in E2E test case. so, it is duplicate, no need to validate.
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify that Complete information in patient maintenance screen and create a profile with all possible fields entered",
            priority = 27, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_27_US_HappyPathAutomation(Map<String, String> inputData) {
        System.out.println(">>>tc_27_US_HappyPathAutomation<<<");

        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //New Patient was already created as part of tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName
        //1.Login to Connexus and Search for a patient | Search result should not be displayed
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);

        //2.Click on Host Look up | Search result should not be displayed
        //3.Click on New | General Information tab of new PMS should be displayed
        //4.Enter all the mandatory details in general information tab of new PMS | User should be able to enter all the details
        //5.Validate that user is able to provide all the fields on the general information tab and save the profile | User should be able to provide all the fields on the general information tab and save the profile
        userExperienceTestSetScript.validatePatientDetails(inputData);

        //To continue the Flow
        userExperienceTestSetScript.closePatientMaintenanceScreen(inputData);

        System.out.println("<<<tc_27_US_HappyPathAutomation>>>");
    }*/

    //Below test cases from tc_28 to tc_31 are invalid because old PMS screen has been replaced by new PMS screen, ignore it
    /*----------------------------------------------------------------------------------------------------------
   * Test Description:To verify whether user is able to enter  and save phone numbers in Phone 1, Phone 2
   * and Phone 3 fields.
   *
   * Pre-Conditions:
   * 1. New PMS Flag 27247 should be set to 'TRUE'
   *
   * Author: Sugapriya S(vn510of)
   ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify whether user is able to enter  and save phone numbers in Phone 1, Phone 2 and " +
            "Phone 3 fields", priority = 28, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_28_PMS_Phone_field_Save_Button(Map<String, String> inputData) {
        System.out.println(">>>tc_28_PMS_Phone_field_Save_Button<<<");

        //1.Login to Connexus and Press Ctrl+Shift+P | Patient search screen should be displayed.
        //2.Enter FN,LN and DOB and hit on Search button |Search result should not be displayed.
        //3.Click on Host Look up | Host search results should be displayed.
        //4.Click on New | General Information tab of New PMS should be displayed.
        //5.Enter all the mandatory details |User should be able to enter the details
        //6.Enter 10 digit phone number in phone 1 field |User should be able to enter phone no in Phone 1 field
        //7.Enter 10 digit phone number in phone 2 field |User should be able to enter phone no in Phone 2 field
        //8.Enter 10 digit phone number in phone 3 field |User should be able to enter phone no in Phone 3 field
        //9.Click on 'Save & Close' button on the General Information Screen on New PMS |Patient profile should be saved in the store and PMS should be closed
        //10.Open Patient search screen and search for the above patient |General Information screen on New PMS should be displayed.
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);

        //11.Verify the Phone 1, Phone 2 and Phone 3 fields |Phone numbers entered above should be displayed in Phone 1, Phone 2 and Phone 3 fields
        userExperienceTestSetScript.validatePhone(inputData);

        System.out.println("<<<tc_28_PMS_Phone_field_Save_Button>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify whether user is able to  modify the   Preferred Contact No option
    * under General Information Tab  in New PMS at any point of time
    *
    * Pre-Conditions:
    * 1.New PMS Flag (27247) value should be set to 'TRUE'.
    * 2. Patient Profile with Phone number should exist in the store
    *
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
 /*   @Test(description = "To verify whether user is able to  modify the   Preferred Contact No option under General Information Tab  in New PMS at any point of time", priority = 29, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_29_PMS_Redesign_Edit_Preferred_Contact_No(Map<String, String> inputData) {
        System.out.println(">>>tc_29_PMS_Redesign_Edit_Preferred_Contact_No<<<");

        //1. Log in to Connexus and Open Patient Search Screen | Patient Search Screen should be displayed
        //2.Search for a patient | Search result should be displayed
        //3.Select the patient and double click on it | New PMS should be displayed
        //4. Select the Preferred Contact Number check box next to Phone2 | Phone2 Radio button should get selected and Phone1 & Phone3
        userExperienceTestSetScript.preferredContactNumberCheckboxStatus(inputData);

        System.out.println("<<<tc_29_PMS_Redesign_Edit_Preferred_Contact_No>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user can select a preferred contact number option under Contact Information
     * section in the New PMS when the patient profile doesn't have any Phone number.
     *
     * Pre-Conditions:
     * 1. Patient Profile shouldn't have any Phone number.
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
 /*   @Test(description = "To verify whether user can select a preferred contact number option under Contact Information section in the New PMS when the patient profile doesn't have any Phone number.", priority = 30, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_30_PMS_Redesign_Preferred_Contact_No(Map<String, String> inputData) {
        System.out.println(">>>tc_30_PMS_Redesign_Preferred_Contact_No<<<");

        //1. Log in to Connexus and Open Patient Search Screen |Patient Search Screen should be displayed
        //2. Search for a patient |Search result should be displayed
        //3.Select the patient and double click on it |New PMS should be displayed
        //4.Try to select  the check box under preferred contact number  under the Contact information section |User
        // should not be able to check the checkbox
        userExperienceTestSetScript.verifyPrefContact(inputData);

        System.out.println("<<<tc_30_PMS_Redesign_Preferred_Contact_No>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the preferred number detail is stored
     * in subject_comm table with the sequence number 20
     *
     * Pre-Conditions:
     * 1. Patient had provided a contact number
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
 /*   @Test(description = "To verify whether the preferred number detail is stored in subject_comm table with the sequence number 20", priority = 31, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_31_PMS_Redesign_Preferred_Contact_No(Map<String, String> inputData) {
        System.out.println(">>>tc_31_PMS_Redesign_Preferred_Contact_No<<<");

        //1. Log in to Connexus and Open Patient Search Screen |Patient Search Screen should be displayed
        //2. Search for a patient |Search result should be displayed
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);

        //3.Select the patient and double click on it |New PMS should be displayed
        //4.Select any one of the Preferred Contact Number check box next to Phone1,Phone 2, Phone 3\Check box should get selected
        //5.Click on Save & Close\Patient should be saved with selected Preferred Contact Number
        //6.Login to DB2 and verify the preferred contact number details|the preferred number details should be stored in subject_comm table with the sequence number 20
        userExperienceTestSetScript.changePrefContact(inputData);

        System.out.println("<<<tc_31_PMS_Redesign_Preferred_Contact_No>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether error pop up saying "Invalid Social Security number.
     * Please Re-enter. " is displayed when the first three digits of the SSN#a
     * entered by the user range between 900-999
     *
     * JIRA: HWPHME2E-588
     *
     * Pre-Conditions:
     * 1. New PMS Flag 27247 should be set to 'TRUE'
     *
     * Author: Tarun(vn510o1)
     // tc_33 to tc_35 all test cases are combined into tc_32 and validating in same screen New PMS
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-588")
    @Test(description = "To verify whether error pop up saying \"Invalid Social Security number. Please Re-enter. \" is displayed when the first three digits of the SSN# entered by the user range between 900-999", priority = 32, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_588_tc_32_UE_NewPMS_SocialSecurityNumberCleanup_digit(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_588_tc_32_UE_NewPMS_SocialSecurityNumberCleanup_digit<<<");
        connexusAppUtils.getStoreId();
        //Pre-Conditions:
        // * 1. New PMS Flag 27247 should be set to 'TRUE'

        //1. Login to Connexus and Search for a patient profile. | Search results should be displayed
        //2. Select the patient profile and Open New PMS | General Information tab of New PMS should be displayed
        userExperienceTestSetScript.searchPatientWithName(inputData);

        //3.Enter SSN# under Primary Third Party Information Section on the General Information tab of New PMS such that the first 3 digits range between 900-999 | User should be abe to enter the SSN# having first 3 digits ranging between 900-999
        //4. Verify the General Information tab of New PMS | Verify dialog box saying "Invalid Social Security number. Please Re-enter. " should be displayed.
        //5. Click on Ok button on the dialog box | Dialogue box should be closed and focus should be in SSN field
        userExperienceTestSetScript.patientMaintenancePageSsnValidation(inputData);

        //6. Enter SSN# such that the first 3 digits are "666" | User should be abe to enter the SSN# having first 3 digits 666
        //7. Verify the General Information tab of New PMS | Verify dialog box saying "Invalid Social Security number. Please Re-enter
        userExperienceTestSetScript.patientSearchPageSsnValidationFirst3Digits(inputData);

        //8.Enter SSN# such that the middlie 2 digits are "00" |User should be abe to enter the SSN# having mid 2 digits 00
        //9.Verify the General Information tab of New PMS |Verify dialog box saying "Invalid Social Security number. Please Re-enter. " should be displayed.
        //10.Click on Ok button on the dialog box \Dialogue box should be closed and focus should be in SSN field
        userExperienceTestSetScript.verifyInvalidSSN(inputData);

        //11.Enter SSN# such that the last 4 digits are "0000" |User should be abe to enter the SSN# having mid 2 digits 0000
        //12.Verify the General Information tab of New PMS |Verify dialog box saying "Invalid Social Security number. Please Re-enter. " should be displayed.
        //13.Click on Ok button on the dialog box \Dialogue box should be closed and focus should be in SSN field
        userExperienceTestSetScript.verifyLastInvalidSSN(inputData);

        System.out.println("<<<HWPHME2E_588_tc_32_UE_NewPMS_SocialSecurityNumberCleanup_digit>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether error pop up saying "Invalid Social Security number.
     * Please Re-enter. " is displayed when the SSN# entered by the user starts with 666.
     *
     * JIRA: HWPHME2E-588
     *
     * Pre-Conditions:
     * 1. New PMS Flag 27247 should be set to 'TRUE'
     *2. The SSN# format is 3+2+4
     *
     * Author: Tarun(vn510o1)
     // tc_33 to tc_35 all test cases are combined into tc_32 and validating in same screen New PMS
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-588")
/*    @Test(description = "To verify whether error pop up saying \"Invalid Social Security number. Please Re-enter. \" is displayed when the SSN# entered by the user starts with 666.", priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_588_tc_33_UE_NewPMS_SocialSecurityNumberCleanup_digit(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_588_tc_33_UE_NewPMS_SocialSecurityNumberCleanup_digit<<<");

        //Pre-Conditions:
        // * 1. New PMS Flag 27247 should be set to 'TRUE'

        //1.  Login to Connexus and Search for a patient profile. | Search results should be displayed
        //2. Select the patient profile and Open New PMS | General Information tab of New PMS should be displayed
        //3. Enter SSN# such that the first 3 digits are "666" | User should be abe to enter the SSN# having first 3 digits 666
        //4. Verify the General Information tab of New PMS | Verify dialog box saying "Invalid Social Security number. Please Re-enter
        userExperienceTestSetScript.patientSearchPageSsnValidationFirst3Digits(inputData);

        System.out.println("<<<HWPHME2E_588_tc_33_UE_NewPMS_SocialSecurityNumberCleanup_digit>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether error pop up saying "Invalid Social Security number.
     * Please Re-enter. " is displayed when the SSN# entered by the user has "00" in between
     *
      * JIRA: HWPHME2E-588
     *
     * Pre-Conditions:
     * 1. New PMS Flag 27247 should be set to 'TRUE'
     *2. The SSN# format is 3+2+4
     *
     * Author: Sugapriya S(vn510of)
     // tc_33 to tc_35 all test cases are combined into tc_32 and validating in same screen New PMS
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-588")
 /*   @Test(description = "To verify whether error pop up saying \"Invalid Social Security number. Please Re-enter. \" is displayed when the SSN# entered by the user has \"00\" in between", priority = 34, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_588_tc_34_UE_New_PMS_Social_Security_Number_Cleanup_digit(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_588_tc_34_UE_New_PMS_Social_Security_Number_Cleanup_digit<<<");

        //1. New PMS Flag 27247 should be set to 'TRUE'
        //1.Login to Connexus and Search for a patient profile. |Search results should be displayed
        //2.Select the patient profile and Open New PMS |General Information tab of New PMS should be displayed
        //3.Enter SSN# such that the middlie 2 digits are "00" |User should be abe to enter the SSN# having mid 2 digits 00
        //4.Verify the General Information tab of New PMS |Verify dialog box saying "Invalid Social Security number. Please Re-enter. " should be displayed.
        //5.Click on Ok button on the dialog box \Dialogue box should be closed and focus should be in SSN field
        userExperienceTestSetScript.verifyInvalidSSN(inputData);

        System.out.println("<<<HWPHME2E_588_tc_34_UE_New_PMS_Social_Security_Number_Cleanup_digit>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether error pop up saying "Invalid Social Security number.
     *  Please Re-enter. " is displayed when the SSN# entered by the user ends with "0000"
     *
     * JIRA: HWPHME2E-588
     *
     * Pre-Conditions:
     * 1. New PMS Flag 27247 should be set to 'TRUE'
     *2. The SSN# format is 3+2+4
     *
     * Author: Sugapriya S(vn510of)
     // tc_33 to tc_35 all test cases are combined into tc_32 and validating in same screen New PMS
   ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-588")
 /*   @Test(description = "To verify whether error pop up saying \"Invalid Social Security number. Please Re-enter. \" is displayed when the SSN# entered by the user ends with \"0000\"", priority = 35, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_588_tc_35_UE_New_PMS_Social_Security_Number_Cleanup_digit(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_588_tc_35_UE_New_PMS_Social_Security_Number_Cleanup_digit<<<");

        //1. New PMS Flag 27247 should be set to 'TRUE'

        //1.Login to Connexus and Search for a patient profile. |Search results should be displayed
        //2.Select the patient profile and Open New PMS |General Information tab of New PMS should be displayed
        //3.Enter SSN# such that the last 4 digits are "0000" |User should be abe to enter the SSN# having mid 2 digits 0000
        //4.Verify the General Information tab of New PMS |Verify dialog box saying "Invalid Social Security number. Please Re-enter. " should be displayed.
        //5.Click on Ok button on the dialog box \Dialogue box should be closed and focus should be in SSN field
        userExperienceTestSetScript.verifyLastInvalidSSN(inputData);

        System.out.println("<<<HWPHME2E_588_tc_35_UE_New_PMS_Social_Security_Number_Cleanup_digit>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed,
     * when user  doesn't make any changes in the Patient profile and click on the Exit button.
     *
     * JIRA: HWPHME2E-597
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE.
     * 2. Patient profile should exist in the Store.
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-597")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, " +
            "when user  doesn't make any changes in the Patient profile and click on the Exit button.",
            priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_597_tc_17_Remove_Cancel_Popup(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_597_tc_17_Remove_Cancel_Popup<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1.Login to Connexus and Search for a patient | Search result should be displayed
        //2.Select the patient and double click on it | General Information tab of New PMS should be displayed.
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.searchPatientWithName(inputData);

        //3.Click on Exit button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed.
        userExperienceTestSetScript.clickExitPMS();
        userExperienceTestSetScript.validateAbandonPopup();

        System.out.println("<<<HWPHME2E_597_tc_17_Remove_Cancel_Popup>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the cancel pop up/abandon changes pop up is not displayed, when user
     *  doesn't make any changes in the Patient profile from Drop off and click on the Exit button.
     *
     * JIRA: HWPHME2E-596
     *
     * Pre-Conditions:
     * 1. New PMS flag 27247 should be set to TRUE.
     * 2. Patient profile should exist in the Store.
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-596")
    @Test(description = "To verify whether the cancel pop up/abandon changes pop up is not displayed, when user  " +
            "doesn't make any changes in the Patient profile from Drop off and click on the Exit button.",
            priority = 34, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled=false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_596_tc_18_Remove_Cancel_Popup_Drop_Off(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_596_tc_18_Remove_Cancel_Popup_Drop_Off<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1.press Ctrl+D and enter a patient name as mentioned in the precondition. | patient profile should be displayed in the drop off screen
        userExperienceTestSetScript.searchPatientInDropOff(inputData);

        //2.Click on the folder icon, next to Patient Name field on the Drop off Screen. | General Information tab of New PMS should be displayed.
        userExperienceTestSetScript.clickFolderIconInDropOff(inputData);

        //3.Click on Exit button on the General Information tab of new PMS | Abondon Changes pop up should not be displayed and PMS should get closed.
        userExperienceTestSetScript.clickExitPMS();
        userExperienceTestSetScript.validateAbandonPopup();

        //To continue to next test case flow
        userExperienceTestSetScript.closeDropOffScreen(inputData);

        System.out.println("<<<HWPHME2E_596_tc_18_Remove_Cancel_Popup_Drop_Off>>>");
    }
}