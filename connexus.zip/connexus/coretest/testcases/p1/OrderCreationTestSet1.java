package connexus.coretest.testcases.p1;

import connexus.coretest.testscripts.OrderCreationTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class OrderCreationTestSet1 {

    OrderCreationTestSetScript orderCreationTestSetScript = new OrderCreationTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean flagUpdated = false;


    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify if user is able to scan a new Rx of Origin type - Phone_Emergency Rx
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created
    *
    * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-355")
    @Test(enabled = true, description = "To verify if user is able to scan a new Rx of Origin type - Phone_Emergency Rx",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP1DataBook.json", sheetName = "OrderCreationP1")
    public void HWPHME2E_355_Tc_3_NN_ScanRx_RxOriginType_Phone(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_355_Tc_3_NN_ScanRx_RxOriginType_Phone<<<");

        connexusAppUtils.getStoreId();

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created
        orderCreationTestSetScript.initializeTestCase(false);
        orderCreationTestSetScript.createNewPatient(inputData);

        //1.Click on Drop Off icon in the left pane | Drop off screen is displayed
        orderCreationTestSetScript.clickAndValidateDropOffScreen();

        //2.Type in an existing patient name or DOB  in the DOB/RX number/name textbox and hit tab | Patient details are populated in the patient information section
        orderCreationTestSetScript.inputPatientNameInDropOff();
        orderCreationTestSetScript.validatePatientDetailsInDropOff();

        //3.Click on Scan New Rx button | Bar code Reader error window is displayed
        orderCreationTestSetScript.validateScanRxWindow();

        //4.Type in a 4 digit bar code number in the bar code reader error window and click Accept | Verify barcode dialog is displayed with a message "You entered <barcode number>.Is this correct?" and Yes and No buttons
        orderCreationTestSetScript.enterBarCodeAndValidateText(inputData);

        //5.Click Yes | Barcode dialog is closed and Rx Origin Type window is displayed with Rx origin Type options 1.Original Rx 2.Phone3.Fax Checkboxes - Tamper Resistant and Emergency RX and an Accept button
        orderCreationTestSetScript.clickYesInVerifyBarCodePopUp();
        orderCreationTestSetScript.validateRxOriginTypeWindow();

        //6.Select Rx origin type as Phone, check emergency Rx checkbox  and click Accept | Rx Origin Window should be closed
        orderCreationTestSetScript.selectRxTypeAsPhoneAndCheckEmergencyRx();
        orderCreationTestSetScript.clickAcceptInRxOriginType();

        //7.Verify if the Patient name, Bar code number and number of Rx's are populated in the Order Information section | Patient name, Bar code number and number of Rx's are populated in the Order Information section
        orderCreationTestSetScript.validateOrderInformationScreen();

        //8.Select a Priority, Ready by time and click Accept | Drop off screen should be closed
        orderCreationTestSetScript.selectPriorityTimeAndClickAccept();

        //9.Hit F6 and search for the same patient name used in step 2 | Search results are displayed
        //10.Newly created Rx should be in Input work queue and should be displayed in the search results window | Newly created Rx is displayed in the search results window
        orderCreationTestSetScript.searchPatientAfterDropOff();
        System.out.println("<<<HWPHME2E_355_Tc_3_NN_ScanRx_RxOriginType_Phone>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Technician is not able to complete few workqueues (4Pt,VV,Counseling)
     * Pre-Conditions:
     * 1.Pharmacist and Technician user ID should be available
     *
     * Author: Lakshmi Priya (vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-336")

    @Test(enabled = true, description = "verify whether the Technician is not able to complete few workqueues (4Pt,VV,Counseling)",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP1DataBook.json", sheetName = "OrderCreationP1")
    public void HWPHME2E_336_Tc_4_Regression_Tech_and_Phar_Workqueue(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_336_Tc_4_Regression_Tech_and_Phar_Workqueue<<<");
        connexusAppUtils.getStoreId();

        //Pre Conditions
        //1. Pharmacist and Technician user ID should be available
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
//        orderCreationTestSetScript.initializeTestCase(flagUpdated);
        orderCreationTestSetScript.initializeTestCase(false);
        orderCreationTestSetScript.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        //1. Login as Technician | Technician should be logged in
        //2. Verify whether the Technician is not able to complete few workqueues | Technician cannot complete following workqueues:-4 Point-Visual Verify-Counseling
        orderCreationTestSetScript.validateFourPointForTechnician();
        orderCreationTestSetScript.validateVisualVerifyForTechnician();
        orderCreationTestSetScript.validateCounsellingForTechnician();
        System.out.println("<<<HWPHME2E_336_Tc_4_Regression_Tech_and_Phar_Workqueue>>>");
    }


    //DUPLICATE TESTCASE, COVERED AS PART OF E2E
     /*
    *----------------------------------------------------------------------------------------------------------
     * Test Description: Drop a refill for rx with zero number fo refills for cash/tp
     * Pre-Conditions:
     * 1. User should be able to login to Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*//*
    //@Jira(testID = "HWPHME2E-336")
    @Test(enabled = true, description = "Drop a refill for rx with zero number fo refills for cash/tp",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderCreationP1DataBook.json", sheetName = "OrderCreationP1")
    public void HWPHME2E_336_Tc_05_Drop_A_Refill_For_RX_With_Zero_Number_Refills(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_336_Tc_05_Drop_A_Refill_For_RX_With_Zero_Number_Refills<<<");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        //Restart Connexus if any of the above flags required update
        if (connexusAppUtils.readAndUpdateFlag("28750", "TRUE") ||
                connexusAppUtils.readAndUpdateFlag("26849", "TRUE") ||
                connexusAppUtils.readAndUpdateFlag("15166", "TRUE") ||
                connexusAppUtils.readAndUpdateFlag("24550", "FALSE") ||
                connexusAppUtils.readAndUpdateFlag("8670", "FALSE") ||
                connexusAppUtils.readAndUpdateFlag("26218", "FALSE")) {
            tearDown();
            orderCreationTestSetScript = new OrderCreationTestSetScript();
            orderCreationTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        // Create a new patient
        orderCreationTestSetScript.createNewPatientWithPrimaryPhoneNumber(inputData);

        //Drop an Order and move till EOD and get the RX Number with Zero refills left
        String rxNbr = orderCreationTestSetScript.dropRXAndMoveToEOD_GetRxNbr(inputData);

        //DropOff another RX for the above order and handle Refill Request popups
        orderCreationTestSetScript.performDropOffForARXWithNoRefills(rxNbr);

        //Verify that RX ends up in Resolution queue.
        orderCreationTestSetScript.verifyIfRxIsInResolutionQueue(rxNbr);

        System.out.println("<<<tc_05_Drop_A_Refill_For_RX_With_Zero_Number_Refills>>>");
    }*/
}
