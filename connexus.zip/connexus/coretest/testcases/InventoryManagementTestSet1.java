package connexus.coretest.testcases;

import connexus.coretest.testscripts.InventoryManagementTestSetScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class InventoryManagementTestSet1 {

    InventoryManagementTestSetScripts inventoryManagementTestSetScripts= new InventoryManagementTestSetScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void performlogin() {
        inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify Pharmacist is able to see the pop-up message for non-D38 items as
     * "Is item in an unopened stock container?" if fill quantity is evenly divisible
     * by pack size(Rx-Filling-Current rx-cancel fill-change fill)
     *
     * TFS ID: 79252
     *
     * PreCondition:None
     *
     * Author: Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify Pharmacist is able to see the pop-up message for non-D38 items as\"Is item in an" +
            " unopened stock container?\"if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel" +
            " fill-change fill)", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName ="inventoryManagementDataSheet")
    public void tc_01_unopened_stock_container_popup_MTR_RTS(Map<String, String> inputData) {
        System.out.println(">>>TC_unopened_stock_container_popup_MTR-RTS<<<");

        //1.Login to connexus and connect to proper box |Pharmacist is able to login connexus successfully
        //2.Collect non-D38 NDC and pack quantity |Pharmacist is able to  collect the non-D38 ndc along with pack quantity successfully
        //3.Drop an non-D38 rx with same pack quantity and take till filling |Pharmacist is able to take filling successfully
        //4.Hit F6 button and search for the created Rx |Pharmacist is able to see the work queue filling as pending
        //5.Double click on the the Rx |Pharmacist is able to see the modify details screen
        //6.Mouse over current Rx-cancel fill-Return To Stock |Pharmacist is able to to see the pop-up message displays "Is item in an unopened stock container?" with Yes or no options
        inventoryManagementTestSetScripts.dropAnRxTillVisualVerify(inputData);
        inventoryManagementTestSetScripts.returnToStockYes();

        System.out.println(">>>TC_unopened_stock_container_popup_MTR-RTS<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:validate after selecting No option from message"Is item in an unopened stock
     * container?" working as current behavior(Rx-VV-Current rx-cancel fill-change fill
     *
     * TFS ID: 79255
     *
     * Pre-Conditions: 1. 25511 flag should be TRUE
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify Pharmacist is able to see the pop-up message for non-D38 items as\"Is item in an" +
            " unopened stock container?\"if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel" + " fill-change fill)", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_02_unopened_stock_container_popup_flag_true_MTR_RTS(Map<String, String> inputData) {
        System.out.println(">>>TC_unopened_stock_container_popup_flag_true_MTR-RTS<<<");

        //Pre-condition
        //1.25511 flag should be TRUE
        /* 25511 is RTS restriction flag */
        if(connexusAppUtils.readAndUpdateFlag("25511", "TRUE")){
            tearDown();
            inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //1.Login to connexus and connect to proper box |Pharmacist is able to login connexus successfully
        //2.Collect non-D38 NDC and pack quantity |Pharmacist is able to  collect the non-D38 ndc along with pack quantity successfully
        //3.Drop an non-D38 rx with same pack quantity and take till vv |Pharmacist is able to take vv successfully
        //4.Hit F6 button and search for the created Rx |Pharmacist is able to see the work queue vv as pending
        //5.Double click on the the Rx |Pharmacist is able to see the modify details screen
        //6.Mouse over current Rx-cancel fill-Return To Stock |Pharmacist is able to to see the pop-up message displays "Is item in an unopened stock container?" with Yes or
        inventoryManagementTestSetScripts.dropAnRxTillVisualVerify(inputData);

        //7.Click on No option |Pharmacist is able to see the already existing behavior
        inventoryManagementTestSetScripts.returnToStockNoOpenStock();

        System.out.println(">>>TC_unopened_stock_container_popup_flag_true_MTR-RTS<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify Pharmacist is able to see the pop-up message for non-D38 items "Is item in an unopened stock container?"
        if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel fill-Therapy Discontinued)
     *
     * TFS ID: 79258
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify Pharmacist is able to see the pop-up message for non-D38 items \"Is item in an " +
            "unopened stock container?if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel fill" +
            "-Therapy Discontinued)", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_03_unopened_stock_container_popup_NonD38_MTR_RTS(Map<String, String> inputData) {
        System.out.println(">>>TC_unopened_stock_container_popup_NonD38_MTR-RTS<<<");

        //1.Login to connexus and connect to proper box |Pharmacist is able to login connexus successfully
        //2.Collect non-D38 NDC and pack quantity |Pharmacist is able to  collect the non-D38 ndc along with pack quantity successfully
        //3.Drop an non-D38 rx with same pack quantity and take till Bagging |Pharmacist is able to take Bagging successfully
        //4.Hit F6 button and search for the created Rx |Pharmacist is able to see the work queue Bagging as pending
        //5.Double click on the the Rx |Pharmacist is able to see the modify details screen
        inventoryManagementTestSetScripts.dropAnRxTillBagging(inputData);

        //6.Mouse over current Rx-cancel fill-Therapy discontinued | Pharmacist is able to to see the pop-up message displays "Is item in an unopened stock container?" with Yes or no options
        inventoryManagementTestSetScripts.therapyDiscontinuedOpenStock();

        System.out.println(">>>TC_unopened_stock_container_popup_NonD38_MTR-RTS<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify Pharmacist is able to see the pop-up message for non-D38 items "Is item in an unopened stock container?"
        if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel fill-Therapy Discontinued)
     *
     * TFS ID: 79259
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify Pharmacist is able to see the pop-up message for non-D38 items \"Is item in an " +
            "unopened stock conntainer?if fill quantity is evenly divisible by pack size(Rx-Filling-Current rx-cancel fill" +
            "-Therapy Discontinued)", priority = 4)
    public void tc_04_Item_will_MTRd_back_original_department_popup_MTR_RTS() {
        System.out.println(">>>TC_Item_will_MTR'd_back_original_department_popup_MTR-RTS<<<");

        //1.Login to connexus and connect to proper box |Pharmacist is able to login connexus successfully
        //2.Collect non-D38 NDC and pack quantity |Pharmacist is able to  collect the non-D38 ndc along with pack quantity successfully
        //3.Drop an non-D38 rx with same pack quantity and take till Bagging |Pharmacist is able to take Bagging successfully
        //4.Hit F6 button and search for the created Rx |Pharmacist is able to see the work queue Bagging as pending
        //5.Double click on the the Rx |Pharmacist is able to see the modify details screen
        //6.Mouse over current Rx-cancel fill-Therapy discontinued | Pharmacist is able to to see the pop-up message displays "Is item in an unopened stock container?" with Yes or no options
        //7.Click on Yes option |Pharmacist is able to see the pop-up message "Item will be MTR'd back to original department"
        inventoryManagementTestSetScripts.clickOkOnTherapyDiscontinued();

        System.out.println(">>>TC_Item_will_MTR'd_back_original_department_popup_MTR-RTS<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that the 3rd Adjustment reason code text is display as "Disp Qty Discrepancy" in
     * IMS Screen for the C2 drug
     *
     * TFS ID:444613
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify verify that the 3rd Adjustment reason code text is display as \"Disp Qty Discrepancy\" in IMS Screen for the C2 drug\n ",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_05_Reason_Code_Display_Text_IMS_Screen_02(Map<String, String> inputData) {
        System.out.println(">>>TC_Reason Code Display Text_IMS Screen_02<<<");

        //1.Login to connexus application |The user should be able to login successfully
        //2.Hit on Ctrl+Shift+D and search for the C2 and double click on the product| The product maintenance screen should be displayed
        //3.Double click on the product in the product maintenance screen |The Item maintenance screen should be displayed
        inventoryManagementTestSetScripts.productSearchWithDrugName(inputData);

        //4.Enter the on hand qty and click on accept check if the pop up is displayed |The adjustment reason pop-up should  be displayed in IMS Screen
        inventoryManagementTestSetScripts.changeOnHandDrugQtyOnIMS();

        //5.Verify the text of the 3rd reason in the adjustment reason screen |The reason should have the below text
        //Disp Qty Discrepancy
        //6.Select the 3rd adjustment reason code and click on Accept|The adjustment reason popup screen should be closed
        inventoryManagementTestSetScripts.selecting3rdAdjustmentCodeInIMS();

        //7.a.Login to Db and run the below query to check if the status code have been updated |
        //  b.select * from pharmacy_offering:phm_item_inv_adjmt_log where mds_fam_id='266951' order by adjmt_status_ts desc
        inventoryManagementTestSetScripts.validateReasonCodeInDb();

        System.out.println(">>>TC_Reason Code Display Text_IMS Screen_02<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify that the 3rd Adjustment reason code text is display as "Disp Qty Discrepancy" in Cycle count report
    *
    * TFS ID: 44461
    *
    * Pre-Condition
    *  1. Rx with High  risk drug should be in EOD
    *  2. Red records should be present in Cycle count report
    *
    * Author:Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify that the 3rd Adjustment reason code text is display as \"Disp Qty Discrepancy\" in " +
            "Cycle count report", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_06_Reason_Code_Display_Text_Cycle_Count_Report_01(Map<String, String> inputData) {
        System.out.println(">>>TC_Reason Code Display Text_Cycle Count Report_01<<<");

        //Pre-Condition
        //1. Rx with High  risk drug should be in EOD
        //2. Red records should be present in Cycle count report
        Reporter.log("Precondition of high risk drug in EOD  is acheived by the previous test case @tc_05_Reason_Code_Display_Text_IMS_Screen_02");

        //1.Login to connexus application |The user should be able to login successfully
        //2.Chcek if the Cycle count report is displayed with red records on the connexus screen as soon as the user logs in |The Cycle count report should be displayed with red records
        inventoryManagementTestSetScripts.openCycleCountReport();

        //3.Select any control drug ( Red record) and enter the quantity |The user should be able to enter the on hand quantity
        //4.Hit on enter and verify whether Double Check Count popup is displayed|Double Check Count popup should be  displayed
        //5.Click on "Yes" and check whether Adjustment Reason popup is displayed with reason |The adjustment reason popup should be displayed
        //6.a.Verify the text of the 3rd reason in the adjustment reason screen |The reason should have the below text
        //  b.Disp Qty Discrepancy
        //7.Select the 3rd adjustment reason code and click on Accept |The adjustment reason popup screen should be closed
        inventoryManagementTestSetScripts.select3rdAdjustmentCodeInCycleCount(inputData);

        //8.a.Login to Db and run the below query to check if the status code have been updated   |The record should be updated with the adjmt_rsn_code as 3
        //  b.select * from pharmacy_offering:phm_item_inv_adjmt_log where mds_fam_id='266951' order by adjmt_status_ts desc
        inventoryManagementTestSetScripts.validateReasonCodeInDb();

        System.out.println(">>>TC_Reason Code Display Text_Cycle Count Report_01<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Verify user is able to view "Cycle count completed for this month" pop-up message
    * if no CII available for current month
    *
    * TFS ID: 239355
    *
    * PreCondition: None
    *
    * Author:Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify user is able to view \"Cycle count completed for this month\" pop-up message if no CII " +
            "available for current month", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_07_Cycle_count_error_msg_completed_for_this_month_popup(Map<String, String> inputData) {
        System.out.println(">>>TC_Cycle-count_error_msg_completed_for_this_month_popup<<<");

        //1.Login to connexus and connect to proper box |User should be able to connect to proper box
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
        inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //2.Move to Reports-Inventory report-Cycle count report | User should be able to open cycle count report
        inventoryManagementTestSetScripts.openCycleCountReport();

        //3.Select "full month" radio button and click on "Get more CII"|User should be able to view CII records for entire month if available
        //4.Select "full month" radio button and click on "Get more CII"|User should be able to view "CII cycle count completed for this month" message
        inventoryManagementTestSetScripts.cycleCountFullMonth(inputData);

        System.out.println(">>>TC_Cycle-count_error_msg_completed_for_this_month_popup<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user is getting adjustment reason pop up when updating the on-hand
     * quantity of Non-CII drug. And verify the adjustment reasons displaying in pop up.
     *
     * TFS ID:250893
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether user is getting adjustment reason pop up when updating the on-hand quantity" +
            " of Non-CII drug. And verify the adjustment reasons displaying in pop up.", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_08_Adjustment_reasoncode_for_Non_CII_drugs(Map<String, String> inputData) {
        System.out.println(">>>TC_Adjustment_reasoncode_for_Non-CII_drugs<<<");

        //1. Update/Set 27107 Flag value as OFF |User should be able to update 27107 Flag value as "OFF"
        /*27107 is the flag for C2Log book feature*/
        if(connexusAppUtils.readAndUpdateFlag("27107", "2019-01-01")){
            tearDown();
            inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //2.Open Utility and verify the 27107 flag for the respective box.|27107 flag should be turned
        //3.Login to connexus and connect to proper box |user should be able to connect proper box
        //4.Go to Product search screen, enter NON-CII drug name and search for the drug. |Drug detail should be displayed
        inventoryManagementTestSetScripts.productSearchWithDrugName(inputData);

        //5.click on drug and change the onhand quantity for the drug |User should be able to change the onhand quantity of the drug.
        //6.a.Verify whether adjustment reason pop up is displaying| Adjustment reason  pop-up should display
        //  b.Applied in Error
        //  c.Hazardous Waste
        //  d.Disp Qty Discrepancy
        //  e.Mfr Shortage/Overage
        //  f.Return Genco/McKes
        //  g.Unknown
        inventoryManagementTestSetScripts.verifyAdjustmentCodeInIMS(inputData);

        System.out.println(">>>TC_Adjustment_reasoncode_for_Non-CII_drugs<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify whether Pre-Receiving pop up is not displaying when
    *  updating the onhand qty of Non-CII Drug.
    *
    * TFS ID: 250894
    *
    * PreCondition:None
    *
    * Author:Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether Pre-Receiving pop up is not displaying when updating the onhand qty of " +
            "Non-CII Drug.", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_09_Pre_Receiving_popup_for_Non_CII_drugs(Map<String, String> inputData) {
        System.out.println(">>>TC_Pre-Receiving_popup_for_Non-CII_drugs<<<");

        //1. Update/Set 27107 Flag value as OFF |User should be able to update 27107 Flag value as "OFF"
        //2.Open Utility and verify the 27107 flag for the respective box.|27107 flag should be turned
        //3.Login to connexus and connect to proper box |user should be able to connect proper box
        //4.Go to Product search screen, enter NON-CII drug name and search for the drug. |Drug detail should be displayed
        //5.click on drug and change the onhand quantity for the drug |User should be able to change the onhand quantity of the drug.
        Reporter.log("Continuing from previous TC @ tc_08_Adjustment_reasoncode_for_Non_CII_drugs and updating OnHand Quantity");

        //6.a.Verify whether adjustment reason pop up is displaying| Adjustment reason  pop-up should displayed
        //  b.Applied in Error
        //  c.Hazardous Waste
        //  d.Disp Qty Discrepancy
        //  e.Mfr Shortage/Overage
        //  f.Return Genco/McKes
        //  g.Unknown
        //7.Verify Pre-Receive  the pop-up is not displaying for the non-ciis |Pre-Receive  the pop-up is not displaying for the non-ciis
        inventoryManagementTestSetScripts.checkingForPreReceivingPopup(inputData);

        System.out.println(">>>TC_Pre-Receiving_popup_for_Non-CII_drugs<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify whether Pharmacist is getting adjustment reason pop up when updating the on-hand qty of
    *  Non-CII Drug in Partial fill Visual verify mismatch.
    *
    * TFS ID: 250899
    *
    * PreCondition: None
    *
    * Author:Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether Pharmacist is getting adjustment reason pop up when updating the on-hand qty " +
            "of Non-CII Drug in Partial fill Visual verify mismatch.", priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_10_Adjustment_reasoncode_Partial_fill_Visual_verify_screen(Map<String, String> inputData) {
        System.out.println(">>>TC_Adjustment_reasoncode_Partial_fill_Visual_verify_screen<<<");

        //1. Update/Set 27107 Flag value as OFF |User should be able to update 27107 Flag value as "OFF"
        /*27107 is the flag for C2 Logbook feature*/
        if(connexusAppUtils.readAndUpdateFlag("27107", "2019-01-01")){
            tearDown();
            connexusAppUtils = new ConnexusAppUtils();
            inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //2.Open Utility and verify the 27107 flag for the respective box.|27107 flag should be turned
        //3.Login to connexus and connect to proper box |user should be able to connect proper box
        //4.Drop and rx with Non-CII drug and process the rx till VV |Rx should be in VV work queue.
        inventoryManagementTestSetScripts.dropAnRxTillVisualVerifyForPartialFill(inputData);

        //5.At Visual verify screen select Current RX>Cancel Fill> Partial Fill |Partial Fill pop up should be displayed for entering initial partial fill value and changed onhand quantity
        //6.Enter a partial fill quantity. Enter a quantity less than Disp Qty in the on-hand quantity. Hit Accept. |User should be able to click on accept button.
        //7.a.Verify whether user is getting adjustment reason pop up for changing on-hand quantity.  Applied in Error |user should get adjustment reason pop up for selecting reason.
        //  b.Hazardous Waste
        //  c.Disp Qty Discrepancy
        //  d.Mfr Shortage/Overage
        //  e.Return Genco/McKes
        //  f.Unknown
        inventoryManagementTestSetScripts.adjustmentReasonInPartialFilling(inputData);

        System.out.println(">>>TC_Adjustment_reasoncode_Partial_fill_Visual_verify_screen<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Pharmacist is getting adjustment reason pop up while updating
     * the on-hand qty of the Non-CII Drug in cycle count report.
     *
     * TFS ID: 250898
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether Pharmacist is getting adjustment reason pop up while updating the on-hand " +
            "qty of the Non-CII Drug in cycle count report.", priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_11_Adjustment_reasoncode_Cyclecount_report(Map<String, String> inputData) {
        System.out.println(">>>TC_Adjustment_reasoncode_Cyclecount_report<<<");

        //1. Update/Set 27107 Flag value as OFF |User should be able to update 27107 Flag value as "OFF"
        if(connexusAppUtils.readAndUpdateFlag("27107", "2019-01-01")){
            tearDown();
            connexusAppUtils = new ConnexusAppUtils();
            inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //2.Open Utility and verify the 27107 flag for the respective box.|27107 flag should be turned
        //3.Login to connexus and connect to proper box |user should be able to connect proper box
        //4.Move to Reports-Inventory Report-Cycle count report |User should be able to move to Cycle count report successfully
        inventoryManagementTestSetScripts.openCycleCountReport();

        //5.a.click on any NDC(Non-CII) and enter the onhand quantity for the NDC |Pharmacist should be able to view adjustment reason pop up displaying
        //  b.Applied in Error
        //  c.Hazardous Waste
        //  d.Disp Qty Discrepancy
        //  e.Mfr Shortage/Overage
        //  f.Return Genco/McKes
        //  g.Unknown
        inventoryManagementTestSetScripts.verifyAdjustmentCodeInCycleCount(inputData);

        System.out.println(">>>TC_Adjustment_reasoncode_Cyclecount_report<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Technician is not getting adjustment reason pop up while updating the
     * on-hand qty of Non-CII Drug in cycle count report.
     *
     * TFS ID: 250903
     *
     * PreCondition:None
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether Technician is not getting adjustment reason pop up while updating the " +
            "on-hand qty of Non-CII Drug in cycle count report.", priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_12_Adjustment_reasoncode_Technician(Map<String, String> inputData) {
        System.out.println(">>>TC_Adjustment_reasoncode_Technician<<<");

        //1.Login to connexus and connect to proper box |user should be able to connect proper box
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        inventoryManagementTestSetScripts=new InventoryManagementTestSetScripts();
        inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);

        //2.Move to Reports-Inventory Report-Cycle count report |User should be able to move to Cycle count report successfully
        inventoryManagementTestSetScripts.openCycleCountReport();

        //3.a.click on any NDC(Non-CII) and enter the onhand quantity for the NDC |Technician should not able to view able to view below adjustment reason pop up displaying
        //  b.Applied in Error
        //  c.Hazardous Waste
        //  d.Disp Qty Discrepancy
        //  e.Mfr Shortage/Overage
        //  f.Return Genco/McKes
        //  g.Unknown
        inventoryManagementTestSetScripts.verifyAdjustmentCodeForTechnician(inputData);

        System.out.println(">>>TC_Adjustment_reasoncode_Technician<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify whether the Technician is not abled to view C2 drug cycle count report
     *
     * TFS ID:168954
     *
     * Per Condition:
     * 1.Technician should be logged into Connexus
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Verify whether the Technician is not abled to view C2 drug cycle count report", priority = 13)
    public void tc_13_Regression_Tech_and_Phar_Cycle_count_report_007() {
        System.out.println(">>>TC_Regression_Tech and Phar_Cycle count report_007<<<");

        //Per Condition:
        //1.Technician should be logged into Connexus |Pre Condition should be setup in store
        //2.Go to Reports-Inventory Report-Cycle count report | Cycle count re\port should be displayed
        //3.Verify whether the Technician is not abled to view C2 drug cycle count report |Technician cant able to view C2 drug Cycle count report
        inventoryManagementTestSetScripts.verifyC2DrugInvisibleForTechnician();

        System.out.println(">>>TC_Regression_Tech and Phar_Cycle count report_007<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Technician is not able to change the Onhand quantity for C2 drug
     *
     * TFS ID: 168955
     *
     * PreCondition: Technician Should be logged into Connexus
     *
     * Author:Sugapriya S(vn510of)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Technician is not able to change the Onhand quantity for C2 drug ",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_14_Regression_Tech_and_Phar_Onhand_C2_008(Map<String, String> inputData) {
        System.out.println(">>>TC_Regression_Tech and Phar_Onhand C2_008<<<");

        //Per Condition:
        //1.Technician should be logged into Connexus |Pre Condition should be setup in store
        //2.Hit Ctrl+Shift+D|Product search screen will display
        //3.Search for C2 drug and open Item maintenance screen |Product maintenance screen should display
        //4.Double click on the NDC number |Item maintenance screen of C2 drug should display
        inventoryManagementTestSetScripts.productSearchWithDrugName(inputData);

        //5.Verify the Onhand quantity field |Onhand quantity field should be disabled
        inventoryManagementTestSetScripts.verifyQuantityDisabledForTechnician();

        System.out.println(">>>TC_Regression_Tech and Phar_Onhand C2_008<<<");
    }
}
