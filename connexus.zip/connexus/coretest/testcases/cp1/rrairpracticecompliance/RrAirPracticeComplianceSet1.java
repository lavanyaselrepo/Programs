package connexus.coretest.testcases.cp1.rrairpracticecompliance;

import connexus.coretest.testscripts.RrAirPracticeComplianceTestSetScript;
import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class RrAirPracticeComplianceSet1 {

    UserExperienceTestSetScript userExperienceTestSetScript;
    RrAirPracticeComplianceTestSetScript rrAirPracticeComplianceTestSetScript = new RrAirPracticeComplianceTestSetScript(LoginAs.userType.PHARMACIST_ADFlagOff);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    public String siteID = prop.getProperty("connexustestharness.storeID");
    boolean flagUpdated = false;



    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
        connexusAppUtils = new ConnexusAppUtils();
        userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Check box text is displayed as “Last Name is Complete” and enabled at
     * pickup screen when user enters a single digit in lastname.
     *
     * Pre-Conditions:
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true,description = "To verify whether Check box text is displayed as " +
            "“Last Name is Complete” and enabled at pickup" +
            " screen when user enters a single digit in lastname.",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_228_tc_1_352175_RR_3_20_0_Pickup_Changes_Rx_last_name(Map<String, String> inputData) {

        //1.Login to connexus with valid credentials. | User should be able to login to the store.
        //2.Hit F11. | TASCO screen should be displayed.
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.openTascoScreen(inputData);

        //3.Verify the text message and checkbox. | “Required: Last Name and First Name with DOB or Phone Number”
        rrAirPracticeComplianceTestSetScript.validateText(inputData);

        //4.Enter a single digit in last name column. | Check box(Last Name is Complete) should be enabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxEnabledLastName(inputData);

        //5.Enter more than one character in last name field. | Check box text should be disabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxDisabledLastName(inputData);

    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Check box text is displayed as “Last Name is Complete” and enabled at pickup
     *  screen when user enters a single digit in first name.
     *
     * Pre-Conditions:
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true,description = "To verify whether Check box text is displayed as “Last Name is Complete” and enabled at pickup " +
            "screen when user enters a single digit in first name.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"HWPHME2E_228_tc_1_352175_RR_3_20_0_Pickup_Changes_Rx_last_name"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_229_tc_2_352176_RR_3_20_0_Pickup_Changes_Rx_first_name(Map<String, String> inputData) {
        System.out.println(">>>tc_2_352176_RR_3_20_0_Pickup_Changes_Rx_first_name<<<");

        //1.Login to connexus with valid credentials. | User should be able to login to the store.
        //2.Hit F11. | TASCO screen should be displayed.
        //3.Verify the text messeage and checkbox. | “Required: Last Name and First Name with DOB or Phone Number”
        //4.Enter a single digit in first name column. | Check box(first Name is Complete) should be enabled.
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.validateCheckBoxEnabledFirstName(inputData);

        //5.Enter more than one character in first name field. | Check box text should be disabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxDisabledFirstName(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Check box text is displayed as “Last Name is Complete” and enabled at
     * PSE screen when user enters a single digit in lastname.
     *
     * Pre-Conditions:
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true,description = "To verify whether Check box text is displayed as “Last Name is Complete” and enabled at " +
            "PSE screen when user enters a single digit in lastname.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"HWPHME2E_229_tc_2_352176_RR_3_20_0_Pickup_Changes_Rx_first_name"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_230_tc_3_352183_RR_3_20_0_Pickup_Changes_PSE_last_name(Map<String, String> inputData) {
        System.out.println(">>>tc_3_352183_RR_3_20_0_Pickup_Changes_PSE_last_name<<<");

        //1.Login to connexus with valid credentials. | User should be able to login to the store.
        //2.Hit F11 and click on PSE icon. | PSE screen should be displayed.
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.openPseudoephedrine(inputData);

        //3.Verify the text messeage and checkbox. | “Required: Last Name and First Name with DOB or Phone Number”
        rrAirPracticeComplianceTestSetScript.validateText(inputData);

        //4.Enter a single digit in last name column. | Check box(Last Name is Complete) should be enabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxEnabledLastName(inputData);

        //5.Enter more than one character in last name field. | Check box should be disabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxDisabledLastName(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Check box text is displayed as “Last Name is Complete” and enabled at PSE
     * screen when user enters a single digit in first name.
     *
     * Pre-Conditions:
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true,description = "To verify whether Check box text is displayed as “Last Name is Complete” and enabled at PSE " +
            "screen when user enters a single digit in first name.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"HWPHME2E_230_tc_3_352183_RR_3_20_0_Pickup_Changes_PSE_last_name"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_232_tc_4_352184_RR_3_20_0_Pickup_Changes_PSE_first_name(Map<String, String> inputData) {

        //1.Login to connexus with valid credentials. | User should be able to login to the store.
        //2.Hit F11 and click on PSE icon. | PSE screen should be displayed.
        //3.Verify the text messeage and checkbox. | “Required: Last Name and First Name with DOB or Phone Number”
        //4.Enter a single digit in first name column. | Check box(First Name is Complete) should be enabled.
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.validateCheckBoxEnabledFirstName(inputData);

        //5.Enter more than one character in first name field. | Check box should be disabled.
        rrAirPracticeComplianceTestSetScript.validateCheckBoxDisabledFirstName(inputData);

        //To continue to next test cases
        rrAirPracticeComplianceTestSetScript.clickExitHIPAA(inputData);
        rrAirPracticeComplianceTestSetScript.clickExitInTasco(inputData);


    }


    /*----------------------------------------------------------------------------------------------------------
      * Test Description:To verify whether Diagnosis code field is displayed in 4point for a C2 prescription in the state of ME.
      * Pre-Conditions:
      * 1. Store state should be ME.
      * Author: Tarun(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that Diagnosis code field is displayed in " +
            "4point for C2 prescription in the state of ME.",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_246_tc_8_369095_RR_3_21_ME_Diagnosis_code_C2(Map<String, String> inputData) {

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreenForControlledDrug();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Diagnosis code field is displayed in 4point for a C3 prescription in the state of ME.
     * Pre-Conditions:
     * 1. Store state should be ME.
     * Author: Tarun(vn510o1)
 ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that Diagnosis code field is displayed in " +
            "4point for a C3 prescription in the state of ME.",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_249_tc_9_369096_RR_3_21_ME_Diagnosis_code_C3(Map<String, String> inputData) {
        System.out.println(">>>tc_9_369096_RR_3_21_ME_Diagnosis_code_C3<<<");

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Diagnosis code field is displayed in 4point for a C4 prescription in the state of ME.
     * Pre-Conditions:
     * 1. Store state should be ME.
     * Author: Tarun(vn510o1)
 ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that Diagnosis code field is displayed " +
            "in 4point for a C4 prescription in the state of ME.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_234_tc_10_369097_RR_3_21_ME_Diagnosis_code_C4(Map<String, String> inputData) {

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:To verify whether Diagnosis code field is displayed in 4point for a C5 prescription in the state of ME.
      * Pre-Conditions:
      * 1. Store state should be ME.
      * Author: Tarun(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that Diagnosis code field is displayed " +
            "in 4point for a C5 prescription in the state of ME.",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_236_tc_11_369098_RR_3_21_ME_Diagnosis_code_C5(Map<String, String> inputData) {

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify that Diagnosis code field is not displayed in 4point for a non ctrl prescription in the state of ME.
    * Pre-Conditions:
    * 1. Store state should be TN.
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that Diagnosis code field is not displayed" +
            " in 4point for a non ctrl prescription in the state of ME.",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_237_tc_12_369099_RR_3_21_ME_Diagnosis_code_non_ctrl(Map<String, String> inputData) {
        System.out.println(">>>tc_12_369099_RR_3_21_ME_Diagnosis_code_non_ctrl<<<");

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify whether Diagnosis code field is displayed in input for a C2 prescription in the state of TN.
    * Pre-Conditions:
    * 1. Store state should be TN.
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "To verify whether Diagnosis code field is displayed in input " +
            "for a C2 prescription in the state of TN.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_238_tc_13_376360_RR_3_21_TN_Diagnosis_code_C2(Map<String, String> inputData) {

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreenForControlledDrug();
    }

    /*----------------------------------------------------------------------------------------------------------
         * Test Description:To verify whether Diagnosis code field is displayed in input for a C3 prescription in the state of TN.
         *
         * Pre-Conditions:
         * 1. Store state should be TN.
         *
         * Author: Tarun(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify whether Diagnosis code field is displayed in input " +
            "for a C3 prescription in the state of TN.",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_239_tc_14_376361_RR_3_21_TN_Diagnosis_code_C3(Map<String, String> inputData) {

        if(flagUpdated){
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:To verify whether Diagnosis code field is displayed in input for a C4 prescription in the state of TN.
       *
       * Pre-Conditions:
       * 1. Store state should be TN.
       *
       * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify whether Diagnosis code field is displayed in" +
            " input for a C4 prescription in the state of TN.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_242_tc_15_376362_RR_3_21_TN_Diagnosis_code_C4(Map<String, String> inputData) {

        if(flagUpdated) {
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();

    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:To verify whether Diagnosis code field is displayed in input for a C4 prescription in the state of TN.
       *
       * Pre-Conditions:
       * 1. Store state should be TN.
       *
       * Author: Tarun(vn510o1)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify whether Diagnosis code field is displayed in " +
            "input for a C5 prescription in the state of TN.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_243_tc_16_376363_RR_3_21_TN_Diagnosis_code_C5(Map<String, String> inputData) {

        if(flagUpdated) {
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:To verify that Diagnosis code field is not displayed in input for a non ctrl prescription in the state of TN.
      *
      * Pre-Conditions:
      * 1. Store state should be TN.
      *
      * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "To verify that Diagnosis code field is displayed in input for a non ctrl prescription in the state of TN",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_226_tc_17_376364_RR_3_21_TN_Diagnosis_code_non_ctrl(Map<String, String> inputData) {

        if(flagUpdated) {
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            rrAirPracticeComplianceTestSetScript.updateStoreState(inputData.get("STATE_UPDATE"));
            String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
            rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencyCode);
        }
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInputandValidateDXCode(inputData);
        rrAirPracticeComplianceTestSetScript.validateDxCodeFieldInFourPointScreen();
        Reporter.log("Diagnosis code field is displayed in input for a non ctrl prescription in the state of TN.");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that patient age is getting updated on the input screen when Patient DOB is changed from input through patient maintenance screen.
     *
     * Pre-Conditions:
     *  1. Pharmacist should be logged into the Connexus.
     *  2. Patient Profile should be present in the store.
     *  3. Drop an rx for the patient and process the rx till input work queue.
     *
     * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "To verify that patient age is getting updated on the " +
            "input screen when Patient DOB is changed from input through patient maintenance screen.",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_217_tc_24_416661_Defect_6945(Map<String, String> inputData) {
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated,true);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.modifyAgeFromInputScreen(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify a C3 Rx doesnot show up earliest fill date and there shall not be any restriction on days supply
    *
    * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "To verify a C3 Rx doesnot show up earliest fill date and there shall not be any restriction on days supply",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_223_tc_29_441176_New_Reg_025(Map<String, String> inputData) {

        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
//        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated,true);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(false,true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInput(inputData);
        Reporter.log("C3 Rx is not showing up earliest fill date and there is not any restriction on days supply");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:To verify the accept button is not getting enabled until the rx having Red and purple Durs are checked and approved on the Check DUR screen.
   *
   * Pre-Conditions:
   * 1. Pharmacist should be logged into the Connexus.
   * 2. Patient profile should be present in the store having allergies.
   * 3. Create an rx for the patient and rx should be pending in 4 point check work queue having Red and Purple DURs.
   *
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "To verify the accept button is not getting enabled until the rx having Red and purple Durs are checked and approved on the Check DUR screen.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RrAirPracticeComplianceDataBook.json", sheetName = "RrOrAirOrPracticeCompliance")
    public void HWPHME2E_222_tc_25_297436_Acceptbtn_Disabled_withOpenDURs(Map<String, String> inputData) {

        if(flagUpdated) {
            // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//            connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
            connexusAppUtils.readAndUpdateFlag("31555", "TRUE");
            connexusAppUtils.readAndUpdateFlag("20013", "TRUE");
            connexusAppUtils.readAndUpdateFlag("5361", "FALSE");
        }
        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff();
        rrAirPracticeComplianceTestSetScript.performInput(inputData);
        rrAirPracticeComplianceTestSetScript.perform4Point(true);
        rrAirPracticeComplianceTestSetScript.performChkDUR();
        Reporter.log("Accept button is not getting enabled until the rx having Red and purple Durs are checked and approved on the Check DUR screen");
        rrAirPracticeComplianceTestSetScript.verifyRxInFillingQueue();
    }
}