package connexus.coretest.testcases.cp1.userexperience;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceTestSet1 {

    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify whether Cursor is moving to selected grid in rx notes section in single click
     * and should display default search text.
     *
     * Jira Id HWRELSE-1069
     *
     * Pre-Conditions:
     * 1. Valid patient profile should be there in connexus.
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether Cursor is moving to selected grid in rx notes section in single click and " +
            "should display default search text.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_422_426304_Cursor_movement_validation_in_rx_note_section(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_422_426304_Cursor_movement_validation_in_rx_note_section<<<");

        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //Valid patient profile should be there in connexus.
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);
        userExperienceTestSetScript.createNewPatient(inputData);

        //1.Login to connexus with valid credentials | User should be able to login
        //2.Drop an RX for any patient profile. | User should be able to drop rx for the patient.
        //3.Process the RX with any drug and complete Input | Rx should be in 4 point work queue.
        userExperienceTestSetScript.performDropOff(Priority.Critical);
        userExperienceTestSetScript.performInput(inputData);
        userExperienceTestSetScript.selectFourPointRxInSearch();
        //4.In 4 point go to the menu bar and hover over CURRENT RX, then click on RX NOTES | User should be able to select Rx note.
        //5.Verify the RX notes | Rx notes should be verified
        userExperienceTestSetScript.navigateToRxNotesInFourPoint();

        //6.Click on the search field and clear the Rx number. | User should be able to clear the RX number.
        userExperienceTestSetScript.clickAndClearRxSearchTextInFourPoint();

        //7.Ensure cursor is in search text box and verify the default search text | Cursor should be in Search text box and Text box should be blank
        //8.Press tab  | "Keyword,Product name, date, Rx # ..."  text should be displayed in Search text box.
        userExperienceTestSetScript.validateRxTextBoxInFourPoint();

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickExitInRxNotesOfFourPoint();
        userExperienceTestSetScript.clickCancelInFourPoint();

        System.out.println("<<<HWPHME2E_422_426304_Cursor_movement_validation_in_rx_note_section>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate no check boxes are displayed in allergy/medical conditions tab for 27267 Flag off
     *
     * Jira Id HWCNXCLD-5296
     *
     * Pre-Conditions:
     * 1. 27267 - OFF
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Validate no check boxes are displayed in allergy/medical conditions tab for 27267 Flag off",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_344_Validate_No_Insulin_CheckBoxes_AllergyTab_PMS(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_344_Validate_No_Insulin_CheckBoxes_AllergyTab_PMS<<<");
        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1.27267 - OFF
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27267", "FALSE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);

        //1.Open existing/new patient profile in PTMS screen and move to Allergy/Medical conditions Tab. | Patient profile is opened successfully
        userExperienceTestSetScript.searchPatient();

        //2.Check whether  the insulin pump and insulin dependent CheckBoxes are not displayed | Checkboxes should not be displayed
        userExperienceTestSetScript.validateNoInsulinCheckBoxesInPMS();

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_344_Validate_No_Insulin_CheckBoxes_AllergyTab_PMS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify phone 1 is displayed in patient search grid.
     *
     * Jira Id HWCNXCLD-4693
     *
     * Pre-Conditions:
     * NA
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify phone 1 is displayed in patient search grid.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_365_Phone1_In_Search_Grid(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_365_Phone1_In_Search_Grid<<<");
        connexusAppUtils.getStoreId();

        //1.Turn off the flag 26849 Create a patient profile with phone1, phone2,phone3, and select  phone1 as preferred and save & close PTMS. | Patient profile should be saved successfully
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);
        userExperienceTestSetScript.createNewPatient(inputData);

        //2.Verify the details in DB and check records 1,2,10,20 are displayed | Records should be displayed in sucessfully
        //Test data - select * from patient where last_name='TEST' and first_name='AVINASH';
        //SELECT * FROM subject_comm WHERE subject_id=123455;
        userExperienceTestSetScript.validateCommSeqNbrForPhone1InDb();

        //3.Turn on the flag 26849 Press ctrl+shift+P and give patient details and check whether phone1 is displayed in search grid | Phone1 should be displayed in search grid scuccessfully
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);
        userExperienceTestSetScript.searchPatient();
        userExperienceTestSetScript.validatePhone1InPatientSearch(inputData);
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_365_Phone1_In_Search_Grid>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To validate error pop-up is displayed when a valid landline number is given for enrolling text
     *  messaging services.
     *
     * Jira Id HWCNXCLD-2505
     *
     * Pre-Conditions:
     * Landline recognition-26862 is True
     * Contact redesign Flag -26849 is True
     * For new patient or existing patient
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To validate error pop-up is displayed when a valid landline number is given for enrolling text messaging services.",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_347_PTMS_for_valid_landline_number_with_flag_on(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_347_PTMS_for_valid_landline_number_with_flag_on<<<");
        connexusAppUtils.getStoreId();

        //Pre-Conditions:
        //Landline recognition-26862 is True
        //Contact redesign Flag -26849 is True
        //For new patient or existing patient
        boolean f1 = connexusAppUtils.readAndUpdateFlag("26862", "TRUE");
        boolean f2 = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        flagUpdated = f1 || f2;
        userExperienceTestSetScript.initializeTestCase(flagUpdated);

        //1.open connexus application | user should be able to access application
        //2.open PMS by ctrl+shift+p and search for an new/existing patient and double click on the patient search result found in the grid  | PMS screen should open with the patient details
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.searchPatient();

        //3.try to enroll text messaging service with valid landline number | connexus should throw an pop error message, stating that "you have selected this number into text messaging, Please enter a valid mobile number" Then exit without saving changes
        userExperienceTestSetScript.enterNumberInMessagingSelectTextPMS(inputData);
        userExperienceTestSetScript.clickSaveAndCloseInPMS();
        userExperienceTestSetScript.validateTextMessagingValidLandlinePopUp();

        //4.verify  error_and_audit:appl_activity table select * from error_and_audit:appl_activity order by 1 desc | activity_coulmn should have an xml file with the given tags in the data column
        // ><AuditEntry Name=Patient ID" Value="117355" /><AuditEntry Name="Validate Landline in PMS" Value="3109974177" /><AuditEntry Name="ApplicationVersion" Value="3.43.0" />
        userExperienceTestSetScript.validateXmlOfActivityColumnInDb(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<tc_20_PTMS_for_valid_landline_number_with_flag_on>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To validate error pop-up is displayed when invalid landline number is given for enrolling text messaging services
     *
     * Jira Id HWCNXCLD-2506
     *
     * Pre-Conditions:
     * Landline recognition-26862 is True
     * Contact redesign Flag -26849 is True
     * For new patient or existing patient
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To validate error pop-up is displayed when invalid landline number is given for enrolling text messaging services",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_346_PTMS_for_invalid_landline_number_with_flag_on(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_346_PTMS_for_invalid_landline_number_with_flag_on<<<");
        connexusAppUtils.getStoreId();

        //Pre-Conditions:
        //Landline recognition-26862 is True
        //Contact redesign Flag -26849 is True
        //For new patient or existing patient
        boolean f1 = connexusAppUtils.readAndUpdateFlag("26862", "TRUE");
        boolean f2 = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        flagUpdated = f1 || f2;
        userExperienceTestSetScript.initializeTestCase(true);

        //1.open connexus application | user should be able to access application
        //2.open PMS by ctrl+shift+p and search for an new/existing patient and double click on the patient search result found in the grid  | PMS screen should open with the patient details
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.searchPatient();

        //3.try to enroll test messaging service with invalid number verify that "please enter a valid number" pop message is displayed | connexus should throw an pop error message, stating that " Please enter a valid mobile number"
        userExperienceTestSetScript.enterNumberInMessagingSelectTextPMS(inputData);
        userExperienceTestSetScript.clickSaveAndCloseInPMS();
        userExperienceTestSetScript.validateTextMessagingInvalidLandlinePopUp();

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_346_PTMS_for_invalid_landline_number_with_flag_on>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate PTMS for valid mobile number with flag on
     *
     * Jira Id HWCNXCLD-2507
     *
     * Pre-Conditions:
     * Landline recognition-26862 is True
     * Contact redesign Flag -26849 is True
     * For new patient or existing patient
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate PTMS for valid mobile number with flag on",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_348_PTMS_for_valid_mobile_number_with_flag_on(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_348_PTMS_for_valid_mobile_number_with_flag_on<<<");
        connexusAppUtils.getStoreId();

        //Pre-Conditions
        //1.Landline recognition-26862 is True
        //2.Contact redesign Flag -26849 is True
        //3.For new patient or existing patient
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26862", "TRUE") || connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);

        //1.open connexus application | user should be able to access application
        //2.open PMS by ctrl+shift+p and search for an new/existing patient and double click on the patient search result found in the grid | PMS screen should open with the patient details
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.searchPatient();

        //3.try to enroll test messaging service with valid mobile number, verify that no popup is displayed | no pop up is displayed
        userExperienceTestSetScript.enterNumberInMessagingSelectTextPMS(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_348_PTMS_for_valid_mobile_number_with_flag_on>>>");
    }


    // ALL BELOW TESTCASES ARE OBSOLETE OR NOT FEASIBLE FOR AUTOMATION OR DUPLICATE





    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate “Host lookup” button is disabled in Old product search screen on erasing the
     * strength or generic name and with only form clicking on search.
     *
     * Jira Id HWCNXCLD-3938
     *
     * Pre-Conditions:
     * 1. 26854-ON
     * 2. 5385-OFF
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To Validate “Host lookup” button is disabled in Old product search screen on erasing the " +
            "strength or generic name and with only form clicking on search.",enabled = false,
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_04_Host_Lookup_disabled_Product_search(Map<String, String> inputData) {
        System.out.println(">>>tc_04_Host_Lookup_disabled_Product_search<<<");

        //This test is obsolete

        //Pre-Conditions
        //1.26854-ON
        //2.5385-OFF
       if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "FALSE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(loginUser_Type);
        }

        //1.Open connexus Application | User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened with "name,strength,form,generic name,NDC" fields
        userExperienceTestSetScript.searchProductPage();
        userExperienceTestSetScript.validateProductSearchPage();

        //3.Input a data in "Form" & "Strength" & "Generic name" fields  and  click on search now and verify "Host lookup" button is enabled | "Host lookup" button should be enabled in search screen
        userExperienceTestSetScript.searchForProduct(inputData);
        userExperienceTestSetScript.validateHostLookUpEnabledInProductPage();

        //4.Erase strength,generic name field and with only form, click on search now | "Host lookup" button should be disabled in search screen
        userExperienceTestSetScript.clearStrengthGenericNameAndSearchInProduct();
        userExperienceTestSetScript.validateHostLookUpDisabledInProductPage();

        //To continue the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_04_Host_Lookup_disabled_Product_search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate “Host lookup” button is disabled in Old product search screen When a user is
     * searching product only with value in the “Form” field.
     *
     * Jira Id HWCNXCLD-3840
     *
     * Pre-Conditions:
     * 1. 5385 Flag is OFF
     * 2. 26854 Flag is ON
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To Validate “Host lookup” button is disabled in Old product search screen When a user is " +
            "searching product only with value in the “Form” field.",enabled = false,
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_04_Host_Lookup_disabled_Product_search"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_05_Host_Lookup_disabled_Form_Field_Product_search(Map<String, String> inputData) {
        System.out.println(">>>tc_05_Host_Lookup_disabled_Form_Field_Product_search<<<");

        //This test is obsolete
        //Pre-Conditions
        //1.5385 Flag is OFF
        //2.26854 Flag is ON

        //1.Open connexus Application | User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened with "name,strength,form,generic name,NDC" fields
        userExperienceTestSetScript.searchProductPage();

        //3.Input a data in "Form" field  and  click on search now and verify "Host lookup" button is disabled | "Host lookup" button should be disabled in search screen
        userExperienceTestSetScript.enterFormAndSearchInProduct(inputData);
        userExperienceTestSetScript.validateHostLookUpDisabledInProductPage();

        //To continue the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_05_Host_Lookup_disabled_Form_Field_Product_search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:The patient's modified and previous LN and FN in PMS displays on the consolidated notes view
     *
     * Jira Id HWUSEREX-2068
     *
     * Pre-Conditions:
     * NA
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "The patient's modified and previous LN and FN in PMS displays on the consolidated notes view",enabled = false,
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_06_Modified_Ln_fn_consolidated_View(Map<String, String> inputData) {
        System.out.println(">>>tc_06_Modified_Ln_fn_consolidated_View<<<");

        //This test case is duplicated in HWQEAUTO-19399


        //1.Login to connexus | Connexus application should launch
        //2.Open existing patient in PMS | Should able to open existing patient in PMS
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);

        //3.Modify the Last Name & First Name | User should able to modify Last Name & First Name
        //4.Click save and close | Consolidated notes view should load
        //5.Verify previous LN & FN and modified LN & FN is displaying on the consolidated notes view | Previous LN & FN and modified LN & FN should display on the consolidated notes view
        userExperienceTestSetScript.modifyPatientLnFnInPMSAndValidate(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitInConsolidatedNotesScreen();
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<tc_06_Modified_Ln_fn_consolidated_View>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that the allergy information created in a WKAllergy ON store can be hostpulled into a WKAllergy ON NDS store.
     *
     * Jira Id HWCENTIND-1126
     *
     * Pre-Conditions:
     * Store A: PMS ON, WKAllergy ON
     * Store B: PMS ON, WKAllergy ON, NDS
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify that the allergy information created in a WKAllergy ON store can be hostpulled into a WKAllergy ON NDS store.",
            priority = 7,enabled = false)
    public void tc_07_hostpulled_WKAllergy_ON_WKAllergy_ON_NDS() {
        System.out.println(">>>tc_07_hostpulled_WKAllergy_ON_WKAllergy_ON_NDS<<<");

        //This test case not feasible.

        // not feasible for Automation
        //Pre-Conditions:
        //Store A: PMS ON, WKAllergy ON
        //Store B: PMS ON, WKAllergy ON, NDS

        //1.Open Connexus in Store A. | Connexus should open.
        //2.Open the PMS and enter mandatory fields for a new patient. | The PMS should open and info should be entered for a new patient.
        //3.Switch to the Allergy/Medical Conditions tab add the following:-An allergy.-A deactivated allergy. | The allergies should appear in the allergy grid below.
        //4.Save the patient. | The PMS should close.
        //5.Verify that the patient and allergy info is saved to CDB with the following queries:
        //select * from pfPHMCEN.patient where last_name='<last name>' and first_name='<first name>' and store_nbr=<store number>;
        //SELECT * FROM PFPHMCEN.PATIENT_ALLERGY WHERE PATIENT_ID = '<patient id>' AND STORE_NBR = '<store number>'; | The records should be found in CDB.
        //6.Open Connexus in store B. | Connexus should open
        //7.Host search for and host pull the patient profile created in Store A. Saved the patient to the store. | The patient patient should be saved to the store.
        //8.The patient patient should be saved to the store. | The patient info and allergy info should be saved to CDB.
        //9.Open the PMS for the profile in Store B and verify the allergies are listed in the allergy grid. | The allergies should be listed in the allergy grid.
        userExperienceTestSetScript.nonAutomateScenario();
        Reporter.log("Test case involves functionalities in Store A and Store B,so it complicate to automate");

        System.out.println("<<<tc_07_hostpulled_WKAllergy_ON_WKAllergy_ON_NDS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that when a new allergy is added to a patient profile in store A(WKAllergy ON), and
     * a linked profile is opened in store B(WKAllergy ON), then that allergy will be added to the store B profile.
     *
     * Jira Id HWCENTIND-1127
     *
     * Pre-Conditions:
     * Store A: PMS ON, WKAllergy ON
     * Store B: PMS ON, WKAllergy ON, NDS
     * Have a patient profile in store A that is linked to a patient profile in store B
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify that when a new allergy is added to a patient profile in store A(WKAllergy ON), and " +
            "a linked profile is opened in store B(WKAllergy ON), then that allergy will be added to the store B profile.",
            priority = 8,enabled = false)
    public void tc_08_new_allergy_auto_synced_WKAllergy_ON_WKAllergy_ON_NDS() {
        System.out.println(">>>tc_08_new_allergy_auto_synced_WKAllergy_ON_WKAllergy_ON_NDS<<<");

        // not feasible for Automation

        //Pre-Conditions:
        //Store A: PMS ON, WKAllergy ON
        //Store B: PMS ON, WKAllergy ON, NDS
        //Have a patient profile in store A that is linked to a patient profile in store B

        //1.Open Connexus in store A and open the PMS for the patient. | Connexus should open and the PMS should be displayed for the patient.
        //2.Add a new allergy for the patient and save. | The PMS should close and the new allergy should be saved for the patient.
        //3.Verify that the allergy is saved to CDB by querying the PATIENT_ALLERGY table for the patient. | The new allergy should appear in the query results.
        //4.Open Connexus in Store B and open the PMS for the linked patient profile. | Connexus should open and the PMS for the patient profile should be displayed.
        //5.Verify that the allergy added to the patient profile in store A is displayed for the patient profile in store B. | The new allergy should be displayed on the PMS for the store B profile.
        //6.Save the store B profile and query the PATIENT_ALLERGY table for the patient. | The new allergy should appear in the query results.
        userExperienceTestSetScript.nonAutomateScenario();
        Reporter.log("Test case involves functionalities in Store A and Store B,so it complicate to automate");

        System.out.println("<<<tc_08_new_allergy_auto_synced_WKAllergy_ON_WKAllergy_ON_NDS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that a one-to-many mapped old allergy code is converted to a new code when hostpulled to WKAllergy ON_DS
     *
     * Jira Id HWCENTIND-1147
     *
     * Pre-Conditions:
     * Store A: PMS ON, WKAllergy OFF
     * Store B: PMS ON, WKAllergy ON, DS
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify that a one-to-many mapped old allergy code is converted to a new code when hostpulled to WKAllergy ON_DS",
            priority = 9,enabled = false)
    public void tc_09_one_to_many_mapped_old_code_to_new_code_when_hostpulled_to_WKAllergy_ON_DS() {
        System.out.println(">>>tc_09_one_to_many_mapped_old_code_to_new_code_when_hostpulled_to_WKAllergy_ON_DS<<<");

        // not feasible for Automation
        //Pre-Conditions:
        //Store A: PMS ON, WKAllergy OFF
        //Store B: PMS ON, WKAllergy ON, DS

        //1.Create a patient in Store A and add an allergy that is mapped one-to-many between the old and new allergy codes. | Patient should be created and allergy should be added.
        //2.Verify that the patient and allergy is saved to CDB. | The patient and allergy info should be saved to CDB.
        //3.Hostpull the patient into Store B and save. Open the PMS and save to trigger allergy conversion. Use the allergy conversion wizard to convert the allergy. | The patient should be saved to store B. The allergy code should be converted.
        //4.Verify that the patient's allergy record is converted to a new allergy code in CDB.  The old allergy record should appear as deactivated and the new allergy code should be added as a new record. | The allergy should have a new allergy code in CDB.
        userExperienceTestSetScript.nonAutomateScenario();
        Reporter.log("Test case involves functionalities in Store A and Store B,so it complicate to automate");

        System.out.println("<<<tc_09_one_to_many_mapped_old_code_to_new_code_when_hostpulled_to_WKAllergy_ON_DS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify that a one-to-one mapped old allergy code is converted to new code when hostpulled to WKAllergy ON_NDS
     *
     * Jira Id HWCENTIND-1131
     *
     * Pre-Conditions:
     * Store A: PMS ON, WKAllergy OFF
     * Store B: PMS ON, WKAllergy ON, NDS
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "To verify that a one-to-one mapped old allergy code is converted to new code when hostpulled to WKAllergy ON_NDS",
            priority = 10,enabled = false)
    public void tc_10_one_to_one_mapped_old_code_to_new_code_when_hostpulled_to_WKAllerg_ON_NDS() {
        System.out.println(">>>tc_10_one_to_one_mapped_old_code_to_new_code_when_hostpulled_to_WKAllerg_ON_NDS<<<");

        // not feasible for Automation
        //Pre-Conditions:
        //Store A: PMS ON, WKAllergy OFF
        //Store B: PMS ON, WKAllergy ON, NDS

        //1.Create a patient in Store A and add a allergy that is mapped one-to-one between the old and new allergy codes. | Patient should be created and allergy should be added.
        //2.Verify that the patient and allergy is saved to CDB. | The patient and allergy info should be saved to CDB.
        //3.Hostpull the patient into Store B and save. Open the PMS again and save the patient to trigger allergy conversion. The allergy should automatically get converted to a new allergy code. | The patient should be saved to store B. The allergy code should be automatically converted.
        //4.Verify that the patient's allergy record is converted to a new allergy code in CDB. | The allergy should have a new allergy code in CDB.
        userExperienceTestSetScript.nonAutomateScenario();
        Reporter.log("Test case involves functionalities in Store A and Store B,so it complicate to automate");

        System.out.println("<<<tc_10_one_to_one_mapped_old_code_to_new_code_when_hostpulled_to_WKAllerg_ON_NDS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate number of records are displayed same for Name field in product search screen when compared with API response.
     *
     * Jira Id HWCNXCLD-3113
     *
     * Pre-Conditions:
     * 26854 Flag is ON
     * 5385 Flag is ON
     *
     * PostMan Set up
     * https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup
     * { "productName": "", "ndcNbr": "", "genericName": "", "gpi": "", "strength": "", "upcNumber": "", "itemNumber": "", "singleLikeFlag": true }
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To Validate number of records are displayed same for Name field in product search screen when compared with API response.",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_11_No_of_Records_Name_Field_Product_Search(Map<String, String> inputData) {
        System.out.println(">>>tc_11_No_of_Records_Name_Field_Product_Search<<<");
        //("This Test Case is Obsolete");
        //Pre-Conditions:
        //1.26854 Flag is ON
        //2.5385 Flag is ON
        if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1.Open connexus Application in store 'A'| User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened
        userExperienceTestSetScript.searchProductPage();

        //3.Input data  in Name field and  click on Host look up button and compare the number of records displayed with API response. | Number of records should match in UI & API response.
        userExperienceTestSetScript.enterNameAndSearchInProduct(inputData);
        userExperienceTestSetScript.clickHostButtonInProduct();
        userExperienceTestSetScript.validateProductCountApi(inputData);

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_11_No_of_Records_Name_Field_Product_Search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate number of records are displayed same for Name,Generic name, GPI, NDC, UPC fields in Product search screen.
     *
     * Jira Id HWCNXCLD-3073
     *
     * Pre-Conditions:
     * 26854 Flag is ON
     * 5385 Flag is ON
     *
     * PostMan Set up
     * https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup
     * { "productName": "", "ndcNbr": "", "genericName": "", "gpi": "", "strength": "", "upcNumber": "", "itemNumber": "", "singleLikeFlag": true }
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To Validate number of records are displayed same for Name,Generic name, GPI, NDC, UPC fields in Product search screen.",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_12_No_of_Records_Name_Generic_GPI_NDC_UPC_Field_Product_Search(Map<String, String> inputData) {
        System.out.println(">>>tc_12_No_of_Records_Name_Generic_GPI_NDC_UPC_Field_Product_Search<<<");
        //This Test Case is Obsolete
        //Pre-Conditions:
        //1.26854 Flag is ON
        //2.5385 Flag is ON
        if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1.Open connexus Application in store 'A'| User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened
        userExperienceTestSetScript.searchProductPage();

        //3.Input the datas in Name,Generic name, GPI, NDC, UPC fields and  click on search and then click on Host look up button and take the count of number of records displayed. | User should be able to see the details and should be able to take the count of number of records displayed
        userExperienceTestSetScript.enterNameGenericGpiNdcUpcAndSearchInProduct(inputData);
        userExperienceTestSetScript.clickHostButtonInProduct();

        //4.Compare the records with API response | The number of records should be matched
        userExperienceTestSetScript.validateProductCountApi(inputData);

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_12_No_of_Records_Name_Generic_GPI_NDC_UPC_Field_Product_Search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate number of records are displayed same for Name and NDC field in product
     * search screen when compared with API response.
     *
     * Jira Id HWCNXCLD-3290
     *
     * Pre-Conditions:
     * 26854 Flag is ON
     * 5385 Flag is ON
     *
     * PostMan Set up
     * https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup
     * { "productName": "", "ndcNbr": "", "genericName": "", "gpi": "", "strength": "", "upcNumber": "", "itemNumber": "", "singleLikeFlag": true }
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To Validate number of records are displayed same for Name and NDC field in product " +
            "search screen when compared with API response.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_13_No_of_Records_Name_NDC_Field_Product_Search(Map<String, String> inputData) {
        System.out.println(">>>tc_13_No_of_Records_Name_NDC_Field_Product_Search<<<");
        //This Test Case is Obsolete
        //Pre-Conditions:
        //1.26854 Flag is ON
        //2.5385 Flag is ON
        if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1.Open connexus Application in store 'A'| User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened
        userExperienceTestSetScript.searchProductPage();

        //3.Input data in "Name" & "NDC" field and  click on Host look up button and take the count of number of records displayed. | User should be able to see the details and should be able to take the count of number of records displayed
        userExperienceTestSetScript.enterNameNdcAndSearchInProduct(inputData);
        userExperienceTestSetScript.clickHostButtonInProduct();

        //4.Compare the records with API response | The number of records should be matched
        userExperienceTestSetScript.validateProductCountApi(inputData);

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_13_No_of_Records_Name_NDC_Field_Product_Search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate number of records are displayed same for Name, UPC and NDC fields in product search screen
     *
     * Jira Id HWCNXCLD-3063
     *
     * Pre-Conditions:
     * 26854 Flag is ON
     * 5385 Flag is ON
     *
     * PostMan Set up
     * https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup
     * { "productName": "", "ndcNbr": "", "genericName": "", "gpi": "", "strength": "", "upcNumber": "", "itemNumber": "", "singleLikeFlag": true }
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To Validate number of records are displayed same for Name, UPC and NDC fields in product search screen",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_14_No_of_Records_Name_UPC_NDC_Field_Product_Search(Map<String, String> inputData) {
        System.out.println(">>>tc_14_No_of_Records_Name_UPC_NDC_Field_Product_Search<<<");

        //This Test Case is Obsolete

        //Pre-Conditions:
        //1.26854 Flag is ON
        //2.5385 Flag is ON
        if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1.Open connexus Application in store 'A'| User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened
        userExperienceTestSetScript.searchProductPage();

        //3.Input data  in "Name" , "UPC", "NDC" field and  click on Host look up button and take the count of number of records displayed. | User should be able to see the details and should be able to take the count of number of records displayed
        userExperienceTestSetScript.enterNameNdcUpcAndSearchInProduct(inputData);
        userExperienceTestSetScript.clickHostButtonInProduct();

        //4.Compare the records with API response | The number of records should be matched
        userExperienceTestSetScript.validateProductCountApi(inputData);

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_14_No_of_Records_Name_UPC_NDC_Field_Product_Search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate number of records are displayed same for name, GPI,UPC fields in Product search screen.
     *
     * Jira Id HWCNXCLD-3075
     *
     * Pre-Conditions:
     * 26854 Flag is ON
     * 5385 Flag is ON
     *
     * PostMan Set up
     * https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup
     * { "productName": "", "ndcNbr": "", "genericName": "", "gpi": "", "strength": "", "upcNumber": "", "itemNumber": "", "singleLikeFlag": true }
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To Validate number of records are displayed same for name, GPI,UPC fields in Product search screen.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_15_No_of_Records_Name_GPI_UPC_Field_Product_Search(Map<String, String> inputData) {
        System.out.println(">>>tc_15_No_of_Records_Name_GPI_UPC_Field_Product_Search<<<");

        //This Test Case is Obsolete

        //Pre-Conditions:
        //1.26854 Flag is ON
        //2.5385 Flag is ON
        if (connexusAppUtils.readAndUpdateFlag("26854", "TRUE") || connexusAppUtils.readAndUpdateFlag("5385", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //1.Open connexus Application in store 'A'| User should be able to login to connexus Application
        //2.Open product search screen by Ctrl+shift+D | Patient product screen should be opened
        userExperienceTestSetScript.searchProductPage();

        //3.Input data  in "Name" ,  "upc" , "gpi" field and  click on Host look up button | User should be able to see the details and number of records should match.
        userExperienceTestSetScript.enterNameGpiUpcAndSearchInProduct(inputData);
        userExperienceTestSetScript.clickHostButtonInProduct();
        userExperienceTestSetScript.validateProductCountApi(inputData);

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInProductSearch();

        System.out.println("<<<tc_15_No_of_Records_Name_GPI_UPC_Field_Product_Search>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify phone 2 is displayed in patient search grid.
     *
     * Jira Id HWCNXCLD-4694
     *
     * Pre-Conditions:
     * NA
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify phone 2 is displayed in patient search grid.",enabled = false,
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_16_Phone1_In_Search_Grid"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_17_Phone2_In_Search_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc_17_Phone2_In_Search_Grid<<<");

        //("This Test Case Obsolete");// because in new PMS there is no ph no 2

        //1.Turn off 26849 flag and Create a patient profile with phone1, phone2,phone3, and select  phone1 as preferred and save & close PTMS.| Patient profile should be saved successfully
        //2.Verify the details in DB and check records 1,2,10,20 are displayed | Records should be displayed in sucessfully
        //3.Turn on the flag 26849 Press ctrl+shift+P and give patient details and check whether phone1 is displayed in search grid | Phone1 should be displayed in search grid scuccessfully
        //4.Now delete phone1 and check whether phone2 is displayed in patient search grid. | Phone2 should be displayed in search grid scuccessfully
        userExperienceTestSetScript.selectPatientInSearchGrid();
        userExperienceTestSetScript.removePrimaryPhoneNbrInPMS();
        userExperienceTestSetScript.clickSaveAndCloseInPMS();
        userExperienceTestSetScript.searchPatient(inputData);
        userExperienceTestSetScript.validatePhone2InPatientSearch(inputData);

        //5.Validate the records in DB and check whether records with 10,2 are displayed | Both 10,2 records should be displayed in DB successfully
        userExperienceTestSetScript.validateCommSeqNbrForPhone2InDb();

        System.out.println("<<<tc_17_Phone2_In_Search_Grid>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify phone 3 is displayed in patient search grid.
     *
     * Jira Id HWCNXCLD-4695
     *
     * Pre-Conditions:
     * NA
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify phone 3 is displayed in patient search grid.",enabled = false,
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_17_Phone2_In_Search_Grid"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_18_Phone3_In_Search_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc_18_Phone3_In_Search_Grid<<<");
        //("This Test Case Obsolete");// because in new PMS there is no ph no 3

        //1.Turn off 26849 flag and Create a patient profile with phone1, phone2,phone3, and select  phone1 as preferred and save & close PTMS.| Patient profile should be saved successfully
        //2.Verify the details in DB and check records 1,2,10,20 are displayed | Records should be displayed in sucessfully
        //3.Turn on the flag 26849 Press ctrl+shift+P and give patient details and check whether phone1 is displayed in search grid | Phone1 should be displayed in search grid scuccessfully
        //4.Now delete phone1 and check whether phone2 is displayed in patient search grid. | Phone2 should be displayed in search grid scuccessfully
        //5.Validate the records in DB and check whether records with 10,2 are displayed | Both 10,2 records should be displayed in DB successfully
        //6.Now delete phone2 and check whether phone3 is displayed in patient search grid. | Phone3 should be displayed in search grid scuccessfully
        userExperienceTestSetScript.selectPatientInSearchGrid();
        userExperienceTestSetScript.removePrimaryPhoneNbrInPMS();
        userExperienceTestSetScript.clickSaveAndCloseInPMS();
        userExperienceTestSetScript.searchPatient(inputData);
        userExperienceTestSetScript.validatePhone3InPatientSearch(inputData);

        //7.Validate the records in DB and check whether record with 2 is displayed | 1 record with comm_seq nbr 2 is displayed in DB successfully
        userExperienceTestSetScript.validateCommSeqNbrForPhone3InDb();

        System.out.println("<<<tc_18_Phone3_In_Search_Grid>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Messaging number as preferred_To validate no number is displayed in patient search grid
     *
     * Jira Id HWCNXCLD-4696
     *
     * Pre-Conditions:
     * NA
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "Messaging number as preferred_To validate no number is displayed in patient search grid",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = false,
            dependsOnMethods = {"tc_16_Phone1_In_Search_Grid"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_19_No_Number_Search_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc_19_No_Number_Search_Grid<<<");
        // This Test Case Obsolete
        //1.Turn off flag 26849 and create a patient with both prefered  number and messaging number as same | Patient profile is created successfully
        if (connexusAppUtils.readAndUpdateFlag("26849", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);
        userExperienceTestSetScript.updatePrefMessagingPhone();
        userExperienceTestSetScript.clickSaveAndCloseInPMS();

        //2.Validate the records in DB and check whether record with 20 is displayed | 1 record with comm_seq nbr 20 is displayed in DB successfully
        userExperienceTestSetScript.validateCommSeqNbrForPreferred();

        //3.Press ctrl+shift+P  and search for the patient details. | No number should be displayed in patient search grid.
        userExperienceTestSetScript.searchPatient(inputData);
        userExperienceTestSetScript.validateNoPhoneNbrInSearchResult();

        //To continue to the flow of next test case
        userExperienceTestSetScript.clickCloseInPatientSearch();

        System.out.println("<<<tc_19_No_Number_Search_Grid>>>");
    }*/

     /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify validation popup saying Required information is missing or invalid And
     * for a bulleted list of the missing or invalid information to be below that text is displayed
     * when all the required Info is missing while creating a new patient
     *
     * Jira Id HWUSEREX-2037
     *
     * Pre-Conditions:
     * 1. PMS flag 27247 should be "TRUE"
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify validation popup saying Required information is missing or invalid And" +
            " for a bulleted list of the missing or invalid information to be below that text is displayed" +
            " when all the required Info is missing while creating a new patient",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void tc_02_Validate_Required_Information_PMS(Map<String, String> inputData) {
        System.out.println(">>>tc_02_Validate_Required_Information_PMS<<<");

        //Pre-Conditions
        //1.PMS flag 27247 should be "TRUE"
        if (connexusAppUtils.readAndUpdateFlag("27247", "TRUE")) {
            tearDown();
            userExperienceTestSetScript = new UserExperienceTestSetScript();
            userExperienceTestSetScript.loginConnexus(loginUser_Type);
        }

        //1.Login to connexus | Connexus homepage should be displayed
        //2.Open search screen, Search for a profile and create a new patient | PMS should load
        appCommonFunctions.appCommonFunctions();
        appCommonFunctions.searchPatientWithName(inputData);

        //3.Remove the data entered in LN,FN and DOB fields | Data should be removed from the fields
        userExperienceTestSetScript.clearFnLnDobFromPMS();

        //4.Hit save & close button on PMS and validate the pop-up message | Validation popup should display And for the popup to read, "Required information is missing or invalid" -Last Name -First name -Date Of Birth
        userExperienceTestSetScript.clickSaveAndValidatePopUpMessage();

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<tc_02_Validate_Required_Information_PMS>>>");
  }*/

}