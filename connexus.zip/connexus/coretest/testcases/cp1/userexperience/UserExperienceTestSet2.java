package connexus.coretest.testcases.cp1.userexperience;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceTestSet2 {

    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    //NOT VALID

    /*----------------------------------------------------------------------------------------------------------
     * TTo Validate resident Portion of DEA is expanded to 10 characters
     *
     * Jira Id HWQEAUTO-10275
     *
     * Pre-Conditions:
     * Author: Narayanaswamy (n0s06rk)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(description = "To Validate resident Portion of DEA is expanded to 10 characters",enabled = true,
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void CP1_HWQEAUTO_10275(Map<String, String> inputData) {
        System.out.println(">>>To Validate resident Portion of DEA is expanded to 10 characters<<<");
        connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.createNewPrescriber(inputData);
        userExperienceTestSetScript.verifyNewPrescriberCreated(inputData);
        System.out.println("<<<To Validate resident Portion of DEA is expanded to 10 characters>>>");
    }*/
    
    // This test case CP1_HWQEAUTO_10216 is duplicate as similar to CP1_HWQEAUTO_10275 so its not required to validate.
    /*----------------------------------------------------------------------------------------------------------
   * TC03_To Validate resident Portion of DEA is allowed to enter less to 10 characters in "Suffix" column
   *
   * Jira Id HWQEAUTO-10216
   *
   * Pre-Conditions:
   * Author: Narayanaswamy (n0s06rk)
   ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "TC03_To Validate resident Portion of DEA is allowed to enter less to 10 characters in Suffix column",
            priority = 2,enabled = true, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/CP1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void CP1_HWQEAUTO_10216(Map<String, String> inputData) {
        System.out.println(">>>TC03_To Validate resident Portion of DEA is allowed to enter less to 10 characters in Suffix column<<<");
        connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        userExperienceTestSetScript.createNewPrescriber(inputData);
        userExperienceTestSetScript.verifyNewPrescriberCreated(inputData);
        System.out.println("<<<TC03_To Validate resident Portion of DEA is allowed to enter less to 10 characters in Suffix column>>>");
    } */

    /*----------------------------------------------------------------------------------------------------------
  * TC03_To Validate resident Portion of DEA is allowed to enter less to 10 characters in "Suffix" column
  *
  * Jira Id HWPHME2E-352
  *
  * Pre-Conditions:
  * Author: Narayanaswamy (n0s06rk)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether Patients modified LN/FN/DOB/SSN will replace the previous data and update with the modify LN/FN/DOB/SSN when user enter the reason for change in consolidated notes view and saved it",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/cp1/UserExperience/Cp1UserExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void CP1_HWPHME2E_352(Map<String, String> inputData) {
        System.out.println(">>>Verify whether Patients modified LN/FN/DOB/SSN will replace the previous data and update with the modify LN/FN/DOB/SSN when user enter the reason for change in consolidated notes view and saved it<<<");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27247", "TRUE");
        userExperienceTestSetScript.initializeTestCase(flagUpdated);
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.updatePatientLS_FS_DOB_SSN(inputData);
        userExperienceTestSetScript.enterConsolidatedNote(inputData);
        userExperienceTestSetScript.verifyPatient_LS_FN_DOB_SSN_Updated(inputData);
        userExperienceTestSetScript.verifyConsidatedNotes(inputData);
        System.out.println("<<<Verify whether Patients modified LN/FN/DOB/SSN will replace the previous data and update with the modify LN/FN/DOB/SSN when user enter the reason for change in consolidated notes view and saved it>>>");
    }

}
